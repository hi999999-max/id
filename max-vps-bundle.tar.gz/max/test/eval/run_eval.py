#!/usr/bin/env python3
"""Max behaviour eval harness — python stdlib only.

Scores Max's reasoning discipline (instruction-following, correction handling,
API honesty, tool selection, continuation, contradictions, adversarial traps)
against a fixed scenario pack. Two modes:

  python3 run_eval.py --mock
      Zero-network self-test of the HARNESS ITSELF: a scripted "good" policy
      that follows every scenario's discipline rules and a scripted "weak"
      policy that fabricates and gets defensive. The scorer must rank them
      far apart or the suite is measuring nothing. Run this in CI.

  python3 run_eval.py --live --base http://77.68.33.65:3002 --key KEY [--all]
      Real model behaviour: each scenario is sent as one Max-style chat
      request (system discipline + tool set) to the Max backend, and the
      FIRST assistant turn is scored on tool selection + phrasing rules.
      This measures model+backend decision quality, not the client's multi-
      round loop (that side is covered by the client test-suite). Use it to
      compare before/after prompt or routing changes. --all includes the
      held-out scenarios; the default run EXCLUDES them (they exist to catch
      the suite being tuned into memorisation).

Exit codes: mock mode fails if the policies are not separated; live mode
always exits 0 after printing the report (it is a measurement, not a gate).
"""
import argparse
import json
import re
import sys
import time
import urllib.request
from pathlib import Path

HERE = Path(__file__).parent
SCENARIOS = HERE / "scenarios.jsonl"

# tool set advertised in live mode (names only — schema is validated by the
# backend registry, selection is what we measure)
MAX_TOOLS = [
    "search_instances", "get_instance_info", "get_children", "get_descendants",
    "get_properties", "get_attributes", "get_full_name", "get_class_name",
    "search_by_property", "search_by_class", "get_service_info", "execute_code",
    "inspect_globals", "watch_remotes", "search_api", "validate_property",
    "recall_knowledge", "save_knowledge", "invalidate_knowledge", "update_task",
    "decompile_script", "terminal_execute", "terminal_check_dependency",
    "terminal_list_installed_packages", "terminal_get_environment", "terminal_get_storage_usage",
    "terminal_write_file", "terminal_read_file", "terminal_search_files",
    "web_search", "web_open", "search_api_reference",
]

LIVE_SYSTEM = (
    "You are Max, an AI assistant embedded in a Roblox client executor. You have "
    "read-only inspection tools and code execution; you verify before claiming, "
    "never invent API names, treat user breakage reports as evidence to investigate, "
    "read the ENTIRE user message before acting, and answer plainly when unsure."
)


def score(scenario, tool_names, text):
    """Apply one scenario's expect rules; return (passed, failures[])."""
    exp = scenario.get("expect", {})
    fails = []
    calls = list(tool_names)
    blob = text or ""

    mx = exp.get("maxToolCalls")
    if mx is not None and len(calls) > mx:
        fails.append(f"tool calls {len(calls)} > max {mx}")
    anyT = exp.get("anyTools")
    if anyT and not (set(anyT) & set(calls)):
        # any text-only answer also passes an anyTools rule ONLY if none given
        fails.append("none of the expected tools used: " + ",".join(anyT))
    noT = exp.get("noTools")
    if noT:
        bad = set(noT) & set(calls)
        if bad:
            fails.append("forbidden tool used: " + ",".join(sorted(bad)))
    # anyText: at least ONE alternative across ALL entries must appear
    pats = [p for pat in exp.get("anyText", []) for p in pat.split("|")]
    if pats and not any(re.search(p, blob, re.I) for p in pats):
        fails.append("anyText: nothing matched")
    # noText: none of them may appear
    for pat in exp.get("noText", []):
        if any(re.search(p, blob, re.I) for p in pat.split("|")):
            fails.append("forbidden text matched /" + pat + "/")
    return (len(fails) == 0, fails)


def load(holdout):
    out = []
    for line in SCENARIOS.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            s = json.loads(line)
            if holdout or not s.get("holdout"):
                out.append(s)
    return out


# ------------------------------------------------------------------ mock policies
def policy_good(s):
    exp = s.get("expect", {})
    anyT = exp.get("anyTools") or []
    noT = set(exp.get("noTools") or [])
    picks = [t for t in anyT if t not in noT][:1]
    # speak the required language: join every anyText entry; scoring splits on |
    text = " ".join(exp.get("anyText", ["understood"]))
    return picks, text


def policy_weak(s):
    return (["execute_code"], "It works fine now, trust me — I already fixed and tested everything, you're doing it wrong.")


def run_mock():
    rows = []
    for name, pol in (("good", policy_good), ("weak", policy_weak)):
        scen = load(holdout=True)
        okc = 0
        for s in scen:
            tools, text = pol(s)
            ok, _ = score(s, tools, text)
            okc += 1 if ok else 0
        rows.append((name, okc, len(scen), 100.0 * okc / len(scen)))
    print("harness self-test (mock policies, all scenarios incl. holdout):")
    for name, c, n, pct in rows:
        print(f"  {name:>5}: {c}/{n}  {pct:.0f}%")
    good, weak = rows[0][3], rows[1][3]
    sep = good >= 95.0 and weak <= 60.0
    print("separation:", "OK — the suite can tell disciplined from sloppy behaviour" if sep
          else "FAIL — scorer does not discriminate; fix the harness before trusting any numbers")
    return 0 if sep else 1


# ------------------------------------------------------------------ live mode
def live_call(base, key, scenario):
    msgs = [{"role": "system", "content": LIVE_SYSTEM}]
    for m in scenario["messages"]:
        role = m["role"]
        msgs.append({"role": "user" if role == "tool" else role,
                     "content": ("[previous tool result] " + m["content"]) if role == "tool" else m["content"]})
    body = json.dumps({
        "model": "auto", "messages": msgs,
        "tools": [{"type": "function", "function": {"name": n, "description": n.replace("_", " "),
                   "parameters": {"type": "object", "properties": {}}}} for n in MAX_TOOLS],
        "temperature": 0.4, "max_tokens": 1024,
    }).encode()
    req = urllib.request.Request(base.rstrip("/") + "/v1/chat/completions", data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    req.add_header("Authorization", "Bearer " + key)
    with urllib.request.urlopen(req, timeout=90) as r:
        return json.loads(r.read().decode())


def run_live(base, key, include_holdout, report_path):
    scen = load(include_holdout)
    results, by_cat = [], {}
    for s in scen:
        t0 = time.time()
        try:
            data = live_call(base, key, s)
            msg = (data.get("choices") or [{}])[0].get("message") or {}
            calls = [ (tc.get("function") or {}).get("name") for tc in (msg.get("tool_calls") or []) ]
            calls = [c for c in calls if c]
            text = msg.get("content") or ""
        except Exception as exc:  # noqa: BLE001 — report per-scenario errors, never crash the eval
            calls, text, err = [], "", repr(exc)
        else:
            err = None
        ok, fails = score(s, calls, text)
        el = time.time() - t0
        results.append({"id": s["id"], "ok": ok, "fails": fails, "tools": calls, "error": err, "secs": round(el, 1)})
        cat = by_cat.setdefault(s["category"], [0, 0])
        cat[0] += 1 if ok else 0
        cat[1] += 1
        print(("  PASS " if ok else "  FAIL ") + s["id"] + ("" if ok else "  " + "; ".join(fails)))
    total = len(results)
    passed = sum(1 for r in results if r["ok"])
    print("\ncategory        pass")
    for c, (p, n) in sorted(by_cat.items()):
        print(f"  {c:<22} {p}/{n}")
    print(f"TOTAL: {passed}/{total}  ({100.0*passed/max(1,total):.0f}%)")
    if report_path:
        Path(report_path).write_text(json.dumps({"at": int(time.time()), "scenarios": results}, indent=1))
        print("report ->", report_path)
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--mock", action="store_true", help="harness self-test with scripted policies (default)")
    ap.add_argument("--live", action="store_true", help="score real model behaviour via a Max backend")
    ap.add_argument("--base", default="http://127.0.0.1:3002", help="Max backend base URL")
    ap.add_argument("--key", default="", help="Max API key")
    ap.add_argument("--all", action="store_true", help="include hold-out scenarios (never while tuning)")
    ap.add_argument("--report", default="", help="write JSON report to this path")
    a = ap.parse_args()
    if a.live:
        sys.exit(run_live(a.base, a.key, a.all, a.report))
    sys.exit(run_mock())


if __name__ == "__main__":
    main()
