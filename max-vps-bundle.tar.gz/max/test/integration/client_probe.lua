-- Drives the REAL Max client bundle against the REAL Max backend using a
-- curl-backed executor transport (stands in for syn.request during tests).
-- Backend port + key arrive via environment.
local port = os.getenv("MAX_PORT") or error("MAX_PORT")
local key = os.getenv("MAX_KEY") or "test-key"

-- curl-based transport with syn.request semantics -------------------------
local TMP = os.tmpname()
local function runCmd(cmd)
    local p = assert(io.popen(cmd .. " 2>/dev/null", "r"))
    local out = p:read("*a")
    p:close()
    return out
end
_G.http_request = function(t)
    assert(type(t) == "table" and t.Url, "table-shape request expected")
    local f = io.open(TMP, "w")
    f:write(t.Body or "")
    f:close()
    local hdrs = ""
    for k, v in pairs(t.Headers or {}) do
        hdrs = hdrs .. " -H '" .. tostring(k) .. ": " .. tostring(v) .. "'"
    end
    local cmd = string.format(
        "curl -sS -m 40 -w '\\n__CODE__%%{http_code}' -X %s%s --data-binary @%s '%s'",
        t.Method or "GET", hdrs, TMP, t.Url)
    local raw = runCmd(cmd)
    local code = tonumber(raw:match("__CODE__(%d+)%s*$")) or 0
    local body = raw:gsub("__CODE__%d+%s*$", "")
    return { StatusCode = code, Body = body }
end

-- minimal Roblox/executor stubs for headless run ---------------------------
_G.getgenv = function() return _G end
-- tiny Roblox-global shim (the probe replaces NS.UI right after load anyway)
_G.Color3 = { fromRGB = function() return {} end }
_G.Vector2 = { new = function(x, y) return { X = x, Y = y } end }
_G.Vector3 = _G.Vector2
_G.UDim = { new = function() return {} end }
local _udim2 = {
    new = function() return { X = { Scale = 0, Offset = 0 }, Y = { Scale = 0, Offset = 0 } } end,
}
_udim2.fromOffset = function() return { X = { Scale = 0, Offset = 0 }, Y = { Scale = 0, Offset = 0 } } end
_udim2.fromScale = _udim2.new
_G.UDim2 = _udim2
_G.TweenInfo = { new = function() return {} end }
_G.typeof = type
_G.Enum = setmetatable({}, { __index = function()
    return setmetatable({}, { __index = function() return {} end })
end })
local _meta = { __index = function() return nil end, __newindex = function() end }
_G.Instance = { new = function() return setmetatable({ GetChildren = function() return {} end, IsA = function() return false end }, _meta) end }
_G.game = setmetatable({ GetService = function() return nil end, GetChildren = function() return {} end,
                        PlaceId = 1, JobId = "", GameName = "it" }, _meta)
_G.workspace = setmetatable({ CurrentCamera = { ViewportSize = _G.Vector2.new(1024, 768) } }, _meta)
_G.isfile = function(p) local f = io.open("./itfs/" .. p, "r"); if f then f:close() return true end return false end
_G.isfolder = function(p) return runCmd("test -d './itfs/" .. p .. "' && echo y") == "y\n" end
_G.isfolder = function(p) return runCmd("test -d './itfs/" .. p .. "' && echo y") == "y\n" end
_G.makefolder = function(p) os.execute("mkdir -p './itfs/" .. p .. "'") end
_G.writefile = function(p, c)
    local dir = p:match("^(.*)/[^/]*$")
    if dir and dir ~= "" then os.execute("mkdir -p './itfs/" .. dir .. "'") end
    local f = assert(io.open("./itfs/" .. p, "w")); f:write(c); f:close()
end
_G.readfile = function(p)
    local f = io.open("./itfs/" .. p, "r"); if not f then return nil end
    local s = f:read("*a"); f:close(); return s
end
_G.delfile = function(p) os.remove("./itfs/" .. p) end
MaxNS = { __NoAutoStart = true, __TestMode = true }
dofile(os.getenv("MAX_CLIENT_BUNDLE") or "client/dist/Max.lua")
local NS = MaxNS
NS.Spawn = function(f, ...) local ok, e = pcall(f, ...) if not ok then error(e, 0) end end
NS.Wait = function() end
-- stub GUI + inspect (this test targets the network path)
NS.UI = { Build = function() end, AttachHooks = function() end, BindKeys = function() end,
          Toast = function() end, SetStatus = function() end, SetDiag = function() end }
NS.Inspect = { Build = function() end, Ensure = function() end, State = {} }
NS.Storage.Diary = function() end

NS.Storage.Init("Max")
NS.Settings.Init()
NS.Settings.Set("apiBase", "http://127.0.0.1:" .. port)
NS.Settings.Set("apiKey", key)

local function check(name, cond)
    print((cond and "PASS " or "FAIL ") .. name)
    if not cond then os.exit(1) end
end

check("transport selected", NS.HTTP.Probe("http://127.0.0.1:" .. port) == true)
local healthy = NS.API.Health()
check("backend health via full client stack", healthy == true)

-- Heavy dev ask: under Automatic the backend must CLASSIFY this to auto:smart (the mock
-- 429s smart once, so this also exercises the health failover into auto:balanced).
local data = NS.API.Chat({ messages = { { role = "user", content = "```lua\nlocal x = 1\n```\nintegration: fix and debug this broken script" } } })
check("chat completion through backend", data ~= nil and data.choices and data.choices[1].message.content ~= nil)
check("diag metadata (model/provider) surfaced to client", data and data.max ~= nil and data.max.routed_via ~= nil)
check("client recorded diag", NS.API.Diag ~= nil)

-- second chat should still work (backend route health state moved on)
local d2 = NS.API.Chat({ messages = { { role = "user", content = "ping 2" } }, model = "auto:fast" })
check("second request ok", d2 ~= nil and d2.choices ~= nil)

-- stats endpoint parse
local stats = NS.API.Stats()
check("stats parsed", type(stats) == "table" and stats.routing ~= nil)

print("INTEGRATION OK")
