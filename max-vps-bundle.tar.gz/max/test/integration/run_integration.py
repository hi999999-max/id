#!/usr/bin/env python3
"""End-to-end integration: mock FreeLLMAPI + real Max backend + real Max
client bundle driven by Lua with a curl transport. From the repo root:

    python3 test/integration/run_integration.py
"""
import json
import os
import subprocess
import sys
import threading
import unittest  # noqa: F401  (keeps parity with backend test infra)

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "backend"))

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer  # noqa: E402
import max_backend as mb  # noqa: E402

CATALOG = [
    {"id": "llama-3.3-70b-instruct", "execution_status": "ready"},
    {"id": "deepseek-r1-distill", "execution_status": "ready"},
    {"id": "whisper-1", "execution_status": "exhausted"},
]


class MockFreeLLM(BaseHTTPRequestHandler):
    calls = []

    def log_message(self, *a):
        pass

    def _json(self, code, obj, headers=None):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.startswith("/v1/models"):
            self._json(200, {"object": "list", "data": [c for c in CATALOG if c["execution_status"] == "ready"]})
        else:
            self._json(404, {})

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        body = json.loads(self.rfile.read(n))
        MockFreeLLM.calls.append(body)
        if self.headers.get("Authorization") != "Bearer unified-secret":
            self._json(401, {"error": {"message": "bad unified key"}})
            return
        model = body.get("model")
        # first call of the suite: make auto:smart hot-fail once → backend must
        # fall back to auto:balanced transparently for the client
        if model == "auto:smart" and not getattr(MockFreeLLM, "failed_once", False):
            MockFreeLLM.failed_once = True
            self._json(429, {"error": {"message": "all keys rate-limited"}}, {"Retry-After": "20"})
            return
        self._json(200, {"id": "x", "object": "chat.completion", "model": model,
                         "choices": [{"index": 0, "finish_reason": "stop",
                                      "message": {"role": "assistant", "content": f"pong via {model}"}}],
                         "usage": {"total_tokens": 7}},
                 {"X-Routed-Via": f"mockprov/{model}"})


def main():
    up = ThreadingHTTPServer(("127.0.0.1", 0), MockFreeLLM)
    threading.Thread(target=up.serve_forever, daemon=True).start()
    up_port = up.server_address[1]

    cfg = mb.Config(dict(mb.DEFAULT_CONFIG))
    cfg.update({
        "listen_host": "127.0.0.1", "listen_port": 0,
        "max_keys": ["it-device-key"], "auth_required": True,
        "upstream_base": f"http://127.0.0.1:{up_port}/v1",
        "upstream_key": "unified-secret",
        "strategy_cooldown_s": 60, "models_cache_s": 60, "request_timeout_s": 15,
    })
    srv = mb.create_server(cfg)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    port = srv.server_address[1]
    print(f"mock freellmapi :1{up_port % 100000}  max backend :{port}")

    subprocess.run(["rm", "-rf", os.path.join(ROOT, "client", "itfs")], check=False)
    env = dict(os.environ, MAX_PORT=str(port), MAX_KEY="it-device-key",
               MAX_CLIENT_BUNDLE=os.path.join(ROOT, "client", "dist", "Max.lua"),
               LUA_INIT="")
    cwd = os.path.join(ROOT, "client")
    lua = os.path.expanduser("~/.tools/lua")
    if not os.path.exists(lua):
        lua = "lua5.1"
    r = subprocess.run([lua, os.path.join(HERE, "client_probe.lua")], env=env, cwd=cwd,
                       capture_output=True, text=True, timeout=120)
    print(r.stdout)
    if r.stderr.strip():
        print("stderr:", r.stderr[:800])
    lines = [l for l in r.stdout.splitlines() if l.startswith(("PASS", "FAIL"))]
    assert all(l.startswith("PASS") for l in lines), "client probe failures"
    assert "INTEGRATION OK" in r.stdout and r.returncode == 0, f"probe exit {r.returncode}"

    models_called = [c.get("model") for c in MockFreeLLM.calls]
    assert models_called[0] == "auto:smart", models_called
    assert any(m == "auto:balanced" for m in models_called), f"fallback did not happen: {models_called}"
    print("backend-side assertions OK · upstream saw:", models_called)

    # unified key must never have leaked anywhere client-facing
    leaks = subprocess.run(["grep", "-rIl", "unified-secret", os.path.join(cwd, "itfs")],
                           capture_output=True, text=True)
    assert leaks.stdout.strip() == "", f"upstream key leaked into client storage:\n{leaks.stdout}"
    print("no upstream-key leak in client storage ✓")

    srv._shutdown = True
    srv.shutdown()
    up.shutdown()
    print("\nINTEGRATION PASS")


if __name__ == "__main__":
    main()
