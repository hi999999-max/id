# Max — Roblox Executor AI Assistant

Max is an AI assistant that lives **inside Roblox executors** (not a Studio
plugin), backed by your own VPS. It has a responsive mobile/PC GUI, a fixed
name (always "Max"), fully **automatic model selection** over your existing
FreeLLMAPI install, **genuine persistent memory** in executor files, and a
read-only **inspection layer** for whatever Roblox DataModel the client can
already see — accessed through structured tool-calling, not vibes.

```
Executor on device (phone/PC)                      Your VPS
┌───────────────────────────────┐      HTTPS    ┌────────────────────────────┐
│  Max.lua  (this repo's client)│ ────────────► │ nginx/caddy  (TLS, /max)   │
│  ├─ GUI (mobile + desktop)    │   Bearer      │   └─► max-backend :3002    │
│  ├─ HTTP transport adapter    │   max-key     │        ├ auth, rate limit, │
│  ├─ Persistent memory (files) │               │        │  validation, diag │
│  ├─ Environment inspector     │               │        └─► FreeLLMAPI :3001 │
│  └─ Tool-call engine          │               │             (Docker, auto:  │
└───────────────────────────────┘               │              routing +      │
      never holds any AI keys                   │              key failover)  │
                                                └────────────────────────────┘
```

Everything here is **additive**: no rebuilds, no edits to FreeLLMAPI, the
Discord bot, or `roblox_update_monitor.py`. Max is its own project
(`max-backend.service` on `127.0.0.1:3002`) with its own keyring.

---

## 0. Infrastructure assessment (read this first)

**What I could verify from here:** I cannot reach your VPS from this
environment, so instead of guessing I built the audit into the project. Run:

```bash
sudo bash deploy/vps_inspect.sh | tee /root/max-infra-report.txt
```

It is read-only and secret-masked. It checks Docker + the FreeLLMAPI
container's port/env shape, loopback reachability of `127.0.0.1:3001/v1`,
`/v1/models` counts per `execution_status` (with `FREELLMAPI_KEY` set), the
`/root/freellmapi-project.tar.gz` archive, `roblox_update_monitor.py`, any
Discord-bot systemd units/crontabs, nginx/caddy/cloudflared/tailscale/certbot
availability, python version, open ports, and the firewall. Paste me the
report and I'll pin the deploy specifics (TLS choice, conflicts, etc.).

**What I verified about FreeLLMAPI itself** (from its current upstream docs,
[tashfeenahmed/freellmapi](https://github.com/tashfeenahmed/freellmapi)):

* OpenAI-compatible `POST /v1/chat/completions` on `http://127.0.0.1:3001/v1`,
  auth = unified Bearer key from the Keys page.
* Built-in router: `model: "auto"`, `auto:smart`, `auto:fast`,
  `auto:balanced`, `auto:reliable`, named profiles — ranks every enabled
  model per request with automatic failover across providers/keys.
* `GET /v1/models?execution_status=ready` — each model row carries a live
  `ready | needsKey | exhausted` status (the answer to "is a request actually
  possible *now*", not just "is it listed").
* Full OpenAI multi-step **tool calling** is proxied across providers.
* Every response carries `X-Routed-Via: <platform>/<model>`, plus
  `X-Fallback-Attempts` / `X-Fallback-Trail` when it fell over.

**Design conclusion:** Max does *not* re-implement a model router. It uses
FreeLLMAPI's `auto:*` strategies as the primary path (its per-key quota
tracking and cross-provider failover are strictly better information than any
client-side guessing), and adds the one layer FreeLLMAPI can't provide you:
an **executor-safe boundary** — separate revocable per-device keys, rate
limiting, request/tool validation, per-strategy backoff when the *whole
gateway* says "exhausted", pinned-model rescue from the live catalog, and
diagnostics the GUI can display.

---

## 1. Project layout

```
max/
├── README.md
├── backend/
│   ├── max_backend.py          # VPS gateway: Python stdlib only, no pip installs
│   ├── config.example.json     # annotated example config (real one lives in /etc/max)
│   └── test_backend.py         # 20 unit tests vs a mock FreeLLMAPI
├── client/
│   ├── src/*.lua               # 12 Luau modules (Lua 5.1 syntax = runs everywhere)
│   ├── build.py                # concatenates → dist/Max.lua (+ luac syntax gate)
│   ├── dist/Max.lua            # THE file you run in the executor (~130 KB, no secrets)
│   ├── loader.lua              # one-liner bootstrap that fetches dist/Max.lua over HTTPS
│   └── test/run_tests.lua      # 101 headless tests (mocked Roblox + executor + fs)
├── deploy/
│   ├── vps_inspect.sh          # read-only infra audit (run first)
│   ├── setup_max.sh            # installer: systemd + nginx/certbot + key minting
│   ├── max-backend.service     # systemd unit
│   ├── nginx-max.conf.template # TLS + /max proxy + /maxscript static (own snippet)
│   └── Caddyfile.max.snippet   # Caddy alternative
└── test/integration/           # real client ↔ real backend ↔ mock FreeLLMAPI over sockets
```

## 2. Install (VPS)

### 2a. Bare IP, no domain, one command (what you want)

From the unpacked bundle, as root on the VPS:

```bash
sudo bash deploy/setup_max.sh
```

It auto-detects your public IP (`curl -4 ifconfig.me`), binds
`max-backend` to `0.0.0.0:3002`, makes the same service serve the client
scripts (`/maxscript/Max.lua`, `/maxscript/loader.lua`), opens `ufw` (if
active), live-tests `http://IP:3002/healthz`, and prints your device key.
Your executor config is then just `http://77.68.33.65:3002` — no TLS, no
domain, no nginx. Trade-off: plain HTTP, so the per-device Max key travels in
clear text (that's exactly why keys are per-device and revocable; mint new
ones with `setup_max.sh key <label>`). If a strict executor refuses plain
`http://` fetches, paste `Max.lua` directly instead of the loader, or use
free DuckDNS + certbot later for real HTTPS (see `--domain` mode below).

> **Fasthosts note:** the CloudNX control panel has a separate *cloud
> firewall* outside the OS. Open inbound **TCP 3002** (HTTP) there, or
> nothing reaches the box even though `ufw` is fine.

### 2b. Full setup (domain + TLS) — recommended whenever you want it

```bash
# 1) audit (no changes)
sudo bash deploy/vps_inspect.sh | tee /root/max-infra-report.txt

# 2) build the client bundle (needs only python3; luac check optional)
cd client && python3 build.py && cd ..

# 3) install backend + TLS + serve the script
sudo bash deploy/setup_max.sh install --domain max.example.com --email you@x.com --upstream-key <FREEELLMAPI-UNIFIED-KEY>
```

`setup_max.sh` writes `/etc/max/config.json` (0600) containing the unified
FreeLLMAPI key + a list of `max_keys`, installs `max-backend.service`
(python3, no venv, no pip), drops one nginx `conf.d` snippet
(`/max/ → 127.0.0.1:3002`, `/maxscript/ → /var/www/max`) and starts Max.
It refuses to overwrite an existing config and never touches Docker.
No domain yet? Options printed by the script: quick `cloudflared tunnel
--url http://127.0.0.1:3002` for testing, or the Caddy snippet.

Per-device keys (revocable, rotatable without touching FreeLLMAPI):

```bash
sudo bash deploy/setup_max.sh key android-tablet   # prints a new `mx_…` key
# revoke = remove it from max_keys in /etc/max/config.json && systemctl restart max-backend
```

## 3. Install (device / executor)

Preferred — self-updating loader, zero secrets in pasted code:

```lua
loadstring(game:HttpGet("https://max.example.com/maxscript/loader.lua"))()
```

Or paste/run `client/dist/Max.lua` directly. First run: open **☰ →
SETTINGS**, paste `https://max.example.com/max` as Backend URL and your
`mx_…` key. Everything else is automatic. (Headless/console users:
`Max.Say("what parts are anchored near me?")`.)

## 4. Supported executor functions (feature-detected, never assumed)

| Category | Functions | Fallback behavior |
|---|---|---|
| HTTP | `http_request`, `request`, `syn.request`, `http.request`, `fluxus.request`, `krnl.request` + runtime discovery of other `request`-shaped fields (also `getgenv().MaxExtraHttp = {fn,...}` for exotic ones) | Each candidate × each call shape (`{Url,Method,Headers,Body}` / lowercase / positional) is probed against `/healthz`; first survivor wins and is normalized. After 3 transport-level fails the winner is demoted and the next probe re-selects. Bounded retries (3/send, backoff), never an infinite loop. |
| Environment | `getgenv` (→ `_G`), `cloneref` (→ direct `game:GetService`), `identifyexecutor`/`getexecutorname` (→ "unknown executor") | |
| Storage | `writefile`, `readfile`, `appendfile`, `isfile`, `isfolder`, `makefolder`, `delfile`, `listfiles` | Missing pieces degrade: verified writes → direct; appendfile → read-modify-write; no file API at all → session-memory mode with a warning (Max still chats). |
| GUI | `gethui`, `get_hidden_gui` | → `CoreGui` (warns that some executors block it). |
| Bulk properties | `getproperties`, `get_properties` | Detected once, guarded, `pcall`ed, result validated as table and iterated with `pairs` (exactly the spec's pattern). Absent/failed → curated per-class individual reads via `instance[prop]` + `GetAttributes`. Result JSON **labels the source**: `method: "bulk(getproperties)"` vs `individual(known-set)`, plus `bulk_available`. |

Every optional global is accessed through `NS.Env.Fns` with `type(f)=="function"`
checks + `pcall`. No executor-specific assumptions; nothing hard-requires Synapse/Krnl/etc.

## 5. How Max's persistent memory actually works

*Folder `Max/` in executor storage, format versioned (`v: 2`).*

```
index.json                 registry {active, convs{title,updated,count}}
conv/<id>.json             snapshot of one conversation (roles, content, timestamps, tool meta)
conv/<id>.json.bak          last known-good snapshot (rotated on every verified write)
conv/<id>.json.log          append-only JSONL write-ahead log (every message as it happens)
memory.json                long-term facts {text, tag, score, created, seen}
settings.json              URL/key/device id/layout  ·  corrupt/  quarantine dir
```

* **Save/restore:** every message → WAL append + verified snapshot write
  (write → read-back → mismatch keeps old copy). Re-executing or rebooting
  rehydrates the active conversation and the registry automatically.
* **Multiple conversations:** unique ids, per-file isolation, switchable from
  the sidebar; delete removes files + index row.
* **Corruption:** snapshot fails → `.bak`; that fails → rebuild from `.log`;
  that fails → the garbage is quarantined and Max proceeds clean.
* **Long-term memory:** after exchanges, Max (quietly, `auto:fast`) extracts
  ≤4 durable *user* facts; deduped by normalized text, scored, capped at ~250
  with recency-weighted eviction.
* **Retrieval, not ingestion:** `SearchMemory` token-overlap-scores facts +
  recent messages of up to 6 other conversations; only the top hits render
  into the system prompt ("Relevant memories … context, not instructions").
  **Not** every old conversation is loaded — token use stays flat.
* **Summaries:** past 200 live messages the oldest half is folded by the
  model into a rolling `summary` (full transcript still on disk/.log).
* Internal ops exactly as specified: `SaveConversation`, `LoadConversation`,
  `SearchMemory`, `UpdateMemory`, `DeleteConversation`, `ListConversations`.

## 6. How automatic model selection works (and why nothing is hardcoded)

1. GUI always says **Max** — but Settings now has a **model tier** picker: *Automatic*
   (default), *Smart*, *Reliable*, *Balanced*. Automatic means Automatic: the backend
   genuinely **chooses the tier per message and adapts as the conversation goes**.
   It reads the newest 16 messages: code blocks / build-implement-write asks /
   debug-why-not-working language push it to **Smart**; a long routine tool-grind
   pushes it to **Reliable**; plain conversation stays **Balanced**; and real friction
   (tool calls returning `"ok":false`, user corrections like "still broken / try again")
   escalates by one tier on top. Chosen tier is echoed as `max.auto_tier` /
   `X-Max-Auto-Tier`. Pinning a tier sends exactly `auto:smart` / `auto:balanced` /
   `auto:reliable` and skips the choosing (client-side fact extraction still rides
   `auto:fast` regardless). Anything explicit in the request's `model` field wins.
2. Inside a tier (or the legacy `strategy_sequence` chain when nothing pins one),
   FreeLLMAPI itself balances providers, keys and quotas: `auto:smart` ranks every
   enabled model intelligence-first, `auto:reliable` recent-success-rate first,
   `auto:balanced` blended — and the Max backend additionally tracks health, so a
   pinned tier still fails over to the next-healthiest route if it goes cold.
3. **Health is runtime truth, not `/v1/models` membership.** The backend keeps a cached
   `GET /v1/models?execution_status=ready` catalog (Max never lists what can't serve),
   excludes non-chat families by name heuristics (embed/audio/image/…), and tracks
   per-strategy outcomes: EWMA latency, fail counts, and **exponential cooldowns**
   (429 `Retry-After` respected; cap 15 min). Cooling strategies are skipped, so a
   rate-limited provider is *not* re-tried every request.
4. **Rescue mode:** if every strategy is cooling, Max pins up to 2 concrete `ready`
   models from the live catalog (reasoning/tool-capability weighted, e.g. prefer
   `…70b-instruct` over `…mini`), each carrying its own penalty if it 429s.
5. Provider rejects tool schemas with a 400 mentioning tools? Max retries that route
   **once** without tools (tool-calling degrades gracefully to plain chat).
6. Bounded: ≤ `max_attempts` routes/request (default 5, incl. the pin set); full
   failure → structured 503 with `max_trail` (which routes failed and why) — never a hang.
7. **Diagnostics (optional display):** each response embeds `max: {model, routed_via,
   route, latency_ms, fallback_attempts, fallback_trail, tools_stripped…}` (from
   FreeLLMAPI's `X-Routed-Via`/`X-Fallback-*` headers). GUI header + chat footer show
   `◇ groq/llama-3.3-70b · 842ms · route auto:smart`; sidebar "Test connection" shows
   ready-model counts from `/v1/max/stats`.
8. Optional `upstream_probe_enabled` adds tiny max_tokens=1 pings (costs quota; off by
   default because FreeLLMAPI already probes lazily and reports it via `execution_status`).

## 7. Environment intelligence (read-only, hybrid retrieval)

Tiered, never a full-dump:
1. **Index** — BFS from `game`'s services: `{path,name,class,depth}`, capped (4000
   entries, 250 children/node, depth 6/9-workspace), built in frame-budgeted chunks,
   TTL 60s, rebuild-safe.
2. **Search** the index (name/path substring, class, service filters, exact-name-first
   ranking, paginated).
3. **Detail on demand** via tool calls.

Tools (names must match backend `TOOL_REGISTRY`; args shape-validated on the server,
re-validated client-side, ≤50 results/call, ≤9 KB JSON/call, per-message budget =
`maxToolRounds` (default 20; old devices that saved the previous default of 8 are
migrated up once) → then a final no-tools call forces a wrap-up answer.
`execute_code` has its OWN per-message budget, user-editable in the app: Settings tab
stepper (also `execMaxAttempts` in `Max/settings.json`), default 8, range 1-32. The client
sends the number with each chat request and the backend enforces the same figure, clamped
1-32; the server config `exec_max_attempts` is only the fallback default for callers that
don't send the key. Both ends refuse over-budget attempts, whitespace-identical re-runs and
repeated-identical-error loops (with guidance toward validate_property/search_api), and the
backend strips the tool from the advertised set once the turn's budget is spent (meta flag
`exec_capped`). Read-only lookups — reference/knowledge (`search_api`, `validate_property`,
`recall_knowledge`, `update_task`) and filesystem INSPECTION (`file_exists`, `is_folder`,
`get_folder`, `get_files_in_folder`, `read_file`, `get_file_info`, `search_files`) — are
exempt from the general budget; filesystem mutations (write/append/delete/copy/move/create)
count like normal tools:

`search_instances · get_instance_info · get_children · get_descendants · get_properties ·
get_attributes · get_full_name · get_class_name · search_by_property · search_by_class ·
get_service_info · execute_code · inspect_globals · watch_remotes · search_api · validate_property ·
recall_knowledge · save_knowledge · invalidate_knowledge · update_task ·
is_folder · get_folder · get_files_in_folder · create_folder · file_exists · read_file ·
write_file · append_file · delete_file · get_file_info · search_files · copy_file · move_file`

### Filesystem tools (Roblox project development)

33 registry entries total; the 13 `fs` tools operate on the **executor's workspace
folder** (where `readfile`/`writefile` live) so Max can hold entire multi-file Roblox
projects: list → read → plan → write → re-read to verify → execute only what must run.

* **Probe, never assume.** The adapter resolves every global (`readfile, writefile,
  appendfile, listfiles, isfile, isfolder, makefolder, delfile, delfolder`, plus
  `copyfile/movefile` where present) through the same env chain as the rest of Max,
  across common alias names, ONCE, and caches the result. Missing capability → the tool
  returns a plain `"not available on this executor (found: …)"` error — Max then tells
  the user instead of pretending, and never invents replacement APIs. `write_file`'s
  result states how it was verified (`byte-identical` readback, or honestly
  `unverified (no readfile)`).
* **Sandbox rules the code enforces (not just the prompt):** workspace-relative paths
  only — absolute paths and `..` traversal are refused; `Max/` (settings/conversations,
  can contain the API key) and credential-looking files (`*.env`, `api_key`, `secret`,
  `password`, `oauth`, `*.pem`) are protected from read, list, copy and search.
* **No silent destruction:** `write_file` refuses an existing file unless
  `overwrite:true`, and the prompt requires the user's explicit go-ahead first;
  `delete_file` changes nothing without `confirm:true` (folders can't be deleted at
  all); `move_file` verifies the destination byte-for-byte BEFORE removing the
  source, so a failed move never loses data; `append_file` falls back to read+rewrite
  and refuses past 200 KB instead of risking truncation.
* **Context discipline:** `read_file` defaults to ~8 KB / 200 lines with `offset_line`
  paging and reports exact total bytes; `search_files` (name globs + content grep) is
  the intended way to sweep a whole project — reads capped at 64 KB/file, 60 files.
  Tool results go through the usual ≤9 KB JSON cap.
* Backend validates their declared schemas like every other tool (`max_tools` grew to
  44 and is auto-clamped ≥ registry+6 so an old config can never reject the client).

`search_api`/`validate_property` answer questions about the **Roblox API itself** (not the
game) from a slim offline dump (`/maxscript/api.json`, installed by setup_max.sh, cached to
`Max/apidump.json` on device): class cards include properties (datatype, readonly/writable +
security, default, deprecated/local notes), method signatures and events, **recursively
resolved through the inheritance chain** with `[SourceClass]` tags; enum names return their
valid item lists (values can never be invented); misspelled classes/properties come back as
`didYouMean` suggestions; and a class the dump does not cover is reported *undetermined*,
never *absent*. The cache is version-stamped, refreshed at most once per 7 days, backs off a
day after a failed refresh while KEEPING the stale copy usable (offline-safe), and an unknown
future dump format is refused rather than adopted. These tools are exempt from the
per-message tool budget — the model consults them freely instead of guessing.
**Verified knowledge** (`Max/knowledge.json`, separate from conversation memory): after a
successful tool-backed turn MAX auto-captures a problem→solution note, and the model can
`save_knowledge` / `recall_knowledge` / `invalidate_knowledge` explicitly. A `verified`
status is granted only when the saving conversation actually contains a successful tool
result (everything else is downgraded to an `unverified` lead); recall results always carry
their status, and matching entries are injected into the system prompt tagged so the model
re-validates before relying on them.

The twelve inspection tools are strictly **read**: property/attribute reads only.
`inspect_globals` reads (never invokes) the client's global environment — default mode='executor'
filters the standard Lua/Roblox globals away so only what the executor injects remains, typed
with `typeof`; tables shallow-serialized. `watch_remotes` passively logs remote traffic
through one `__namecall` hook (transparent pass-through, capped buffer, explicitly stopped).
`execute_code` runs arbitrary Luau the model writes in the user's own client (the user asked
for this; it is gated by a Settings toggle), capturing print/warn/errors/return, time-boxed
via a `debug.sethook` count-hook with a static-guard fallback. Max never writes to the
DataModel on its own initiative, and cannot and does not try to fetch server-only state or
bypass protections. Values are stringified (`Vector3`→string, Instance→`<Instance Name : Class>`,
tables→`#table(n)`); unreadable properties are reported as such rather than guessed. The
system prompt explicitly forbids inventing instance data — answers must cite tool results.

## 7.9 Dev sandbox, web research & decompilation (R16)

One more VPS command turns Max into a full development assistant:

    bash ~/max/deploy/terminal/setup_maxterm.sh

**Architecture.** Tool calls flow `client → backend (/v1/max/terminal) → maxterm daemon (127.0.0.1:3009, container)`. The daemon (`terminal/maxterm.py`, stdlib-only) is the enforcement point — the prompts only advise:

* **Jail** — every path argument is resolved and must stay under `/workspace`; `..`, absolute paths and symlink escapes are refused by the storage layer.
* **Quota** — 300 MB, enforced twice: the workspace is its own ext4 image (the filesystem physically cannot hold more) and the daemon re-computes recursive usage before every write/install/exec and locks the sandbox when over. It never auto-deletes; over-quota errors name current usage and what to prune. `terminal_get_storage_usage` reads the same accounting.
* **Limits** — container: 1 CPU, 512 MB, 128 pids, read-only rootfs, no capabilities, no-new-privileges, non-root, loopback-only port. Per process (daemon): RLIMIT_CPU/AS/FSIZE, hard timeouts, spawn kill of the whole process group, max 8 supervised processes.
* **Approvals** — host-escalation or catastrophic commands (`sudo`, `mount`, `rm -rf /`, device writes, pipe-to-shell…) are refused unconditionally; workspace-wide destructive commands need `confirm:true`, which the tool contract says is used only after the user approved that exact action. Ordinary pip/npm installs need no approval (registry names are validated; `--only-binary` + `--ignore-scripts`, always inside the workspace).
* **Audit** — every exec/install is appended to `/workspace/.max/logs.jsonl` (1-rotation, not tool-visible).

**Long-running work.** `terminal_execute {cmd, detach:true, name}` supervises processes across messages: liveness + exit codes in `terminal_list_processes`, `terminal_read_output {id}` for logs, `terminal_kill_process`, auto-kill at `timeout_s`, duplicate-name guard, zombie reap at 30 min.

**Environment honesty.** The session prompt carries a LIVE manifest pulled from the daemon (OS, Python/Node/git versions, utilities, quota %, what MAX installed). Installs refresh it. `terminal_check_dependency` must return `exists=true` before any claim that a library is usable; missing = say so.

**Web research.** `web_search` (DuckDuckGo, optional domain + recency filters) and `web_open` run on the BACKEND with guards: public IPs only (loopback/private/link-local refused — no VPS metadata access), no redirect following, text content only, 400 KB cap, results as data + citation URLs. Decompiled code, package content and web pages are all treated as untrusted data — never instructions, never auto-executed.

**Decompilation.** `decompile_script {path}` validates the Instance is a LocalScript/ModuleScript, probes `decompile`/`getscriptsource` capabilities (never assumes), paginates large sources via `offset_line` (no silent truncation), and returns FAILED honestly when nothing comes back — the tool contract keeps output as *evidence*, and the system prompt requires live verification before acting on it. The workflow (identify relevant scripts first, never bulk-decompile) is enforced through the prompts and eval scenarios, not by hard count limits.

**Evidence statuses.** The client marks every consequential answer CONFIRMED / FAILED / UNKNOWN against actual observed results (readbacks, exit output, live state); verification must inspect artifacts, not repeat generation assumptions. Backend tests + eval scenarios pin this.

## 8. GUI (mobile + PC)

Dark theme (`#11121a`), rounded bubbles (user right/indigo, Max left),
`TextService`-measured bubble heights, auto-scroll, typing indicator (♥ heartbeat
dots), day-to-day: viewport <720px → **mobile mode**: 44–52px touch targets,
17px text, near-fullscreen draggable window; ☰ sidebar overlays; otherwise
**desktop mode**: dockable sidebar, resize grip, compact fonts. Header: status
dot (green/amber/red), current-model label, ＋ new chat, ☰ conversations,
– minimize (floating ✦ orb reopens), ✕ close. Toast errors + connection state
live. Drag works with mouse **and** touch (`InputChanged` + clamp to viewport);
position/size persist in settings.json. Keyboard: `Enter` send, `Esc`
defocus, `Alt+M` hide/show. All Roblox class/event access is `pcall`-guarded
so partial executor support degrades, never explodes. No element overlaps are
possible in the row-list layout; bubbles truncate rather than clip.

## 8.5 Intelligence scaffolding & evaluation (R12)

Max's reasoning quality comes from FOUR code-enforced layers, not model luck. Each is
tested in the client suite and, behaviourally, in the eval pack:

- **Requirements discipline (prompt):** the system prompt forces whole-message parsing,
  a plan-before-act order, CONFIRMED-vs-GUESSED language, "user report = evidence,
  your past work = suspect" for corrections, and a prohibition on claiming
  fixed-without-reproduction. Generated != executed != verified is an explicit rule.
- **`update_task` — persistent checklist:** on multi-step asks Max records one line per
  user requirement (including "do NOT" items) into the CONVERSATION RECORD
  (`Max/conv-*.json` → `task = {obj, items}`), re-injected into every following system
  prompt. It survives budget exhaustion, history folding and re-execution, and costs no
  tool budget. Releasing an answer with open `[ ]` lines is treated as unfinished.
- **AUTO-CONTINUE:** when a turn dies mid-task at the round cap, the client silently
  grants up to `autoContinue` (Settings row, 0-3, default 2) extra segments with fresh
  budgets, ordering "resume at the open checklist lines, never redo verified steps".
  The user saying "continue" five times was a design bug, and it is now the fallback,
  not the mechanism.
- **Learning consent:** Settings → "Learning from chats" gates BOTH the end-of-chat
  user-fact extraction and automatic knowledge capture. Off = nothing is learned
  automatically (explicit `save_knowledge` still works — that is the user asking).

**Eval harness** — `test/eval/run_eval.py` (stdlib only): 24 scenarios across
instruction-following, correction handling, API accuracy, state investigation, honesty,
tool selection, continuation, contradictions and adversarial traps; 9 are HOLD-OUT and
excluded unless `--all`. `--mock` self-tests the scorer (must separate disciplined
behaviour from sloppy or the harness is worthless — currently 100% vs 29%).
`--live --base http://77.68.33.65:3002 --key KEY` scores the REAL first-turn decisions
of whatever model the router picks; use it before/after prompt or routing changes and
save `--report file.json` diffs. The live mode measures model+backend judgement on the
single-turn level; multi-round loop mechanics stay covered by the Lua test suite.

**What this deliberately does NOT do:** Max does not train or fine-tune anything — there
is no approved-dataset pipeline and no provider-side training; conversation records
never leave your VPS beyond the routed inference call. "Dataset export" is intentionally
not implemented until a reviewed-training story exists; the consent toggle above is the
current guarantee.

## 9. Security posture

* Executor devices only ever hold a **per-device revocable Max key**; the
  FreeLLMAPI unified key lives only in `/etc/max/config.json` (0600) —
  integration test asserts it never lands in client storage or responses.
* `auth_required` with constant-time compare; **refuses to start** with an
  empty keyring. Backend binds `127.0.0.1` only — nothing new is exposed;
  nginx/caddy adds TLS + `limit_req` (30 r/min, burst 40) and the backend
  enforces its own per-device bucket + global in-flight cap.
* Validation: 256 KB body cap, role allowlist, tool allowlist+arg types,
  tool payload truncation (16 KB), ≤150 messages trimmed server-side too,
  `stream`/`n` stripped, unknown fields dropped. Max's tool registry is
  fixed — neither a compromised prompt nor a jailbroken model can make the
  backend proxy arbitrary client-side functions.
* Logging is one line/request (route, status, ms, hashed device id) — no
  keys, no payloads, no conversation bodies. Conversations are *only* on the
  user's device by design.
* If a shared HTTPS endpoint is overkill, FreeLLMAPI's own revocable
  `/v1/t/{token}` path or Tailscale are viable substitutes — but then Max's
  validation layer should be kept (don't expose 3001 raw).

## 10. Testing (all runnable here)

```bash
# backend vs mock FreeLLMAPI (routing, fallback, cooldown, auth, ratelimit, validation)
cd backend && python3 -m unittest test_backend -v

# client headless suite (JSON, HTTP dialects, memory corruption/recovery, facts,
# inspection w/ mock instance tree, getproperties bulk-vs-individual, tools,
# chat engine tool-loop, summaries, GUI logic) — 101 asserts
cd client && python3 build.py && ~/.tools/lua test/run_tests.lua

# real client ↔ real backend ↔ mock FreeLLMAPI over sockets (curl transport)
python3 test/integration/run_integration.py
```

Covered from the spec's test list: HTTP compat (all three shapes + runtime
discovery + fail/demote/recover), FreeLLMAPI connectivity, auto selection,
fallback after 429 + cooldown skip + rescue pinning, tool calling
round-trips + server validation rejections, instance search/detail,
`getproperties` present/absent, memory save/restore across "re-exec",
multiple conversations, corrupted-file recovery (bak/log/quarantine),
large-index caps + pagination, connection failure structuring + bounded
retries, rate limit + oversized body handling.

**Honest gaps (need your hardware):** true pixel rendering of the GUI on a
real device (logic/layout math is unit-tested headless), live anti-cheat
behavior of loading any script (outside Max's control), and your VPS's actual
state (run the inspect script). Also — inherently — executors exist in a
ToS-gray area; Max stays read-only/observational by construction, which is
also the design line this project won't cross.

## 11. Troubleshooting

| Symptom | Fix |
|---|---|
| GUI says offline, backend logs `transport probe failed` | Backend URL wrong / TLS cert invalid on your executor's HTTP stack / nginx snippet missing trailing-slash mapping (`/max/ → :3002/`). `curl https://…/max/healthz` must return `{"ok":true…}`. |
| `401 invalid Max API key` | Paste the `mx_…` key from `/etc/max/first-key.txt` (or `setup_max.sh key …`), not the FreeLLMAPI key. |
| `502 upstream unreachable` | FreeLLMAPI container down / wrong `upstream_base` / unified key missing (backend warns at boot). |
| `429` immediately | You hit the per-device bucket; wait, or raise `rate_limit_rpm`. |
| "all routes failed" | FreeLLMAPI reports every key exhausted — check its dashboard; Max will retry later (cooldowns visible in `/v1/max/stats`). |
| Memory not persisting | Executor lacks `writefile` (diagnostics line shows `storage: memory`); switch executors or accept session-only memory. |
| GUI invisible | `gethui`/`get_hidden_gui` unavailable and CoreGui blocked — check `[Max]` console warnings. |

*Max v1.0.0 — client bundle 12 modules / 3.2k lines; backend ~650 lines stdlib-only.*
