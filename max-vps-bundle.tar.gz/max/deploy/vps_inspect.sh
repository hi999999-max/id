#!/usr/bin/env bash
# vps_inspect.sh — READ-ONLY infrastructure audit for Max.
#
# Run this ON THE VPS (as root) BEFORE installing Max, then share the
# generated report so the Max config can be matched to reality:
#
#     sudo bash vps_inspect.sh | tee /root/max-infra-report.txt
#
# It never writes, restarts, or reconfigures anything. Secret VALUES are
# masked (names only). Safe to re-run.

set -u
mask() { sed -E 's/((KEY|TOKEN|SECRET|PASSWORD|PASS)[A-Z_]*=).*/\1***MASKED***/Ig'; }
sec() { echo; echo "==================== $1 ===================="; }

echo "Max infrastructure inspection — $(date -Is)  (read-only)"

sec "SYSTEM"
uname -a
cat /etc/os-release 2>/dev/null | head -3
uptime
free -h | head -2
df -h / | tail -1

sec "LISTENING PORTS"
ss -ltnp 2>/dev/null || netstat -ltnp 2>/dev/null

sec "DOCKER"
if command -v docker >/dev/null 2>&1; then
  docker ps -a --format '{{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}' 2>/dev/null
  echo "--- FreeLLMAPI container details (env VALUES masked) ---"
  FL=$(docker ps --format '{{.Names}}' 2>/dev/null | grep -i -m1 'freellm' || true)
  if [ -n "${FL:-}" ]; then
    echo "container: $FL"
    docker inspect "$FL" --format 'image={{.Config.Image}} restart={{.HostConfig.RestartPolicy.Name}}' 2>/dev/null
    docker inspect "$FL" --format '{{range $k, $v := .NetworkSettings.Ports}}{{println $k $v}}{{end}}' 2>/dev/null | head -10
    docker inspect "$FL" --format '{{range .Config.Env}}{{println .}}{{end}}' 2>/dev/null | mask
    docker inspect "$FL" --format '{{range .Mounts}}{{println .Type .Source "->" .Destination}}{{end}}' 2>/dev/null
  else
    echo "no container matching 'freellm' found — check names above"
  fi
else
  echo "docker not installed"
fi

sec "FREELLMAPI ENDPOINT (loopback)"
BASE="${FREELLMAPI_BASE:-http://127.0.0.1:3001}"
code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 "$BASE/" 2>/dev/null || echo "000")
echo "GET $BASE/ -> HTTP $code"
if [ -n "${FREELLMAPI_KEY:-}" ]; then
  echo "-- /v1/models (counts by execution_status) --"
  curl -s --max-time 10 -H "Authorization: Bearer $FREELLMAPI_KEY" "$BASE/v1/models" \
    | python3 -c 'import json,sys
d=json.load(sys.stdin).get("data",[])
from collections import Counter
print("total models:", len(d))
print(Counter(m.get("execution_status","?") for m in d))
print("sample ids:", ", ".join(m.get("id","?") for m in d[:8]))' 2>/dev/null || echo "(could not parse /v1/models)"
  echo "-- auto route smoke test (tiny completion) --"
  curl -s --max-time 60 -H "Authorization: Bearer $FREELLMAPI_KEY" -H 'Content-Type: application/json' \
    -d '{"model":"auto","messages":[{"role":"user","content":"ping"}],"max_tokens":4}' \
    "$BASE/v1/chat/completions" | head -c 400; echo
else
  echo "set FREELLMAPI_KEY=<unified key> before running to enable the live endpoint checks"
fi

sec "EXISTING ROOT PROJECTS"
for f in /root/freellmapi-project.tar.gz /root/roblox_update_monitor.py; do
  if [ -e "$f" ]; then ls -la "$f"; else echo "missing: $f"; fi
done
if [ -f /root/roblox_update_monitor.py ]; then
  echo "--- roblox_update_monitor.py (first 25 lines) ---"
  head -25 /root/roblox_update_monitor.py
fi
echo "--- /root listing ---"
ls -la /root 2>/dev/null | head -30

sec "DISCORD BOT / SERVICES"
systemctl list-units --type=service --all 2>/dev/null | grep -iE 'discord|roblox|freellm|max' || echo "(no matching systemd units)"
ls /etc/systemd/system/ 2>/dev/null | grep -iE 'discord|roblox|freellm|max' || true
crontab -l 2>/dev/null | grep -v '^\s*#' | head -10 || echo "(no root crontab)"

sec "TLS / PROXY TOOLING"
for c in nginx caddy cloudflared tailscaled certbot; do
  if command -v $c >/dev/null 2>&1; then echo "$c: $(command -v $c)"; else echo "$c: absent"; fi
done
command -v certbot >/dev/null 2>&1 && certbot certificates 2>/dev/null | grep -E 'Certificate Name|Expiry' | head -10

sec "PYTHON"
python3 --version 2>&1

sec "FIREWALL"
ufw status verbose 2>/dev/null || firewall-cmd --list-all 2>/dev/null || iptables -S 2>/dev/null | head -10 || echo "(no recognized firewall tool)"

sec "END OF REPORT"
echo "Share this report (it has no secret values) and run deploy/setup_max.sh install to proceed."
