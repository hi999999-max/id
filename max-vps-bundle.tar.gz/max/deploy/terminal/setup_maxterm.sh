#!/usr/bin/env bash
# setup_maxterm.sh — install MAX's isolated dev environment on the VPS.
#
#   bash ~/max/deploy/terminal/setup_maxterm.sh
#
# Idempotent; run as root. Creates:
#   /var/lib/maxterm.img      330 MB ext4 image, loop-mounted — the FILESYSTEM
#                             itself is a hard cap: MAX can never store more,
#                             no matter what runs inside the sandbox
#   /var/lib/maxterm          mount point = /workspace in the container
#   maxterm:latest            hardened container image (python/node/git/...)
#   maxterm.service           systemd unit (loopback :3009 only, no new
#                             privileges, cap-drop ALL, read-only rootfs,
#                             512 MB RAM, 1 CPU, 128 pids — the daemon adds
#                             per-process CPU/mem/file limits and timeouts)
#   /etc/max/term.env         shared X-Max-Term-Key (0600)
# Then wires /etc/max/config.json (terminal_base) + backend EnvironmentFile
# and restarts both services.
set -euo pipefail

REPO="$(cd "$(dirname "$0")/../.." && pwd)"
QUOTA_MB=300
IMG=/var/lib/maxterm.img
MNT=/var/lib/maxterm
ENVF=/etc/max/term.env
CONF=/etc/max/config.json
BEUNIT=/etc/systemd/system/max-backend.service
UNIT=/etc/systemd/system/maxterm.service
say() { printf '\n== %s\n' "$*"; }

[ "$(id -u)" = 0 ] || { echo "run as root (ssh root@77.68.33.65)"; exit 1; }

say "1/5 key"
mkdir -p /etc/max
if [ ! -s "$ENVF" ] || ! grep -q '^MAXTERM_KEY=' "$ENVF"; then
  KEY=$(python3 -c 'import secrets; print("mk_"+secrets.token_hex(16))')
  umask 077; printf 'MAXTERM_KEY=%s\n' "$KEY" > "$ENVF"
  echo "generated new key"
else
  echo "keeping existing key"
fi
chmod 600 "$ENVF"
KEY=$(grep '^MAXTERM_KEY=' "$ENVF" | cut -d= -f2)

say "2/5 quota-backed storage (ext4 image = the hard ceiling; self-repairing)"
IMGMB=$((QUOTA_MB + 55))   # ext4 needs headroom for its own metadata; usable lands >= QUOTA_MB
mk_ok() {
  local s
  s=$(df -BM --output=size "$MNT" 2>/dev/null | tail -1 | tr -dc '0-9')
  [ -n "$s" ] && [ "$s" -ge "$QUOTA_MB" ] && [ "$s" -le "$((QUOTA_MB + 90))" ]
}
fsmb() { df -BM --output=size "$MNT" 2>/dev/null | tail -1 | tr -dc '0-9'; }
if [ ! -f "$IMG" ]; then
  truncate -s ${IMGMB}M "$IMG"
  # no journal / no metadata_csum: predictable usable size and less overhead in a throwaway loop image
  mkfs.ext4 -q -F -m 0 -O ^has_journal,^metadata_csum "$IMG"
  echo "created ${IMGMB} MB workspace image"
fi
mkdir -p "$MNT"
if ! mountpoint -q "$MNT"; then
  mount -o loop,noatime "$IMG" "$MNT" 2>/dev/null || { echo "could not loop-mount $IMG"; exit 1; }
  echo "mounted"
fi
if ! grep -q "$IMG" /etc/fstab; then
  printf '%s %s ext4 loop,noatime 0 2\n' "$IMG" "$MNT" >> /etc/fstab
  echo "added to /etc/fstab (auto-mount on boot)"
fi
if ! mk_ok; then
  # R17 fix: earlier layouts (journal taking ~32 MB) made the mount SMALLER than
  # the quota and the script stopped. Now it repairs automatically.
  echo "usable fs is $(fsmb) MB < target — resizing the image + filesystem..."
  systemctl stop maxterm >/dev/null 2>&1 || true
  umount "$MNT" 2>/dev/null || umount -l "$MNT" 2>/dev/null || true
  SZB=$(stat -c %s "$IMG" 2>/dev/null || echo 0)
  [ "${SZB:-0}" -lt $((IMGMB * 1024 * 1024)) ] && truncate -s ${IMGMB}M "$IMG"
  e2fsck -f -y "$IMG" >/dev/null 2>&1 || true
  tune2fs -O ^has_journal,^metadata_csum "$IMG" >/dev/null 2>&1 || true
  e2fsck -f -y "$IMG" >/dev/null 2>&1 || true
  resize2fs "$IMG" >/dev/null 2>&1 || true
  mount -o loop,noatime "$IMG" "$MNT"
  mk_ok || { echo "STILL off: $(fsmb) MB usable from a ${IMGMB} MB image — send this line to support:"; df -h "$MNT"; exit 1; }
  echo "repaired — the run that failed before now self-heals"
fi
chown 1000:1000 "$MNT"
mkdir -p "$MNT/.tmp" "$MNT/.max" && chown -R 1000:1000 "$MNT/.tmp" "$MNT/.max"
echo "workspace filesystem: $(fsmb) MB usable — the hard ceiling nothing can outgrow; daemon quota ${QUOTA_MB} MB"

say "3/5 service (container if docker present, else systemd+host python)"
if command -v docker >/dev/null 2>&1; then
  docker build -q -t maxterm:latest -f "$REPO/deploy/terminal/Dockerfile" "$REPO" >/dev/null
  cat > "$UNIT" <<UNIT
[Unit]
Description=MAX dev sandbox (maxterm container)
After=network-online.target docker.service
Requires=docker.service
[Service]
ExecStartPre=-/usr/bin/docker rm -f maxterm
ExecStart=/usr/bin/docker run --rm -i --name maxterm \
  -p 127.0.0.1:3009:8080 \
  -v $MNT:/workspace \
  --env-file $ENVF \
  -e MAXTERM_QUOTA_MB=$QUOTA_MB -e MAXTERM_PORT=8080 -e MAXTERM_BIND=0.0.0.0 \
  --read-only --tmpfs /tmp:mode=1777,size=64m \
  --memory 512m --memory-swap 512m --cpus 1.0 --pids-limit 128 \
  --user 1000:1000 \
  --security-opt no-new-privileges --cap-drop ALL \
  --stop-timeout 10 \
  maxterm:latest
ExecStopPost=-/usr/bin/docker rm -f maxterm
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
UNIT
  echo "docker mode (node + full toolchain inside the container)"
else
  cat > "$UNIT" <<UNIT
[Unit]
Description=MAX dev sandbox (maxterm, host-python fallback — docker missing)
After=network-online.target
[Service]
EnvironmentFile=$ENVF
Environment=MAXTERM_ROOT=$MNT
Environment=MAXTERM_QUOTA_MB=$QUOTA_MB
Environment=MAXTERM_PORT=3009
Environment=MAXTERM_BIND=127.0.0.1
ExecStart=$(command -v python3) $REPO/terminal/maxterm.py
Restart=always
RestartSec=3
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ReadWritePaths=$MNT
ProtectHome=yes
MemoryMax=512M
CPUQuota=100%
TasksMax=128
[Install]
WantedBy=multi-user.target
UNIT
  echo "fallback mode: host python (installs still go to the workspace; node may be absent — the manifest reports the truth)"
fi
systemctl daemon-reload
systemctl enable maxterm >/dev/null 2>&1 || true
systemctl restart maxterm
sleep 2

say "4/5 backend wiring (config + key + restart)"
python3 - "$CONF" <<'PY'
import json, os, sys
p = sys.argv[1]
cfg = {}
if os.path.exists(p):
    cfg = json.load(open(p))
cfg["terminal_base"] = "http://127.0.0.1:3009"
cfg.setdefault("web_enabled", True)
if int(cfg.get("max_tools", 0)) < 72:
    cfg["max_tools"] = 72
os.makedirs(os.path.dirname(p), exist_ok=True)
tmp = p + ".t"
json.dump(cfg, open(tmp, "w"), indent=1)
os.replace(tmp, p); os.chmod(p, 0o600)
print("config.json patched (terminal_base, web_enabled, max_tools)")
PY
if [ -f "$BEUNIT" ] && ! grep -q 'EnvironmentFile=/etc/max/term.env' "$BEUNIT"; then
  if [ -w /etc/systemd/system ] && command -v systemctl >/dev/null; then
    sed -i '\|^\[Service\]|a EnvironmentFile=/etc/max/term.env' "$BEUNIT"
    systemctl daemon-reload
    echo "backend unit gets the sandbox key via EnvironmentFile"
  fi
fi
systemctl restart max-backend
sleep 1

say "5/5 verify"
ok=1
curl -sf --max-time 6 http://127.0.0.1:3009/healthz | grep -q '"ok": *true' \
  && echo "maxterm: healthy, quota-backed" || { echo "maxterm: NO ANSWER — journalctl -u maxterm -n 40"; ok=0; }
curl -sf --max-time 10 http://127.0.0.1:3002/healthz >/dev/null \
  && echo "backend: healthy" || { echo "backend: no answer on :3002 — journalctl -u max-backend -n 40"; ok=0; }
curl -sf --max-time 8 -X POST http://127.0.0.1:3009/manifest -H 'Content-Type: application/json' \
  -H "X-Max-Term-Key: $KEY" -d '{}' | grep -q '"quota_mb"' \
  && echo "manifest: quota visible (filesystem + daemon)" || { echo "manifest check failed"; ok=0; }
[ "$ok" = 1 ] && echo -e "\nDONE. MAX's terminal tools are live. Nothing else for you to do — just talk to Max." \
              || echo -e "\nSome checks failed — paste the lines above to whoever helps with the server."
exit 0
