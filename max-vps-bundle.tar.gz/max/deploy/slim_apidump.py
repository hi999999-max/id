#!/usr/bin/env python3
"""Slim Roblox Mini-API-Dump.json -> Max's api.json reference format.

Output: {version, classes: {Name: {sup, p: {prop: "Type[|flags][=default]"},
f: {method: "(a: T, b: T?) -> R"}, e: {event: true}}}} — small enough for the
Luau JSON decoder on phones, structured for O(1) property lookups by
validate_property and substring class search by search_api.
Usage: slim_apidump.py <Mini-API-Dump.json> <out.json>"""
import json, sys, time

SKIP_DEFAULT = ("__api_dump_class_not_creatable__", "__api_dump_no_string_value__")

def type_str(t):
    if not isinstance(t, dict):
        return "?"
    cat, nm = t.get("Category"), t.get("Name")
    if cat == "Enum":
        return "Enum." + (nm or "?")
    if cat == "Class" or cat == "DataType" or cat == "EnumType" or cat == "TypeDef":
        return nm or "?"
    if cat == "Generic":
        return "<T>"
    if cat == "Variadic":
        return "..." + type_str(t.get("Type") or t)
    return nm or cat or "?"

def slim(members):
    p, f, e = {}, {}, {}
    for m in members:
        kind = m.get("MemberType")
        name = m.get("Name")
        if not name:
            continue
        tags = m.get("Tags") or []
        if "Internal" in tags:
            continue
        if kind == "Property":
            t = type_str(m.get("ValueType"))
            flags = []
            if "ReadOnly" in tags:
                flags.append("readonly")
            else:
                sec = m.get("Security") or {}
                wr = sec.get("Write", "None")
                rd = sec.get("Read", "None")
                if wr != "None":
                    flags.append("w:" + str(wr))
                if rd != "None":
                    flags.append("r:" + str(rd))
            if "NotReplicated" in tags:
                flags.append("local")
            if "Deprecated" in tags:
                flags.append("deprecated")
            s = t
            if flags:
                s += "|" + ",".join(flags)
            d = m.get("Default")
            if isinstance(d, str) and d and not d.startswith("__api_dump") and len(d) <= 14 \
               and not t.startswith("Enum") and t not in ("string", "Color3", "CFrame", "Vector3", "Vector2"):
                s += "=" + d
            p[name] = s
        elif kind in ("Function", "YieldableFunction"):
            args = []
            for a in (m.get("Parameters") or []):
                args.append("%s: %s" % (a.get("Name") or "arg", type_str(a.get("Type"))))
            rets = m.get("ReturnType")
            if isinstance(rets, list):
                r = ", ".join(type_str(x) for x in rets)
            elif rets:
                r = type_str(rets)
            else:
                r = "void"
            f[name] = "(%s) -> %s%s" % (", ".join(args), r, " (yields)" if kind == "YieldableFunction" else "")
        elif kind == "Event":
            e[name] = ""
        elif kind == "Callback":
            e[name] = "callback"
    return p, f, e

def main():
    src, dst = sys.argv[1], sys.argv[2]
    d = json.load(open(src, encoding="utf-8"))
    classes = {}
    for c in d.get("Classes") or []:
        name = c.get("Name")
        if not name:
            continue
        p, f, e = slim(c.get("Members") or [])
        entry = {}
        if c.get("Superclass"):
            entry["sup"] = c["Superclass"]
        if p:
            entry["p"] = p
        if f:
            entry["f"] = f
        if e:
            entry["e"] = e
        classes[name] = entry
    enums = {}
    for e in d.get("Enums") or []:
        nm = e.get("Name")
        if not nm:
            continue
        items = []
        for it in e.get("Items") or []:
            iname = it.get("Name")
            if iname:
                items.append("%s=%s" % (iname, it.get("Value")))
        enums[nm] = items
    out = {
        "version": time.strftime("%Y-%m-%d"),
        "format": 2,  # bump if the layout changes; the client keeps its old cache when the format is unknown to it
        "classes": classes,
        "enums": enums,
    }
    with open(dst, "w", encoding="utf-8") as fh:
        json.dump(out, fh, separators=(",", ":"))
    print("slimmed %d classes, %d enums -> %s (%d bytes)" % (
        len(classes), len(enums), dst, __import__("os").path.getsize(dst)))

if __name__ == "__main__":
    main()
