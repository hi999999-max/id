#!/usr/bin/env bash
# setup_max.sh — install / configure the Max backend on your Ubuntu VPS.
#
#   sudo bash deploy/setup_max.sh                      # bare-IP mode (no domain, no nginx):
#                                                      #   backend on 0.0.0.0:3002, serves /maxscript/*
#   sudo bash deploy/setup_max.sh install --ip 1.2.3.4 # same, explicit IP
#   sudo bash deploy/setup_max.sh install --domain max.example.com --email you@x.com \
#        --upstream-key KEY                            # TLS via nginx + certbot (recommended later)
#   sudo bash deploy/setup_max.sh key <label>           # mint a new revocable per-device key
#   sudo bash deploy/setup_max.sh status
#   sudo bash deploy/setup_max.sh uninstall             # removes ONLY Max's own files
#
# Design rules: never touches Docker/FreeLLMAPI/other services; no pip
# installs (python3 stdlib only); FreeLLMAPI's unified key stays in
# /etc/max/config.json (0600); executor devices get their own revocable keys.

set -euo pipefail

MAX_DIR=/opt/max
ETC=/etc/max
CONF=$ETC/config.json
UNIT=/etc/systemd/system/max-backend.service
WWW=/var/www/max
REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

say() { printf '\n\033[1;36m== %s\033[0m\n' "$*"; }
die() { printf '\033[1;31mmax-setup: %s\033[0m\n' "$*" >&2; exit 1; }
require_root() { [ "$(id -u)" = "0" ] || die "run with sudo / as root"; }
genkey() { python3 -c 'import secrets; print("mx_"+secrets.token_hex(24))'; }
detect_ip() { curl -4 -fsS --max-time 8 ifconfig.me 2>/dev/null || curl -4 -fsS --max-time 8 icanhazip.com 2>/dev/null || true; }

cfg_patch() { # python: merge keys into existing config (creates if missing)
  python3 - "$CONF" "$@" <<'PY'
import json, os, sys
conf = sys.argv[1]
cfg = {}
if os.path.isfile(conf):
    cfg = json.load(open(conf))
base = {
    "listen_host": "127.0.0.1",
    "listen_port": 3002,
    "upstream_base": "http://127.0.0.1:3001/v1",
    "upstream_key": "",
    "max_keys": [],
    "auth_required": True,
    "rate_limit_rpm": 30,
    "strategy_sequence": ["auto:smart", "auto:balanced", "auto:fast"],
    "request_timeout_s": 120,
    "upstream_probe_enabled": False,
    "static_dir": "",
}
for kv in sys.argv[2:]:
    k, _, v = kv.partition("=")
    if k == "max_keys":
        cfg.setdefault("max_keys", [])
        continue
    if k in base and base[k] is False and v in ("0", "false"):
        cfg[k] = False
    else:
        try:
            cfg[k] = json.loads(v)
        except Exception:
            cfg[k] = v
merged = {**base, **cfg}
os.makedirs(os.path.dirname(conf), exist_ok=True)
json.dump(merged, open(conf, "w"), indent=2)
os.chmod(conf, 0o600)
PY
}

cmd_install() {
  require_root
  local ip="" domain="" email="" upkey="${FREELLMAPI_KEY:-}" port=3002 with_nginx=0
  while [ $# -gt 0 ]; do
    case "$1" in
      --ip) ip="$2"; shift 2;;
      --port) port="$2"; shift 2;;
      --domain) domain="$2"; shift 2;;
      --email) email="$2"; shift 2;;
      --upstream-key) upkey="$2"; shift 2;;
      *) shift;;
    esac
  done
  command -v python3 >/dev/null || die "python3 required (stdlib 3.8+; no pip installs needed)"
  local mode="bare"
  [ -n "$domain" ] && mode="tls"

  say "1/6 backend files -> $MAX_DIR"
  mkdir -p "$MAX_DIR/backend" "$WWW"
  [ -f "$REPO/backend/max_backend.py" ] || die "run from the Max project root (backend/max_backend.py not found)"
  cp -f "$REPO/backend/max_backend.py" "$MAX_DIR/backend/"
  for f in "$REPO/client/dist/Max.lua" "$REPO/client/dist/loader.lua" "$REPO/client/loader.lua"; do
    if [ -f "$f" ]; then
      base="$(basename "$f")"
      [ "$base" = "loader.lua" ] && [ -f "$REPO/client/dist/loader.lua" ] && continue
      cp -f "$f" "$WWW/$base"
    fi
  done
  chmod 644 "$WWW"/*.lua 2>/dev/null || true
  echo "(scripts served from $WWW)"

  # Roblox API reference for the search_api / validate_property tools.
  # Refresh from the client tracker when possible; always fall back to the
  # bundled slim copy so the tools work even on an offline VPS.
  if [ -s "$WWW/api.json" ] && [ $(( $(date +%s) - $(stat -c %Y "$WWW/api.json" 2>/dev/null || echo 0) )) -lt 518400 ]; then
    say "api.json present and <6 days old (keeping it)"
  else
    if command -v curl >/dev/null && command -v python3 >/dev/null \
       && curl -fsSL --max-time 30 "https://raw.githubusercontent.com/MaximumADHD/Roblox-Client-Tracker/refs/heads/roblox/Mini-API-Dump.json" -o /tmp/max_apidump.raw 2>/dev/null \
       && [ -s /tmp/max_apidump.raw ] \
       && python3 "$REPO/deploy/slim_apidump.py" /tmp/max_apidump.raw "$WWW/api.json" >/dev/null 2>&1; then
      say "api.json refreshed from Roblox-Client-Tracker"
    elif [ -f "$REPO/deploy/api-dump.json" ]; then
      cp -f "$REPO/deploy/api-dump.json" "$WWW/api.json"
      say "api.json installed from bundled copy (offline/refresh skipped)"
    else
      echo "WARNING: api.json not installed — search_api/validate_property will tell users to re-run setup." >&2
    fi
    rm -f /tmp/max_apidump.raw
    chmod 644 "$WWW/api.json" 2>/dev/null || true
  fi

  say "2/6 config ($mode mode)"
  local firstkey=""
  if [ ! -f "$CONF" ]; then
    cfg_patch "listen_port=$port" ${upkey:+"upstream_key=$upkey"}
    firstkey="$(genkey)"
    cfg_patch "max_keys=[\"$firstkey\"]"
    # cfg_patch can't append via scalar; do it explicitly:
    python3 - "$CONF" "$firstkey" <<'PY'
import json, sys
conf, key = sys.argv[1], sys.argv[2]
cfg = json.load(open(conf))
cfg["max_keys"] = [key]
json.dump(cfg, open(conf, "w"), indent=2)
PY
    echo "$firstkey" > "$ETC/first-key.txt"; chmod 600 "$ETC/first-key.txt"
    [ -z "${upkey:-}" ] && echo "NOTE: upstream_key is empty — put your FreeLLMAPI unified key into $CONF before chatting works."
  else
    say "existing config kept (upstream/max_keys untouched)"
  fi
  if [ "$mode" = "bare" ]; then
    [ -z "$ip" ] || [ "$ip" = "auto" ] && ip="$(detect_ip)"
    [ -n "$ip" ] || die "could not detect public IPv4 — pass --ip"
    cfg_patch "listen_host=0.0.0.0" "listen_port=$port" "static_dir=$WWW"
  else
    cfg_patch "listen_host=127.0.0.1" "listen_port=$port" "static_dir=$WWW"
  fi

  say "3/6 systemd"
  if [ -f "$REPO/deploy/max-backend.service" ]; then
    cp "$REPO/deploy/max-backend.service" "$UNIT"
    sed -i "s|/usr/bin/python3|$(command -v python3)|" "$UNIT"
  else
    cat > "$UNIT" <<UNITFILE
[Unit]
Description=Max backend (FreeLLMAPI gateway)
After=network-online.target docker.service
[Service]
ExecStart=$(command -v python3) $MAX_DIR/backend/max_backend.py $CONF
Restart=always
RestartSec=3
NoNewPrivileges=true
PrivateTmp=true
[Install]
WantedBy=multi-user.target
UNITFILE
  fi
  systemctl daemon-reload
  systemctl enable max-backend >/dev/null 2>&1 || true
  systemctl restart max-backend
  sleep 1
  curl -fsS "http://127.0.0.1:$port/healthz" >/dev/null \
    && say "max-backend responding on :$port ✓" \
    || die "backend not answering — check: journalctl -u max-backend -n 50"

  say "4/6 public reachability"
  if [ "$mode" = "bare" ]; then
    if command -v ufw >/dev/null 2>&1 && ufw status | grep -q "Status: active"; then
      ufw allow "$port/tcp" >/dev/null && say "ufw: opened $port/tcp for Max only"
    fi
    cat <<WARN
  ⚠ Bare-IP = plain HTTP. The Max key travels in clear text between device
    and VPS. That's why keys are per-device + revocable and the backend has
    its own rate limiter + auth. ALSO: Fasthosts' CloudNX panel has a cloud
    firewall — open inbound TCP $port (HTTP) there or nothing will reach you.
WARN
    PUBURL="http://$ip:$port"
  else
    if command -v nginx >/dev/null 2>&1; then
      if [ ! -f /etc/nginx/conf.d/zz-max.conf ]; then
        sed "s|MAX.DOMAIN.TLD|$domain|g" "$REPO/deploy/nginx-max.conf.template" > /etc/nginx/conf.d/zz-max.conf
      fi
      command -v certbot >/dev/null 2>&1 && [ -n "$email" ] && \
        certbot --nginx -d "$domain" --non-interactive --agree-tos -m "$email" -n || echo "(certbot step skipped)"
      nginx -t && systemctl reload nginx && say "nginx: https://$domain/max → 127.0.0.1:$port ✓"
      PUBURL="https://$domain/max"
    else
      say "nginx not installed — apt install nginx yourself, or rerun without --domain for bare mode" ; PUBURL="(set after nginx)"
    fi
  fi

  # loader.lua self-heal: the copy step above depends on what made it into the
  # upload; loader.lua is tiny and secret-free, so guarantee a WORKING stamped
  # one exists (regenerate if missing or still the unstamped template).
  if [ "$PUBURL" != "(set after nginx)" ]; then
    if [ "$mode" = "bare" ]; then
      LOADER_URL="$PUBURL/maxscript/loader.lua"; SCRIPT_URL="$PUBURL/maxscript/Max.lua"
    else
      LOADER_URL="https://$domain/maxscript/loader.lua"; SCRIPT_URL="https://$domain/maxscript/Max.lua"
    fi
    mkdir -p "$WWW"
    if [ ! -f "$WWW/loader.lua" ] || grep -q "MAX.DOMAIN.TLD" "$WWW/loader.lua" 2>/dev/null; then
      cat > "$WWW/loader.lua" <<LOADEREOF
-- Max loader — generated by setup_max.sh ($mode mode). One-line bootstrap:
--   loadstring(game:HttpGet("$LOADER_URL"))()
-- It fetches the current Max.lua from THIS server and runs it, so updating
-- Max = replacing /var/www/max/Max.lua here, nothing on the device.
local URL = "$SCRIPT_URL"
local src
local ok, res = pcall(function() return game:HttpGet(URL, true) end)
if ok and type(res) == "string" and #res > 200 then src = res end
if not src then
    local shapes = { syn and syn.request, http_request, request, http and http.request }
    for _, fn in ipairs(shapes) do
        if type(fn) == "function" and not src then
            local okc, r = pcall(fn, { Url = URL, Method = "GET", Headers = { ["Cache-Control"] = "no-cache" } })
            if okc then
                if type(r) == "table" then r = r.Body or r.body end
                if type(r) == "string" and #r > 200 then src = r end
            end
        end
    end
end
if not src then error("[Max loader] could not fetch " .. URL .. " — check URL/firewall") end
local chunk, err = loadstring(src)
if not chunk then error("[Max loader] fetched code failed to compile: " .. tostring(err)) end
print("[Max loader] loaded Max build (" .. #src .. " bytes)")
chunk()
LOADEREOF
      chmod 644 "$WWW/loader.lua"
      say "loader.lua generated in $WWW (bundle copy was missing or unstamped)"
    fi
  fi

  say "5/6 live check from the public side"
  if command -v curl >/dev/null; then
    code=$(curl -fsS -o /dev/null -w '%{http_code}' --max-time 10 "$PUBURL/healthz" 2>/dev/null || echo "??")
    [ "$code" = "200" ] && say "$PUBURL/healthz -> 200 ✓ (reachable from the internet)" \
      || say "$PUBURL/healthz -> $code — if '??'/timeout: open TCP $port in the Fasthosts CloudNX firewall and retest"
    scriptok=$(curl -fsS -o /dev/null -w '%{http_code}' --max-time 10 "$PUBURL/maxscript/Max.lua" 2>/dev/null || echo "??")
    [ "$scriptok" = "200" ] && say "$PUBURL/maxscript/Max.lua -> 200 ✓ (loader will work)"
  fi

  say "6/6 done — hook up your executor"
  echo "  Backend URL : $PUBURL"
  echo "  Max key     : ${firstkey:-\$(cat $ETC/first-key.txt or mint: setup_max.sh key phone)}"
  echo
  echo "  In the executor, run:"
  echo "    loadstring(game:HttpGet(\"$PUBURL/maxscript/loader.lua\"))()"
  echo "  Then in Max's GUI: ☰ → SETTINGS → paste Backend URL + key → close."
  echo "  (If an executor refuses plain http fetches, paste Max.lua itself or use --domain TLS mode.)"
  echo
  echo "  Mint more keys:   sudo bash $REPO/deploy/setup_max.sh key <label>"
  echo "  Logs:             journalctl -u max-backend -f"
}

cmd_key() {
  require_root
  local label="${1:-device}"
  [ -f "$CONF" ] || die "no config yet — run: setup_max.sh install"
  local key; key="$(genkey)"
  python3 - "$CONF" "$key" <<'PY'
import json, sys
conf, key = sys.argv[1], sys.argv[2]
cfg = json.load(open(conf))
keys = cfg.get("max_keys") or []
if key not in keys:
    keys.append(key)
cfg["max_keys"] = keys
json.dump(cfg, open(conf, "w"), indent=2)
PY
  systemctl restart max-backend || true
  say "new Max key for '$label' (revoke: delete from $CONF max_keys + restart)"
  echo "$key"
}

cmd_status() {
  systemctl status max-backend --no-pager | head -12 || true
  local port; port=$(python3 -c 'import json;print(json.load(open("/etc/max/config.json")).get("listen_port",3002))' 2>/dev/null || echo 3002)
  curl -fsS "http://127.0.0.1:$port/healthz" && echo
  curl -fsS "http://127.0.0.1:$port/v1/max/stats" -H "Authorization: Bearer $(python3 -c 'import json;print((json.load(open("/etc/max/config.json")).get("max_keys") or [""])[0])')" 2>/dev/null | head -c 400; echo
}

cmd_uninstall() {
  require_root
  say "removing Max only — Docker/FreeLLMAPI/other services untouched"
  systemctl disable --now max-backend 2>/dev/null || true
  rm -f "$UNIT" /etc/nginx/conf.d/zz-max.conf; systemctl daemon-reload
  command -v nginx >/dev/null 2>&1 && nginx -t 2>/dev/null && systemctl reload nginx || true
  rm -rf "$MAX_DIR" "$WWW"
  say "kept $ETC (config + keys). rm -rf $ETC when you're sure."
}

case "${1:-install}" in
  install) shift 2>/dev/null || true; cmd_install "$@";;
  key) shift; cmd_key "$@";;
  status) cmd_status;;
  uninstall) cmd_uninstall;;
  *) echo "usage: $0 [install [--ip A.B.C.D|--domain D --email E --upstream-key K] [--port N] | key <label> | status | uninstall]";;
esac
