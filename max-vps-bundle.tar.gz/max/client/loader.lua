--[[
    Max loader — the ONE line you paste into your executor.

    It fetches the full Max build from YOUR VPS over HTTPS, so no API keys or
    provider config ever live in shared/pasted code. Your Max key is entered
    once inside Max's GUI (sidebar → SETTINGS) and saved to the device.

    Usage:
      loadstring(game:HttpGet("https://YOUR-DOMAIN/maxscript/loader.lua"))()

    Or with a custom URL injected first (e.g. for testing/local deploy):
      getgenv().MAX_SCRIPT_URL = "https://YOUR-DOMAIN/maxscript/Max.lua"
]]

local DEFAULT = "https://MAX.DOMAIN.TLD/maxscript/Max.lua"
local target = (getgenv and getgenv().MAX_SCRIPT_URL) or DEFAULT
if target:find("MAX.DOMAIN.TLD", 1, true) then
    error("[Max loader] Set your real URL: copy the loader next to Max.lua on your VPS or set getgenv().MAX_SCRIPT_URL first.")
end

local src, how
-- 1) Roblox-level HttpGet (hooked by most executors)
local ok, res = pcall(function() return game:HttpGet(target, true) end)
if ok and type(res) == "string" and #res > 200 then src, how = res, "game:HttpGet" end
-- 2) any executor request function
if not src then
    local shapes = {
        { "syn.request", (syn and syn.request), "table" },
        { "http_request", http_request, "table" },
        { "request", request, "table" },
        { "http.request", (http and http.request), "table" },
        { "fluxus.request", (fluxus and fluxus.request), "positional" },
        { "krnl.request", (krnl and krnl.request), "table" },
    }
    for _, sh in ipairs(shapes) do
        local name, fn, kind = sh[1], sh[2], sh[3]
        if type(fn) == "function" and not src then
            local okc, r
            if kind == "table" then
                okc, r = pcall(fn, { Url = target, Method = "GET", Headers = { ["Cache-Control"] = "no-cache" } })
            else
                okc, r = pcall(fn, target, "GET", { ["Cache-Control"] = "no-cache" }, nil)
            end
            if okc then
                if type(r) == "table" and (r.Body or r.body) then
                    r = r.Body or r.body
                end
                if type(r) == "string" and #r > 200 then
                    src, how = r, name
                end
            end
        end
    end
end
if not src then
    error("[Max loader] could not fetch " .. target .. " (no working HTTP path — try a different executor request function or check the URL/TLS).")
end

local chunk, err = loadstring(src)
if not chunk then
    error("[Max loader] fetched code failed to compile: " .. tostring(err))
end
print(("[Max loader] loaded Max build via %s (%d bytes)"):format(how, #src))
chunk()
