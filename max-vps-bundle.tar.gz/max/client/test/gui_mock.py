#!/usr/bin/env python3
"""Render high-fidelity mockups of Max's in-game GUI by replaying the exact
geometry constants from src/10_ui.lua. For visual QA only (not pixel-perfect
font metrics). Usage: python3 gui_mock.py [outdir]"""
import math, os, sys
from PIL import Image, ImageDraw, ImageFont

S = 2  # supersample for crispness
def px(v): return int(round(v * S))

FDIR = "/usr/share/fonts/truetype/dejavu"
_fonts = {}
def font(size, kind="r"):  # r=regular(medium-ish), b=bold, m=mono, mb=mono bold
    key = (size, kind)
    if key not in _fonts:
        f = {"r": "DejaVuSans.ttf", "b": "DejaVuSans-Bold.ttf",
             "m": "DejaVuSansMono.ttf", "mb": "DejaVuSansMono-Bold.ttf"}[kind]
        _fonts[key] = ImageFont.truetype(os.path.join(FDIR, f), px(size))
    return _fonts[key]

# palette (verbatim from 10_ui.lua)
C = dict(bg=(9,11,20), panel=(14,17,31), panel2=(22,26,45), stroke=(47,54,84),
         text=(225,229,245), dim=(131,139,170), user=(104,96,255),
         userText=(246,246,255), max=(26,30,51), ok=(72,214,132),
         bad=(240,98,104), warn=(238,180,78), note=(116,124,158))

def alch(rgb, alpha_over_bg, base):
    """Roblox BackgroundTransparency t: color = base*(t) + rgb*(1-t)."""
    t = alpha_over_bg
    return tuple(int(round(base[i]*(t) + rgb[i]*(1-t))) for i in range(3))

def metrics(vsx, vsy, forced_mobile=None):
    mobile = forced_mobile if forced_mobile is not None else vsx < 720
    m = dict(mobile=mobile)
    m.update(font=17 if mobile else 15, fontSmall=13 if mobile else 11,
             headerH=52 if mobile else 42, btn=44 if mobile else 32,
             inputH=46 if mobile else 36, gap=8 if mobile else 6,
             radius=14 if mobile else 10, bubblePad=12 if mobile else 10)
    if mobile:
        m["winW"] = min(vsx-12, 640); m["winH"] = min(vsy-110, vsy*0.86)
    else:
        m["winW"] = min(max(560, vsx*0.44), 780); m["winH"] = min(vsy-140, 620)
    return m

def rrect(d, xy, r, fill=None, outline=None, ow=1, alpha_fill=None):
    d.rounded_rectangle([px(xy[0]), px(xy[1]), px(xy[2]), px(xy[3])],
                        radius=px(r), fill=fill, outline=outline, width=px(ow))

def text_w(s, size, kind="r"):
    return font(size, kind).getbbox(s)[2] / S

def wrap(s, size, maxw, kind="r"):
    out = []
    for para in s.split("\n"):
        words = para.split(" ")
        line = ""
        for w_ in words:
            cand = (line + " " + w_).strip()
            if text_w(cand, size, kind) <= maxw or not line:
                line = cand
            else:
                out.append(line); line = w_
        out.append(line)
    return out

def draw_icon(d, kind, cx, cy, size, col):
    s = size / 2.0
    lw = max(1, px(1.6))
    if kind == "plus":
        d.line([px(cx-s), px(cy), px(cx+s), px(cy)], fill=col, width=lw)
        d.line([px(cx), px(cy-s), px(cx), px(cy+s)], fill=col, width=lw)
    elif kind == "minus":
        d.line([px(cx-s), px(cy), px(cx+s), px(cy)], fill=col, width=lw)
    elif kind == "square":
        d.rectangle([px(cx-s*0.75), px(cy-s*0.75), px(cx+s*0.75), px(cy+s*0.75)], outline=col, width=lw)
    elif kind == "menu":
        for k in (-1, 0, 1):
            d.line([px(cx-s), px(cy+k*s*0.62), px(cx+s), px(cy+k*s*0.62)], fill=col, width=lw)
    elif kind == "x":
        d.line([px(cx-s*0.72), px(cy-s*0.72), px(cx+s*0.72), px(cy+s*0.72)], fill=col, width=lw)
        d.line([px(cx+s*0.72), px(cy-s*0.72), px(cx-s*0.72), px(cy+s*0.72)], fill=col, width=lw)
    elif kind == "up":
        d.line([px(cx), px(cy+s*0.8), px(cx), px(cy-s*0.8)], fill=col, width=lw)
        d.line([px(cx-s*0.6), px(cy-s*0.15), px(cx), px(cy-s*0.8)], fill=col, width=lw)
        d.line([px(cx+s*0.6), px(cy-s*0.15), px(cx), px(cy-s*0.8)], fill=col, width=lw)
    elif kind == "diamond":
        p = [(cx, cy-s), (cx+s*0.8, cy), (cx, cy+s), (cx-s*0.8, cy)]
        d.polygon([(px(a), px(b)) for a, b in p], fill=col)

def scene(name, vsx, vsy, mobile=None, sidebar_open=False, rows=None, convs=None,
          typing=None, window_pos=None):
    M = metrics(vsx, vsy, mobile)
    W, H = M["winW"], M["winH"]
    wx = window_pos[0] if window_pos else max(6, (vsx-W)/2)
    wy = window_pos[1] if window_pos else max(6, (vsy-H)/2-6)
    img = Image.new("RGB", (px(vsx), px(vsy)), (18, 20, 26))
    d = ImageDraw.Draw(img, "RGBA")
    # fake game backdrop: floor grid + light shafts
    for gy in range(0, int(vsy), 7):
        d.line([0, px(gy), px(vsx), px(gy)], fill=(24, 27, 34, 255), width=1)
    for gx in range(0, int(vsx), 9):
        d.line([px(gx), 0, px(gx), px(vsy)], fill=(22, 25, 32, 255), width=1)
    d.polygon([(px(vsx*0.7), 0), (px(vsx), 0), (px(vsx), px(vsy*0.3))], fill=(32, 36, 48, 255))

    # window
    rrect(d, (wx, wy, wx+W, wy+H), M["radius"], fill=C["bg"], outline=C["stroke"], ow=1.5)
    hx, hy = wx, wy
    headerH = M["headerH"]
    # header (rounded top, square bottom)
    rrect(d, (hx, hy, hx+W, hy+headerH), M["radius"], fill=C["panel"])
    d.rectangle([px(hx), px(hy+headerH-M["radius"]-1), px(hx+W), px(hy+headerH)], fill=C["panel"])
    d.line([px(hx+2), px(hy+headerH), px(hx+W-2), px(hy+headerH)],
           fill=alch(C["stroke"], 0.45, C["bg"]), width=max(1, px(0.6)))
    # header contents
    d.ellipse([px(hx+14), px(hy+headerH/2-4.5-4), px(hx+14+9), px(hy+headerH/2+4.5-4)], fill=C["ok"])
    draw_icon(d, "diamond", hx+30+9, hy+headerH/2, 14, C["user"])
    d.text((px(hx+52), px(hy+headerH/2 - 8 - (M["font"]/2))), "Max", font=font(16 if not M["mobile"] else 19, "b"), fill=C["text"])
    diag = "google/gemini-3.1-flash-lite · 1101ms"
    btnLeft = W - ((M["btn"]+8)*4 + M["btn"] + 8)
    diagAvail = btnLeft - 106
    if diagAvail >= 64:
        while text_w(diag, M["fontSmall"], "b") > diagAvail - 8 and len(diag) > 3:
            diag = diag[:-2] + "…"
        d.text((px(hx+102), px(hy+headerH/2 - 5 - M["fontSmall"]/2)), diag, font=font(M["fontSmall"], "b"), fill=C["dim"])
    bx = M["btn"]
    for i, kind in enumerate(["plus", "menu", "minus", "square", "x"], start=1):
        rx = hx+W - ((bx+8)*(i-1) + 8)      # right edge per placeBtn() (anchor 1,0)
        xx = rx - bx
        yy = hy + round((headerH-bx)/2)
        bgc = C["user"] if kind == "square" else C["panel2"]
        rrect(d, (xx, yy, xx+bx, yy+bx), 9, fill=bgc)
        col = C["userText"] if kind == "square" else (C["bad"] if kind == "x" else C["dim"])
        draw_icon(d, "menu" if kind == "menu" else kind, xx+bx/2, yy+bx/2, max(14, bx-18), col)

    # chat area (rendered onto a clipped layer so cards can't spill over the input row,
    # mirroring the ScrollingFrame behaviour in the real client)
    chatW = W
    chatTop = wy + headerH
    chatH = H - (headerH + M["inputH"] + 28)
    rimg = Image.new("RGB", img.size, C["bg"])
    rd = ImageDraw.Draw(rimg)
    maxBubbleW = max(200, (chatW - 46) * (0.92 if M["mobile"] else 0.86))
    y = chatTop + 8
    lh = lambda sz: math.ceil(sz * 1.22)
    drawMain = d
    d = rd  # rows draw on the clipped layer, pasted back below
    for row in (rows or []):
        k = row["k"]
        if k == "user" or k == "assistant":
            clean = row["t"]
            isUser = k == "user"
            one = max(text_w(ln, M["font"]) for ln in clean.split("\n"))
            wantW = maxBubbleW if one > maxBubbleW - 2*M["bubblePad"] else one + 2*M["bubblePad"] + 3
            lines = wrap(clean, M["font"], wantW - 2*M["bubblePad"])
            bh = len(lines)*lh(M["font"]) + 2*M["bubblePad"]
            if isUser:
                bx0 = hx+W-10-wantW; col_bg = C["user"]; col_tx = C["userText"]
            else:
                bx0 = hx+10; col_bg = alch(C["max"], 0.0, C["bg"]); col_tx = C["text"]
            rrect(d, (bx0, y, bx0+wantW, y+bh), M["radius"], fill=col_bg)
            ty = y + M["bubblePad"]
            for ln in lines:
                d.text((px(bx0+M["bubblePad"]), px(ty)), ln, font=font(M["font"]), fill=col_tx)
                ty += lh(M["font"])
            y += bh + M["gap"]
        elif k == "note":
            d.text((px(hx+12), px(y+ (20-lh(M["fontSmall"]))/2 )), row["t"],
                   font=font(M["fontSmall"], "b"), fill=C["note"])
            y += 20 + M["gap"]
        elif k == "exec":
            fs = M["fontSmall"]
            body = row["t"]
            blines = []
            for ln in body.split("\n"):
                seg = ln
                while text_w(seg, fs, "m") > chatW - 16:
                    cut = len(seg)
                    while text_w(seg[:cut], fs, "m") > chatW - 16: cut -= 1
                    blines.append(seg[:cut]); seg = seg[cut:]
                blines.append(seg)
            cardH = min(30 + len(blines)*(fs+3), 460)
            rrect(d, (hx+10, y, hx+W-10, y+cardH), 8, fill=C["panel2"])
            head = "» executed code" if not row.get("bad") else "» execute_code (failed)"
            d.text((px(hx+18), px(y+4)), head, font=font(fs-1, "b"),
                   fill=(C["bad"] if row.get("bad") else C["user"]))
            ty = y + 22
            for ln in blines:
                d.text((px(hx+18), px(ty)), ln, font=font(fs, "m"), fill=C["dim"])
                ty += fs + 3
            y += cardH + M["gap"]
        elif k == "meta":
            fsz = M["fontSmall"] - 2
            wmeas = text_w(row["t"], fsz)
            d.text((px(hx+W-12-wmeas), px(y)), row["t"], font=font(fsz), fill=C["dim"])
            y += 16 + M["gap"]
        elif k == "welcome":
            rrect(d, (hx+10, y, hx+W-10, y+24), 8, fill=alch(C["panel2"], 0.45, C["bg"]))
            wd = row["t"]; wsz = text_w(wd, M["fontSmall"], "b")
            d.text((px(hx + W/2 - wsz/2), px(y+4)), wd, font=font(M["fontSmall"], "b"), fill=C["note"])
            y += 24 + M["gap"]

    # paste chat clip back onto the window
    d = drawMain
    cx0, cy0 = px(wx), px(wy+headerH)
    cx1, cy1 = px(wx+W), px(wy+H-(M["inputH"]+28))
    img.paste(rimg.crop((cx0, cy0, cx1, cy1)), (cx0, cy0))

    # typing / task strip (typingBar at (12, bottom-(inputH+24)))
    stripY = wy+H - M["inputH"] - 24
    if typing:
        t = "Task: " + typing
        d.text((px(hx+12), px(stripY)), t, font=font(M["fontSmall"]), fill=C["dim"])
        dots = sum(ord(c) for c in typing) % 3
        for i in range(3):
            if i <= dots:
                x0 = hx + 12 + text_w(t, M["fontSmall"]) + 8 + i*7
                d.ellipse([px(x0), px(stripY+3), px(x0+4), px(stripY+7)], fill=C["user"])

    # input row
    iy = wy+H-M["inputH"]
    rrect(d, (hx, iy, hx+W, wy+H), M["radius"], fill=C["panel"])
    d.rectangle([px(hx), px(iy), px(hx+W), px(iy+M["radius"]+1)], fill=C["panel"])
    inW = W - (bx + 20)
    rrect(d, (hx+10, iy+5, hx+10+inW, iy+M["inputH"]-5), 8, fill=C["panel2"], outline=C["stroke"])
    ph = "Ask Max anything…"
    d.text((px(hx+10+8), px(iy+M["inputH"]/2 - lh(M["font"])/2)), ph, font=font(M["font"]), fill=C["dim"])
    sx = hx+W-(bx+6)-bx
    rrect(d, (sx, iy+ (M["inputH"]-bx)/2, sx+bx, iy+(M["inputH"]-bx)/2+bx), bx/2, fill=C["user"])
    draw_icon(d, "up", sx+bx/2, iy+M["inputH"]/2, max(14, bx-16), C["userText"])

    # sidebar (+scrim)
    if sidebar_open:
        d.rectangle([px(hx), px(hy), px(hx+W), px(hy+H)], fill=(C["bg"][0], C["bg"][1], C["bg"][2], 107))
        sbW = min(W-24, 300) if M["mobile"] else 250
        sbX, sbY = hx+8, hy+headerH+6
        sbH = H - (headerH+18)
        rrect(d, (sbX, sbY, sbX+sbW, sbY+sbH), 10, fill=C["panel"], outline=C["stroke"])
        cy = sbY + 8
        def sec(t):
            nonlocal cy
            d.text((px(sbX+8), px(cy+2)), t, font=font(M["fontSmall"], "b"), fill=C["dim"])
            cy += 20 + 4
        def convrow(title, stamp, active):
            nonlocal cy
            rh = 44 if M["mobile"] else 36
            if active:
                rrect(d, (sbX+8, cy, sbX+sbW-8, cy+rh), 10, fill=C["panel2"])
                barh = 20 if M["mobile"] else 18
                rrect(d, (sbX+6+2, cy+rh/2-barh/2, sbX+6+2+3, cy+rh/2+barh/2), 1.5, fill=C["user"])
            tx = sbX+8+20
            tw = text_w(title, M["font"]-1)
            avail = sbW-8-20-86
            shown = title if tw <= avail else title[:max(1,int(len(title)*avail/tw))]+"…"
            d.text((px(tx), px(cy+rh/2-lh(M["font"]-1)/2)), shown,
                   font=font(M["font"]-1, "b" if active else "r"), fill=C["text"] if active else C["dim"])
            d.text((px(sbX+sbW-8-40-text_w(stamp, M["fontSmall"]-2)), px(cy+rh/2-lh(M["fontSmall"])/2)),
                   stamp, font=font(M["fontSmall"]-2), fill=C["dim"])
            xbx = 30
            dx = sbX+sbW-8-4-xbx
            d.text((px(dx+xbx/2-text_w("x", 15, "b")/2), px(cy+rh/2-lh(15)/2)), "x", font=font(15, "b"), fill=C["dim"])
            cy += rh + 4
        def setlabel(t):
            nonlocal cy
            d.text((px(sbX+8), px(cy)), t, font=font(M["fontSmall"]-1), fill=C["dim"])
            cy += 16 + 4
        def setbox(val, h=None):
            nonlocal cy
            hh = h or (38 if M["mobile"] else 28)
            rrect(d, (sbX+8, cy, sbX+sbW-8, cy+hh), 6, fill=C["panel2"], outline=C["stroke"])
            d.text((px(sbX+8+7), px(cy+hh/2-lh(M["fontSmall"])/2)), val, font=font(M["fontSmall"], "m"), fill=C["text"])
            cy += hh + 4
        def actionrow(t, danger=False):
            nonlocal cy
            hh = 42 if M["mobile"] else 30
            rrect(d, (sbX+8, cy, sbX+sbW-8, cy+hh), 8, fill=C["panel2"])
            d.text((px(sbX+18), px(cy+hh/2-lh(M["font"]-1)/2)), t,
                   font=font(M["font"]-1, "b"), fill=C["bad"] if danger else C["text"])
            cy += hh + 4
        sec("CONVERSATIONS")
        for (t, s, a) in (convs or []): convrow(t, s, a)
        sec("SETTINGS")
        setlabel("Backend URL (http://ip:port or https://host)")
        setbox("http://77.68.33.65:3002")
        setlabel("Max key (minted by setup script)")
        setbox("•" * 24)
        actionrow("AI code execution: ON")
        actionrow("Test connection + stats")
        setlabel("Font size (12-20)")
        setbox(str(M["font"]))
        actionrow("Clear this conversation")
        actionrow("Delete ALL chats + memory", danger=True)

    # crop to window + margin
    pad_ = 26
    x0 = max(0, px(wx-pad_)); y0 = max(0, px(wy-pad_))
    x1 = min(px(vsx), px(wx+W+pad_)); y1 = min(px(vsy), px(wy+H+pad_))
    out = img.crop((x0, y0, x1, y1))
    return out

def main():
    outdir = sys.argv[1] if len(sys.argv) > 1 else "/home/user/max"
    A = scene("landscape-sidebar", 1366, 646, sidebar_open=True,
              rows=[{"k": "user", "t": "what is this game?"},
                    {"k": "note", "t": "» get_service_info"},
                    {"k": "note", "t": "» search_instances · vault"},
                    {"k": "assistant", "t": "It looks like a baseplate arena: PlaceId 123974602339071, 250 indexed instances so far. This isn't your average obby — the Vault folder has 121 crates."}],
              convs=[("hello", "0m", True), ("New chat", "8h", False)])
    B = scene("landscape-chat", 1366, 646,
              rows=[{"k": "note", "t": "» get_service_info"},
                    {"k": "user", "t": "teleport me to 0, 0, 0"},
                    {"k": "exec", "t": "local plr = game.Players.LocalPlayer\nlocal char = plr.Character\nif char and char:FindFirstChild(\"HumanoidRootPart\") then\n    char:SetPrimaryPartCFrame(CFrame.new(0, 6, 0))\n    print(\"moved to\", char:GetPivot().Position)\nelse\n    warn(\"no character\")\nend\n— output —\nmoved to 0, 6, 0"},
                    {"k": "assistant", "t": "You're at the origin now (0, 6, 0) — I nudged you 6 studs up so you don't fall inside the baseplate."},
                    {"k": "meta", "t": "answered in 4.1s · 2 model rounds · 1 tool call"},
                    {"k": "user", "t": "who is closest to me?"},
                    {"k": "exec", "t": "local me = workspace.CurrentCamera.CFrame.Position\nlocal best, bd = nil, math.huge\nfor i, p in ipairs(workspace:GetDescendants()) do\n    if p:IsA(\"BasePart\") and p.Name ~= \"Baseplate\" then\n        local dd = (p.Position - me).Magnitude\n        if dd < bd then bd, best = dd, p end\n    end\nend\nprint(best:GetFullName(), string.format(\"%.1f studs\", bd))"},
                    {"k": "assistant", "t": "The nearest thing is Workspace.Vault.GoldCrate — 11.3 studs away, slightly behind your left shoulder."}],
              typing="running code")
    Cm = scene("mobile-chat", 390, 844,
               rows=[{"k": "user", "t": "hook remotes for 5s"},
                     {"k": "note", "t": "» watch_remotes · start"},
                     {"k": "exec", "t": "task.wait(5)\nprint(\"window done\")"},
                     {"k": "note", "t": "» watch_remotes · report"},
                     {"k": "assistant", "t": "In 5s I saw 4 remote calls:\n• Combat.Hit (C→S) args: \"sword\", 42\n• Shop.Buy (C→S) args: \"potion\"\n• UI.Ping (S→C) x2, no args"},
                     {"k": "meta", "t": "answered in 9.8s · 3 model rounds · 3 tool calls"}],
               typing="thinking")
    Dm = scene("mobile-sidebar", 390, 844, sidebar_open=True,
               rows=[{"k": "welcome", "t": "hi — ask me anything about this game."}],
               convs=[("hello", "0m", True), ("vault scan", "1h", False), ("New chat", "8h", False)])
    aw, ah = A.size; bw, bh = B.size
    cw, ch = Cm.size; dw, dh = Dm.size
    W = max(aw+bw, cw+dw) + 48
    Hh = max(ah, bh) + max(ch, dh) + 140
    canvas = Image.new("RGB", (W, Hh), (5, 6, 10))
    d = ImageDraw.Draw(canvas)
    canvas.paste(A, (24, 44)); canvas.paste(B, (24+aw+24, 44))
    ymid = 44 + max(ah, bh) + 60
    canvas.paste(Cm, (24, ymid)); canvas.paste(Dm, (24+cw+24, ymid))
    caps = [("Landscape · sidebar open (fixed row: bar @6, text @20)", 24, 10),
            ("Landscape · chat + exec cards + timing line", 24+aw+24, 10),
            ("Portrait mobile · chat", 24, ymid-30),
            ("Portrait mobile · sidebar", 24+cw+24, ymid-30)]
    for txt, cx, cy in caps:
        d.text((cx, cy), txt, font=font(11, "m"), fill=(150, 158, 185))
    for lbl, x, y in [("A", 24+aw-16, 44+ah-20)]:
        pass
    canvas.save(os.path.join(outdir, "gui_preview.png"))
    print("wrote", os.path.join(outdir, "gui_preview.png"), canvas.size)

if __name__ == "__main__":
    main()
