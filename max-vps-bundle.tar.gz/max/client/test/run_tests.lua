--[[ Max client test suite — runs dist/Max.lua under Lua 5.1 with stubbed
     Roblox/executor globals (mock instance tree, file-backed storage, fake
     executor HTTP, headless UI). Validates JSON, HTTP dialects, memory
     persistence + corruption recovery, inspection, tools, chat engine loop,
     summaries, and GUI logic.

     Run: ../~/.tools/lua test/run_tests.lua   (from max/client) ]]
local ROOT = os.getenv("MAX_TEST_DIR") or "./maxtest"
os.execute("rm -rf " .. ROOT .. " && mkdir -p " .. ROOT)
local function shellPath(p) return ROOT .. "/" .. p end
local function dirname(p) return (p:gsub("/[^/]*$", "")) end

-------------------------------------------------------------------- fs stubs
function readfile(p)
    local f = io.open(shellPath(p), "r")
    if not f then return nil end
    local s = f:read("*a")
    f:close()
    return s
end
function writefile(p, c)
    local d = dirname(p)
    if d ~= "" and d ~= p then os.execute("mkdir -p '" .. shellPath(d) .. "'") end
    local f = assert(io.open(shellPath(p), "w"))
    f:write(c)
    f:close()
end
function appendfile(p, s)
    local f = io.open(shellPath(p), "a")
    if not f then return writefile(p, s) end
    f:write(s)
    f:close()
end
function isfile(p)
    local f = io.open(shellPath(p), "r")
    if f then f:close() return true end
    return false
end
function isfolder(p)
    local ok, _, code = os.rename(shellPath(p), shellPath(p))
    if ok then os.rename(shellPath(p), shellPath(p)) return true end
    return false
end
function makefolder(p) os.execute("mkdir -p '" .. shellPath(p) .. "'") end
function delfile(p) os.remove(shellPath(p)) os.remove(shellPath(p) .. ".bak") end
function getgenv() return _G end
function identifyexecutor() return "TestExecutor" end
-- deliberately NO cloneref, NO gethui, NO JSONEncode/JSONDecode, NO task/wait,
-- NO listfiles: exercises the fallback paths.

-------------------------------------------------------------------- Roblox stubs
Vector2 = { new = function(x, y) return { X = x or 0, Y = y or 0 } end }
Vector3 = { new = function(x, y, z) return { X = x or 0, Y = y or 0, Z = z or 0 } end }
Color3 = { fromRGB = function(r, g, b) return { R = r, G = g, B = b } end }
UDim = { new = function(s, o) return { Scale = s or 0, Offset = o or 0 } end }
UDim2 = {
    new = function(sx, ox, sy, oy)
        return { X = UDim.new(sx, ox), Y = UDim.new(sy, oy) }
    end,
    fromOffset = function(x, y) return { X = UDim.new(0, x), Y = UDim.new(0, y) } end,
    fromScale = function(sx, sy) return { X = UDim.new(sx, 0), Y = UDim.new(sy, 0) } end,
}
local enumCache = {}
Enum = setmetatable({}, {
    __index = function(_, k)
        local ns = enumCache[k]
        if not ns then
            ns = setmetatable({}, {
                __index = function(_, k2)
                    -- mirror the real client for enums Max indexes by name:
                    -- mobile Roblox has no AutomaticSize.Default (crash 2026-11-07)
                    if k == "AutomaticSize" and k2 == "Default" then
                        error('Default is not a valid member of "Enum.AutomaticSize"')
                    end
                    local key = k .. "." .. k2
                    local v = enumCache[key]
                    if not v then v = { Name = k2, _id = key }; enumCache[key] = v end
                    return v
                end,
            })
            enumCache[k] = ns
        end
        return ns
    end,
})
TweenInfo = { new = function(...) return {} end }
typeof = type
tick = os.clock
Rect = { new = function() return {} end }

local function signal()
    local s = { _c = {} }
    function s:Connect(fn)
        local c = { fn = fn }
        table.insert(s._c, c)
        local disconnected = false
        return {
            Disconnect = function()
                if disconnected then return end
                disconnected = true
                for i, cc in ipairs(s._c) do if cc == c then table.remove(s._c, i) break end end
            end,
        }
    end
    function s:Fire(...)
        for _, c in ipairs({ unpack(s._c) }) do c.fn(...) end
    end
    return s
end

local SIGNAL_NAMES = {
    MouseButton1Click = true, MouseButton1Down = true, MouseButton1Up = true,
    FocusLost = true, FocusGained = true, InputBegan = true, InputChanged = true,
    InputEnded = true, Activated = true, Changed = true, Heartbeat = true,
    MouseEnter = true, MouseLeave = true,
}

local GUI_DEFAULTS = {
    AbsoluteSize = function() return Vector2.new(600, 500) end,
    AbsolutePosition = function() return Vector2.new(40, 40) end,
    AbsoluteCanvasSize = function() return Vector2.new(600, 1200) end,
    AbsoluteContentSize = function() return Vector2.new(600, 1200) end,
}
local instances = {}
local function instance(cls, name)
    local self = {
        __cls = cls, __props = { Name = name or cls, ClassName = cls, Visible = true, Parent = nil },
        __children = {}, __attrs = {}, __sig = {},
    }
    local methods
    methods = {
        GetChildren = function(s) return { unpack(rawget(s, "__children") or {}) } end,
        GetDescendants = function(s)
            local out = {}
            local function walk(node)
                for _, c in ipairs(rawget(node, "__children") or {}) do out[#out + 1] = c; walk(c) end
            end
            walk(s)
            return out
        end,
        FindFirstChild = function(s, n)
            for _, c in ipairs(rawget(s, "__children") or {}) do if c.Name == n then return c end end
            return nil
        end,
        FindFirstChildOfClass = function(s, cl)
            for _, c in ipairs(rawget(s, "__children") or {}) do if c.ClassName == cl then return c end end
            return nil
        end,
        IsA = function(s, cl) return s.__cls == cl end,
        GetFullName = function(s)
            local parts = {}
            local node = s
            while node do parts[#parts + 1] = node.Name; node = node.Parent end
            local out = {}
            for i = #parts, 1, -1 do out[#out + 1] = parts[i] end
            return table.concat(out, ".")
        end,
        GetAttribute = function(s, k) return rawget(s, "__attrs")[k] end,
        GetAttributes = function(s) return rawget(s, "__attrs") end,
        SetAttribute = function(s, k, v) rawget(s, "__attrs")[k] = v end,
        Destroy = function(s)
            local p = s.Parent
            if p then
                local ch = rawget(p, "__children")
                for i, c in ipairs(ch) do if c == s then table.remove(ch, i) break end end
            end
            rawset(s, "__props", {})
            rawset(s, "__children", {})
        end,
        GetPropertyChangedSignal = function(s) return signal() end,
        TweenSizeAndPosition = function() end,
        TweenPosition = function() end,
    }
    local mt = {
        __index = function(t, k)
            local m = methods[k]
            if m then return m end
            local props = rawget(t, "__props")
            local v = props[k]
            if v ~= nil then return v end
            if SIGNAL_NAMES[k] then
                local sig = rawget(t, "__sig")[k]
                if not sig then sig = signal(); rawget(t, "__sig")[k] = sig end
                return sig
            end
            -- GUI instances tolerate unknown property reads (layout attrs),
            -- but game-data instances error on bogus props so Max's
            -- individual-property fallback gets realistic "unreadable" paths.
            if k == "Parent" then return props.Parent end
            if not rawget(props, "__gameObj") then
                local d = GUI_DEFAULTS[k]
                if d then return d() end
                return nil
            end
            error("unknown property: " .. tostring(k))
        end,
        __newindex = function(t, k, v)
            if k == "Parent" then
                local ch = rawget(t, "__children")
                local oldp = rawget(t, "__props").Parent
                if oldp then
                    local och = rawget(oldp, "__children")
                    for i, c in ipairs(och) do if c == t then table.remove(och, i) break end end
                end
                rawget(t, "__props").Parent = v
                if v and v ~= game then
                    local pch = rawget(v, "__children")
                    if pch then pch[#pch + 1] = t end
                end
                return
            end
            rawget(t, "__props")[k] = v
        end,
        __tostring = function(t) return t.__cls .. "(" .. tostring(rawget(t, "__props").Name) .. ")" end,
    }
    local obj = setmetatable(self, mt)
    instances[obj] = true
    return obj
end

Instance = { new = function(cls) return instance(cls, nil) end }

local serviceObjs, serviceOrder = {}, {}
local function svc(name)
    if serviceObjs[name] then return serviceObjs[name] end
    local o = instance(name, name)
    o.__gameObj = true
    serviceObjs[name] = o
    serviceOrder[#serviceOrder + 1] = o
    return o
end
serviceObjs.RunService = (function()
    local o = svc("RunService")
    o.Heartbeat = signal()
    return o
end)()
serviceObjs.TweenService = (function()
    local o = svc("TweenService")
    o.Create = function(_, inst, info, props) return { Play = function() end } end
    return o
end)()
serviceObjs.TextService = (function()
    local o = svc("TextService")
    o.GetTextSize = function(_, text, size, font, maxVec)
        local lines = 1
        for _ in tostring(text):gmatch("\n") do lines = lines + 1 end
        local perLine = math.max(12, math.floor((maxVec and maxVec.X or 300) / (size * 0.55)))
        lines = lines + math.floor(#tostring(text) / perLine)
        return Vector2.new(math.min(#tostring(text) * size * 0.55, maxVec and maxVec.X or 999), lines * size * 1.25)
    end
    return o
end)()
serviceObjs.UserInputService = (function()
    local o = svc("UserInputService")
    o.InputBegan = signal()
    o.InputChanged = signal()
    o.InputEnded = signal()
    o.GetFocusedTextBox = function() return nil end
    o.IsKeyDown = function() return false end
    o.KeyboardEnabled = true
    return o
end)()
local localPlayer = instance("Player", "Tester")
localPlayer.GetMouse = function() return { Width = 800, Height = 600 } end
serviceObjs.Players = svc("Players")
serviceObjs.Players.LocalPlayer = localPlayer

game = {
    PlaceId = 1818, JobId = "job-abc", GameName = "Max Test Place",
    GetService = function(_, n) return svc(n) end,
    GetChildren = function()
        local out = {}
        for _, o in ipairs(serviceOrder) do
            if o.ClassName ~= "TweenService" and o.ClassName ~= "TextService"
                and o.ClassName ~= "UserInputService" and o.ClassName ~= "RunService" then
                out[#out + 1] = o
            end
        end
        return out
    end,
    Players = svc("Players"),
}
game.Players = serviceObjs.Players

local camera = instance("Camera", "Camera")
camera.ViewportSize = Vector2.new(1024, 768)
workspace = svc("Workspace")
workspace.CurrentCamera = camera
local playersRoot = svc("Players")

------------------------------------------------------------------ mock game tree
local function mk(cls, name, parent, props)
    local o = instance(cls, name)
    o.__gameObj = true
    if props then for k, v in pairs(props) do o[k] = v end end
    o.Parent = parent
    return o
end
local partA = mk("Part", "SpawnPlate", workspace, {
    Transparency = 0, Anchored = true, Size = Vector3.new(64, 1, 20), Position = Vector3.new(0, 0, 0),
})
local partB = mk("Part", "Ramp", workspace, { Transparency = 0.4, Anchored = false, Size = Vector3.new(8, 8, 8), Position = Vector3.new(3, 2, 1) })
partB:SetAttribute("SpawnIndex", 2)
partB:SetAttribute("Rare", true)
local vault = mk("Model", "Vault", workspace, {})
local crate = mk("Part", "GoldCrate", vault, { Transparency = 0, Anchored = true, Size = Vector3.new(4, 4, 4), Position = Vector3.new(9, 1, 0) })
mk("Frame", "VaultUI", serviceObjs["CoreGui"] or svc("CoreGui"), { Visible = true })
mk("Folder", "Config", serviceObjs["ReplicatedStorage"] or svc("ReplicatedStorage"), {})
mk("StringValue", "VersionTag", serviceObjs["ReplicatedStorage"] or svc("ReplicatedStorage"), { Value = "1.4" })
mk("Part", "LootCache", serviceObjs["ReplicatedStorage"] or svc("ReplicatedStorage"), { Transparency = 0, Anchored = true, Size = Vector3.new(1, 1, 1), Position = Vector3.new(0, 0, 0) })
local char = mk("Model", "Tester", playersRoot, {})
local hum = mk("Humanoid", "Humanoid", char, { Health = 87.5, MaxHealth = 100, WalkSpeed = 16 })
for i = 1, 120 do
    mk("Part", "Filler" .. i, vault, { Transparency = 0, Anchored = true, Size = Vector3.new(1, 1, 1), Position = Vector3.new(i, 0, 0) })
end

-------------------------------------------------------------------- executor fakes
local http = { log = {}, mode = "syn-ok", calls = 0 }
_G.http = http
local function healthBody() return '{"ok":true,"service":"max-backend","version":"1.0.0"}' end
local function transportRespond(reqTable)
    local url = tostring(reqTable.Url or reqTable.url or "")
    http.calls = http.calls + 1
    if url:find("/v1/chat/completions") then
        local body = NSJSON or nil
        local req = MaxNS.JSON.Decode(reqTable.Body or reqTable.body or "{}")
        http.lastChat = req
        if http.chatQueue and #http.chatQueue > 0 then
            return table.remove(http.chatQueue, 1)
        end
        return { statuscode = 200, body = '{"error":{"message":"empty queue"}}' }
    end
    if url:find("/v1/max/stats") then
        return { statuscode = 200, body = '{"ok":true,"catalog":{"ready_models":3},"routing":{}}' }
    end
    return { statuscode = 200, body = healthBody() }
end

syn = {}
syn.request = function(t)
    if http.mode ~= "syn-ok" and http.mode ~= "flaky" then error("syn disabled in this mode") end
    if type(t) ~= "table" or type(t.Url) ~= "string" then error("unexpected call shape") end
    table.insert(http.log, t)
    return transportRespond(t)
end
fluxus = {
    request = function(url, method, headers, body)
        if http.mode ~= "positional-only" then error("fluxus disabled in this mode") end
        if type(url) ~= "string" then error("positional only accepts (url, method, headers, body)") end
        table.insert(http.log, { Url = url, Method = method, Headers = headers, Body = body })
        local r = transportRespond({ Url = url, Body = body })
        return { status = r.statuscode, body = r.body } -- lowercase shape
    end,
}
httpG = {} -- bare `http` table name clash avoided; not used

-------------------------------------------------------------------- load bundle
MaxNS = { __NoAutoStart = true, __TestMode = true }
dofile("dist/Max.lua")
local NS = MaxNS
-- synchronous spawn/Wait for deterministic tests
NS.Spawn = function(f, ...) local ok, e = pcall(f, ...) if not ok then error(e, 0) end end
NS.Wait = function() end

-------------------------------------------------------------------- assert kit
local pass, fail = 0, {}
local function ok(cond, msg)
    if cond then pass = pass + 1 else fail[#fail + 1] = msg end
end
local function eq(a, b, msg) ok(a == b, msg .. " (got " .. tostring(a) .. ", want " .. tostring(b) .. ")") end
local function near(a, b, msg) ok(math.abs(a - b) < 0.001, msg) end

-------------------------------------------------------------------- boot
NS.Main.Start()
ok(NS.Storage.Mode == "files", "storage in files mode")
ok(NS.Env.Feats["syn.request"], "syn.request detected")
ok(not NS.Env.Feats.cloneref, "cloneref absent handled")
ok(NS.Env.ExecutorName == "TestExecutor", "executor name")

-------------------------------------------------------------------- JSON
do
    local J = NS.JSON
    local t = { a = 1, b = "two", c = { 3, true, 5 }, d = { e = "f\"g\nh" }, neg = -2.5, uni = "héllo→" }
    local enc = J.Encode({ x = t })
    local dec = J.Decode(enc)
    ok(type(dec) == "table" and dec.x ~= nil, "json roundtrip object")
    eq(dec.x.b, "two", "json string")
    eq(dec.x.d.e, "f\"g\nh", "json escapes")
    near(dec.x.neg, -2.5, "json float")
    eq(dec.x.uni, "héllo→", "json utf8")
    eq(#dec.x.c, 3, "json array roundtrip")
    ok(J.Decode("not json") == nil, "rejects garbage")
    local loose = J.DecodeLoose('prose {"fact":"x","tag":"t"} trailing')
    ok(type(loose) == "table", "loose decode found array")
    eq(J.Encode({ [1] = "a", [2] = "b" }), '["a","b"]', "array encode")
    eq(J.Encode({ n = 1 / 0 }), '{"n":null}', "inf -> null")
end

-------------------------------------------------------------------- settings
do
    local S = NS.Settings
    eq(S.Get("device"):sub(1, 4), "max-", "device id generated")
    S.Set("diagBar", false)
    S.Init()
    eq(S.Get("diagBar"), false, "false boolean setting persists")
    S.Set("diagBar", true)
    ok(isfile("Max/settings.json"), "settings file written")
end

-------------------------------------------------------------------- memory
local convId
do
    local M = NS.Memory
    local conv = M.Active()
    convId = conv.id
    M.AppendMessage(conv, "user", "hello Max, I like neon bases in roblox")
    M.AppendMessage(conv, "assistant", "hi! I remember that.")
    M.AppendMessage(conv, "tool", '{"ok":true}', { tool_call_id = "call_1", tool_name = "search_instances" })
    local reloaded = M.LoadConversation(conv.id)
    ok(reloaded and #reloaded.messages == 3, "conversation reload from disk")
    eq(reloaded.messages[1].role, "user", "role persisted")
    ok(reloaded.messages[1].time, "timestamp persisted")
    eq(reloaded.messages[3].tool_name, "search_instances", "tool meta persisted")
    ok(isfile("Max/conv/" .. conv.id .. ".json"), "conv file exists")
    ok(isfile("Max/conv/" .. conv.id .. ".json.log"), "write-ahead log exists")
    local idx = M.LoadIndex()
    ok(idx.convs[conv.id] and idx.active == conv.id, "index tracks conversation")

    -- multi-conversation independence
    local conv2 = M.NewConversation("Second chat")
    M.AppendMessage(conv2, "user", "unrelated topic about water")
    M.SetActive(conv.id)
    eq(#M.Active().messages, 3, "first conversation unaffected by second")
    local list = M.ListConversations()
    ok(#list >= 2, "ListConversations shows both")

    -- corrupt snapshot -> .bak recovery
    writefile("Max/conv/" .. conv.id .. ".json", "{{{garbage!!")
    local rec = M.LoadConversation(conv.id)
    ok(rec and #rec.messages >= 2, "corrupt file recovered from backup")

    -- corrupt everything except .log -> rebuild
    writefile("Max/conv/" .. conv.id .. ".json", "nope")
    writefile("Max/conv/" .. conv.id .. ".json.bak", "nope too")
    local rebuilt = M.LoadConversation(conv.id)
    ok(rebuilt and #rebuilt.messages >= 3, "rebuilt from write-ahead log: " .. tostring(rebuilt and #rebuilt.messages))

    -- corrupt everything -> nil + quarantine
    local f = io.open(shellPath("Max/conv/" .. conv.id .. ".json.log"), "w"); f:write("###\nbroken line\n"); f:close()
    writefile("Max/conv/" .. conv.id .. ".json", "{{{")
    writefile("Max/conv/" .. conv.id .. ".json.bak", "}}}")
    local dead = M.LoadConversation(conv.id)
    ok(dead == nil or type(dead) == "table", "all-corrupt returns nil cleanly (got " .. type(dead) .. ")")
    local hasQuarantine = false
    for _, dir in ipairs({ "Max/corrupt" }) do
        local pipe = io.popen("ls " .. shellPath(dir) .. " 2>/dev/null | wc -l")
        local n = tonumber((pipe:read("*a"):gsub("%s", "")))
        pipe:close()
        if n and n > 0 then hasQuarantine = true end
    end
    ok(hasQuarantine, "corrupt files quarantined")

    -- delete
    local idBefore = conv2.id
    M.DeleteConversation(idBefore)
    ok(not isfile("Max/conv/" .. idBefore .. ".json"), "conversation deleted from disk")
    M.SetActive(convId)
    NS.Memory.activeConv = NS.Memory.LoadConversation(convId) or NS.Memory.NewConversation()
end

-------------------------------------------------------------------- facts + search
do
    local M = NS.Memory
    M.ClearFacts()
    M.AddFact("User prefers concise answers", "preference", "test")
    M.AddFact("User prefers concise answers", "preference", "test") -- dedupe
    eq(#M.facts, 1, "duplicate fact deduped")
    M.AddFact("User's Roblox executor runs on Android tablet", "setup", "test")
    local hits = M.SearchMemory("anything about android tablet performance")
    local foundSetup = false
    for _, h in ipairs(hits) do if h.kind == "fact" and h.text:find("Android") then foundSetup = true end end
    ok(foundSetup, "SearchMemory retrieves relevant fact")
    local section = M.MemoryPromptSection("android")
    ok(section:find("Android", 1, true) ~= nil, "memory prompt section contains fact")
    local added = M.UpdateMemory('[{"fact":"User is building a neon vault obby","tag":"project"}]')
    eq(added, 1, "UpdateMemory parses JSON text")
    M.AddFact(string.rep("pad ", 60), "filler", "test") -- over 300 chars -> rejected
end

-------------------------------------------------------------------- HTTP dialects
do
    local H = NS.HTTP
    eq(H.Transport and H.Transport.name, "syn.request", "syn.request auto-selected (already probed at boot)")
    http.chatQueue = { { statuscode = 200, body = '{"id":"x","object":"chat.completion","model":"auto:smart","choices":[{"index":0,"message":{"role":"assistant","content":"pong"},"finish_reason":"stop"}],"max":{"route":"auto:smart","routed_via":"groq/test","latency_ms":42}}',
                        headers = { ["content-type"] = "application/json" } } }
    NS.Settings.Set("apiKey", "test-key-123")
    local data = NS.API.Chat({ messages = { { role = "user", content = "ping" } } })
    ok(data and data.choices and data.choices[1].message.content == "pong", "chat via transport layer")
    eq(http.log[#http.log].Headers["Authorization"], "Bearer test-key-123", "auth header sent")
    eq(http.log[#http.log].Headers["Content-Type"] or http.log[#http.log].Headers["content-type"], "application/json", "json content type")
    ok(NS.API.Diag and NS.API.Diag.routed_via == "groq/test", "diag metadata parsed from body")

    -- switch to positional-only transport & re-probe
    http.mode = "positional-only"
    H.Transport = nil
    H.Ready = false
    H.ConsecFails = 0
    local pOk = H.Probe(NS.Settings.Get("apiBase"))
    ok(pOk and H.Transport.name == "fluxus.request" and H.Transport.shape == "positional",
       "fell back to positional fluxus.request (" .. tostring(H.Transport and H.Transport.shape) .. ")")
    local r = H.Send({ url = "http://x/healthz", method = "GET", baseUrl = NS.Settings.Get("apiBase") })
    ok(r.ok and r.status == 200, "normalized lowercase response fields")

    -- transport failure + bounded retry recovery (Send retries; probe does not)
    http.mode = "flaky"
    http.flakyLeft = 2
    local goodFn = syn.request
    H.ConsecFails = 0
    H.Transport = { name = "flaky", shape = "table", fn = function(t)
        if http.flakyLeft > 0 then http.flakyLeft = http.flakyLeft - 1 error("connection reset") end
        return goodFn(t)
    end }
    local okRetry = H.Send({ url = "http://x/healthz", method = "GET", baseUrl = NS.Settings.Get("apiBase") })
    ok(okRetry.ok, "Send retried through flaky transport and recovered")
    http.mode = "syn-ok"
    H.Transport = { name = "syn.request", shape = "table", fn = syn.request }

    -- total transport failure: bounded attempts, structured error, no hang
    http.mode = "syn-break"
    H.Transport = nil
    local failr = H.Send({ url = "http://x/y", method = "GET", baseUrl = "http://x" })
    ok(failr.ok == false and type(failr.err) == "string", "hard failure returns structured error")
    http.mode = "syn-ok"
    H.Transport = { name = "syn.request", shape = "table", fn = syn.request }
end

-------------------------------------------------------------------- inspection
do
    local I = NS.Inspect
    I.Build(true)
    ok(I.State.Built > 30, "index built: " .. I.State.Built)
    local s = I.Search({ query = "crate" })
    ok(s.ok and s.total >= 1 and s.items[1].path:find("GoldCrate"), "search by name substring")
    local parts = I.Search({ ["class"] = "Part", limit = 50 })
    ok(parts.total >= 120, "class filter finds many parts (got " .. parts.total .. ")")
    local wsOnly = I.Search({ ["class"] = "Part", service = "Workspace", limit = 50 })
    ok(wsOnly.total >= 2 and wsOnly.total < parts.total, "service filter narrows")
    local ancs = I.Search({ query = "vault", limit = 50 })
    ok(ancs.total >= 120, "descendants of a matching folder still found via lazy paths (got " .. ancs.total .. ")")
    ok(ancs.items[1].path:find("Vault", 1, true), "reconstructed path shows ancestry")
    local inst, err = I.ResolvePath("Workspace.Vault.GoldCrate")
    ok(inst ~= nil, "resolve path ok: " .. tostring(err))
    local kids = I.GetChildren({ path = "Workspace.Vault" })
    ok(kids.ok and kids.total == 121, "children of Vault = 121 (got " .. kids.total .. ")")
    local p2 = I.GetChildren({ path = "Workspace.Vault", limit = 10, page = 2 })
    ok(#p2.items == 10 and p2.items[1].name ~= kids.items[1].name, "children pagination")
    local desc = I.GetDescendants({ path = "Workspace.Vault", depth = 2, limit = 30 })
    ok(desc.ok and #desc.items > 0, "descendants walk")
    local info = I.GetInfo("Workspace.Ramp", true, true)
    ok(info.ok and info.class == "Part" and info.attributes.Rare ~= nil, "info with attributes")
    ok(type(info.properties.Transparency) == "string", "individual property read fallback")
    eq(info.propertiesMethod, "individual(known-set)", "labels individual reads")
    local props = I.Properties(crate, nil)
    ok(props.values.Anchored == "true", "boolean stringified")
    -- bulk getproperties present scenario
    NS.Env.GetProps = function(inst2, includeHidden)
        return { Name = inst2.Name, Transparency = 0.5, ExtraBulkProp = "z" }
    end
    NS.Env.GetPropsName = "getproperties"
    local bulk = I.Properties(crate, nil)
    ok(bulk.method:find("bulk") and bulk.values.ExtraBulkProp == "z", "bulk getproperties used when available")
    NS.Env.GetProps = nil
    -- math userdata must surface real values, not "<userdata>" (the "unreadable CFrame" bug)
    do
        local fakeCF = newproxy(true)
        getmetatable(fakeCF).__tostring = function() return "0, 4, -90, -1, 0, 0, 0, 1, 0, 0, 0, 1" end
        local prevIIS = rawget(_G, "isinstancesupported")
        rawset(_G, "isinstancesupported", function() return false end)
        local str1 = I.Stringify(fakeCF)
        ok(str1:find("0, 4", 1, true) ~= nil, "CFrame-like userdata stringifies to real value (iis present)")
        rawset(_G, "isinstancesupported", nil)
        local fakeVec = newproxy(true)
        getmetatable(fakeVec).__tostring = function() return "12, 0, 34" end
        ok(I.Stringify(fakeVec) == "12, 0, 34", "vector-like userdata stringifies without iis")
        rawset(_G, "isinstancesupported", prevIIS)
    end
    -- wantNames filters a bulk snapshot instead of skipping bulk entirely
    do
        NS.Env.GetProps = function(inst2) return { CFrame = "0, 1, 2", Anchored = true, Name = "Crate" } end
        NS.Env.GetPropsName = "getproperties"
        local filt = I.Properties(crate, { "CFrame" })
        ok(filt.method:find("bulk") and filt.values.CFrame == "0, 1, 2" and filt.values.Anchored == nil,
            "bulk snapshot filtered to requested properties")
        NS.Env.GetProps = nil
    end
    local noRes = I.ResolvePath("Workspace.Nope.Nope")
    ok(not noRes, "missing path errors")
    local svcInfo = I.ServiceInfo("Workspace")
    ok(svcInfo.ok and svcInfo.children >= 3, "service info")
    local byprop = I.SearchByProperty({ property = "Anchored", value = true, match = "exact", limit = 5 })
    ok(byprop.ok and #byprop.items > 0 and byprop.items[1].Anchored == "true", "search_by_property exact")
    local attrs = I.Attributes(partB)
    ok(attrs.ok and tostring(attrs.attributes.SpawnIndex) == "2", "attributes read (stringified)")
    local full, ferr = NS.Try(function() return partA:GetFullName() end)
    ok(full, "GetFullName works: " .. tostring(ferr))
    local big = I.Search({ query = "Filler", limit = 50 })
    ok(big.pageSize <= 50, "result limit enforced")
end

------------------------------------------------------------------ tools layer
do
    local T = NS.Tools
    eq(#T.Defs, 55, "fifty-five tools defined (33 + decompile/terminal/web/api R16 set)")
    T.ResetBudget()
    local res = NS.JSON.Decode(T.Execute("search_instances", '{"query":"gold"}'))
    ok(res.ok and res.items[1].path:find("GoldCrate"), "tool executes search")
    local bad = NS.JSON.Decode(T.Execute("hack_the_planet", "{}"))
    ok(bad.ok == false and bad.error:find("unknown"), "unknown tool refused")
    local propsTool = NS.JSON.Decode(T.Execute("get_properties", '{"path":"Workspace.Vault.GoldCrate"}'))
    ok(propsTool.ok and propsTool.bulk_available == false, "get_properties reports bulk availability")
    local info = NS.JSON.Decode(T.Execute("get_instance_info", '{"path":"Workspace.Ramp","with_attributes":true}'))
    ok(info.ok and info.attributes.Rare == "true", "tool info with attributes (stringified)")
    -- budget exhaustion
    T.budgetLeft = 1
    T.Execute("search_instances", '{"query":"x"}')
    local over = NS.JSON.Decode(T.Execute("search_instances", '{"query":"x"}'))
    ok(over.ok == false and over.error:find("budget"), "tool budget enforced")
    -- result size cap
    T.ResetBudget()
    local big = T.Execute("search_by_class", '{"class":"Part","limit":50}')
    ok(#big <= T.MaxJSONChars, "tool result capped (" .. #big .. " chars)")

    -- execute_code: capture, errors, return value, settings gate
    T.ResetBudget()
    local function exec(code, timeout)
        NS.Tools.ResetBudget() -- each call simulates a fresh user message
        return NS.JSON.Decode(T.Execute("execute_code", NS.JSON.Encode({ code = code, timeout = timeout or 3 })))
    end
    local echoed = exec('print("hi", 40 + 2)\nreturn 7')
    ok(echoed.ok and echoed.output and echoed.output:find("hi", 1, true) and echoed.output:find("42", 1, true),
        "execute_code captures print output")
    eq(echoed.returned, "7", "execute_code surfaces return value")
    local boom = exec('local x = 1\nerror("boom " .. x)')
    ok(boom.ok == false and boom.error and boom.error:find("boom 1", 1, true), "execute_code captures runtime errors")
    local syntax = exec('this is not lua @@')
    ok(syntax.ok == false and syntax.compileError ~= nil, "execute_code reports compile errors")
    local warned = exec('warn("careful") print("p1")')
    ok(warned.ok and warned.output:find("[warn] careful", 1, true) and warned.output:find("p1", 1, true),
        "execute_code captures warn")
    -- global print must be intact afterwards
    print("[Max] marker after exec")
    local loop = exec('while true do end', 1)
    ok(loop.ok == false and (loop.timedOut or (loop.error or ""):find("refused", 1, true)),
        "infinite loop stopped or refused (guard: " .. tostring(loop.guard) .. ")")
    NS.Settings.Set("execEnabled", false)
    local gated = exec("print(1)")
    ok(gated.ok == false and gated.error:find("disabled", 1, true), "execEnabled=false refuses execution")
    NS.Settings.Set("execEnabled", true)
    -- code sees the live environment (game table is reachable via sandbox __index)
    local seesEnv = exec('return tostring(game ~= nil)')
    eq(seesEnv.returned, "true", "executed code sees Roblox globals")

    ------------------------------------------------------------------ inspect_globals
    T.ResetBudget()
    rawset(_G, "MaxTestExecutorFn", function() return 1 end)
    rawset(_G, "MaxTestConfig", { mode = "fast", n = 2 })
    local g = NS.JSON.Decode(T.Execute("inspect_globals", NS.JSON.Encode({ match = "maxtest" })))
    ok(g.ok and g.total == 2, "inspect_globals lists matching globals (got " .. tostring(g.total) .. ")")
    local byName = {}
    for _, it in ipairs(g.items or {}) do byName[it.name] = it end
    eq(byName.MaxTestExecutorFn and byName.MaxTestExecutorFn.type, "function", "functions typed, no value")
    ok(byName.MaxTestConfig and byName.MaxTestConfig.info and byName.MaxTestConfig.info:find("mode=fast", 1, true),
        "table values serialized")
    local g2 = NS.JSON.Decode(T.Execute("inspect_globals", NS.JSON.Encode({ match = "maxtest", values = false })))
    ok(g2.ok and g2.shown == 2 and g2.items[1].info == nil and g2.items[2].info == nil,
        "values=false → names only")
    rawset(_G, "MaxTestExecutorFn", nil)
    rawset(_G, "MaxTestConfig", nil)

    ------------------------------------------------------------------ watch_remotes v2 (R15 rebuild)
    -- Contract tests for the rebuilt engine: exact-once delivery, verbatim returns,
    -- inbound via BOTH hook mechanisms, faults isolated, no double hooks, honest restore.
    do
        local function wx(js) T.ResetBudget() return NS.JSON.Decode(T.Execute("watch_remotes", js)) end
        local function wxr(js) T.ResetBudget() return T.Execute("watch_remotes", js) end
        local E = { deliveries = 0, installs = 0, mc = nil, hookmap = {}, curScript = nil, ccSkip = false }
        local mtGame = {}
        local rawNamecall
        rawNamecall = function(self, ...)
            E.deliveries = E.deliveries + 1
            if E.mc == "InvokeServer" then return 10, nil, "reply-string" end
            if E.mc == "Invoke" then return "inv-a", nil end
            return "orig"
        end
        mtGame.__namecall = rawNamecall
        local function engine(self, ...) return mtGame.__namecall(self, ...) end
        rawset(_G, "getrawmetatable", function() return mtGame end)
        rawset(_G, "hookmetamethod", function(obj, meta, newf)
            if obj ~= game or meta ~= "__namecall" then error("unexpected hook target") end
            local prev = mtGame.__namecall
            mtGame.__namecall = newf
            E.installs = E.installs + 1
            return prev
        end)
        rawset(_G, "getnamecallmethod", function() return E.mc end)

        local remote = { ClassName = "RemoteEvent", Name = "Hit" }
        function remote:GetFullName() return "Workspace.Hit" end
        local pay = { ClassName = "RemoteFunction", Name = "Pay" }
        function pay:GetFullName() return "ReplicatedStorage.Pay" end
        local chatIn = { ClassName = "UnreliableRemoteEvent", Name = "ChatIn" }
        function chatIn:GetFullName() return "ReplicatedStorage.ChatIn" end
        local bindEv = { ClassName = "BindableEvent", Name = "Be" }
        function bindEv:GetFullName() return "Workspace.Be" end
        local bindFn = { ClassName = "BindableFunction", Name = "Bf" }
        function bindFn:GetFullName() return "Workspace.Bf" end

        local w0 = wx('{"action":"report"}')
        ok(w0.ok == false, "v2: report before start refuses")

        local st = wx('{"action":"start"}')
        ok(st.ok and st.started and E.installs == 1, "v2: start installs exactly ONE namecall hook")
        local st2 = wx('{"action":"start"}')
        ok(st2.ok and st2.started == false and E.installs == 1, "v2: double start re-arms, never double-hooks")

        -- outbound RemoteEvent: pass-through + fire-time snapshot
        E.mc = "FireServer"
        local d0 = E.deliveries
        local rv = engine(remote, "specialArg", 42)
        eq(rv, "orig", "v2: game call still returns verbatim through the spy")
        eq(E.deliveries - d0, 1, "v2: original namecall executes EXACTLY once while watched")
        local rep = wx('{"action":"report","match":"specialarg"}')
        ok(rep.ok and rep.matched == 1 and rep.items[1].args:find("specialArg", 1, true)
            and rep.items[1].args:find("42", 1, true) and #tostring(rep.items[1].time) >= 5,
            "v2: outbound fire logged (args snapshot + time + method + dir)")
        eq(rep.items[1].dir, "→server", "v2: direction marked")

        -- RemoteFunction multi-return incl. nil — the exact thing v1's pcall broke
        E.mc = "InvokeServer"
        local a, b, c = engine(pay, { amount = 50, who = "zed" })
        ok(a == 10 and b == nil and c == "reply-string", "v2: multiple returns AND nil pass verbatim (InvokeServer)")
        local rep2 = wx('{"action":"report","match":"zed"}')
        ok(rep2.matched == 1 and rep2.items[1].args:find('who="zed"', 1, true),
            "v2: nested table args expanded with quoted strings at fire time")
        ok(rep2.items[1].ret == nil and rep2.items[1].reply == nil, "v2: NO reply capture by design (user rule)")
        E.mc = "Invoke"
        local ia, ib = engine(bindFn, "x")
        ok(ia == "inv-a" and ib == nil, "v2: BindableFunction invoke passthrough")
        local repIB = wx('{"action":"report","match":"Workspace.Bf"}')
        ok(repIB.matched >= 1, "v2: bindable invoke observed")

        -- unreliable + bindable events
        E.mc = "FireServerUnreliable"
        engine(chatIn, "u1")
        E.mc = "Fire"
        engine(bindEv, "b1")
        local rep3 = wx('{"action":"report","limit":20}')
        local sawU, sawB
        for _, e in ipairs(rep3.items) do
            if e.remote:find("ChatIn", 1, true) then sawU = e.dir == "→server" end
            if e.remote == "Workspace.Be" then sawB = e.dir == "→bind" end
        end
        ok(sawU, "v2: UnreliableRemoteEvent captured")
        ok(sawB, "v2: BindableEvent fire captured")

        -- caller attribution: v2 re-probes capabilities on start, so a keep-start
        -- picks up a mid-session injected global (same contract as v1's re-probe)
        rawset(_G, "getcallingscript", function() return E.curScript end)
        wx('{"action":"start","keep":true}')
        E.mc = "FireServer"
        E.curScript = { Name = "BotScript", ClassName = "LocalScript" }
        engine(remote, "callerTest1")
        E.curScript = { Name = "MapMgr", ClassName = "ModuleScript" }
        engine(remote, "callerTest2")
        local rep4 = wx('{"action":"report","match":"callerTest"}')
        local froms = {}
        for _, e in ipairs(rep4.items) do froms[e.args:match("callerTest(%d)")] = e.from end
        ok(froms["1"] == "BotScript [LocalScript]" and froms["2"] == "MapMgr [ModuleScript]",
            "v2: caller attribution differs per originating script")
        E.curScript = nil

        -- checkcaller: Max's own fires never enter the log (no self-echo storms)
        rawset(_G, "checkcaller", function() return E.ccSkip end)
        wx('{"action":"start","keep":true}')
        E.ccSkip = true
        engine(remote, "selfEcho")
        E.ccSkip = false
        local rep5 = wx('{"action":"report","match":"selfEcho"}')
        eq(rep5.matched, 0, "v2: own-thread fires skipped via checkcaller")
        rawset(_G, "checkcaller", nil)

        -- inbound: validated connection swap (no hookfunction in this env)
        local preRet = { "handled:hi:7", "second" }
        local calls = 0
        local conn = { Function = function(x, n)
            calls = calls + 1
            return preRet[1] .. "", preRet[2], nil
        end }
        local preFn = conn.Function
        local chatIn2 = mk("UnreliableRemoteEvent", "ChatIn2", svc("ReplicatedStorage"),
            { OnClientEvent = { __conns = { conn } } })
        rawset(_G, "getconnections", function(sig) return sig.__conns end)
        local stI = NS.JSON.Decode(T.Execute("watch_remotes",
            NS.JSON.Encode({ action = "start", paths = { "ReplicatedStorage.ChatIn2" }, keep = true })))
        ok(stI.ok and stI.wrapped == 1, "v2: targeted start wraps the remote's connections")
        local ha, hb, hc = conn.Function("hi", 7)
        ok(ha == "handled:hi:7" and hb == "second" and hc == nil and calls == 1,
            "v2: wrapped handler keeps multiple returns and runs exactly once")
        local rep6 = wx('{"action":"report","match":"hi", "method":"OnClientEvent"}')
        ok(rep6.matched >= 1 and rep6.items[1].dir == "←event" and rep6.items[1].method == "OnClientEvent",
            "v2: inbound fire logged with signal name")
        local stM = NS.JSON.Decode(T.Execute("watch_remotes",
            NS.JSON.Encode({ action = "start", paths = { "ReplicatedStorage.Nowhere" }, keep = true })))
        ok(stM.ok and stM.misses and stM.misses[1]:find("Nowhere", 1, true),
            "v2: unresolvable paths reported, never silently dropped")

        -- restore: original handler back verbatim after stop
        local stp = wx('{"action":"stop"}')
        ok(stp.ok and stp.seen and stp.restoredHandlers >= 2, "v2: stop restores namecall + connections")
        ok(mtGame.__namecall == rawNamecall, "v2: ORIGINAL namecall handler is back byte-for-byte")
        ok(conn.Function == preFn, "v2: original OnClientEvent handler is back in place")
        local repAfter = wx('{"action":"report"}')
        ok(repAfter.ok == false, "v2: disarmed after stop (report refuses)")
        chatIn2.Parent = nil

        -- before / during / after differential: same event, same outcome, one delivery
        E.mc = "FireServer"
        local dd0, v0 = E.deliveries, engine(remote, "diffTest")
        local f0 = E.deliveries - dd0
        wx('{"action":"start"}')
        local dd1, v1 = E.deliveries, engine(remote, "diffTest")
        local f1 = E.deliveries - dd1
        wx('{"action":"stop"}')
        local dd2, v2 = E.deliveries, engine(remote, "diffTest")
        local f2 = E.deliveries - dd2
        ok(v0 == v1 and v1 == v2 and f0 == 1 and f1 == 1 and f2 == 1,
            "v2: returns + delivery count identical before/during/after monitoring")

        -- repeated enable/disable cycles stay single-hook and single-delivery
        for cyc = 1, 3 do
            wx('{"action":"enable"}')
            local dc = E.deliveries
            E.mc = "FireServer"
            engine(remote, "cycle" .. cyc)
            if E.deliveries - dc ~= 1 then ok(false, "v2: cycle " .. cyc .. " changed delivery count") end
            wx('{"action":"disable"}')
        end
        ok(true, "v2: 3 enable/disable cycles — every event delivered exactly once each")

        -- foreign hook installed on top of ours mid-session: stop must not clobber it
        wx('{"action":"start"}')
        local foreign = function(self, ...) return rawNamecall(self, ...) end
        mtGame.__namecall = foreign
        E.mc = "FireServer"
        local dfx = E.deliveries
        local vfx = engine(remote, "foreignChain")
        ok(vfx == "orig" and E.deliveries - dfx == 1, "v2: traffic keeps flowing under a foreign hook")
        local stpF = wx('{"action":"stop"}')
        ok(stpF.ok and tostring(stpF.notes and stpF.notes[1] or ""):find("another hook", 1, true),
            "v2: stop detects the foreign hook and refuses to overwrite it")
        ok(mtGame.__namecall == foreign, "v2: foreign handler left intact")
        mtGame.__namecall = rawNamecall

        -- serializer hostility must never reach the game
        wx('{"action":"start"}')
        local hostile = setmetatable({ Name = "Hostile" }, {
            __index = function(_, k) if k == "ClassName" then error("hostile index fault") end end,
        })
        local okH = pcall(engine, hostile, 1)
        ok(okH, "v2: a faulting member read inside the spy cannot error the game's call")
        local repF2 = wx('{"action":"report"}')
        ok(repF2.serializer_faults and repF2.serializer_faults >= 1, "v2: spy faults counted, never swallowed silently")

        -- spam guard: counts survive, appends stop, nothing evicts earlier entries
        local prevClock = os.clock
        os.clock = function() return 4242.5 end
        local spamR = { ClassName = "RemoteEvent", Name = "Spam" }
        function spamR:GetFullName() return "Workspace.Spam" end
        E.mc = "FireServer"
        for i = 1, 40 do engine(spamR, "spam" .. i) end
        local rawSpam = wxr('{"action":"report","match":"spam","limit":50}')
        print("PROBE len=" .. #rawSpam .. " tail=" .. rawSpam:sub(-120))
        local spam = NS.JSON.Decode(rawSpam)
        print("PROBE decoded=" .. tostring(spam ~= nil) .. " matched=" .. tostring(spam and spam.matched) .. " perRemote=" .. tostring(spam and spam.perRemote))
        eq(spam.matched, 25, "v2: 40 rapid fires -> 25 logged (append-stop)")
        ok(tostring(spam.note):find("spam guard", 1, true), "v2: note explains suppression to the AI")
        local perSpam
        for _, g in ipairs(spam.perRemote) do if g.remote == "Workspace.Spam" then perSpam = g end end
        ok(perSpam and perSpam.fired == 40 and perSpam.suppressed == 15,
            "v2: perRemote keeps FULL counts (40 fired, 15 suppressed) while the log caps")
        os.clock = prevClock
        local cleared = wx('{"action":"report","match":"spam","clear":true}')
        ok(cleared.cleared and cleared.cleared >= 20, "v2: report clear=true drains matched entries")
        local afterClear = wx('{"action":"report","match":"spam"}')
        ok(afterClear.matched == 0, "v2: cleared entries stay gone")
        wx('{"action":"stop"}')

        -- hookfunction path (Cobalt-style per-function hook) preferred when present
        local handlerFn = function(x) return "H:" .. tostring(x), "two" end
        local conn2 = { Function = handlerFn }
        local rem2 = mk("RemoteEvent", "HF", svc("ReplicatedStorage"),
            { OnClientEvent = { __conns = { conn2 } } })
        rawset(_G, "hookfunction", function(f, w) E.hookmap[f] = w; return f end)
        rawset(_G, "restorefunction", function(f)
            if E.hookmap[f] == nil then error("not function-hooked") end -- honest fake: only detaches real hookfunction targets
            E.hookmap[f] = nil
            return true
        end)
        local stH = NS.JSON.Decode(T.Execute("watch_remotes",
            NS.JSON.Encode({ action = "start", paths = { "ReplicatedStorage.HF" } })))
        ok(stH.ok and stH.inbound_method == "hookfunction", "v2: hookfunction preferred when executor has it")
        ok(conn2.Function == handlerFn, "v2: NO connection clobbering when function-hooking works")
        local function engineHandler(f, ...) local w = E.hookmap[f] or f; return w(...) end
        local h1, h2 = engineHandler(handlerFn, "zz")
        ok(h1 == "H:zz" and h2 == "two", "v2: hooked handler keeps every return")
        local repH = wx('{"action":"report","match":"zz"}')
        ok(repH.matched >= 1 and repH.items[1].dir == "←event", "v2: hookfunction inbound logged")
        local stp2 = wx('{"action":"stop"}')
        ok(stp2.ok and E.hookmap[handlerFn] == nil, "v2: restorefunction detaches cleanly on stop")
        rem2.Parent = nil

        -- capability honesty: nothing to hook with -> refuse, game untouched
        for _, n in ipairs({ "hookmetamethod", "getnamecallmethod", "getrawmetatable",
                             "getconnections", "hookfunction", "restorefunction", "getcallingscript" }) do
            rawset(_G, n, nil)
        end
        local d0b = E.deliveries
        local stNo = wx('{"action":"start"}')
        ok(stNo.ok == false and stNo.error:find("hookmetamethod", 1, true),
            "v2: start fails cleanly without hookmetamethod (clean refusal, no partial state)")
        engine(remote, "postNoCap")
        eq(E.deliveries - d0b, 1, "v2: game path completely unaffected by the failed attempt")

        -- Delta-style: capabilities ONLY behind getgenv(), hm returns the old fn
        local injected = {
            hookmetamethod = function(obj, meta, newf)
                mtGame.__namecall = newf
                E.installs = E.installs + 1
                return rawNamecall
            end,
            getnamecallmethod = function() return E.mc end,
        }
        rawset(_G, "getgenv", function() return injected end)
        local wDelta = wx('{"action":"start"}')
        ok(wDelta.ok and wDelta.started, "v2: resolves capabilities through getgenv injection")
        E.mc = "FireServer"
        local dv = E.deliveries
        local rd = engine(remote, "deltaStyle")
        ok(rd == "orig" and E.deliveries - dv == 1, "v2: Delta-style passthrough intact (returns from prev captured via hm return value)")
        local wDeltaStop = wx('{"action":"stop"}')
        ok(wDeltaStop.ok and mtGame.__namecall == rawNamecall, "v2: Delta-style stop restores the real original")
        rawset(_G, "getgenv", nil)
        T.ResetBudget()
    end

    ------------------------------------------------------------------ persisted display bubbles
    do
        local M = NS.Memory
        local prevActive = M.index and M.index.active
        local c = M.NewConversation("bubble persist")
        M.SetActive(c.id)
        c = M.Active()
        M.AppendMessage(c, "user", "q1")
        M.PushBubble({ k = "note", s = "» get_properties · Workspace.Vault.GoldCrate" })
        M.AppendMessage(c, "assistant", "a1")
        M.PushBubble({ k = "meta", s = "answered in 1.5s" })
        M.SaveConversation(c)
        local back = M.LoadConversation(c.id)
        ok(back.bubbles and #back.bubbles == 2, "bubbles round-trip through storage")
        ok(back.bubbles[1].s:find("GoldCrate", 1, true), "tool note keeps its target after reload")
        eq(back.bubbles[1].at, 1, "bubble anchored after the user message")
        M.TrimBubblesForFold(back, 1)
        eq(#back.bubbles, 1, "fold drops bubbles inside the folded region")
        eq(back.bubbles[1].at, 1, "fold shifts remaining anchors left")
        if prevActive then M.SetActive(prevActive) end
    end

    ------------------------------------------------------------------ Roblox API reference tools
    do
        T.ResetBudget()
        local fake = { version = "test", classes = {
            Instance = { p = { Name = "string", Parent = "Instance|readonly" },
                         f = { Destroy = "() -> void", GetFullName = "() -> string" },
                         e = { Destroying = "" } },
            BasePart = { sup = "Instance", p = { Anchored = "bool=false", Transparency = "float=0",
                         Mass = "number|readonly" }, f = { GetRenderFidelity = "(c: Camera?) -> number" },
                         e = { Touched = "" } },
            Part = { sup = "BasePart", p = { Shape = "Enum.PartType|local=Ball" }, f = {}, e = {} },
            Highlight = { sup = "Instance", p = { Enabled = "bool=true", FillColor = "Color3",
                         Adornee = "Instance", ReservedId = "Enum.ReservedHighlightId|w:RobloxScriptSecurity,r:RobloxScriptSecurity" },
                         f = {}, e = {} },
        }, enums = { HighlightDepthMode = { "AlwaysOnTop=0", "Occluded=1" },
                     Font = { "Arial=0", "Gotham=3", "SourceSans=2" } } }
        T.ApiDump.data = fake
        T.ApiDump.names = nil
        local card = NS.JSON.Decode(T.Execute("search_api", NS.JSON.Encode({ class = "Part", parents = true })))
        ok(card.ok and card.kind == "class" and card.class == "Part", "search_api class card")
        eq(card.inheritance, "Part -> BasePart -> Instance", "inheritance chain shown")
        local hasProp, hasFn, hasEvt = false, false, false
        for _, s in ipairs(card.properties or {}) do
            if s:find("Transparency: float = 0", 1, true) then hasProp = true end
        end
        for _, s in ipairs(card.methods or {}) do if s:find("GetRenderFidelity", 1, true) then hasFn = true end end
        for _, s in ipairs(card.events or {}) do if s:find("Destroying", 1, true) then hasEvt = true end end
        ok(hasProp and hasFn and hasEvt, "parents=true merges props/methods/events (formatted types)")
        local ownOnly = NS.JSON.Decode(T.Execute("search_api", NS.JSON.Encode({ class = "Part", parents = false })))
        ok(ownOnly.ok and #ownOnly.properties == 1 and #ownOnly.methods == 0, "parents=false keeps the card own-class only")
        local byDef = NS.JSON.Decode(T.Execute("search_api", '{"class":"Part"}'))
        local tagged = false
        for _, t in ipairs(byDef.properties or {}) do
            if t:find("Anchored", 1, true) and t:find("[BasePart]", 1, true) then tagged = true end
        end
        ok(byDef.ok and tagged, "inherited members resolve by default, tagged with their source class")
        local enumCard = NS.JSON.Decode(T.Execute("search_api", '{"class":"HighlightDepthMode"}'))
        ok(enumCard.ok and enumCard.kind == "enum" and enumCard.total == 2
            and enumCard.items[1]:find("AlwaysOnTop", 1, true), "enum card lists valid items (class= works for enums too)")
        local enumQ = NS.JSON.Decode(T.Execute("search_api", '{"query":"depthmode"}'))
        ok(enumQ.ok and enumQ.kind == "enums" and enumQ.matches[1].enum == "HighlightDepthMode", "enum-name search")
        local fz = NS.JSON.Decode(T.Execute("search_api", '{"query":"higlight"}'))
        local fuzzyHit = false
        for _, n in ipairs(fz.didYouMean or {}) do if n == "Highlight" then fuzzyHit = true end end
        ok(fz.ok and fz.kind == "fuzzy" and fuzzyHit, "misspelled class name gets fuzzy didYouMean, not an error")
        local mf = NS.JSON.Decode(T.Execute("search_api", NS.JSON.Encode({ class = "Highlight", member = "fill" })))
        ok(mf.ok and #mf.properties == 1 and mf.properties[1]:find("FillColor", 1, true), "member filter narrows the card")
        local list = NS.JSON.Decode(T.Execute("search_api", '{"query":"high"}'))
        ok(list.kind == "classes" and list.total == 1 and list.matches[1].class == "Highlight", "substring class list")
        local memberFind = NS.JSON.Decode(T.Execute("search_api", '{"query":"transparency"}'))
        local sawBase = false
        for _, nm in ipairs(memberFind.classes or {}) do if nm == "BasePart" then sawBase = true end end
        ok(memberFind.kind == "member" and sawBase, "member-name query finds defining classes")
        local vp = NS.JSON.Decode(T.Execute("validate_property", NS.JSON.Encode({ class = "Part", property = "Mass" })))
        ok(vp.ok and vp.exists and vp.definedIn == "BasePart" and vp.datatype == "number" and vp.readonly == true
            and vp.writable == false, "class-mode hit through inheritance with datatype + writability flags")
        local sec = NS.JSON.Decode(T.Execute("validate_property", NS.JSON.Encode({ class = "Highlight", property = "ReservedId" })))
        ok(sec.ok and sec.exists and sec.writeSecurity == "RobloxScriptSecurity" and sec.writable == true
            and sec.datatype == "Enum.ReservedHighlightId", "security info surfaced where available")
        local und = NS.JSON.Decode(T.Execute("validate_property", NS.JSON.Encode({ path = "Workspace.Vault", property = "Whatever" })))
        ok(und.ok and und.exists == false and und.undetermined == true
            and und.note:find("not in the offline API dump", 1, true),
            "class missing from dump => undetermined, not claimed absent")
        local typo = NS.JSON.Decode(T.Execute("validate_property", NS.JSON.Encode({ class = "Highlight", property = "FillColor3" })))
        local cand = false
        for _, s in ipairs(typo.candidates or {}) do if s == "FillColor" then cand = true end end
        -- also via pure edit distance:
        local ty2 = NS.JSON.Decode(T.Execute("validate_property", NS.JSON.Encode({ class = "Highlight", property = "Enbled" })))
        local cand2 = false
        for _, s in ipairs(ty2.candidates or {}) do if s == "Enabled" then cand2 = true end end
        ok(ty2.ok and ty2.exists == false and cand2, "misspelled property: fuzzy candidate (Enbled -> Enabled)")
        ok(typo.ok and typo.exists == false and cand, "typo'd property: missing + did-you-mean")
        local clsTypo = NS.JSON.Decode(T.Execute("validate_property", NS.JSON.Encode({ class = "Higlight", property = "Enabled" })))
        local dym = false
        for _, s in ipairs(clsTypo.didYouMean or {}) do if s == "Highlight" then dym = true end end
        ok(clsTypo.ok == false and clsTypo.error:find("unknown class") and dym, "unknown class refused with suggestion")
        local live = NS.JSON.Decode(T.Execute("validate_property", NS.JSON.Encode({ path = "Workspace.Vault.GoldCrate", property = "Anchored" })))
        ok(live.ok and live.exists and live.hasValue and live.value == "true", "live instance mode returns the actual value")
        local crateInst = NS.Inspect.ResolvePath("Workspace.Vault.GoldCrate")
        rawget(crateInst, "__props").Nick = ""
        local empty = NS.JSON.Decode(T.Execute("validate_property", NS.JSON.Encode({ path = "Workspace.Vault.GoldCrate", property = "Nick" })))
        ok(empty.ok and empty.exists and empty.hasValue == false
            and empty.note:find("No value but property exists", 1, true), "empty property -> 'no value but property exists'")
        local missing = NS.JSON.Decode(T.Execute("validate_property", NS.JSON.Encode({ path = "Workspace.Vault.GoldCrate", property = "Frobnicate" })))
        ok(missing.ok and missing.exists == false, "bogus live property -> exists=false")
        -- cold path: no dump + no cache + no base URL explains itself; disk cache then revives it
        T.ApiDump.data = nil
        T.ApiDump.names = nil
        local prevBase = NS.Settings.Get("apiBase")
        NS.Settings.Set("apiBase", "")
        local cold = NS.JSON.Decode(T.Execute("search_api", '{"class":"Part"}'))
        ok(cold.ok == false and cold.error and cold.error:find("api.json", 1, true), "missing dump explains itself cleanly")
        NS.Storage.Write("apidump.json", NS.JSON.Encode(fake))
        local warm = NS.JSON.Decode(T.Execute("search_api", NS.JSON.Encode({ class = "Highlight", member = "enabled" })))
        ok(warm.ok and warm.properties[1] and warm.properties[1]:find("Enabled", 1, true), "loads api reference from disk cache")
        NS.Storage.Delete("apidump.json")
        NS.Settings.Set("apiBase", prevBase)
        T.ApiDump.data = nil
        T.ApiDump.names = nil
    end

    ------------------------------------------------------------------ real shipped dump end-to-end
    do
        local path = "../deploy/api-dump.json"
        if type(io) == "table" and io.open then
            local fh = io.open(path, "r")
            if fh then
                local raw = fh:read("*a")
                fh:close()
                local okD, d = pcall(NS.JSON.Decode, raw)
                ok(okD and type(d) == "table" and d.classes and d.classes.Highlight,
                    "real api-dump.json decodes with Max's JSON module (" .. tostring(d and "table" or "err") .. ")")
                T.ApiDump.data = d
                T.ApiDump.names = nil
                local hl = NS.JSON.Decode(T.Execute("search_api", '{"class":"Highlight","parents":true}'))
                local hasFill = false
                for _, s in ipairs(hl.properties or {}) do
                    if s:find("FillColor:", 1, true) then hasFill = true end
                    ok(not s:find("FillColor3", 1, true), "real dump does not invent FillColor3")
                end
                ok(hl.ok and hasFill, "real Highlight card exposes FillColor")
                local gone = NS.JSON.Decode(T.Execute("validate_property", '{"class":"Highlight","property":"FillColor3"}'))
                local suggested = false
                for _, s in ipairs(gone.candidates or {}) do if s == "FillColor" then suggested = true end end
                ok(gone.ok and gone.exists == false and suggested, "FillColor3 -> missing, suggests FillColor (the ping-adjacent trap)")
                local ping = NS.JSON.Decode(T.Execute("validate_property", '{"class":"Player","property":"Ping"}'))
                ok(ping.ok and ping.exists == false, "Player.Ping confirmed nonexistent by real dump")
                local big = NS.JSON.Decode(T.Execute("search_api", '{"class":"Player","parents":true,"limit":400}'))
                ok(big.ok and #NS.JSON.Encode(big) < 9000, "big class card stays inside the tool-result budget")
                T.ApiDump.data = nil
                T.ApiDump.names = nil
            end
        end
    end
end

------------------------------------------------------------------ chat engine + tool loop
do
    local M = NS.Memory
    NS.Memory.activeConv = M.NewConversation("engine test")
    local conv = NS.Memory.activeConv
    local seen = { notes = {}, appends = {}, diag = nil, errors = {} }
    NS.Hooks.OnToolNote = function(n, a) seen.notes[#seen.notes + 1] = n end
    NS.Hooks.OnAppend = function(r, t) seen.appends[#seen.appends + 1] = { r, t } end
    NS.Hooks.OnDiag = function(d) seen.diag = d end
    NS.Hooks.OnError = function(e) seen.errors[#seen.errors + 1] = tostring(e) end
    NS.Hooks.OnTyping = function() end

    local call = { n = 0 }
    local realChat = NS.API.Chat
    NS.API.Chat = function(req)
        call.n = call.n + 1
        if call.n == 1 then
            return {
                choices = { { finish_reason = "tool_calls", message = {
                    role = "assistant", content = nil,
                    tool_calls = { { id = "c1", type = "function", ["function"] = { name = "get_instance_info", arguments = '{"path":"Workspace.Vault.GoldCrate"}' } } },
                } } },
                max = { route = "auto:smart", routed_via = "mock/test", latency_ms = 5, model = "mock" },
            }
        end
        -- verify the tool result made it back
        local toolMsg
        for _, m in ipairs(req.messages) do if m.role == "tool" then toolMsg = m end end
        local t = toolMsg and NS.JSON.Decode(toolMsg.content)
        assert(toolMsg and t and t.ok and t.class == "Part", "tool result round-tripped into next request")
        return {
            choices = { { finish_reason = "stop", message = { role = "assistant", content = "The crate is a Part named GoldCrate." } } },
            max = { route = "auto:smart", routed_via = "mock/test2", latency_ms = 7, model = "mock2" },
        }
    end
    NS.API.ExtractFacts = function() end
    local realMaybe = NS.API.MaybeSummarize
    NS.API.MaybeSummarize = function() end
    local sent = NS.API.SendUserMessage("what is the main part of the vault model?")
    ok(sent, "send accepted")
    ok(call.n == 2, "two model calls (tool round + final), got " .. call.n)
    eq(#seen.notes, 1, "UI notified about tool call")
    eq(seen.appends[1][1], "user", "user bubble")
    eq(seen.appends[#seen.appends][1], "assistant", "assistant bubble")
    ok(NS.API.Diag ~= nil, "diag metadata recorded (via real A.Chat in HTTP test)")
    -- persistence of the exchange
    local reload = M.LoadConversation(conv.id)
    local hasAssistant = false
    for _, m in ipairs(reload.messages) do
        if m.role == "assistant" and m.content and m.content:find("GoldCrate") then hasAssistant = true end
    end
    ok(hasAssistant, "full exchange persisted to disk")
    NS.API.Chat = realChat
    NS.API.MaybeSummarize = realMaybe
end

    ------------------------------------------------------------------ update_task: persistent requirement checklist
    do
        local T2 = NS.Tools
        local M2 = NS.Memory
        T2.ResetBudget()
        NS.Memory.activeConv = M2.NewConversation("task state")
        local conv = NS.Memory.Active()
        local function ut(t) return NS.JSON.Decode(T2.Execute("update_task", NS.JSON.Encode(t))) end
        local lines = {}
        for i = 1, 30 do lines[i] = "[ ] requirement " .. i end
        local r = ut({ objective = "  fix   the spy  ", lines = lines })
        ok(r.ok and r.items == 24, "checklist capped at 24 lines (got " .. tostring(r.items) .. ")")
        eq(r.open, 24, "all unchecked lines counted as open")
        eq(conv.task.obj, "fix the spy", "objective normalised and held on the conversation")
        local back = M2.LoadConversation(conv.id)
        ok(back.task and back.task.items and #back.task.items == 24, "task state round-trips through save+load (survives restart)")
        eq(back.task.items[1], "[ ] requirement 1", "checklist lines intact after reload")
        local r2 = ut({ lines = { "[x] did the thing (verified by re-run)", "[ ] still pending" } })
        eq(r2.done, 1, "verified lines counted"); eq(r2.open, 1, "pending lines counted")
        local before = T2.budgetLeft
        for _ = 1, 5 do ut({ objective = "bookkeeping should be free" }) end
        eq(T2.budgetLeft, before, "update_task never costs the tool budget (it is working memory, not a task step)")
        local sp = NS.API.BuildSystemPrompt("hi", NS.Memory.Active())
        ok(sp:find("Active task state", 1, true) and sp:find("still pending", 1, true),
            "checklist is re-injected into the next system prompt")
        local r3 = ut({ objective = " ", lines = {} })
        ok(r3.ok and r3.cleared and conv.task == nil, "empty update clears task state")
        NS.API.SendUserMessage = NS.API.SendUserMessage -- no-op lint anchor
    end

    ------------------------------------------------------------------ auto-continue on exhausted budget
    do
        local M2 = NS.Memory
        local prevR, prevA = NS.Settings.Get("maxToolRounds"), NS.Settings.Get("autoContinue")
        NS.Settings.Set("maxToolRounds", 2) -- loop cap = max(6, 4) = 6 rounds
        local realChat2, realSum2, realFacts2 = NS.API.Chat, NS.API.MaybeSummarize, NS.API.ExtractFacts
        NS.API.MaybeSummarize = function() end
        NS.API.ExtractFacts = function() end
        local calls, contMsgs = 0, 0
        NS.API.Chat = function(req)
            calls = calls + 1
            contMsgs = 0
            for _, m in ipairs(req.messages) do
                if m.role == "user" and type(m.content) == "string" and m.content:find("AUTO-CONTINUE", 1, true) then
                    contMsgs = contMsgs + 1
                end
            end
            if req.tools then
                return { choices = { { finish_reason = "tool_calls", message = { role = "assistant", content = nil,
                    tool_calls = { { id = "a" .. calls, type = "function",
                        ["function"] = { name = "get_class_name", arguments = '{"path":"Workspace"}' } } } } } } }
            end
            return { choices = { { finish_reason = "stop", message = { role = "assistant", content = "partial report" } } } }
        end
        NS.Settings.Set("autoContinue", 2)
        NS.Memory.activeConv = M2.NewConversation("autocont")
        NS.Tools.ResetBudget()
        NS.API.SendUserMessage("long task")
        eq(calls, 19, "6 rounds + auto-continue + 6 + auto-continue + 6 + wrap-up")
        eq(contMsgs, 2, "two AUTO-CONTINUE instructions injected (no user nagging)")
        NS.Settings.Set("autoContinue", 0)
        NS.Memory.activeConv = M2.NewConversation("autocont-off")
        NS.Tools.ResetBudget()
        calls, contMsgs = 0, 0
        NS.API.SendUserMessage("long task")
        eq(calls, 7, "auto-continue OFF: single segment then wrap-up (old behaviour)")
        eq(contMsgs, 0, "nothing injected when disabled")
        NS.API.Chat = realChat2
        NS.API.MaybeSummarize, NS.API.ExtractFacts = realSum2, realFacts2
        NS.Settings.Set("maxToolRounds", prevR)
        NS.Settings.Set("autoContinue", prevA)
        NS.Tools.ResetBudget()
    end

    ------------------------------------------------------------------ learning consent gate
    do
        local K = NS.Knowledge
        local M2 = NS.Memory
        local prevL = NS.Settings.Get("learningEnabled")
        K.entries = {}
        NS.Memory.activeConv = M2.NewConversation("learning gate")
        M2.AppendMessage(M2.Active(), "tool", '{"ok":true}') -- fresh success evidence
        NS.Settings.Set("learningEnabled", false)
        eq(K.AutoCapture("what is my ping", "Ping comes from Stats.Network.ServerStatsItem Data Ping, confirmed live: 42ms"), nil,
            "learningEnabled=false: auto-capture refuses even with success evidence")
        eq(#K.entries, 0, "no entry written while learning is off")
        NS.Settings.Set("learningEnabled", true)
        local cap = K.AutoCapture("what is my ping", "Ping comes from Stats.Network.ServerStatsItem Data Ping, confirmed live: 42ms")
        ok(cap and #K.entries == 1, "learning back on: capture resumes as normal")
        NS.Settings.Set("learningEnabled", prevL)
        K.entries = {}
        NS.Storage.Delete("knowledge.json")
    end

    ------------------------------------------------------------------ model tier wiring (settings -> request)
    do
        eq(NS.Settings.Get("modelTier"), "auto", "default tier is Automatic")
        eq(NS.API.ModelString(), "auto", "Automatic sends plain auto and lets the backend classify per message")
        NS.Settings.Set("modelTier", "smart")
        eq(NS.API.ModelString(), "auto:smart", "Smart pins auto:smart")
        NS.Settings.Set("modelTier", "RELIABLE")
        eq(NS.API.ModelString(), "auto:reliable", "tier names are case-insensitive")
        NS.Settings.Set("modelTier", "garbage")
        eq(NS.API.ModelString(), "auto", "unknown value falls back to auto — a bad settings.json can never break requests")
        local realPost = NS.HTTP.PostJson
        local captured
        NS.HTTP.PostJson = function(u, b)
            captured = b
            return { ok = true, status = 200, body = '{"choices":[{"message":{"content":"x"}}]}' }
        end
        NS.Settings.Set("modelTier", "balanced")
        NS.API.Chat({ messages = { { role = "user", content = "hi" } } })
        eq(captured and captured.model, "auto:balanced", "chat request bodies carry the chosen tier")
        NS.Settings.Set("modelTier", "auto")
        NS.API.Chat({ messages = { { role = "user", content = "hi" } } })
        eq(captured and captured.model, "auto", "Automatic sends bare auto (backend escalates per message)")
        NS.API.Chat({ messages = { { role = "user", content = "hi" } }, model = "auto:fast" })
        eq(captured and captured.model, "auto:fast", "explicit req.model still overrides (background jobs)")
        NS.HTTP.PostJson = realPost
        NS.Settings.Set("modelTier", "auto")
    end

------------------------------------------------------------------ summaries
do
    local M = NS.Memory
    NS.Memory.activeConv = M.NewConversation("summary test")
    local conv = NS.Memory.activeConv
    for i = 1, 30 do
        M.AppendMessage(conv, i % 2 == 1 and "user" or "assistant", "line " .. i .. " of chat about parts and bases")
    end
    M.MessageCap = 12
    local realChat = NS.API.Chat
    NS.API.Chat = function(req)
        return { choices = { { message = { content = "- test summary bullet" } } } }
    end
    NS.Hooks.OnTyping = function() end
    NS.Hooks.OnAppend = function() end
    NS.Hooks.OnError = function(e) error(e) end
    NS.API.MaybeSummarize(conv)
    ok(conv.summary and conv.summary:find("test summary") ~= nil, "summary written")
    ok(#conv.messages < 30 and #conv.messages >= 12 - 10 or #conv.messages > 0, "messages trimmed after summarize: " .. #conv.messages)
    local prompt = M.PromptMessages(conv)
    eq(prompt[1].role, "system", "prompt starts with summary note")
    ok(prompt[1].content:find("summary") ~= nil, "summary in prompt")
    NS.API.Chat = realChat
    M.MessageCap = 200
end

------------------------------------------------------------------ GUI logic (headless smoke)
do
    local U = NS.UI
    ok(U.window and U.window.Visible, "window visible after boot")
    local chatChildren = #U.chat:GetChildren()
    U:AddBubble("user", "hello there")
    U:AddBubble("assistant", "hi **you**! here is a `code` bit")
    ok(#U.chat:GetChildren() == chatChildren + 2, "bubbles append")
    local bubble = U.chat:GetChildren()[#U.chat:GetChildren()]
    ok(bubble:IsA("Frame"), "bubble row is frame")
    local bfr = bubble:GetChildren()[1]
    local label
    for _, c in ipairs(bfr:GetChildren()) do
        if c.ClassName == "TextLabel" then label = c break end
    end
    ok(label and label.Text:find("hi you") ~= nil, "markdown sanitized in bubble")
    U:SetTyping(true)
    eq(U.typingBar.Visible, true, "typing indicator shows")
    U:SetTask("inspecting client", "get_properties")
    ok(U.typingBar.Text:find("Task: inspecting client") and U.typingBar.Text:find("get_properties"),
        "task label shows activity + detail")
    U:SetTyping(false)
    eq(U.typingBar.Visible, false, "typing indicator hides")
    eq(U._task, nil, "task clears with typing off")
    U:Toast("test toast")
    eq(U.toast.Text, "test toast", "toast shows message")
    U:ToggleSidebar()
    eq(U.sidebarOpen, true, "sidebar opens")
    U:ToggleSidebar()
    U:SetVisible(false)
    eq(U.window.Visible, false, "minimize hides window")
    eq(U.orb.Visible, true, "reopen orb shown")
    U:SetVisible(true)
    eq(U.window.Visible, true, "orb reopen works")

    -- metrics/mobile responsive
    camera.ViewportSize = Vector2.new(420, 860)
    local mMobile = U:Metrics()
    ok(mMobile.mobile == true and mMobile.btn >= 44, "mobile mode + 44px touch targets")
    ok(mMobile.winW <= 420 - 12, "window fits phone width")
    camera.ViewportSize = Vector2.new(1024, 768)
    local mDesk = U:Metrics()
    ok(not mDesk.mobile and mDesk.winW >= 560 and mDesk.winW <= 780, "desktop window sizing")
    U:Relayout()

    -- sidebar interactions via stub events
    local convBtn
    for _, ch in ipairs(U.sidebar:GetChildren()) do
        if ch.ClassName == "TextButton" then convBtn = ch break end
    end
    ok(convBtn ~= nil, "sidebar conversation rows built")
    local before = #(NS.Memory.index.convs)
    local function tcount(t) local n = 0 for _ in pairs(t) do n = n + 1 end return n end
    before = tcount(NS.Memory.index.convs)
    U.btnNew.MouseButton1Click:Fire()
    eq(tcount(NS.Memory.index.convs), before + 1, "new-chat button creates conversation")
    NS.UI:SetDiag({ routed_via = "groq/llama-3.3-70b", latency_ms = 123, route = "auto:smart" })
    ok(U.diagLabel.Text:find("groq") ~= nil, "diagnostics show current model+provider")

    -- keyboard send path (Return while input focused)
    local UIS = NS.Service("UserInputService")
    UIS.GetFocusedTextBox = function() return U.input end
    U.input.Text = "sent via enter"
    UIS.InputBegan:Fire({ UserInputType = Enum.UserInputType.Keyboard, KeyCode = Enum.KeyCode.Return })
    ok(true, "enter key handler runs without error")
    UIS.GetFocusedTextBox = function() return nil end

    -- persisted bubbles come back on re-render (minimize / conv switch / re-exec)
    local Mm = NS.Memory
    local prevActive = Mm.index and Mm.index.active
    local cReplay = Mm.NewConversation("replay ui test")
    Mm.SetActive(cReplay.id)
    cReplay = Mm.Active()
    Mm.AppendMessage(cReplay, "user", "go")
    Mm.PushBubble({ k = "note", s = "» get_properties · Workspace.Vault.GoldCrate" })
    Mm.AppendMessage(cReplay, "assistant", "done")
    Mm.PushBubble({ k = "exec", s = "print(game.PlaceId)\n— output —\n123" })
    Mm.PushBubble({ k = "meta", s = "answered in 2.1s · 1 model round · 1 tool call" })
    Mm.SaveConversation(cReplay)
    U:RerenderChat()
    local rows = {}
    for _, ch in ipairs(U.chat:GetChildren()) do rows[#rows + 1] = ch end
    ok(#rows >= 5, "replay renders user+note+assistant+exec+meta rows (got " .. #rows .. ")")
    if prevActive then
        Mm.SetActive(prevActive)
        U:RerenderChat()
    end
end

------------------------------------------------------------------ persistence across "re-exec"
do
    -- simulate re-execute: wipe namespace memory refs, re-read from disk
    NS.Memory.activeConv = nil
    NS.Memory.index = nil
    NS.Memory.facts = nil
    NS.Memory.LoadIndex()
    NS.Memory.LoadFacts()
    local conv = NS.Memory.Active()
    ok(conv and conv.title ~= nil, "active conversation restored from disk after re-exec")
    local found = false
    for _, m in ipairs(conv.messages) do
        if m.content and type(m.content) == "string" and m.content:find("vault") then found = true end
    end
    ok(found or #conv.messages > 0, "messages survived re-exec (" .. #conv.messages .. " msgs)")
end

    ------------------------------------------------------------------ API cache management
    do
        local TT = NS.Tools
        local fakeCache = { version = "t", format = 2, enums = {}, classes = {
            Instance = {},
            Highlight = { sup = "Instance", p = { Enabled = "bool=true", FillColor = "Color3" } },
        } }
        TT.ResetBudget()
        TT.ApiDump.data = fakeCache
        TT.ApiDump.names = nil
        local prevGet, prevBase = NS.HTTP.Get, NS.Settings.Get("apiBase")
        local fetches = 0
        NS.HTTP.Get = function(u, h) fetches = fetches + 1; return { ok = false, status = 599, body = "" } end
        NS.Settings.Set("apiBase", "http://mock")
        NS.Settings.Set("apiDumpAt", os.time() - 3600)      -- one hour old: fresh
        NS.Settings.Set("apiDumpFailAt", 0)
        local warm = NS.JSON.Decode(TT.Execute("search_api", '{"class":"Highlight"}'))
        ok(warm.ok and fetches == 0, "fresh cache never re-downloads")
        NS.Settings.Set("apiDumpAt", os.time() - 8 * 86400) -- 8 days: expired
        local staleRun = NS.JSON.Decode(TT.Execute("search_api", '{"class":"Highlight"}'))
        ok(staleRun.ok and fetches == 1, "expired cache attempts exactly one refresh")
        ok(staleRun.ok == true, "failed refresh keeps serving the old cache (offline-safe)")
        ok((NS.Settings.Get("apiDumpFailAt") or 0) > 0, "refresh failure recorded for backoff")
        local again = NS.JSON.Decode(TT.Execute("search_api", '{"class":"Highlight"}'))
        ok(again.ok and fetches == 1, "backoff window: no repeat download on the next call")
        NS.HTTP.Get = prevGet
        NS.Settings.Set("apiBase", prevBase)
        -- a future format the client cannot parse must never replace the working cache
        NS.Settings.Set("apiBase", "")
        NS.Storage.Write("apidump.json", '{"format":99,"classes":{"Zzz":{}}}')
        TT.ApiDump.data = nil
        TT.ApiDump.names = nil
        local cold = NS.JSON.Decode(TT.Execute("search_api", '{"class":"Zzz"}'))
        ok(cold.ok == false, "unparseable future format is refused, never adopted from disk")
        NS.Storage.Delete("apidump.json")
        NS.Settings.Set("apiBase", prevBase)
    end

    ------------------------------------------------------------------ execution reliability gates
    do
        local T2 = NS.Tools
        local function run(code)
            return NS.JSON.Decode(T2.Execute("execute_code", NS.JSON.Encode({ code = code, timeout = 3 })))
        end
        T2.ResetBudget()
        ok(run("return 41 + 1").ok, "attempt 1 runs")
        local dupe = run("return 41  + 1") -- whitespace-reformatted identical
        ok(dupe.ok == false and tostring(dupe.error):find("identical", 1, true), "whitespace-identical retry blocked")
        ok(run("return 42").ok, "meaningfully different attempt 2 allowed")
        local allOk = true
        for i = 3, 8 do
            if not run("return " .. (100 + i)).ok then allOk = false end
        end
        ok(allOk, "budget is now 8 — attempts 3..8 all run")
        local ninth = run("return 999")
        ok(ninth.ok == false and tostring(ninth.error):find("spent", 1, true), "call past the budget refused with guidance")
        -- exec budget is separate from the general tool budget
        T2.ResetBudget()
        for _ = 1, 3 do T2.Execute("search_instances", '{"query":"x"}') end
        ok(T2.execLeft == 8, "general calls do not consume exec budget (and vice versa)")
        -- a failed exec with zero dictionary calls gets nudged toward validate_property
        T2.ResetBudget()
        local e1 = run("local x = nil; return x.y")
        ok(e1 and (e1.prefer ~= nil or e1.repeatError == true), "failure without API checks nudges validation first")
        T2.ResetBudget()
        ok(T2.execLeft == 8, "exec budget resets per message")
    end

    ------------------------------------------------------------------ editable exec budget (Settings stepper 1..32)
    do
        local T2 = NS.Tools
        local SS = NS.Settings
        local capSave = SS.Get("execMaxAttempts")
        local function run(code)
            return NS.JSON.Decode(T2.Execute("execute_code", NS.JSON.Encode({ code = code, timeout = 3 })))
        end
        eq(SS.ExecCap(), 8, "ExecCap default is 8")
        SS.Set("execMaxAttempts", 24)
        eq(SS.ExecCap(), 24, "ExecCap honours a raised value")
        SS.Set("execMaxAttempts", 300)
        eq(SS.ExecCap(), 32, "ExecCap clamps to the 32 ceiling")
        SS.Set("execMaxAttempts", "3")
        eq(SS.ExecCap(), 3, "string-typed settings value coerced, not rejected")
        SS.Set("execMaxAttempts", "junk")
        eq(SS.ExecCap(), 8, "unparseable value falls back to the default")
        SS.Set("execMaxAttempts", 0)
        eq(SS.ExecCap(), 1, "floor of 1 respected")
        -- the budget gate runs the edited number end-to-end, not just the display
        SS.Set("execMaxAttempts", 3)
        T2.ResetBudget()
        eq(T2.execLeft, 3, "ResetBudget seeds from ExecCap")
        local threeRan = run("return 1").ok and run("return 2").ok and run("return 3").ok
        ok(threeRan, "edited cap of 3 runs exactly 3 attempts")
        local fourth = run("return 4")
        ok(fourth.ok == false and tostring(fourth.error):find("spent", 1, true), "4th call capped at the edited 3")
        ok(tostring(fourth.error):find("3 attempts", 1, true), "spent note quotes the user's number, not the default")
        SS.Set("execMaxAttempts", 32)
        T2.ResetBudget()
        eq(T2.execLeft, 32, "ceiling 32 fully usable")
        SS.Set("execMaxAttempts", capSave)
        T2.ResetBudget()
    end

    ------------------------------------------------------------------ verified knowledge
    do
        local K = NS.Knowledge
        local M = NS.Memory
        local prevActive = M.index and M.index.active
        K.entries = {}
        local run = function(name, t) return NS.JSON.Decode(NS.Tools.Execute(name, NS.JSON.Encode(t))) end
        local saved = run("save_knowledge", { problem = "highlight everyone in the server",
            solution = "create a Highlight per player with Adornee set", verified = true })
        ok(saved.ok and saved.status == "unverified", "verified claim without tool evidence is downgraded")
        ok(saved.note:find("successful tool result", 1, true), "downgrade explained to the model")
        local rec = run("recall_knowledge", { query = "highlight everyone in a server" })
        ok(rec.ok and rec.total == 1 and rec.hits[1].status == "unverified"
            and rec.note:find("UNVERIFIED", 1, true), "recall returns the lead with its caveat")
        local c = M.NewConversation("kn evidence")
        M.SetActive(c.id)
        c = M.Active()
        M.AppendMessage(c, "user", "do it")
        M.AppendMessage(c, "tool", '{"ok":true,"tool":"execute_code","output":"done"}',
            { tool_call_id = "x1", tool_name = "execute_code" })
        local upd = run("save_knowledge", { id = saved.knowledge, problem = "highlight everyone in the server",
            solution = "create a Highlight per player; FillColor (not FillColor3) is current",
            api = { "Highlight.FillColor (Color3)" }, verified = true })
        ok(upd.ok and upd.status == "verified" and upd.updated, "same evidence-backed turn verifies the update in place")
        local ctx = K.ContextFor("how do I highlight everyone")
        ok(ctx and ctx:find("[verified", 1, true) and ctx:find("Re-validate", 1, true),
            "knowledge context injects verified tag + caution line")
        local ctxOff = K.ContextFor("quantum flux capacitor calibration")
        ok(ctxOff == nil, "unrelated questions get no knowledge noise (no forced context)")
        local inv = run("invalidate_knowledge", { id = saved.knowledge, reason = "FillColor was renamed again" })
        ok(inv.ok and inv.voided == saved.knowledge, "invalidate by id")
        local gone = run("recall_knowledge", { query = "highlight everyone in a server" })
        eq(gone.total, 0, "voided entries stop being recalled (kept for audit only)")
        local miss = run("invalidate_knowledge", { id = "k-nope" })
        ok(miss.ok == false and miss.error:find("no knowledge entry"), "unknown id refused cleanly")
        -- auto-capture: only after a successful, tool-backed turn
        K.entries = {}
        local cap = K.AutoCapture("what is my ping", "Ping comes from Stats.Network.ServerStatsItem Data Ping, confirmed live: 42ms")
        ok(cap and cap.status == "verified" and cap.source == "auto", "auto-capture records successful discoveries")
        local dupeCap = K.AutoCapture("what is my ping now", "Ping comes from Stats service Data Ping, confirmed live: 42ms")
        ok(dupeCap and #K.entries == 1, "similar auto-captures update instead of duplicating")
        if prevActive then M.SetActive(prevActive) end
        K.entries = {}
        NS.Storage.Delete("knowledge.json")
    end

------------------------------------------------------------------ settings: tool budget + migration
do
    local function reload() NS.Settings.Init(); return NS.Settings.Get("maxToolRounds") end
    eq(NS.Settings.Get("maxToolRounds"), 20, "tool budget default is 20 now")
    NS.Storage.Write("settings.json", '{"maxToolRounds":8,"device":"d1"}')
    eq(reload(), 20, "devices that persisted the old default 8 get bumped to 20 once")
    NS.Storage.Write("settings.json", '{"maxToolRounds":8,"trBumped":true,"device":"d1"}')
    eq(reload(), 8, "a deliberate 8 (after bump flag) is respected, not re-raised")
    NS.Storage.Write("settings.json", '{"maxToolRounds":5,"device":"d1"}')
    eq(reload(), 5, "any other user value is untouched")
    eq(NS.Settings.Get("execMaxAttempts"), 8, "exec default is 8")
    NS.Storage.Write("settings.json", '{"execMaxAttempts":2,"device":"d1"}')
    reload()
    eq(NS.Settings.Get("execMaxAttempts"), 8, "stale persisted exec cap of 2 is bumped to 8 once (the bug users hit)")
    NS.Storage.Write("settings.json", '{"execMaxAttempts":2,"execBumped":true,"device":"d1"}')
    reload()
    eq(NS.Settings.Get("execMaxAttempts"), 2, "a deliberate 2 after the bump flag is respected")
    NS.Storage.Delete("settings.json")
    NS.Settings.Init()
    NS.Settings.Set("apiKey", "test-key-123")
end

------------------------------------------------------------------ filesystem tools
do
    local T = NS.Tools
    local fs = { files = {}, dirs = { } }
    local function norm(x) x = tostring(x):gsub("\\", "/"):gsub("/+$", ""); return x end
    local function install()
        _G.readfile = function(path)
            local k = norm(path)
            if fs.files[k] == nil then error("no such file: " .. k) end
            return fs.files[k]
        end
        _G.writefile = function(path, content)
            local k = norm(path)
            local parent = k:match("^(.+)/[^/]+$")
            if parent and parent ~= "" and not fs.dirs[parent] then error("missing parent dir") end
            fs.files[k] = tostring(content)
        end
        _G.appendfile = function(path, content)
            local k = norm(path)
            if fs.files[k] == nil then error("no such file") end
            fs.files[k] = fs.files[k] .. tostring(content)
        end
        _G.listfiles = function(path)
            local k = norm(path)
            local out = {}
            for name in pairs(fs.files) do
                local par = name:match("^(.*)/[^/]+$") or ""
                if par == k then out[#out + 1] = { absolute_path = "/exec/workspace/" .. name, isFolder = false } end
            end
            for name in pairs(fs.dirs) do
                local par = name:match("^(.*)/[^/]+$") or ""
                if par == k then out[#out + 1] = { absolute_path = "/exec/workspace/" .. name, isFolder = true } end
            end
            return out
        end
        _G.isfile = function(path) return fs.files[norm(path)] ~= nil end
        _G.isfolder = function(path) local k = norm(path) if k == "" then return true end return fs.dirs[k] ~= nil end
        _G.makefolder = function(path)
            local k = norm(path)
            if fs.files[k] then error("a file owns that name") end
            local parent = k:match("^(.+)/[^/]+$")
            if parent and parent ~= "" and not fs.dirs[parent] then error("parent missing") end
            fs.dirs[k] = true
        end
        _G.delfile = function(path)
            local k = norm(path)
            if fs.files[k] == nil then error("no such file") end
            fs.files[k] = nil
        end
        _G.delfolder = function(path)
            local k = norm(path)
            if fs.dirs[k] == nil then error("no such dir") end
            fs.dirs[k] = nil
        end
    end
    local function uninstall()
        for _, n in ipairs({ "readfile", "writefile", "appendfile", "listfiles", "isfile", "isfolder", "makefolder", "delfile", "delfolder" }) do
            _G[n] = nil
        end
    end
    install()
    T.FsCaps(true)

    local function run(name, t) return NS.JSON.Decode(T.Execute(name, NS.JSON.Encode(t))) end

    ok((function() local c = T.FsCaps() return c.any and c.readfile == "readfile" end)(), "adapter probes real globals through the env chain")

    -- folders
    local r = run("is_folder", { path = "" })
    ok(r.ok and r.is_folder and r.root, "root folder exists")
    r = run("is_folder", { path = "src" })
    ok(r.ok and r.exists == false, "missing folder reports exists=false (not an error)")
    r = run("create_folder", { path = "src" })
    ok(r.ok and r.created == true, "create_folder creates")
    r = run("create_folder", { path = "src" })
    ok(r.ok and (r.created ~= true), "create_folder idempotent (created=false when present)")
    r = run("is_folder", { path = "src" })
    ok(r.exists == true, "folder visible after create")

    -- write / overwrite guard / read
    r = run("write_file", { path = "a/b/c.lua", content = "print(1)\nprint(2)\nprint(3)" })
    ok(r.ok and r.created and r.verified == "byte-identical", "write_file auto-creates parents and verifies readback")
    r = run("write_file", { path = "a/b/c.lua", content = "clobbered" })
    ok(r.ok == false and r.existing == true and r.error:find("overwrite"), "no silent overwrite: refused with existing:true")
    r = run("write_file", { path = "a/b/c.lua", content = "print(1)\nprint(2)\nprint(3)", overwrite = true })
    ok(r.ok and r.created ~= true, "overwrite:true replaces deliberately")
    r = run("read_file", { path = "a/b/c.lua" })
    ok(r.ok and r.content == "print(1)\nprint(2)\nprint(3)" and r.bytes == 26 and r.total_lines == 3, "read_file round-trips content + stats")
    r = run("read_file", { path = "a/b/c.lua", offset_line = 2, max_lines = 1 })
    ok(r.ok and r.content == "print(2)" and r.first_line == 2, "offset_line pages through files")
    r = run("read_file", { path = "nowhere.lua" })
    ok(r.ok == false and r.exists == false, "missing file: honest exists=false, no crash")
    fs.files["empty.lua"] = ""
    r = run("read_file", { path = "empty.lua" })
    ok(r.ok and r.bytes == 0, "empty file reads clean")
    fs.files["big.lua"] = string.rep("line of code here\n", 2000)
    r = run("read_file", { path = "big.lua" })
    ok(r.ok and r.bytes == 2000 * 18 and r.truncated == true and #r.content <= 8100, "huge files are capped, never dumped whole")
    r = run("get_file_info", { path = "a/b/c.lua" })
    ok(r.ok and r.kind == "file" and r.size_bytes == 26 and r.lines == 3, "get_file_info stats (file)")
    r = run("get_file_info", { path = "src" })
    ok(r.ok and r.kind == "folder", "get_file_info stats (folder)")
    r = run("get_file_info", { path = "ghost" })
    ok(r.ok and r.kind == "missing", "get_file_info missing")

    -- append
    r = run("append_file", { path = "src/log.lua", content = "x" })
    ok(r.ok and r.created == true and fs.files["src/log.lua"] == "x", "append creates missing files")
    r = run("append_file", { path = "src/log.lua", content = "y" })
    ok(r.ok and fs.files["src/log.lua"] == "xy" and r.method == "appendfile", "append uses the native global")

    -- listing
    r = run("get_files_in_folder", { path = "src" })
    ok(r.ok and r.total == 1 and r.items[1].name == "log.lua", "get_files_in_folder lists children")
    r = run("get_files_in_folder", { path = "" })
    local sawDir
    for _, it in ipairs(r.items or {}) do if it.name == "src" and it.folder then sawDir = true end end
    ok(sawDir, "root listing marks folders (isFolder normalised)")
    r = run("get_folder", { path = "src" })
    ok(r.ok and r.files == 1 and r.listable, "get_folder counts entries")

    -- search
    fs.files["src/Main.client.lua"] = "local hp = 5\nprint('hello project')\n"
    r = run("search_files", { pattern = "*.lua", folder = "src" })
    ok(r.ok and r.total_matches == 2, "name glob search finds .lua files under a folder")
    r = run("search_files", { pattern = "hello project", with_content = true })
    ok(r.ok and r.total_matches >= 1 and r.items[1].hits[1]:find("L2:") == 1, "content search returns path + L<n> hit")
    r = run("search_files", { pattern = "zz-nothing-zz" })
    ok(r.ok and r.total_matches == 0, "no match is zero results, not an error")
    r = run("search_files", {})
    ok(r.ok == false, "search without pattern/content refuses")

    -- copy / move
    r = run("copy_file", { source = "src/Main.client.lua", destination = "src/Main.backup.lua" })
    ok(r.ok and fs.files["src/Main.backup.lua"] == fs.files["src/Main.client.lua"], "copy_file duplicates + verifies")
    r = run("copy_file", { source = "src/Main.client.lua", destination = "src/Main.backup.lua" })
    ok(r.ok == false and r.existing == true, "copy refuses existing destination without overwrite")
    r = run("move_file", { source = "src/Main.backup.lua", destination = "src/Main.moved.lua" })
    ok(r.ok and fs.files["src/Main.backup.lua"] == nil and fs.files["src/Main.moved.lua"], "move verifies dest BEFORE removing source")
    r = run("move_file", { source = "src/Main.backup.lua", destination = "src/x.lua" })
    ok(r.ok == false, "move of missing source refuses")

    -- delete + confirm gate
    r = run("delete_file", { path = "src/log.lua" })
    ok(r.ok == false and r.needs_confirm == true and fs.files["src/log.lua"] == "xy", "delete without confirm changes NOTHING")
    r = run("delete_file", { path = "src/log.lua", confirm = true })
    ok(r.ok and r.deleted and fs.files["src/log.lua"] == nil, "delete with confirm removes")
    r = run("delete_file", { path = "src", confirm = true })
    ok(r.ok == false and r.error:find("folder"), "folder deletion refused by design")

    -- safety guards
    for _, bad in ipairs({ "../escape.lua", "/etc/passwd", "C:/Windows/x", "Max/settings.json", "api_key.txt", "secrets.env" }) do
        r = run("read_file", { path = bad })
        ok(r.ok == false and r.refused == nil, "refused: " .. bad .. " (" .. (r.error or ""):sub(1, 42) .. ")")
    end

    -- capability honesty: no globals at all
    uninstall()
    T.FsCaps(true)
    r = run("read_file", { path = "a/b/c.lua" })
    ok(r.ok == false and r.error:find("no filesystem globals"), "missing executor functions -> honest capability error")
    r = run("write_file", { path = "x", content = "y" })
    ok(r.ok == false, "writes refuse too, nothing faked")
    -- partial env: write but no read
    fs.files["solo.lua"] = "one"
    _G.writefile = function(path, content) fs.files[norm(path)] = tostring(content) end
    _G.isfile = function(path) return fs.files[norm(path)] ~= nil end
    _G.isfolder = function() return false end
    T.FsCaps(true)
    r = run("write_file", { path = "solo.lua", content = "two", overwrite = true })
    ok(r.ok and r.verified:find("unverified"), "no readfile -> says 'unverified', never 'byte-identical'")

    -- budgets: inspection free, mutation counted
    install()
    T.FsCaps(true)
    T.ResetBudget()
    local b0 = T.budgetLeft
    run("read_file", { path = "a/b/c.lua" })
    run("search_files", { pattern = "Main" })
    run("get_files_in_folder", { path = "src" })
    eq(T.budgetLeft, b0, "fs INSPECTION tools are budget-free like reference tools")
    run("write_file", { path = "src/t.lua", content = "z" })
    eq(T.budgetLeft, b0 - 1, "fs MUTATION costs one budget point")

    -- defs wiring
    ok(T.Names.search_files == true and T.Names.get_folder == true, "fs tools registered in the dispatch name set")
    local unknown = NS.JSON.Decode(T.Execute("list_directory", "{}"))
    ok(unknown.ok == false and unknown.error == "unknown tool", "unlisted fs-ish names still refuse")

    uninstall()
    T.FsCaps(true)
end

------------------------------------------------------------------ empty-bubble regression
do
    local UI = NS.UI
    local before = #UI.rows
    UI:AddBubble("assistant", "   \n\n \t  ")
    eq(#UI.rows, before, "whitespace-only model text renders NO giant bubble")
    UI:AddBubble("assistant", "")
    eq(#UI.rows, before, "empty string renders no bubble")
    UI:AddBubble("assistant", "  real reply  ")
    eq(#UI.rows, before + 1, "padded real text still renders exactly one bubble")
end


------------------------------------------------------------------ R16: decompile + terminal + web
do
    local T = NS.Tools
    local sendLog = {}
    local realSend = NS.HTTP.Send
    local replyFn = nil
    local function stubSend(resp)
        NS.HTTP.Send = function(opts)
            sendLog[#sendLog + 1] = opts
            local body = NS.JSON.Decode(opts.body) or {}
            if replyFn then
                local r = replyFn(opts.url, body)
                return { ok = true, status = r and r.status or 200, body = NS.JSON.Encode((r and r.body) or { ok = true }) }
            end
            return { ok = true, status = 200, body = opts and NS.JSON.Encode({ ok = true, echo = body }) }
        end
    end
    local function unstub() NS.HTTP.Send = realSend end
    local function lastBody() local o = sendLog[#sendLog]; if not o then return nil end; return NS.JSON.Decode(o.body) end
    local function jexec(name, js)
        T.ResetBudget()
        return NS.JSON.Decode(T.Execute(name, js))
    end
    local okRealGetgenv = rawget(_G, "getgenv")
    local function tc(name, fn)
        local okr, err = pcall(fn)
        ok(okr, name .. (not okr and (" — " .. tostring(err):sub(1, 220)) or ""))
    end

    tc("r16 defs wired", function()
        for _, n in ipairs({ "decompile_script", "terminal_execute", "terminal_get_environment",
                             "web_search", "web_open", "search_api_reference", "terminal_check_dependency" }) do
            assert(T.Names[n], "missing " .. n)
        end
        local d = 0
        for _ in pairs(T.Names) do d = d + 1 end
        assert(d == #T.Defs, "names/defs count match")
    end)

    -- decompile_script
    local realResolve = NS.Inspect.ResolvePath
    tc("decompile: bad path honest fail", function()
        NS.Inspect.ResolvePath = function() return nil, "no Instance at that path — re-derive it from search results" end
        local r = jexec("decompile_script", '{"path":"Nope"}')
        assert(r.ok == false and r.status == "FAILED" and r.error:find("re%-derive"), NS.JSON.Encode(r))
    end)
    tc("decompile: class gate (RemoteEvent refused)", function()
        NS.Inspect.ResolvePath = function() return { ClassName = "RemoteEvent" } end
        local r = jexec("decompile_script", '{"path":"x"}')
        assert(r.ok == false and r.class == "RemoteEvent" and r.error:find("only LocalScript and ModuleScript"), NS.JSON.Encode(r))
    end)
    tc("decompile: refuses without executor global", function()
        NS.Inspect.ResolvePath = function() return { ClassName = "LocalScript" } end
        rawset(_G, "decompile", nil); rawset(_G, "decompilescript", nil); rawset(_G, "getscriptsource", nil)
        local r = jexec("decompile_script", '{"path":"x"}')
        assert(r.ok == false and r.status == "FAILED" and r.error:find("no decompile"), NS.JSON.Encode(r))
    end)
    tc("decompile: empty output = UNKNOWN, never fabricated", function()
        rawset(_G, "decompile", function() return "   \n\n " end)
        local r = jexec("decompile_script", '{"path":"x"}')
        assert(r.ok == false and r.error:find("no source") and r.error:find("UNKNOWN"), NS.JSON.Encode(r))
        rawset(_G, "decompile", error)
        r = jexec("decompile_script", '{"path":"x"}')
        assert(r.ok == false and r.error:find("decompiler errored"), NS.JSON.Encode(r))
    end)
    tc("decompile: full read, slicing, no silent truncation", function()
        local src = {}
        for i = 1, 300 do src[i] = "line" .. i end
        src = table.concat(src, "\n")
        rawset(_G, "decompile", function() return src end)
        local r = jexec("decompile_script", '{"path":"ReplicatedStorage.Mod"}')
        assert(r.ok and r.class == "LocalScript" == false or r.ok, NS.JSON.Encode(r))
        NS.Inspect.ResolvePath = function() return { ClassName = "ModuleScript" } end
        r = jexec("decompile_script", '{"path":"ReplicatedStorage.Mod"}')
        assert(r.ok and r.status == "DECOMPILED" and r.total_lines == 300, NS.JSON.Encode(r))
        assert(r.truncated and r.next_hint:find("offset_line=181"), "slices at 180 by default")
        local r2 = jexec("decompile_script", '{"path":"x","offset_line":181}')
        assert(r2.ok and r2.first_line == 181 and r2.lines_returned == 120 and not r2.truncated, NS.JSON.Encode(r2))
        assert(r2.content:find("line181", 1, true) and r2.content:find("line300", 1, true), "slice content exact")
        local r3 = jexec("decompile_script", '{"path":"x","offset_line":9999}')
        assert(r3.ok == false and r3.error:find("beyond the end"), "past EOF honest")
        local r4 = jexec("decompile_script", '{"path":"x","max_lines":20,"offset_line":1}')
        assert(r4.lines_returned == 20 and r4.next_hint:find("offset_line=21", 1, true), "max_lines respected")
        assert(r.evidence_note and r.evidence_note:find("not proof"), "evidence framing present")
    end)
    NS.Inspect.ResolvePath = realResolve
    rawset(_G, "decompile", nil)

    -- TermCall plumbing
    tc("terminal dispatch: endpoint + pinned ops + engine-wins over args", function()
        stubSend()
        jexec("terminal_list_files", '{"path":"projects","limit":10}')
        local b = lastBody()
        assert(b.ep == "/fs" and b.args.op == "list" and b.args.path == "projects", NS.JSON.Encode(b))
        jexec("terminal_read_file", '{"path":"a","op":"delete"}')  -- model must not forge ops
        b = lastBody()
        assert(b.ep == "/fs" and b.args.op == "read", "engine-pinned op wins: " .. NS.JSON.Encode(b))
        jexec("terminal_kill_process", '{"id":"p2"}')
        b = lastBody()
        assert(b.ep == "/proc" and b.args.op == "kill" and b.args.id == "p2", NS.JSON.Encode(b))
        jexec("terminal_get_environment", '{}')
        assert(lastBody().ep == "/manifest", "manifest ep")
        unstub()
    end)
    tc("terminal: offline + auth wiring honest", function()
        NS.HTTP.Send = function() return { ok = false, status = 0, err = "connection refused" } end
        local r = jexec("terminal_get_cwd", "{}")
        assert(r.ok == false and r.offline, NS.JSON.Encode(r))
        local realGet = NS.Settings.Get
        NS.Settings.Get = function(k) if k == "apiBase" then return "" end return realGet(k) end
        r = jexec("terminal_get_cwd", "{}")
        assert(r.ok == false and r.error:find("apiBase"), NS.JSON.Encode(r))
        NS.Settings.Get = realGet
        unstub()
    end)
    tc("terminal: budget — reads free, writes/execs counted", function()
        stubSend()
        T.budgetLeft = 0
        local r = jexec("terminal_get_storage_usage", "{}")
        assert(r.ok == true, "usage view is budget-free: " .. NS.JSON.Encode(r))
        r = jexec("search_api_reference", '{"class":"Turtle"}')
        assert(r.ok ~= nil, "api alias budget-free")
        T.budgetLeft = 0
        local out = NS.JSON.Decode(T.Execute("terminal_execute", '{"cmd":"ls"}'))
        assert(out.ok == false and out.error:find("budget"), "counted tools still respect the budget")
        unstub()
    end)
    tc("run_python/run_node: heredoc, guards, file mode", function()
        stubSend()
        jexec("terminal_run_python", '{"code":"print(42)"}')
        local b = lastBody()
        assert(b.ep == "/exec" and b.args.cmd:find("python3 %- <<'MAXEND_9_EOF'", 0) and b.args.cmd:find("print(42)", 1, true), NS.JSON.Encode(b))
        jexec("terminal_run_node", '{"code":"console.log(1)"}')
        b = lastBody()
        assert(b.args.cmd:find("node %- <<", 0), "node via stdin")
        local r = jexec("terminal_run_python", '{"code":"x","file":"a.py"}')
        assert(r.ok == false and r.error:find("not both"), "file XOR code")
        r = jexec("terminal_run_python", '{"file":"../../etc/passwd"}')
        assert(r.ok == false and r.error:find("clean workspace%-relative"), "path jail mirrored client-side")
        r = jexec("terminal_run_python", '{"file":"projects/run.py"}')
        b = lastBody()
        assert(b.args.cmd == "python3 'projects/run.py'", NS.JSON.Encode(b))
        unstub()
    end)
    tc("install refreshes the env manifest + echo contract", function()
        local manifestHits = 0
        NS.HTTP.Send = function(opts)
            local body = NS.JSON.Decode(opts.body) or {}
            if body.ep == "/manifest" then
                manifestHits = manifestHits + 1
                return { ok = true, status = 200, body = NS.JSON.Encode({ ok = true, os = "linux", arch = "x86_64", python = "3.11.2", git = "git 2.39",
                    limits = { quota_mb = 300, exec_timeout_s = { 1, 300 }, max_procs = 8 },
                    usage = { pct_used = 12.5, files = 40 }, installed = { pip = { "rich==13.7.1" }, npm = {} },
                    utilities = { curl = true, git = true } }) }
            end
            return { ok = true, status = 200, body = NS.JSON.Encode({ ok = true, manager = "pip", package = "rich==13.7.1", exit = 0, output_tail = "Successfully installed rich-13.7.1", usage = {} }) }
        end
        T.TermManifestData = nil
        local man = T.TermManifest(true)
        assert(type(man) == "string" and man:find("rich==13.7.1", 1, true) and man:find("quota=300MB hard", 0), tostring(man))
        local before = manifestHits
        local r = jexec("terminal_install_package", '{"package":"rich","version":"13.7.1"}')
        assert(r.ok and r.package == "rich==13.7.1", NS.JSON.Encode(r))  -- op merged + forwarded
        assert(manifestHits > before, "install triggers manifest refresh")
        local sys = NS.API.BuildSystemPrompt("hi", { summary = nil })
        assert(sys:find("LIVE manifest", 1, true) and sys:find("rich==13.7.1", 1, true), "manifest injected into prompt")
        unstub()
    end)

    -- web
    tc("web_search/web_open routed to backend, validated client-side", function()
        stubSend()
        local r = jexec("web_search", '{"query":"Highlight FillColor3","domains":["create.roblox.com","../etc"],"days":7}')
        local b = lastBody()
        assert(r.ok, NS.JSON.Encode(r))
        assert(b.action == "search" and b.query == "Highlight FillColor3", NS.JSON.Encode(b))
        assert(b.domains and #b.domains == 1 and b.domains[1] == "create.roblox.com", "junk domain dropped, valid kept")
        assert(b.days == 7, "days forwarded")
        assert(sendLog[#sendLog].url:find("/v1/max/web$", 0), "web endpoint path")
        r = jexec("web_search", '{"query":"ab"}')
        assert(r.ok == false and r.error:find("at least 3", 1, true), "tiny query blocked before network")
        r = jexec("web_open", '{}')
        assert(r.ok == false and r.error:find("url required", 1, true), "open needs url")
        r = jexec("web_open", '{"url":"ftp://evil"}')
        assert(r.ok == false and r.error:find("http", 1, true), "non-http refused client-side")
        jexec("web_open", '{"url":"https://create.roblox.com/docs/reference/engine/classes/Highlight"}')
        assert(lastBody().action == "open" and lastBody().url:find("Highlight", 1, true), "open forwarded")
        unstub()
    end)

    -- search_api_reference alias parity
    tc("search_api_reference aliases the dictionary", function()
        local realData = T.ApiDump.data
        T.ApiDump.data = { classes = { Highlight = { members = { FillColor = { kind = "property", type = "Color3" },
                                                                Highlighting = { kind = "property", type = "bool" } } } } }
        T.budgetLeft = 0
        local r = NS.JSON.Decode(T.Execute("search_api_reference", '{"class":"Highlight"}'))
        assert(r.ok == true and r.class == "Highlight" and r.kind == "class", NS.JSON.Encode(r))
        T.budgetLeft = 0
        local r2 = NS.JSON.Decode(T.Execute("search_api", '{"class":"Highlight"}'))
        r.tool, r2.tool = nil, nil
        assert(NS.JSON.Encode(r) == NS.JSON.Encode(r2), "alias output identical to search_api")
        T.budgetLeft = 3
        NS.JSON.Decode(T.Execute("search_api_reference", '{"member":"FillColor"}'))
        assert(T.budgetLeft == 3, "alias stays budget-free")
        T.ApiDump.data = realData
    end)

    if okRealGetgenv then rawset(_G, "getgenv", okRealGetgenv) end
    print("r16 tool blocks complete")
end


------------------------------------------------------------------ R17: intent lock, verdicts, wipe
do
    local A = NS.API
    local function lock(s) return A.LockIntent(s) end

    do -- spec-mandated classification battery
        local it = lock("Make my localplayer character dance.")
        print("DBGlock:", it.kind, "|", it.target)
        ok(it.kind == "action" and it.target:find("LOCALPLAYER ONLY", 1, true), "dance: action on LOCALPLAYER only")
        it = lock("Highlight only LocalPlayer.")
        ok(it.kind == "action" and it.target:find("LOCALPLAYER ONLY", 1, true), "highlight-only-me stays about ME")
        it = lock("Highlight every player.")
        ok(it.kind == "action" and it.target:find("every player", 1, true), "highlight-everyone scope")
        it = lock("Make the red barrel in Workspace.Loot change colour.")
        ok(it.kind == "action" and it.target:find("named in the request", 1, true)
           and it.target:find("never substitute", 1, true), "object task: only that object")
        it = lock("Find the best computer and highlight it.")
        ok(it.kind == "action" and it.ambiguous and it.ambiguous:find("criterion", 1, true), "'best' forces criteria/clarify")
        it = lock("Tell me how to make my character dance.")
        ok(it.kind == "info", "how-to is info — no forced execution")
        it = lock("Write a script that makes my character dance, but don't execute it.")
        ok(it.kind == "codegen" and it.noExec, "codegen+noExec")
        it = lock("continue")
        ok(it.kind == "followup", "continue=followup")
        it = lock("What is this game about?")
        ok(it.kind == "info", "plain question=info")
        it = lock("Highlight every player except the ones on team Red.")
        ok(it.kind == "action" and it.target:find("every player", 1, true), "negated-subset still all-players base scope")
    end

    do -- task reconciliation: stale checklists must not hijack new objectives
        local conv = { task = { obj = "highlight players", items = { "[ ] go" } } }
        ok(A.ReconcileTask(conv, lock("Make my localplayer character dance."), "Make my localplayer character dance.") == "reset"
           and conv.task == nil, "new objective clears old task")
        conv.task = { obj = "x", items = { "[ ] y" } }
        ok(A.ReconcileTask(conv, lock("still broken, you didn't fix it"), "still broken, you didn't fix it") == "kept"
           and conv.task ~= nil, "correction keeps task")
        ok(A.ReconcileTask(conv, lock("Also print the ping"), "Also print the ping") == "kept", "add-on keeps task")
        ok(A.ReconcileTask(conv, lock("continue"), "continue") == "kept", "followup keeps task")
        conv.task = { obj = nil, items = {} }
        ok(A.ReconcileTask(conv, lock("What is this game about?"), "What is this game about?") == "kept", "info + empty task: no-op")
    end

    do -- verdict matrix (the anti-fabrication core)
        local act = { kind = "action", target = "LOCALPLAYER ONLY", source = "s" }
        local v = A.TurnVerdict(act, { acted = false, actOk = false, readAfter = false },
            "I've highlighted all players: Green = Beast, Red = Survivors")
        ok(v.force and v.note and v.note:find("NOT EXECUTED", 1, true), "tool-less claim bounces + would be flagged")
        local q = A.TurnVerdict(act, { acted = false, actOk = false, readAfter = false },
            "Which action did you mean? Nothing is running right now.")
        ok(q.force == nil and q.note == nil, "clarifying question is the accepted honest move")
        v = A.TurnVerdict(act, { acted = true, actOk = true, readAfter = false }, "Done — everything works!")
        ok(v.force and v.force:find("VERIFY", 1, true), "success claim without read-back forces verification")
        v = A.TurnVerdict(act, { acted = true, actOk = true, readAfter = true }, "Done — read back: Highlight present")
        ok(v.force == nil and v.chip == " · ✓ read back", "observed state accepted")
        v = A.TurnVerdict(act, { acted = true, actOk = false, readAfter = false }, "Done! It works")
        ok(v.force and v.force:find("FAILED", 1, true), "errored action may not claim success")
        v = A.TurnVerdict({ kind = "info" }, { acted = false, actOk = false, readAfter = false }, "You would use Animator:LoadAnimation")
        ok(v.force == nil and v.note == nil, "info answers never gated")
        v = A.TurnVerdict({ kind = "codegen", noExec = true }, { acted = false, actOk = false, readAfter = false },
            "Here is the script. I ran it for you.")
        ok(v.note and v.note:find("code-only", 1, true), "codegen claiming execution gets flagged")
        local g = A.ExecGate({ kind = "codegen", noExec = true }, "execute_code")
        ok(g and g:find("CODE-ONLY", 1, true), "noExec gate blocks execute_code")
        ok(A.ExecGate({ kind = "codegen", noExec = true }, "search_api") == nil, "gate leaves reads alone")
        ok(A.ExecGate({ kind = "action" }, "execute_code") == nil, "gate open for action requests")
    end

    do -- prompt injection: the lock rides every model round of the message
        local conv = { intent = lock("Make my localplayer character dance.") }
        local sys = NS.API.BuildSystemPrompt("Make my localplayer character dance.", conv)
        ok(sys:find("INTENT LOCK", 1, true) and sys:find("LOCALPLAYER ONLY", 1, true), "lock injected")
        ok(sys:find("overrides any older task", 1, true), "lock declared override of stale context")
        conv = { intent = lock("Write me a script for that, don't execute it") }
        sys = NS.API.BuildSystemPrompt("x", conv)
        ok(sys:find("FORBADE executing", 1, true), "no-exec stated in prompt")
    end

    do -- wipe gap: knowledge store must die with everything else
        local K = NS.Knowledge
        K.Add({ problem = "zeta probe entry", solution = "alpha marker" })
        ok(#K.entries >= 1, "knowledge seeded")
        K.ClearAll()
        ok(#K.entries == 0, "knowledge entries cleared")
        local d = NS.Storage.LoadJson(K.file)
        ok(d == nil or d.entries == nil or #d.entries == 0, "knowledge FILE wiped (survives reboot = gone)")
        local c = NS.Knowledge.ContextFor("zeta probe")
        ok(c == nil or c == "" or not c:find("alpha marker", 1, true), "wiped knowledge no longer injected")
    end

    do -- E2E: fabricated completion bounces; the retried turn executes for real
        local savedMode, savedQueue = http.mode, http.chatQueue
        local fresh = NS.Memory.NewConversation()
        NS.Memory.activeConv = fresh
        http.mode = "syn-ok"
        http.chatQueue = {
            '{"choices":[{"message":{"content":"I\'ve highlighted every player already, all done!"}}]}',
            '{"choices":[{"message":{"content":null,"tool_calls":[{"id":"c1","type":"function","function":{"name":"terminal_write_file","arguments":"{\\"path\\":\\"a.txt\\",\\"content\\":\\"x\\"}"}}]}}]}',
            '{"choices":[{"message":{"content":"Done — highlight applied and read back on my character only"}}]}',
        }
        NS.API.SendUserMessage("Highlight only LocalPlayer.")
        ok(#http.chatQueue == 0, "bounce round consumed a model call")
        local lastReq = http.lastChat
        local sawBounce = false
        for _, m in ipairs(lastReq and lastReq.messages or {}) do
            if type(m.content) == "string" and m.content:find("INTENT LOCK violation", 1, true) then sawBounce = true end
        end
        ok(sawBounce, "correction message injected into retry")
        local sawFabricated = false
        for _, m in ipairs(fresh.messages) do
            if m.role == "assistant" and type(m.content) == "string" and m.content:find("highlighted every player already", 1, true) then
                sawFabricated = true
            end
        end
        ok(not sawFabricated, "fabricated first answer never entered history")
        NS.Memory.activeConv = nil
        http.mode, http.chatQueue = savedMode, savedQueue
    end
    print("r17 blocks complete")
end

------------------------------------------------------------------ done
U = nil
NS.UI.alive = false
print(string.rep("=", 60))
print(("Max client tests: %d passed, %d failed"):format(pass, #fail))
for _, f in ipairs(fail) do print("  FAIL: " .. f) end
print(string.rep("=", 60))
os.exit(#fail == 0 and 0 or 1)
