--[[
    ██╗  ██╗ █████╗ ██████╗
    ██║  ██║██╔══██╗██╔══██╗   Max — AI assistant for Roblox executors
    ███████║███████║██████╔╝   Client v1.0.0  (Lua 5.1 / Luau compatible)
    ██╔══██║██╔══██║██╔══██╗
    ██║  ██║██║  ██║██║  ██║   Built to run inside executors, NOT Studio.
    ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝

    Everything attaches to the single global table `MaxNS` so we only ever
    touch one global name. Modules are concatenated by build.py in file-name
    order; each file expects `MaxNS` to exist.

    Hard guarantees:
      * Feature-detects every optional executor API; never assumes one exists.
      * Read-only Roblox inspection; Max never writes to the DataModel.
      * Conversations + long-term memory persist via writefile/readfile, so
        they survive re-execution, Roblox restarts, and device reboots.
      * All inference happens on your VPS (FreeLLMAPI via the Max backend);
        the client embeds no model and no provider keys.
]]

local maxDefaults = {
    Version = "1.0.0",
    Build = "2026-11-06",
    Name = "Max",
}
MaxNS = MaxNS or maxDefaults
for k, v in pairs(maxDefaults) do
    if MaxNS[k] == nil then MaxNS[k] = v end
end
local NS = MaxNS

NS.List = {}
if type(listfiles) == "function" then NS.List.Supported = true end

function NS.Spawn(fn, ...)
    if type(task) == "table" and type(task.spawn) == "function" then
        return task.spawn(fn, ...)
    elseif type(spawn) == "function" then
        return spawn(fn, ...)
    end
    return fn(...)
end

function NS.Wait(seconds)
    seconds = tonumber(seconds) or 0
    if type(task) == "table" and type(task.wait) == "function" then
        return task.wait(seconds)
    elseif type(wait) == "function" then
        return wait(seconds)
    elseif type(yield) == "function" then
        return yield(seconds)
    end
end

function NS.Warn(msg)
    pcall(function()
        print("[Max] " .. tostring(msg))
    end)
end

function NS.Try(fn, ...)
    local results = { pcall(fn, ...) }
    local ok = table.remove(results, 1)
    if ok then return true, unpack(results) end
    return false, results[1]
end

-- cloneref-aware service access
local cloneref = (type(cloneref) == "function") and cloneref or nil
NS.ServiceCache = {}
function NS.Service(name)
    local cached = NS.ServiceCache[name]
    if cached then return cached end
    local ok, svc = NS.Try(function()
        if cloneref then
            return cloneref(game:GetService(name))
        end
        return game:GetService(name)
    end)
    if ok and svc then
        NS.ServiceCache[name] = svc
        return svc
    end
    return nil
end
