--[[ Max GUI — one executor-built window that must feel right on a 6" phone
     AND a desktop monitor.

     Manual responsive layout driven by viewport size (mobile mode under
     720px), touch/mouse drag, tap targets >= 44px on mobile, measured
     rounded bubbles, sidebar that overlays on mobile / docks on desktop,
     tween animations where available (every call pcall-guarded), a floating
     reopen orb after minimise, and an in-window settings block for backend
     URL + key, so no secret ever lives in the script itself. ]]
local NS = MaxNS
local U = { alive = false, sidebarOpen = false, rows = {}, order = 0 }
NS.UI = U

------------------------------------------------------------------ theme
local C = {
    bg = Color3.fromRGB(9, 11, 20),        -- deep midnight
    panel = Color3.fromRGB(14, 17, 31),
    panel2 = Color3.fromRGB(22, 26, 45),
    stroke = Color3.fromRGB(47, 54, 84),
    text = Color3.fromRGB(225, 229, 245),
    dim = Color3.fromRGB(131, 139, 170),
    user = Color3.fromRGB(104, 96, 255),
    userText = Color3.fromRGB(246, 246, 255),
    max = Color3.fromRGB(26, 30, 51),
    ok = Color3.fromRGB(72, 214, 132),
    bad = Color3.fromRGB(240, 98, 104),
    warn = Color3.fromRGB(238, 180, 78),
    note = Color3.fromRGB(116, 124, 158),
}
U.Colors = C

local function new(cls, props, parent)
    local inst = Instance.new(cls)
    for k, v in pairs(props or {}) do
        if k ~= "Parent" then
            pcall(function() inst[k] = v end)
        end
    end
    if parent then inst.Parent = parent end
    return inst
end

local function corner(inst, r)
    return new("UICorner", { CornerRadius = UDim.new(0, r or 8) }, inst)
end
local function stroke(inst, color, t)
    return new("UIStroke", { Color = color or C.stroke, Thickness = t or 1, Transparency = 0.35 }, inst)
end
local function pad(inst, l, r, t, b)
    new("UIPadding", { PaddingLeft = UDim.new(0, l), PaddingRight = UDim.new(0, r or l),
                       PaddingTop = UDim.new(0, t or 0), PaddingBottom = UDim.new(0, b or t or 0) }, inst)
end
local function round(n) return math.floor(n + 0.5) end

-- Drawn vector icons from plain frames. Roblox's default fonts do NOT contain
-- glyphs like ✦ ☰ ✕ ➤ ▸ ◇ — on many executors they render as empty boxes,
-- which made the header look broken. Frames render identically everywhere.
local function icon(parent, kind, size, colr)
    local s = size or 14
    local t = math.max(2, math.floor(s / 7))
    local wrap = new("Frame", {
        Name = "Icon", BackgroundTransparency = 1, BorderSizePixel = 0,
        Size = UDim2.fromOffset(s + t * 2, s + t * 2),
        AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.new(0.5, 0, 0.5, 0),
    }, parent)
    local function bar(w, h, ox, oy, rot)
        local f = new("Frame", {
            Size = UDim2.fromOffset(w, h), BackgroundColor3 = colr, BorderSizePixel = 0,
            AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.new(0.5, ox, 0.5, oy),
            Rotation = rot or 0,
        }, wrap)
        corner(f, math.floor(h / 2))
        return f
    end
    if kind == "x" then
        bar(s + t, t, 0, 0, 45); bar(s + t, t, 0, 0, -45)
    elseif kind == "minus" then
        bar(s, t, 0, 0)
    elseif kind == "plus" then
        bar(s, t, 0, 0); bar(t, s, 0, 0)
    elseif kind == "menu" then
        bar(s, t, 0, -round(s * 0.3)); bar(s, t, 0, 0); bar(s, t, 0, round(s * 0.3))
    elseif kind == "square" then
        bar(s, t, 0, -round(s / 2)); bar(s, t, 0, round(s / 2))
        bar(t, s + t, -round(s / 2), 0); bar(t, s + t, round(s / 2), 0)
    elseif kind == "up" then
        bar(round(s * 0.75), t, -round(s * 0.16), round(s * 0.13), -45)
        bar(round(s * 0.75), t,  round(s * 0.16), round(s * 0.13), 45)
    elseif kind == "diamond" then
        local d = new("Frame", {
            Size = UDim2.fromOffset(s, s), BackgroundColor3 = colr, BorderSizePixel = 0,
            AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.new(0.5, 0, 0.5, 0), Rotation = 45,
        }, wrap)
        corner(d, math.floor(s * 0.24))
    end
    return wrap
end

local function tween(inst, props, dur)
    local ts = NS.Service("TweenService")
    if not ts then return end
    pcall(function()
        local ti = TweenInfo.new(dur or 0.16, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
        ts:Create(inst, ti, props):Play()
    end)
end

-- Manual frame-driven animation (no TweenService.Completed dependency):
-- calls step(u) each ~16ms with eased 0..1, then done(). Skipped in tests.
local function animate(dur, step, done)
    if NS.__TestMode then step(1) if done then done() end return end
    NS.Spawn(function()
        local t0 = os.clock()
        while U.alive do
            local u = (os.clock() - t0) / (dur or 0.2)
            if u >= 1 then step(1) if done then done() end return end
            step(u)
            NS.Wait(0.016)
        end
    end)
end

-- "AutomaticSize off" is spelled differently across Roblox client versions
-- (Default on some builds, None on others; indexing a missing member THROWS
-- "… is not a valid member of Enum.AutomaticSize", which is exactly the crash
-- mobile users saw). Resolve it defensively and use the instance default
-- (already "off") wherever possible instead.
local AS_NONE
do
    local function try(n)
        local ok, v = NS.Try(function() return Enum.AutomaticSize[n] end)
        return ok and v or nil
    end
    AS_NONE = try("Default") or try("None")
end

local function sanitize(s)
    s = tostring(s or "")
    s = s:gsub("%*%*", ""):gsub("`", "")
    s = s:gsub("^#+%s*", "")
    s = s:gsub("\n%s*[%*%-]%s+", "\n• ")
    s = s:gsub("[\r]", "")
    -- generous cap only (safety for stored history); long answers now scroll
    -- fully because every bubble reserves its true measured height
    if #s > 10000 then s = s:sub(1, 10000) .. "\n…[trimmed]" end
    return s
end

------------------------------------------------------------------ metrics
function U:GetViewport()
    local ok, size = NS.Try(function()
        local cam = workspace and workspace.CurrentCamera
        if cam then return cam.ViewportSize end
    end)
    if ok and size then return size end
    local ok2, m = NS.Try(function() return game.Players.LocalPlayer:GetMouse() end)
    if ok2 and m then return Vector2.new(m.Width, m.Height) end
    return Vector2.new(800, 600)
end

function U:Metrics()
    local vs = U:GetViewport()
    local forced = NS.Settings.Get("mobile")
    local mobile = (forced ~= nil and forced) or (vs and vs.X < 720) or false
    local M = {}
    M.mobile = mobile
    M.font = mobile and 17 or 15
    M.fontSmall = mobile and 13 or 11
    M.headerH = mobile and 52 or 42
    M.btn = mobile and 44 or 32
    M.inputH = mobile and 46 or 36
    M.gap = mobile and 8 or 6
    M.radius = mobile and 14 or 10
    M.bubblePad = mobile and 12 or 10
    if mobile then
        M.winW = math.min(vs.X - 12, 640)
        M.winH = math.min(vs.Y - 110, vs.Y * 0.86)
    else
        M.winW = math.min(math.max(560, vs.X * 0.44), 780)
        M.winH = math.min(vs.Y - 140, 620)
    end
    return M
end

------------------------------------------------------------------ build
function U:Build()
    local M = U:Metrics()
    U.mode = M.mobile and "mobile" or "desktop"
    U.alive = true

    local parentGui
    for _, fnName in ipairs({ "gethui", "get_hidden_gui" }) do
        local f = NS.Env.Fns[fnName]
        if f then
            local ok, res = NS.Try(f)
            if ok and res then parentGui = res break end
        end
    end
    if not parentGui then
        local cg = NS.Service("CoreGui")
        if cg then
            parentGui = cg
            NS.Warn("gethui/get_hidden_gui unavailable — using CoreGui (some executors block this; settings may fail silently)")
        end
    end
    if not parentGui then error("no GUI parent available") end

    local gui = new("ScreenGui", {
        Name = "MaxUI", ResetOnSpawn = false, IgnoreGuiInset = true,
        ZIndexBehavior = Enum.ZIndexBehavior.Sibling, DisplayOrder = 999,
    }, parentGui)
    U.gui = gui

    local window = new("Frame", {
        Name = "Window", Active = true, AnchorPoint = Vector2.new(0, 0),
        BackgroundColor3 = C.bg, Size = UDim2.fromOffset(M.winW, M.winH),
        Position = UDim2.fromOffset(round((U:GetViewport().X - M.winW) / 2), round((U:GetViewport().Y - M.winH) / 2)),
    }, gui)
    corner(window, M.radius)
    U.winStroke = stroke(window, C.stroke, 1.2)
    U.window = window

    ---------------------------------------------------------------- header
    local header = new("Frame", { Name = "Header", Size = UDim2.new(1, 0, 0, M.headerH), BackgroundColor3 = C.panel, BorderSizePixel = 0, ZIndex = 65 }, window)
    corner(header, M.radius)
    new("Frame", { Size = UDim2.new(1, 0, 0, M.radius + 1), Position = UDim2.new(0, 0, 1, -M.radius),
                   BackgroundColor3 = C.panel, BorderSizePixel = 0 }, header) -- square off bottom corners
    U.header = header

    new("Frame", { Name = "Hairline", Size = UDim2.new(1, 0, 0, 1), Position = UDim2.new(0, 0, 1, -1),
                   BackgroundColor3 = C.stroke, BackgroundTransparency = 0.45, BorderSizePixel = 0 }, header)

    U.statusDot = new("Frame", { Size = UDim2.fromOffset(9, 9), Position = UDim2.new(0, 14, 0.5, -4), BackgroundColor3 = C.warn, BorderSizePixel = 0 }, header)
    corner(U.statusDot, 5)
    local logo = new("Frame", { Name = "LogoSlot", BackgroundTransparency = 1, BorderSizePixel = 0,
                                Size = UDim2.fromOffset(18, 18), Position = UDim2.new(0, 30, 0.5, -9) }, header)
    icon(logo, "diamond", 14, C.user)
    new("TextLabel", {
        Text = "Max", Font = Enum.Font.GothamBold, TextSize = M.mobile and 19 or 16,
        TextColor3 = C.text, BackgroundTransparency = 1, Size = UDim2.fromOffset(46, M.headerH),
        Position = UDim2.new(0, 52, 0, 0), TextXAlignment = Enum.TextXAlignment.Left,
    }, header)
    U.diagLabel = new("TextLabel", {
        Text = "", Font = Enum.Font.GothamMedium, TextSize = M.fontSmall, TextColor3 = C.dim, BackgroundTransparency = 1,
        Size = UDim2.new(0, 300, 0, M.headerH), Position = UDim2.new(0, 102, 0, 0),
        TextXAlignment = Enum.TextXAlignment.Left, TextTruncate = Enum.TextTruncate.AtEnd,
    }, header)
    -- the chip lives in the gap between the title and the 5 buttons; if a
    -- narrow/mobile window leaves no room, it hides rather than colliding
    function U:FitDiag()
        if not U.diagLabel or not U.window then return end
        local Mb = U:Metrics()
        local winW = U.window.AbsoluteSize.X
        if not winW or winW <= 0 then winW = Mb.winW end
        local btnLeft = winW - ((Mb.btn + 8) * 4 + Mb.btn + 8)
        local gap = btnLeft - 106
        U.diagLabel.Size = UDim2.new(0, math.max(0, gap), 0, Mb.headerH)
        U.diagLabel.Visible = gap >= 64
    end
    U:FitDiag()

    local bx = M.btn
    local function hbtn(kind, cb, danger)
        local b = new("TextButton", {
            Text = "", BackgroundColor3 = C.panel2,
            Size = UDim2.fromOffset(bx, bx), BorderSizePixel = 0, AutoButtonColor = true,
        }, header)
        corner(b, 9)
        icon(b, kind, math.max(14, bx - 18), danger and C.bad or C.dim)
        b.MouseButton1Click:Connect(cb)
        return b
    end
    U.btnClose = hbtn("x", function() U:Destroy() end, true)
    U.btnMax  = hbtn("square", function() U:ToggleResize() end)
    U.btnMin  = hbtn("minus", function() U:SetVisible(false) end)
    U.btnSide = hbtn("menu", function() U:ToggleSidebar() end)
    U.btnNew  = hbtn("plus", function()
        NS.Memory.activeConv = NS.Memory.NewConversation()
        U:RebuildSidebar()
        U:RerenderChat()
    end)
    local function placeBtn(b, i)
        -- right-edge anchor: buttons pack from the right edge exactly; the old
        -- formula wasted a button-width and let the leftmost overlap the title
        b.AnchorPoint = Vector2.new(1, 0)
        b.Position = UDim2.new(1, -((bx + 8) * (i - 1) + 8), 0, round((M.headerH - bx) / 2))
    end
    placeBtn(U.btnClose, 1) placeBtn(U.btnMax, 2) placeBtn(U.btnMin, 3) placeBtn(U.btnSide, 4) placeBtn(U.btnNew, 5)

    ---------------------------------------------------------------- chat
    -- bottom margin = input row + the Task line's strip (24px); the old diag
    -- line above the textbox was removed entirely (header already shows model)
    local chat = new("ScrollingFrame", {
        Name = "Chat", BackgroundTransparency = 1, BorderSizePixel = 0,
        Size = UDim2.new(1, 0, 1, -(M.headerH + M.inputH + 28)),
        Position = UDim2.new(0, 0, 0, M.headerH),
        CanvasSize = UDim2.new(0, 0, 0, 0), AutomaticCanvasSize = Enum.AutomaticSize.Y,
        ScrollBarThickness = M.mobile and 3 or 6, ScrollingDirection = Enum.ScrollingDirection.Y,
    }, window)
    new("UIListLayout", { SortOrder = Enum.SortOrder.LayoutOrder, Padding = UDim.new(0, M.gap) }, chat)
    -- breathing room: first bubble off the header hairline, last off the Task strip
    pad(chat, 0, 0, 8, 10)
    pad(chat, 12, 12, 8, 8)
    U.chat = chat

    U.typingBar = new("TextLabel", {
        Name = "Typing", Font = Enum.Font.GothamMedium, TextSize = M.fontSmall, TextColor3 = C.dim,
        BackgroundTransparency = 1, Size = UDim2.new(1, -24, 0, 18), TextXAlignment = Enum.TextXAlignment.Left,
        Text = "", Visible = false,
        Position = UDim2.new(0, 12, 1, -(M.inputH + 24)),
    }, window)

    ---------------------------------------------------------------- input
    local inputRow = new("Frame", { Name = "InputRow", BackgroundColor3 = C.panel, BorderSizePixel = 0,
                                    Size = UDim2.new(1, 0, 0, M.inputH), Position = UDim2.new(0, 0, 1, -M.inputH) }, window)
    new("Frame", { Size = UDim2.new(1, 0, 0, M.radius + 1), Position = UDim2.new(0, 0, 0, -M.radius),
                   BackgroundColor3 = C.panel, BorderSizePixel = 0 }, inputRow)
    corner(inputRow, M.radius)
    U.inputRow = inputRow
    -- wrapper frame carries the visible box; the transparent TextBox sits inset
    -- by 8px so typed text breathes (UIPadding does NOT inset TextBox text —
    -- the old layout had glyphs glued to the left border). Text="" is explicit:
    -- an untouched TextBox otherwise shows the literal string "TextBox".
    local inputBox = new("Frame", { Name = "InputBox", BackgroundColor3 = C.panel2, BorderSizePixel = 0,
                                    Size = UDim2.new(1, -(bx + 20), 1, -10), Position = UDim2.new(0, 10, 0, 5) }, inputRow)
    corner(inputBox, 8)
    stroke(inputBox, C.stroke)
    local input = new("TextBox", {
        Name = "Input", Text = "", Font = Enum.Font.Gotham, TextSize = M.font, TextColor3 = C.text,
        PlaceholderText = "Ask Max anything…", PlaceholderColor3 = C.dim,
        BackgroundTransparency = 1, BorderSizePixel = 0, ClearTextOnFocus = false,
        MultiLine = false, TextXAlignment = Enum.TextXAlignment.Left,
        Size = UDim2.new(1, -16, 1, 0), Position = UDim2.new(0, 8, 0, 0),
    }, inputBox)
    U.input = input

    local send = new("TextButton", {
        Text = "", BackgroundColor3 = C.user, Size = UDim2.fromOffset(bx, bx),
        Position = UDim2.new(1, -(bx + 6), 0.5, -bx / 2), BorderSizePixel = 0, AutoButtonColor = true,
    }, inputRow)
    corner(send, math.floor(bx / 2))
    icon(send, "up", math.max(14, bx - 16), C.userText)
    U.btnSend = send
    send.MouseButton1Click:Connect(function() U:Send() end)

    ---------------------------------------------------------------- sidebar
    local sidebarW = M.mobile and math.min(M.winW - 24, 300) or 250
    U.sidebarW = sidebarW
    -- scrim: dim backdrop, tap anywhere to close (mobile)
    local scrim = new("TextButton", {
        Name = "Scrim", BackgroundColor3 = C.bg, BackgroundTransparency = 0.42, Text = "",
        Size = UDim2.new(1, 0, 1, 0), Visible = false, ZIndex = 40, BorderSizePixel = 0, AutoButtonColor = false,
    }, window)
    scrim.MouseButton1Click:Connect(function() if U.sidebarOpen then U:ToggleSidebar() end end)
    U.scrim = scrim
    -- fixed-height panel docked INSIDE the window (was growing past the window
    -- and floating off-screen left, where its close button was unreachable)
    local sidebar = new("ScrollingFrame", {
        Name = "Sidebar", BackgroundColor3 = C.panel, BorderSizePixel = 0,
        Size = UDim2.new(0, sidebarW, 1, -(M.headerH + 18)),
        Position = UDim2.new(0, -sidebarW - 16, 0, M.headerH + 6),
        CanvasSize = UDim2.new(), AutomaticCanvasSize = Enum.AutomaticSize.Y,
        ScrollBarThickness = M.mobile and 4 or 6, Visible = false, ZIndex = 50,
    }, window)
    corner(sidebar, 10)
    stroke(sidebar, C.stroke, 1)
    new("UIListLayout", { SortOrder = Enum.SortOrder.LayoutOrder, Padding = UDim.new(0, 4) }, sidebar)
    pad(sidebar, 8, 8, 8, 8)
    U.sidebar = sidebar

    ---------------------------------------------------------------- orb / toast
    local orb = new("TextButton", {
        Name = "MaxOrb", Text = "", BackgroundColor3 = C.user,
        Size = UDim2.fromOffset(54, 54), AnchorPoint = Vector2.new(1, 1),
        Position = UDim2.new(1, -16, 1, -16), Visible = false, BorderSizePixel = 0, AutoButtonColor = true, ZIndex = 1000,
    }, gui)
    corner(orb, 27)
    icon(orb, "diamond", 20, C.userText)
    orb.MouseButton1Click:Connect(function() U:SetVisible(true) end)
    U.orb = orb

    local toast = new("TextLabel", {
        Name = "Toast", Font = Enum.Font.GothamMedium, TextSize = M.fontSmall, TextColor3 = C.text,
        BackgroundColor3 = C.panel2, Size = UDim2.new(0, 0, 0, 30), Position = UDim2.new(0.5, 0, 0, M.headerH + 8),
        AnchorPoint = Vector2.new(0.5, 0), Visible = false, ZIndex = 200, Text = "", BackgroundTransparency = 0.05,
    }, window)
    corner(toast, 8)
    stroke(toast, C.stroke)
    U.toast = toast

    U:MakeDraggable(header, window)
    U:_buildGrips()

    U:RebuildSidebar()
    U:RerenderChat()

    -- lightweight responsive loop (cheap; no GetPropertyChangedSignal assumptions)
    U.lastVp = U:GetViewport()
    if not NS.__TestMode then
        NS.Spawn(function()
            while U.alive do
                NS.Wait(0.75)
                local vs = U:GetViewport()
                if vs and (math.abs(vs.X - U.lastVp.X) > 30 or math.abs(vs.Y - U.lastVp.Y) > 30) then
                    U.lastVp = vs
                    U:Relayout()
                end
            end
        end)
    end

    if NS.Settings.Get("windowPos") then
        local p = NS.Settings.Get("windowPos")
        local vs = U:GetViewport()
        window.Position = UDim2.fromOffset(math.max(4, math.min(vs.X - 60, p.x or 40)), math.max(4, math.min(vs.Y - 60, p.y or 40)))
    end
end

------------------------------------------------------------------ drag / resize
function U:MakeDraggable(handle, frame)
    local UIS = NS.Service("UserInputService")
    if not UIS or not UIS.InputChanged then return end
    handle.InputBegan:Connect(function(input)
        local t = input.UserInputType
        if t ~= Enum.UserInputType.MouseButton1 and t ~= Enum.UserInputType.Touch then return end
        -- The header hosts the 5 control buttons; taps that STARTED on a
        -- button/textbox must not drag the window (the old "button moves away" bug).
        -- NOTE: InputObject.Target only EXISTS for mouse inputs — indexing it on a
        -- Touch input throws "Target is not a valid member of InputObject" on
        -- mobile executors. Read it under pcall, and hit-test button rects for touch.
        local tgt
        local okT, v = pcall(function() return input.Target end)
        if okT then tgt = v end
        if tgt ~= nil and tgt ~= handle then
            local node, hops = tgt, 0
            while node and node ~= handle and hops < 8 do
                local isCtl = false
                pcall(function() isCtl = node:IsA("TextButton") or node:IsA("TextBox") end)
                if isCtl then return end
                node = node.Parent
                hops = hops + 1
            end
        elseif tgt == nil then
            local okU, utype = pcall(function() return input.UserInputType end)
            if okU and utype == Enum.UserInputType.Touch then
                local okP, pos = pcall(function() return input.Position end)
                if okP and pos then
                    local okD, descs = pcall(function() return handle:GetDescendants() end)
                    if okD and type(descs) == "table" then
                        for _, d in ipairs(descs) do
                            local isCtl = false
                            pcall(function() isCtl = d:IsA("TextButton") or d:IsA("TextBox") end)
                            if isCtl then
                                local okR, r = pcall(function() return d.AbsoluteRect end)
                                if okR and r and r:IsInside(pos) then return end
                            end
                        end
                    end
                end
            end
        end
        local startPos = frame.Position
        local startInput = input.Position
        local dragging = true
        local disc = {}
        disc.move = UIS.InputChanged:Connect(function(i2)
            if not dragging then return end
            local ut = i2.UserInputType
            if ut ~= Enum.UserInputType.MouseMovement and ut ~= Enum.UserInputType.Touch then return end
            local vs = U:GetViewport()
            local nx = startPos.X.Offset + (i2.Position.X - startInput.X)
            local ny = startPos.Y.Offset + (i2.Position.Y - startInput.Y)
            nx = math.max(4, math.min(vs.X - frame.AbsoluteSize.X - 4, nx))
            ny = math.max(4, math.min(vs.Y - frame.AbsoluteSize.Y - 4, ny))
            frame.Position = UDim2.fromOffset(round(nx), round(ny))
        end)
        disc.stop = UIS.InputEnded:Connect(function(i2)
            if i2 == input then
                dragging = false
                if disc.move then disc.move:Disconnect() end
                if disc.stop then disc.stop:Disconnect() end
                NS.Settings.Set("windowPos", { x = round(frame.Position.X.Offset), y = round(frame.Position.Y.Offset) })
            end
        end)
    end)
end

------------------------------------------------------------------ resize mode
-- The square header button toggles RESIZE MODE: glowing edge/corner strips
-- appear; drag any of them to size the window freely. Content is scale-based
-- so bubbles/sidebar/input reflow live; RerenderChat re-measures text to the
-- new width during the drag.
local MIN_W, MIN_H = 320, 240

function U:_edgeDrag(side, input)
    local UIS = NS.Service("UserInputService")
    if not UIS or not UIS.InputChanged then return end
    local w = U.window
    local s0, p0 = w.AbsoluteSize, w.Position
    local i0 = input.Position
    local moved, disc = false, {}
    disc.move = UIS.InputChanged:Connect(function(i2)
        local ut = i2.UserInputType
        if ut ~= Enum.UserInputType.MouseMovement and ut ~= Enum.UserInputType.Touch then return end
        local dx, dy = i2.Position.X - i0.X, i2.Position.Y - i0.Y
        local vs = U:GetViewport()
        local nw, nh = s0.X, s0.Y
        local nx, ny = p0.X.Offset, p0.Y.Offset
        if side == "r" or side == "br" then nw = s0.X + dx end
        if side == "b" or side == "br" then nh = s0.Y + dy end
        if side == "l" then nw = s0.X - dx; nx = p0.X.Offset + dx end
        if side == "t" then nh = s0.Y - dy; ny = p0.Y.Offset + dy end
        nw = math.max(MIN_W, math.min(vs.X - 8, nw))
        nh = math.max(MIN_H, math.min(vs.Y - 8, nh))
        if side == "l" then nx = math.max(4, math.min(nx, p0.X.Offset + (s0.X - nw))) end
        if side == "t" then ny = math.max(4, math.min(ny, p0.Y.Offset + (s0.Y - nh))) end
        w.Size = UDim2.fromOffset(round(nw), round(nh))
        w.Position = UDim2.fromOffset(round(nx), round(ny))
        moved = true
        local now = os.clock()
        if not U._lastReflow or now - U._lastReflow > 0.12 then
            U._lastReflow = now
            U:RerenderChat()
        end
    end)
    disc.stop = UIS.InputEnded:Connect(function(i2)
        if i2 == input then
            if disc.move then disc.move:Disconnect() end
            if disc.stop then disc.stop:Disconnect() end
            if moved then
                NS.Settings.Set("windowSize", { w = round(w.AbsoluteSize.X), h = round(w.AbsoluteSize.Y) })
                NS.Settings.Set("windowPos", { x = round(w.Position.X.Offset), y = round(w.Position.Y.Offset) })
                U:RerenderChat()
            end
        end
    end)
end

function U:_buildGrips()
    if U._grips then return end
    U._grips = {}
    local defs = {
        { "t",  UDim2.new(1, -28, 0, 12), UDim2.new(0, 14, 0, -6) },
        { "b",  UDim2.new(1, -28, 0, 12), UDim2.new(0, 14, 1, -6) },
        { "l",  UDim2.new(0, 12, 1, -28), UDim2.new(0, -6, 0, 14) },
        { "r",  UDim2.new(0, 12, 1, -28), UDim2.new(1, -6, 0, 14) },
        { "br", UDim2.fromOffset(30, 30), UDim2.new(1, -15, 1, -15) },
    }
    for _, d in ipairs(defs) do
        local g = new("Frame", { Name = "Grip" .. d[1], Size = d[2], Position = d[3],
            BackgroundColor3 = C.user, BackgroundTransparency = 0.15, BorderSizePixel = 0,
            Visible = false, ZIndex = 70 }, U.window)
        corner(g, 4)
        g.InputBegan:Connect(function(input)
            local t = input.UserInputType
            if t ~= Enum.UserInputType.MouseButton1 and t ~= Enum.UserInputType.Touch then return end
            U:_edgeDrag(d[1], input)
        end)
        U._grips[d[1]] = g
    end
end

function U:ToggleResize(on)
    U:_buildGrips()
    U._resizing = (on == nil) and (not U._resizing) or (on and true or nil)
    local show = U._resizing and true or false
    for _, g in pairs(U._grips) do g.Visible = show end
    if U.winStroke then
        pcall(function()
            U.winStroke.Color = U._resizing and C.user or C.stroke
            U.winStroke.Thickness = U._resizing and 2 or 1.2
        end)
    end
    if U.btnMax then
        pcall(function() U.btnMax.BackgroundColor3 = U._resizing and C.user or C.panel2 end)
    end
    U:Toast(U._resizing and "resize mode — drag the glowing edges, tap again when done" or "resize mode off")
end

------------------------------------------------------------------ layout
function U:Relayout()
    if not U.window then return end
    local M = U:Metrics()
    local vs = U:GetViewport()
    local w, h = M.winW, M.winH
    local saved = NS.Settings.Get("windowSize")
    if saved then
        -- respect a user-chosen size from resize mode (clamped to the screen)
        w = math.max(MIN_W, math.min(vs.X - 8, saved.w or w))
        h = math.max(MIN_H, math.min(vs.Y - 8, saved.h or h))
    end
    U.window.Size = UDim2.fromOffset(w, h)
    U._geo = U:_geometry()
    if U.header then U.header.Size = UDim2.new(1, 0, 0, M.headerH) end
    if U.chat then
        U.chat.Size = UDim2.new(1, 0, 1, -(M.headerH + M.inputH + 28))
    end
    if U.typingBar then
        U.typingBar.Position = UDim2.new(0, 12, 1, -(M.inputH + 24))
    end
    if U.FitDiag then pcall(function() U:FitDiag() end) end
    if U.sidebar and U.sidebarOpen then
        U.sidebar.Size = UDim2.new(0, U.sidebarW, 1, -(M.headerH + 18))
        U.sidebar.Position = UDim2.new(0, 8, 0, M.headerH + 6)
    end
    if U.inputRow then
        U.inputRow.Size = UDim2.new(1, 0, 0, M.inputH)
        U.inputRow.Position = UDim2.new(0, 0, 1, -M.inputH)
    end
    U.mode = M.mobile and "mobile" or "desktop"
    U:RerenderChat()
end

------------------------------------------------------------------ bubbles
function U:_row()
    U.order = U.order + 1
    return new("Frame", {
        BackgroundTransparency = 1, Size = UDim2.new(1, 0, 0, 0), AutomaticSize = Enum.AutomaticSize.Y,
        LayoutOrder = U.order,
    }, U.chat)
end

function U:AddBubble(role, text, sub)
    if not U.chat or not U.window then return end
    local M = U:Metrics()
    -- Heights are computed by the layout engine itself (label auto-Y inside a
    -- padded auto-Y bubble inside an auto-Y row). The old manual GetTextSize
    -- math could under-measure wrapped text, which is why bubbles sometimes
    -- "jumped" and overlapped later messages. Nothing overlaps now: the row's
    -- size is whatever its content needs, always.
    local row = U:_row()
    local chatW = U.chat.AbsoluteSize.X
    if not chatW or chatW <= 0 then chatW = M.winW end
    local maxBubbleW = math.max(200, (chatW - 46) * (M.mobile and 0.92 or 0.86))
    local clean = sanitize(text)
    -- trim hard; whitespace-only content (reasoning models emit it) used to
    -- render as a giant empty bubble — that is the bug in the screenshot.
    clean = (clean:gsub("^%s+", ""):gsub("%s+$", ""))
    if type(sub) == "string" then
        sub = (sub:gsub("^%s+", ""):gsub("%s+$", ""))
        if sub == "" then sub = nil end
    end
    if clean == "" then
        if not sub then return end          -- nothing to show: no bubble, no row
        clean = sub sub = nil
    end
    local isUser = role == "user"
    local TS = NS.Service("TextService")
    -- Tight bubble width: measure the real single-line size through TextService
    -- (falls back to a char heuristic when absent, e.g. headless tests). The old
    -- len*0.5 guess over-widened short replies and under-widened long words.
    local wantW = 64 + #clean * (M.font * 0.5)
    if TS and TS.GetTextSize then
        local okM, sz = pcall(function()
            return TS:GetTextSize(clean, M.font, Enum.Font.Gotham, Vector2.new(999999, 999999))
        end)
        if okM and sz and sz.X and sz.X > 0 then
            wantW = sz.X + 2 * M.bubblePad + 3
        end
    end
    local bubbleW = math.min(maxBubbleW, wantW)
    -- Explicit height math (TextService constrained-width measurement, whose Y
    -- is trustworthy). We do NOT rely on AutomaticSize propagating up through
    -- plain frames: when a client under-reports that, long messages grew past
    -- their row and the scroll canvas never reached the rest — the tail of the
    -- answer was invisible AND unscrollable. Now every bubble's row reserves
    -- the full height, so scrolling always shows everything.
    local textW = math.max(60, bubbleW - 2 * M.bubblePad)
    local function wrappedH(str, fsize, fnt)
        if TS and TS.GetTextSize then
            local okS, sz2 = pcall(function()
                return TS:GetTextSize(str, fsize, fnt, Vector2.new(textW, 999999))
            end)
            if okS and sz2 and sz2.Y and sz2.Y > 0 then return sz2.Y + 2 end
        end
        local lines = 0
        local perLine = math.max(12, math.floor(textW / (fsize * 0.52)))
        for seg in (str .. "\n"):gmatch("([^\n]*)\n") do
            lines = lines + math.max(1, math.ceil(#seg / perLine))
        end
        return math.max(1, lines) * (fsize + 3) + 3
    end
    local mainH = wrappedH(clean, M.font, Enum.Font.Gotham)
    local subH = sub and wrappedH(tostring(sub), M.fontSmall - 1, Enum.Font.Gotham) or 0
    local h = mainH + 2 * M.bubblePad + 2 + (sub and (subH + 3) or 0)

    local bubble = new("Frame", {
        BackgroundColor3 = isUser and C.user or C.max, BackgroundTransparency = 0.35,
        Size = UDim2.fromOffset(bubbleW, h),
        AnchorPoint = Vector2.new(isUser and 1 or 0, 0),
        Position = UDim2.new(isUser and 1 or 0, isUser and -10 or 10, 0, 0),
        BorderSizePixel = 0,
    }, row)
    row.Size = UDim2.new(1, 0, 0, h)
    if AS_NONE then row.AutomaticSize = AS_NONE end -- else: engine Y-fit over fixed-size children is equivalent
    corner(bubble, M.radius)
    new("UIListLayout", { SortOrder = Enum.SortOrder.LayoutOrder, Padding = UDim.new(0, 3) }, bubble)
    pad(bubble, M.bubblePad, M.bubblePad, M.bubblePad, M.bubblePad)
    local mainLbl = new("TextLabel", {
        LayoutOrder = 1, Text = clean, Font = Enum.Font.Gotham, TextSize = M.font,
        TextColor3 = isUser and C.userText or C.text, BackgroundTransparency = 1,
        TextWrapped = true, TextXAlignment = Enum.TextXAlignment.Left, TextYAlignment = Enum.TextYAlignment.Top,
        Size = UDim2.new(1, 0, 0, mainH),
    }, bubble)
    -- One-shot height fit from the label's real TextBounds: TextService math
    -- over/under-shoots on some executors (oversized padding around short
    -- replies). Two frames late the layout is settled; correct row+bubble once.
    NS.Spawn(function()
        NS.Wait(0.05) NS.Wait(0.05)
        if not U.alive or not mainLbl or not mainLbl.Parent then return end
        local okF, tb = pcall(function() return mainLbl.TextBounds end)
        if okF and tb and tb.Y and tb.Y > 0 then
            local want = math.max(M.font + 4, tb.Y + 2)
            if math.abs(want - mainH) > 3 then
                local newH = h + (want - mainH)
                pcall(function()
                    mainLbl.Size = UDim2.new(1, 0, 0, want)
                    bubble.Size = UDim2.new(0, bubbleW, 0, newH)
                    row.Size = UDim2.new(1, 0, 0, newH)
                end)
                U:ScrollBottom()
            end
        end
    end)
    if sub then
        new("TextLabel", {
            LayoutOrder = 2, Text = sub, Font = Enum.Font.Gotham, TextSize = M.fontSmall - 1,
            TextColor3 = isUser and C.userText or C.dim, BackgroundTransparency = 1,
            TextWrapped = true, TextXAlignment = Enum.TextXAlignment.Left, TextYAlignment = Enum.TextYAlignment.Top,
            Size = UDim2.new(1, 0, 0, subH),
        }, bubble)
    end
    tween(bubble, { BackgroundTransparency = 0 }, 0.18)
    table.insert(U.rows, row)
    U:ScrollBottom()
end

function U:AddNoteLine(text)
    if not U.chat then return end
    local row = U:_row()
    row.Size = UDim2.new(1, 0, 0, 20)
    new("TextLabel", {
        Text = text, Font = Enum.Font.GothamMedium, TextSize = U:Metrics().fontSmall,
        TextColor3 = C.note, BackgroundTransparency = 1,
        Size = UDim2.new(1, -24, 1, 0), Position = UDim2.new(0, 12, 0, 0),
        TextXAlignment = Enum.TextXAlignment.Left, TextYAlignment = Enum.TextYAlignment.Center,
    }, row)
    U:ScrollBottom()
end

function U:AddMetaLine(text)
    if not U.chat then return end
    local row = U:_row()
    row.Size = UDim2.new(1, 0, 0, 16)
    new("TextLabel", {
        Text = text, Font = Enum.Font.Gotham, TextSize = U:Metrics().fontSmall - 2, TextColor3 = C.dim,
        BackgroundTransparency = 1, Size = UDim2.new(1, -24, 1, 0), Position = UDim2.new(0, 12, 0, 0),
        TextXAlignment = Enum.TextXAlignment.Right, TextYAlignment = Enum.TextYAlignment.Center,
    }, row)
    U:ScrollBottom()
end

-- Tool notes are persisted onto the conversation (conv.bubbles via
-- Memory.PushBubble) so a conversation switch, minimize, or re-exec restores
-- the FULL line — including the target object name, not just the tool name.
function U:AddToolNote(name, argsStr)
    if not U.chat then return end
    local hint = ""
    if type(argsStr) == "string" and #argsStr > 2 then
        local p = NS.JSON.Decode(argsStr)
        local pick = p and (p.path or p.query or p["class"] or p.name or p.property or p.service)
        if pick then hint = " · " .. tostring(pick):sub(1, 40) end
    end
    local line = "» " .. tostring(name) .. hint
    if not U._replaying then NS.Memory.PushBubble({ k = "note", s = line }) end
    U:AddNoteLine(line)
end

-- Code the AI just ran: grey monospace preview (capped at 100 lines) plus the
-- captured output, clipped inside a fixed-height card so it can never overlap.
-- The card body is persisted on the conversation too, so minimize /
-- conversation switch / re-exec restores exactly what ran (not a blanked row).
function U:_execCard(body, bad)
    if not U.chat then return end
    local M = U:Metrics()
    local lc = 1
    for _ in body:gmatch("\n") do lc = lc + 1 end
    local per = M.fontSmall + 3
    local h = math.min(30 + lc * per, 460)
    local row = U:_row()
    row.Size = UDim2.new(1, 0, 0, h)
    row.ClipsDescendants = true
    local bg = new("Frame", { Size = UDim2.new(1, 0, 1, 0), BackgroundColor3 = C.panel2,
                              BorderSizePixel = 0 }, row)
    corner(bg, 8)
    new("TextLabel", {
        Text = bad and "» execute_code (failed)" or "» executed code",
        Font = Enum.Font.GothamMedium, TextSize = M.fontSmall - 1,
        TextColor3 = bad and C.bad or C.user, BackgroundTransparency = 1,
        Size = UDim2.new(1, -16, 0, 15), Position = UDim2.new(0, 8, 0, 5),
        TextXAlignment = Enum.TextXAlignment.Left,
    }, row)
    new("TextLabel", {
        Text = body, Font = Enum.Font.Code, TextSize = M.fontSmall,
        TextColor3 = C.dim, BackgroundTransparency = 1,
        Size = UDim2.new(1, -16, 1, -26), Position = UDim2.new(0, 8, 0, 22),
        TextXAlignment = Enum.TextXAlignment.Left, TextYAlignment = Enum.TextYAlignment.Top,
    }, row)
    U:ScrollBottom()
end

function U:AddExecView(argsJson, resultJson)
    if not U.chat then return end
    local a = NS.JSON.Decode(argsJson or "")
    local r = NS.JSON.Decode(resultJson or "") or {}
    local code = (type(a) == "table" and type(a.code) == "string" and a.code) or ""
    local n = 0
    local shown = {}
    for ln in (code .. "\n"):gmatch("([^\n]*)\n") do
        n = n + 1
        if n <= 100 then shown[#shown + 1] = ln:len() > 120 and (ln:sub(1, 120) .. "…") or ln end
    end
    local body = table.concat(shown, "\n")
    if n > 100 then body = body .. "\n… +" .. (n - 100) .. " more lines" end
    local outParts = {}
    if type(r.output) == "string" and #r.output > 0 then outParts[#outParts + 1] = r.output end
    if r.returned then outParts[#outParts + 1] = "=> " .. tostring(r.returned) end
    if r.timedOut then outParts[#outParts + 1] = "[stopped: timeout]"
    elseif r.error then outParts[#outParts + 1] = "[error] " .. tostring(r.error)
    elseif r.compileError then outParts[#outParts + 1] = "[compile] " .. tostring(r.compileError) end
    local outText = table.concat(outParts, "\n")
    if #outText > 1800 then outText = outText:sub(1, 1800) .. "\n…" end
    if outText ~= "" then body = (body ~= "" and (body .. "\n") or "") .. "— output —\n" .. outText end
    local bad = (r.ok == false)
    if not U._replaying then
        NS.Memory.PushBubble({ k = "exec", bad = bad,
            s = body:len() > 9000 and (body:sub(1, 9000) .. "\n…") or body })
    end
    U:_execCard(body, bad)
end

function U:AddNoteBar(text)
    local row = U:_row()
    row.Size = UDim2.new(1, 0, 0, 24)
    local bg = new("Frame", { Size = UDim2.new(1, 0, 1, 0), BackgroundColor3 = C.panel2,
                              BackgroundTransparency = 0.45, BorderSizePixel = 0 }, row)
    corner(bg, 8)
    new("TextLabel", {
        Text = text, Font = Enum.Font.GothamMedium, TextSize = U:Metrics().fontSmall, TextColor3 = C.note,
        BackgroundTransparency = 1, Size = UDim2.new(1, -16, 1, 0), Position = UDim2.new(0, 8, 0, 0),
        TextXAlignment = Enum.TextXAlignment.Center,
    }, row)
end

function U:ScrollBottom()
    local chat = U.chat
    if not chat then return end
    NS.Spawn(function()
        NS.Wait(0.05)
        pcall(function()
            chat.CanvasPosition = Vector2.new(0, chat.AbsoluteCanvasSize.Y + 99999)
        end)
    end)
end

function U:RerenderChat()
    if not U.chat then return end
    for _, ch in ipairs(U.chat:GetChildren()) do
        if ch:IsA("Frame") then
            pcall(function() ch:Destroy() end)
        end
    end
    U.order = 0
    U.rows = {}
    local conv = NS.Memory.Active()
    if not conv then return end
    if conv.summary then
        U:AddNoteBar("earlier turns were summarized to save context")
    end
    -- Persisted display bubbles (tool notes with their targets, executed-code
    -- cards, turn timing) interleave with the message list by their "at" mark
    -- = number of messages when they happened. Older conversations recorded
    -- before this existed have none: fall back to synthesizing bare notes from
    -- tool_calls messages.
    local bl = (type(conv.bubbles) == "table" and #conv.bubbles > 0) and conv.bubbles or nil
    local legacy = not bl
    local bi = 1
    local function flush(after)
        if not bl then return end
        while bi <= #bl and (tonumber(bl[bi].at) or 0) <= after do
            local b = bl[bi]
            bi = bi + 1
            local s = type(b.s) == "string" and b.s or ""
            if b.k == "note" and s ~= "" then
                U:AddNoteLine(s:sub(1, 400))
            elseif b.k == "exec" and s ~= "" then
                U:_execCard(s:sub(1, 10000), b.bad == true)
            elseif b.k == "meta" and s ~= "" then
                U:AddMetaLine(s:sub(1, 200))
            end
        end
    end
    U._replaying = true
    flush(0)
    for j, m in ipairs(conv.messages) do
        if m.role == "user" then
            U:AddBubble("user", m.content or "")
        elseif m.role == "assistant" then
            if m.tool_calls and (m.content == nil or m.content == "") then
                if legacy then
                    local tf = m.tool_calls[1] and m.tool_calls[1]["function"]
                    U:AddToolNote((tf and tf.name) or "tool", nil)
                end
            elseif m.content and #m.content > 0 then
                U:AddBubble("assistant", m.content)
            end
        end
        flush(j)
    end
    U._replaying = false
    if U.order == 0 then
        U:AddNoteBar("hi — ask me anything about this game. The + button starts a chat; menu has settings, key + tools.")
    end
    U:ScrollBottom()
end

------------------------------------------------------------------ typing / task / status / toast
-- Live activity line above the input: "Task: <what Max is doing>" in dim
-- grey, with a soft pulsing refresh while active.
function U:SetTask(text, detail)
    U._task = text
    U._taskDetail = detail
    if not U.typingBar then return end
    if U.typingTick then
        pcall(function() U.typingTick:Disconnect() end)
        U.typingTick = nil
    end
    if text then
        U.typingBar.Visible = true
        U.typingBar.Text = "Task: " .. tostring(text) .. (detail and (" · " .. tostring(detail)) or "")
        U.typingBar.TextTransparency = 0.35
        if not NS.__TestMode then
            local hb = NS.Service("RunService")
            if hb and hb.Heartbeat then
                local t, dotPhase = 0, 0
                local dots = { "", ".", "..", "..." }
                U.typingTick = hb.Heartbeat:Connect(function(dt)
                    if not U.alive or not U.typingBar then
                        pcall(function() U.typingTick:Disconnect() end)
                        U.typingTick = nil
                        return
                    end
                    t = t + dt
                    U.typingBar.TextTransparency = 0.45 + 0.35 * math.sin(t * 3.2)
                    local ph = math.floor(t / 0.42) % 4
                    if ph ~= dotPhase then
                        dotPhase = ph
                        local base = "Task: " .. tostring(U._task or "thinking") ..
                            (U._taskDetail and (" · " .. tostring(U._taskDetail)) or "")
                        pcall(function() U.typingBar.Text = base .. " " .. dots[dotPhase + 1] end)
                    end
                end)
            end
        end
        U:ScrollBottom()
    else
        U.typingBar.Visible = false
        U.typingBar.Text = ""
    end
end

function U:SetTyping(on)
    if not U.typingBar then return end
    if on then
        U:SetTask(U._task or "thinking")
    else
        U:SetTask(nil)
    end
end

function U:SetStatus(online, err)
    if not U.statusDot then return end
    U.statusDot.BackgroundColor3 = online and C.ok or C.bad
    if err and not online then U:Toast("no connection: " .. tostring(err)) end
end

function U:SetDiag(d)
    if type(d) ~= "table" then return end
    local via = tostring(d.routed_via or d.model or "?")
    if U.diagLabel then
        local ms = tonumber(d.latency_ms)
        U.diagLabel.Text = ms and (via .. " · " .. ms .. "ms") or via
    end
end

function U:Toast(msg)
    if not U.toast then
        NS.Warn("[toast] " .. tostring(msg))
        return
    end
    U.toast.Text = tostring(msg):sub(1, 140)
    U.toast.Visible = true
    U.toastJob = (U.toastJob or 0) + 1
    local job = U.toastJob
    NS.Spawn(function()
        NS.Wait(4.2)
        if U.toastJob == job and U.toast then U.toast.Visible = false end
    end)
end

------------------------------------------------------------------ sidebar
function U:ToggleSidebar()
    if not U.sidebar then return end
    U.sidebarOpen = not U.sidebarOpen
    if U.sidebarOpen then
        U:RebuildSidebar()
        -- keep the panel inside the actual window width (not the viewport guess)
        local winW = U.window and U.window.AbsoluteSize.X or 0
        if winW > 40 and U.sidebarW > winW - 16 then U.sidebarW = winW - 16 end
        U.sidebar.Size = UDim2.new(0, U.sidebarW, 1, -(U:Metrics().headerH + 18))
        U.sidebar.Position = UDim2.new(0, 8, 0, U:Metrics().headerH + 6)
        U.sidebar.Visible = true
        if U.scrim then U.scrim.Visible = true end
    else
        -- instant hide — closing used to slide the panel OUTSIDE the window
        -- and only hide it 220ms later, which read as "it moves away and can't
        -- be closed". It now just goes away, right where it is.
        U.sidebar.Visible = false
        if U.scrim then U.scrim.Visible = false end
    end
end

function U:RebuildSidebar()
    local sb = U.sidebar
    if not sb then return end
    for _, ch in ipairs(sb:GetChildren()) do
        if ch:IsA("TextButton") or ch:IsA("TextLabel") or ch:IsA("TextBox") or ch:IsA("Frame") then
            pcall(function() ch:Destroy() end)
        end
    end
    local M = U:Metrics()
    local order = 0
    local function item(inst)
        order = order + 1
        inst.LayoutOrder = order
        inst.Parent = sb
    end
    local function secTitle(t)
        item(new("TextLabel", { Text = t, Font = Enum.Font.GothamBold, TextSize = M.fontSmall, TextColor3 = C.dim,
                                BackgroundTransparency = 1, Size = UDim2.new(1, 0, 0, 20), TextXAlignment = Enum.TextXAlignment.Left }))
    end

    secTitle("CONVERSATIONS")
    local convs = NS.Memory.ListConversations()
    local activeId = NS.Memory.index and NS.Memory.index.active
    for i, meta in ipairs(convs) do
        if i <= 30 then
            local ago = math.floor((os.time() - (meta.updated or os.time())) / 60)
            local stamp = ago < 60 and (ago .. "m") or ago < 2880 and (math.floor(ago / 60) .. "h") or (math.floor(ago / 1440) .. "d")
            local active = meta.id == activeId
            -- Row is a transparent-click catcher with EXPLICIT child labels —
            -- never the button's own text with UIPadding (that combo ignored the
            -- padding on some clients, letting the active bar sit on top of the
            -- title). Geometry here is literal: bar x=6, text x=20, nothing can overlap.
            local b = new("TextButton", {
                Text = "",
                BackgroundColor3 = active and C.panel2 or C.panel,
                BackgroundTransparency = active and 0 or 1,
                BorderSizePixel = 0,
                Size = UDim2.new(1, 0, 0, M.mobile and 44 or 36), AutoButtonColor = true,
            })
            corner(b, 10)
            if active then
                new("Frame", { Size = UDim2.fromOffset(3, M.mobile and 20 or 18),
                                Position = UDim2.new(0, 6, 0.5, 0),
                                AnchorPoint = Vector2.new(0, 0.5), CornerRadius = UDim.new(1, 0),
                                BackgroundColor3 = C.user, BorderSizePixel = 0, ZIndex = 6 }, b)
            end
            new("TextLabel", {
                Text = meta.title or "untitled",
                Font = active and Enum.Font.GothamBold or Enum.Font.GothamMedium,
                TextSize = M.font - 1, TextColor3 = active and C.text or C.dim,
                BackgroundTransparency = 1, TextTruncate = Enum.TextTruncate.AtEnd,
                TextXAlignment = Enum.TextXAlignment.Left, TextYAlignment = Enum.TextYAlignment.Center,
                Size = UDim2.new(1, -86, 1, 0), Position = UDim2.new(0, 20, 0, 0), ZIndex = 6,
            }, b)
            b.MouseButton1Click:Connect(function()
                NS.Memory.SetActive(meta.id)
                U:RebuildSidebar()
                U:RerenderChat()
                if U.mode == "mobile" and U.sidebarOpen then U:ToggleSidebar() end
            end)
            local del = new("TextButton", {
                Text = "x", Font = Enum.Font.GothamMedium, TextSize = 15, BackgroundTransparency = 1,
                TextColor3 = C.dim, Size = UDim2.fromOffset(30, M.mobile and 34 or 30),
                AnchorPoint = Vector2.new(1, 0.5),
                Position = UDim2.new(1, -4, 0.5, 0), ZIndex = 60, AutoButtonColor = true,
            }, b)
            del.MouseButton1Click:Connect(function()
                NS.Memory.DeleteConversation(meta.id)
                if not NS.Memory.index or NS.Memory.index.active == meta.id then
                    NS.Memory.activeConv = NS.Memory.NewConversation()
                    U:RerenderChat()
                end
                U:RebuildSidebar()
            end)
            new("TextLabel", {
                Text = stamp, Font = Enum.Font.Gotham, TextSize = M.fontSmall - 2, TextColor3 = C.dim,
                BackgroundTransparency = 1, Size = UDim2.fromOffset(36, 20), AnchorPoint = Vector2.new(1, 0.5),
                Position = UDim2.new(1, -40, 0.5, 0), ZIndex = 55,
            }, b)
            item(b)
        end
    end
    if #convs == 0 then
        item(new("TextLabel", { Text = "no conversations yet", Font = Enum.Font.Gotham, TextSize = M.fontSmall,
                                TextColor3 = C.dim, BackgroundTransparency = 1, Size = UDim2.new(1, 0, 0, 22) }))
    end

    secTitle("SETTINGS")
    local function settingBox(label, key, pwd)
        item(new("TextLabel", { Text = label, Font = Enum.Font.Gotham, TextSize = M.fontSmall - 1, TextColor3 = C.dim,
                                BackgroundTransparency = 1, Size = UDim2.new(1, 0, 0, 16), TextXAlignment = Enum.TextXAlignment.Left }))
        local box = new("Frame", { BackgroundColor3 = C.panel2, BorderSizePixel = 0,
                                   Size = UDim2.new(1, 0, 0, M.mobile and 38 or 28) })
        corner(box, 6)
        stroke(box, C.stroke)
        local tb = new("TextBox", {
            Text = tostring(NS.Settings.Get(key) or ""), Font = Enum.Font.Code, TextSize = M.fontSmall,
            TextColor3 = C.text, BackgroundTransparency = 1, BorderSizePixel = 0,
            Size = UDim2.new(1, -14, 1, 0), Position = UDim2.new(0, 7, 0, 0), ClearTextOnFocus = false,
            Password = pwd and true or false, TextXAlignment = Enum.TextXAlignment.Left,
        }, box)
        tb.FocusLost:Connect(function()
            NS.Settings.Set(key, tb.Text)
            if key == "apiBase" or key == "apiKey" then
                U:Toast("saved — testing connection…")
                NS.Spawn(function() NS.API.Health() end)
            end
        end)
        item(box)
        return tb
    end
    settingBox("Backend URL (http://ip:port or https://host)", "apiBase")
    settingBox("Max key (minted by setup script)", "apiKey", true)

    local function action(label, cb, danger)
        -- explicit label child: UIPadding does NOT inset a button's own text,
        -- so padded text would sit flush on the frame edge
        local b = new("TextButton", { Text = "",
            BackgroundColor3 = C.panel2, BorderSizePixel = 0,
            Size = UDim2.new(1, 0, 0, M.mobile and 42 or 30), AutoButtonColor = true })
        corner(b, 8)
        new("TextLabel", { Text = label, Font = Enum.Font.GothamMedium, TextSize = M.font - 1,
            TextColor3 = danger and C.bad or C.text, BackgroundTransparency = 1,
            Size = UDim2.new(1, -20, 1, 0), Position = UDim2.new(0, 10, 0, 0),
            TextXAlignment = Enum.TextXAlignment.Left, TextYAlignment = Enum.TextYAlignment.Center,
            TextTruncate = Enum.TextTruncate.AtEnd }, b)
        b.MouseButton1Click:Connect(cb)
        item(b)
        return b
    end
    action("AI code execution: " .. (NS.Settings.Get("execEnabled") ~= false and "ON" or "OFF (dangerous)"), function()
        NS.Settings.Set("execEnabled", NS.Settings.Get("execEnabled") == false)
        U:RebuildSidebar()
    end)
    action("Auto-continue unfinished work: " .. (function()
        local n = math.floor(tonumber(NS.Settings.Get("autoContinue")) or 2)
        if n <= 0 then return "OFF (asks you to say continue)" end
        return n .. (n == 1 and " extra round" or " extra rounds")
    end)(), function()
        local n = math.floor(tonumber(NS.Settings.Get("autoContinue")) or 2)
        n = n + 1
        if n > 3 then n = 0 end
        NS.Settings.Set("autoContinue", n)
        U:RebuildSidebar()
    end)
    action("Learning from chats (memory + auto-notes): " .. (NS.Settings.Get("learningEnabled") ~= false and "ON" or "OFF"), function()
        NS.Settings.Set("learningEnabled", NS.Settings.Get("learningEnabled") == false)
        U:RebuildSidebar()
    end)
    -- model tier picker: a 4-segment control (dropdowns are hostile on touch;
    -- this is the same choice with fat tappable targets). Highlight follows the
    -- live setting; tapping a segment saves instantly and repaints in place.
    item(new("TextLabel", { Text = "model tier (which brains answer you)", Font = Enum.Font.Gotham,
                            TextSize = M.fontSmall - 1, TextColor3 = C.dim, BackgroundTransparency = 1,
                            Size = UDim2.new(1, 0, 0, 16), TextXAlignment = Enum.TextXAlignment.Left }))
    do
        local row = new("Frame", { BackgroundColor3 = C.panel2, BorderSizePixel = 0,
                                   Size = UDim2.new(1, 0, 0, M.mobile and 40 or 28) })
        corner(row, 8)
        stroke(row, C.stroke)
        local opts = {
            { id = "auto", label = "Auto" },
            { id = "smart", label = "Smart" },
            { id = "reliable", label = "Reliable" },
            { id = "balanced", label = "Balanced" },
        }
        local painted = {}
        local function paint()
            local cur = tostring(NS.Settings.Get("modelTier") or "auto"):lower()
            for i, o in ipairs(opts) do
                local on = o.id == cur
                if painted[i] then
                    painted[i][1].BackgroundColor3 = on and C.user or C.panel
                    painted[i][2].TextColor3 = on and C.userText or C.dim
                end
            end
        end
        for i, o in ipairs(opts) do
            local b = new("TextButton", { Text = "", BackgroundColor3 = C.panel, BorderSizePixel = 0,
                AutoButtonColor = true, Size = UDim2.new(0.25, -3, 1, -4),
                Position = UDim2.new(0.25 * (i - 1), 2, 0, 2) }, row)
            corner(b, 6)
            local lb = new("TextLabel", { Text = o.label, Font = Enum.Font.GothamMedium,
                TextSize = M.fontSmall - 2, TextColor3 = C.dim, BackgroundTransparency = 1,
                Size = UDim2.new(1, 0, 1, 0), TextTruncate = Enum.TextTruncate.AtEnd }, b)
            painted[i] = { b, lb }
            b.MouseButton1Click:Connect(function()
                NS.Settings.Set("modelTier", o.id)
                paint()
                U:Toast("model tier: " .. o.label)
            end)
        end
        paint()
        item(row)
    end
    -- execute_code budget: stepper, 1..32 attempts per message (default 8).
    -- Persisted as a NUMBER (Settings.ExecCap clamps reads); chat requests
    -- carry it so the backend enforces the same figure the user picked.
    item(new("TextLabel", { Text = "exec attempts per message (1–32)", Font = Enum.Font.Gotham,
                            TextSize = M.fontSmall - 1, TextColor3 = C.dim, BackgroundTransparency = 1,
                            Size = UDim2.new(1, 0, 0, 16), TextXAlignment = Enum.TextXAlignment.Left }))
    do
        local rowH = M.mobile and 44 or 30
        local row = new("Frame", { BackgroundColor3 = C.panel2, BorderSizePixel = 0,
                                   Size = UDim2.new(1, 0, 0, rowH) })
        corner(row, 8)
        stroke(row, C.stroke)
        local val = new("TextLabel", {
            Text = tostring(NS.Settings.ExecCap()), Font = Enum.Font.GothamMedium, TextSize = M.font,
            TextColor3 = C.text, BackgroundTransparency = 1, ZIndex = 6,
            Size = UDim2.new(0, 30, 1, 0), Position = UDim2.new(1, -82, 0, 0),
        }, row)
        local function stepBtn(label, xOff, d)
            local b = new("TextButton", { Text = "", BackgroundColor3 = C.panel, BorderSizePixel = 0,
                Size = UDim2.new(0, 34, 0, rowH - (M.mobile and 10 or 6)), Position = UDim2.new(1, xOff, 0.5, 0),
                AnchorPoint = Vector2.new(0, 0.5), AutoButtonColor = true, ZIndex = 6 }, row)
            corner(b, 6)
            new("TextLabel", { Text = label, Font = Enum.Font.GothamMedium, TextSize = M.font + 2,
                TextColor3 = C.text, BackgroundTransparency = 1, Size = UDim2.new(1, 0, 1, 0), ZIndex = 7 }, b)
            b.MouseButton1Click:Connect(function()
                local cur = NS.Settings.ExecCap()
                NS.Settings.Set("execMaxAttempts", math.max(1, math.min(32, cur + d)))
                val.Text = tostring(NS.Settings.ExecCap())
                if cur ~= NS.Settings.ExecCap() then U:Toast("execute_code budget: " .. val.Text .. " per message") end
            end)
        end
        stepBtn("-", -40, -1)
        stepBtn("+", -4, 1)
        new("TextLabel", {
            Text = "how often the AI may run code each reply", Font = Enum.Font.Gotham,
            TextSize = M.fontSmall - 1, TextColor3 = C.dim, BackgroundTransparency = 1,
            Size = UDim2.new(1, -136, 1, 0), Position = UDim2.new(0, 10, 0, 0),
            TextXAlignment = Enum.TextXAlignment.Left, TextTruncate = Enum.TextTruncate.AtEnd,
        }, row)
        item(row)
    end
    action("Test connection + stats", function()
        NS.Spawn(function()
            local ok = NS.API.Health()
            if not ok then U:Toast("backend unreachable") return end
            local stats = NS.API.Stats()
            if stats and stats.catalog then
                U:Toast(string.format("online · %d ready models", stats.catalog.ready_models or 0))
            else
                U:Toast("online · stats unavailable")
            end
        end)
    end)
    action("Clear this conversation", function()
        local conv = NS.Memory.Active()
        conv.messages = {}
        conv.summary = nil
        NS.Memory.SaveConversation(conv)
        U:RerenderChat()
    end)
    action("Delete ALL chats + memory", function()
        if U._wipeArmed then
            NS.Memory.ClearAll()
            NS.Memory.ClearFacts()
            if NS.Knowledge and NS.Knowledge.ClearAll then NS.Knowledge.ClearAll() end
            NS.Warn("wipe: memory + facts + knowledge + all conversations erased")
            U._wipeArmed = nil
            NS.Memory.activeConv = NS.Memory.NewConversation()
            U:RerenderChat()
            U:RebuildSidebar()
            U:Toast("memory wiped")
            return
        end
        U._wipeArmed = true
        U:Toast("tap again within 5s to wipe everything")
        NS.Spawn(function() NS.Wait(5) U._wipeArmed = nil end)
    end, true)

    secTitle("DIAGNOSTICS")
    local feats = NS.Env.Describe()
    local info = string.format("executor: %s · http: %s · index: %d · facts: %d · %s · storage: %s",
        feats.executor,
        (NS.HTTP.Transport and NS.HTTP.Transport.name) or "none",
        tonumber(NS.Inspect.State.Built) or 0,
        #(NS.Memory.facts or {}),
        U.mode or "?",
        NS.Storage.Mode)
    item(new("TextLabel", { Text = info, Font = Enum.Font.Gotham, TextSize = M.fontSmall - 1, TextColor3 = C.dim,
                            BackgroundTransparency = 1, Size = UDim2.new(1, 0, 0, 44), TextWrapped = true,
                            TextXAlignment = Enum.TextXAlignment.Left, TextYAlignment = Enum.TextYAlignment.Top }))
    item(new("TextLabel", { Text = "memory " .. NS.Memory.Format .. " · build " .. NS.Build, Font = Enum.Font.Gotham,
                            TextSize = M.fontSmall - 2, TextColor3 = C.note, BackgroundTransparency = 1,
                            Size = UDim2.new(1, 0, 0, 16), TextXAlignment = Enum.TextXAlignment.Left }))
end

------------------------------------------------------------------ window control
-- Minimize/restore: genie-shrink toward the orb corner (and pop back out).
-- Pure size/position tween on frames — no fonts, no TweenService requirement.
function U:_geometry()
    local w = U.window
    return { x = round(w.Position.X.Offset), y = round(w.Position.Y.Offset),
             w = round(w.AbsoluteSize.X), h = round(w.AbsoluteSize.Y) }
end

function U:SetVisible(v)
    if not U.window then return end
    U._hidden = not v
    if NS.__TestMode then
        U.window.Visible = v
        if U.orb then U.orb.Visible = not v end
        if v then U:RerenderChat() U:ScrollBottom() end
        return
    end
    if v then
        local geo = U._geo or { x = 40, y = 40, w = 560, h = 480 }
        U.window.Visible = true
        if U.orb then U.orb.Visible = false end
        animate(0.22, function(u)
            local e = 1 - (1 - u) ^ 3                     -- cubic out
            local w = 64 + (geo.w - 64) * e
            local h = 64 + (geo.h - 64) * e
            pcall(function()
                U.window.Size = UDim2.fromOffset(round(w), round(h))
                U.window.Position = UDim2.fromOffset(round(geo.x + (geo.w - w) / 2), round(geo.y + (geo.h - h) / 2))
            end)
        end, function()
            pcall(function()
                U.window.Size = UDim2.fromOffset(geo.w, geo.h)
                U.window.Position = UDim2.fromOffset(geo.x, geo.y)
            end)
            U:RerenderChat()
            U:ScrollBottom()
        end)
    else
        local geo = U:_geometry()
        U._geo = geo
        local vs = U:GetViewport()
        local tx, ty = vs.X - 70, vs.Y - 70
        animate(0.2, function(u)
            local e = u * u                                -- quadratic in
            local w = math.max(48, geo.w - (geo.w - 64) * e)
            local h = math.max(48, geo.h - (geo.h - 64) * e)
            pcall(function()
                U.window.Size = UDim2.fromOffset(round(w), round(h))
                U.window.Position = UDim2.fromOffset(round(geo.x + (tx - geo.x) * e), round(geo.y + (ty - geo.y) * e))
            end)
        end, function()
            U.window.Visible = false
            pcall(function()
                U.window.Size = UDim2.fromOffset(geo.w, geo.h)
                U.window.Position = UDim2.fromOffset(geo.x, geo.y)
            end)
            if U.orb then
                U.orb.Visible = true
                animate(0.16, function(u)
                    local s = 44 + 10 * math.min(1, u * 1.15)
                    pcall(function() U.orb.Size = UDim2.fromOffset(round(s), round(s)) end)
                end, function()
                    pcall(function() U.orb.Size = UDim2.fromOffset(54, 54) end)
                end)
            end
        end)
    end
end

function U:Destroy()
    U.alive = false
    if U.typingTick then pcall(function() U.typingTick:Disconnect() end) end
    if U.gui then pcall(function() U.gui:Destroy() end) end
    NS.Warn("Max GUI closed. Re-execute the script to bring Max back.")
end

------------------------------------------------------------------ send + keys
function U:Send()
    local tb = U.input
    if not tb then return end
    local text = tostring(tb.Text or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if #text == 0 then return end
    tb.Text = ""
    NS.API.SendUserMessage(text)
end

function U:BindKeys()
    local UIS = NS.Service("UserInputService")
    if not UIS or not UIS.InputBegan then return end
    UIS.InputBegan:Connect(function(input, gameProcessed)
        pcall(function()
            if input.UserInputType ~= Enum.UserInputType.Keyboard then return end
            local focused = UIS:GetFocusedTextBox()
            if focused == U.input then
                if input.KeyCode == Enum.KeyCode.Return then
                    U:Send()
                elseif input.KeyCode == Enum.KeyCode.Escape then
                    focused:ReleaseFocus()
                end
            elseif input.KeyCode == Enum.KeyCode.M and (UIS:IsKeyDown(Enum.KeyCode.LeftAlt) or UIS:IsKeyDown(Enum.KeyCode.RightAlt)) then
                U:SetVisible(not U.window.Visible)
            end
        end)
    end)
end

function U:AttachHooks()
    NS.Hooks.OnAppend = function(role, text, sub)
        if U.alive then U:AddBubble(role, text, sub) end
    end
    NS.Hooks.OnToolNote = function(name, args)
        if U.alive then U:AddToolNote(name, args) end
    end
    NS.Hooks.OnTyping = function(on) if U.alive then U:SetTyping(on) end end
    NS.Hooks.OnTask = function(txt, det) if U.alive then U:SetTask(txt, det) end end
    NS.Hooks.OnExecCode = function(args, result) if U.alive then U:AddExecView(args, result) end end
    NS.Hooks.OnMeta = function(text) if U.alive then U:AddMetaLine(tostring(text)) end end
    NS.Hooks.OnStatus = function(ok, err) if U.alive then U:SetStatus(ok, err) end end
    NS.Hooks.OnDiag = function(d) if U.alive then U:SetDiag(d) end end
    NS.Hooks.OnError = function(msg) if U.alive then U:Toast("⚠ " .. tostring(msg)) else NS.Warn(msg) end end
    NS.Hooks.OnConvs = function() if U.alive then U:RebuildSidebar() end end
end
