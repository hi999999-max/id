local NS = MaxNS
local S = {}
NS.Settings = S

local DEFAULTS = {
    apiBase = "https://REPLACE-ME/max",   -- your reverse-proxied Max backend URL (see README §2)
    apiKey = "",                          -- per-device Max key (backend config max_keys); never the FreeLLMAPI key
    device = "",                          -- stable random device id (generated once)
    diagBar = false,                      -- legacy switch; the bottom diag line was removed (header still shows the model)
    indexEnabled = true,                  -- build the environment index for tools
    maxToolRounds = 20,                   -- tool-calling loop budget per user message
    trBumped = false,                     -- internal: old devices persisted 8 as the default; bumped once to 20
    execBumped = false,                   -- internal: devices that saved execMaxAttempts=2 get bumped once to 8
    execEnabled = true,                   -- lets the AI run Luau in your client via the execute_code tool
    autoContinue = 2,                     -- extra rounds the AI gets to FINISH an interrupted task before it must report
    modelTier = "auto",                   -- auto | smart | reliable | balanced: which FreeLLMAPI strategy answers (auto = per-message choice)
    learningEnabled = true,               -- memory fact-extraction + auto knowledge notes from chats (off = nothing learned automatically)
    execMaxAttempts = 8,                  -- execute_code attempts per message (Settings tab: 1..32; mirrored + enforced by the backend)
    apiDumpAt = 0,                        -- internal: when the API reference cache was last (re)fetched
    apiDumpFailAt = 0,                    -- internal: last failed refresh — backs off a day, keeps serving the old cache
    mobile = nil,                         -- nil = auto-detect
    fontSize = nil,
    windowPos = nil,
    windowSize = nil,
    theme = "dark",
}
S.Defaults = DEFAULTS

function S.Init()
    local loaded = NS.Storage.LoadJson("settings.json")
    -- one-time migration: builds before the bump persisted the old default of
    -- 8, which users felt as "the AI stops after 8 tools". Raise it once;
    -- anyone who deliberately set a different number is left alone.
    local bumped = false
    if loaded and loaded.maxToolRounds == 8 and loaded.trBumped ~= true then
        loaded.maxToolRounds = 20
        loaded.trBumped = true
        bumped = true
    end
    -- same trap one round later: the build shipped for a few hours persisted
    -- execMaxAttempts=2 as ITS default; that stale 2 must not shadow the new 8.
    if loaded and loaded.execMaxAttempts == 2 and loaded.execBumped ~= true then
        loaded.execMaxAttempts = 8
        loaded.execBumped = true
        bumped = true
    end
    S.v = {}
    for k, d in pairs(DEFAULTS) do
        local v = d
        if loaded and loaded[k] ~= nil then v = loaded[k] end
        S.v[k] = v
    end
    S.file = loaded
    if bumped then S.Save() end
    if not S.v.device or S.v.device == "" then
        math.randomseed(os.time() + (os.clock and math.floor(os.clock() * 1000) or 0))
        local s = ""
        for _ = 1, 16 do
            s = s .. string.format("%x", math.random(0, 15))
        end
        S.v.device = "max-" .. s
        S.Save()
    end
end

function S.Get(k) return S.v[k] end

-- execute_code attempts per user message. User-editable in the Settings tab
-- (stepper, 1..32, default 8). Clamped + coerced here so a hand-edited or
-- string-typed settings.json value can never wedge the loop; EVERY consumer
-- (budget gate, notes, prompt context, backend request, UI) reads through
-- this one function.
function S.ExecCap()
    local f = tonumber(S.v and S.v.execMaxAttempts)
    if not f then f = DEFAULTS.execMaxAttempts end
    f = math.floor(f)
    if f < 1 then f = 1 elseif f > 32 then f = 32 end
    return f
end

function S.Set(k, v)
    if S.v[k] == v then return end
    S.v[k] = v
    S.Save()
end

function S.Save()
    local enc = NS.JSON.Encode(S.v)
    if enc then NS.Storage.Write("settings.json", enc) end
end
