--[[ JSON layer: prefers the executor's native JSONEncode/JSONDecode, falls
     back to a compact pure-Lua implementation so Max still works on bare
     executors without them. Pure-decoder contract: okFirst returns. ]]
local NS = MaxNS
local JSON = {}

local haveNative = (type(JSONEncode) == "function") and (type(JSONDecode) == "function")

-------------------------------------------------------------------- encode
local escMap = {
    ['"'] = '\\"', ['\\'] = '\\\\', ['\b'] = '\\b', ['\f'] = '\\f',
    ['\n'] = '\\n', ['\r'] = '\\r', ['\t'] = '\\t',
}
local function escStr(s)
    return (s:gsub('[%c"\\]', function(c) return escMap[c] or string.format('\\u%04x', string.byte(c)) end))
end

local function isSparse(t)
    local n = 0
    for _ in pairs(t) do n = n + 1 end
    return n ~= #t
end

local encodeVal
local function encodeTbl(t, seen)
    if seen[t] then return "null" end
    seen[t] = true
    local parts = {}
    local isArray = #t > 0 and not isSparse(t)
    if isArray then
        for i = 1, #t do parts[#parts + 1] = encodeVal(t[i], seen) end
        seen[t] = nil
        return "[" .. table.concat(parts, ",") .. "]"
    end
    for k, v in pairs(t) do
        local ks
        if type(k) == "string" then ks = escStr(k)
        elseif type(k) == "number" then ks = string.format("%.14g", k)
        else ks = tostring(k) end
        parts[#parts + 1] = '"' .. ks .. '":' .. encodeVal(v, seen)
    end
    seen[t] = nil
    return "{" .. table.concat(parts, ",") .. "}"
end

encodeVal = function(v, seen)
    local tv = type(v)
    if tv == "string" then return '"' .. escStr(v) .. '"' end
    if tv == "number" then
        if v ~= v or v == math.huge or v == -math.huge then return "null" end
        return string.format("%.14g", v)
    end
    if tv == "boolean" then return tostring(v) end
    if tv == "table" then return encodeTbl(v, seen) end
    return "null"
end

-------------------------------------------------------------------- decode
-- decodeVal(s, i) -> ok, value, newPos   (ok=false, nil, errString)

local function skipWs(s, i)
    while i <= #s do
        local c = string.byte(s, i)
        if c == 32 or c == 9 or c == 10 or c == 13 then i = i + 1 else break end
    end
    return i
end

local function decodeString(s, i)
    local buf = {}
    i = i + 1
    while true do
        if i > #s then return false, "unterminated string" end
        local c = string.byte(s, i)
        if c == 34 then
            return true, table.concat(buf), i + 1
        elseif c == 92 then
            local e = string.sub(s, i + 1, i + 1)
            local simple = { ['"'] = '"', ["\\"] = "\\", ["/"] = "/", b = "\b", f = "\f", n = "\n", r = "\r", t = "\t" }
            if e == "u" then
                local cp = tonumber(string.sub(s, i + 2, i + 5), 16)
                if not cp then return false, "bad \\u escape" end
                if cp < 0x80 then
                    buf[#buf + 1] = string.char(cp)
                elseif cp < 0x800 then
                    buf[#buf + 1] = string.char(0xC0 + math.floor(cp / 0x40), 0x80 + cp % 0x40)
                else
                    buf[#buf + 1] = string.char(0xE0 + math.floor(cp / 0x1000),
                        0x80 + math.floor(cp / 0x40) % 0x40, 0x80 + cp % 0x40)
                end
                i = i + 6
            elseif simple[e] then
                buf[#buf + 1] = simple[e]
                i = i + 2
            else
                return false, "bad escape"
            end
        elseif c < 32 then
            return false, "control char in string"
        else
            buf[#buf + 1] = string.char(c)
            i = i + 1
        end
    end
end

local decodeVal
local function decodeSeq(s, i, closeByte, isObj)
    local out = {}
    i = skipWs(s, i + 1)
    if string.byte(s, i) == closeByte then return true, out, i + 1 end
    while true do
        local key = nil
        if isObj then
            i = skipWs(s, i)
            if string.byte(s, i) ~= 34 then return false, "expected key" end
            local ok, k, ni = decodeString(s, i)
            if not ok then return false, k end
            key = k
            i = skipWs(s, ni)
            if string.byte(s, i) ~= 58 then return false, "expected colon" end
            i = i + 1
        end
        local ok, val, pos = decodeVal(s, i)
        if not ok then return false, val end
        if isObj then out[key] = val else out[#out + 1] = val end
        i = skipWs(s, pos)
        local d = string.byte(s, i)
        if d == 44 then
            i = i + 1
        elseif d == closeByte then
            return true, out, i + 1
        else
            return false, isObj and "expected , or }" or "expected , or ]"
        end
    end
end

decodeVal = function(s, i)
    i = skipWs(s, i)
    local c = string.byte(s, i)
    if not c then return false, "eof" end
    if c == 123 then return decodeSeq(s, i, 125, true) end
    if c == 91 then return decodeSeq(s, i, 93, false) end
    if c == 34 then return decodeString(s, i) end
    if s:sub(i, i + 3) == "true" then return true, true, i + 4 end
    if s:sub(i, i + 4) == "false" then return true, false, i + 5 end
    if s:sub(i, i + 3) == "null" then return true, nil, i + 4 end
    if c == 45 or (c >= 48 and c <= 57) then
        local numStr = s:match("^-?%d+%.?%d*[eE]?[+-]?%d*", i)
        if not numStr then return false, "bad number" end
        return true, tonumber(numStr), i + #numStr
    end
    return false, "unexpected char"
end

JSON.Encode = function(t)
    if haveNative then
        local ok, res = NS.Try(JSONEncode, t)
        if ok and type(res) == "string" then return res end
    end
    local ok, res = NS.Try(encodeTbl, (type(t) == "table" and t) or {}, {})
    if ok then return res end
    return nil, res
end

JSON.Decode = function(s)
    if type(s) ~= "string" then return nil, "not a string" end
    if haveNative then
        local ok, res = NS.Try(JSONDecode, s)
        if ok and type(res) == "table" then return res end
    end
    local ok, val, pos = decodeVal(s, 1)
    if not ok then return nil, val end
    if val == nil or type(val) ~= "table" then
        -- top level must be an object/array for our use
        return val
    end
    return val
end

-- Decode tolerant of surrounding prose: grabs the first balanced {...} or [...]
JSON.DecodeLoose = function(s)
    if type(s) ~= "string" then return nil end
    local direct = JSON.Decode(s)
    if type(direct) == "table" then return direct end
    local a1 = s:find("{", 1, true)
    local b1 = s:find("[", 1, true)
    local start
    if a1 and b1 then start = math.min(a1, b1) elseif a1 then start = a1 else start = b1 end
    if not start then return nil end
    local openC = string.sub(s, start, start)
    local closeC = openC == "{" and "}" or "]"
    local depth, inStr, esc = 0, false, false
    for i = start, #s do
        local c = string.sub(s, i, i)
        if inStr then
            if esc then esc = false
            elseif c == "\\" then esc = true
            elseif c == '"' then inStr = false end
        else
            if c == '"' then inStr = true
            elseif c == openC then depth = depth + 1
            elseif c == closeC then
                depth = depth - 1
                if depth == 0 then
                    return JSON.Decode(s:sub(start, i))
                end
            end
        end
    end
    return nil
end

NS.JSON = JSON
