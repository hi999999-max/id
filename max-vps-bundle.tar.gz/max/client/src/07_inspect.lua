--[[ Roblox environment intelligence — hybrid retrieval.

     Tier 1: a lightweight, incrementally-built INDEX of accessible instances
             (path, name, class, depth). Capped, TTL'd, frame-budgeted.
     Tier 2: search the index (cheap, no Instance walking per query).
     Tier 3: fetch detail on demand (children/descendants/properties/attrs),
             paginated and size-limited.

     Read-only by design: Max only ever reads properties/attributes; it never
     writes, fires, parents, or clones. Bulk property reads use getproperties
     / get_properties ONLY if the executor actually provides one (feature
     detected), and results are labelled so the model knows a property came
     from bulk read vs individual read vs "not readable on this executor". ]]
local NS = MaxNS
local INS = {}
NS.Inspect = INS

local CFG = {
    MaxEntries = 4000,     -- index size cap
    ChildCap = 250,        -- children explored per node
    Depth = 6,             -- default BFS depth under each service
    WorkspaceDepth = 9,
    ResultLimit = 25,
    MaxResultLimit = 50,
    TtlSeconds = 60,       -- index freshness
    EnsureRebuildSeconds = 600, -- searches only force a rebuild when the index is OLDER than this (a background refresher keeps it warm)
    YieldEvery = 300,      -- frame budget while walking
}
INS.Cfg = CFG

local ALIASES = {
    workspace = "Workspace", game = "DataModel", data = "DataModel", datamodel = "DataModel",
    players = "Players", lightservice = "Lighting", lighting = "Lighting",
    rep = "ReplicatedStorage", replicated = "ReplicatedStorage", repstorage = "ReplicatedStorage",
    starter = "StarterPlayer", startergui = "StarterGui", runtimeservice = "RunService",
    gui = "CoreGui", core = "CoreGui", sound = "SoundService", soundsservice = "SoundService",
}

local function services()
    local ok, list = NS.Try(function() return game:GetChildren() end)
    return (ok and type(list) == "table" and list) or {}
end

function INS.ResolveService(name)
    local target = ALIASES[string.lower(tostring(name or ""))] or tostring(name or "")
    for _, s in ipairs(services()) do
        local ok, n = NS.Try(function() return s.Name end)
        if ok and (n == target or string.lower(tostring(n)) == string.lower(target)) then
            return s
        end
    end
    local svc = NS.Service(target)
    if svc then
        local okName, real = NS.Try(function() return svc.Name end)
        if okName then return svc end
    end
    return nil
end

function INS.ResolvePath(pathStr)
    pathStr = tostring(pathStr or ""):gsub("^game%.", ""):gsub("^%.+", "")
    local segs = {}
    for seg in pathStr:gmatch("[^%.]+") do segs[#segs + 1] = seg end
    if #segs == 0 then return nil, "empty path" end
    local first = segs[1]
    local node = INS.ResolveService(first)
    if not node then
        node = workspace -- tolerate "Workspace..." lowercase etc.
        local okName, real = NS.Try(function() return workspace.Name end)
        if okName and string.lower(real or "") ~= string.lower(first) then
            return nil, "unknown root service: " .. first
        end
        table.remove(segs, 1)
    else
        table.remove(segs, 1)
    end
    for _, seg in ipairs(segs) do
        local found = nil
        local ok, kids = NS.Try(function() return node:GetChildren() end)
        if ok and type(kids) == "table" then
            for _, k in ipairs(kids) do
                local okN, n = NS.Try(function() return k.Name end)
                if okN and n == seg then found = k break end
            end
        end
        if not found then
            local okF, child = NS.Try(function() return node:FindFirstChild(seg) end)
            if okF and child then found = child end
        end
        if not found then return nil, "not found at segment: " .. seg end
        node = found
    end
    return node
end

local function safeName(i) local _, n = NS.Try(function() return i.Name end) return n or "?" end
local function safeClass(i) local _, c = NS.Try(function() return i.ClassName end) return c or "?" end
local function safeFullName(i)
    local ok, f = NS.Try(function() return i:GetFullName() end)
    if ok and type(f) == "string" then return f end
    return nil
end

function INS.Stringify(v)
    local t = type(v)
    if t == "string" then return (v:len() > 240 and (v:sub(1, 240) .. "…") or v) end
    if t == "number" then return string.format("%.10g", v) end
    if t == "boolean" then return tostring(v) end
    if t == "function" then return "<function>" end
    if t == "thread" then return "<thread>" end
    if t == "userdata" then
        -- CFrame/Vector3/Color3/UDim2 are userdata too. The old code returned
        -- "<userdata>" whenever isinstancesupported said "not an instance",
        -- which hid every position/size from the model ("unreadable"). Only
        -- real instances collapse to <Instance ...>; everything else keeps
        -- its tostring so numeric components survive.
        local okC, iCls = NS.Try(function() return v.ClassName end)
        local looksInstance = okC and type(iCls) == "string" and iCls:len() > 0
        local isInst = looksInstance
        if type(isinstancesupported) == "function" then
            local okI, r = NS.Try(isinstancesupported, v)
            if okI and r == true then isInst = true end
        end
        if isInst then
            return "<Instance " .. tostring(safeName(v)) .. " : " .. tostring(iCls) .. ">"
        end
        local ok, s = NS.Try(tostring, v)
        if ok and type(s) == "string" and s:len() > 0 and not s:find("^userdata:") then
            return (s:len() > 160 and (s:sub(1, 160) .. "…") or s)
        end
        return "<userdata>"
    end
    if t == "table" then
        local n = 0
        for _ in pairs(v) do n = n + 1 end
        return "#table(" .. n .. ")"
    end
    return "<" .. t .. ">"
end

------------------------------------------------------------------ index build
INS.State = { Status = "idle", Built = 0, StartedAt = 0, DoneAt = 0 }

local function resetIndex()
    INS.entries = {}          -- {id, inst, name, class, path, parentPath, depth, service}
    INS.byName = {}            -- lower name -> {ids}
    INS.byClass = {}           -- lower class -> {ids}
    INS.nextId = 1
end

function INS.Build(force)
    if not NS.Settings.Get("indexEnabled") then
        INS.State.Status = "disabled"
        return false
    end
    if INS.entries and not force then
        if os.time() - INS.State.DoneAt < CFG.TtlSeconds then return true end
    end
    INS.Building = true
    resetIndex()
    local t0 = os.clock()
    INS.State = { Status = "building", Built = 0, StartedAt = t0 }
    local count = 0
    local queue = {}
    for _, svc in ipairs(services()) do
        local nm = safeName(svc)
        queue[#queue + 1] = { inst = svc, name = nm, lname = nm:lower(), class = safeClass(svc), depth = 0, service = nm, pid = nil }
    end
    local idx = 1
    while idx <= #queue and count < CFG.MaxEntries do
        local parent = queue[idx]
        idx = idx + 1
        if parent then
            count = count + 1
            local id = INS.nextId
            INS.nextId = id + 1
            -- NOTE: entries deliberately do NOT carry full path strings — building
            -- "A.B.C" per node dominated the walk. Paths are reconstructed lazily
            -- (PathOf) for the handful of rows that are actually shown.
            local entry = { id = id, inst = parent.inst, name = parent.name, lname = parent.lname,
                            class = parent.class, depth = parent.depth, service = parent.service, pid = parent.pid }
            INS.entries[id] = entry
            INS.byName[parent.lname] = INS.byName[parent.lname] or {}
            table.insert(INS.byName[parent.lname], id)
            local lc = parent.class:lower()
            INS.byClass[lc] = INS.byClass[lc] or {}
            table.insert(INS.byClass[lc], id)
            local maxDepth = (parent.service == "Workspace" or parent.service == "workspace") and CFG.WorkspaceDepth or CFG.Depth
            if parent.depth < maxDepth then
                local ok, kids = NS.Try(function() return parent.inst:GetChildren() end)
                if ok and type(kids) == "table" then
                    for i = 1, math.min(#kids, CFG.ChildCap) do
                        local k = kids[i]
                        local kn = safeName(k)
                        queue[#queue + 1] = {
                            inst = k, name = kn, lname = kn:lower(),
                            class = safeClass(k), depth = parent.depth + 1, service = parent.service, pid = id,
                        }
                    end
                end
            end
        end
        if count % CFG.YieldEvery == 0 then NS.Wait(0.01) end
    end
    INS.State = {
        Status = count >= CFG.MaxEntries and "capped" or "ready",
        Built = count, StartedAt = t0, DoneAt = os.time(),
        Truncated = count >= CFG.MaxEntries,
    }
    INS.Building = false
    NS.Warn(string.format("environment index: %d instances%s", count,
        INS.State.Truncated and (" (capped at " .. CFG.MaxEntries .. ")") or ""))
    return true
end

function INS.Ensure()
    if INS.Building then return true end
    if not INS.entries or next(INS.entries) == nil then
        INS.Build(true)
    elseif os.time() - (INS.State.DoneAt or 0) > CFG.EnsureRebuildSeconds then
        INS.Build(true)
    end
    return true
end

-- Reconstruct "Service.Child.Grandchild" from the parent-id chain (lazy: only
-- for rows that are returned, never during the walk itself).
function INS.PathOf(id)
    local segs, guard = {}, 0
    while id and guard < 40 do
        local e = INS.entries and INS.entries[id]
        if not e then break end
        segs[#segs + 1] = e.name
        id = e.pid
        guard = guard + 1
    end
    local out = {}
    for i = #segs, 1, -1 do out[#out + 1] = segs[i] end
    return table.concat(out, ".")
end

------------------------------------------------------------------ search
local function clampLimit(v, dflt)
    v = tonumber(v) or dflt or CFG.ResultLimit
    if v < 1 then v = 1 end
    if v > CFG.MaxResultLimit then v = CFG.MaxResultLimit end
    return math.floor(v)
end

-- One bounded pass over the index: name/path substring, class, service
-- filters; exact name matches sort first. No Instance walking needed here.
function INS.Search(opts)
    INS.Ensure()
    opts = opts or {}
    local q = opts.query and string.lower(tostring(opts.query)) or nil
    local clsF = opts.class and string.lower(tostring(opts.class)) or nil
    local svcF = opts.service and string.lower(tostring(opts.service)) or nil
    local limit = clampLimit(opts.limit)
    local page = math.max(1, math.floor(tonumber(opts.page) or 1))
    local exact, partial, total = {}, {}, 0
    local function ancMatch(e)
        -- cheap "inside a matching folder" support without storing path strings:
        -- walk the ≤9-deep parent chain comparing lowercase names, with a
        -- per-query memo keyed by the query string (safe across interleaved queries).
        local id, guard = e.pid, 0
        while id and guard < 12 do
            local p = INS.entries[id]
            if not p then break end
            if p.qhitQ == q then
                if p.qhit then return true end
            else
                local hit = p.lname:find(q, 1, true) ~= nil
                p.qhitQ, p.qhit = q, hit
                if hit then return true end
            end
            id = p.pid
            guard = guard + 1
        end
        return false
    end
    local lower = string.lower
    for id, e in pairs(INS.entries or {}) do
        local ename = e.lname or ""
        local okQ = (not q) or ename == q or ename:find(q, 1, true) ~= nil or ancMatch(e)
        local ecls = lower(e.class or "")
        local okC = (not clsF) or ecls == clsF or ecls:find(clsF, 1, true) ~= nil
        local okS = true
        if svcF then
            if e._lsvc ~= e.service then -- (re)compute lowercase only when the service string changed
                e._lsvc = e.service
                e._lsvcVal = lower(e.service or "")
            end
            okS = e._lsvcVal:find(svcF, 1, true) ~= nil
        end
        if okQ and okC and okS then
            total = total + 1
            if q and ename == q then
                exact[#exact + 1] = id
            elseif #partial < 400 then
                partial[#partial + 1] = id
            end
        end
    end
    local all = {}
    for _, r in ipairs(exact) do all[#all + 1] = r end
    for _, r in ipairs(partial) do all[#all + 1] = r end
    local matched = {}
    for i = (page - 1) * limit + 1, math.min(#all, (page - 1) * limit + limit) do
        local e = INS.entries[all[i]]
        if e then
            matched[#matched + 1] = { path = INS.PathOf(all[i]), name = e.name, class = e.class, depth = e.depth }
        end
    end
    return { ok = true, total = total, page = page, pageSize = limit,
             items = matched, index = { built = INS.State.Built, status = INS.State.Status } }
end

function INS.GetChildren(opts)
    local inst, err = INS.ResolvePath(opts.path)
    if not inst then return { ok = false, error = err } end
    local limit = clampLimit(opts.limit)
    local page = math.max(1, math.floor(tonumber(opts.page) or 1))
    local ok, kids = NS.Try(function() return inst:GetChildren() end)
    if not ok or type(kids) ~= "table" then return { ok = false, error = "GetChildren unsupported here" } end
    local items, total = {}, #kids
    for i = (page - 1) * limit + 1, math.min(total, page * limit) do
        local k = kids[i]
        if k then
            local rootPath = safeFullName(inst) or tostring(opts.path)
            items[#items + 1] = { name = safeName(k), class = safeClass(k), path = rootPath .. "." .. safeName(k) }
        end
    end
    return { ok = true, parent = opts.path, total = total, page = page, pageSize = limit, items = items }
end

function INS.GetDescendants(opts)
    local inst, err = INS.ResolvePath(opts.path)
    if not inst then return { ok = false, error = err } end
    local limit = clampLimit(opts.limit)
    local depthCap = math.floor(tonumber(opts.depth) or 4)
    local clsF = opts.class and string.lower(tostring(opts.class)) or nil
    local out, total, visited = {}, 0, 0
    local queue = { { inst, 0 } }
    local qi = 1
    while qi <= #queue and visited < 3000 do
        local qe = queue[qi]
        local node, d = qe[1], qe[2]
        qi = qi + 1
        visited = visited + 1
        if d > 0 and (not clsF or safeClass(node):lower() == clsF or safeClass(node):lower():find(clsF, 1, true)) then
            total = total + 1
            if total > limit then
                queue = {}
                break
            end
            local fn = safeFullName(node) or (opts.path .. "?" .. tostring(visited))
            out[#out + 1] = { path = fn, name = safeName(node), class = safeClass(node) }
        end
        if d < depthCap then
            local ok, kids = NS.Try(function() return node:GetChildren() end)
            if ok and type(kids) == "table" then
                for i = 1, math.min(#kids, CFG.ChildCap) do
                    queue[#queue + 1] = { kids[i], d + 1 }
                end
            end
        end
        if visited % CFG.YieldEvery == 0 then NS.Wait(0.02) end
    end
    return { ok = true, root = opts.path, count = #out, truncated = total > limit, items = out }
end

------------------------------------------------------------------ properties
local COMMON_PROPS = {
    base = { "Name", "ClassName", "Archivable", "Parent" },
    Instance = {},
    BasePart = { "Position", "Size", "CFrame", "Anchored", "CanCollide", "Transparency", "Color", "Material", "Reflectance", "Massless", "Velocity", "TopSurface", "BottomSurface" },
    Part = { "Position", "Size", "CFrame", "Anchored", "CanCollide", "Transparency", "Color", "Material" },
    Model = { "PrimaryPart", "WorldPivot" },
    Folder = {},
    Script = { "Disabled", "LinkedSource" },
    LocalScript = { "Disabled" },
    ModuleScript = { "Disabled" },
    GuiBase2d = { "Visible", "ZIndex", "Active", "Locked" },
    Frame = { "Position", "Size", "BackgroundColor3", "BackgroundTransparency", "BorderSizePixel", "Visible" },
    TextBox = { "Text", "PlaceholderText", "TextSize", "TextColor3", "Font", "MultiLine", "Editable" },
    TextLabel = { "Text", "TextSize", "TextColor3", "Font", "TextWrapped", "TextXAlignment", "TextYAlignment" },
    TextButton = { "Text", "TextSize", "TextColor3", "AutoButtonColor", "Modal" },
    ImageLabel = { "Image", "ImageColor3", "ImageTransparency", "ScaleType" },
    ImageButton = { "Image", "ImageColor3", "ImageTransparency", "HoverImage" },
    ScreenGui = { "Enabled", "ResetOnSpawn", "IgnoreGuiInset", "ZIndexBehavior", "DisplayOrder" },
    Humanoid = { "Health", "MaxHealth", "WalkSpeed", "JumpPower", "JumpHeight", "FloorMaterial" },
    CharacterAppearance = {},
    Accessory = {},
    Decal = { "Texture" },
    Sound = { "Playing", "TimePosition", "Volume", "Pitch", "Looped" },
    Animation = { "AnimationId" },
    Airplane = {},
    PointLight = { "Brightness", "Color", "Range", "Shadows" },
    SpawnLocation = { "TeamColor", "Neutral" },
    UnionOperation = { "AssetId" },
}
do
    -- children of BasePart-ish classes inherit their prop lists
    COMMON_PROPS.SpawnLocation = COMMON_PROPS.SpawnLocation
    for _, k in ipairs({ "UnionOperation", "MeshPart", "FileMesh", "WedgePart", "TrussPart", "JointInstance" }) do
        COMMON_PROPS[k] = COMMON_PROPS.Part
    end
end
local CLASS_FALLBACK = {
    Part = "BasePart", SpawnLocation = "SpawnLocation", MeshPart = "BasePart", UnionOperation = "BasePart",
    WedgePart = "BasePart", Frame = "GuiBase2d", ImageLabel = "GuiBase2d", ImageButton = "GuiBase2d",
    TextLabel = "GuiBase2d", TextButton = "GuiBase2d", TextBox = "GuiBase2d", BillboardGui = "GuiBase2d",
}

function INS.Properties(inst, wantNames)
    local result = { values = {}, unreadable = {}, missing = {} }
    local bulkFn = NS.Env.GetProps
    local wanted
    if wantNames and #wantNames > 0 then
        wanted = {}
        for _, w in ipairs(wantNames) do
            if type(w) == "string" then wanted[w:lower()] = w end
        end
    end
    if bulkFn then
        local props
        -- signatures differ across executors: try (inst, includeHidden) then (inst)
        local ok1, r1 = NS.Try(bulkFn, inst, true)
        if ok1 and type(r1) == "table" then
            props = r1
        else
            local ok2, r2 = NS.Try(bulkFn, inst)
            if ok2 and type(r2) == "table" then props = r2 end
        end
        if props then
            local n = 0
            local function put(name, val)
                if type(name) ~= "string" then return end
                if wanted and not wanted[name:lower()] then return end
                result.values[name] = INS.Stringify(val)
                n = n + 1
            end
            -- normalize: map form {name = value} OR array form { {Name=..., Value=...}, ... }
            if #props > 0 and type(props[1]) == "table" and props[1].Name then
                for _, row in ipairs(props) do put(row.Name, row.Value) end
            else
                for name, val in pairs(props) do put(name, val) end
            end
            if n > 0 then
                result.method = "bulk(" .. (NS.Env.GetPropsName or "getproperties") .. ")"
                result.count = n
                if wanted then
                    -- names the snapshot lacked: individual reads as fallback
                    for _, w in ipairs(wantNames) do
                        if type(w) == "string" and result.values[w] == nil then
                            local okR, v = NS.Try(function() return inst[w] end)
                            if okR then
                                result.values[w] = INS.Stringify(v)
                                result.count = result.count + 1
                            else
                                result.missing[#result.missing + 1] = w
                            end
                        end
                    end
                end
                return result
            end
        end
    end
    -- individual reads
    local names = wantNames
    if not names or #names == 0 then
        names = {}
        local cls = safeClass(inst)
        local seen = {}
        local chain = { cls }
        local fb = CLASS_FALLBACK[cls]
        if fb then chain[#chain + 1] = fb end
        for _, c in ipairs(chain) do
            for _, p in ipairs(COMMON_PROPS[c] or {}) do
                if not seen[p] then seen[p] = true; names[#names + 1] = p end
            end
        end
        for _, p in ipairs(COMMON_PROPS.base) do
            if not seen[p] then seen[p] = true; names[#names + 1] = p end
        end
    end
    for _, p in ipairs(names) do
        if type(p) == "string" and p:len() < 64 then
            local ok, v = NS.Try(function() return inst[p] end)
            if ok then
                result.values[p] = INS.Stringify(v)
            else
                result.unreadable[#result.unreadable + 1] = p
            end
        end
    end
    result.method = wantNames and "individual(requested)" or "individual(known-set)"
    result.count = 0
    for _ in pairs(result.values) do result.count = result.count + 1 end
    return result
end

function INS.Attributes(inst)
    local out = {}
    local ok, attrs = NS.Try(function() return inst:GetAttributes() end)
    if ok and type(attrs) == "table" then
        for k, v in pairs(attrs) do
            if type(k) == "string" then out[k] = INS.Stringify(v) end
        end
        return { ok = true, attributes = out, count = (function() local n = 0 for _ in pairs(out) do n = n + 1 end return n end)() }
    end
    return { ok = false, error = "GetAttributes unavailable for this instance" }
end

function INS.ServiceInfo(name)
    local svc = INS.ResolveService(name)
    if not svc then return { ok = false, error = "service not found: " .. tostring(name) } end
    local ok, kids = NS.Try(function() return svc:GetChildren() end)
    local count = ok and type(kids) == "table" and #kids or -1
    local hist = {}
    if ok and count > 0 then
        for i = 1, math.min(count, 500) do
            local c = safeClass(kids[i])
            hist[c] = (hist[c] or 0) + 1
        end
    end
    local top = {}
    for c, n in pairs(hist) do top[#top + 1] = { class = c, count = n } end
    table.sort(top, function(a, b) return a.count > b.count end)
    return { ok = true, name = safeName(svc), class = safeClass(svc), children = count,
             classHistogram = top, note = count > 500 and "histogram capped at first 500 children" or nil }
end

function INS.SearchByProperty(opts)
    local prop = tostring(opts.property or "")
    if prop == "" then return { ok = false, error = "property required" } end
    local wantVal = opts.value
    local match = string.lower(tostring(opts.match or (wantVal ~= nil and "exact" or "any")))
    local clsF = opts.class and string.lower(tostring(opts.class)) or nil
    local svcF = opts.service and string.lower(tostring(opts.service)) or nil
    local limit = clampLimit(opts.limit)
    INS.Ensure()
    local items, scanned, total = {}, 0, 0
    local wantStr = wantVal ~= nil and INS.Stringify(wantVal):lower() or nil
    for id, e in pairs(INS.entries or {}) do
        if scanned < 4000 then
            scanned = scanned + 1
            local okC = (not clsF) or e.class:lower() == clsF
            local okS = (not svcF) or string.lower(e.service or ""):find(svcF, 1, true)
            if okC and okS then
                local inst = e.inst
                if inst then
                    local ok, v = NS.Try(function() return inst[prop] end)
                    if ok then
                        local s = INS.Stringify(v):lower()
                        local hit = (match == "any")
                            or (match == "contains" and wantStr and s:find(wantStr, 1, true))
                            or (match == "exact" and s == wantStr)
                        if hit then
                            total = total + 1
                            if #items < limit then
                                items[#items + 1] = { path = INS.PathOf(id), class = e.class, [prop] = INS.Stringify(v) }
                            end
                        end
                    end
                end
            end
            if #items >= limit then break end
        end
    end
    return { ok = true, property = prop, match = match, total = total, scanned = scanned, items = items,
             note = scanned >= 4000 and "scan capped at 4000 indexed instances" or nil }
end

function INS.GetInfo(pathStr, withProps, withAttrs)
    local inst, err = INS.ResolvePath(pathStr)
    if not inst then
        local fallback = INS.Search({ query = tostring(pathStr), limit = 10 })
        return { ok = false, error = err, suggestions = fallback.items }
    end
    local info = {
        ok = true,
        name = safeName(inst),
        class = safeClass(inst),
        path = safeFullName(inst) or tostring(pathStr),
    }
    local okPar, par = NS.Try(function() return inst.Parent end)
    if okPar and par then info.parent = safeName(par) end
    local okN, nc = NS.Try(function() return inst:GetChildren() end)
    if okN and type(nc) == "table" then info.childCount = #nc end
    if withAttrs then
        local a = INS.Attributes(inst)
        info.attributes = a.attributes or {}
    end
    if withProps then
        local p = INS.Properties(inst)
        info.properties = p.values
        info.propertiesMethod = p.method
    end
    return info
end
