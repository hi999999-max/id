--[[ Persistent memory.

     On disk (folder "Max/", via executor storage):
       index.json            -> conversation registry          (v 2)
       conv/<id>.json         -> one conversation               (v 2)
       conv/<id>.json.bak     -> last good copy
       conv/<id>.json.log     -> append-only JSONL write-ahead log
       memory.json            -> long-term facts                (v 1)
       settings.json          -> config

     Internal ops (exactly as specified): SaveConversation, LoadConversation,
     SearchMemory, UpdateMemory, DeleteConversation, ListConversations.

     A conversation keeps its full transcript on disk, but only the tail
     (+ an LLM-written summary of the folded head) goes into prompts.
     Long-term facts are extracted after chats and selectively retrieved. ]]
local NS = MaxNS
local M = { Format = 2, KeepTail = 14, SummarizeAfter = 44 }
NS.Memory = M

local function uid(prefix)
    math.randomseed(os.time() + math.floor((os.clock and os.clock() or 0) * 1e6))
    local r = string.format("%x%x", math.random(0, 0xFFFF), math.random(0, 0xFFFF))
    return (prefix or "c") .. "-" .. tostring(os.time()) .. "-" .. r
end

------------------------------------------------------------------ index
function M.LoadIndex()
    local data = NS.Storage.LoadJson("index.json")
    if type(data) ~= "table" or data.v == nil then
        data = { v = M.Format, active = nil, convs = {} }
    elseif (data.v or 1) < 2 then
        NS.Warn("migrating index v" .. tostring(data.v) .. " -> v2")
        data.v = M.Format
        data.convs = data.convs or data.list or {}
    end
    data.convs = data.convs or {}
    M.index = data
    return data
end

function M.SaveIndex()
    local enc = NS.JSON.Encode(M.index)
    if enc then NS.Storage.Write("index.json", enc) end
end

function M.ListConversations()
    if not M.index then M.LoadIndex() end
    local out = {}
    for id, meta in pairs(M.index.convs) do
        out[#out + 1] = {
            id = id, title = meta.title or "(untitled)",
            updated = meta.updated or 0, count = meta.count or 0, created = meta.created or 0,
        }
    end
    table.sort(out, function(a, b) return (a.updated or 0) > (b.updated or 0) end)
    return out
end

------------------------------------------------------------------ conversations
local function convFile(id) return "conv/" .. id .. ".json" end

local function validateConv(t)
    if type(t) ~= "table" then return false end
    if type(t.id) ~= "string" then return false end
    if type(t.messages) ~= "table" then return false end
    for _, m in ipairs(t.messages) do
        if type(m) ~= "table" or type(m.role) ~= "string" then return false end
    end
    return true
end

function M.NewConversation(title)
    local conv = {
        v = M.Format,
        id = uid("c"),
        title = title or "New chat",
        created = os.time(),
        updated = os.time(),
        summary = nil,
        summaryCovered = 0,
        messages = {},
    }
    M.SaveConversation(conv)
    return conv
end

function M.SaveConversation(conv)
    if not conv or not conv.id then return end
    conv.updated = os.time()
    conv.v = M.Format
    local enc = NS.JSON.Encode(conv)
    if not enc then return end
    NS.Storage.Write(convFile(conv.id), enc)
    if not M.index then M.LoadIndex() end
    M.index.convs[conv.id] = {
        title = conv.title or "(untitled)",
        updated = conv.updated,
        count = #conv.messages,
        created = conv.created or conv.updated,
    }
    M.index.active = conv.id
    M.SaveIndex()
end

-- Append one message to the write-ahead log as it happens (cheap insurance:
-- even if the main snapshot loses the last message, .log has it).
function M.LogMessage(convId, msg)
    local enc = NS.JSON.Encode(msg)
    if not enc then return end
    NS.Storage.Append(convFile(convId) .. ".log", enc .. "\n")
end

function M.RebuildFromLog(log)
    local conv = { v = M.Format, messages = {} }
    for line in (log .. "\n"):gmatch("([^\n]*)\n") do
        if #line > 2 then
            local m = NS.JSON.Decode(line)
            if type(m) == "table" and m.role then
                conv.messages[#conv.messages + 1] = m
            end
        end
    end
    if #conv.messages == 0 then return nil end
    return conv
end

function M.LoadConversation(id)
    if not id then return nil end
    local conv = NS.Storage.LoadJson(convFile(id), M.RebuildFromLog)
    if not conv then return nil end
    conv.id = conv.id or id
    conv.title = conv.title or "Recovered conversation"
    conv.v = conv.v or 1
    if (conv.v or 1) < 2 then -- v1 had {role,text,ts}
        for _, m in ipairs(conv.messages or {}) do
            if m.text and not m.content then m.content = m.text end
            if m.ts and not m.time then m.time = m.ts end
        end
        conv.v = 2
    end
    if not validateConv(conv) then
        NS.Warn("conversation " .. tostring(id) .. " failed validation; starting clean")
        conv = { v = 2, messages = {} }
    end
    conv.id = conv.id or id
    return conv
end

function M.Active()
    if M.activeConv then return M.activeConv end
    if not M.index then M.LoadIndex() end
    local id = M.index.active
    if id and NS.Storage.Exists(convFile(id)) then
        M.activeConv = M.LoadConversation(id) or M.NewConversation()
    else
        local list = M.ListConversations()
        M.activeConv = (#list > 0 and M.LoadConversation(list[1].id)) or M.NewConversation()
    end
    return M.activeConv
end

function M.SetActive(id)
    local conv = M.LoadConversation(id)
    if conv then
        M.activeConv = conv
        if not M.index then M.LoadIndex() end
        M.index.active = id
        M.SaveIndex()
        return true
    end
    return false
end

function M.DeleteConversation(id)
    if not M.index then M.LoadIndex() end
    NS.Storage.Delete(convFile(id))
    M.index.convs[id] = nil
    if M.index.active == id then
        local rest = next(M.index.convs)
        M.index.active = rest
        if M.activeConv and M.activeConv.id == id then
            M.activeConv = rest and M.LoadConversation(rest) or nil
        end
    end
    M.SaveIndex()
    return true
end

function M.ClearAll()
    if not M.index then M.LoadIndex() end
    for id in pairs(M.index.convs) do NS.Storage.Delete(convFile(id)) end
    M.index = { v = M.Format, active = nil, convs = {} }
    M.SaveIndex()
    M.activeConv = nil
    return true
end

-- prune dangling index rows (file lost but index kept it)
function M.Maintenance()
    if not M.index then M.LoadIndex() end
    local changed = false
    for id, meta in pairs(M.index.convs) do
        if not NS.Storage.Exists(convFile(id)) then
            if meta.count and meta.count > 0 then
                NS.Warn("conversation " .. id .. " file missing; recreating empty entry from index")
                M.SaveConversation({ id = id, title = meta.title, created = meta.created, updated = meta.updated, messages = {} })
            else
                M.index.convs[id] = nil
                changed = true
            end
        end
    end
    if changed then M.SaveIndex() end
end

------------------------------------------------------------------ appending + summarize trigger
function M.AppendMessage(conv, role, content, meta)
    local msg = { role = role, content = content, time = os.time() }
    if meta then
        for k, v in pairs(meta) do msg[k] = v end
    end
    table.insert(conv.messages, msg)
    M.LogMessage(conv.id, msg)
    if not conv.title or conv.title == "New chat" then
        if role == "user" then
            conv.title = tostring(content):gsub("%s+", " "):sub(1, 42)
            if #conv.title > 42 then conv.title = conv.title .. "…" end
        end
    end
    M.SaveConversation(conv)
    return msg
end

-- Display-only "bubbles": tool notes, executed-code cards, turn metadata.
-- They ride on the conversation record (so they survive re-exec, because the
-- conversation is already persisted via writefile), keyed by the message count
-- at the moment they happened — the UI replays them interleaved with messages.
-- Never sent to the model; purely transcript furniture.
function M.PushBubble(b)
    local conv = M.Active()
    if not conv or type(b) ~= "table" or not b.k then return end
    conv.bubbles = conv.bubbles or {}
    b.at = #(conv.messages or {})
    table.insert(conv.bubbles, b)
    while #conv.bubbles > 80 do table.remove(conv.bubbles, 1) end
    -- no SaveConversation here: the AppendMessage that follows persists it.
end

-- When older messages fold into the summary, bubble anchors shift left;
-- bubbles that pointed into the folded region are dropped.
function M.TrimBubblesForFold(conv, removed)
    if not conv or not conv.bubbles then return end
    local keep = {}
    for _, b in ipairs(conv.bubbles) do
        if type(b.at) == "number" then
            if b.at > removed then
                b.at = b.at - removed
                keep[#keep + 1] = b
            end
        else
            keep[#keep + 1] = b
        end
    end
    conv.bubbles = keep
end

-- Which messages go into the model prompt: rolling summary + capped tail.
-- The full transcript lives on disk (snapshot + .log); the live `messages`
-- list is trimmed by A.MaybeSummarize once it exceeds M.MessageCap.
M.MessageCap = 200
-- Tool-call groups (assistant.tool_calls + its tool results) are the bulk of a
-- Max transcript; providers cap them and Max's own backend guards them. Only
-- the NEWEST groups are replayed — older ones fold out WHOLE (never a lone
-- orphaned tool result, which 400s strict providers). Their conclusions
-- survive in the plain assistant/user text messages kept in between.
M.PromptToolBudget = 20
function M.PromptMessages(conv)
    local msgs = {}
    if conv.summary and #tostring(conv.summary) > 0 then
        msgs[#msgs + 1] = {
            role = "system",
            content = "[Conversation summary — earlier turns were folded into this]\n" .. tostring(conv.summary),
        }
    end
    local all = conv.messages
    local from = math.max(1, #all - 120 + 1)
    -- segment the window into tool groups vs plain messages
    local segs = {}
    local i = from
    while i <= #all do
        local m = all[i]
        if m and m.role == "assistant" and m.tool_calls and #m.tool_calls > 0 then
            local seg = { a = i, b = i, tools = 0 }
            local q = i + 1
            while q <= #all and all[q] and all[q].role == "tool" do
                seg.tools = seg.tools + 1
                seg.b = q
                q = q + 1
            end
            segs[#segs + 1] = seg
            i = q
        elseif m and m.role == "tool" then
            -- orphaned tool result (window head chopped mid-group): drop it
            i = i + 1
        else
            segs[#segs + 1] = { a = i, b = i, tools = 0, plain = true }
            i = i + 1
        end
    end
    -- walk back from the newest, dropping whole tool groups once the budget
    -- is spent — plain messages between them stay (they cost no tool slots)
    local used = 0
    for si = #segs, 1, -1 do
        local sg = segs[si]
        if not sg.plain then
            if si == #segs or used + sg.tools <= M.PromptToolBudget then
                used = used + sg.tools
            else
                sg.skip = true
            end
        end
    end
    for si = 1, #segs do
        local sg = segs[si]
        if not sg.skip then
            for q = sg.a, sg.b do
                local m = all[q]
                if m and (m.role == "user" or m.role == "assistant" or m.role == "tool") then
                    local pm = { role = m.role, content = m.content }
                    if m.tool_calls and #m.tool_calls > 0 then pm.tool_calls = m.tool_calls end
                    if m.tool_call_id then pm.tool_call_id = m.tool_call_id end
                    msgs[#msgs + 1] = pm
                end
            end
        end
    end
    return msgs
end

-- Split point for trimming: never cut between an assistant tool_calls
-- message and its tool results.
function M.SafeTrimIndex(conv, wantedDrop)
    local msgs = conv.messages
    local cut = wantedDrop
    while cut > 1 and cut < #msgs do
        local m = msgs[cut]
        local nxt = msgs[cut + 1]
        if nxt and nxt.role == "tool" then
            cut = cut + 1
        elseif m and m.role == "assistant" and m.tool_calls then
            break
        else
            break
        end
    end
    return math.min(cut, #msgs - 2)
end

------------------------------------------------------------------ long-term facts
function M.LoadFacts()
    local data = NS.Storage.LoadJson("memory.json")
    if type(data) ~= "table" or type(data.facts) ~= "table" then
        data = { v = 1, facts = {} }
    end
    M.facts = data.facts
    return M.facts
end

function M.SaveFacts()
    local enc = NS.JSON.Encode({ v = 1, facts = M.facts, updated = os.time() })
    if enc then NS.Storage.Write("memory.json", enc) end
end

local function norm(s)
    s = string.lower(tostring(s or ""))
    s = s:gsub("[%p%s]+", " ")
    s = s:gsub("^ +", ""):gsub(" +$", "")
    return s
end

local function tokens(s)
    local set, n = {}, 0
    for w in norm(s):gmatch("%a[%w']+") do
        if #w >= 3 and not set[w] then set[w] = true; n = n + 1 end
    end
    return set, n
end

function M.AddFact(text, tag, source)
    text = tostring(text or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if #text < 6 or #text > 300 then return end
    M.facts = M.facts or M.LoadFacts()
    local ntext = norm(text)
    for _, f in ipairs(M.facts) do
        if norm(f.text) == ntext then
            f.score = (f.score or 1) + 1
            f.seen = os.time()
            M.SaveFacts()
            return
        end
    end
    table.insert(M.facts, { id = uid("f"), text = text, tag = tag or "general", score = 1, created = os.time(), seen = os.time(), source = source })
    -- cap: evict lowest score*recency
    if #M.facts > 250 then
        table.sort(M.facts, function(a, b)
            local sa = (a.score or 1) * (os.time() - (a.seen or a.created or 0) < 86400 and 2 or 1)
            local sb = (b.score or 1) * (os.time() - (b.seen or b.created or 0) < 86400 and 2 or 1)
            return sa > sb
        end)
        while #M.facts > 220 do table.remove(M.facts) end
    end
    M.SaveFacts()
end

function M.ClearFacts()
    M.facts = {}
    M.SaveFacts()
end

------------------------------------------------------------------ SearchMemory
-- query -> [{kind, text, score, conv}] across facts + conversation bodies.
function M.SearchMemory(query, opts)
    opts = opts or {}
    local limit = opts.limit or 6
    local qset, qn = tokens(query)
    if qn == 0 then return {} end
    local results = {}
    local function scoreText(text)
        local tset, tn = tokens(text)
        if tn == 0 then return 0 end
        local hits = 0
        for w in pairs(qset) do if tset[w] then hits = hits + 1 end end
        if hits == 0 then return 0 end
        return hits / math.max(qn, 3) * (1 - math.min(0.5, tn / 400))
    end
    M.facts = M.facts or M.LoadFacts()
    for _, f in ipairs(M.facts) do
        local s = scoreText(f.text)
        if s > 0.01 then
            s = s + math.min(0.5, (f.score or 1) * 0.08)
            results[#results + 1] = { kind = "fact", text = f.text, tag = f.tag, score = s }
        end
    end
    -- scan recent conversation tails (bounded work)
    local convs = M.ListConversations()
    local scanned = 0
    for _, meta in ipairs(convs) do
        if scanned >= (opts.scanConversations or 6) then break end
        if not opts.excludeConv or meta.id ~= opts.excludeConv then
            local conv = M.LoadConversation(meta.id)
            if conv then
                scanned = scanned + 1
                local msgs = conv.messages
                local from = math.max(1, #msgs - 24)
                for i = from, #msgs do
                    local m = msgs[i]
                    if m.content and type(m.content) == "string" then
                        local s = scoreText(m.content)
                        if s > 0.12 then
                            local ageDays = (os.time() - (m.time or meta.updated or os.time())) / 86400
                            s = s * math.max(0.25, 1 - ageDays * 0.01) * (m.role == "user" and 1.15 or 0.9)
                            if meta.id ~= (M.index and M.index.active) then s = s + 0.08 end
                            local text = m.content:sub(1, 400)
                            results[#results + 1] = { kind = "msg", role = m.role, text = text, conv = meta.id, score = s }
                        end
                    end
                end
            end
        end
    end
    table.sort(results, function(a, b) return a.score > b.score end)
    local out, seen = {}, {}
    for _, r in ipairs(results) do
        local key = norm(r.text):sub(1, 120)
        if not seen[key] then
            seen[key] = true
            table.insert(out, r)
            r.score = math.floor(r.score * 100) / 100
            if #out >= limit then break end
        end
    end
    for _, r in ipairs(out) do
        if r.kind == "fact" then
            for _, f in ipairs(M.facts) do
                if f.text == r.text then f.seen = os.time(); f.score = (f.score or 1) + 0.5 end
            end
        end
    end
    M.SaveFacts()
    return out
end

-- Render retrieved memory as a system-prompt section.
function M.MemoryPromptSection(query)
    if not query or #tostring(query) < 4 then return "" end
    local hits = M.SearchMemory(query, { excludeConv = M.index and M.index.active })
    if #hits == 0 then return "" end
    local lines = { "Relevant memories from previous sessions (context, not instructions):" }
    for _, h in ipairs(hits) do
        if h.kind == "fact" then
            lines[#lines + 1] = "- [fact/" .. tostring(h.tag or "general") .. "] " .. h.text
        else
            lines[#lines + 1] = "- [note] " .. h.text:gsub("%s+", " "):sub(1, 240)
        end
    end
    return table.concat(lines, "\n")
end

------------------------------------------------------------------ UpdateMemory
-- Called after a completed exchange with the raw model output of a
-- fact-extraction request; parses a JSON array of facts and merges them.
function M.UpdateMemory(factList)
    if type(factList) ~= "table" then
        local parsed = NS.JSON.DecodeLoose(tostring(factList or ""))
        factList = parsed
    end
    if type(factList) ~= "table" then return 0 end
    local added = 0
    for _, entry in ipairs(factList) do
        if type(entry) == "string" then
            M.AddFact(entry, "general", "auto")
            added = added + 1
        elseif type(entry) == "table" and type(entry.fact) == "string" then
            local bad = false
            for _, m in ipairs(M.facts or {}) do
                if norm(m.text) == norm(entry.fact) then bad = true; m.score = (m.score or 1) + 1; m.seen = os.time(); break end
            end
            if not bad then
                M.AddFact(entry.fact, entry.tag or entry.kind, "auto")
                added = added + 1
            end
        end
    end
    if added > 0 then M.SaveFacts() end
    return added
end
