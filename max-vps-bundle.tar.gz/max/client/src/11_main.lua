--[[ Bootstrap: detect → storage → settings → memory restore → GUI → probe
     transport → health → warm index. Then hand control to the chat engine. ]]
local NS = MaxNS
local Main = { Started = false }
NS.Main = Main

function Main.Start()
    if Main.Started then return end
    Main.Started = true
    local steps = {}

    steps[#steps + 1] = function()
        NS.Env.Detect = NS.Env.Detect or function() end -- env already resolved at load
    end
    steps[#steps + 1] = function() NS.Storage.Init("Max") end
    steps[#steps + 1] = function() NS.Settings.Init() end
    steps[#steps + 1] = function()
        NS.Memory.LoadIndex()
        NS.Memory.Maintenance()
        NS.Memory.LoadFacts()
        NS.Memory.Active() -- restores the last conversation (or starts one)
    end
    steps[#steps + 1] = function() NS.Knowledge.Init() end
    steps[#steps + 1] = function()
        NS.HTTP.BaseUrl = NS.Settings.Get("apiBase")
    end

    local softFail = false
    for _, step in ipairs(steps) do
        local ok, err = NS.Try(step)
        if not ok then
            softFail = true
            NS.Warn("startup step failed: " .. tostring(err))
        end
    end

    -- GUI (a GUI failure must not kill chat: fall back to console-less no-op hooks)
    local guiOk = true
    local uiErr
    NS.Hooks.OnAppend = NS.Hooks.OnAppend or function() end
    NS.Hooks.OnToolNote = NS.Hooks.OnToolNote or function() end
    NS.Hooks.OnTyping = NS.Hooks.OnTyping or function() end
    NS.Hooks.OnTask = NS.Hooks.OnTask or function() end
    NS.Hooks.OnExecCode = NS.Hooks.OnExecCode or function() end
    NS.Hooks.OnMeta = NS.Hooks.OnMeta or function() end
    NS.Hooks.OnStatus = NS.Hooks.OnStatus or function() end
    NS.Hooks.OnDiag = NS.Hooks.OnDiag or function() end
    NS.Hooks.OnError = NS.Hooks.OnError or function(m) NS.Warn("ERR " .. tostring(m)) end
    NS.Hooks.OnConvs = NS.Hooks.OnConvs or function() end
    guiOk, uiErr = NS.Try(function()
        NS.UI.AttachHooks()
        NS.UI.Build()
        NS.UI.BindKeys()
    end)
    if not guiOk then
        NS.Warn("GUI failed to build (" .. tostring(uiErr) .. "); Max runs headless — use Max.Say(\"...\") in your console")
    end

    -- headless fallback API for console use
    NS.Say = function(text)
        if type(text) ~= "string" then return nil, "usage: Max.Say('question')" end
        return NS.API.SendUserMessage(text)
    end

    -- transport + health + index warm-up (async, never blocking)
    NS.Spawn(function()
        local ok = NS.API.Health()
        if not ok and guiOk then
            NS.UI.Toast("backend offline — tap the menu button, open SETTINGS, set Backend URL + Max key")
        end
        -- probe transport via health call already exercised HTTP.Send when a
        -- transport existed; if none was found, HTTP.LastError explains why.
        if NS.HTTP and NS.HTTP.LastError then NS.Warn(NS.HTTP.LastError) end
        NS.Inspect.Build(true)
        -- periodic health check + background index refresher (so a search
        -- never pays for a rebuild itself)
        if not NS.__TestMode then
            NS.Spawn(function()
                while Main.Started do
                    NS.Wait(60)
                    NS.API.Health()
                    local ST = NS.Inspect.State
                    if NS.Settings.Get("indexEnabled") ~= false and ST and (ST.DoneAt or 0) > 0
                       and os.time() - ST.DoneAt > 300 then
                        NS.Inspect.Build(true)
                    end
                end
            end)
        end
    end)

    NS.Storage.Diary("session start · executor=" .. tostring(NS.Env.ExecutorName))
    NS.Warn("Max v" .. NS.Version .. " ready · executor: " .. NS.Env.ExecutorName ..
            " · storage: " .. NS.Storage.Mode .. " · conversation: " .. tostring(NS.Memory.index and NS.Memory.index.active or "new"))
    if softFail then NS.Warn("some startup steps failed; see messages above") end
    return true
end

function Main.Stop()
    Main.Started = false
    NS.Try(function() NS.UI.Destroy() end)
end

-- auto-start on execution (guarded so requiring the file in tests is safe)
if not MaxNS.__NoAutoStart then
    local ok, err = NS.Try(Main.Start)
    if not ok then
        NS.Warn("fatal startup error: " .. tostring(err))
    end
end

return NS
