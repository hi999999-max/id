--[[ Executor HTTP compatibility layer.

     Every executor speaks a slightly different dialect of "make an HTTP
     request". This module:
       1. enumerates candidate functions (known names + runtime discovery),
       2. tries each with the call shapes we know ({Url,Method,...} table,
          lowercase table, positional args),
       3. picks the first combination that survives a live GET /healthz,
       4. normalizes every response to {ok, status, body, headers, err}.

     Transient transport failures get bounded retries with backoff; after 3
     consecutive failures the winner is demoted and the probe re-runs. It can
     never loop forever: probing happens at most once per send, retries are
     capped, and callers always get a structured answer. ]]
local NS = MaxNS
local HTTP = { Ready = false, Transport = nil, LastError = nil, ConsecFails = 0 }
NS.HTTP = HTTP

local SHAPES = { "table", "table_lower", "positional" }

local function buildArgs(shape, req)
    if shape == "table" then
        local t = { Url = req.url, Method = req.method or "GET", Headers = req.headers or {}, Body = req.body }
        if req.timeout then t.RequestTimeout = math.floor(req.timeout) end
        return t
    elseif shape == "table_lower" then
        local t = { url = req.url, method = req.method or "GET", headers = req.headers or {}, body = req.body }
        if req.timeout then t.timeout = math.floor(req.timeout) end
        return t
    else
        return req.url, req.method or "GET", req.headers or {}, req.body
    end
end

local function callRaw(cand, shape, req)
    if shape == "positional" then
        local a, b, c, d = buildArgs(shape, req)
        return cand.fn(a, b, c, d)
    end
    return cand.fn(buildArgs(shape, req))
end

local function normHeaders(h)
    if type(h) ~= "table" then return {} end
    local out = {}
    for k, v in pairs(h) do
        if type(k) == "string" then out[string.lower(k)] = tostring(v) end
    end
    return out
end

local function normalize(res)
    if res == nil or res == false then
        return { ok = false, status = 0, body = "", headers = {}, err = "empty response from transport" }
    end
    if type(res) == "string" then
        -- some old executors hand back just the body
        return { ok = true, status = 200, body = res, headers = {}, err = nil, guessed = true }
    end
    if type(res) ~= "table" then
        return { ok = false, status = 0, body = "", headers = {}, err = "transport returned " .. type(res) }
    end
    local status = tonumber(res.StatusCode or res.statuscode or res.status or res.Status or res.code) or 0
    local body = res.Body or res.body or res.ResponseBody or res.string or ""
    if type(body) ~= "string" then body = tostring(body) end
    return { ok = status > 0, status = status, body = body, headers = normHeaders(res.Headers or res.headers), err = nil }
end

function HTTP.Candidates()
    local list = {}
    local seen = {}
    local discovered = NS.Env.DiscoverHttp and NS.Env.DiscoverHttp() or {}
    -- some executors expose ONLY getgenv-injected functions; include HTTP.BaseUrl default
    -- prefer "table"-shaped staples first: they exist on nearly all modern executors
    local order = { ["syn.request"] = 1, ["http_request"] = 2, ["request"] = 3, ["http.request"] = 4, ["krnl.request"] = 5, ["fluxus.request"] = 6 }
    for _, d in ipairs(discovered) do
        if d.fn and not seen[d.fn] then
            seen[d.fn] = true
            list[#list + 1] = d
        end
    end
    table.sort(list, function(a, b)
        return (order[a.name] or 99) < (order[b.name] or 99)
    end)
    return list
end

-- Low-level single attempt through a specific candidate/shape
function HTTP.Raw(cand, shape, req)
    local ok, res = NS.Try(callRaw, cand, shape, req)
    if not ok then
        return { ok = false, status = 0, body = "", headers = {}, err = tostring(res) }
    end
    return normalize(res)
end

-- Probe a base URL ("http://host:port/prefix") and pick a working transport.
-- Returns true/false. Safe to call again to re-select.
function HTTP.Probe(baseUrl)
    local cands = HTTP.Candidates()
    if #cands == 0 then
        HTTP.LastError = "no executor HTTP request function found (looked for http_request, request, syn.request, http.request, fluxus.request, krnl.request)"
        return false
    end
    local probeUrl = tostring(baseUrl or ""):gsub("/+$", "") .. "/healthz"
    for _, cand in ipairs(cands) do
        for _, shape in ipairs(SHAPES) do
            local r = HTTP.Raw(cand, shape, {
                url = probeUrl, method = "GET",
                headers = { ["Content-Type"] = "application/json", ["X-Max-Probe"] = "1" },
                timeout = 8,
            })
            if r.ok and (r.status == 200 or r.guessed) and (string.find(r.body or "", '"ok"', 1, true) or string.find(r.body or "", "max-backend", 1, true) or r.guessed) then
                HTTP.Ready = true
                HTTP.ConsecFails = 0
                HTTP.Transport = { name = cand.name, shape = shape, fn = cand.fn }
                NS.Warn("HTTP transport: " .. cand.name .. " (" .. shape .. ")")
                return true
            end
        end
    end
    HTTP.LastError = "transport probe failed on every candidate (check the API base URL, TLS, and backend status)"
    return false
end

-- The one send function everyone else uses. req = {url, method, headers, body, timeout}
function HTTP.Send(req)
    req.method = req.method or "GET"
    local attempts = 0
    local lastErr
    local t = HTTP.Transport
    while attempts < 3 do
        attempts = attempts + 1
        if not t then
            local baseUrl = req.baseUrl or HTTP.BaseUrl
            if baseUrl and HTTP.Probe(baseUrl) then
                t = HTTP.Transport
            else
                return { ok = false, status = 0, body = "", headers = {}, err = HTTP.LastError or "no transport selected" }
            end
        end
        local r = HTTP.Raw({ fn = t.fn }, t.shape, req)
        if r.ok then
            HTTP.ConsecFails = 0
            return r
        end
        lastErr = r.err or ("http " .. tostring(r.status))
        if r.status >= 400 then
            -- the request reached the server; retrying at transport level won't help.
            HTTP.ConsecFails = 0
            return r
        end
        HTTP.ConsecFails = HTTP.ConsecFails + 1
        if HTTP.ConsecFails >= 3 and attempts == 1 then
            HTTP.Transport = nil
            HTTP.Ready = false
            NS.Warn("transport " .. tostring(t.name) .. " failing (" .. tostring(lastErr) .. "); will re-probe")
        end
        NS.Wait(0.7 * attempts)
    end
    return { ok = false, status = 0, body = "", headers = {}, err = lastErr or "transport failed" }
end

function HTTP.Get(url, headers) return HTTP.Send({ url = url, method = "GET", headers = headers, timeout = 20 }) end
function HTTP.PostJson(url, obj, headers)
    local body = NS.JSON.Encode(obj)
    if not body then return { ok = false, status = 0, err = "json encode failed" } end
    local h = headers or {}
    h["Content-Type"] = "application/json"
    return HTTP.Send({ url = url, method = "POST", headers = h, body = body, timeout = 150 })
end
