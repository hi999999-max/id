--[[ Verified knowledge: MAX's own notebook of discoveries that WORKED.

     Separate from conversation/user memory (06) on purpose: this stores
     task-shaped facts — "problem -> verified solution" — never chat or
     preferences. Entries are either 'verified' (backed by a successful
     tool result in the conversation that saved them) or 'unverified'
     leads. Retrieval only ever surfaces live-checkable claims, and the
     AI is told to re-validate before relying on one. File: Max/knowledge.json
     through the same atomic Storage layer the rest of Max uses. ]]
local NS = MaxNS
local K = {}
NS.Knowledge = K

K.file = "knowledge.json"
K.Max = 60
K.entries = {}

local STOP = {}
for _, w in ipairs({ "the", "a", "an", "and", "or", "to", "of", "in", "on", "for", "is", "are",
                     "my", "me", "how", "do", "does", "what", "with", "this", "that", "it", "i",
                     "you", "please", "can", "get", "make", "all", "from" }) do STOP[w] = true end

local function tokens(s)
    local out, seen = {}, {}
    for w in tostring(s or ""):lower():gmatch("[%w_]+") do
        if #w >= 3 and not STOP[w] and not seen[w] then
            seen[w] = true
            out[#out + 1] = w
        end
    end
    return out
end

local function now()
    local okT, t = NS.Try(os.time)
    return (okT and type(t) == "number") and t or 0
end

local function save()
    NS.Storage.Write(K.file, NS.JSON.Encode({ ver = 1, entries = K.entries }) or "")
end

function K.Init()
    local d = NS.Storage.LoadJson(K.file)
    K.entries = (d and type(d.entries) == "table") and d.entries or {}
end

-- R17: the WIPE gap — "Delete ALL chats + memory" must erase this store too.
-- Knowledge survives conversations by design; it must NOT survive a user's
-- explicit total-memory deletion. Deleting the file AND the live table means
-- nothing re-loads it on the next boot either.
function K.ClearAll()
    K.entries = {}
    K._n = 0
    NS.Try(function() NS.Storage.Delete(K.file) end)
    return true
end

local function nextId()
    K._n = (K._n or 0) + 1
    return "k" .. tostring(now()) .. "-" .. tostring(K._n)
end

local function evict()
    while #K.entries > K.Max do
        local worst, wi = nil, nil
        for i, e in ipairs(K.entries) do
            local sc = (e.status == "verified" and 100 or 1) + (e.hits or 0) * 2
            if not worst or sc < worst then worst, wi = sc, i end
        end
        if not wi then break end
        table.remove(K.entries, wi)
    end
end

-- similarity of two problems (jaccard over tokens), for auto-capture dedupe
local function similar(a, b)
    local ta, tb = tokens(a), tokens(b)
    if #ta == 0 or #tb == 0 then return 0 end
    local setB = {}
    for _, w in ipairs(tb) do setB[w] = true end
    local inter = 0
    for _, w in ipairs(ta) do if setB[w] then inter = inter + 1 end end
    return inter / (#ta + #tb - inter)
end

-- Add or (when id given) update an entry. e.verified is downgraded to
-- "unverified" unless the CURRENT conversation actually contains a
-- successful tool result — hallucination guard the user asked for.
function K.Add(e)
    if not e or not e.problem or not e.solution or e.problem == "" or e.solution == "" then
        return nil, "problem and solution are required"
    end
    local api = {}
    if type(e.api) == "table" then
        for _, x in ipairs(e.api) do
            if type(x) == "string" and x ~= "" then api[#api + 1] = x:sub(1, 80) end
            if #api >= 8 then break end
        end
    end
    local status = K.HasSuccessEvidence() and "verified" or "unverified"
    if not e.verified then status = "unverified" end
    local patch = {
        problem = tostring(e.problem):sub(1, 300),
        solution = tostring(e.solution):sub(1, 600),
        api = #api > 0 and api or nil,
        evidence = e.evidence and tostring(e.evidence):sub(1, 200) or nil,
        status = status,
    }
    if e.id then
        for _, x in ipairs(K.entries) do
            if x.id == e.id then
                for k2, v in pairs(patch) do x[k2] = v end
                x.updated = now()
                if x.status == "verified" and not K.HasSuccessEvidence() then
                    x.status = "unverified"
                end
                save()
                return x, nil, "updated"
            end
        end
        return nil, "no knowledge entry " .. tostring(e.id)
    end
    for _, x in ipairs(K.entries) do
        if not x.void and similar(x.problem, patch.problem) >= 0.5 then
            for k2, v in pairs(patch) do x[k2] = v end
            x.updated = now()
            save()
            return x, nil, "updated-duplicate"
        end
    end
    local ent = { id = nextId(), created = now(), updated = now(), hits = 0, source = e.source or "manual" }
    for k2, v in pairs(patch) do ent[k2] = v end
    table.insert(K.entries, ent)
    evict()
    save()
    return ent
end

function K.Void(id, reason)
    for _, x in ipairs(K.entries) do
        if x.id == id then
            x.void = true
            x.voidReason = reason and tostring(reason):sub(1, 200) or "invalidated"
            x.updated = now()
            save()
            return x
        end
    end
    return nil
end

function K.Recall(query, k)
    local q = tokens(query)
    if #q == 0 then return {} end
    local scored = {}
    for _, e in ipairs(K.entries) do
        if not e.void then
            local hay = {}
            for _, w in ipairs(tokens(e.problem)) do hay[#hay + 1] = w end
            for _, w in ipairs(tokens(e.solution)) do hay[#hay + 1] = w end
            if e.api then
                for _, a in ipairs(e.api) do
                    for _, w in ipairs(tokens(a)) do hay[#hay + 1] = w end
                end
            end
            local setH = {}
            for _, w in ipairs(hay) do setH[w] = true end
            local m = 0
            for _, w in ipairs(q) do if setH[w] then m = m + 1 end end
            if m > 0 then
                local sc = m / math.max(3, #q) + (e.status == "verified" and 0.25 or 0)
                scored[#scored + 1] = { e = e, score = sc }
                e.hits = (e.hits or 0) + 1
            end
        end
    end
    table.sort(scored, function(a, b) return a.score > b.score end)
    for i = (k or 4) + 1, #scored do scored[i] = nil end
    return scored
end

-- A turn "succeeded" if its recent tool results include an ok:true from a
-- state-changing/verifying tool (execute_code in particular). Read-only tool
-- success alone counts as evidence too: the discovery came from a real run.
function K.HasSuccessEvidence()
    local conv = NS.Memory and NS.Memory.Active and NS.Memory.Active()
    if not conv or type(conv.messages) ~= "table" then return false end
    local start = math.max(1, #conv.messages - 20)
    for i = #conv.messages, start, -1 do
        local m = conv.messages[i]
        if m and m.role == "user" and not (m.meta and m.meta.tool_call_id) then break end
        if m and m.role == "tool" and type(m.content) == "string" and m.content:find('"ok":true', 1, true) then
            return true
        end
    end
    return false
end

-- quiet end-of-turn capture: only when the message ran tools AND every
-- recent tool result was successful; otherwise the note is not trustworthy
function K.AutoCapture(userText, answerText)
    -- consent gate: the user can turn ALL automatic learning off in Settings;
    -- explicit save_knowledge calls still work (that's the user asking)
    if NS.Settings and NS.Settings.Get("learningEnabled") == false then return nil end
    if not answerText or #answerText < 40 or not userText or userText == "" then return nil end
    if K.HasSuccessEvidence() then
        local e = K.Add({ problem = userText, solution = answerText:sub(1, 600),
                          source = "auto", verified = true })
        return e
    end
    return nil
end

function K.ContextFor(query)
    local hits = K.Recall(query, 3)
    local lines = {}
    for _, h in ipairs(hits) do
        if h.score >= 0.3 then
            local tag = h.e.status == "verified" and ("[verified " .. h.e.id .. "]") or ("[UNVERIFIED " .. h.e.id .. "]")
            lines[#lines + 1] = "- " .. tag .. " " .. h.e.problem:sub(1, 90) .. " -> " .. h.e.solution:sub(1, 180)
            if h.e.api then
                lines[#lines + 1] = "    api: " .. table.concat(h.e.api, ", ")
            end
        end
    end
    if #lines == 0 then return nil end
    lines[#lines + 1] = "Re-validate live before relying on any entry (properties change between Roblox versions); 'unverified' means a lead, not a fact. If one proves wrong, invalidate_knowledge it."
    return table.concat(lines, "\n")
end
