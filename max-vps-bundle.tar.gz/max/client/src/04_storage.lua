--[[ Safe local file layer.

     Wraps the optional storage functions (writefile/readfile/appendfile/
     isfile/isfolder/makefolder/delfile/listfiles) with everything memory
     needs: atomic verified writes, .bak rotation of the last good copy, a
     write-ahead JSONL log, corruption quarantine, and a pure-memory
     fallback so Max still runs on executors without file access (that
     memory just won't survive re-execution). ]]
local NS = MaxNS
local ST = { Available = false, Mode = "none", Files = {} }
NS.Storage = ST

local F = function(name) return NS.Env.Fns[name] end

local mem = {} -- fallback store when no file API exists

function ST.Init(rootFolder)
    ST.Root = rootFolder or "Max"
    ST.Available = type(F("writefile")) == "function" and type(F("readfile")) == "function"
    ST.CanAppend = ST.Available and type(F("appendfile")) == "function"
    ST.CanList = ST.Available and type(F("listfiles")) == "function"
    if ST.Available then
        ST.Mode = "files"
        if type(F("isfolder")) == "function" and type(F("makefolder")) == "function" then
            NS.Try(function()
                if not F("isfolder")(ST.Root) then F("makefolder")(ST.Root) end
                if not F("isfolder")(ST.Root .. "/conv") then F("makefolder")(ST.Root .. "/conv") end
                if not F("isfolder")(ST.Root .. "/corrupt") then F("makefolder")(ST.Root .. "/corrupt") end
            end)
        else
            NS.Warn("makefolder/isfile unsupported; relying on writefile creating parent dirs")
        end
    else
        ST.Mode = "memory"
        NS.Warn("writefile/readfile unavailable — memory will not persist across re-execute")
    end
end

local function path(rel)
    if rel:sub(1, 1) == "/" then rel = rel:sub(2) end
    return ST.Root .. "/" .. rel
end
ST.Path = path

function ST.Exists(rel)
    if not ST.Available then return mem[path(rel)] ~= nil end
    local f = F("isfile")
    if f then
        local ok, res = NS.Try(f, path(rel))
        if ok then return res and true or false end
    end
    local ok, res = NS.Try(F("readfile"), path(rel))
    return ok and res ~= nil
end

function ST.Read(rel)
    local p = path(rel)
    if not ST.Available then return mem[p] end
    local f = F("readfile")
    if not f then return nil end
    local ok, res = NS.Try(f, p)
    if ok and (type(res) == "string") then return res end
    return nil
end

function ST.Write(rel, content)
    local p = path(rel)
    if not ST.Available then
        mem[p] = content
        return true
    end
    local f = F("writefile")
    if not f then return false end
    -- rotate last known-good copy
    local previous = ST.Read(rel)
    if previous ~= nil then
        NS.Try(f, p .. ".bak", previous)
    end
    NS.Try(f, p .. ".tmp", content)
    local ok = NS.Try(f, p, content)
    if not ok then return false end
    local back = ST.Read(rel)
    if back ~= content then
        NS.Warn("write verify mismatch on " .. rel)
        if previous then NS.Try(f, p, previous) end
        return false
    end
    mem[p] = content -- mirror for memory-mode reads of the same session
    return true
end

function ST.Append(rel, line)
    local p = path(rel)
    if not ST.Available then
        mem[p] = (mem[p] or "") .. line
        return true
    end
    local af = F("appendfile")
    if af and ST.Exists(rel) then
        local ok = NS.Try(af, p, line)
        if ok then return true end
    end
    -- fallback: read-modify-write (documented; only used when appendfile
    -- is missing, errors, or the file doesn't exist yet)
    local cur = ST.Read(rel) or ""
    return ST.Write(rel, cur .. line)
end

function ST.Delete(rel)
    local p = path(rel)
    mem[p] = nil
    mem[p .. ".bak"] = nil
    if not ST.Available then return true end
    local f = F("delfile")
    if f then
        NS.Try(f, p)
        NS.Try(f, p .. ".bak")
        NS.Try(f, p .. ".log")
        NS.Try(f, p .. ".tmp")
        return true
    end
    NS.Try(F("writefile"), p, "")
    return true
end

-- Load + decode a JSON file with full corruption handling:
-- file -> .bak -> optional .log rebuild -> quarantine.
-- rebuild(logRel, decoder) is an optional fn(logLines) -> table.
function ST.LoadJson(rel, rebuild)
    local raw = ST.Read(rel)
    if raw then
        local data = NS.JSON.Decode(raw)
        if type(data) == "table" then return data end
    end
    local bak = ST.Read(rel .. ".bak")
    if bak then
        local data = NS.JSON.Decode(bak)
        if type(data) == "table" then
            NS.Warn("recovered " .. rel .. " from backup")
            ST.Write(rel, bak)
            return data
        end
    end
    if rebuild then
        local log = ST.Read(rel .. ".log")
        if log and #log > 0 then
            local ok, data = NS.Try(rebuild, log)
            if ok and type(data) == "table" then
                NS.Warn("rebuilt " .. rel .. " from write-ahead log")
                local enc = NS.JSON.Encode(data)
                if enc then ST.Write(rel, enc) end
                return data
            end
        end
    end
    if raw then -- quarantine unreadable original for manual recovery
        local stamp = tostring(os.time())
        NS.Try(function()
            ST.Write("corrupt/" .. rel:gsub("[/\\]", "_") .. "." .. stamp .. ".bad", tostring(raw))
        end)
        NS.Warn("quarantined corrupted " .. rel .. " into " .. ST.Root .. "/corrupt/")
    end
    return nil
end

-- Debug/diary log via appendfile when available
function ST.Diary(line)
    if not ST.Available then return end
    NS.Try(ST.Append, "max.log", "[" .. os.date("%H:%M:%S") .. "] " .. tostring(line) .. "\n")
end
