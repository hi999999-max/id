--[[ Feature detection: every optional executor API is probed once here and
     exposed through NS.Env. Nothing else in Max may call a global directly
     without going through this table first. ]]
local NS = MaxNS
local ENV = { Feats = {}, Fns = {} }

local function grab(fn)
    if type(fn) == "function" then return fn end
    return nil
end

-- Resolve an injected global by name. Executors frequently expose `request`,
-- `http_request`, `syn`, etc. ONLY through the __index metamethod of the
-- script's environment (they are not raw table entries) — so rawget() misses
-- them while a plain `print(type(request))` still works. We index candidate
-- environment tables normally — script env -> getgenv() -> _G — each access
-- pcall-guarded (reading hidden globals can error), plus a loadstring
-- last-ditch probe for envs that only materialise names on real reads.
local function envTables()
    local list = {}
    if type(getfenv) == "function" then
        -- wrap in a Lua closure: pcall(getfenv) makes getfenv's caller the C
        -- pcall itself, which has no environment, so level-1 lookups miss the
        -- chunk env where executors inject `request` etc.
        local ok, f = pcall(function() return getfenv(1) end)
        if ok and type(f) == "table" then list[#list + 1] = f end
    end
    if type(getgenv) == "function" then
        local ok, g = pcall(function() return getgenv() end)
        if ok and type(g) == "table" then
            local dup = false
            for _, t in ipairs(list) do if t == g then dup = true break end end
            if not dup then list[#list + 1] = g end
        end
    end
    list[#list + 1] = _G
    return list
end

function NS.EnvResolve(name)
    for _, t in ipairs(envTables()) do
        local ok, v = pcall(function() return t[name] end)
        if ok and v ~= nil then return v end
    end
    if type(loadstring) == "function" then
        local okc, chunk = pcall(loadstring, "return " .. tostring(name))
        if okc and type(chunk) == "function" then
            local okr, v = pcall(chunk)
            if okr and v ~= nil then return v end
        end
    end
    return nil
end

function NS.EnvIndex(t, key)
    if type(t) ~= "table" then return nil end
    local ok, v = pcall(function() return t[key] end)
    return ok and v or nil
end

-- (function-name -> resolved-or-nil); existence AND callability checked.
local names = {
    "getgenv", "cloneref", "identifyexecutor", "getexecutorname",
    "writefile", "readfile", "appendfile", "isfile", "isfolder", "makefolder", "delfile", "listfiles",
    "gethui", "get_hidden_gui",
    "getproperties", "get_properties",
    "queue_on_teleport", "setclipboard", "toclipboard",
    "http_request", "request",
}
for _, n in ipairs(names) do
    local f = grab(NS.EnvResolve(n))
    ENV.Fns[n] = f
    ENV.Feats[n] = f ~= nil
end
-- namespaced ones (root resolved through the env chain too)
local function grabPath(parts)
    local cur = NS.EnvResolve(parts[1])
    for i = 2, #parts do
        cur = NS.EnvIndex(cur, parts[i])
    end
    return type(cur) == "function" and cur or nil
end
ENV.Feats["syn.request"] = grabPath({ "syn", "request" }) ~= nil
ENV.Feats["http.request"] = grabPath({ "http", "request" }) ~= nil
ENV.Feats["fluxus.request"] = grabPath({ "fluxus", "request" }) ~= nil
ENV.Feats["krnl.request"] = grabPath({ "krnl", "request" }) ~= nil

-- getgenv with fallback to _G
do
    local g = ENV.Fns.getgenv
    local tbl = _G
    if g then
        local ok, res = NS.Try(g)
        if ok and type(res) == "table" then tbl = res end
    end
    ENV.G = tbl
end

-- Bulk property reader (optional): getproperties / get_properties
do
    local f = ENV.Fns.getproperties or ENV.Fns.get_properties
    ENV.GetProps = f
    ENV.GetPropsName = f and (ENV.Fns.getproperties and "getproperties" or "get_properties") or nil
end

-- Executor identity
do
    local nm = "unknown executor"
    local f = ENV.Fns.identifyexecutor or ENV.Fns.getexecutorname
    if f then
        local ok, res = NS.Try(f)
        if ok and type(res) == "string" and #res > 0 then nm = res end
    end
    ENV.ExecutorName = nm
end

-- Runtime discovery of *other* request-capable functions the user's executor
-- exposes (beyond the known set). getgenv().MaxExtraHttp = { fn, ... } lets a
-- user inject a custom transport; we also scan common globals and tables.
function ENV.DiscoverHttp()
    local found = {}
    local seen = {}
    local function add(label, fn)
        if type(fn) == "function" and not seen[fn] then
            seen[fn] = true
            found[#found + 1] = { name = label, fn = fn }
        end
    end
    add("http_request", ENV.Fns.http_request)
    add("request", ENV.Fns.request)
    add("syn.request", grabPath({ "syn", "request" }))
    add("http.request", grabPath({ "http", "request" }))
    add("fluxus.request", grabPath({ "fluxus", "request" }))
    add("krnl.request", grabPath({ "krnl", "request" }))
    -- other common executor aliases seen in the wild
    for _, k in ipairs({ "httpget", "http_get", "request_async", "fetch", "https_request", "web_request", "hookhttp" }) do
        add(k, ENV.Fns[k] or grabPath({ k }))
    end
    -- scan env-exposed namespace tables for fields named request / http_request
    for _, nsName in ipairs({ "syn", "http", "fluxus", "krnl", "wave", "horizon", "titan", "codex", "volt", "resalex", "silent", "protosmash", "PROTOSMASH", "Hydrogen", "Trigon" }) do
        local t = NS.EnvResolve(nsName)
        if type(t) == "table" then
            for _, fld in ipairs({ "request", "http_request" }) do
                add(nsName .. "." .. fld, NS.EnvIndex(t, fld))
            end
        end
    end
    local injected = ENV.G and ENV.G.MaxExtraHttp
    if type(injected) == "table" then
        for i, fn in ipairs(injected) do add("user:" .. i, fn) end
    end
    return found
end

ENV.HasStorage = ENV.Fns.writefile ~= nil and ENV.Fns.readfile ~= nil

function ENV.Describe()
    local out = {
        executor = ENV.ExecutorName,
        features = {},
    }
    for k, v in pairs(ENV.Feats) do
        if v then out.features[#out.features + 1] = k end
    end
    table.sort(out.features)
    return out
end

NS.Env = ENV
