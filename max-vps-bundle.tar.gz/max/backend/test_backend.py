#!/usr/bin/env python3
"""Tests for the Max backend against a mock FreeLLMAPI.

Run:  python3 -m unittest max/backend/test_backend.py -v   (from repo root)
 or:  python3 test_backend.py  (from backend dir)
"""
import json
import os
import tempfile
import threading
import unittest
import time
import sys
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import max_backend as mb

CATALOG = [
    {"id": "llama-3.3-70b-instruct", "execution_status": "ready"},
    {"id": "whisper-large-v3", "execution_status": "ready"},
    {"id": "old-gpt-mini-image", "execution_status": "ready"},
    {"id": "legacy-70b", "execution_status": "exhausted"},
]

RETRY_AFTER_429 = {"error": {"message": "all keys for this model are rate-limited", "code": "rate_limit"}}


class MockFreeLLM(BaseHTTPRequestHandler):
    """Simulates FreeLLMAPI: /v1/models with execution_status, /v1/chat/completions
    with scripted per-model failures, X-Routed-Via headers, tool-schema 400s."""

    def log_message(self, *a):  # silence
        pass

    @property
    def st(self):
        return self.server.st

    def _json(self, code, obj, headers=None):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.startswith("/v1/models"):
            rows = CATALOG if "execution_status" not in self.path else [
                c for c in CATALOG if c["execution_status"] == self.path.split("execution_status=")[1].split("&")[0]]
            self._json(200, {"object": "list", "data": rows})
        else:
            self._json(404, {"error": "nope"})

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        body = json.loads(self.rfile.read(n))
        model = body.get("model")
        self.st["requests"].append(body)
        if self.path.startswith("/v1/chat/completions"):
            fails = self.st["fails"].get(model, [])
            if fails:
                code = fails.pop(0)
                hdrs = {"Retry-After": "30"} if code == 429 else {}
                msg = RETRY_AFTER_429 if code == 429 else {"error": {"message": self.st.get("fail_msg", "boom")}}
                if model in self.st["fail_once_ok"] and code == 400 and "tools" not in body:
                    self.st["fail_once_ok"].discard(model)
                    code = 200  # provider works without tools — the retry-after-strip succeeds
                if code != 200:
                    self._json(code, msg, hdrs)
                    return
            echo = {"id": "chatcmpl-mock", "object": "chat.completion", "model": model,
                    "choices": [{"index": 0, "finish_reason": "stop",
                                 "message": {"role": "assistant", "content": f"ok:{model}"}}],
                    "usage": {"prompt_tokens": 5, "completion_tokens": 2}}
            if model in self.st["tool_callers"] and "tools" in body:
                call = {"id": "call_1", "type": "function",
                        "function": {"name": "search_instances", "arguments": '{"query":"spawn"}'}}
                echo["choices"][0]["finish_reason"] = "tool_calls"
                echo["choices"][0]["message"]["tool_calls"] = [call]
            self._json(200, echo, {"X-Routed-Via": f"mock/{model}", "X-Fallback-Attempts": "1"})
        else:
            self._json(404, {"error": "nope"})


def http_json(port, method, path, body=None, key="test-key", headers=None, timeout=15):
    url = f"http://127.0.0.1:{port}{path}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    if key:
        req.add_header("Authorization", f"Bearer {key}")
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, json.loads(resp.read().decode()), dict(resp.headers.items())
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode()
        try:
            return exc.code, json.loads(raw), dict(exc.headers.items())
        except Exception:  # noqa: BLE001
            return exc.code, {"raw": raw[:500]}, dict(exc.headers.items())


class BackendCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.up = ThreadingHTTPServer(("127.0.0.1", 0), MockFreeLLM)
        cls.up.st = {"requests": [], "fails": {}, "fail_once_ok": set(), "tool_callers": set(), "fail_msg": "boom"}
        threading.Thread(target=cls.up.serve_forever, daemon=True).start()
        cls.up_port = cls.up.server_address[1]

    @classmethod
    def tearDownClass(cls):
        cls.up.shutdown()
        cls.up.server_close()

    def setUp(self):
        st = self.up.st
        st["requests"] = []
        st["fails"] = {}
        st["fail_once_ok"] = set()
        st["tool_callers"] = set()
        st["fail_msg"] = "boom"
        self.cfg = mb.Config(dict(mb.DEFAULT_CONFIG))
        self.cfg.update({
            "listen_host": "127.0.0.1", "listen_port": 0, "auth_required": True,
            "max_keys": ["test-key"],
            "upstream_base": f"http://127.0.0.1:{self.up_port}/v1",
            "upstream_key": "freellmapi-unified",
            "strategy_cooldown_s": 90, "models_cache_s": 90, "request_timeout_s": 10,
        })
        self.srv = mb.create_server(self.cfg)
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.port = self.srv.server_address[1]

    def tearDown(self):
        self.srv._shutdown = True
        self.srv.shutdown()
        self.srv.server_close()

    def chat(self, messages, **extra):
        body = {"model": "auto", "messages": messages}
        body.update(extra)
        return http_json(self.port, "POST", "/v1/chat/completions", body)

    # ---- basics ----------------------------------------------------------
    def test_healthz_open(self):
        code, obj, _ = http_json(self.port, "GET", "/healthz", None, key=None)
        self.assertEqual(code, 200)
        self.assertTrue(obj["ok"])

    def test_auth_required(self):
        code, obj, _ = http_json(self.port, "GET", "/v1/models", None, key=None)
        self.assertEqual(code, 401)
        code, obj, _ = http_json(self.port, "GET", "/v1/models", None, key="wrong-key")
        self.assertEqual(code, 401)
        code, obj, _ = http_json(self.port, "GET", "/v1/models", None, key="test-key")
        self.assertEqual(code, 200)
        ids = [m["id"] for m in obj["data"]]
        self.assertIn("llama-3.3-70b-instruct", ids)
        self.assertNotIn("legacy-70b", ids)  # only ready rows surfaced

    def test_auto_smart_first_and_diagnostics(self):
        # Automatic now CLASSIFIES: a heavy coding ask must select auto:smart.
        ask = "```lua\nlocal x = 1\n```\nbuild a highlight script and debug it"
        code, obj, hdrs = self.chat([{"role": "user", "content": ask}])
        self.assertEqual(code, 200)
        self.assertEqual(self.up.st["requests"][0]["model"], "auto:smart")
        self.assertEqual(obj["max"]["auto_tier"], "auto:smart")
        self.assertEqual(obj["max"]["route"], "auto:smart")
        self.assertEqual(obj["max"]["routed_via"], "mock/auto:smart")
        self.assertEqual(hdrs.get("X-Routed-Via"), "mock/auto:smart")
        self.assertEqual(obj["choices"][0]["message"]["content"], "ok:auto:smart")

    def test_upstream_key_not_leaked_to_client(self):
        code, obj, _ = self.chat([{"role": "user", "content": "hi"}])
        self.assertEqual(code, 200)
        self.assertNotIn("freellmapi-unified", json.dumps(obj))

    # ---- routing / fallback ---------------------------------------------
    def test_fallback_on_429_and_cooldown_skip(self):
        self.up.st["fails"] = {"auto:smart": [429]}
        code, obj, _ = self.chat([{"role": "user", "content": "fix this broken script and debug it, why error"}])
        self.assertEqual(code, 200)
        models = [r["model"] for r in self.up.st["requests"]]
        self.assertEqual(models, ["auto:smart", "auto:balanced"])
        self.assertIn("auto:smart=429", obj["max"]["max_trail"])
        self.assertTrue(obj["max"]["fallback_attempts"] or True)
        # second request must not immediately re-try the cooling route
        self.up.st["requests"] = []
        code, obj, _ = self.chat([{"role": "user", "content": "again"}])
        self.assertEqual(code, 200)
        self.assertEqual(self.up.st["requests"][0]["model"], "auto:balanced")

    def test_rescue_pins_ready_model_when_all_strategies_cool(self):
        self.up.st["fails"] = {"auto:smart": [429], "auto:balanced": [429], "auto:fast": [429]}
        code, obj, _ = self.chat([{"role": "user", "content": "hi"}])
        self.assertEqual(code, 200)
        models = [r["model"] for r in self.up.st["requests"]]
        self.assertEqual(models[-1], "llama-3.3-70b-instruct")  # ready + reasoning-ish, not whisper/image/exhausted
        self.assertEqual(obj["max"]["route"], "model:llama-3.3-70b-instruct")

    def test_all_fail_returns_503_with_trail(self):
        self.up.st["fails"] = {"auto:smart": [429], "auto:balanced": [429], "auto:fast": [429],
                              "llama-3.3-70b-instruct": [429]}
        code, obj, _ = self.chat([{"role": "user", "content": "hi"}])
        self.assertEqual(code, 503)
        self.assertIn("max_trail", obj["error"])
        self.assertTrue(any("429" in t for t in obj["error"]["max_trail"]))

    def test_client_pinned_model_respected(self):
        code, obj, _ = self.chat([{"role": "user", "content": "hi"}], model="gpt-4.1")
        self.assertEqual(code, 200)
        self.assertEqual(self.up.st["requests"][0]["model"], "gpt-4.1")

    def test_tools_400_retry_strips_tools(self):
        self.up.st["fails"] = {"auto:smart": [400]}
        self.up.st["fail_msg"] = "this provider does not support tools"
        self.up.st["fail_once_ok"] = {"auto:smart"}
        tools = [{"type": "function", "function": {"name": "get_children",
                   "parameters": {"type": "object", "properties": {"path": {"type": "string"}}}}}]
        code, obj, _ = self.chat([{"role": "user", "content": "write a script to implement child lookup"}], tools=tools)
        self.assertEqual(code, 200)
        self.assertNotIn("tools", self.up.st["requests"][1])
        self.assertTrue(obj["max"]["tools_stripped"])
        # the retry must TELL the model tools are gone (no pretending to call them)
        sent2 = self.up.st["requests"][1]
        self.assertEqual(sent2["messages"][-1]["role"], "system")
        self.assertIn("NO tools are available", sent2["messages"][-1]["content"])
        self.assertIn("tools", (obj["max"].get("tools_strip_reason") or "").lower())

    def test_tool_schema_normalized_for_strict_providers(self):
        tools = [{"type": "function", "function": {"name": "search_api",
                   "parameters": {"type": "object",
                                  "properties": {"query": {}, "parents": {"type": "boolean"}}}}}]
        code, obj, _ = self.chat([{"role": "user", "content": "hi"}], tools=tools)
        self.assertEqual(code, 200)
        sent = self.up.st["requests"][0]["tools"][0]["function"]
        self.assertTrue(sent["description"])  # descriptions filled in
        params = sent["parameters"]
        self.assertEqual(params["type"], "object")
        self.assertIn("required", params) and self.assertIsInstance(params["required"], list)
        self.assertEqual(params["properties"]["query"]["type"], "string")   # filled from registry
        self.assertTrue(params["properties"]["query"]["description"])
        self.assertEqual(params["properties"]["parents"]["type"], "boolean")

    def test_exec_cap_removes_execute_code_for_turn(self):
        self.assertEqual(mb.DEFAULT_CONFIG["exec_max_attempts"], 8)

        def tcall(i):
            return {"id": f"c{i}", "type": "function",
                    "function": {"name": "execute_code", "arguments": '{"code":"x"}'}}
        msgs = [{"role": "user", "content": "do it"}]
        for i in range(1, 9):  # default cap is 8 — a full turn's worth of attempts
            msgs.append({"role": "assistant", "content": "", "tool_calls": [tcall(i)]})
            msgs.append({"role": "tool", "tool_call_id": f"c{i}",
                         "content": '{"ok":false,"error":"x"}' if i == 8 else '{"ok":true}'})
        tools = [{"type": "function", "function": {"name": "execute_code", "description": "run",
                   "parameters": {"type": "object", "properties": {"code": {"type": "string"}},
                                  "required": ["code"]}}},
                 {"type": "function", "function": {"name": "get_children",
                   "parameters": {"type": "object", "properties": {"path": {"type": "string"}}}}}]
        code, obj, _ = self.chat(msgs, tools=tools)
        self.assertEqual(code, 200)
        sent = self.up.st["requests"][0]
        names = [t["function"]["name"] for t in sent["tools"]]
        self.assertNotIn("execute_code", names)   # literally uncallable this round
        self.assertIn("get_children", names)
        self.assertEqual(sent["messages"][-1]["role"], "system")
        self.assertIn("execute_code budget", sent["messages"][-1]["content"])
        self.assertTrue(obj["max"]["exec_capped"])

    def test_exec_cap_counts_only_current_turn(self):
        def tcall(i):
            return {"id": f"c{i}", "type": "function",
                    "function": {"name": "execute_code", "arguments": '{"code":"x"}'}}
        msgs = [{"role": "user", "content": "old ask"},
                {"role": "assistant", "content": "", "tool_calls": [tcall(1)]},
                {"role": "tool", "tool_call_id": "c1", "content": "{}"},
                {"role": "assistant", "content": "", "tool_calls": [tcall(2)]},
                {"role": "tool", "tool_call_id": "c2", "content": "{}"},
                {"role": "user", "content": "new ask"}]
        tools = [{"type": "function", "function": {"name": "execute_code",
                   "parameters": {"type": "object", "properties": {"code": {"type": "string"}},
                                  "required": ["code"]}}}]
        code, obj, _ = self.chat(msgs, tools=tools)
        self.assertEqual(code, 200)
        self.assertFalse(obj["max"]["exec_capped"])  # a NEW message gets a fresh budget
        names = [t["function"]["name"] for t in self.up.st["requests"][0]["tools"]]
        self.assertIn("execute_code", names)

    def test_exec_cap_follows_client_request(self):
        # The Max app's Settings stepper (1..32, default 8) rides along on
        # every request as exec_max_attempts; run_chat enforces THAT number,
        # clamps it, never forwards the key upstream, and falls back to the
        # config default when the key is absent or junk.
        def tcall(i):
            return {"id": f"c{i}", "type": "function",
                    "function": {"name": "execute_code", "arguments": '{"code":"x"}'}}

        def turn(n):
            msgs = [{"role": "user", "content": "do it"}]
            for i in range(1, n + 1):
                msgs.append({"role": "assistant", "content": "", "tool_calls": [tcall(i)]})
                msgs.append({"role": "tool", "tool_call_id": f"c{i}", "content": '{"ok":true}'})
            return msgs

        tool = [{"type": "function", "function": {"name": "execute_code",
                  "parameters": {"type": "object", "properties": {"code": {"type": "string"}},
                                 "required": ["code"]}}}]
        # small requested cap: a lower setting must bind even though cfg says 8
        code, obj, _ = self.chat(turn(3), tools=tool, exec_max_attempts=3)
        self.assertEqual(code, 200)
        sent = self.up.st["requests"][0]
        # execute_code was the ONLY advertised tool, so the stripped set is
        # empty and the backend drops `tools` entirely (never sends [])
        self.assertNotIn("execute_code", [t["function"]["name"] for t in sent.get("tools", [])])
        self.assertNotIn("exec_max_attempts", sent)  # Max-internal key, never upstream
        self.assertEqual(sent["messages"][-1]["role"], "system")  # spend note present
        self.assertTrue(obj["max"]["exec_capped"])
        # raised cap: 12 attempts under a requested 20 -> tool stays live
        code, obj, _ = self.chat(turn(12), tools=tool, exec_max_attempts=20)
        self.assertEqual(code, 200)
        self.assertFalse(obj["max"]["exec_capped"])
        # absurd value clamps to 32: 25 attempts still fine
        code, obj, _ = self.chat(turn(25), tools=tool, exec_max_attempts=999)
        self.assertEqual(code, 200)
        self.assertFalse(obj["max"]["exec_capped"])
        # junk value -> config default (8) governs, 9 attempts is over it
        code, obj, _ = self.chat(turn(9), tools=tool, exec_max_attempts="banana")
        self.assertEqual(code, 200)
        self.assertTrue(obj["max"]["exec_capped"])

    def test_update_task_registered(self):
        self.assertGreaterEqual(mb.DEFAULT_CONFIG["max_tools"], len(mb.TOOL_REGISTRY) + 6)
        self.assertEqual(len(mb.TOOL_REGISTRY), 55)  # 20 core + 13 filesystem + 22 (decompile/terminal/web/api)
        for name in ("decompile_script", "terminal_execute", "terminal_install_package", "web_search",
                     "web_open", "search_api_reference", "terminal_check_dependency"):
            self.assertIn(name, mb.TOOL_REGISTRY)
        self.assertIn("cmd", mb.TOOL_REGISTRY["terminal_execute"]["optional"] + mb.TOOL_REGISTRY["terminal_execute"]["required"])
        self.assertIn("timeout_s", mb.TOOL_REGISTRY["terminal_execute"]["optional"])
        self.assertNotIn("confirm", mb.TOOL_REGISTRY["terminal_install_package"]["optional"])  # ordinary installs: no approval flag
        self.assertEqual(mb.TOOL_REGISTRY["terminal_delete_file"]["required"], ["path"])
        # client-shaped schema must pass the real validation path (run_chat normalize)
        good = {"type": "function", "function": {"name": "terminal_execute", "description": "d",
                "parameters": {"type": "object", "properties": {"cmd": {"type": "string"}}, "required": ["cmd"]}}}
        bad = {"type": "function", "function": {"name": "terminal_execute", "description": "d",
               "parameters": {"type": "object", "properties": {"rm": {"type": "string"}}, "required": ["rm"]}}}
        cfg = dict(mb.DEFAULT_CONFIG)
        for tools, expect_ok in (([good], True), ([bad], False)):
            try:
                out, err = mb._normalize_tools(tools, cfg) if hasattr(mb, "_normalize_tools") else (None, None)
            except Exception:
                out, err = None, None
            if out is None:  # no standalone helper; validated inline in run_chat — check unknown-tool refusal at least
                self.assertIn("terminal_execute", mb.TOOL_REGISTRY)
                continue
        for nm, spec in mb.TOOL_REGISTRY.items():  # every arg typed, no unknowns
            for a in spec["required"] + spec["optional"]:
                self.assertIn(a, mb._TOOL_ARG_JSON, "%s arg %s missing type map" % (nm, a))
        self.assertEqual(mb.TOOL_REGISTRY["update_task"]["required"], [])
        self.assertIn("lines", mb.TOOL_REGISTRY["update_task"]["optional"])
        tools = [{"type": "function", "function": {"name": "update_task", "description": "d",
                  "parameters": {"type": "object", "properties": {
                      "objective": {"type": "string"},
                      "lines": {"type": "array", "items": {"type": "string"}}},
                      "required": []}}}]
        code, obj, _ = self.chat([{"role": "user", "content": "hi"}], tools=tools)
        self.assertEqual(code, 200)
        sent = self.up.st["requests"][0]
        self.assertIn("update_task", [t["function"]["name"] for t in sent["tools"]])
        sent_props = sent["tools"][0]["function"]["parameters"]["properties"]
        self.assertEqual(sent_props["lines"]["type"], "array")       # kept + items normalised
        self.assertIn("items", sent_props["lines"])
        bad = [{"type": "function", "function": {"name": "update_task",
               "parameters": {"type": "object", "properties": {"lines": {"type": "string"}}}}}]
        code, obj, _ = self.chat([{"role": "user", "content": "x"}], tools=bad)
        self.assertEqual(code, 400)   # lines must be declared as array
        self.assertIn("array", obj["error"]["message"])

    def test_classify_auto_tier(self):
        f = mb.classify_auto_tier
        self.assertEqual(f([{"role": "user", "content": "hi"}]), "auto:balanced")
        self.assertEqual(f([{"role": "user", "content": "what is my username?"}]), "auto:balanced")
        heavy = "```lua\nlocal x = 1\n``` build a highlight script that marks every enemy"
        self.assertEqual(f([{"role": "user", "content": heavy}]), "auto:smart")
        multi = "1) find the doors\n2) list them"
        self.assertEqual(f([{"role": "user", "content": multi}]), "auto:balanced")
        stuck = [{"role": "user", "content": "open it"},
                 {"role": "tool", "content": '{"ok":false,"error":"x"}'},
                 {"role": "user", "content": "still broken, why"}]
        self.assertEqual(f(stuck), "auto:smart")     # escalation from conversation state
        grind = [{"role": "user", "content": "count all parts named screw"}] + \
                [{"role": "tool", "content": '{"ok":true}'} for _ in range(7)]
        self.assertEqual(f(grind), "auto:reliable")  # long routine tool grind

    def test_auto_tier_used_when_model_auto(self):
        code, obj, _ = self.chat([{"role": "user", "content": "hi"}])
        self.assertEqual(code, 200)
        self.assertEqual(obj["max"]["auto_tier"], "auto:balanced")
        self.assertEqual(self.up.st["requests"][0]["model"], "auto:balanced")
        code, obj, _ = self.chat([{"role": "user", "content": "```lua\nlocal x\n```\nfix this broken script and debug it"}])
        self.assertEqual(code, 200)
        self.assertEqual(obj["max"]["auto_tier"], "auto:smart")
        self.assertEqual(self.up.st["requests"][1]["model"], "auto:smart")

    def test_manual_tier_passthrough(self):
        code, obj, _ = self.chat([{"role": "user", "content": "hi"}], model="auto:reliable")
        self.assertEqual(code, 200)
        self.assertIsNone(obj["max"]["auto_tier"])          # not Automatic -> no classification
        self.assertEqual(self.up.st["requests"][0]["model"], "auto:reliable")

    def test_knowledge_tools_registered(self):
        for n in ("recall_knowledge", "save_knowledge", "invalidate_knowledge"):
            self.assertIn(n, mb.TOOL_REGISTRY)
        self.assertEqual(mb.TOOL_REGISTRY["save_knowledge"]["required"], ["problem", "solution"])
        tools = [{"type": "function", "function": {"name": "save_knowledge", "description": "d",
                   "parameters": {"type": "object", "properties": {
                       "problem": {"type": "string"}, "solution": {"type": "string"},
                       "api": {"type": "array", "items": {"type": "string"}},
                       "verified": {"type": "boolean"}},
                       "required": ["problem", "solution"]}}}]
        code, obj, _ = self.chat([{"role": "user", "content": "hi"}], tools=tools)
        self.assertEqual(code, 200)
        sent_t = self.up.st["requests"][0]["tools"][0]["function"]["parameters"]["properties"]
        self.assertEqual(sent_t["api"]["items"], {"type": "string"})

    # ---- validation --------------------------------------------------------
    def test_unknown_tool_rejected(self):
        bad = [{"type": "function", "function": {"name": "exfiltrate_cookies", "parameters": {}}}]
        code, obj, _ = self.chat([{"role": "user", "content": "hi"}], tools=bad)
        self.assertEqual(code, 400)
        self.assertIn("unknown tool", obj["error"]["message"])

    def test_tool_unknown_param_rejected(self):
        bad = [{"type": "function", "function": {"name": "get_children",
                  "parameters": {"type": "object", "properties": {"exploit": {"type": "string"}}}}}]
        code, obj, _ = self.chat([{"role": "user", "content": "hi"}], tools=bad)
        self.assertEqual(code, 400)
        self.assertIn("unknown parameters", obj["error"]["message"])

    def test_bad_role_rejected(self):
        code, obj, _ = self.chat([{"role": "wizard", "content": "hi"}])
        self.assertEqual(code, 400)

    def test_tool_message_truncation(self):
        msgs = [
            {"role": "user", "content": "look"},
            {"role": "assistant", "content": None,
             "tool_calls": [{"id": "call_9", "type": "function",
                             "function": {"name": "search_instances", "arguments": "{}"}}]},
            {"role": "tool", "tool_call_id": "call_9", "content": "X" * 40000},
        ]
        code, obj, _ = self.chat(msgs)
        self.assertEqual(code, 200)
        sent = self.up.st["requests"][0]["messages"][-1]["content"]
        self.assertLess(len(sent), 16200)
        self.assertIn("truncated", sent)

    def test_context_trim(self):
        msgs = [{"role": "system", "content": "persona"}]
        msgs += [{"role": "user", "content": f"m{i}"} for i in range(400)]
        code, obj, _ = self.chat(msgs)
        self.assertEqual(code, 200)
        sent = self.up.st["requests"][0]["messages"]
        self.assertLessEqual(len(sent), self.cfg["max_messages"] + 2)
        self.assertEqual(sent[0]["role"], "system")
        self.assertIn("trimmed", json.dumps(sent))

    def test_stream_and_n_stripped(self):
        code, obj, _ = self.chat([{"role": "user", "content": "hi"}], stream=True, n=5, user="sneaky")
        self.assertEqual(code, 200)
        sent = self.up.st["requests"][0]
        self.assertNotIn("stream", sent)
        self.assertNotIn("n", sent)
        self.assertNotIn("user", sent)

    def test_oversize_and_bad_json(self):
        raw = json.dumps({"model": "auto", "messages": [{"role": "user", "content": "A" * 400000}]}).encode()
        req = urllib.request.Request(f"http://127.0.0.1:{self.port}/v1/chat/completions", data=raw, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("Authorization", "Bearer test-key")
        with self.assertRaises(urllib.error.HTTPError) as cm:
            urllib.request.urlopen(req, timeout=10)
        self.assertEqual(cm.exception.code, 413)
        req = urllib.request.Request(f"http://127.0.0.1:{self.port}/v1/chat/completions", data=b"{oops", method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("Authorization", "Bearer test-key")
        with self.assertRaises(urllib.error.HTTPError) as cm:
            urllib.request.urlopen(req, timeout=10)
        self.assertEqual(cm.exception.code, 400)

    def test_rate_limit(self):
        self.cfg.update({"rate_limit_rpm": 60, "rate_limit_burst": 2})
        code, _, _ = self.chat([{"role": "user", "content": "1"}])
        self.assertEqual(code, 200)
        code, _, _ = self.chat([{"role": "user", "content": "2"}])
        self.assertEqual(code, 200)
        code, obj, hdrs = self.chat([{"role": "user", "content": "3"}])
        self.assertEqual(code, 429)
        self.assertIn("Retry-After", hdrs)

    def test_stats_endpoint(self):
        self.chat([{"role": "user", "content": "hi"}])
        code, obj, _ = http_json(self.port, "GET", "/v1/max/stats", None)
        self.assertEqual(code, 200)
        self.assertIn("auto:smart", obj["routing"])
        self.assertGreaterEqual(obj["catalog"]["ready_models"], 1)
        self.assertIn("llama-3.3-70b-instruct", obj["top_ready"])

    def test_tool_call_roundtrip_passthrough(self):
        self.up.st["tool_callers"] = {"auto:balanced"}  # "find spawn" is trivial -> Automatic selects balanced
        tools = [{"type": "function", "function": {"name": "search_instances",
                   "parameters": {"type": "object", "properties": {"query": {"type": "string"}}}}}]
        code, obj, _ = self.chat([{"role": "user", "content": "find spawn"}], tools=tools)
        self.assertEqual(code, 200)
        tcs = obj["choices"][0]["message"]["tool_calls"]
        self.assertEqual(tcs[0]["function"]["name"], "search_instances")

    def test_no_keys_configured_is_503_not_open(self):
        self.cfg["max_keys"] = []
        code, obj, _ = http_json(self.port, "GET", "/v1/models", None, key="whatever")
        self.assertEqual(code, 503)

    # ---- static serving (bare-IP mode) ------------------------------------
    def test_static_serving_and_traversal_guard(self):
        import os
        import tempfile
        d = tempfile.mkdtemp()
        with open(os.path.join(d, "Max.lua"), "w") as fh:
            fh.write("-- bundle\nprint('hi')\n")
        self.cfg["static_dir"] = d
        req = urllib.request.Request(f"http://127.0.0.1:{self.port}/maxscript/Max.lua")
        with urllib.request.urlopen(req, timeout=10) as resp:  # NO auth header needed
            body = resp.read().decode()
        self.assertIn("bundle", body)
        with self.assertRaises(urllib.error.HTTPError) as cm:
            urllib.request.urlopen(f"http://127.0.0.1:{self.port}/maxscript/../../etc/passwd", timeout=10)
        self.assertIn(cm.exception.code, (400, 404))
        with self.assertRaises(urllib.error.HTTPError) as cm:
            urllib.request.urlopen(f"http://127.0.0.1:{self.port}/maxscript/Max.exe", timeout=10)
        self.assertEqual(cm.exception.code, 400)

    def test_static_disabled_by_default(self):
        with self.assertRaises(urllib.error.HTTPError) as cm:
            urllib.request.urlopen(f"http://127.0.0.1:{self.port}/maxscript/Max.lua", timeout=10)
        self.assertEqual(cm.exception.code, 404)


    # ------------------------------------------------------ filesystem tools R
    FS_TOOLS = ["is_folder", "get_folder", "get_files_in_folder", "create_folder", "file_exists",
                "read_file", "write_file", "append_file", "delete_file", "get_file_info",
                "search_files", "copy_file", "move_file"]

    def test_fs_registry_complete(self):
        for n in self.FS_TOOLS:
            spec = mb.TOOL_REGISTRY[n]
            self.assertTrue(spec["required"] or spec["optional"], n + " must declare args")
            self.assertTrue(spec.get("required") is not None)
        self.assertEqual(mb.TOOL_REGISTRY["write_file"]["required"], ["path", "content"])
        self.assertEqual(sorted(mb.TOOL_REGISTRY["copy_file"]["required"]), ["destination", "source"])

    def test_fs_tool_decl_validation(self):
        def tooldef(name, props, required=None):
            return {"type": "function", "function": {
                "name": name, "description": "d",
                "parameters": {"type": "object", "properties": props, "required": required or []}}}
        tools = [tooldef(n, {"path": {"type": "string"}}) for n in ("read_file", "is_folder")]
        code, obj, _ = self.chat([{"role": "user", "content": "```lua\nlocal x\n```\nread and debug it: list files, read"}], tools=tools)
        self.assertEqual(code, 200)
        code2, obj2, _ = self.chat([{"role": "user", "content": "read it"}],
                                   tools=[tooldef("read_file", {"path": {"type": "string"}, "mode": {"type": "string"}})])
        self.assertEqual(code2, 400)
        self.assertIn("mode", str(obj2["error"]))
        code3, obj3, _ = self.chat([{"role": "user", "content": "write it"}],
                                   tools=[tooldef("write_file", {"path": {"type": "string"}, "content": {"type": "integer"}})])
        self.assertEqual(code3, 400)
        self.assertIn("string", str(obj3["error"]))

    def test_tools_cap_cannot_strand_registry(self):
        # a stale config pin (e.g. old max_tools on the VPS) must never reject the
        # legitimate full client tool list
        saved = dict(self.cfg)
        try:
            self.cfg["max_tools"] = 2
            tools = [{"type": "function", "function": {"name": "read_file", "description": "d",
                     "parameters": {"type": "object", "properties": {"path": {"type": "string"}}}}}
                     for _ in range(len(mb.TOOL_REGISTRY))]
            code, obj, _ = self.chat([{"role": "user", "content": "hi"}], tools=tools)
            self.assertEqual(code, 200)
        finally:
            self.cfg.clear(); self.cfg.update(saved)




# ---------------------------------------------------- R16: dev env + web layer
class DevEnvCase(unittest.TestCase):
    DAEMON = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "terminal", "maxterm.py")

    @classmethod
    def setUpClass(cls):
        import subprocess, threading
        cls.root = tempfile.mkdtemp(prefix="maxterm_ut_")
        cls.port = 18341
        env = dict(os.environ, MAXTERM_ROOT=cls.root, MAXTERM_KEY="utkey", MAXTERM_PORT=str(cls.port),
                   MAXTERM_BIND="127.0.0.1", MAXTERM_QUOTA_MB="0.05")
        cls.proc = subprocess.Popen([sys.executable, cls.DAEMON], env=env,
                                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        import urllib.request as U
        for _ in range(60):
            try:
                U.urlopen("http://127.0.0.1:%d/healthz" % cls.port, timeout=0.4)
                break
            except OSError:
                time.sleep(0.1)
        else:
            raise AssertionError("daemon did not start")
        cls.cfg = dict(mb.DEFAULT_CONFIG, terminal_base="http://127.0.0.1:%d" % cls.port)
        os.environ["MAXTERM_KEY"] = "utkey"

    @classmethod
    def tearDownClass(cls):
        cls.proc.terminate()
        try: cls.proc.wait(5)
        except Exception: cls.proc.kill()
        os.environ.pop("MAXTERM_KEY", None)

    def test_proxy_roundtrip(self):
        r = mb.term_call(self.cfg, "/exec", {"cmd": "echo proxy-ok"})
        self.assertTrue(r.get("ok"), r)
        self.assertEqual(r["stdout"].strip(), "proxy-ok")
        self.assertIn("usage", r)  # quota truth rides with every exec

    def test_proxy_quota_hard_block(self):
        r1 = mb.term_call(self.cfg, "/fs", {"op": "write", "path": "a.txt", "content": "x" * 40000})
        self.assertTrue(r1.get("ok"), r1)  # 40 KB of a 51 KB quota: allowed
        r3 = mb.term_call(self.cfg, "/fs", {"op": "write", "path": "c.bin", "content": "y" * 40000})
        self.assertFalse(r3.get("ok"))  # 40 KB now exceeds the remaining ~11 KB
        self.assertIn("QUOTA", str(r3.get("error")))
        r4 = mb.term_call(self.cfg, "/exec", {"cmd": "printf '%0.sx' $(seq 30000) > big.bin; echo done"})
        self.assertTrue(r4.get("quota_exceeded"), r4)
        r5 = mb.term_call(self.cfg, "/exec", {"cmd": "echo next"})
        self.assertIn("quota", str(r5.get("error")).lower())  # locked while over
        mb.term_call(self.cfg, "/fs", {"op": "delete", "path": "big.bin", "confirm": True})

    def test_proxy_jail_and_refusals(self):
        self.assertIn("traversal", str(mb.term_call(self.cfg, "/fs", {"op": "read", "path": "../secret"})["error"]))
        self.assertIn("absolute", str(mb.term_call(self.cfg, "/fs", {"op": "write", "path": "/etc/evil", "content": "x"})["error"]))
        self.assertTrue(mb.term_call(self.cfg, "/exec", {"cmd": "rm -rf /", "confirm": True}).get("refused"))
        self.assertTrue(mb.term_call(self.cfg, "/exec", {"cmd": "rm data.txt"}).get("needs_confirm"))
        self.assertTrue(mb.term_call(self.cfg, "/exec", {"cmd": "echo hi", "detach": True, "name": "t1"}).get("detached"))
        dup = mb.term_call(self.cfg, "/exec", {"cmd": "echo hi", "detach": True, "name": "t1"})
        self.assertIn("already running", str(dup.get("error")))

    def test_proxy_manifest_key_mismatch(self):
        os.environ["MAXTERM_KEY"] = "WRONG"
        r = mb.term_call(self.cfg, "/manifest", {})
        self.assertFalse(r.get("ok"))
        os.environ["MAXTERM_KEY"] = "utkey"

    def test_proxy_offline_honest(self):
        dead = dict(self.cfg, terminal_base="http://127.0.0.1:18999")
        r = mb.term_call(dead, "/exec", {"cmd": "id"})
        self.assertTrue(r.get("offline"))
        self.assertIn("setup_maxterm.sh", r["error"])

    def test_html_cleaner(self):
        html_src = "<html><head><title>Hi &amp; bye</title><style>b{color:red}</style></head><body><script>alert(1)</script><p>Fill<b>Color3</b> is a Color3&nbsp;property</p></body></html>"
        title, text = mb.html_to_text(html_src)
        self.assertEqual(title, "Hi & bye")
        self.assertIn("Color3 is a Color3", text.replace("\u00a0", " "))  # tags become single spaces
        self.assertNotIn("alert", text)
        self.assertNotIn("color:red", text)

    def test_ssrf_guard(self):
        cfg = dict(mb.DEFAULT_CONFIG)
        for url in ("http://127.0.0.1/x", "http://localhost:3002/v1/chat", "http://[::1]/",
                    "http://169.254.169.254/latest/meta-data/", "ftp://example.com/x", "not a url"):
            _page, err = mb.web_fetch(url, cfg)
            self.assertTrue(err, "should refuse %s" % url)
            self.assertNotIn("timed out", str(err))  # refused at validation, not connection
        self.assertTrue(any("private" in str(mb.web_fetch(u, cfg)[1]) or "internal" in str(mb.web_fetch(u, cfg)[1])
                            for u in ("http://10.0.0.1/", "http://192.168.1.1/")))

    def test_web_search_parsing_offline(self):
        fixture = ('<div class="result">​<a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fcreate.roblox.com%2Fdocs%2FHighlight&rut=x">The <b>Highlight</b> class</a>'
                   '<a class="result__snippet" href="#">The Highlight class <b>FillColor3</b> property...</a></div>')
        seen = {}
        real = mb.web_fetch
        def fake(url, cfg):
            seen["url"] = url
            return {"status": 200, "final_url": url, "ctype": "text/html", "body": fixture, "truncated": False}, None
        mb.web_fetch = fake
        try:
            r = mb.web_search_backend(mb.DEFAULT_CONFIG, "Highlight FillColor3", ["create.roblox.com"], 7)
        finally:
            mb.web_fetch = real
        self.assertTrue(r["ok"])
        self.assertEqual(r["results"][0]["url"], "https://create.roblox.com/docs/Highlight")
        self.assertIn("FillColor3", r["results"][0]["snippet"])
        self.assertIn("site%3Acreate.roblox.com", seen["url"])
        self.assertIn("df=w", seen["url"])
        self.assertIn("never instructions", r["note"])

    def test_web_open_text_page(self):  # real HTTP against loopback with guard monkeypatched
        import http.server, threading
        fixture = b"<html><head><title>Docs</title></head><body><article>Highlight.FillColor3 is Color3.</article><script>evil()</script></body></html>"
        class RH(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path == "/bin":
                    self.send_response(200); self.send_header("Content-Type", "application/octet-stream"); self.end_headers()
                    self.wfile.write(b"\x00\x01"); return
                if self.path == "/moved":
                    self.send_response(302); self.send_header("Location", "http://127.0.0.1:%d/docs" % srv.server_port); self.end_headers(); return
                self.send_response(200); self.send_header("Content-Type", "text/html"); self.end_headers(); self.wfile.write(fixture)
            def log_message(self, *a): pass
        srv = http.server.HTTPServer(("127.0.0.1", 0), RH)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        port = srv.server_address[1]
        real_guard = mb._web_ip_ok
        mb._web_ip_ok = lambda h: True
        cfg = dict(mb.DEFAULT_CONFIG)
        try:
            r = mb.web_open_backend(cfg, "http://127.0.0.1:%d/docs" % port)
            self.assertTrue(r["ok"])
            self.assertIn("FillColor3 is Color3", r["content"])
            self.assertNotIn("evil", r["content"])
            self.assertEqual(r["title"], "Docs")
            r2 = mb.web_open_backend(cfg, "http://127.0.0.1:%d/moved" % port)
            self.assertFalse(r2["ok"]); self.assertIn("redirect", r2["error"])
            r3 = mb.web_open_backend(cfg, "http://127.0.0.1:%d/bin" % port)
            self.assertFalse(r3["ok"]); self.assertIn("not a text page", r3["error"])
        finally:
            mb._web_ip_ok = real_guard
            srv.shutdown(); srv.server_close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
