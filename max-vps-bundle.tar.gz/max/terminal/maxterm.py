#!/usr/bin/env python3
"""maxterm — MAX's isolated development-workspace daemon.

One stdlib-only HTTP server MAX's backend proxies to. It gives MAX a real
terminal, its own filesystem, persistent storage, Python/Node/git, package
installs and long-running processes — inside hard walls:

  * JAIL:      every path argument is resolved and must land under MAXTERM_ROOT.
               Symlinks out of the jail are rejected (realpath checked).
  * QUOTA:     MAXTERM_QUOTA_MB (default 300) is a HARD cap enforced HERE, in
               the storage layer: usage = recursive size of the workspace root.
               Writes/installs/procs that would exceed it are refused before
               they run; overshoot discovered after an exec is reported in the
               response so MAX must clean up. Nothing is ever auto-deleted.
  * ISOLATION: no host FS access beyond the mount it is given, non-root user,
               read-only host (container/systemd hardening — see setup script),
               per-process RLIMITS (CPU, address space, file size), timeouts,
               a process-count cap, and an audit log of every command.
  * DANGER:    host-escalation and destruction patterns (sudo, mount, rm -rf /,
               dd to devices, shutdown, container sockets, absolute-path writes
               outside the jail...) are refused outright — even with confirm.
               Workspace-destructive commands (rm, rmdir, chmod -R) run only
               with confirm:true. Package installs are workspace-scoped by
               construction (pip --target, npm local-only) with install-script
               execution disabled.

Endpoints (JSON POST {"action":...} or per-route; X-Max-Term-Key auth):
  /healthz             GET  open probe
  /exec     cmd, timeout_s?, detach?, name?, confirm?
  /proc     op=list|output|kill   id, tail_bytes?
  /fs       op=read|write|list|mkdir|delete|search|usage|cwd
  /pkg      op=install|list|check
  /manifest
"""
import json
import os
import re
import shlex
import signal
import subprocess
import sys
import threading
import time
import shutil
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

ROOT = os.path.realpath(os.environ.get("MAXTERM_ROOT") or os.getcwd())
KEY = os.environ.get("MAXTERM_KEY") or ""
QUOTA_MB = float(os.environ.get("MAXTERM_QUOTA_MB") or 300)
QUOTA = int(QUOTA_MB * 1024 * 1024)
EXEC_TIMEOUT = float(os.environ.get("MAXTERM_TIMEOUT_S") or 60)
EXEC_TIMEOUT_MAX = float(os.environ.get("MAXTERM_TIMEOUT_MAX_S") or 300)
MEM_MB = float(os.environ.get("MAXTERM_MEM_MB") or 384)
MAX_PROCS = int(os.environ.get("MAXTERM_MAX_PROCS") or 8)
OUT_CAP = 16000  # per stream, per response

_LOCK = threading.RLock()
_PROCS = {}          # id -> dict(popen, name, cmd, log, started, timeout, dead, exit)
_SEQ = {"n": 0}

# Hostile patterns: refused regardless of confirm. These target the host or
# are catastrophic-by-shape; the jail/rlimit layer catches the rest.
NEVER = re.compile(
    r"(\brm\s+(-[a-z]*\s+)*/(\s|$)|\brm\s+-rf\s+/(?:\s|\*|$)|: *\(\) *\{.*\}; *: *\(\)"
    r"|\bmkfs\b|\bdd\b[^|;&]*\bof=/dev/|\bshred\b|\bshutdown\b|\breboot\b|\bpoweroff\b|\bhalt\b"
    r"|\binit +0\b|\bsystemctl\b|\bjournalctl\b|\biotop\b|\bmount\b|\bumount\b|\bnsenter\b|\bchroot\b"
    r"|\bdocker\b|\bpodman\b|\bcrictl\b|\bkubectl\b|\bsu\b|\bsudo\b|\bdoas\b|\buseradd\b|\buserdel\b|\bpasswd\b"
    r"|\bcrontab\b|\bmodprobe\b|\binsmod\b|\brmmod\b|\bipcrontab\b|\bfdisk\b|\bparted\b|\bnewfs\b"
    r"|/etc/(passwd|shadow|sudoers)|/root/|/boot/|/sys/|/proc/sys|/dev/(sd|nvme|vd)"
    r"|\bchmod\b[^|;&]*(-[a-z]*R[a-z]*\s+)*/(\s|$)|\bchown\b[^|;&]*\s/(\s|$)"
    r"|\|\s*(?:ba)?sh\b|\bcurl\b[^|;]*\|\s*\w|\bwget\b[^|;]*\|\s*\w"
    r"|>\s*/(?!dev/null\b)[a-z]|\btee\b\s+/[a-z])", re.I)
# Destructive-inside-workspace: allowed but confirm:true required.
DESTRUCTIVE = re.compile(r"(\brm\b|\brmdir\b|\bfind\b[^|;]*-delete|\btruncate\b|\bchmod\b[^|;&]*-R|\bchattr\b)", re.I)

MAX_READ_BYTES = 8000
MAX_WRITE_BYTES = 200000
MAX_SEARCH_BYTES = 65536

# ---------------------------------------------------------------- jail + quota
def safe_rel(p):
    """Normalize a workspace-relative path; refuse escapes. Returns rel|None, err."""
    if p is None or p == "":
        return "", None
    if not isinstance(p, str) or len(p) > 240:
        return None, "path must be a short string (workspace-relative)"
    s = p.replace("\\", "/").strip()
    if s.startswith("/") or re.match(r"^[A-Za-z]:", s) or s.startswith("~"):
        return None, "absolute paths refused — everything is relative to the MAX workspace"
    parts = []
    for seg in s.split("/"):
        if seg in ("", "."):
            continue
        if seg == "..":
            return None, "'..' traversal refused — the workspace is the sandbox"
        parts.append(seg)
    rel = "/".join(parts)
    if rel.split("/")[0] == ".max":
        return None, ".max/ is the daemon's internal area (logs, process outputs)"
    full = os.path.realpath(os.path.join(ROOT, rel))
    if full != ROOT and not full.startswith(ROOT + os.sep):
        return None, "path resolves outside the workspace (symlink escape?) — refused"
    return rel, None


def abs_of(rel):
    return os.path.join(ROOT, rel) if rel else ROOT


def dir_bytes(path):
    total, files = 0, 0
    for base, dirs, names in os.walk(path, followlinks=False):
        dirs[:] = [d for d in dirs if not os.path.islink(os.path.join(base, d))]
        for n in names:
            fp = os.path.join(base, n)
            try:
                if not os.path.islink(fp):
                    total += os.path.getsize(fp)
                    files += 1
            except OSError:
                pass
    return total, files


def usage():
    used, files = dir_bytes(ROOT)
    return {"used_bytes": used, "files": files, "limit_bytes": QUOTA,
            "limit_mb": round(QUOTA_MB, 1), "free_bytes": max(0, QUOTA - used),
            "pct_used": round(100.0 * used / QUOTA, 1) if QUOTA else 0.0,
            "over_quota": used > QUOTA}


def quota_room(extra_bytes):
    used, _ = dir_bytes(ROOT)
    return used + max(0, extra_bytes) <= QUOTA


def audit(entry):
    try:
        d = os.path.join(ROOT, ".max")
        os.makedirs(d, exist_ok=True)
        lf = os.path.join(d, "logs.jsonl")
        if os.path.exists(lf) and os.path.getsize(lf) > 512 * 1024:
            os.replace(lf, lf + ".1")
        entry["ts"] = time.strftime("%Y-%m-%dT%H:%M:%S")
        with open(lf, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False)[:2000] + "\n")
    except OSError:
        pass  # auditing must never break an operation


# ---------------------------------------------------------------- processes
def _limits():
    mem = int(MEM_MB * 1024 * 1024)

    def pre():
        os.setsid()
        import resource
        for res, soft in ((resource.RLIMIT_CPU, 300), (resource.RLIMIT_FSIZE, 64 * 1024 * 1024)):
            try:
                _, hard = resource.getrlimit(res)
                resource.setrlimit(res, (min(soft, hard), hard))
            except (ValueError, OSError):
                pass
        try:
            resource.setrlimit(resource.RLIMIT_AS, (mem, mem))
        except (ValueError, OSError):
            pass
    return pre


def env_for():
    e = {"HOME": ROOT, "TMPDIR": os.path.join(ROOT, ".tmp"), "PATH": os.environ.get("PATH", "/usr/local/bin:/usr/bin:/bin"),
         "LANG": "C.UTF-8"}
    pl = os.path.join(ROOT, ".pylibs")
    if os.path.isdir(pl):
        e["PYTHONPATH"] = pl
        e["PYTHONUSERBASE"] = pl
    return e


def _reap():
    while True:
        time.sleep(2)
        now = time.time()
        with _LOCK:
            for pid, p in list(_PROCS.items()):
                if p.get("dead"):
                    if now - p.get("deadat", now) > 1800:
                        _PROCS.pop(pid, None)
                    continue
                rc = p["popen"].poll()
                if rc is not None:
                    p["dead"], p["exit"], p["deadat"] = True, rc, now
                elif p.get("deadline") and now > p["deadline"]:
                    _kill(p)
                    p["killed"] = "timeout"


def _kill(p):
    try:
        os.killpg(os.getpgid(p["popen"].pid), signal.SIGTERM)
    except (ProcessLookupError, PermissionError, OSError):
        try:
            p["popen"].terminate()
        except OSError:
            pass


def proc_start(name, cmd, timeout_s):
    with _LOCK:
        alive = [p for p in _PROCS.values() if not p.get("dead")]
        if len(alive) >= MAX_PROCS:
            return None, "process limit reached (%d running) — stop something first (terminal_list_processes)" % MAX_PROCS
        for p in alive:
            if p["name"] == name:
                return None, "a process named '%s' is already running (id %s) — no duplicates; kill it first or use another name" % (name, p["id"])
        _SEQ["n"] += 1
        pid = "p%d" % _SEQ["n"]
        log = os.path.join(ROOT, ".max", "proc", pid + ".log")
        os.makedirs(os.path.dirname(log), exist_ok=True)
        lf = open(log, "ab")
        try:
            popen = subprocess.Popen(["/bin/sh", "-c", cmd], stdout=lf, stderr=subprocess.STDOUT,
                                     cwd=ROOT, env=env_for(), preexec_fn=_limits(),
                                     start_new_session=False)
        except OSError as exc:
            lf.close()
            return None, "could not start: " + str(exc)
        p = {"id": pid, "name": name, "cmd": cmd[:300], "popen": popen, "log": log,
             "started": time.time(), "deadline": time.time() + timeout_s if timeout_s else None}
        _PROCS[pid] = p
        threading.Thread(target=_close_after, args=(popen, lf), daemon=True).start()
        return p, None


def _close_after(popen, lf):
    popen.wait()
    try:
        lf.close()
    except OSError:
        pass


def proc_info(p):
    with _LOCK:
        rc = None if p.get("dead") and p.get("exit") is None else p["popen"].poll()
        if rc is not None and not p.get("dead"):
            p.update(dead=True, exit=rc, deadat=time.time())
        out = {"id": p["id"], "name": p["name"], "cmd": p["cmd"],
               "running": rc is None and not p.get("dead"),
               "exit_code": p.get("exit"), "uptime_s": round(time.time() - p["started"], 1)}
        if p.get("killed"):
            out["note"] = "killed: " + p["killed"]
        try:
            out["log_bytes"] = os.path.getsize(p["log"])
        except OSError:
            pass
        return out


# ---------------------------------------------------------------- fs ops
def fs_read(rel, offset_line, max_bytes):
    full = abs_of(rel)
    if not os.path.isfile(full):
        return {"ok": False, "exists": False, "error": "no such file: " + rel}
    try:
        with open(full, "rb") as f:
            data = f.read(1024 * 1024)
    except OSError as exc:
        return {"ok": False, "error": "read failed: " + str(exc)}
    dec = data.decode("utf-8", "replace")
    capped = len(data) >= 1024 * 1024
    lines = dec.split("\n")
    off = max(1, int(offset_line or 1))
    lim = max(1, min(int(max_bytes or MAX_READ_BYTES), 20000))
    out, n = [], 0
    for ln in lines[off - 1:]:
        s = ln[:240] + ("…" if len(ln) > 240 else "")
        if n + len(s) + 1 > lim:
            break
        out.append(s)
        n += len(s) + 1
    stop = off + len(out) - 1
    truncated = capped or stop < len(lines) or (len(dec) > lim)
    return {"ok": True, "path": rel, "content": "\n".join(out), "first_line": off,
            "lines_returned": len(out), "total_lines": len(lines) if not capped else None,
            "bytes_at_least": len(data), "truncated": truncated or None,
            "hint": ("continue with offset_line=%d" % (stop + 1)) if truncated else None}


def fs_write(rel, content, overwrite):
    if rel == "":
        return {"ok": False, "error": "path must name a file"}
    if not isinstance(content, str) or len(content.encode()) > MAX_WRITE_BYTES:
        return {"ok": False, "error": "content must be a string up to %d bytes" % MAX_WRITE_BYTES}
    full = abs_of(rel)
    existed = os.path.isfile(full)
    if existed and not overwrite:
        return {"ok": False, "existing": True, "error": "file exists — refuse to overwrite silently; pass overwrite:true deliberately",
                "bytes": os.path.getsize(full)}
    if not quota_room(len(content.encode()) + 4096):
        u = usage()
        return {"ok": False, "error": "STORAGE QUOTA EXCEEDED — writing this would pass the %.0f MB limit (used %.1f MB). Delete or shrink workspace files first; never assume cleanup." % (QUOTA_MB, u["used_bytes"] / 1e6)}
    os.makedirs(os.path.dirname(full), exist_ok=True)
    tmp = full + ".maxwrite"
    with open(tmp, "wb") as f:
        f.write(content.encode())
    os.replace(tmp, full)  # atomic
    rb = ""
    try:
        with open(full, "rb") as f:
            rb = f.read(len(content) + 10).decode("utf-8", "replace")
    except OSError:
        pass
    verified = "byte-identical" if rb == content else "READBACK MISMATCH — treat as failed"
    res = {"ok": verified == "byte-identical", "path": rel, "bytes": len(content.encode()),
           "created": not existed, "verified": verified, "usage": usage()}
    if verified != "byte-identical":
        res["error"] = verified
    return res


def fs_list(rel, limit, page):
    full = abs_of(rel)
    if not os.path.isdir(full):
        return {"ok": False, "error": "not a directory: " + rel}
    kids = []
    try:
        for n in sorted(os.listdir(full)):
            p = os.path.join(full, n)
            isd = os.path.isdir(p)
            sz = None
            try:
                sz = None if isd or os.path.islink(p) else os.path.getsize(p)
            except OSError:
                pass
            kids.append({"name": n, "folder": True if isd else None, "bytes": sz})
    except OSError as exc:
        return {"ok": False, "error": str(exc)}
    limit = max(1, min(int(limit or 120), 400))
    page = max(1, int(page or 1))
    fr = (page - 1) * limit
    return {"ok": True, "path": rel or ".", "total": len(kids), "page": page,
            "items": kids[fr:fr + limit],
            "hint": "more: page=%d" % (page + 1) if fr + limit < len(kids) else None}


def fs_mkdir(rel):
    if rel == "":
        return {"ok": False, "error": "name a folder to create"}
    full = abs_of(rel)
    if os.path.isdir(full):
        return {"ok": True, "path": rel, "created": False}
    if os.path.exists(full):
        return {"ok": False, "error": "a file has that name"}
    os.makedirs(full, exist_ok=True)
    return {"ok": True, "path": rel, "created": True}


def fs_delete(rel, confirm):
    if rel == "":
        return {"ok": False, "error": "refusing to delete the workspace root"}
    if not confirm:
        return {"ok": False, "needs_confirm": True,
                "error": "destructive: pass confirm:true only after the user approved deleting this exact path in chat"}
    full = abs_of(rel)
    if os.path.isfile(full) or os.path.islink(full):
        os.remove(full)
        return {"ok": True, "deleted": rel, "usage": usage()}
    if os.path.isdir(full):
        if os.listdir(full):
            return {"ok": False, "error": "folder not empty — delete its contents explicitly first (no recursive deletes through this tool)"}
        os.rmdir(full)
        return {"ok": True, "deleted": rel, "usage": usage()}
    return {"ok": False, "error": "not found: " + rel}


def fs_search(pattern, folder, with_content, limit):
    pat = (pattern or "").lower()
    if not pat:
        return {"ok": False, "error": "pattern required"}
    base = abs_of(folder or "")
    if not os.path.isdir(base):
        return {"ok": False, "error": "no such folder: " + (folder or "")}
    limit = max(1, min(int(limit or 50), 150))
    matches, scanned = [], 0
    for cur, dirs, names in os.walk(base, followlinks=False):
        dirs[:] = [d for d in dirs if not d.startswith(".") and d != "node_modules" or pat in d.lower()][:200]
        relcur = os.path.relpath(cur, ROOT)
        for n in names:
            scanned += 1
            if scanned > 4000:
                break
            if n.startswith("."):
                continue
            rp = n if relcur == "." else os.path.join(relcur, n).replace(os.sep, "/")
            hit = {"path": rp}
            if pat in n.lower():
                hit["name_match"] = True
            if with_content and (len(matches) < 60):
                fp = os.path.join(cur, n)
                try:
                    if os.path.getsize(fp) < MAX_SEARCH_BYTES and not os.path.islink(fp):
                        with open(fp, "rb") as f:
                            dec = f.read().decode("utf-8", "replace")
                        lines = dec.split("\n")
                        hits = []
                        for i, ln in enumerate(lines):
                            if pat in ln.lower():
                                hits.append("L%d: %s" % (i + 1, ln[:160]))
                                if len(hits) >= 3:
                                    break
                        if hits:
                            hit["hits"] = hits
                except (OSError, UnicodeError):
                    pass
            if hit.get("name_match") or hit.get("hits"):
                matches.append(hit)
                if len(matches) >= limit:
                    break
        if len(matches) >= limit or scanned > 4000:
            break
    return {"ok": True, "pattern": pattern, "matches": matches, "total": len(matches),
            "scanned_files": scanned, "truncated": scanned > 4000 or None}


# ---------------------------------------------------------------- packages
SAFE_REQ = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,80}(==[A-Za-z0-9._+!-]{1,40})?$")


def pkg_install(manager, package, version, confirm):
    manager = (manager or "pip").lower()
    if manager not in ("pip", "npm"):
        return {"ok": False, "error": "manager must be pip or npm"}
    if not isinstance(package, str) or not SAFE_REQ.match(package):
        return {"ok": False, "error": "package name must be a plain PyPI/npm name (no URLs, specs, or shell) — got %r" % str(package)[:60]}
    req = package if not version else ("%s==%s" % (package, version) if manager == "pip" else "%s@%s" % (package, version))
    if not quota_room(2 * 1024 * 1024):
        return {"ok": False, "error": "quota exhausted — no room to install (see terminal_get_storage_usage). Free space first; installs are never auto-cleaned."}
    if manager == "pip":
        target = os.path.join(ROOT, ".pylibs")
        os.makedirs(target, exist_ok=True)
        cmd = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check",
               "--no-cache-dir", "--only-binary", ":all:", "--target", target, req]
    else:
        pj = os.path.join(ROOT, "package.json")
        if not os.path.exists(pj):
            with open(pj, "w") as f:
                json.dump({"name": "max-workspace", "private": True}, f)
        npm = shutil.which("npm")
        if not npm:
            return {"ok": False, "error": "npm not installed in this image (ask the user to rebuild with nodejs, or use the python side)"}
        cmd = [npm, "install", "--no-audit", "--no-fund", "--ignore-scripts",
               "--loglevel=error", "--prefix", ROOT, req]
    try:
        r = subprocess.run(cmd, cwd=ROOT, env=env_for(), capture_output=True, text=True,
                           timeout=240, preexec_fn=_limits())
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "install timed out (240s) — registry slow or package huge; check quota and retry once"}
    out = ((r.stdout or "") + "\n" + (r.stderr or "")).strip()
    res = {"ok": r.returncode == 0, "manager": manager, "package": req,
           "exit": r.returncode, "output_tail": out[-1200:], "usage": usage()}
    if r.returncode != 0 and "only-binary" in out:
        res["hint"] = "package has no wheel (would run setup.py) — refused by design; pick a wheel-only package"
    audit({"ep": "pkg.install", "cmd": " ".join(cmd)[:200], "exit": r.returncode})
    return res


def pkg_list():
    pip_pkgs, npm_pkgs = [], []
    py = os.path.join(ROOT, ".pylibs")
    if os.path.isdir(py):
        for d in sorted(os.listdir(py)):
            m = re.match(r"(.+)-([0-9][^-]*)\.dist-info$", d)
            if m:
                pip_pkgs.append("%s==%s" % (m.group(1), m.group(2)))
    nm = os.path.join(ROOT, "node_modules")
    if os.path.isdir(nm):
        try:
            for d in sorted(os.listdir(nm)):
                pj = os.path.join(nm, d, "package.json")
                if os.path.isfile(pj):
                    with open(pj) as f:
                        j = json.load(f)
                    npm_pkgs.append("%s@%s" % (j.get("name", d), j.get("version", "?")))
        except (OSError, ValueError):
            pass
    return {"ok": True, "workspace_pip": pip_pkgs, "workspace_npm": npm_pkgs,
            "note": "workspace-scoped installs only — the base image's system packages are not MAX's and are not listed here",
            "usage": usage()}


def pkg_check(name):
    if not isinstance(name, str) or not re.match(r"^[A-Za-z0-9@/._-]{1,80}$", name):
        return {"ok": False, "error": "invalid dependency name"}
    found = {"package": name, "pip": None, "npm": None, "executable": None, "python_module": None}
    lst = pkg_list()
    for p in lst["workspace_pip"]:
        if p.split("==")[0].lower() == name.lower():
            found["pip"] = p
    for p in lst["workspace_npm"]:
        if p.split("@")[0] == name:
            found["npm"] = p
    exe = shutil.which(name)
    if exe:
        found["executable"] = exe
    mod = re.match(r"^[A-Za-z_][A-Za-z0-9_]{0,60}$", name)
    if mod:
        r = subprocess.run([sys.executable, "-c",
                            "import importlib,sys;"
                            "m=importlib.import_module('%s');"
                            "print(getattr(m,'__version__','present'))" % name,
                            ], capture_output=True, text=True, timeout=20, env=env_for(), cwd=ROOT)
        if r.returncode == 0:
            found["python_module"] = r.stdout.strip()[:60]
    exists = any(found[k] for k in ("pip", "npm", "executable", "python_module"))
    return {"ok": True, "exists": exists, "detail": found,
            "note": None if exists else "NOT installed here — verify before you import/require it anywhere"}


def manifest():
    def ver(cmd):
        try:
            r = subprocess.run(cmd + ["--version"], capture_output=True, text=True, timeout=8)
            return (r.stdout or r.stderr).strip().split("\n")[0][:80] if r.returncode == 0 else None
        except (OSError, subprocess.TimeoutExpired):
            return None
    utils = {}
    for tool in ("git", "rg", "grep", "sed", "awk", "curl", "make", "gcc", "jq", "zip", "tar"):
        utils[tool] = bool(shutil.which(tool))
    lst = pkg_list()
    return {"ok": True, "os": sys.platform, "arch": os.uname().machine,
            "python": sys.version.split()[0], "node": ver(["node"]) if shutil.which("node") else None,
            "npm": ver(["npm"]) if shutil.which("npm") else None, "git": ver(["git"]),
            "utilities": utils,
            "workspace": {"root": "/workspace", "pip_target": ".pylibs (auto on PYTHONPATH)",
                          "npm_root": "node_modules at workspace root", "tmp": ".tmp (COUNTED against quota)",
                          "internal": ".max (logs/proc, not tool-accessible)"},
            "network": "egress only via package registries (pip/npm) inside the container; arbitrary URLs are the BACKEND's web tools, not yours",
            "limits": {"quota_mb": QUOTA_MB, "exec_timeout_s": [EXEC_TIMEOUT, EXEC_TIMEOUT_MAX],
                       "memory_mb_per_proc": MEM_MB, "max_procs": MAX_PROCS,
                       "read_bytes_per_call": MAX_READ_BYTES, "write_bytes_per_call": MAX_WRITE_BYTES},
            "installed": {"pip": lst["workspace_pip"], "npm": lst["workspace_npm"]},
            "processes_running": len([p for p in _PROCS.values() if not p.get("dead")]),
            "usage": usage()}


# ---------------------------------------------------------------- HTTP
class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):  # quiet
        pass

    def _send(self, code, obj):
        data = json.dumps(obj, ensure_ascii=False, default=str).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):  # noqa: N802
        if self.path.split("?")[0] == "/healthz":
            return self._send(200, {"ok": True, "service": "maxterm", "usage": usage()})
        return self._send(404, {"error": "use POST"})

    def do_POST(self):  # noqa: N802
        if KEY and self.headers.get("X-Max-Term-Key") != KEY:
            return self._send(401, {"error": "bad terminal key"})
        try:
            ln = min(int(self.headers.get("Content-Length") or 0), 2 * 1024 * 1024)
            req = json.loads(self.rfile.read(ln) or b"{}")
            return self._send(200, self._route(self.path.split("?")[0].rstrip("/"), req))
        except Exception as exc:  # daemon never traces at the caller
            return self._send(200, {"ok": False, "error": "maxterm: " + type(exc).__name__ + ": " + str(exc)[:200]})

    def _route(self, ep, q):
        if ep == "/manifest":
            return manifest()
        if ep == "/exec":
            return self.exec_cmd(q)
        if ep == "/proc":
            op = q.get("op")
            with _LOCK:
                procs = dict(_PROCS)
            if op == "list":
                return {"ok": True, "processes": [proc_info(p) for p in procs.values()],
                        "cap": MAX_PROCS}
            p = procs.get(str(q.get("id") or ""))
            if not p:
                return {"ok": False, "error": "no such process id (check terminal_list_processes)"}
            if op == "output":
                tail = max(100, min(int(q.get("tail_bytes") or 4000), OUT_CAP))
                try:
                    with open(p["log"], "rb") as f:
                        f.seek(0, 2)
                        sz = f.tell()
                        f.seek(max(0, sz - tail))
                        data = f.read().decode("utf-8", "replace")
                    return {"ok": True, "info": proc_info(p), "output": data, "log_bytes": sz,
                            "truncated": sz > tail or None}
                except OSError as exc:
                    return {"ok": False, "error": str(exc)}
            if op == "kill":
                _kill(p)
                deadline = time.time() + 3
                while time.time() < deadline and p["popen"].poll() is None:
                    time.sleep(0.1)
                if p["popen"].poll() is None:
                    try:
                        os.killpg(os.getpgid(p["popen"].pid), signal.SIGKILL)
                    except OSError:
                        p["popen"].kill()
                    p["popen"].wait()
                return {"ok": True, "killed": p["id"], "info": proc_info(p)}
            return {"ok": False, "error": "proc op?"}
        if ep == "/fs":
            return self.fs(q)
        if ep == "/pkg":
            op = q.get("op")
            if op == "install":
                return pkg_install(q.get("manager"), q.get("package"), q.get("version"), q.get("confirm"))
            if op == "list":
                return pkg_list()
            if op == "check":
                return pkg_check(q.get("name"))
            return {"ok": False, "error": "pkg op must be install|list|check"}
        return {"ok": False, "error": "unknown endpoint: " + ep}

    def exec_cmd(self, q):
        cmd = q.get("cmd")
        if not isinstance(cmd, str) or not cmd.strip() or len(cmd) > 4000:
            return {"ok": False, "error": "cmd must be a non-empty string under 4000 chars"}
        if NEVER.search(cmd):
            return {"ok": False, "refused": True,
                    "error": "refused: command targets things outside MAX's sandbox (host paths, services, devices, pipes-to-shell). Keep all work inside the workspace."}
        rel, err = safe_rel(q.get("cwd") or "")
        if err:
            return {"ok": False, "error": "cwd: " + err}
        destr = DESTRUCTIVE.search(cmd)
        if destr and not q.get("confirm"):
            return {"ok": False, "needs_confirm": True,
                    "error": "destructive command (deletes/overwrites broadly in the workspace). Run the equivalent through the single-path fs tools where possible, or pass confirm:true ONLY after the user approved this exact removal."}
        try:
            to = float(q.get("timeout_s") or EXEC_TIMEOUT)
        except (TypeError, ValueError):
            to = EXEC_TIMEOUT
        to = max(1.0, min(to, EXEC_TIMEOUT_MAX))
        if not quota_room(0):
            return {"ok": False, "error": "quota already exceeded — shell commands stay locked until the workspace shrinks back under %.0f MB (free space or ask the user; never delete blindly)" % QUOTA_MB}
        audit({"ep": "exec", "cmd": cmd[:400], "mode": "detach" if q.get("detach") else "run"})
        if q.get("detach"):
            name = str(q.get("name") or cmd.split()[0])[:40]
            p, perr = proc_start(name, cmd, to)
            if perr:
                return {"ok": False, "error": perr}
            return {"ok": True, "detached": True, "process": proc_info(p)}
        t0 = time.time()
        try:
            r = subprocess.run(["/bin/sh", "-c", cmd], cwd=abs_of(rel), env=env_for(),
                               capture_output=True, text=True, timeout=to, preexec_fn=_limits())
            exit_code, so, se = r.returncode, r.stdout or "", r.stderr or ""
        except subprocess.TimeoutExpired as te:
            exit_code = -1
            so = (te.stdout or b"").decode("utf-8", "replace") if isinstance(te.stdout, bytes) else (te.stdout or "")
            se = "TIMEOUT after %ss (process group killed)" % to
        except OSError as exc:
            return {"ok": False, "error": "spawn failed: " + str(exc)}
        u = usage()
        res = {"ok": exit_code == 0, "exit": exit_code,
               "stdout": so[:OUT_CAP] + ("\n…[truncated]" if len(so) > OUT_CAP else ""),
               "stderr": se[:4000] + ("\n…[truncated]" if len(se) > 4000 else ""),
               "elapsed_ms": int((time.time() - t0) * 1000), "usage": u}
        if u["over_quota"]:
            res["quota_exceeded"] = "OVER QUOTA after this run: remove or shrink files before any further writes/installs"
        return res

    def fs(self, q):
        op = q.get("op")
        rel, err = safe_rel(q.get("path") if q.get("path") is not None else q.get("folder"))
        if err:
            return {"ok": False, "error": err}
        if op == "read":
            return fs_read(rel, q.get("offset_line"), q.get("max_bytes"))
        if op == "write":
            return fs_write(rel, q.get("content"), q.get("overwrite"))
        if op == "list":
            return fs_list(rel, q.get("limit"), q.get("page"))
        if op == "mkdir":
            return fs_mkdir(rel)
        if op == "delete":
            return fs_delete(rel, q.get("confirm"))
        if op == "search":
            return fs_search(q.get("pattern"), rel, q.get("with_content"), q.get("limit"))
        if op == "usage":
            top = []
            for n in sorted(os.listdir(ROOT)):
                if n == ".max":
                    continue
                fp = os.path.join(ROOT, n)
                b, _f = dir_bytes(fp) if os.path.isdir(fp) and not os.path.islink(fp) else ((os.path.getsize(fp) if os.path.isfile(fp) else 0), 0)
                top.append({n if not n.startswith(".") else n: b})
            top.sort(key=lambda d: -list(d.values())[0])
            return {"ok": True, "usage": usage(), "top_entries": top[:10]}
        if op == "cwd":
            return {"ok": True, "cwd": "/workspace", "abs": ROOT}
        return {"ok": False, "error": "fs op must be read|write|list|mkdir|delete|search|usage|cwd"}


def main():
    os.makedirs(os.path.join(ROOT, ".tmp"), exist_ok=True)
    port = int(os.environ.get("MAXTERM_PORT") or 8080)
    host = os.environ.get("MAXTERM_BIND") or "0.0.0.0"
    threading.Thread(target=_reap, daemon=True).start()
    srv = ThreadingHTTPServer((host, port), H)
    print("maxterm listening on %s:%d root=%s quota=%.0fMB" % (host, port, ROOT, QUOTA_MB), flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    main()
