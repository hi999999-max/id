# Roblox AI Executor Bridge v2 — Beginner Setup Guide

This project runs an HTTP(S) dashboard and a real-time WebSocket bridge on one port (default `3003`). It is designed for **authorised Roblox testing only**.

Your VPS address is shown in examples as `77.68.33.65`.

## What changed in v2

- **Dashboard:** normal HTTP(S) website at `/`.
- **AI:** WebSocket at `/ws/ai`.
- **Roblox executor:** WebSocket at `/ws/executor`; no task polling.
- **Same port:** the website and both WebSocket endpoints share `PORT`.
- **Dashboard login repair:** browser gets an opaque server-side session cookie, not the raw admin token.
- **New tools:** `ReadFile`, `ReadFolder`, `MakeFile`, and `MakeFolder`, safely sandboxed under the executor’s `roblox-ai-bridge-workspace/` folder.
- **Large Luau source:** `ExecuteLuau.sourceFile` accepts a `.txt` payload beyond the direct 16 KB `code` limit (up to configured limits).
- **WebSocket enforced by default:** legacy HTTP AI/executor routes are disabled unless `ENABLE_LEGACY_HTTP_API=true` is explicitly set for a temporary migration.
- **Ready AI prompt:** install/update generates private `AI_START_PROMPT.txt` from `.env`, including the current AI token and WebSocket URL.

---

## 1. Upload and install

On your computer, upload the zip to the VPS:

```bash
scp roblox-ai-bridge-v2.zip root@77.68.33.65:/root/
```

On the VPS:

```bash
cd /root
unzip -o roblox-ai-bridge-v2.zip -d roblox-ai-bridge-v2
cd roblox-ai-bridge-v2/roblox-ai-bridge
sudo bash install.sh
```

The installer:

1. checks/installs Node.js 20+;
2. installs dependencies;
3. creates `/opt/roblox-ai-bridge/.env` if needed;
4. creates high-entropy role-separated tokens without printing them;
5. generates `/opt/roblox-ai-bridge/AI_START_PROMPT.txt` from those tokens;
6. starts the `roblox-ai-bridge` systemd service.

> `AI_START_PROMPT.txt` contains an AI token. It is permission `0600`; do not upload it to GitHub or share it publicly.

---

## 2. Choose a secure network path

Never expose a token through public plaintext HTTP/WS.

### Option A — WireGuard (recommended)

Run on the VPS:

```bash
sudo bash /opt/roblox-ai-bridge/scripts/setup-wireguard.sh
sudo sed -i 's/^HOST=.*/HOST=10.66.66.1/' /opt/roblox-ai-bridge/.env
sudo sed -i 's|^BRIDGE_PUBLIC_URL=.*|BRIDGE_PUBLIC_URL=http://10.66.66.1:3003|' /opt/roblox-ai-bridge/.env
sudo systemctl restart roblox-ai-bridge
sudo -u robloxbridge node /opt/roblox-ai-bridge/scripts/generate-ai-start-prompt.js
```

Use these addresses while WireGuard is active:

- Dashboard: `http://10.66.66.1:3003/`
- AI: `ws://10.66.66.1:3003/ws/ai`
- Executor (derived by BridgeClient): `ws://10.66.66.1:3003/ws/executor`

### Option B — HTTPS/WSS

With a trusted certificate, set `TLS_ENABLED=true`, set `HOST=0.0.0.0`, set `BRIDGE_PUBLIC_URL=https://YOUR_HOST_OR_IP:3003`, and place the certificate/key at the paths in `.env`. Then restart and regenerate the prompt:

```bash
sudo systemctl restart roblox-ai-bridge
sudo -u robloxbridge node /opt/roblox-ai-bridge/scripts/generate-ai-start-prompt.js
```

The dashboard is then `https://…:3003/`; AI/executor use `wss://…:3003/ws/...`.

---

## 3. View tokens and generated AI prompt

On the VPS (do not paste output into public chat):

```bash
sudo cat /opt/roblox-ai-bridge/.env
sudo cat /opt/roblox-ai-bridge/AI_START_PROMPT.txt
```

Role separation is mandatory:

| Credential | Used by |
|---|---|
| `EXECUTOR_API_TOKEN` | `executor/BridgeClient.lua` |
| `AI_API_TOKEN` | generated private `AI_START_PROMPT.txt` / AI WebSocket client |
| `DASHBOARD_ADMIN_TOKEN` | human dashboard login |

---

## 4. Configure and run `BridgeClient.lua`

Copy `/opt/roblox-ai-bridge/executor/BridgeClient.lua` to your authorised executor and edit only the configuration at the top:

```lua
ServerUrl = "http://10.66.66.1:3003", -- or https://your-host:3003
WebSocketPath = "/ws/executor",
ExecutorToken = "PASTE_EXECUTOR_API_TOKEN_HERE",
```

Run it in an authorised Roblox experience. The executor must provide a WebSocket API such as `WebSocket.connect`, `websocket.connect`, or `syn.websocket.connect`.

Successful output resembles:

```text
[RobloxAIBridge] WebSocket connected! SessionId=sess_... ExecutorId=exec_...
```

The client now receives tasks pushed by the server. It does not use `/api/v1/executor/poll`.

---

## 5. Open the dashboard

Open your dashboard URL in a normal browser and enter `DASHBOARD_ADMIN_TOKEN`.

The v2 dashboard remains HTTP(S), refreshes its state every two seconds, and shows that AI/executor are connected through WebSocket. If login succeeds but the app remains locked, use the **same hostname/scheme** for login and dashboard and allow same-site cookies; the UI shows a clear session-retention message.

---

## 6. Connect an AI client

Use the generated `/opt/roblox-ai-bridge/AI_START_PROMPT.txt` with an AI client that can open WebSockets. It already contains:

- your WebSocket endpoint;
- your AI token;
- exact authentication/register/list-tools message flow;
- large `.txt` `ExecuteLuau.sourceFile` instructions.

Also provide `AI_TOOL_GUIDE.md` to the AI client. It documents all 47 tools and safety rules.

Minimal wire protocol:

```json
{"type":"authenticate","role":"ai","token":"<AI_API_TOKEN>"}
{"type":"register","clientName":"My AI"}
{"type":"list_tools","id":"tools-1","format":"all"}
```

---

## 7. New sandboxed file tools

The executor reports whether it supports `readfile`, `listfiles`, `writefile`, and `makefolder`. The new tools map to them as follows:

| AI tool | Executor API | Result when missing |
|---|---|---|
| `ReadFile` | `readfile` | `{ "status": "Not supported" }` |
| `ReadFolder` | `listfiles` | `{ "status": "Not supported" }` |
| `MakeFile` | `writefile` | `{ "status": "Not supported" }` |
| `MakeFolder` | `makefolder` | `{ "status": "Not supported" }` |

All paths are limited to a `roblox-ai-bridge-workspace/` folder that BridgeClient creates/uses. They cannot use absolute paths, backslashes, or `..` traversal.

---

## 8. Large `ExecuteLuau` scripts

Direct code stays limited to 16 KB. Send large, authorised diagnostic code as a WebSocket text-file object:

```json
{
  "type":"tool_call",
  "id":"large-script-1",
  "sessionId":"sess_...",
  "toolName":"ExecuteLuau",
  "args":{
    "sourceFile":{"name":"diagnostic.txt","content":"-- large Luau source"},
    "reason":"Authorised diagnostic"
  }
}
```

Default maximum file content is 1 MiB. `ExecuteLuau` may still require an administrator to approve it in the dashboard.

---

## Useful VPS commands

```bash
# Status and logs
sudo bash /opt/roblox-ai-bridge/status.sh
sudo bash /opt/roblox-ai-bridge/logs.sh

# Run tests
cd /opt/roblox-ai-bridge && npm test

# Regenerate the private AI prompt after changing URL or rotating AI token
sudo -u robloxbridge node /opt/roblox-ai-bridge/scripts/generate-ai-start-prompt.js

# Update an existing install
# See UPDATE_GUIDE.md in the new package.
```

## Troubleshooting quick reference

- **Executor says it lacks WebSocket support:** use an executor exposing one of the supported WebSocket APIs; v2 intentionally does not fall back to HTTP polling.
- **`401` during AI auth:** check that the AI uses `AI_API_TOKEN`, not executor/dashboard tokens.
- **`EXECUTOR_OFFLINE`:** BridgeClient needs to be running and registered into the same session as AI.
- **Dashboard token is rejected:** check `DASHBOARD_ADMIN_TOKEN` in `/opt/roblox-ai-bridge/.env`, remove accidental quotes/spaces, then restart after editing.
- **Dashboard login loops:** access the dashboard through one consistent origin, e.g. always `https://host:3003` or always the WireGuard URL. Check browser cookie/privacy controls.
- **`Not supported` from file tools:** that executor does not expose the required file API; this is expected and is not a bridge-server failure.
- **Large source rejected:** check `EXECUTE_LUAU_MAX_FILE_BYTES` and `WS_MAX_MESSAGE_BYTES`; send `sourceFile` (not oversized direct `code`).
