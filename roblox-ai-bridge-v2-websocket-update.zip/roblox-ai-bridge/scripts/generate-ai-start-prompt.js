'use strict';

/**
 * Creates the private, ready-to-paste AI_START_PROMPT.txt after .env tokens exist.
 * The generated prompt intentionally contains AI_API_TOKEN, so it is chmod 0600 and
 * is not tracked in source control. Never print the token or generated contents here.
 */

const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');

const rootDir = path.resolve(__dirname, '..');
const envPath = path.join(rootDir, '.env');
const templatePath = path.join(rootDir, 'AI_START_PROMPT.template.txt');
const outputPath = path.join(rootDir, 'AI_START_PROMPT.txt');

function normaliseBaseUrl(raw) {
  return String(raw || '').trim().replace(/\/+$/, '');
}

function deriveBaseUrl(env) {
  const configured = normaliseBaseUrl(env.BRIDGE_PUBLIC_URL);
  if (configured) return configured;

  const tls = ['1', 'true', 'yes', 'on'].includes(String(env.TLS_ENABLED || '').trim().toLowerCase());
  let host = String(env.HOST || '127.0.0.1').trim();
  if (host === '0.0.0.0' || host === '::' || host === '[::]') {
    host = String(env.PUBLIC_IP || '77.68.33.65').trim();
  }
  const port = String(env.PORT || '3003').trim();
  const protocol = tls ? 'https' : 'http';
  const defaultPort = (tls && port === '443') || (!tls && port === '80');
  return `${protocol}://${host}${defaultPort ? '' : `:${port}`}`;
}

function toWebSocketUrl(baseUrl) {
  const normalized = normaliseBaseUrl(baseUrl);
  if (normalized.startsWith('https://')) return `wss://${normalized.slice('https://'.length)}/ws/ai`;
  if (normalized.startsWith('http://')) return `ws://${normalized.slice('http://'.length)}/ws/ai`;
  if (normalized.startsWith('wss://') || normalized.startsWith('ws://')) return `${normalized}/ws/ai`;
  throw new Error('BRIDGE_PUBLIC_URL must begin with http://, https://, ws://, or wss://.');
}

function main() {
  if (!fs.existsSync(envPath)) {
    throw new Error('Missing .env. Generate or configure tokens before creating AI_START_PROMPT.txt.');
  }
  if (!fs.existsSync(templatePath)) {
    throw new Error('Missing AI_START_PROMPT.template.txt.');
  }

  const env = dotenv.parse(fs.readFileSync(envPath, 'utf8'));
  const token = String(env.AI_API_TOKEN || '').trim();
  if (!token || token.startsWith('REPLACE_WITH_') || token.length < 24) {
    throw new Error('AI_API_TOKEN is not configured with a valid high-entropy token.');
  }

  const dashboardUrl = deriveBaseUrl(env);
  const websocketUrl = toWebSocketUrl(dashboardUrl);
  const template = fs.readFileSync(templatePath, 'utf8');
  const output = template
    .replaceAll('{{BRIDGE_DASHBOARD_URL}}', dashboardUrl)
    .replaceAll('{{AI_WEBSOCKET_URL}}', websocketUrl)
    .replaceAll('{{AI_API_TOKEN}}', token);

  fs.writeFileSync(outputPath, output, { mode: 0o600 });
  try {
    fs.chmodSync(outputPath, 0o600);
  } catch {
    // Non-POSIX development platforms may not support chmod; the write still succeeds.
  }

  console.log('Generated private AI_START_PROMPT.txt from .env (permissions 0600). Token was not printed.');
}

try {
  main();
} catch (error) {
  console.error(`AI prompt generation failed: ${error.message}`);
  process.exit(1);
}
