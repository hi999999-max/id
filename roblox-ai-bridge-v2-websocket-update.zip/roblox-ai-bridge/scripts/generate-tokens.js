'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const rootDir = path.resolve(__dirname, '..');
const envPath = path.join(rootDir, '.env');
const examplePath = path.join(rootDir, '.env.example');

function generateToken() {
  return crypto.randomBytes(36).toString('base64url');
}

function main() {
  const force = process.argv.includes('--force');

  let content = '';
  if (fs.existsSync(envPath)) {
    content = fs.readFileSync(envPath, 'utf8');
  } else if (fs.existsSync(examplePath)) {
    content = fs.readFileSync(examplePath, 'utf8');
  } else {
    console.error('Missing .env.example template.');
    process.exit(1);
  }

  const keys = ['AI_API_TOKEN', 'EXECUTOR_API_TOKEN', 'DASHBOARD_ADMIN_TOKEN'];
  let updated = false;

  for (const key of keys) {
    const regex = new RegExp(`^${key}=(.*)$`, 'm');
    const match = content.match(regex);
    const currentVal = match ? match[1].trim() : '';
    const needsNew = force || !currentVal || currentVal.startsWith('REPLACE_WITH_') || currentVal.length < 24;

    if (needsNew) {
      const newToken = generateToken();
      if (match) {
        content = content.replace(regex, `${key}=${newToken}`);
      } else {
        content += `\n${key}=${newToken}\n`;
      }
      updated = true;
    }
  }

  fs.writeFileSync(envPath, content, { mode: 0o600 });
  try {
    fs.chmodSync(envPath, 0o600);
  } catch {
    // Ignore chmod error on platforms without POSIX permissions
  }

  if (updated) {
    console.log('Generated high-entropy tokens and saved to .env (permissions 0600).');
    console.log('Tokens are intentionally not printed to stdout.');
  } else {
    console.log('.env already contains valid high-entropy tokens. Pass --force to rotate them.');
  }

  // Keep the private ready-to-paste prompt in sync whenever keys are first generated
  // or deliberately rotated. The child script never prints the token.
  const promptScript = path.join(rootDir, 'scripts', 'generate-ai-start-prompt.js');
  if (fs.existsSync(promptScript)) {
    const { spawnSync } = require('child_process');
    const result = spawnSync(process.execPath, [promptScript], { stdio: 'inherit' });
    if (result.status !== 0) {
      console.error('Failed to generate AI_START_PROMPT.txt after token setup.');
      process.exit(result.status || 1);
    }
  }
}

main();
