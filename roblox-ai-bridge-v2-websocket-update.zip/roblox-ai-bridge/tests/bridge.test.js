'use strict';

const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');

const { startServer } = require('../server/index');
const { MockExecutorClient, MockRobloxWorld } = require('../scripts/mock-executor');

const TEST_AI_TOKEN = 'test_ai_token_high_entropy_0123456789abcdef';
const TEST_EXEC_TOKEN = 'test_exec_token_high_entropy_fedcba9876543210';
const TEST_DASH_TOKEN = 'test_dash_token_high_entropy_aabbccddeeff0011';

async function apiJson(baseUrl, path, { method = 'GET', token = null, body = null, headers = {} } = {}) {
  const reqHeaders = {
    'Content-Type': 'application/json',
    ...headers,
  };
  if (token) {
    reqHeaders.Authorization = `Bearer ${token}`;
  }
  const res = await fetch(`${baseUrl}${path}`, {
    method,
    headers: reqHeaders,
    body: body !== null ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => null);
  return { status: res.status, headers: res.headers, json };
}

describe('Roblox AI Executor Bridge - Complete Suite', () => {
  let ctx;
  let baseUrl;

  before(async () => {
    process.env.NODE_ENV = 'test';
    ctx = await startServer({
      skipDotenv: true,
      skipSignalHandlers: true,
      returnOnError: true,
      NODE_ENV: 'test',
      HOST: '127.0.0.1',
      PORT: '0', // ephemeral free port for tests
      TLS_ENABLED: 'false',
      AI_API_TOKEN: TEST_AI_TOKEN,
      EXECUTOR_API_TOKEN: TEST_EXEC_TOKEN,
      DASHBOARD_ADMIN_TOKEN: TEST_DASH_TOKEN,
      ALLOWED_PLACE_IDS: '123456789,555555',
      EXECUTE_LUAU_ENABLED: 'true',
      EXECUTE_LUAU_REQUIRE_APPROVAL: 'true',
      DEFAULT_TOOL_TIMEOUT_MS: '2500',
      MAX_RESULT_BYTES: '8192',
      EXECUTOR_POLL_DEFAULT_WAIT_MS: '1500',
      EXECUTOR_POLL_MAX_WAIT_MS: '3000',
      ENABLE_LEGACY_HTTP_API: 'true',
      LOG_LEVEL: 'error',
    });
    baseUrl = `http://127.0.0.1:${ctx.port}`;
  });

  after(() => {
    if (ctx) {
      ctx.sessionManager.shutdown();
      ctx.server.close();
    }
  });

  it('1. starts server and serves /health and authenticated /api/v1/info', async () => {
    const health = await apiJson(baseUrl, '/health');
    assert.equal(health.status, 200);
    assert.equal(health.json.ok, true);
    assert.equal(health.json.status, 'healthy');

    const unauthInfo = await apiJson(baseUrl, '/api/v1/info');
    assert.equal(unauthInfo.status, 401);

    const authInfo = await apiJson(baseUrl, '/api/v1/info', { token: TEST_AI_TOKEN });
    assert.equal(authInfo.status, 200);
    assert.equal(authInfo.json.authenticatedAs, 'ai');
    assert.equal(authInfo.json.toolCount, 47);
  });

  it('2. enforces strict role-separated authentication', async () => {
    // AI token cannot register executor
    const aiAsExec = await apiJson(baseUrl, '/api/v1/executor/register', {
      method: 'POST',
      token: TEST_AI_TOKEN,
      body: { placeId: 123456789 },
    });
    assert.equal(aiAsExec.status, 401);

    // Executor token cannot call AI endpoint
    const execAsAi = await apiJson(baseUrl, '/api/v1/ai/tools', {
      token: TEST_EXEC_TOKEN,
    });
    assert.equal(execAsAi.status, 401);

    // Wrong token cannot access dashboard state
    const badDash = await apiJson(baseUrl, '/api/v1/dashboard/state', {
      token: TEST_AI_TOKEN,
    });
    assert.equal(badDash.status, 401);
  });

  it('3. enforces Place ID allowlist on executor registration', async () => {
    const denied = await apiJson(baseUrl, '/api/v1/executor/register', {
      method: 'POST',
      token: TEST_EXEC_TOKEN,
      body: {
        placeId: 999999999,
        gameName: 'Unauthorised Game',
      },
    });
    assert.equal(denied.status, 403);
    assert.equal(denied.json.error.code, 'PLACE_NOT_ALLOWED');
  });

  it('4. discovers all 47 tools including OpenAI and MCP formats', async () => {
    const res = await apiJson(baseUrl, '/api/v1/ai/tools?format=all', {
      token: TEST_AI_TOKEN,
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.toolCount, 47);
    assert.equal(res.json.tools.length, 47);
    assert.equal(res.json.openaiTools.length, 47);
    assert.equal(res.json.mcpTools.length, 47);

    const names = new Set(res.json.tools.map((t) => t.name));
    assert.ok(names.has('GetGameInfo'));
    assert.ok(names.has('MoveTo'));
    assert.ok(names.has('InteractWithPrompt'));
    assert.ok(names.has('ExecuteLuau'));
  });

  it('5. pairs executor and AI, runs full autonomous workflow via MockExecutor', async () => {
    const world = new MockRobloxWorld();
    const mockExec = new MockExecutorClient({
      baseUrl,
      token: TEST_EXEC_TOKEN,
      world,
    });
    const execInfo = await mockExec.startLoop({ pollWaitMs: 1000, heartbeatMs: 4000 });

    try {
      const aiReg = await apiJson(baseUrl, '/api/v1/ai/register', {
        method: 'POST',
        token: TEST_AI_TOKEN,
        body: { sessionId: execInfo.sessionId, clientName: 'TestAI' },
      });
      assert.equal(aiReg.status, 200);
      assert.equal(aiReg.json.sessionId, execInfo.sessionId);
      assert.equal(aiReg.json.executorConnected, true);

      // Step 1: GetGameInfo
      const gameInfo = await apiJson(baseUrl, '/api/v1/ai/tool-call', {
        method: 'POST',
        token: TEST_AI_TOKEN,
        body: { sessionId: execInfo.sessionId, toolName: 'GetGameInfo', args: {} },
      });
      assert.equal(gameInfo.status, 200);
      assert.equal(gameInfo.json.ok, true);
      assert.equal(gameInfo.json.data.placeId, 123456789);

      // Step 2: GetNearbyInteractables
      const nearby = await apiJson(baseUrl, '/api/v1/ai/tool-call', {
        method: 'POST',
        token: TEST_AI_TOKEN,
        body: { sessionId: execInfo.sessionId, toolName: 'GetNearbyInteractables', args: { radius: 80 } },
      });
      assert.equal(nearby.json.ok, true);
      assert.equal(nearby.json.data.count, 1);
      const prompt = nearby.json.data.interactables[0];

      // Step 3: GetNavigationPath & MoveTo
      const nav = await apiJson(baseUrl, '/api/v1/ai/tool-call', {
        method: 'POST',
        token: TEST_AI_TOKEN,
        body: { sessionId: execInfo.sessionId, toolName: 'GetNavigationPath', args: { targetPosition: prompt.position } },
      });
      assert.equal(nav.json.data.available, true);

      const move = await apiJson(baseUrl, '/api/v1/ai/tool-call', {
        method: 'POST',
        token: TEST_AI_TOKEN,
        body: { sessionId: execInfo.sessionId, toolName: 'MoveTo', args: { targetPosition: prompt.position } },
      });
      assert.equal(move.json.data.arrived, true);

      // Step 4: InteractWithPrompt
      const interact = await apiJson(baseUrl, '/api/v1/ai/tool-call', {
        method: 'POST',
        token: TEST_AI_TOKEN,
        body: { sessionId: execInfo.sessionId, toolName: 'InteractWithPrompt', args: { promptPath: prompt.path } },
      });
      assert.equal(interact.json.data.triggered, true);
      assert.equal(world.doorOpened, true);
    } finally {
      mockExec.stop();
      await apiJson(baseUrl, '/api/v1/session/disconnect', {
        method: 'POST',
        token: TEST_DASH_TOKEN,
        body: { sessionId: execInfo.sessionId, target: 'session' },
      });
    }
  });

  it('6. correlates concurrent requests accurately without cross-contamination', async () => {
    const mockExec = new MockExecutorClient({
      baseUrl,
      token: TEST_EXEC_TOKEN,
      customHandler: async (task) => {
        // Deliberately invert response timing so later requests finish earlier
        const delay = task.args.query === 'slow' ? 120 : 15;
        await new Promise((r) => setTimeout(r, delay));
        return { echoedQuery: task.args.query, requestId: task.requestId };
      },
    });
    const execInfo = await mockExec.startLoop({ pollWaitMs: 800 });

    try {
      await apiJson(baseUrl, '/api/v1/ai/register', {
        method: 'POST',
        token: TEST_AI_TOKEN,
        body: { sessionId: execInfo.sessionId, clientName: 'ConcurrencyTester' },
      });

      const queries = ['slow', 'fast-1', 'fast-2', 'slow', 'fast-3'];
      const calls = queries.map((q) =>
        apiJson(baseUrl, '/api/v1/ai/tool-call', {
          method: 'POST',
          token: TEST_AI_TOKEN,
          body: {
            sessionId: execInfo.sessionId,
            toolName: 'SearchWorkspace',
            args: { query: q },
          },
        })
      );

      const results = await Promise.all(calls);
      results.forEach((res, idx) => {
        assert.equal(res.status, 200);
        assert.equal(res.json.ok, true);
        assert.equal(res.json.data.echoedQuery, queries[idx]);
      });
    } finally {
      mockExec.stop();
      await apiJson(baseUrl, '/api/v1/session/disconnect', {
        method: 'POST',
        token: TEST_DASH_TOKEN,
        body: { sessionId: execInfo.sessionId, target: 'session' },
      });
    }
  });

  it('7. rejects invalid tool arguments, external URLs, and duplicate requests', async () => {
    const execReg = await apiJson(baseUrl, '/api/v1/executor/register', {
      method: 'POST',
      token: TEST_EXEC_TOKEN,
      body: { placeId: 123456789, gameName: 'ValidationTest' },
    });
    const sessionId = execReg.json.sessionId;

    await apiJson(baseUrl, '/api/v1/ai/register', {
      method: 'POST',
      token: TEST_AI_TOKEN,
      body: { sessionId },
    });

    try {
      // Unknown tool
      const unknown = await apiJson(baseUrl, '/api/v1/ai/tool-call', {
        method: 'POST',
        token: TEST_AI_TOKEN,
        body: { sessionId, toolName: 'DeleteUniverse', args: {} },
      });
      assert.equal(unknown.status, 404);
      assert.equal(unknown.json.error.code, 'UNKNOWN_TOOL');

      // External URL blocked in tool arguments
      const urlBlocked = await apiJson(baseUrl, '/api/v1/ai/tool-call', {
        method: 'POST',
        token: TEST_AI_TOKEN,
        body: {
          sessionId,
          toolName: 'SearchWorkspace',
          args: { query: 'https://evil.example.com/payload' },
        },
      });
      assert.equal(urlBlocked.status, 400);
      assert.equal(urlBlocked.json.error.code, 'INVALID_INPUT');

      // Duplicate requestId protection
      const reqId = `req_${crypto.randomUUID()}`;
      const first = await apiJson(baseUrl, '/api/v1/ai/tool-call', {
        method: 'POST',
        token: TEST_AI_TOKEN,
        body: {
          sessionId,
          toolName: 'GetGameInfo',
          args: {},
          requestId: reqId,
          wait: false,
        },
      });
      assert.equal(first.status, 200);

      const dup = await apiJson(baseUrl, '/api/v1/ai/tool-call', {
        method: 'POST',
        token: TEST_AI_TOKEN,
        body: {
          sessionId,
          toolName: 'GetGameInfo',
          args: {},
          requestId: reqId,
          wait: false,
        },
      });
      assert.equal(dup.status, 409);
      assert.equal(dup.json.error.code, 'DUPLICATE_REQUEST');
    } finally {
      await apiJson(baseUrl, '/api/v1/session/disconnect', {
        method: 'POST',
        token: TEST_DASH_TOKEN,
        body: { sessionId, target: 'session' },
      });
    }
  });

  it('8. handles request timeouts when executor fails to submit result', async () => {
    const execReg = await apiJson(baseUrl, '/api/v1/executor/register', {
      method: 'POST',
      token: TEST_EXEC_TOKEN,
      body: { placeId: 123456789, gameName: 'TimeoutTest' },
    });
    const sessionId = execReg.json.sessionId;
    await apiJson(baseUrl, '/api/v1/ai/register', {
      method: 'POST',
      token: TEST_AI_TOKEN,
      body: { sessionId },
    });

    try {
      const res = await apiJson(baseUrl, '/api/v1/ai/tool-call', {
        method: 'POST',
        token: TEST_AI_TOKEN,
        body: {
          sessionId,
          toolName: 'GetGameInfo',
          args: {},
          timeoutMs: 600,
        },
      });
      assert.equal(res.status, 200);
      assert.equal(res.json.ok, false);
      assert.equal(res.json.status, 'timed_out');
      assert.equal(res.json.error.code, 'REQUEST_TIMEOUT');
    } finally {
      await apiJson(baseUrl, '/api/v1/session/disconnect', {
        method: 'POST',
        token: TEST_DASH_TOKEN,
        body: { sessionId, target: 'session' },
      });
    }
  });

  it('9. enforces output size limits (MAX_RESULT_BYTES)', async () => {
    const execReg = await apiJson(baseUrl, '/api/v1/executor/register', {
      method: 'POST',
      token: TEST_EXEC_TOKEN,
      body: { placeId: 123456789, gameName: 'SizeLimitTest' },
    });
    const sessionId = execReg.json.sessionId;
    await apiJson(baseUrl, '/api/v1/ai/register', {
      method: 'POST',
      token: TEST_AI_TOKEN,
      body: { sessionId },
    });

    try {
      const pendingPromise = apiJson(baseUrl, '/api/v1/ai/tool-call', {
        method: 'POST',
        token: TEST_AI_TOKEN,
        body: { sessionId, toolName: 'GetWorkspaceSummary', args: {} },
      });

      const poll = await apiJson(baseUrl, '/api/v1/executor/poll', {
        method: 'POST',
        token: TEST_EXEC_TOKEN,
        body: { sessionId, waitMs: 1000 },
      });
      assert.equal(poll.json.tasks.length, 1);
      const task = poll.json.tasks[0];

      const hugeSubmit = await apiJson(baseUrl, '/api/v1/executor/result', {
        method: 'POST',
        token: TEST_EXEC_TOKEN,
        body: {
          sessionId,
          requestId: task.requestId,
          ok: true,
          data: { blob: 'X'.repeat(12000) },
        },
      });
      assert.equal(hugeSubmit.status, 413);
      assert.equal(hugeSubmit.json.error.code, 'PAYLOAD_TOO_LARGE');

      const aiRes = await pendingPromise;
      assert.equal(aiRes.json.ok, false);
      assert.equal(aiRes.json.error.code, 'PAYLOAD_TOO_LARGE');
    } finally {
      await apiJson(baseUrl, '/api/v1/session/disconnect', {
        method: 'POST',
        token: TEST_DASH_TOKEN,
        body: { sessionId, target: 'session' },
      });
    }
  });

  it('10. supports ExecuteLuau manual approval, disconnection, reconnection, and emergency stop', async () => {
    const mockExec = new MockExecutorClient({
      baseUrl,
      token: TEST_EXEC_TOKEN,
    });
    const execInfo = await mockExec.startLoop({ pollWaitMs: 1000 });
    const sessionId = execInfo.sessionId;

    await apiJson(baseUrl, '/api/v1/ai/register', {
      method: 'POST',
      token: TEST_AI_TOKEN,
      body: { sessionId },
    });

    // ExecuteLuau awaits manual approval by default
    const luauPromise = apiJson(baseUrl, '/api/v1/ai/tool-call', {
      method: 'POST',
      token: TEST_AI_TOKEN,
      body: {
        sessionId,
        toolName: 'ExecuteLuau',
        args: { code: 'print("hello") return 42', reason: 'Unit test approval' },
      },
    });

    await new Promise((r) => setTimeout(r, 100));
    const dashState = await apiJson(baseUrl, '/api/v1/dashboard/state', { token: TEST_DASH_TOKEN });
    assert.equal(dashState.json.pendingApprovals.length, 1);
    const pendingId = dashState.json.pendingApprovals[0].requestId;

    const approve = await apiJson(baseUrl, '/api/v1/dashboard/actions/approve-request', {
      method: 'POST',
      token: TEST_DASH_TOKEN,
      body: { sessionId, requestId: pendingId },
    });
    assert.equal(approve.status, 200);

    const luauResult = await luauPromise;
    assert.equal(luauResult.json.ok, true);
    assert.equal(luauResult.json.data.succeeded, true);

    // Disconnect and reconnect executor on same session
    mockExec.stop();
    await apiJson(baseUrl, '/api/v1/dashboard/actions/disconnect-executor', {
      method: 'POST',
      token: TEST_DASH_TOKEN,
      body: { sessionId },
    });

    const offlineCall = await apiJson(baseUrl, '/api/v1/ai/tool-call', {
      method: 'POST',
      token: TEST_AI_TOKEN,
      body: { sessionId, toolName: 'GetGameInfo', args: {} },
    });
    assert.equal(offlineCall.status, 503);
    assert.equal(offlineCall.json.error.code, 'EXECUTOR_OFFLINE');

    // Reconnect executor to same sessionId
    const reReg = await mockExec.register(sessionId);
    assert.equal(reReg.sessionId, sessionId);

    // Emergency stop cancels active requests & emits control signal
    const asyncReq = await apiJson(baseUrl, '/api/v1/ai/tool-call', {
      method: 'POST',
      token: TEST_AI_TOKEN,
      body: { sessionId, toolName: 'GetGameInfo', args: {}, wait: false },
    });
    assert.equal(asyncReq.json.accepted, true);

    const stopRes = await apiJson(baseUrl, '/api/v1/dashboard/actions/emergency-stop', {
      method: 'POST',
      token: TEST_DASH_TOKEN,
      body: { sessionId },
    });
    assert.equal(stopRes.status, 200);
    assert.ok(stopRes.json.cancelledCount >= 1);

    const pollAfterStop = await mockExec.pollOnce(100);
    assert.ok(pollAfterStop.controlSignals.some((s) => s.type === 'EMERGENCY_STOP'));

    await apiJson(baseUrl, '/api/v1/session/disconnect', {
      method: 'POST',
      token: TEST_DASH_TOKEN,
      body: { sessionId, target: 'session' },
    });
  });

  it('11. supports MCP over HTTP (initialize, tools/list, tools/call)', async () => {
    const mockExec = new MockExecutorClient({
      baseUrl,
      token: TEST_EXEC_TOKEN,
    });
    const execInfo = await mockExec.startLoop({ pollWaitMs: 1000 });

    try {
      const initRes = await apiJson(baseUrl, '/mcp', {
        method: 'POST',
        token: TEST_AI_TOKEN,
        body: { jsonrpc: '2.0', id: 1, method: 'initialize', params: {} },
      });
      assert.equal(initRes.status, 200);
      assert.equal(initRes.json.result.serverInfo.name, 'roblox-ai-bridge');

      const listRes = await apiJson(baseUrl, '/mcp', {
        method: 'POST',
        token: TEST_AI_TOKEN,
        body: { jsonrpc: '2.0', id: 2, method: 'tools/list', params: {} },
      });
      assert.equal(listRes.status, 200);
      assert.equal(listRes.json.result.tools.length, 47);

      const callRes = await apiJson(baseUrl, '/mcp', {
        method: 'POST',
        token: TEST_AI_TOKEN,
        body: {
          jsonrpc: '2.0',
          id: 3,
          method: 'tools/call',
          params: { name: 'GetGameInfo', arguments: {} },
        },
      });
      assert.equal(callRes.status, 200);
      assert.equal(callRes.json.result.isError, false);
      const parsedText = JSON.parse(callRes.json.result.content[0].text);
      assert.equal(parsedText.ok, true);
      assert.equal(parsedText.data.placeId, 123456789);
    } finally {
      mockExec.stop();
      await apiJson(baseUrl, '/api/v1/session/disconnect', {
        method: 'POST',
        token: TEST_DASH_TOKEN,
        body: { sessionId: execInfo.sessionId, target: 'session' },
      });
    }
  });

  it('12. serves dark-theme dashboard UI and authenticates via HttpOnly cookie without exposing tokens', async () => {
    const htmlRes = await fetch(`${baseUrl}/`);
    assert.equal(htmlRes.status, 200);
    const html = await htmlRes.text();
    assert.ok(html.includes('Roblox AI Executor Bridge'));
    assert.ok(!html.includes(TEST_AI_TOKEN));
    assert.ok(!html.includes(TEST_EXEC_TOKEN));
    assert.ok(!html.includes(TEST_DASH_TOKEN));

    const loginRes = await apiJson(baseUrl, '/api/v1/dashboard/login', {
      method: 'POST',
      body: { token: TEST_DASH_TOKEN },
    });
    assert.equal(loginRes.status, 200);
    assert.equal(loginRes.json.authenticated, true);
    const setCookie = loginRes.headers.get('set-cookie');
    assert.ok(setCookie && setCookie.includes('rb_dashboard_session='));

    const cookieVal = setCookie.split(';')[0];
    assert.ok(!cookieVal.includes(TEST_DASH_TOKEN));
    const stateRes = await apiJson(baseUrl, '/api/v1/dashboard/state', {
      headers: { Cookie: cookieVal },
    });
    assert.equal(stateRes.status, 200);
    assert.equal(stateRes.json.ok, true);
    const stateStr = JSON.stringify(stateRes.json);
    assert.ok(!stateStr.includes(TEST_AI_TOKEN));
    assert.ok(!stateStr.includes(TEST_EXEC_TOKEN));
    assert.ok(!stateStr.includes(TEST_DASH_TOKEN));
  });

  it('13. blocks replayed nonces when X-Request-Timestamp and X-Request-Nonce are supplied', async () => {
    const nonce = `nonce-${crypto.randomUUID()}`;
    const ts = String(Date.now());
    const headers = {
      'X-Request-Timestamp': ts,
      'X-Request-Nonce': nonce,
    };

    const first = await apiJson(baseUrl, '/api/v1/ai/register', {
      method: 'POST',
      token: TEST_AI_TOKEN,
      headers,
      body: { clientName: 'ReplayTester' },
    });
    assert.equal(first.status, 200);

    const replay = await apiJson(baseUrl, '/api/v1/ai/register', {
      method: 'POST',
      token: TEST_AI_TOKEN,
      headers,
      body: { clientName: 'ReplayTester' },
    });
    assert.equal(replay.status, 409);
    assert.equal(replay.json.error.code, 'REPLAY_DETECTED');

    await apiJson(baseUrl, '/api/v1/session/disconnect', {
      method: 'POST',
      token: TEST_DASH_TOKEN,
      body: { sessionId: first.json.sessionId, target: 'session' },
    });
  });
});
