'use strict';

const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { WebSocket } = require('ws');

const { startServer } = require('../server/index');

const TEST_AI_TOKEN = 'websocket_ai_token_high_entropy_0123456789abcdef';
const TEST_EXEC_TOKEN = 'websocket_exec_token_high_entropy_fedcba9876543210';
const TEST_DASH_TOKEN = 'websocket_dash_token_high_entropy_aabbccddeeff0011';

class WsPeer {
  constructor(url) {
    this.ws = new WebSocket(url);
    this.messages = [];
    this.waiters = [];
    this.opened = new Promise((resolve, reject) => {
      this.ws.once('open', resolve);
      this.ws.once('error', reject);
    });

    this.ws.on('message', (raw) => {
      const message = JSON.parse(raw.toString('utf8'));
      this.messages.push(message);
      for (let index = this.waiters.length - 1; index >= 0; index -= 1) {
        const waiter = this.waiters[index];
        if (waiter.predicate(message)) {
          this.waiters.splice(index, 1);
          clearTimeout(waiter.timer);
          waiter.resolve(message);
        }
      }
    });
  }

  send(message) {
    this.ws.send(JSON.stringify(message));
  }

  waitFor(predicate, timeoutMs = 3000) {
    const existing = this.messages.find(predicate);
    if (existing) return Promise.resolve(existing);
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        const index = this.waiters.findIndex((waiter) => waiter.resolve === resolve);
        if (index >= 0) this.waiters.splice(index, 1);
        reject(new Error('Timed out waiting for a WebSocket message.'));
      }, timeoutMs);
      this.waiters.push({ predicate, resolve, timer });
    });
  }

  async close() {
    if (this.ws.readyState === WebSocket.CLOSED) return;
    const closed = new Promise((resolve) => this.ws.once('close', resolve));
    this.ws.close();
    await Promise.race([closed, new Promise((resolve) => setTimeout(resolve, 500))]);
  }
}

async function authenticateAndRegister(peer, role, token, registration) {
  await peer.opened;
  peer.send({ type: 'authenticate', role, token });
  const authenticated = await peer.waitFor((message) => message.type === 'authenticated');
  assert.equal(authenticated.role, role);
  peer.send({ type: 'register', ...registration });
  return peer.waitFor((message) => message.type === 'registered');
}

describe('WebSocket transport', () => {
  let ctx;
  let baseUrl;
  let wsUrl;

  before(async () => {
    ctx = await startServer({
      skipDotenv: true,
      skipSignalHandlers: true,
      returnOnError: true,
      NODE_ENV: 'test',
      HOST: '127.0.0.1',
      PORT: '0',
      TLS_ENABLED: 'false',
      AI_API_TOKEN: TEST_AI_TOKEN,
      EXECUTOR_API_TOKEN: TEST_EXEC_TOKEN,
      DASHBOARD_ADMIN_TOKEN: TEST_DASH_TOKEN,
      ALLOWED_PLACE_IDS: '123456789',
      EXECUTE_LUAU_ENABLED: 'true',
      EXECUTE_LUAU_REQUIRE_APPROVAL: 'false',
      DEFAULT_TOOL_TIMEOUT_MS: '3000',
      MAX_RESULT_BYTES: '262144',
      WS_MAX_MESSAGE_BYTES: '2097152',
      LOG_LEVEL: 'error',
    });
    baseUrl = `http://127.0.0.1:${ctx.port}`;
    wsUrl = `ws://127.0.0.1:${ctx.port}`;
  });

  after(async () => {
    if (ctx) {
      ctx.websocketBridge.close();
      ctx.sessionManager.shutdown();
      await new Promise((resolve) => ctx.server.close(resolve));
    }
  });

  it('shares one port with the HTTP dashboard and moves AI/executor calls over WebSocket', async () => {
    const dashboard = await fetch(`${baseUrl}/`);
    assert.equal(dashboard.status, 200);
    assert.match(await dashboard.text(), /Roblox AI Executor Bridge/);
    const legacyToolRoute = await fetch(`${baseUrl}/api/v1/ai/tools`);
    assert.equal(legacyToolRoute.status, 404);

    const executor = new WsPeer(`${wsUrl}/ws/executor`);
    const execRegistration = await authenticateAndRegister(executor, 'executor', TEST_EXEC_TOKEN, {
      executorName: 'WebSocket Test Executor',
      placeId: 123456789,
      gameName: 'WebSocket Test Place',
      capabilities: { websocket: true },
    });

    const ai = new WsPeer(`${wsUrl}/ws/ai`);
    const aiRegistration = await authenticateAndRegister(ai, 'ai', TEST_AI_TOKEN, {
      sessionId: execRegistration.sessionId,
      clientName: 'WebSocket Test AI',
    });
    assert.equal(aiRegistration.sessionId, execRegistration.sessionId);

    ai.send({ type: 'list_tools', id: 'tools-1', format: 'all' });
    const tools = await ai.waitFor((message) => message.type === 'tools' && message.id === 'tools-1');
    assert.equal(tools.toolCount, 47);
    assert.ok(tools.tools.some((tool) => tool.name === 'ReadFile'));
    assert.ok(tools.tools.some((tool) => tool.name === 'MakeFolder'));
    assert.equal(tools.openaiTools.length, 47);
    assert.equal(tools.mcpTools.length, 47);

    ai.send({
      type: 'tool_call',
      id: 'game-info-call',
      toolName: 'GetGameInfo',
      args: {},
    });
    const task = await executor.waitFor((message) => message.type === 'task' && message.task.toolName === 'GetGameInfo');
    executor.send({
      type: 'result',
      requestId: task.task.requestId,
      ok: true,
      data: { placeId: 123456789, gameName: 'WebSocket Test Place' },
      durationMs: 2,
    });
    const outcome = await ai.waitFor((message) => message.type === 'tool_result' && message.id === 'game-info-call');
    assert.equal(outcome.ok, true);
    assert.equal(outcome.data.placeId, 123456789);

    // Lower-case file API spellings are accepted as aliases and dispatched canonically.
    ai.send({ type: 'tool_call', id: 'read-folder-alias', toolName: 'readfolder', args: {} });
    const fileTask = await executor.waitFor((message) => message.type === 'task' && message.task.toolName === 'ReadFolder');
    executor.send({
      type: 'result', requestId: fileTask.task.requestId, ok: true,
      data: { supported: false, status: 'Not supported', operation: 'listfiles' }, durationMs: 1,
    });
    const fileOutcome = await ai.waitFor((message) => message.type === 'tool_result' && message.id === 'read-folder-alias');
    assert.equal(fileOutcome.toolName, 'ReadFolder');
    assert.equal(fileOutcome.data.status, 'Not supported');

    await ai.close();
    await executor.close();
  });

  it('accepts a large ExecuteLuau .txt payload over WebSocket and normalises it for the executor', async () => {
    const executor = new WsPeer(`${wsUrl}/ws/executor`);
    const execRegistration = await authenticateAndRegister(executor, 'executor', TEST_EXEC_TOKEN, {
      executorName: 'Large Source Executor',
      placeId: 123456789,
      gameName: 'Large Source Place',
    });

    const ai = new WsPeer(`${wsUrl}/ws/ai`);
    await authenticateAndRegister(ai, 'ai', TEST_AI_TOKEN, {
      sessionId: execRegistration.sessionId,
      clientName: 'Large Source AI',
    });

    const source = `-- generated diagnostic source\n${'local value = 1\n'.repeat(1500)}`;
    assert.ok(Buffer.byteLength(source, 'utf8') > 16384);

    ai.send({
      type: 'tool_call',
      id: 'large-source-call',
      toolName: 'ExecuteLuau',
      args: {
        sourceFile: { name: 'large-diagnostic.txt', content: source },
        reason: 'WebSocket source-file regression test',
      },
    });

    const task = await executor.waitFor((message) => message.type === 'task' && message.task.toolName === 'ExecuteLuau');
    assert.equal(task.task.args.code, source);
    assert.equal(task.task.args.sourceFileName, 'large-diagnostic.txt');
    assert.equal(task.task.args.sourceFileBytes, Buffer.byteLength(source, 'utf8'));
    assert.equal(task.task.args.sourceFile, undefined);

    executor.send({
      type: 'result',
      requestId: task.task.requestId,
      ok: true,
      data: { compiled: true, succeeded: true, output: [], durationMs: 4 },
      durationMs: 4,
    });
    const result = await ai.waitFor((message) => message.type === 'tool_result' && message.id === 'large-source-call');
    assert.equal(result.ok, true);

    await ai.close();
    await executor.close();
  });
});
