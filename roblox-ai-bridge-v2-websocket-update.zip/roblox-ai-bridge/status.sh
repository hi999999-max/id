#!/usr/bin/env bash
set -euo pipefail

INSTALL_DIR="/opt/roblox-ai-bridge"
SERVICE_NAME="roblox-ai-bridge"

echo "=== Systemd Service Status ==="
systemctl --no-pager status "${SERVICE_NAME}.service" || true

echo ""
echo "=== Shared HTTP Dashboard / WebSocket Port 3003 ==="
ss -tlnp 2>/dev/null | grep ':3003 ' || echo "Nothing listening on port 3003."

echo ""
echo "=== Local Health Check ==="
if [[ -f "${INSTALL_DIR}/.env" ]]; then
  # Read only HOST, PORT, TLS_ENABLED without printing tokens
  HOST_VAL=$(grep -E '^HOST=' "${INSTALL_DIR}/.env" | cut -d= -f2- || echo "127.0.0.1")
  PORT_VAL=$(grep -E '^PORT=' "${INSTALL_DIR}/.env" | cut -d= -f2- || echo "3003")
  TLS_VAL=$(grep -E '^TLS_ENABLED=' "${INSTALL_DIR}/.env" | cut -d= -f2- || echo "false")
  CHECK_HOST="$HOST_VAL"
  if [[ "$CHECK_HOST" == "0.0.0.0" ]]; then
    CHECK_HOST="127.0.0.1"
  fi
  PROTO="http"
  CURL_OPTS="-fsS"
  if [[ "$TLS_VAL" == "true" ]]; then
    PROTO="https"
    CURL_OPTS="-fsSk"
  fi
  curl $CURL_OPTS "${PROTO}://${CHECK_HOST}:${PORT_VAL}/health" && echo "" || echo "Health check failed."
fi
