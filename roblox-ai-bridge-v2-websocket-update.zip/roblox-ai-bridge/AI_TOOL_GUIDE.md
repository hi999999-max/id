# AI_TOOL_GUIDE.md — Roblox AI Executor Bridge v2 Reference

> **Transport update:** v2 uses **WebSocket** for AI ↔ bridge ↔ executor traffic. The visual dashboard remains an HTTP(S) website on the **same port**. Do not use the dashboard HTTP endpoints to dispatch AI tools.

---

## 1. System Prompt & Operating Rules for Future AI Agents

1. **Authorised environments only.** Operate only in the Roblox experience, account, and test session the user has explicitly authorised.
2. **Real environment.** Tool results come from `BridgeClient.lua` running in a live Roblox client. Never fabricate game state, success, or failure.
3. **WebSocket only for tools.** Connect to `/ws/ai`, authenticate, register, and use `tool_call` messages. The dashboard's HTTP site is for a human administrator only.
4. **Never expose credentials.** Do not repeat, log, save, or include the AI token in responses. The generated `AI_START_PROMPT.txt` is private because it contains that token.
5. **Inspect before acting.** Start with environment tools before movement, interactions, file tools, or code execution.
6. **Use structured tools first.** Prefer `GetNearbyPrompts`, `FindInstances`, `MoveTo`, `ReadFile`, etc. over `ExecuteLuau`.
7. **Minimise actions.** Use bounded radii, result counts, and timeouts. Explain intent before impactful actions when the user has not already asked for them.
8. **Respect policy controls.** `ExecuteLuau` can be disabled or require dashboard approval. Never try to bypass a pending approval, rejection, timeout, or cancellation.
9. **Keep filesystem access sandboxed.** The four file tools are restricted to `roblox-ai-bridge-workspace/` by `BridgeClient.lua`; never imply that they can inspect arbitrary executor or computer files.
10. **Handle failure honestly.** Relay the error code/message, revise the plan, and ask the user when appropriate.

---

## 2. Architecture and URLs

The single Node.js listener uses one TCP port (normally `3003`):

| Part | Transport | URL/path |
|---|---|---|
| Human dashboard | HTTP(S) | `http(s)://HOST:3003/` |
| AI client | WebSocket | `ws(s)://HOST:3003/ws/ai` |
| Roblox executor | WebSocket | `ws(s)://HOST:3003/ws/executor` |
| Health check | HTTP(S) | `GET /health` |

- With WireGuard, use `http://10.66.66.1:3003` for the dashboard and `ws://10.66.66.1:3003/ws/ai` for AI traffic inside the encrypted tunnel.
- With a public TLS certificate, use `https://…` and `wss://…`.
- Do **not** send tokens over public plaintext `http://` / `ws://`.

`BridgeClient.lua` derives its executor WebSocket address from its `ServerUrl` and attaches `/ws/executor`, so it shares the website port automatically.

---

## 3. AI WebSocket Protocol

All messages are UTF-8 JSON objects. The server does not accept token credentials in the URL query string. Send the token only in the first WebSocket message.

### 3.1 Authenticate

Immediately after opening `ws(s)://HOST:PORT/ws/ai`:

```json
{"type":"authenticate","role":"ai","token":"<AI_API_TOKEN>"}
```

Wait for:

```json
{"type":"authenticated","role":"ai","protocol":"websocket","registerRequired":true}
```

### 3.2 Register and retain the session ID

```json
{"type":"register","id":"register-1","clientName":"My AI Agent"}
```

Response:

```json
{
  "type":"registered",
  "id":"register-1",
  "role":"ai",
  "sessionId":"sess_…",
  "aiClientId":"ai_…",
  "executorConnected":true,
  "policy":{"executeLuauEnabled":true,"executeLuauRequireApproval":true},
  "toolCount":47
}
```

Save `sessionId`. A WebSocket is authorised only for the session it registered; do not substitute another session ID.

### 3.3 Discover tools

```json
{"type":"list_tools","id":"tools-1","format":"all"}
```

`format` can be `default`, `openai`, `mcp`, or `all`. The response has `type: "tools"`, `toolCount`, `tools`, and optionally `openaiTools` / `mcpTools`.

### 3.4 Call a tool

```json
{
  "type":"tool_call",
  "id":"inspect-1",
  "sessionId":"sess_…",
  "toolName":"GetGameInfo",
  "args":{}
}
```

The matching response uses the same `id`:

```json
{
  "type":"tool_result",
  "id":"inspect-1",
  "ok":true,
  "requestId":"req_…",
  "sessionId":"sess_…",
  "toolName":"GetGameInfo",
  "status":"completed",
  "data":{ }
}
```

- `wait` defaults to `true`, so `tool_result` arrives after executor completion.
- Set `"wait": false` to receive an accepted result immediately, then query status.
- Supply a unique `id` for every WebSocket command. Optionally supply a unique `requestId` / `idempotencyKey` for tool de-duplication.

### 3.5 Async status and cancellation

```json
{"type":"request_status","id":"status-1","sessionId":"sess_…","requestId":"req_…"}
{"type":"cancel_request","id":"cancel-1","sessionId":"sess_…","requestId":"req_…","reason":"User cancelled the action"}
```

Responses are `request_status_result` and `cancelled`.

### 3.6 Errors and server messages

Errors are structured:

```json
{"type":"error","id":"inspect-1","error":{"code":"INVALID_INPUT","message":"…","details":[]}}
```

The executor receives server-pushed `task` and `control` messages. An AI may receive `disconnect` if a human dashboard operator disconnects its session.

---

## 4. Large `ExecuteLuau` Text-File Payloads

Use direct `args.code` for source up to **16 KB**. For a larger authorised diagnostic script, attach it as an in-message `.txt` file object; this is the intended 16 KB bypass:

```json
{
  "type":"tool_call",
  "id":"large-diagnostic-1",
  "sessionId":"sess_…",
  "toolName":"ExecuteLuau",
  "args":{
    "sourceFile":{
      "name":"diagnostic.txt",
      "content":"-- complete Luau source goes here"
    },
    "timeoutMs":5000,
    "reason":"Explain the bounded authorised diagnostic"
  }
}
```

Rules:

- `sourceFile.name` must end in `.txt`.
- Send exactly one of `code` or `sourceFile`, never both.
- The default configured maximum for `sourceFile.content` is 1 MiB (`EXECUTE_LUAU_MAX_FILE_BYTES`); WebSocket messages default to 2 MiB (`WS_MAX_MESSAGE_BYTES`).
- The server normalises the file into executor `code`, preserves only filename/size metadata for dashboard review, and limits dashboard code preview to 16,000 characters.
- This changes transport size, **not** safety policy: the dashboard may still require manual approval and the executor must still expose `loadstring`.

---

## 5. Tool Catalog (47 tools)

### A. Environment inspection (1–15)

| Tool | Typical use |
|---|---|
| `GetGameInfo` | Game name, PlaceId, JobId, game/creator information. |
| `GetLocalPlayerInfo` | Local player identity, team, account age, character state. |
| `GetCharacterState` | Position, velocity, health, humanoid state. |
| `GetCameraState` | Current camera position, direction, FOV, viewport. |
| `GetWorkspaceSummary` | Bounded Workspace overview. |
| `GetDescendants` | Traverse an instance hierarchy with pagination. |
| `GetChildren` | List direct children of an instance. |
| `FindInstances` | Find by name fragment and/or class. |
| `SearchWorkspace` | Search visible workspace names/tags/prompt text. |
| `GetInstanceInfo` | Instance metadata and path. |
| `GetInstanceProperties` | Read an allowlisted property set. |
| `GetInstanceAttributes` | Read custom attributes. |
| `GetCollectionServiceTags` | Inspect tags or tagged instances. |
| `GetLightingInfo` | Lighting configuration. |
| `GetVisibleGuiTree` | Bounded visible PlayerGui tree. |

### B. Surrounding environment (16–24)

`GetNearbyParts`, `GetNearbyModels`, `GetNearbyPlayers`, `GetNearbyInteractables`, `GetNearbyPrompts`, `GetNearestObject`, `GetObjectsInRadius`, `GetNavigationPath`, `GetMapOverview`.

Use `radius`, `maxResults`, `maxDepth`, and pagination conservatively. Do not request unbounded scans.

### C. Movement and navigation (25–35)

`MoveTo`, `MoveDirection`, `StopMovement`, `Jump`, `FacePosition`, `FollowPath`, `CancelMovement`, `GetMovementStatus`, `GetDistanceTo`, `WaitForObject`, `WaitForStateChange`.

Before moving, inspect current state and route. `MoveTo`, `FollowPath`, and waits can take time; use a realistic `timeoutMs` on the outer tool call or call asynchronously.

### D. Interaction (36–42)

`InteractWithPrompt`, `InspectInteractable`, `InspectGui`, `ClickVisibleGuiButton`, `GetAvailableTools`, `GetCurrentTasks`, `GetExecutorCapabilities`.

Always inspect target paths/visibility before triggering interaction. Executor-specific functions such as `fireproximityprompt` may be unavailable; check `GetExecutorCapabilities`.

### E. Sandboxed executor files (43–46)

| Tool | Executor function | Notes |
|---|---|---|
| `ReadFile` | `readfile` | Reads UTF-8 text from `roblox-ai-bridge-workspace/`; bounded return size. |
| `ReadFolder` | `listfiles` | Lists the sandbox workspace or a relative subfolder. |
| `MakeFile` | `writefile` | Writes UTF-8 text in the sandbox; existing files need `overwrite: true`. |
| `MakeFolder` | `makefolder` | Creates a sandbox-relative folder. |

If the executor lacks a required file API, the tool returns a successful structured result containing `status: "Not supported"`, rather than pretending that the operation succeeded. The lowercase spellings `readfile`, `readfolder`, `makefile`, and `makefolder` are accepted aliases, but `list_tools` advertises the canonical PascalCase names. Paths are relative only; no `..`, absolute paths, or backslashes are allowed.

### F. Code execution (47)

`ExecuteLuau` runs a diagnostic script after policy checks. Use `code` or the `.txt` `sourceFile` form described above. Include a concise `reason`; it appears in the human approval dashboard. Use only when structured tools cannot solve the task.

---

## 6. Suggested Startup Workflow

1. Open the AI WebSocket; authenticate and register.
2. Send `list_tools` and rely on the returned schemas rather than hard-coding arguments.
3. Call, in order: `GetGameInfo`, `GetLocalPlayerInfo`, `GetCharacterState`, `GetWorkspaceSummary`, and `GetNearbyInteractables`.
4. Summarise the observed game, player location/state, and viable nearby interactions.
5. Wait for the user’s concrete task.
6. For a task, inspect a precise target, take the minimum action, and report tool-derived outcome.

---

## 7. Important Error Codes

| Code | Meaning / response |
|---|---|
| `UNAUTHORIZED` | Bad/missing token or failed WebSocket authentication. Recheck the correct role token. |
| `FORBIDDEN` | Role/session mismatch or an operation is not permitted. |
| `EXECUTOR_OFFLINE` | No active executor WebSocket for the session. Ask the user to start/reconnect BridgeClient.lua. |
| `AI_NOT_REGISTERED` | Register the AI WebSocket before tool calls. |
| `PLACE_NOT_ALLOWED` | Executor PlaceId is not in `ALLOWED_PLACE_IDS`. |
| `UNKNOWN_TOOL` / `INVALID_INPUT` | Re-run `list_tools`; correct tool name/arguments. |
| `PAYLOAD_TOO_LARGE` | Reduce output size, use bounds, or use the approved `sourceFile` mechanism for large ExecuteLuau input. |
| `TOOL_DISABLED` | Human policy disabled `ExecuteLuau`. Do not try to work around it. |
| `REQUEST_REJECTED` | Dashboard rejected the request. Respect it. |
| `REQUEST_TIMEOUT` | Executor did not dispatch/finish in time. Inspect connection and retry only if safe. |
| `REQUEST_CANCELLED` | The user/dashboard stopped the request. Do not assume effects completed. |
| `NOT_SUPPORTED` / `status: "Not supported"` | Executor lacks a required capability, commonly a file function. Choose another method. |
| `WEBSOCKET_PROTOCOL_ERROR` | Send a valid JSON object/type for the authenticated endpoint. |

---

## 8. Human Dashboard Notes

The dashboard remains HTTP(S) at `/`. It uses an opaque, server-side HttpOnly session ID after the human enters `DASHBOARD_ADMIN_TOKEN`; it no longer stores the raw admin token in the browser cookie. It can view WebSocket-connected AI/executor status, approve or reject ExecuteLuau, disconnect clients, stop active work, and view history.

Do not ask the dashboard to relay AI messages. Keep tool traffic on `/ws/ai`.
