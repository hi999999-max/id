#!/usr/bin/env bash
set -euo pipefail

# Safe in-place upgrade. Run this script FROM the freshly extracted v2 package;
# it copies code into /opt while retaining your existing .env, certificates,
# WireGuard files, and the private generated prompt until it is regenerated.
INSTALL_DIR="/opt/roblox-ai-bridge"
SERVICE_NAME="roblox-ai-bridge"
SERVICE_USER="robloxbridge"
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ $EUID -ne 0 ]]; then
  echo "ERROR: Run update.sh as root (for example: sudo bash update.sh)."
  exit 1
fi
if [[ ! -d "$INSTALL_DIR" ]]; then
  echo "ERROR: ${INSTALL_DIR} does not exist. Run install.sh for a first installation."
  exit 1
fi

was_active=0
if systemctl is-active --quiet "${SERVICE_NAME}.service"; then
  was_active=1
  echo "Stopping ${SERVICE_NAME} before replacing application files..."
  systemctl stop "${SERVICE_NAME}.service"
fi

restore_on_failure() {
  local status=$?
  if [[ $status -ne 0 ]]; then
    echo "UPDATE FAILED. Your .env and certificates were preserved."
    echo "Inspect: journalctl -u ${SERVICE_NAME} -n 80 --no-pager"
  fi
  exit "$status"
}
trap restore_on_failure ERR

echo "Updating ${SERVICE_NAME} in ${INSTALL_DIR} from ${SOURCE_DIR}..."
if [[ "$SOURCE_DIR" != "$INSTALL_DIR" ]]; then
  tar -C "$SOURCE_DIR" \
    --exclude='.env' \
    --exclude='node_modules' \
    --exclude='certs/*' \
    --exclude='wireguard-clients/*' \
    --exclude='AI_START_PROMPT.txt' \
    -cf - . | tar -C "$INSTALL_DIR" -xf -
fi

chmod +x "$INSTALL_DIR"/*.sh "$INSTALL_DIR"/scripts/*.sh 2>/dev/null || true
cd "$INSTALL_DIR"

if [[ ! -f .env ]]; then
  cp .env.example .env
fi

if [[ -f package-lock.json ]]; then
  npm ci --omit=dev
else
  npm install --omit=dev
fi

# This preserves valid existing tokens and automatically regenerates the private AI prompt.
# Neither script prints a token.
node "$INSTALL_DIR/scripts/generate-tokens.js"

chown -R "${SERVICE_USER}:${SERVICE_USER}" "$INSTALL_DIR"
chmod 600 "$INSTALL_DIR/.env" "$INSTALL_DIR/AI_START_PROMPT.txt"

# Pick up service-description/hardening changes included by this release.
NODE_BIN=$(command -v node)
sed "s|/usr/bin/node|${NODE_BIN}|g" "$INSTALL_DIR/deploy/roblox-ai-bridge.service" > "/etc/systemd/system/${SERVICE_NAME}.service"
systemctl daemon-reload
systemctl enable "${SERVICE_NAME}.service" >/dev/null
systemctl restart "${SERVICE_NAME}.service"
sleep 2

if systemctl is-active --quiet "${SERVICE_NAME}.service"; then
  echo "SUCCESS: ${SERVICE_NAME} v2 is running."
  echo "Dashboard: use your existing HTTP(S) URL. AI: use /ws/ai. Executor: use /ws/executor on the same port."
  systemctl --no-pager status "${SERVICE_NAME}.service" | head -n 18
else
  echo "ERROR: Service did not stay active."
  journalctl -u "${SERVICE_NAME}" -n 80 --no-pager || true
  exit 1
fi

trap - ERR
