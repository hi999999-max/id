# Upgrade Guide — existing VPS installation to Roblox AI Bridge v2

Use this guide if you already have the old bridge installed at `/opt/roblox-ai-bridge` on your VPS (`77.68.33.65`). The v2 update preserves your `.env`, role tokens, certificates, and WireGuard files.

## Before starting

- Keep your current bridge URL noted (WireGuard or HTTPS).
- Download the new zip archive created for this release.
- Do **not** delete `/opt/roblox-ai-bridge/.env`.
- Expect the existing service to be stopped briefly while files/dependencies are replaced.

## 1. Upload the new zip

From your own computer:

```bash
scp roblox-ai-bridge-v2-websocket-update.zip root@77.68.33.65:/root/
```

## 2. Extract it into a new temporary source folder

SSH to the VPS, then run:

```bash
cd /root
rm -rf roblox-ai-bridge-v2-update
unzip -o roblox-ai-bridge-v2-websocket-update.zip -d roblox-ai-bridge-v2-update
cd /root/roblox-ai-bridge-v2-update/roblox-ai-bridge
```

If the extracted project folder has a different name, `cd` into the folder that contains `update.sh`, `package.json`, and `server/`.

## 3. Run the upgrade script

```bash
sudo bash ./update.sh
```

The script will:

1. stop the `roblox-ai-bridge` service;
2. copy the v2 application files into `/opt/roblox-ai-bridge`;
3. preserve `.env`, `certs/`, `wireguard-clients/`, and the existing private prompt until regeneration;
4. install the new `ws` Node dependency with `npm ci --omit=dev`;
5. preserve valid existing role tokens (or generate only missing/placeholder ones);
6. regenerate private `/opt/roblox-ai-bridge/AI_START_PROMPT.txt` from the current `.env`;
7. refresh the systemd unit and restart the service.

No token is printed by the updater.

## 4. Verify server and WebSocket upgrade

```bash
sudo bash /opt/roblox-ai-bridge/status.sh
sudo journalctl -u roblox-ai-bridge -n 80 --no-pager
```

Look for a startup log mentioning:

```text
websocketEndpoints: ["/ws/ai", "/ws/executor"]
```

The dashboard URL stays the same port as before. For example:

- WireGuard dashboard: `http://10.66.66.1:3003/`
- WireGuard AI endpoint: `ws://10.66.66.1:3003/ws/ai`
- Public TLS dashboard: `https://YOUR_HOST:3003/`
- Public TLS AI endpoint: `wss://YOUR_HOST:3003/ws/ai`

## 5. Set the public URL used in the generated AI prompt (recommended)

If `/opt/roblox-ai-bridge/.env` does not already contain the real externally reachable address, edit it:

```bash
sudo nano /opt/roblox-ai-bridge/.env
```

Set one value, for example:

```dotenv
BRIDGE_PUBLIC_URL=http://10.66.66.1:3003
```

or for public TLS:

```dotenv
BRIDGE_PUBLIC_URL=https://your-domain.example:3003
```

Then regenerate the prompt without rotating any token:

```bash
sudo -u robloxbridge node /opt/roblox-ai-bridge/scripts/generate-ai-start-prompt.js
sudo chmod 600 /opt/roblox-ai-bridge/AI_START_PROMPT.txt
```

Read it only on the VPS/private machine:

```bash
sudo cat /opt/roblox-ai-bridge/AI_START_PROMPT.txt
```

It now includes the current AI token and `/ws/ai` connection instructions.

## 6. Replace your running Roblox executor script

This is required: v1 `BridgeClient.lua` polls HTTP, while v2 uses WebSocket.

1. Open `/opt/roblox-ai-bridge/executor/BridgeClient.lua` from the updated package.
2. Keep your existing `EXECUTOR_API_TOKEN` in the `ExecutorToken` field.
3. Set `ServerUrl` to the same base website address:

   ```lua
   ServerUrl = "http://10.66.66.1:3003", -- WireGuard example
   WebSocketPath = "/ws/executor",
   ExecutorToken = "YOUR_EXISTING_EXECUTOR_API_TOKEN",
   ```

4. Paste/execute the whole updated script in your authorised Roblox test session.
5. Confirm the Roblox console says `WebSocket connected!`.

## 7. Use the refreshed dashboard and AI prompt

- Hard refresh the browser dashboard (`Ctrl+F5` / `Cmd+Shift+R`).
- Sign in again with the existing `DASHBOARD_ADMIN_TOKEN`; service restart intentionally clears opaque dashboard sessions.
- Give your WebSocket-capable AI client the regenerated `AI_START_PROMPT.txt` and updated `AI_TOOL_GUIDE.md`.
- It should use `/ws/ai`, not legacy HTTP tool-call/poll endpoints. v2 disables those legacy routes by default; only set `ENABLE_LEGACY_HTTP_API=true` temporarily if you intentionally need to migrate an old client.

## If the update fails

Your `.env` and certificates remain in place. Run:

```bash
sudo journalctl -u roblox-ai-bridge -n 120 --no-pager
sudo systemctl status roblox-ai-bridge --no-pager
```

Common fixes:

- **`Cannot find module 'ws'`:** re-run `sudo bash /root/roblox-ai-bridge-v2-update/roblox-ai-bridge/update.sh` from the fresh source folder.
- **Public plaintext bind refused:** use WireGuard or HTTPS/WSS; do not set `ALLOW_INSECURE_PUBLIC_HTTP=true` unless a trusted TLS reverse proxy terminates encryption.
- **Executor cannot connect:** replace the old BridgeClient.lua with v2 and use an executor that supports a WebSocket API.
- **Dashboard login fails:** verify the admin token in `.env`, then `sudo systemctl restart roblox-ai-bridge`; use the same browser scheme/host consistently.
