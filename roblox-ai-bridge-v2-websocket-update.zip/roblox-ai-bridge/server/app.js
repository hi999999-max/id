'use strict';

const path = require('path');
const express = require('express');
const helmet = require('helmet');

const { ERROR_CODES } = require('../shared/constants');
const { createLogger } = require('./logger');
const { createAuthMiddleware } = require('./middleware/auth');
const { createRateLimiters } = require('./middleware/rateLimit');
const { createReplayGuard } = require('./middleware/replayGuard');
const { ToolRegistry } = require('./services/toolRegistry');
const { SessionManager, BridgeError } = require('./services/sessionManager');
const { createMcpHandler } = require('./services/mcpHandler');

const { createHealthRouter } = require('./routes/health');
const { createConnectRouter } = require('./routes/connect');
const { createExecutorRouter } = require('./routes/executor');
const { createAiRouter } = require('./routes/ai');
const { createSessionRouter } = require('./routes/session');
const { createDashboardRouter } = require('./routes/dashboard');
const { createMcpRouter } = require('./routes/mcp');

function createApp(config) {
  const logger = createLogger({
    level: config.logLevel,
    secrets: [config.aiApiToken, config.executorApiToken, config.dashboardAdminToken],
  });

  const app = express();
  app.disable('x-powered-by');
  if (config.trustProxy) {
    app.set('trust proxy', 1);
  }

  // Security headers via Helmet
  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'"],
          styleSrc: ["'self'"],
          imgSrc: ["'self'", 'data:'],
          connectSrc: ["'self'"],
          objectSrc: ["'none'"],
          frameAncestors: ["'none'"],
          baseUri: ["'self'"],
          formAction: ["'self'"],
        },
      },
      crossOriginEmbedderPolicy: false,
      hsts: config.tlsEnabled ? undefined : false,
    })
  );

  // Strict non-wildcard CORS (disabled unless specific origins are configured)
  app.use((req, res, next) => {
    const origin = req.get('origin');
    if (origin && config.corsAllowedOrigins.includes(origin)) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Vary', 'Origin');
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
      res.setHeader(
        'Access-Control-Allow-Headers',
        'Content-Type, Authorization, X-Api-Key, X-Ai-Token, X-Executor-Token, X-Dashboard-Token, X-Session-Id, X-Request-Timestamp, X-Request-Nonce'
      );
      res.setHeader('Access-Control-Allow-Credentials', 'true');
      if (req.method === 'OPTIONS') {
        return res.status(204).end();
      }
    }
    return next();
  });

  // Strict JSON body size limit
  app.use(
    express.json({
      limit: config.maxRequestBodyBytes,
      strict: true,
    })
  );

  // Core services
  const auth = createAuthMiddleware(config, logger);
  const rateLimiters = createRateLimiters();
  const replayGuard = createReplayGuard(config, logger);
  const toolRegistry = new ToolRegistry(config);
  const sessionManager = new SessionManager(config, logger, toolRegistry);
  const mcpHandler = createMcpHandler({ sessionManager, toolRegistry, logger });

  // Static dashboard UI (contains zero secrets)
  const dashboardDir = path.resolve(__dirname, '../dashboard');
  app.use(
    express.static(dashboardDir, {
      index: 'index.html',
      etag: true,
      maxAge: config.nodeEnv === 'production' ? '1h' : 0,
    })
  );

  // Dashboard/health remain HTTP(S). AI and executor traffic is WebSocket-first in v2.
  app.use(createHealthRouter({ auth, config, toolRegistry }));
  app.use(createDashboardRouter({ auth, config, sessionManager, rateLimiters }));

  // Optional short-term migration path for old clients. It is OFF by default so normal tool,
  // executor, and AI traffic cannot silently fall back to HTTP polling.
  if (config.legacyHttpApiEnabled) {
    app.use(createConnectRouter({ auth, sessionManager, rateLimiters, replayGuard }));
    app.use(createExecutorRouter({ auth, sessionManager, rateLimiters, replayGuard }));
    app.use(createAiRouter({ auth, sessionManager, toolRegistry, rateLimiters, replayGuard }));
    app.use(createSessionRouter({ auth, sessionManager, rateLimiters, replayGuard }));
    app.use(createMcpRouter({ auth, mcpHandler, rateLimiters }));
    logger.warn('Legacy HTTP AI/executor API is enabled; migrate clients to /ws/ai and /ws/executor.');
  }

  // 404 handler for API paths
  app.use('/api', (req, res) => {
    res.status(404).json({
      ok: false,
      error: {
        code: 'NOT_FOUND',
        message: `Endpoint ${req.method} ${req.originalUrl} not found.`,
      },
    });
  });

  // Central structured error handler
  app.use((err, req, res, _next) => {
    if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
      return res.status(400).json({
        ok: false,
        error: {
          code: ERROR_CODES.INVALID_INPUT,
          message: 'Malformed JSON request body.',
        },
      });
    }

    if (err.type === 'entity.too.large') {
      return res.status(413).json({
        ok: false,
        error: {
          code: ERROR_CODES.PAYLOAD_TOO_LARGE,
          message: `Request payload exceeds ${config.maxRequestBodyBytes} bytes.`,
        },
      });
    }

    if (err instanceof BridgeError) {
      return res.status(err.statusCode).json({
        ok: false,
        error: {
          code: err.code,
          message: err.message,
          details: err.details,
        },
      });
    }

    logger.error('Unhandled server error', {
      path: req.originalUrl,
      method: req.method,
      error: err,
    });

    return res.status(500).json({
      ok: false,
      error: {
        code: ERROR_CODES.INTERNAL_ERROR,
        message: 'Internal server error.',
      },
    });
  });

  return {
    app,
    config,
    logger,
    auth,
    sessionManager,
    toolRegistry,
  };
}

module.exports = {
  createApp,
};
