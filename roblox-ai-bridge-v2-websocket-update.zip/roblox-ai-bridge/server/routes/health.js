'use strict';

const express = require('express');
const { SERVICE_NAME, SERVICE_VERSION, PROTOCOL, ROLES } = require('../../shared/constants');

function createHealthRouter({ auth, config, toolRegistry }) {
  const router = express.Router();

  router.get('/health', (req, res) => {
    res.json({
      ok: true,
      status: 'healthy',
      service: SERVICE_NAME,
      version: SERVICE_VERSION,
      timestamp: new Date().toISOString(),
    });
  });

  router.get(
    '/api/v1/info',
    auth.requireRole(ROLES.AI, ROLES.EXECUTOR, ROLES.DASHBOARD),
    (req, res) => {
      res.json({
        ok: true,
        service: SERVICE_NAME,
        version: SERVICE_VERSION,
        protocol: PROTOCOL,
        authenticatedAs: req.authRole,
        port: config.port,
        tlsEnabled: config.tlsEnabled,
        toolCount: toolRegistry.listTools().length,
        websocket: {
          ai: '/ws/ai',
          executor: '/ws/executor',
          samePortAsDashboard: true,
          authentication: 'first JSON message: { type: "authenticate", token: "..." }',
        },
        legacyHttpApiEnabled: config.legacyHttpApiEnabled,
        ...(config.legacyHttpApiEnabled
          ? {
              legacyHttpEndpoints: {
                executorRegister: '/api/v1/executor/register',
                executorHeartbeat: '/api/v1/executor/heartbeat',
                executorPoll: '/api/v1/executor/poll',
                executorResult: '/api/v1/executor/result',
                aiRegister: '/api/v1/ai/register',
                aiTools: '/api/v1/ai/tools',
                aiToolCall: '/api/v1/ai/tool-call',
                sessionDisconnect: '/api/v1/session/disconnect',
                mcp: '/mcp',
              },
            }
          : {}),
      });
    }
  );

  return router;
}

module.exports = {
  createHealthRouter,
};
