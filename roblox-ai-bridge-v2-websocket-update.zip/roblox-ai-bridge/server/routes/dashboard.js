'use strict';

const express = require('express');
const { z } = require('zod');
const { ROLES, ERROR_CODES } = require('../../shared/constants');
const { validateBody } = require('../middleware/validate');

const LoginSchema = z.object({
  token: z.string().min(1).max(512),
}).strict();

const SessionActionSchema = z.object({
  sessionId: z.string().min(4).max(128),
}).strict();

const RequestActionSchema = z.object({
  sessionId: z.string().min(4).max(128),
  requestId: z.string().min(4).max(128),
  reason: z.string().max(240).optional(),
}).strict();

const TogglePolicySchema = z.object({
  executeLuauEnabled: z.boolean().optional(),
  executeLuauRequireApproval: z.boolean().optional(),
}).strict();

const EmergencyStopSchema = z.object({
  sessionId: z.string().min(4).max(128).optional(),
}).strict();

function dashboardCookieOptions(req, config) {
  // req.secure supports TLS termination at a trusted reverse proxy when TRUST_PROXY=true.
  return {
    httpOnly: true,
    sameSite: 'strict',
    secure: Boolean(config.tlsEnabled || req.secure),
    maxAge: 12 * 60 * 60 * 1000,
    path: '/',
  };
}

function createDashboardRouter({ auth, config, sessionManager, rateLimiters }) {
  const router = express.Router();

  router.post(
    '/api/v1/dashboard/login',
    rateLimiters.authActions,
    validateBody(LoginSchema),
    (req, res) => {
      const valid = auth.timingSafeMatch(req.validatedBody.token.trim(), config.dashboardAdminToken);
      if (!valid) {
        return res.status(401).json({
          ok: false,
          error: {
            code: ERROR_CODES.UNAUTHORIZED,
            message: 'Invalid dashboard admin token.',
          },
        });
      }

      // Store only an opaque, server-side session id in the browser. The long-lived admin
      // token never appears in a cookie, browser storage, dashboard response, or UI source.
      const session = auth.createDashboardSession();
      res.set('Cache-Control', 'no-store');
      res.cookie('rb_dashboard_session', session.sessionId, dashboardCookieOptions(req, config));
      return res.json({ ok: true, authenticated: true, expiresAt: new Date(session.expiresAt).toISOString() });
    }
  );

  router.post('/api/v1/dashboard/logout', (req, res) => {
    auth.destroyDashboardSession(req);
    res.set('Cache-Control', 'no-store');
    res.clearCookie('rb_dashboard_session', {
      path: '/',
      sameSite: 'strict',
      secure: Boolean(config.tlsEnabled || req.secure),
    });
    res.json({ ok: true, authenticated: false });
  });

  router.get(
    '/api/v1/dashboard/state',
    rateLimiters.generalApi,
    auth.requireRole(ROLES.DASHBOARD),
    (req, res) => {
      res.set('Cache-Control', 'no-store');
      res.json({ ok: true, ...sessionManager.getDashboardState() });
    }
  );

  router.post(
    '/api/v1/dashboard/actions/disconnect-executor',
    rateLimiters.generalApi,
    auth.requireRole(ROLES.DASHBOARD),
    validateBody(SessionActionSchema),
    (req, res, next) => {
      try {
        res.json(sessionManager.disconnectExecutor(req.validatedBody.sessionId, 'Disconnected from dashboard'));
      } catch (err) {
        next(err);
      }
    }
  );

  router.post(
    '/api/v1/dashboard/actions/disconnect-ai',
    rateLimiters.generalApi,
    auth.requireRole(ROLES.DASHBOARD),
    validateBody(SessionActionSchema),
    (req, res, next) => {
      try {
        res.json(sessionManager.disconnectAi(req.validatedBody.sessionId, 'Disconnected from dashboard'));
      } catch (err) {
        next(err);
      }
    }
  );

  router.post(
    '/api/v1/dashboard/actions/end-session',
    rateLimiters.generalApi,
    auth.requireRole(ROLES.DASHBOARD),
    validateBody(SessionActionSchema),
    (req, res, next) => {
      try {
        res.json(sessionManager.endSession(req.validatedBody.sessionId, 'Ended from dashboard'));
      } catch (err) {
        next(err);
      }
    }
  );

  router.post(
    '/api/v1/dashboard/actions/clear-history',
    rateLimiters.generalApi,
    auth.requireRole(ROLES.DASHBOARD),
    (req, res) => {
      res.json(sessionManager.clearHistory());
    }
  );

  router.post(
    '/api/v1/dashboard/actions/toggle-execute-luau',
    rateLimiters.generalApi,
    auth.requireRole(ROLES.DASHBOARD),
    validateBody(TogglePolicySchema),
    (req, res) => {
      res.json(sessionManager.updatePolicy(req.validatedBody));
    }
  );

  router.post(
    '/api/v1/dashboard/actions/approve-request',
    rateLimiters.generalApi,
    auth.requireRole(ROLES.DASHBOARD),
    validateBody(RequestActionSchema),
    (req, res, next) => {
      try {
        res.json(sessionManager.approvePendingRequest(req.validatedBody.sessionId, req.validatedBody.requestId));
      } catch (err) {
        next(err);
      }
    }
  );

  router.post(
    '/api/v1/dashboard/actions/reject-request',
    rateLimiters.generalApi,
    auth.requireRole(ROLES.DASHBOARD),
    validateBody(RequestActionSchema),
    (req, res, next) => {
      try {
        res.json(
          sessionManager.rejectPendingRequest(
            req.validatedBody.sessionId,
            req.validatedBody.requestId,
            req.validatedBody.reason || 'Rejected from dashboard'
          )
        );
      } catch (err) {
        next(err);
      }
    }
  );

  router.post(
    '/api/v1/dashboard/actions/emergency-stop',
    rateLimiters.generalApi,
    auth.requireRole(ROLES.DASHBOARD),
    validateBody(EmergencyStopSchema),
    (req, res) => {
      res.json(sessionManager.emergencyStop(req.validatedBody.sessionId || null));
    }
  );

  return router;
}

module.exports = {
  createDashboardRouter,
};
