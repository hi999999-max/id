'use strict';

const crypto = require('crypto');
const { ROLES, ERROR_CODES } = require('../../shared/constants');

const DASHBOARD_SESSION_TTL_MS = 12 * 60 * 60 * 1000;

function timingSafeMatch(provided, expected) {
  if (typeof provided !== 'string' || typeof expected !== 'string') return false;
  if (!provided || !expected) return false;
  const bufA = Buffer.from(provided, 'utf8');
  const bufB = Buffer.from(expected, 'utf8');
  if (bufA.length !== bufB.length) {
    // Still run timingSafeEqual on equal-length dummy buffers to avoid short-circuit timing leaks.
    crypto.timingSafeEqual(bufB, bufB);
    return false;
  }
  return crypto.timingSafeEqual(bufA, bufB);
}

function parseCookies(cookieHeader) {
  const cookies = {};
  if (!cookieHeader || typeof cookieHeader !== 'string') return cookies;
  const pairs = cookieHeader.split(';');
  for (const pair of pairs) {
    const idx = pair.indexOf('=');
    if (idx > 0) {
      const key = pair.slice(0, idx).trim();
      const val = pair.slice(idx + 1).trim();
      try {
        cookies[key] = decodeURIComponent(val);
      } catch {
        cookies[key] = val;
      }
    }
  }
  return cookies;
}

class DashboardSessionStore {
  constructor({ ttlMs = DASHBOARD_SESSION_TTL_MS } = {}) {
    this.ttlMs = ttlMs;
    this.sessions = new Map();
  }

  create() {
    this.prune();
    const sessionId = `dash_${crypto.randomBytes(32).toString('base64url')}`;
    this.sessions.set(sessionId, Date.now() + this.ttlMs);
    return { sessionId, expiresAt: Date.now() + this.ttlMs };
  }

  has(sessionId) {
    if (typeof sessionId !== 'string' || !sessionId) return false;
    const expiresAt = this.sessions.get(sessionId);
    if (!expiresAt) return false;
    if (expiresAt <= Date.now()) {
      this.sessions.delete(sessionId);
      return false;
    }
    return true;
  }

  revoke(sessionId) {
    if (typeof sessionId === 'string') this.sessions.delete(sessionId);
  }

  prune() {
    const now = Date.now();
    for (const [sessionId, expiresAt] of this.sessions.entries()) {
      if (expiresAt <= now) this.sessions.delete(sessionId);
    }
  }
}

function extractToken(req, roleHint) {
  const authHeader = req.get('authorization');
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.slice(7).trim();
  }

  if (roleHint === ROLES.EXECUTOR) {
    const execHeader = req.get('x-executor-token');
    if (execHeader) return execHeader.trim();
  }

  if (roleHint === ROLES.AI) {
    const aiHeader = req.get('x-ai-token');
    if (aiHeader) return aiHeader.trim();
  }

  if (roleHint === ROLES.DASHBOARD) {
    const dashHeader = req.get('x-dashboard-token');
    if (dashHeader) return dashHeader.trim();
  }

  const apiKey = req.get('x-api-key');
  if (apiKey) return apiKey.trim();

  return '';
}

function createAuthMiddleware(config, logger) {
  const dashboardSessions = new DashboardSessionStore();

  function verifyTokenForRole(token, role) {
    if (role === ROLES.AI) return timingSafeMatch(token, config.aiApiToken);
    if (role === ROLES.EXECUTOR) return timingSafeMatch(token, config.executorApiToken);
    if (role === ROLES.DASHBOARD) return timingSafeMatch(token, config.dashboardAdminToken);
    return false;
  }

  function hasDashboardSession(req) {
    const cookies = parseCookies(req.get('cookie'));
    return dashboardSessions.has(cookies.rb_dashboard_session);
  }

  function verifyRequestForRole(req, role) {
    if (role === ROLES.DASHBOARD) {
      const directToken = extractToken(req, ROLES.DASHBOARD);
      return verifyTokenForRole(directToken, role) || hasDashboardSession(req);
    }
    return verifyTokenForRole(extractToken(req, role), role);
  }

  function detectRoleFromRequest(req) {
    const bearer = extractToken(req, null);
    if (bearer) {
      if (timingSafeMatch(bearer, config.aiApiToken)) return ROLES.AI;
      if (timingSafeMatch(bearer, config.executorApiToken)) return ROLES.EXECUTOR;
      if (timingSafeMatch(bearer, config.dashboardAdminToken)) return ROLES.DASHBOARD;
    }
    const execToken = req.get('x-executor-token');
    if (execToken && timingSafeMatch(execToken.trim(), config.executorApiToken)) return ROLES.EXECUTOR;
    const aiToken = req.get('x-ai-token');
    if (aiToken && timingSafeMatch(aiToken.trim(), config.aiApiToken)) return ROLES.AI;
    if (verifyRequestForRole(req, ROLES.DASHBOARD)) return ROLES.DASHBOARD;
    return null;
  }

  function requireRole(...allowedRoles) {
    return (req, res, next) => {
      for (const role of allowedRoles) {
        if (verifyRequestForRole(req, role)) {
          req.authRole = role;
          return next();
        }
      }

      logger.warn('Authentication failed', {
        path: req.originalUrl,
        method: req.method,
        ip: req.ip,
        expectedRoles: allowedRoles,
      });

      return res.status(401).json({
        ok: false,
        error: {
          code: ERROR_CODES.UNAUTHORIZED,
          message: 'Invalid or missing authentication credentials for this endpoint.',
        },
      });
    };
  }

  function createDashboardSession() {
    return dashboardSessions.create();
  }

  function destroyDashboardSession(req) {
    const cookies = parseCookies(req.get('cookie'));
    dashboardSessions.revoke(cookies.rb_dashboard_session);
  }

  return {
    requireRole,
    detectRoleFromRequest,
    verifyTokenForRole,
    timingSafeMatch,
    createDashboardSession,
    destroyDashboardSession,
    hasDashboardSession,
  };
}

module.exports = {
  createAuthMiddleware,
  timingSafeMatch,
  parseCookies,
};
