'use strict';

const {
  TOOL_DEFINITIONS,
  getToolDefinition,
  toOpenAITools,
  toMcpTools,
} = require('../../shared/toolDefinitions');
const { ERROR_CODES } = require('../../shared/constants');

// Accept the lower-case spellings users commonly associate with executor file APIs
// while advertising one consistent PascalCase tool catalog to AI clients.
const TOOL_ALIASES = new Map([
  ['readfile', 'ReadFile'],
  ['readfolder', 'ReadFolder'],
  ['makefile', 'MakeFile'],
  ['makefolder', 'MakeFolder'],
]);

class ToolRegistry {
  constructor(config) {
    this.config = config;
  }

  listTools() {
    return TOOL_DEFINITIONS.map((tool) => ({
      name: tool.name,
      category: tool.category,
      description: tool.description,
      requiresApprovalPolicy: tool.requiresApprovalPolicy,
      parameters: tool.jsonSchema,
    }));
  }

  getOpenAITools() {
    return toOpenAITools();
  }

  getMcpTools() {
    return toMcpTools();
  }

  getTool(name) {
    return getToolDefinition(name);
  }

  validateToolCall(toolName, rawArgs) {
    const canonicalToolName = TOOL_ALIASES.get(String(toolName).toLowerCase()) || toolName;
    const def = getToolDefinition(canonicalToolName);
    if (!def) {
      return {
        ok: false,
        code: ERROR_CODES.UNKNOWN_TOOL,
        message: `Unknown tool "${toolName}". Send list_tools over the AI WebSocket to inspect available tools.`,
      };
    }

    const argsObj = rawArgs === undefined || rawArgs === null ? {} : rawArgs;
    if (typeof argsObj !== 'object' || Array.isArray(argsObj)) {
      return {
        ok: false,
        code: ERROR_CODES.INVALID_INPUT,
        message: 'Tool arguments must be a JSON object.',
      };
    }

    const parsed = def.zodSchema.safeParse(argsObj);
    if (!parsed.success) {
      return {
        ok: false,
        code: ERROR_CODES.INVALID_INPUT,
        message: `Invalid arguments for tool "${toolName}".`,
        details: parsed.error.issues.map((issue) => ({
          path: issue.path.join('.') || '(root)',
          message: issue.message,
        })),
      };
    }

    let normalizedArgs = parsed.data;

    // Direct source deliberately remains capped at 16 KiB. A larger script must be sent as
    // sourceFile { name: "script.txt", content: "..." } through the WebSocket ExecuteLuau call.
    // The executor receives normalised code only; the original large file object is not retained.
    if (toolName === 'ExecuteLuau') {
      const isFilePayload = Boolean(parsed.data.sourceFile);
      const code = isFilePayload ? parsed.data.sourceFile.content : parsed.data.code;
      const byteLength = Buffer.byteLength(code, 'utf8');
      const byteLimit = isFilePayload
        ? this.config.executeLuauMaxFileBytes
        : this.config.executeLuauMaxCodeBytes;

      if (byteLength > byteLimit) {
        return {
          ok: false,
          code: ERROR_CODES.PAYLOAD_TOO_LARGE,
          message: isFilePayload
            ? `ExecuteLuau sourceFile exceeds EXECUTE_LUAU_MAX_FILE_BYTES (${byteLimit} bytes).`
            : `ExecuteLuau code exceeds maximum size of ${byteLimit} bytes. Use sourceFile with a .txt payload for larger scripts.`,
        };
      }
      if (parsed.data.timeoutMs && parsed.data.timeoutMs > this.config.executeLuauMaxTimeoutMs) {
        return {
          ok: false,
          code: ERROR_CODES.INVALID_INPUT,
          message: `ExecuteLuau timeoutMs cannot exceed ${this.config.executeLuauMaxTimeoutMs} ms.`,
        };
      }

      normalizedArgs = {
        code,
        ...(parsed.data.timeoutMs !== undefined ? { timeoutMs: parsed.data.timeoutMs } : {}),
        ...(parsed.data.reason !== undefined ? { reason: parsed.data.reason } : {}),
        ...(isFilePayload
          ? {
              sourceFileName: parsed.data.sourceFile.name,
              sourceFileBytes: byteLength,
            }
          : {}),
      };
    }

    return {
      ok: true,
      tool: def,
      args: normalizedArgs,
    };
  }
}

module.exports = {
  ToolRegistry,
};
