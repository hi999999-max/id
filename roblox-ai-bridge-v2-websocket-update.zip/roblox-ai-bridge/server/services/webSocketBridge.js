'use strict';

const crypto = require('crypto');
const { URL } = require('url');
const { WebSocketServer, WebSocket } = require('ws');
const { z } = require('zod');

const {
  SERVICE_NAME,
  SERVICE_VERSION,
  PROTOCOL,
  ROLES,
  ERROR_CODES,
} = require('../../shared/constants');
const { BridgeError } = require('./sessionManager');

const CorrelationIdSchema = z.union([
  z.string().min(1).max(128),
  z.number().finite(),
]);
const SessionIdSchema = z.string().min(4).max(128);
const ExecutorIdSchema = z.string().min(4).max(128);
const RequestIdSchema = z.string().min(4).max(128);

const AuthenticateSchema = z.object({
  type: z.literal('authenticate'),
  id: CorrelationIdSchema.optional(),
  role: z.enum([ROLES.AI, ROLES.EXECUTOR]).optional(),
  token: z.string().min(1).max(512),
}).strict();

const ExecutorRegisterSchema = z.object({
  type: z.literal('register'),
  id: CorrelationIdSchema.optional(),
  sessionId: SessionIdSchema.optional(),
  executorName: z.string().min(1).max(100).optional(),
  placeId: z.number().int().nonnegative(),
  jobId: z.string().max(128).optional(),
  gameName: z.string().max(200).optional(),
  playerName: z.string().max(100).optional(),
  playerUserId: z.number().int().nonnegative().optional(),
  capabilities: z.record(z.any()).optional(),
}).strict();

const AiRegisterSchema = z.object({
  type: z.literal('register'),
  id: CorrelationIdSchema.optional(),
  sessionId: SessionIdSchema.optional(),
  clientName: z.string().min(1).max(100).optional(),
}).strict();

const ExecutorHeartbeatSchema = z.object({
  type: z.literal('heartbeat'),
  id: CorrelationIdSchema.optional(),
  sessionId: SessionIdSchema.optional(),
  executorId: ExecutorIdSchema.optional(),
  placeId: z.number().int().nonnegative().optional(),
  jobId: z.string().max(128).optional(),
  gameName: z.string().max(200).optional(),
  capabilities: z.record(z.any()).optional(),
}).strict();

const ExecutorResultSchema = z.object({
  type: z.literal('result'),
  id: CorrelationIdSchema.optional(),
  sessionId: SessionIdSchema.optional(),
  executorId: ExecutorIdSchema.optional(),
  requestId: RequestIdSchema,
  ok: z.boolean(),
  data: z.any().optional(),
  error: z.any().optional(),
  durationMs: z.number().min(0).max(600000).optional(),
  truncated: z.boolean().optional(),
}).strict();

const ToolCallSchema = z.object({
  type: z.literal('tool_call'),
  id: CorrelationIdSchema.optional(),
  sessionId: SessionIdSchema.optional(),
  toolName: z.string().min(1).max(100),
  args: z.record(z.any()).optional(),
  requestId: RequestIdSchema.optional(),
  idempotencyKey: z.string().min(4).max(128).optional(),
  timeoutMs: z.number().int().min(500).max(120000).optional(),
  wait: z.boolean().optional(),
}).strict();

const RequestStatusSchema = z.object({
  type: z.literal('request_status'),
  id: CorrelationIdSchema.optional(),
  sessionId: SessionIdSchema.optional(),
  requestId: RequestIdSchema,
}).strict();

const CancelSchema = z.object({
  type: z.literal('cancel_request'),
  id: CorrelationIdSchema.optional(),
  sessionId: SessionIdSchema.optional(),
  requestId: RequestIdSchema,
  reason: z.string().max(240).optional(),
}).strict();

const ListToolsSchema = z.object({
  type: z.literal('list_tools'),
  id: CorrelationIdSchema.optional(),
  format: z.enum(['default', 'openai', 'mcp', 'all']).optional(),
}).strict();

const InfoSchema = z.object({
  type: z.literal('get_info'),
  id: CorrelationIdSchema.optional(),
}).strict();

const DisconnectSchema = z.object({
  type: z.literal('disconnect'),
  id: CorrelationIdSchema.optional(),
  reason: z.string().max(240).optional(),
}).strict();

function issueDetails(parsed) {
  return parsed.error.issues.map((issue) => ({
    path: issue.path.join('.') || '(root)',
    message: issue.message,
  }));
}

function asBridgeError(err) {
  if (err instanceof BridgeError) return err;
  return new BridgeError(500, ERROR_CODES.INTERNAL_ERROR, 'Internal WebSocket bridge error.');
}

/**
 * WebSocket transport for AI and Roblox executor traffic.
 * The static dashboard remains a conventional HTTP(S) site on the same server.
 */
class WebSocketBridge {
  constructor({ server, config, logger, sessionManager, toolRegistry, auth }) {
    this.server = server;
    this.config = config;
    this.logger = logger;
    this.sessionManager = sessionManager;
    this.toolRegistry = toolRegistry;
    this.auth = auth;

    this.contexts = new Set();
    this.executorContexts = new Map(); // sessionId -> context
    this.aiContexts = new Map(); // sessionId -> context
    this.closed = false;

    this.wss = new WebSocketServer({
      noServer: true,
      clientTracking: false,
      maxPayload: config.wsMaxMessageBytes,
      perMessageDeflate: false,
    });

    this._handleUpgrade = this._handleUpgrade.bind(this);
    this.server.on('upgrade', this._handleUpgrade);
    this.wss.on('connection', (ws, req) => this._onConnection(ws, req));

    this.sessionManager.setRealtimeNotifier((sessionId) => this.flushExecutor(sessionId));
    this.sessionManager.setRealtimeDisconnectNotifier((role, sessionId, clientId, reason) => {
      this.disconnectRealtimeClient(role, sessionId, clientId, reason);
    });

    this.heartbeatTimer = setInterval(() => this._heartbeatSweep(), config.wsPingIntervalMs);
    if (this.heartbeatTimer.unref) this.heartbeatTimer.unref();
  }

  _handleUpgrade(req, socket, head) {
    if (this.closed) {
      socket.destroy();
      return;
    }

    let path;
    try {
      path = new URL(req.url, `http://${req.headers.host || 'localhost'}`).pathname;
    } catch {
      socket.destroy();
      return;
    }

    const role = path === '/ws/ai'
      ? ROLES.AI
      : path === '/ws/executor'
        ? ROLES.EXECUTOR
        : null;

    if (!role) {
      socket.write('HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n');
      socket.destroy();
      return;
    }

    this.wss.handleUpgrade(req, socket, head, (ws) => {
      ws._robloxBridgeRole = role;
      this.wss.emit('connection', ws, req);
    });
  }

  _onConnection(ws, req) {
    const ctx = {
      id: crypto.randomUUID(),
      ws,
      role: ws._robloxBridgeRole,
      authenticated: false,
      sessionId: null,
      executorId: null,
      aiClientId: null,
      isAlive: true,
      closed: false,
      authTimer: null,
      remoteAddress: req.socket && req.socket.remoteAddress ? req.socket.remoteAddress : 'unknown',
    };
    delete ws._robloxBridgeRole;
    this.contexts.add(ctx);

    ctx.authTimer = setTimeout(() => {
      if (!ctx.authenticated) {
        this._send(ctx, this._errorPayload(undefined, ERROR_CODES.UNAUTHORIZED, 'WebSocket authentication timed out.'));
        this._close(ctx, 1008, 'Authentication timeout');
      }
    }, this.config.wsAuthenticationTimeoutMs);
    if (ctx.authTimer.unref) ctx.authTimer.unref();

    ws.on('pong', () => {
      ctx.isAlive = true;
    });

    ws.on('message', (raw, isBinary) => {
      this._onMessage(ctx, raw, isBinary);
    });

    ws.on('error', (err) => {
      // Close events perform the state cleanup. Avoid logging expected transport resets as errors.
      this.logger.debug('WebSocket transport error', {
        role: ctx.role,
        sessionId: ctx.sessionId,
        error: err && err.message ? err.message : String(err),
      });
    });

    ws.on('close', (code, reason) => {
      this._onClose(ctx, code, reason ? reason.toString() : '');
    });
  }

  _onMessage(ctx, raw, isBinary) {
    if (ctx.closed) return;
    if (isBinary) {
      this._send(ctx, this._errorPayload(undefined, ERROR_CODES.WEBSOCKET_PROTOCOL_ERROR, 'Binary WebSocket frames are not supported. Send JSON messages.'));
      return;
    }

    let message;
    try {
      message = JSON.parse(Buffer.isBuffer(raw) ? raw.toString('utf8') : String(raw));
    } catch {
      this._send(ctx, this._errorPayload(undefined, ERROR_CODES.WEBSOCKET_PROTOCOL_ERROR, 'Message must be valid JSON.'));
      return;
    }

    if (!message || typeof message !== 'object' || Array.isArray(message)) {
      this._send(ctx, this._errorPayload(undefined, ERROR_CODES.WEBSOCKET_PROTOCOL_ERROR, 'Message must be a JSON object.'));
      return;
    }

    if (!ctx.authenticated) {
      this._authenticate(ctx, message);
      return;
    }

    this._dispatch(ctx, message).catch((err) => {
      this._handleDispatchError(ctx, message.id, err);
    });
  }

  _authenticate(ctx, message) {
    const parsed = AuthenticateSchema.safeParse(message);
    if (!parsed.success) {
      this._send(ctx, this._errorPayload(message && message.id, ERROR_CODES.WEBSOCKET_PROTOCOL_ERROR, 'Invalid authenticate message.', issueDetails(parsed)));
      this._close(ctx, 1008, 'Invalid authenticate message');
      return;
    }

    if (parsed.data.role && parsed.data.role !== ctx.role) {
      this._send(ctx, this._errorPayload(parsed.data.id, ERROR_CODES.FORBIDDEN, 'The role in the message does not match this WebSocket endpoint.'));
      this._close(ctx, 1008, 'Role mismatch');
      return;
    }

    if (!this.auth.verifyTokenForRole(parsed.data.token, ctx.role)) {
      this.logger.warn('WebSocket authentication failed', {
        role: ctx.role,
        ip: ctx.remoteAddress,
      });
      this._send(ctx, this._errorPayload(parsed.data.id, ERROR_CODES.UNAUTHORIZED, 'Invalid WebSocket credential.'));
      this._close(ctx, 1008, 'Invalid credential');
      return;
    }

    ctx.authenticated = true;
    clearTimeout(ctx.authTimer);
    ctx.authTimer = null;
    this._send(ctx, {
      type: 'authenticated',
      id: parsed.data.id,
      role: ctx.role,
      protocol: PROTOCOL,
      version: SERVICE_VERSION,
      registerRequired: true,
    });
  }

  async _dispatch(ctx, message) {
    const type = message.type;
    if (type === 'register') {
      return ctx.role === ROLES.EXECUTOR
        ? this._registerExecutor(ctx, message)
        : this._registerAi(ctx, message);
    }

    if (type === 'heartbeat' && ctx.role === ROLES.EXECUTOR) {
      return this._heartbeat(ctx, message);
    }
    if (type === 'result' && ctx.role === ROLES.EXECUTOR) {
      return this._submitResult(ctx, message);
    }
    if (type === 'tool_call' && ctx.role === ROLES.AI) {
      return this._toolCall(ctx, message);
    }
    if (type === 'request_status' && ctx.role === ROLES.AI) {
      return this._requestStatus(ctx, message);
    }
    if (type === 'cancel_request' && ctx.role === ROLES.AI) {
      return this._cancelRequest(ctx, message);
    }
    if (type === 'list_tools' && ctx.role === ROLES.AI) {
      return this._listTools(ctx, message);
    }
    if (type === 'get_info') {
      return this._getInfo(ctx, message);
    }
    if (type === 'disconnect') {
      return this._disconnect(ctx, message);
    }

    throw new BridgeError(400, ERROR_CODES.WEBSOCKET_PROTOCOL_ERROR, `Message type "${String(type)}" is not permitted for role "${ctx.role}".`);
  }

  _registerExecutor(ctx, message) {
    const parsed = ExecutorRegisterSchema.safeParse(message);
    if (!parsed.success) {
      throw new BridgeError(400, ERROR_CODES.INVALID_INPUT, 'Invalid executor registration message.', issueDetails(parsed));
    }

    if (ctx.sessionId && ctx.sessionId !== parsed.data.sessionId) {
      this._detachContextFromSession(ctx, 'Executor registered a new session.', true);
    }

    const result = this.sessionManager.registerExecutor({
      sessionId: parsed.data.sessionId,
      executorName: parsed.data.executorName,
      placeId: parsed.data.placeId,
      jobId: parsed.data.jobId,
      gameName: parsed.data.gameName,
      playerName: parsed.data.playerName,
      playerUserId: parsed.data.playerUserId,
      capabilities: parsed.data.capabilities,
    });

    const previous = this.executorContexts.get(result.sessionId);
    if (previous && previous !== ctx) {
      this.executorContexts.delete(result.sessionId);
      previous.sessionId = null;
      this._send(previous, {
        type: 'disconnect',
        reason: 'A newer executor connection registered for this session.',
      });
      this._close(previous, 4001, 'Superseded by a newer executor connection');
    }

    ctx.sessionId = result.sessionId;
    ctx.executorId = result.executorId;
    this.executorContexts.set(result.sessionId, ctx);

    this._send(ctx, {
      type: 'registered',
      id: parsed.data.id,
      role: ROLES.EXECUTOR,
      ...result,
      transport: { kind: 'websocket', path: '/ws/executor' },
    });
    this.flushExecutor(result.sessionId);
  }

  _registerAi(ctx, message) {
    const parsed = AiRegisterSchema.safeParse(message);
    if (!parsed.success) {
      throw new BridgeError(400, ERROR_CODES.INVALID_INPUT, 'Invalid AI registration message.', issueDetails(parsed));
    }

    if (ctx.sessionId && ctx.sessionId !== parsed.data.sessionId) {
      this._detachContextFromSession(ctx, 'AI client registered a new session.', true);
    }

    const result = this.sessionManager.registerAi({
      sessionId: parsed.data.sessionId,
      clientName: parsed.data.clientName,
    });

    const previous = this.aiContexts.get(result.sessionId);
    if (previous && previous !== ctx) {
      this.aiContexts.delete(result.sessionId);
      previous.sessionId = null;
      this._send(previous, {
        type: 'disconnect',
        reason: 'A newer AI connection registered for this session.',
      });
      this._close(previous, 4001, 'Superseded by a newer AI connection');
    }

    ctx.sessionId = result.sessionId;
    ctx.aiClientId = result.aiClientId;
    this.aiContexts.set(result.sessionId, ctx);

    this._send(ctx, {
      type: 'registered',
      id: parsed.data.id,
      role: ROLES.AI,
      ...result,
      transport: { kind: 'websocket', path: '/ws/ai' },
    });
  }

  _heartbeat(ctx, message) {
    const parsed = ExecutorHeartbeatSchema.safeParse(message);
    if (!parsed.success) {
      throw new BridgeError(400, ERROR_CODES.INVALID_INPUT, 'Invalid executor heartbeat message.', issueDetails(parsed));
    }
    const sessionId = this._requireCurrentSession(ctx, parsed.data.sessionId);
    const result = this.sessionManager.executorHeartbeat({
      sessionId,
      executorId: ctx.executorId,
      placeId: parsed.data.placeId,
      jobId: parsed.data.jobId,
      gameName: parsed.data.gameName,
      capabilities: parsed.data.capabilities,
    });
    this._send(ctx, { type: 'heartbeat_ack', id: parsed.data.id, ...result });
    this.flushExecutor(sessionId);
  }

  _submitResult(ctx, message) {
    const parsed = ExecutorResultSchema.safeParse(message);
    if (!parsed.success) {
      throw new BridgeError(400, ERROR_CODES.INVALID_INPUT, 'Invalid executor result message.', issueDetails(parsed));
    }
    const sessionId = this._requireCurrentSession(ctx, parsed.data.sessionId);
    const result = this.sessionManager.submitExecutorResult({
      sessionId,
      executorId: ctx.executorId,
      requestId: parsed.data.requestId,
      ok: parsed.data.ok,
      data: parsed.data.data,
      error: parsed.data.error,
      durationMs: parsed.data.durationMs,
      truncated: parsed.data.truncated,
    });
    this._send(ctx, { type: 'result_ack', id: parsed.data.id, ...result });
    this.flushExecutor(sessionId);
  }

  _toolCall(ctx, message) {
    const parsed = ToolCallSchema.safeParse(message);
    if (!parsed.success) {
      throw new BridgeError(400, ERROR_CODES.INVALID_INPUT, 'Invalid AI tool call message.', issueDetails(parsed));
    }
    const sessionId = this._requireCurrentSession(ctx, parsed.data.sessionId);

    // Do not await this promise: a synchronous call intentionally completes later when the
    // executor returns its result, while the socket can still process heartbeats/results.
    Promise.resolve(this.sessionManager.enqueueToolCall({
      sessionId,
      toolName: parsed.data.toolName,
      args: parsed.data.args || {},
      requestId: parsed.data.requestId,
      idempotencyKey: parsed.data.idempotencyKey,
      timeoutMs: parsed.data.timeoutMs,
      wait: parsed.data.wait,
    })).then((outcome) => {
      this._send(ctx, {
        type: 'tool_result',
        id: parsed.data.id,
        ...outcome,
      });
    }).catch((err) => {
      this._handleDispatchError(ctx, parsed.data.id, err);
    });
  }

  _requestStatus(ctx, message) {
    const parsed = RequestStatusSchema.safeParse(message);
    if (!parsed.success) {
      throw new BridgeError(400, ERROR_CODES.INVALID_INPUT, 'Invalid request status message.', issueDetails(parsed));
    }
    const sessionId = this._requireCurrentSession(ctx, parsed.data.sessionId);
    const result = this.sessionManager.getRequestStatus(sessionId, parsed.data.requestId);
    this._send(ctx, { type: 'request_status_result', id: parsed.data.id, ...result });
  }

  _cancelRequest(ctx, message) {
    const parsed = CancelSchema.safeParse(message);
    if (!parsed.success) {
      throw new BridgeError(400, ERROR_CODES.INVALID_INPUT, 'Invalid cancellation message.', issueDetails(parsed));
    }
    const sessionId = this._requireCurrentSession(ctx, parsed.data.sessionId);
    const result = this.sessionManager.cancelRequest(sessionId, parsed.data.requestId, parsed.data.reason || 'Cancelled by AI client');
    this._send(ctx, { type: 'cancelled', id: parsed.data.id, ...result });
  }

  _listTools(ctx, message) {
    const parsed = ListToolsSchema.safeParse(message);
    if (!parsed.success) {
      throw new BridgeError(400, ERROR_CODES.INVALID_INPUT, 'Invalid list_tools message.', issueDetails(parsed));
    }
    const format = parsed.data.format || 'default';
    const tools = this.toolRegistry.listTools();
    const response = {
      type: 'tools',
      id: parsed.data.id,
      toolCount: tools.length,
      tools,
    };
    if (format === 'openai' || format === 'all') response.openaiTools = this.toolRegistry.getOpenAITools();
    if (format === 'mcp' || format === 'all') response.mcpTools = this.toolRegistry.getMcpTools();
    this._send(ctx, response);
  }

  _getInfo(ctx, message) {
    const parsed = InfoSchema.safeParse(message);
    if (!parsed.success) {
      throw new BridgeError(400, ERROR_CODES.INVALID_INPUT, 'Invalid get_info message.', issueDetails(parsed));
    }
    this._send(ctx, {
      type: 'info',
      id: parsed.data.id,
      ok: true,
      service: SERVICE_NAME,
      version: SERVICE_VERSION,
      protocol: PROTOCOL,
      authenticatedAs: ctx.role,
      port: this.config.port,
      tlsEnabled: this.config.tlsEnabled,
      toolCount: this.toolRegistry.listTools().length,
      websocketEndpoints: {
        ai: '/ws/ai',
        executor: '/ws/executor',
      },
    });
  }

  _disconnect(ctx, message) {
    const parsed = DisconnectSchema.safeParse(message);
    if (!parsed.success) {
      throw new BridgeError(400, ERROR_CODES.INVALID_INPUT, 'Invalid disconnect message.', issueDetails(parsed));
    }
    const reason = parsed.data.reason || 'Disconnected by WebSocket client';
    this._detachContextFromSession(ctx, reason, true);
    this._send(ctx, { type: 'disconnected', id: parsed.data.id, ok: true });
    this._close(ctx, 1000, reason);
  }

  _requireCurrentSession(ctx, requestedSessionId) {
    if (!ctx.sessionId) {
      throw new BridgeError(409, ERROR_CODES.INVALID_INPUT, 'Register this WebSocket connection before sending this message.');
    }
    if (requestedSessionId && requestedSessionId !== ctx.sessionId) {
      throw new BridgeError(403, ERROR_CODES.FORBIDDEN, 'This WebSocket connection is only authorised for its registered session.');
    }
    return ctx.sessionId;
  }

  flushExecutor(sessionId) {
    const ctx = this.executorContexts.get(sessionId);
    if (!ctx || ctx.closed || ctx.ws.readyState !== WebSocket.OPEN || !ctx.executorId) return;

    let work;
    try {
      work = this.sessionManager.takeExecutorWork(sessionId, ctx.executorId, 5);
    } catch (err) {
      // A dashboard action may have disconnected the session while a queued notification was pending.
      return;
    }

    for (const control of work.controlSignals || []) {
      this._send(ctx, { type: 'control', control });
    }
    for (const task of work.tasks || []) {
      this._send(ctx, { type: 'task', task });
    }
  }

  disconnectRealtimeClient(role, sessionId, clientId, reason) {
    const map = role === ROLES.EXECUTOR ? this.executorContexts : this.aiContexts;
    const ctx = map.get(sessionId);
    if (!ctx) return;

    const expectedId = role === ROLES.EXECUTOR ? ctx.executorId : ctx.aiClientId;
    if (clientId && expectedId && clientId !== expectedId) return;

    map.delete(sessionId);
    ctx.sessionId = null;
    this._send(ctx, { type: 'disconnect', reason: reason || 'Disconnected by server' });
    this._close(ctx, 4000, reason || 'Disconnected by server');
  }

  _detachContextFromSession(ctx, reason, notifyManager) {
    const sessionId = ctx.sessionId;
    if (!sessionId) return;

    if (ctx.role === ROLES.EXECUTOR) {
      if (this.executorContexts.get(sessionId) === ctx) {
        this.executorContexts.delete(sessionId);
      }
      const executorId = ctx.executorId;
      ctx.sessionId = null;
      ctx.executorId = null;
      if (notifyManager) this.sessionManager.disconnectExecutorIfMatches(sessionId, executorId, reason);
      return;
    }

    if (this.aiContexts.get(sessionId) === ctx) {
      this.aiContexts.delete(sessionId);
    }
    const aiClientId = ctx.aiClientId;
    ctx.sessionId = null;
    ctx.aiClientId = null;
    if (notifyManager) this.sessionManager.disconnectAiIfMatches(sessionId, aiClientId, reason);
  }

  _onClose(ctx, code, reason) {
    if (ctx.closed) return;
    ctx.closed = true;
    clearTimeout(ctx.authTimer);
    this.contexts.delete(ctx);
    this._detachContextFromSession(ctx, `WebSocket closed (${code}${reason ? `: ${reason}` : ''})`, true);
  }

  _heartbeatSweep() {
    if (this.closed) return;
    for (const ctx of this.contexts) {
      if (ctx.closed || ctx.ws.readyState !== WebSocket.OPEN) continue;
      if (!ctx.isAlive) {
        this._close(ctx, 1001, 'WebSocket heartbeat timed out');
        continue;
      }
      ctx.isAlive = false;
      try {
        ctx.ws.ping();
      } catch {
        this._close(ctx, 1001, 'WebSocket ping failed');
      }
    }
  }

  _handleDispatchError(ctx, correlationId, err) {
    const bridgeError = asBridgeError(err);
    if (!(err instanceof BridgeError)) {
      this.logger.error('Unhandled WebSocket command error', {
        role: ctx.role,
        sessionId: ctx.sessionId,
        error: err,
      });
    }
    this._send(ctx, this._errorPayload(correlationId, bridgeError.code, bridgeError.message, bridgeError.details));
  }

  _errorPayload(id, code, message, details = undefined) {
    return {
      type: 'error',
      ...(id !== undefined ? { id } : {}),
      error: { code, message, ...(details ? { details } : {}) },
    };
  }

  _send(ctx, payload) {
    if (!ctx || ctx.closed || ctx.ws.readyState !== WebSocket.OPEN) return false;
    try {
      ctx.ws.send(JSON.stringify(payload));
      return true;
    } catch (err) {
      this.logger.debug('WebSocket send failed', {
        role: ctx.role,
        sessionId: ctx.sessionId,
        error: err && err.message ? err.message : String(err),
      });
      return false;
    }
  }

  _close(ctx, code, reason) {
    if (!ctx || ctx.closed) return;
    try {
      if (ctx.ws.readyState === WebSocket.OPEN || ctx.ws.readyState === WebSocket.CLOSING) {
        ctx.ws.close(code, String(reason || '').slice(0, 120));
      } else {
        ctx.ws.terminate();
      }
    } catch {
      try {
        ctx.ws.terminate();
      } catch {
        // Best-effort transport cleanup.
      }
    }
  }

  close() {
    if (this.closed) return;
    this.closed = true;
    clearInterval(this.heartbeatTimer);
    this.server.off('upgrade', this._handleUpgrade);
    this.sessionManager.setRealtimeNotifier(null);
    this.sessionManager.setRealtimeDisconnectNotifier(null);

    for (const ctx of [...this.contexts]) {
      this._detachContextFromSession(ctx, 'Server shutting down', true);
      this._close(ctx, 1001, 'Server shutting down');
    }
    this.contexts.clear();
    this.executorContexts.clear();
    this.aiContexts.clear();
    this.wss.close();
  }
}

module.exports = {
  WebSocketBridge,
};
