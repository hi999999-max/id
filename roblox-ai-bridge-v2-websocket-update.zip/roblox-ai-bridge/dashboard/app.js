'use strict';

(function () {
  const state = {
    authenticated: false,
    selectedSessionId: null,
    latestData: null,
    pollTimer: null,
    refreshPromise: null,
  };

  const el = {
    loginView: document.getElementById('loginView'),
    appView: document.getElementById('appView'),
    loginForm: document.getElementById('loginForm'),
    tokenInput: document.getElementById('tokenInput'),
    tokenVisibilityBtn: document.getElementById('tokenVisibilityBtn'),
    loginSubmitBtn: document.getElementById('loginSubmitBtn'),
    loginError: document.getElementById('loginError'),
    loginConnectionDot: document.getElementById('loginConnectionDot'),
    loginConnectionText: document.getElementById('loginConnectionText'),
    logoutBtn: document.getElementById('logoutBtn'),
    refreshBtn: document.getElementById('refreshBtn'),
    lastUpdatedText: document.getElementById('lastUpdatedText'),
    sessionSelect: document.getElementById('sessionSelect'),
    emergencyStopBtn: document.getElementById('emergencyStopBtn'),

    serverStatusText: document.getElementById('serverStatusText'),
    serverMetaText: document.getElementById('serverMetaText'),
    executorStatusBadge: document.getElementById('executorStatusBadge'),
    executorSub: document.getElementById('executorSub'),
    aiStatusBadge: document.getElementById('aiStatusBadge'),
    aiSub: document.getElementById('aiSub'),
    gameNameVal: document.getElementById('gameNameVal'),
    placeIdSub: document.getElementById('placeIdSub'),
    sessionIdVal: document.getElementById('sessionIdVal'),
    heartbeatSub: document.getElementById('heartbeatSub'),
    placeAllowlistBadge: document.getElementById('placeAllowlistBadge'),

    pendingCountVal: document.getElementById('pendingCountVal'),
    completedCountVal: document.getElementById('completedCountVal'),
    failedCountVal: document.getElementById('failedCountVal'),
    approvalCountVal: document.getElementById('approvalCountVal'),
    activeRequestsBadge: document.getElementById('activeRequestsBadge'),

    disconnectExecutorBtn: document.getElementById('disconnectExecutorBtn'),
    disconnectAiBtn: document.getElementById('disconnectAiBtn'),
    endSessionBtn: document.getElementById('endSessionBtn'),
    clearHistoryBtn: document.getElementById('clearHistoryBtn'),
    toggleLuauEnabledBtn: document.getElementById('toggleLuauEnabledBtn'),
    toggleLuauApprovalBtn: document.getElementById('toggleLuauApprovalBtn'),

    approvalSection: document.getElementById('approvalSection'),
    approvalList: document.getElementById('approvalList'),
    pendingHeaderCount: document.getElementById('pendingHeaderCount'),
    pendingList: document.getElementById('pendingList'),
    errorHeaderCount: document.getElementById('errorHeaderCount'),
    errorList: document.getElementById('errorList'),
    activityFeed: document.getElementById('activityFeed'),
    historyCountBadge: document.getElementById('historyCountBadge'),
    historyList: document.getElementById('historyList'),

    toolsCountBadge: document.getElementById('toolsCountBadge'),
    toolSearchInput: document.getElementById('toolSearchInput'),
    toolCategorySelect: document.getElementById('toolCategorySelect'),
    toolsGrid: document.getElementById('toolsGrid'),
    toast: document.getElementById('toast'),
  };

  function showToast(message) {
    el.toast.textContent = message;
    el.toast.classList.remove('hidden');
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => el.toast.classList.add('hidden'), 3600);
  }

  function setLoginConnection(status, text) {
    el.loginConnectionDot.className = `connection-dot ${status}`;
    el.loginConnectionText.textContent = text;
  }

  async function checkDashboardConnection() {
    setLoginConnection('checking', 'Checking dashboard connection…');
    try {
      const response = await fetch('/health', { credentials: 'same-origin', cache: 'no-store' });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      setLoginConnection('online', 'Dashboard HTTP endpoint is reachable');
    } catch {
      setLoginConnection('offline', 'Cannot reach the dashboard HTTP endpoint');
    }
  }

  async function apiRequest(url, options = {}) {
    const { headers: optionHeaders = {}, ...requestOptions } = options;
    const response = await fetch(url, {
      credentials: 'same-origin',
      cache: 'no-store',
      ...requestOptions,
      headers: {
        'Content-Type': 'application/json',
        ...optionHeaders,
      },
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(data?.error?.message || `HTTP ${response.status}`);
      error.status = response.status;
      error.code = data?.error?.code;
      throw error;
    }
    return data;
  }

  function clearChildren(node) {
    while (node.firstChild) node.removeChild(node.firstChild);
  }

  function makeEl(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined && text !== null) node.textContent = String(text);
    return node;
  }

  function formatDurationAge(ms) {
    if (ms === null || ms === undefined) return '—';
    if (ms < 1000) return `${ms}ms ago`;
    if (ms < 60000) return `${(ms / 1000).toFixed(1)}s ago`;
    return `${Math.floor(ms / 60000)}m ago`;
  }

  function formatBytes(bytes) {
    const value = Number(bytes || 0);
    if (value < 1024) return `${value} B`;
    if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
    return `${(value / (1024 * 1024)).toFixed(2)} MB`;
  }

  function renderSessions(data) {
    const sessions = data.sessions || [];
    const previousSelection = state.selectedSessionId;
    clearChildren(el.sessionSelect);

    if (sessions.length === 0) {
      const option = makeEl('option', '', 'No active sessions');
      option.value = '';
      el.sessionSelect.appendChild(option);
      state.selectedSessionId = null;
    } else {
      for (const session of sessions) {
        const executorLabel = session.executor.gameName || 'Waiting for executor';
        const option = makeEl('option', '', `${session.sessionId.slice(0, 14)}… · ${executorLabel}`);
        option.value = session.sessionId;
        el.sessionSelect.appendChild(option);
      }
      const selectionStillExists = sessions.some((session) => session.sessionId === previousSelection);
      state.selectedSessionId = selectionStillExists ? previousSelection : sessions[0].sessionId;
      el.sessionSelect.value = state.selectedSessionId;
    }

    const active = sessions.find((session) => session.sessionId === state.selectedSessionId) || null;
    if (!active) {
      el.executorStatusBadge.textContent = 'Disconnected';
      el.executorStatusBadge.className = 'status-pill offline';
      el.executorSub.textContent = 'Waiting for BridgeClient.lua';
      el.aiStatusBadge.textContent = 'Disconnected';
      el.aiStatusBadge.className = 'status-pill offline';
      el.aiSub.textContent = 'Waiting for AI WebSocket registration';
      el.gameNameVal.textContent = '—';
      el.placeIdSub.textContent = 'Place ID: —';
      el.sessionIdVal.textContent = '—';
      el.heartbeatSub.textContent = 'Heartbeat: —';
      el.disconnectExecutorBtn.disabled = true;
      el.disconnectAiBtn.disabled = true;
      el.endSessionBtn.disabled = true;
      return;
    }

    el.sessionIdVal.textContent = active.sessionId;
    el.disconnectExecutorBtn.disabled = !active.executor.connected;
    el.disconnectAiBtn.disabled = !active.ai.connected;
    el.endSessionBtn.disabled = false;

    if (active.executor.connected) {
      el.executorStatusBadge.textContent = 'Connected';
      el.executorStatusBadge.className = 'status-pill online';
      el.executorSub.textContent = `${active.executor.executorName || 'Executor'} · ${active.executor.playerName || 'LocalPlayer'}`;
      el.gameNameVal.textContent = active.executor.gameName || 'Unknown Experience';
      el.placeIdSub.textContent = `Place ID: ${active.executor.placeId ?? '—'}`;
      el.heartbeatSub.textContent = `Heartbeat: ${formatDurationAge(active.executor.heartbeatAgeMs)}`;
    } else {
      el.executorStatusBadge.textContent = 'Disconnected';
      el.executorStatusBadge.className = 'status-pill offline';
      el.executorSub.textContent = 'Executor offline';
      el.gameNameVal.textContent = active.executor.gameName || '—';
      el.placeIdSub.textContent = `Place ID: ${active.executor.placeId ?? '—'}`;
      el.heartbeatSub.textContent = 'Heartbeat: Offline';
    }

    if (active.ai.connected) {
      el.aiStatusBadge.textContent = 'Connected';
      el.aiStatusBadge.className = 'status-pill online';
      el.aiSub.textContent = `${active.ai.clientName || 'AI Agent'} · ${active.ai.aiClientId || ''}`;
    } else {
      el.aiStatusBadge.textContent = 'Disconnected';
      el.aiStatusBadge.className = 'status-pill offline';
      el.aiSub.textContent = 'Waiting for AI WebSocket registration';
    }
  }

  function renderApprovals(data) {
    const approvals = data.pendingApprovals || [];
    clearChildren(el.approvalList);
    if (approvals.length === 0) {
      el.approvalSection.classList.add('hidden');
      return;
    }

    el.approvalSection.classList.remove('hidden');
    for (const item of approvals) {
      const box = makeEl('article', 'list-item');
      const header = makeEl('div', 'list-item-head');
      header.appendChild(makeEl('strong', '', `ExecuteLuau · ${item.requestId.slice(0, 12)}…`));
      header.appendChild(makeEl('span', 'mono-small', new Date(item.createdAt).toLocaleTimeString()));
      box.appendChild(header);

      if (item.reason) box.appendChild(makeEl('div', 'muted', `Reason: ${item.reason}`));
      if (item.sourceFileName) {
        box.appendChild(makeEl('div', 'mono-small', `Text file: ${item.sourceFileName} · ${formatBytes(item.sourceFileBytes)}`));
      }

      box.appendChild(makeEl('pre', 'code-preview', item.code));
      if (item.codeTruncated) {
        box.appendChild(makeEl('div', 'mono-small', 'Preview limited to the first 16,000 characters. Approval executes the full .txt payload.'));
      }

      const actions = makeEl('div', 'approval-actions');
      const approve = makeEl('button', 'btn btn-success', 'Approve & Run');
      approve.addEventListener('click', async () => {
        try {
          await apiRequest('/api/v1/dashboard/actions/approve-request', {
            method: 'POST', body: JSON.stringify({ sessionId: item.sessionId, requestId: item.requestId }),
          });
          showToast('ExecuteLuau request approved');
          await refreshState();
        } catch (error) { showToast(`Approval failed: ${error.message}`); }
      });
      const reject = makeEl('button', 'btn btn-danger', 'Reject');
      reject.addEventListener('click', async () => {
        const reason = window.prompt('Optional rejection reason:', 'Rejected from dashboard');
        if (reason === null) return;
        try {
          await apiRequest('/api/v1/dashboard/actions/reject-request', {
            method: 'POST', body: JSON.stringify({ sessionId: item.sessionId, requestId: item.requestId, reason }),
          });
          showToast('ExecuteLuau request rejected');
          await refreshState();
        } catch (error) { showToast(`Rejection failed: ${error.message}`); }
      });
      actions.append(approve, reject);
      box.appendChild(actions);
      el.approvalList.appendChild(box);
    }
  }

  function renderPending(data) {
    const requests = data.pendingRequests || [];
    el.pendingHeaderCount.textContent = `${requests.length} requests`;
    clearChildren(el.pendingList);
    if (requests.length === 0) {
      el.pendingList.appendChild(makeEl('div', 'empty-state', 'No queued or in-flight requests.'));
      return;
    }
    for (const item of requests) {
      const box = makeEl('article', 'list-item');
      const header = makeEl('div', 'list-item-head');
      header.appendChild(makeEl('strong', '', item.toolName));
      header.appendChild(makeEl('span', 'chip', item.status));
      box.appendChild(header);
      box.appendChild(makeEl('div', 'mono-small', `${item.requestId} · ${item.argsPreview}`));
      el.pendingList.appendChild(box);
    }
  }

  function renderErrors(data) {
    const items = data.connectionErrors || [];
    el.errorHeaderCount.textContent = String(items.length);
    clearChildren(el.errorList);
    if (items.length === 0) {
      el.errorList.appendChild(makeEl('div', 'empty-state', 'No recent connection errors.'));
      return;
    }
    for (const item of items) {
      const box = makeEl('article', 'list-item');
      const header = makeEl('div', 'list-item-head');
      header.appendChild(makeEl('strong', '', `${item.source}: ${item.code}`));
      header.appendChild(makeEl('span', 'mono-small', new Date(item.ts).toLocaleTimeString()));
      box.appendChild(header);
      box.appendChild(makeEl('div', 'muted', item.message));
      el.errorList.appendChild(box);
    }
  }

  function renderActivity(data) {
    const items = data.recentActivity || [];
    clearChildren(el.activityFeed);
    if (items.length === 0) {
      el.activityFeed.appendChild(makeEl('div', 'empty-state', 'No activity recorded yet.'));
      return;
    }
    for (const item of items) {
      const box = makeEl('article', 'list-item');
      const header = makeEl('div', 'list-item-head');
      header.appendChild(makeEl('span', 'chip', item.type));
      header.appendChild(makeEl('span', 'mono-small', new Date(item.ts).toLocaleTimeString()));
      box.appendChild(header);
      box.appendChild(makeEl('div', '', item.message));
      el.activityFeed.appendChild(box);
    }
  }

  function renderHistory(data) {
    const items = data.executionHistory || [];
    el.historyCountBadge.textContent = String(items.length);
    clearChildren(el.historyList);
    if (items.length === 0) {
      el.historyList.appendChild(makeEl('div', 'empty-state', 'No completed or failed tool calls yet.'));
      return;
    }
    for (const item of items) {
      const box = makeEl('article', 'list-item');
      const header = makeEl('div', 'list-item-head');
      header.appendChild(makeEl('strong', '', item.toolName));
      header.appendChild(makeEl('span', `chip ${item.ok ? '' : 'warn'}`, `${item.status} · ${item.durationMs ?? '—'}ms`));
      box.appendChild(header);
      box.appendChild(makeEl('div', 'mono-small', `Args: ${item.argsPreview}`));
      if (item.error) box.appendChild(makeEl('div', 'muted', `Error: ${item.error.message || item.error.code}`));
      else if (item.resultPreview) box.appendChild(makeEl('div', 'mono-small', `Result: ${item.resultPreview}`));
      el.historyList.appendChild(box);
    }
  }

  function renderTools(data) {
    const tools = data.tools || [];
    const search = el.toolSearchInput.value.trim().toLowerCase();
    const category = el.toolCategorySelect.value;
    const filtered = tools.filter((tool) => {
      if (category !== 'all' && tool.category !== category) return false;
      return !search || tool.name.toLowerCase().includes(search) || tool.description.toLowerCase().includes(search);
    });

    el.toolsCountBadge.textContent = `${filtered.length} / ${tools.length} tools`;
    clearChildren(el.toolsGrid);
    if (filtered.length === 0) {
      el.toolsGrid.appendChild(makeEl('div', 'empty-state', 'No tools match this filter.'));
      return;
    }
    for (const tool of filtered) {
      const card = makeEl('article', 'tool-card');
      const header = makeEl('div', 'tool-card-head');
      header.appendChild(makeEl('span', 'tool-name', tool.name));
      header.appendChild(makeEl('span', 'chip', tool.category));
      card.appendChild(header);
      card.appendChild(makeEl('div', 'tool-desc', tool.description));
      el.toolsGrid.appendChild(card);
    }
  }

  function renderState(data) {
    state.latestData = data;
    const server = data.server || {};
    el.serverStatusText.textContent = `Server ${server.status || 'online'} · uptime ${server.uptimeSeconds ?? 0}s`;
    el.serverMetaText.textContent = `Port ${server.port || 3003} · ${server.tlsEnabled ? 'HTTPS' : 'HTTP'} dashboard`;
    el.placeAllowlistBadge.textContent = `Place Allowlist: ${server.allowedPlaceIds || '*'}`;
    el.lastUpdatedText.textContent = `Updated ${new Date().toLocaleTimeString()}`;

    const stats = data.stats || {};
    el.pendingCountVal.textContent = String(stats.pendingCount ?? 0);
    el.completedCountVal.textContent = String(stats.completedCount ?? 0);
    el.failedCountVal.textContent = String(stats.failedCount ?? 0);
    el.approvalCountVal.textContent = String(stats.approvalCount ?? 0);
    el.activeRequestsBadge.textContent = `${stats.pendingCount ?? 0} active`;

    const policy = data.policy || {};
    el.toggleLuauEnabledBtn.textContent = `ExecuteLuau: ${policy.executeLuauEnabled ? 'ON' : 'OFF'}`;
    el.toggleLuauApprovalBtn.textContent = `Manual Approval: ${policy.executeLuauRequireApproval ? 'ON' : 'OFF'}`;

    renderSessions(data);
    renderApprovals(data);
    renderPending(data);
    renderErrors(data);
    renderActivity(data);
    renderHistory(data);
    renderTools(data);
  }

  async function refreshState({ silent = false } = {}) {
    if (state.refreshPromise) return state.refreshPromise;
    state.refreshPromise = (async () => {
      el.refreshBtn.disabled = true;
      try {
        const data = await apiRequest('/api/v1/dashboard/state', { method: 'GET' });
        state.authenticated = true;
        el.loginView.classList.add('hidden');
        el.appView.classList.remove('hidden');
        renderState(data);
        return true;
      } catch (error) {
        if (error.status === 401) {
          stopPolling();
          state.authenticated = false;
          el.appView.classList.add('hidden');
          el.loginView.classList.remove('hidden');
          return false;
        }
        if (!silent && state.authenticated) showToast(`Refresh failed: ${error.message}`);
        return false;
      } finally {
        el.refreshBtn.disabled = false;
        state.refreshPromise = null;
      }
    })();
    return state.refreshPromise;
  }

  function startPolling({ immediate = true } = {}) {
    stopPolling();
    if (immediate) refreshState();
    state.pollTimer = setInterval(() => refreshState({ silent: true }), 2000);
  }

  function stopPolling() {
    if (state.pollTimer) clearInterval(state.pollTimer);
    state.pollTimer = null;
  }

  async function postDashboardAction(path, body, successMessage, confirmMessage) {
    if (confirmMessage && !window.confirm(confirmMessage)) return;
    try {
      await apiRequest(path, { method: 'POST', body: JSON.stringify(body) });
      showToast(successMessage);
      await refreshState();
    } catch (error) {
      showToast(`Action failed: ${error.message}`);
    }
  }

  el.loginForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    el.loginError.classList.add('hidden');
    el.loginSubmitBtn.disabled = true;
    try {
      await apiRequest('/api/v1/dashboard/login', {
        method: 'POST', body: JSON.stringify({ token: el.tokenInput.value.trim() }),
      });
      el.tokenInput.value = '';
      const loaded = await refreshState({ silent: true });
      if (!loaded) {
        throw new Error('Login succeeded but the browser did not retain the secure dashboard session. Use the same browser address for login and dashboard, then check cookie/privacy settings.');
      }
      startPolling({ immediate: false });
      showToast('Dashboard unlocked');
    } catch (error) {
      el.loginError.textContent = error.message;
      el.loginError.classList.remove('hidden');
    } finally {
      el.loginSubmitBtn.disabled = false;
    }
  });

  el.tokenVisibilityBtn.addEventListener('click', () => {
    const show = el.tokenInput.type === 'password';
    el.tokenInput.type = show ? 'text' : 'password';
    el.tokenVisibilityBtn.textContent = show ? 'Hide' : 'Show';
    el.tokenVisibilityBtn.setAttribute('aria-label', show ? 'Hide token' : 'Show token');
  });

  el.logoutBtn.addEventListener('click', async () => {
    stopPolling();
    await apiRequest('/api/v1/dashboard/logout', { method: 'POST', body: '{}' }).catch(() => {});
    state.authenticated = false;
    state.latestData = null;
    state.selectedSessionId = null;
    el.appView.classList.add('hidden');
    el.loginView.classList.remove('hidden');
    setLoginConnection('checking', 'Dashboard locked. Checking connection…');
    checkDashboardConnection();
  });

  el.refreshBtn.addEventListener('click', async () => {
    const refreshed = await refreshState();
    if (refreshed) showToast('Dashboard refreshed');
  });

  el.sessionSelect.addEventListener('change', () => {
    state.selectedSessionId = el.sessionSelect.value || null;
    if (state.latestData) renderSessions(state.latestData);
  });

  el.emergencyStopBtn.addEventListener('click', () => {
    postDashboardAction(
      '/api/v1/dashboard/actions/emergency-stop',
      state.selectedSessionId ? { sessionId: state.selectedSessionId } : {},
      'Emergency stop triggered',
      'Cancel active requests and halt movement for the selected session?'
    );
  });
  el.disconnectExecutorBtn.addEventListener('click', () => {
    if (!state.selectedSessionId) return;
    postDashboardAction('/api/v1/dashboard/actions/disconnect-executor', { sessionId: state.selectedSessionId }, 'Executor disconnected', 'Disconnect this executor now?');
  });
  el.disconnectAiBtn.addEventListener('click', () => {
    if (!state.selectedSessionId) return;
    postDashboardAction('/api/v1/dashboard/actions/disconnect-ai', { sessionId: state.selectedSessionId }, 'AI disconnected', 'Disconnect this AI client now?');
  });
  el.endSessionBtn.addEventListener('click', () => {
    if (!state.selectedSessionId) return;
    postDashboardAction('/api/v1/dashboard/actions/end-session', { sessionId: state.selectedSessionId }, 'Session ended', 'End this session and disconnect both sides?');
  });
  el.clearHistoryBtn.addEventListener('click', () => {
    postDashboardAction('/api/v1/dashboard/actions/clear-history', {}, 'History cleared', 'Clear dashboard activity and execution history?');
  });
  el.toggleLuauEnabledBtn.addEventListener('click', () => {
    const current = Boolean(state.latestData?.policy?.executeLuauEnabled);
    postDashboardAction('/api/v1/dashboard/actions/toggle-execute-luau', { executeLuauEnabled: !current }, `ExecuteLuau ${!current ? 'enabled' : 'disabled'}`);
  });
  el.toggleLuauApprovalBtn.addEventListener('click', () => {
    const current = Boolean(state.latestData?.policy?.executeLuauRequireApproval);
    postDashboardAction('/api/v1/dashboard/actions/toggle-execute-luau', { executeLuauRequireApproval: !current }, `Manual approval ${!current ? 'enabled' : 'disabled'}`);
  });

  el.toolSearchInput.addEventListener('input', () => state.latestData && renderTools(state.latestData));
  el.toolCategorySelect.addEventListener('change', () => state.latestData && renderTools(state.latestData));

  // The dashboard intentionally stays HTTP(S); this only restores an existing opaque browser session.
  checkDashboardConnection();
  refreshState({ silent: true }).then((resumed) => {
    if (resumed) startPolling({ immediate: false });
  });
})();
