'use strict';

const { z } = require('zod');
const { TOOL_CATEGORIES, SPATIAL_LIMITS } = require('./constants');

const EXTERNAL_URL_REGEX = /\b(?:https?|wss?|ftp):\/\/\S+/i;

function noExternalUrlString(maxLen = 512, minLen = 0) {
  let schema = z.string().max(maxLen);
  if (minLen > 0) {
    schema = schema.min(minLen);
  }
  return schema.refine(
    (val) => !EXTERNAL_URL_REGEX.test(val),
    'External URLs are not permitted in tool arguments'
  );
}

// File tools are intentionally limited to BridgeClient.lua's own sandboxed
// `roblox-ai-bridge-workspace/` directory. Paths may never be absolute, use
// backslashes, or escape through `..` segments.
const EXECUTOR_WORKSPACE_PATH_REGEX = /^(?!\.?\.?$)(?!.*(?:^|\/)\.\.(?:\/|$))[A-Za-z0-9][A-Za-z0-9 _.-]*(?:\/[A-Za-z0-9][A-Za-z0-9 _.-]*)*$/;

function workspaceRelativePath(maxLen = 240, minLen = 1) {
  return noExternalUrlString(maxLen, minLen).refine(
    (value) => EXECUTOR_WORKSPACE_PATH_REGEX.test(value),
    'Path must be a safe relative path inside the Roblox AI Bridge workspace'
  );
}

const Vector3Schema = z.object({
  x: z.number().finite().min(-1e6).max(1e6),
  y: z.number().finite().min(-1e6).max(1e6),
  z: z.number().finite().min(-1e6).max(1e6),
}).strict();

const Vector3JsonSchema = {
  type: 'object',
  properties: {
    x: { type: 'number', description: 'X coordinate in studs' },
    y: { type: 'number', description: 'Y coordinate in studs' },
    z: { type: 'number', description: 'Z coordinate in studs' },
  },
  required: ['x', 'y', 'z'],
  additionalProperties: false,
};

const ALLOWLISTED_INSTANCE_PROPERTIES = [
  'Name', 'ClassName', 'Position', 'Orientation', 'Size', 'CFrame',
  'Color', 'BrickColor', 'Material', 'Transparency', 'CanCollide',
  'Anchored', 'Locked', 'Visible', 'Enabled', 'Text', 'PlaceholderText',
  'Value', 'MaxDistance', 'ActionText', 'ObjectText', 'HoldDuration',
  'KeyboardKeyCode', 'RequiresLineOfSight', 'WalkSpeed', 'JumpPower',
  'JumpHeight', 'Health', 'MaxHealth', 'Sit', 'Active', 'Modal',
  'AbsolutePosition', 'AbsoluteSize', 'Image', 'ToolTip', 'GripPos',
];

/**
 * Complete registry of all 47 Roblox AI Bridge tools.
 * Each entry includes:
 * - name
 * - category
 * - description
 * - requiresApprovalPolicy (boolean)
 * - jsonSchema (JSON Schema for OpenAI / MCP / REST manifest)
 * - zodSchema (Strict runtime validator)
 */
const TOOL_DEFINITIONS = [
  // =========================================================================
  // A. ENVIRONMENT INSPECTION (1 - 15)
  // =========================================================================
  {
    name: 'GetGameInfo',
    category: TOOL_CATEGORIES.ENVIRONMENT,
    description: 'Get current Roblox game name, PlaceId, JobId, GameId, creator info, and player count.',
    requiresApprovalPolicy: false,
    jsonSchema: { type: 'object', properties: {}, required: [], additionalProperties: false },
    zodSchema: z.object({}).strict(),
  },
  {
    name: 'GetLocalPlayerInfo',
    category: TOOL_CATEGORIES.ENVIRONMENT,
    description: 'Get LocalPlayer display name, username, UserId, Team, account age, and character availability.',
    requiresApprovalPolicy: false,
    jsonSchema: { type: 'object', properties: {}, required: [], additionalProperties: false },
    zodSchema: z.object({}).strict(),
  },
  {
    name: 'GetCharacterState',
    category: TOOL_CATEGORIES.ENVIRONMENT,
    description: 'Get LocalPlayer character position, rotation/lookVector, velocity, health, maxHealth, walkSpeed, jumpPower, and HumanoidStateType.',
    requiresApprovalPolicy: false,
    jsonSchema: { type: 'object', properties: {}, required: [], additionalProperties: false },
    zodSchema: z.object({}).strict(),
  },
  {
    name: 'GetCameraState',
    category: TOOL_CATEGORIES.ENVIRONMENT,
    description: 'Get Workspace.CurrentCamera position, lookVector, CFrame summary, FieldOfView, CameraType, and viewport size.',
    requiresApprovalPolicy: false,
    jsonSchema: { type: 'object', properties: {}, required: [], additionalProperties: false },
    zodSchema: z.object({}).strict(),
  },
  {
    name: 'GetWorkspaceSummary',
    category: TOOL_CATEGORIES.ENVIRONMENT,
    description: 'Get a concise overview of Workspace top-level folders/models, terrain summary, player count, and object counts.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        maxTopLevelItems: {
          type: 'integer',
          minimum: 1,
          maximum: 100,
          default: 40,
          description: 'Maximum number of top-level Workspace children to list.',
        },
      },
      required: [],
      additionalProperties: false,
    },
    zodSchema: z.object({
      maxTopLevelItems: z.number().int().min(1).max(100).optional(),
    }).strict(),
  },
  {
    name: 'GetDescendants',
    category: TOOL_CATEGORIES.ENVIRONMENT,
    description: 'Retrieve descendants of a specified instance with optional ClassName filtering, depth limit, and pagination.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        rootPath: {
          type: 'string',
          default: 'Workspace',
          description: 'Dot-separated instance path (e.g. "Workspace", "Workspace.Map", "Players.LocalPlayer.PlayerGui").',
        },
        classFilter: {
          type: 'string',
          description: 'Optional Roblox ClassName filter (e.g. "BasePart", "Model", "ProximityPrompt").',
        },
        maxDepth: {
          type: 'integer',
          minimum: 1,
          maximum: SPATIAL_LIMITS.MAX_DEPTH,
          default: SPATIAL_LIMITS.DEFAULT_DEPTH,
          description: 'Maximum hierarchy depth to traverse.',
        },
        limit: {
          type: 'integer',
          minimum: 1,
          maximum: SPATIAL_LIMITS.MAX_RESULTS,
          default: SPATIAL_LIMITS.DEFAULT_RESULTS,
          description: 'Maximum items per page.',
        },
        offset: {
          type: 'integer',
          minimum: 0,
          maximum: 5000,
          default: 0,
          description: 'Zero-based pagination offset.',
        },
      },
      required: [],
      additionalProperties: false,
    },
    zodSchema: z.object({
      rootPath: noExternalUrlString(300, 1).optional(),
      classFilter: noExternalUrlString(80, 1).optional(),
      maxDepth: z.number().int().min(1).max(SPATIAL_LIMITS.MAX_DEPTH).optional(),
      limit: z.number().int().min(1).max(SPATIAL_LIMITS.MAX_RESULTS).optional(),
      offset: z.number().int().min(0).max(5000).optional(),
    }).strict(),
  },
  {
    name: 'GetChildren',
    category: TOOL_CATEGORIES.ENVIRONMENT,
    description: 'Retrieve direct children of a specified instance path.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        instancePath: {
          type: 'string',
          default: 'Workspace',
          description: 'Dot-separated instance path (e.g. "Workspace", "Workspace.Doors").',
        },
        classFilter: {
          type: 'string',
          description: 'Optional ClassName filter.',
        },
        limit: {
          type: 'integer',
          minimum: 1,
          maximum: SPATIAL_LIMITS.MAX_RESULTS,
          default: 50,
        },
      },
      required: ['instancePath'],
      additionalProperties: false,
    },
    zodSchema: z.object({
      instancePath: noExternalUrlString(300, 1),
      classFilter: noExternalUrlString(80, 1).optional(),
      limit: z.number().int().min(1).max(SPATIAL_LIMITS.MAX_RESULTS).optional(),
    }).strict(),
  },
  {
    name: 'FindInstances',
    category: TOOL_CATEGORIES.ENVIRONMENT,
    description: 'Find instances matching a name pattern and/or ClassName under a root instance.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        nameContains: { type: 'string', description: 'Case-insensitive substring to match against instance Name.' },
        className: { type: 'string', description: 'Roblox ClassName or base class (via IsA).' },
        rootPath: { type: 'string', default: 'Workspace', description: 'Root instance path to search under.' },
        maxResults: { type: 'integer', minimum: 1, maximum: SPATIAL_LIMITS.MAX_RESULTS, default: 25 },
      },
      required: [],
      additionalProperties: false,
    },
    zodSchema: z.object({
      nameContains: noExternalUrlString(120, 1).optional(),
      className: noExternalUrlString(80, 1).optional(),
      rootPath: noExternalUrlString(300, 1).optional(),
      maxResults: z.number().int().min(1).max(SPATIAL_LIMITS.MAX_RESULTS).optional(),
    }).strict().refine(
      (data) => Boolean(data.nameContains || data.className),
      'Provide at least one of nameContains or className'
    ),
  },
  {
    name: 'SearchWorkspace',
    category: TOOL_CATEGORIES.ENVIRONMENT,
    description: 'Search Workspace for visible objects matching a text query across names, tags, or prompt text.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'Search keyword (case-insensitive).' },
        classFilter: { type: 'string', description: 'Optional ClassName filter.' },
        maxResults: { type: 'integer', minimum: 1, maximum: SPATIAL_LIMITS.MAX_RESULTS, default: 25 },
      },
      required: ['query'],
      additionalProperties: false,
    },
    zodSchema: z.object({
      query: noExternalUrlString(120, 1),
      classFilter: noExternalUrlString(80, 1).optional(),
      maxResults: z.number().int().min(1).max(SPATIAL_LIMITS.MAX_RESULTS).optional(),
    }).strict(),
  },
  {
    name: 'GetInstanceInfo',
    category: TOOL_CATEGORIES.ENVIRONMENT,
    description: 'Retrieve instance Name, ClassName, full path, parent path, child count, position (if applicable), and key metadata.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        instancePath: { type: 'string', description: 'Dot-separated path to the target instance.' },
      },
      required: ['instancePath'],
      additionalProperties: false,
    },
    zodSchema: z.object({
      instancePath: noExternalUrlString(300, 1),
    }).strict(),
  },
  {
    name: 'GetInstanceProperties',
    category: TOOL_CATEGORIES.ENVIRONMENT,
    description: 'Read an explicitly allowlisted collection of safe properties from an instance.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        instancePath: { type: 'string', description: 'Dot-separated path to the target instance.' },
        properties: {
          type: 'array',
          items: { type: 'string', enum: ALLOWLISTED_INSTANCE_PROPERTIES },
          minItems: 1,
          maxItems: 25,
          description: 'Allowlisted property names to read.',
        },
      },
      required: ['instancePath', 'properties'],
      additionalProperties: false,
    },
    zodSchema: z.object({
      instancePath: noExternalUrlString(300, 1),
      properties: z.array(z.enum(ALLOWLISTED_INSTANCE_PROPERTIES)).min(1).max(25),
    }).strict(),
  },
  {
    name: 'GetInstanceAttributes',
    category: TOOL_CATEGORIES.ENVIRONMENT,
    description: 'Read all custom Roblox Attributes attached to an instance.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        instancePath: { type: 'string', description: 'Dot-separated path to the target instance.' },
      },
      required: ['instancePath'],
      additionalProperties: false,
    },
    zodSchema: z.object({
      instancePath: noExternalUrlString(300, 1),
    }).strict(),
  },
  {
    name: 'GetCollectionServiceTags',
    category: TOOL_CATEGORIES.ENVIRONMENT,
    description: 'Retrieve CollectionService tags on a specific instance, or find instances carrying a specific tag.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        instancePath: { type: 'string', description: 'Instance path to inspect tags on.' },
        tagName: { type: 'string', description: 'Optional tag name to list tagged instances for.' },
        maxResults: { type: 'integer', minimum: 1, maximum: SPATIAL_LIMITS.MAX_RESULTS, default: 25 },
      },
      required: [],
      additionalProperties: false,
    },
    zodSchema: z.object({
      instancePath: noExternalUrlString(300, 1).optional(),
      tagName: noExternalUrlString(120, 1).optional(),
      maxResults: z.number().int().min(1).max(SPATIAL_LIMITS.MAX_RESULTS).optional(),
    }).strict().refine(
      (data) => Boolean(data.instancePath || data.tagName),
      'Provide either instancePath or tagName'
    ),
  },
  {
    name: 'GetLightingInfo',
    category: TOOL_CATEGORIES.ENVIRONMENT,
    description: 'Read Lighting service settings such as ClockTime, Brightness, Ambient, FogStart, FogEnd, and GlobalShadows.',
    requiresApprovalPolicy: false,
    jsonSchema: { type: 'object', properties: {}, required: [], additionalProperties: false },
    zodSchema: z.object({}).strict(),
  },
  {
    name: 'GetVisibleGuiTree',
    category: TOOL_CATEGORIES.ENVIRONMENT,
    description: 'Inspect visible GUI elements in PlayerGui (and optionally CoreGui-safe player overlays) including readable text and clickable buttons.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        maxDepth: { type: 'integer', minimum: 1, maximum: 10, default: 6 },
        maxNodes: { type: 'integer', minimum: 1, maximum: 150, default: 60 },
        includeInvisible: { type: 'boolean', default: false },
      },
      required: [],
      additionalProperties: false,
    },
    zodSchema: z.object({
      maxDepth: z.number().int().min(1).max(10).optional(),
      maxNodes: z.number().int().min(1).max(150).optional(),
      includeInvisible: z.boolean().optional(),
    }).strict(),
  },

  // =========================================================================
  // B. SURROUNDING ENVIRONMENT (16 - 24)
  // =========================================================================
  {
    name: 'GetNearbyParts',
    category: TOOL_CATEGORIES.SURROUNDING,
    description: 'Find BaseParts within a bounded radius of the local character (or specified position).',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        radius: { type: 'number', minimum: 1, maximum: SPATIAL_LIMITS.MAX_RADIUS_STUDS, default: 60 },
        maxResults: { type: 'integer', minimum: 1, maximum: SPATIAL_LIMITS.MAX_RESULTS, default: 25 },
        origin: Vector3JsonSchema,
        nameContains: { type: 'string' },
      },
      required: [],
      additionalProperties: false,
    },
    zodSchema: z.object({
      radius: z.number().finite().min(1).max(SPATIAL_LIMITS.MAX_RADIUS_STUDS).optional(),
      maxResults: z.number().int().min(1).max(SPATIAL_LIMITS.MAX_RESULTS).optional(),
      origin: Vector3Schema.optional(),
      nameContains: noExternalUrlString(120, 1).optional(),
    }).strict(),
  },
  {
    name: 'GetNearbyModels',
    category: TOOL_CATEGORIES.SURROUNDING,
    description: 'Find Model instances near the local character or specified origin.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        radius: { type: 'number', minimum: 1, maximum: SPATIAL_LIMITS.MAX_RADIUS_STUDS, default: 80 },
        maxResults: { type: 'integer', minimum: 1, maximum: SPATIAL_LIMITS.MAX_RESULTS, default: 25 },
        origin: Vector3JsonSchema,
        nameContains: { type: 'string' },
      },
      required: [],
      additionalProperties: false,
    },
    zodSchema: z.object({
      radius: z.number().finite().min(1).max(SPATIAL_LIMITS.MAX_RADIUS_STUDS).optional(),
      maxResults: z.number().int().min(1).max(SPATIAL_LIMITS.MAX_RESULTS).optional(),
      origin: Vector3Schema.optional(),
      nameContains: noExternalUrlString(120, 1).optional(),
    }).strict(),
  },
  {
    name: 'GetNearbyPlayers',
    category: TOOL_CATEGORIES.SURROUNDING,
    description: 'Return nearby players (display name, username, distance, position, health) without exposing private account data.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        radius: { type: 'number', minimum: 1, maximum: SPATIAL_LIMITS.MAX_RADIUS_STUDS, default: 150 },
        maxResults: { type: 'integer', minimum: 1, maximum: 50, default: 20 },
      },
      required: [],
      additionalProperties: false,
    },
    zodSchema: z.object({
      radius: z.number().finite().min(1).max(SPATIAL_LIMITS.MAX_RADIUS_STUDS).optional(),
      maxResults: z.number().int().min(1).max(50).optional(),
    }).strict(),
  },
  {
    name: 'GetNearbyInteractables',
    category: TOOL_CATEGORIES.SURROUNDING,
    description: 'Locate nearby interactable objects (ProximityPrompts, ClickDetectors, TouchTransmitters, Seats, VehicleSeats).',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        radius: { type: 'number', minimum: 1, maximum: SPATIAL_LIMITS.MAX_RADIUS_STUDS, default: 80 },
        maxResults: { type: 'integer', minimum: 1, maximum: SPATIAL_LIMITS.MAX_RESULTS, default: 25 },
      },
      required: [],
      additionalProperties: false,
    },
    zodSchema: z.object({
      radius: z.number().finite().min(1).max(SPATIAL_LIMITS.MAX_RADIUS_STUDS).optional(),
      maxResults: z.number().int().min(1).max(SPATIAL_LIMITS.MAX_RESULTS).optional(),
    }).strict(),
  },
  {
    name: 'GetNearbyPrompts',
    category: TOOL_CATEGORIES.SURROUNDING,
    description: 'Find nearby ProximityPrompts with ActionText, ObjectText, Enabled, MaxActivationDistance, HoldDuration, and path.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        radius: { type: 'number', minimum: 1, maximum: SPATIAL_LIMITS.MAX_RADIUS_STUDS, default: 80 },
        maxResults: { type: 'integer', minimum: 1, maximum: SPATIAL_LIMITS.MAX_RESULTS, default: 25 },
        onlyEnabled: { type: 'boolean', default: true },
      },
      required: [],
      additionalProperties: false,
    },
    zodSchema: z.object({
      radius: z.number().finite().min(1).max(SPATIAL_LIMITS.MAX_RADIUS_STUDS).optional(),
      maxResults: z.number().int().min(1).max(SPATIAL_LIMITS.MAX_RESULTS).optional(),
      onlyEnabled: z.boolean().optional(),
    }).strict(),
  },
  {
    name: 'GetNearestObject',
    category: TOOL_CATEGORIES.SURROUNDING,
    description: 'Find the nearest matching object in Workspace by name substring, ClassName, or CollectionService tag.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        nameContains: { type: 'string' },
        className: { type: 'string' },
        tagName: { type: 'string' },
        maxRadius: { type: 'number', minimum: 1, maximum: SPATIAL_LIMITS.MAX_RADIUS_STUDS, default: 300 },
      },
      required: [],
      additionalProperties: false,
    },
    zodSchema: z.object({
      nameContains: noExternalUrlString(120, 1).optional(),
      className: noExternalUrlString(80, 1).optional(),
      tagName: noExternalUrlString(120, 1).optional(),
      maxRadius: z.number().finite().min(1).max(SPATIAL_LIMITS.MAX_RADIUS_STUDS).optional(),
    }).strict().refine(
      (data) => Boolean(data.nameContains || data.className || data.tagName),
      'Provide at least one of nameContains, className, or tagName'
    ),
  },
  {
    name: 'GetObjectsInRadius',
    category: TOOL_CATEGORIES.SURROUNDING,
    description: 'Return matching objects inside a specified radius of the character or a given origin point.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        radius: { type: 'number', minimum: 1, maximum: SPATIAL_LIMITS.MAX_RADIUS_STUDS, default: 60 },
        origin: Vector3JsonSchema,
        nameContains: { type: 'string' },
        className: { type: 'string' },
        maxResults: { type: 'integer', minimum: 1, maximum: SPATIAL_LIMITS.MAX_RESULTS, default: 25 },
      },
      required: ['radius'],
      additionalProperties: false,
    },
    zodSchema: z.object({
      radius: z.number().finite().min(1).max(SPATIAL_LIMITS.MAX_RADIUS_STUDS),
      origin: Vector3Schema.optional(),
      nameContains: noExternalUrlString(120, 1).optional(),
      className: noExternalUrlString(80, 1).optional(),
      maxResults: z.number().int().min(1).max(SPATIAL_LIMITS.MAX_RESULTS).optional(),
    }).strict(),
  },
  {
    name: 'GetNavigationPath',
    category: TOOL_CATEGORIES.SURROUNDING,
    description: 'Compute a PathfindingService path to a target position or instance path and return status and waypoints.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        targetPosition: Vector3JsonSchema,
        targetPath: { type: 'string', description: 'Optional dot-separated instance path instead of targetPosition.' },
        agentRadius: { type: 'number', minimum: 0.5, maximum: 10, default: 2 },
        agentHeight: { type: 'number', minimum: 1, maximum: 20, default: 5 },
        agentCanJump: { type: 'boolean', default: true },
      },
      required: [],
      additionalProperties: false,
    },
    zodSchema: z.object({
      targetPosition: Vector3Schema.optional(),
      targetPath: noExternalUrlString(300, 1).optional(),
      agentRadius: z.number().finite().min(0.5).max(10).optional(),
      agentHeight: z.number().finite().min(1).max(20).optional(),
      agentCanJump: z.boolean().optional(),
    }).strict().refine(
      (data) => Boolean(data.targetPosition || data.targetPath),
      'Provide either targetPosition or targetPath'
    ),
  },
  {
    name: 'GetMapOverview',
    category: TOOL_CATEGORIES.SURROUNDING,
    description: 'Provide an overview of accessible map areas, SpawnLocations, major named landmarks/models, and bounding extent.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        maxLandmarks: { type: 'integer', minimum: 5, maximum: 60, default: 25 },
      },
      required: [],
      additionalProperties: false,
    },
    zodSchema: z.object({
      maxLandmarks: z.number().int().min(5).max(60).optional(),
    }).strict(),
  },

  // =========================================================================
  // C. MOVEMENT AND NAVIGATION (25 - 35)
  // =========================================================================
  {
    name: 'MoveTo',
    category: TOOL_CATEGORIES.MOVEMENT,
    description: 'Navigate LocalPlayer smoothly to a target position or instance using Humanoid:MoveTo and PathfindingService.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        targetPosition: Vector3JsonSchema,
        targetPath: { type: 'string', description: 'Optional instance path to walk toward.' },
        usePathfinding: { type: 'boolean', default: true },
        stopDistance: { type: 'number', minimum: 0.5, maximum: 25, default: 3 },
        timeoutSeconds: { type: 'number', minimum: 1, maximum: 45, default: 15 },
        waitForArrival: { type: 'boolean', default: true },
      },
      required: [],
      additionalProperties: false,
    },
    zodSchema: z.object({
      targetPosition: Vector3Schema.optional(),
      targetPath: noExternalUrlString(300, 1).optional(),
      usePathfinding: z.boolean().optional(),
      stopDistance: z.number().finite().min(0.5).max(25).optional(),
      timeoutSeconds: z.number().finite().min(1).max(45).optional(),
      waitForArrival: z.boolean().optional(),
    }).strict().refine(
      (data) => Boolean(data.targetPosition || data.targetPath),
      'Provide either targetPosition or targetPath'
    ),
  },
  {
    name: 'MoveDirection',
    category: TOOL_CATEGORIES.MOVEMENT,
    description: 'Move LocalPlayer in a unit direction vector using normal Humanoid:Move for a bounded duration.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        direction: Vector3JsonSchema,
        durationSeconds: { type: 'number', minimum: 0.1, maximum: 10, default: 1 },
        relativeToCamera: { type: 'boolean', default: false },
      },
      required: ['direction'],
      additionalProperties: false,
    },
    zodSchema: z.object({
      direction: Vector3Schema,
      durationSeconds: z.number().finite().min(0.1).max(10).optional(),
      relativeToCamera: z.boolean().optional(),
    }).strict(),
  },
  {
    name: 'StopMovement',
    category: TOOL_CATEGORIES.MOVEMENT,
    description: 'Immediately stop any active character movement or path following.',
    requiresApprovalPolicy: false,
    jsonSchema: { type: 'object', properties: {}, required: [], additionalProperties: false },
    zodSchema: z.object({}).strict(),
  },
  {
    name: 'Jump',
    category: TOOL_CATEGORIES.MOVEMENT,
    description: 'Trigger a normal Humanoid jump for LocalPlayer.',
    requiresApprovalPolicy: false,
    jsonSchema: { type: 'object', properties: {}, required: [], additionalProperties: false },
    zodSchema: z.object({}).strict(),
  },
  {
    name: 'FacePosition',
    category: TOOL_CATEGORIES.MOVEMENT,
    description: 'Rotate LocalPlayer character horizontally toward a specified world position or instance.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        targetPosition: Vector3JsonSchema,
        targetPath: { type: 'string' },
      },
      required: [],
      additionalProperties: false,
    },
    zodSchema: z.object({
      targetPosition: Vector3Schema.optional(),
      targetPath: noExternalUrlString(300, 1).optional(),
    }).strict().refine(
      (data) => Boolean(data.targetPosition || data.targetPath),
      'Provide either targetPosition or targetPath'
    ),
  },
  {
    name: 'FollowPath',
    category: TOOL_CATEGORIES.MOVEMENT,
    description: 'Follow an ordered array of world waypoints using normal Humanoid movement.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        waypoints: {
          type: 'array',
          items: Vector3JsonSchema,
          minItems: 1,
          maxItems: SPATIAL_LIMITS.MAX_PATH_WAYPOINTS,
        },
        stopDistance: { type: 'number', minimum: 0.5, maximum: 20, default: 3 },
        timeoutSeconds: { type: 'number', minimum: 1, maximum: 45, default: 20 },
      },
      required: ['waypoints'],
      additionalProperties: false,
    },
    zodSchema: z.object({
      waypoints: z.array(Vector3Schema).min(1).max(SPATIAL_LIMITS.MAX_PATH_WAYPOINTS),
      stopDistance: z.number().finite().min(0.5).max(20).optional(),
      timeoutSeconds: z.number().finite().min(1).max(45).optional(),
    }).strict(),
  },
  {
    name: 'CancelMovement',
    category: TOOL_CATEGORIES.MOVEMENT,
    description: 'Cancel any ongoing navigation task and reset movement state.',
    requiresApprovalPolicy: false,
    jsonSchema: { type: 'object', properties: {}, required: [], additionalProperties: false },
    zodSchema: z.object({}).strict(),
  },
  {
    name: 'GetMovementStatus',
    category: TOOL_CATEGORIES.MOVEMENT,
    description: 'Report whether navigation is currently active, current target, waypoints remaining, speed, and Humanoid state.',
    requiresApprovalPolicy: false,
    jsonSchema: { type: 'object', properties: {}, required: [], additionalProperties: false },
    zodSchema: z.object({}).strict(),
  },
  {
    name: 'GetDistanceTo',
    category: TOOL_CATEGORIES.MOVEMENT,
    description: 'Calculate Euclidean and horizontal distance in studs from LocalPlayer to a position or instance.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        targetPosition: Vector3JsonSchema,
        targetPath: { type: 'string' },
      },
      required: [],
      additionalProperties: false,
    },
    zodSchema: z.object({
      targetPosition: Vector3Schema.optional(),
      targetPath: noExternalUrlString(300, 1).optional(),
    }).strict().refine(
      (data) => Boolean(data.targetPosition || data.targetPath),
      'Provide either targetPosition or targetPath'
    ),
  },
  {
    name: 'WaitForObject',
    category: TOOL_CATEGORIES.MOVEMENT,
    description: 'Wait until a specified instance path or named child appears, up to a bounded timeout.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        rootPath: { type: 'string', default: 'Workspace' },
        name: { type: 'string', description: 'Exact child/descendant name to wait for.' },
        timeoutSeconds: { type: 'number', minimum: 0.5, maximum: SPATIAL_LIMITS.MAX_WAIT_SECONDS, default: 10 },
      },
      required: ['name'],
      additionalProperties: false,
    },
    zodSchema: z.object({
      rootPath: noExternalUrlString(300, 1).optional(),
      name: noExternalUrlString(120, 1),
      timeoutSeconds: z.number().finite().min(0.5).max(SPATIAL_LIMITS.MAX_WAIT_SECONDS).optional(),
    }).strict(),
  },
  {
    name: 'WaitForStateChange',
    category: TOOL_CATEGORIES.MOVEMENT,
    description: 'Wait for a character or environment state change (e.g. HumanoidState, Health change, or attribute change) within timeout.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        watchType: {
          type: 'string',
          enum: ['humanoid_state', 'health', 'position_moved', 'attribute'],
          default: 'humanoid_state',
        },
        instancePath: { type: 'string', description: 'Used when watchType is attribute.' },
        attributeName: { type: 'string', description: 'Used when watchType is attribute.' },
        timeoutSeconds: { type: 'number', minimum: 0.5, maximum: SPATIAL_LIMITS.MAX_WAIT_SECONDS, default: 10 },
      },
      required: ['watchType'],
      additionalProperties: false,
    },
    zodSchema: z.object({
      watchType: z.enum(['humanoid_state', 'health', 'position_moved', 'attribute']),
      instancePath: noExternalUrlString(300, 1).optional(),
      attributeName: noExternalUrlString(120, 1).optional(),
      timeoutSeconds: z.number().finite().min(0.5).max(SPATIAL_LIMITS.MAX_WAIT_SECONDS).optional(),
    }).strict(),
  },

  // =========================================================================
  // D. INTERACTION (36 - 42)
  // =========================================================================
  {
    name: 'InteractWithPrompt',
    category: TOOL_CATEGORIES.INTERACTION,
    description: 'Interact with a ProximityPrompt using fireproximityprompt (or executor-supported interaction).',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        promptPath: { type: 'string', description: 'Dot-separated path to the ProximityPrompt.' },
        holdDurationOverride: { type: 'number', minimum: 0, maximum: 15 },
      },
      required: ['promptPath'],
      additionalProperties: false,
    },
    zodSchema: z.object({
      promptPath: noExternalUrlString(300, 1),
      holdDurationOverride: z.number().finite().min(0).max(15).optional(),
    }).strict(),
  },
  {
    name: 'InspectInteractable',
    category: TOOL_CATEGORIES.INTERACTION,
    description: 'Inspect an interactable object (Prompt, ClickDetector, TouchInterest, Seat) and report properties, distance, and supported interaction methods.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        instancePath: { type: 'string', description: 'Dot-separated path to the interactable or its parent BasePart/Model.' },
        triggerTouchInterest: {
          type: 'boolean',
          default: false,
          description: 'Optional: if true and firetouchinterest is available, touch the BasePart TouchInterest safely.',
        },
        triggerClickDetector: {
          type: 'boolean',
          default: false,
          description: 'Optional: if true and fireclickdetector is available, trigger ClickDetector.',
        },
      },
      required: ['instancePath'],
      additionalProperties: false,
    },
    zodSchema: z.object({
      instancePath: noExternalUrlString(300, 1),
      triggerTouchInterest: z.boolean().optional(),
      triggerClickDetector: z.boolean().optional(),
    }).strict(),
  },
  {
    name: 'InspectGui',
    category: TOOL_CATEGORIES.INTERACTION,
    description: 'Inspect a specific GUI object or ScreenGui in PlayerGui by path, returning text, visibility, bounds, and interactive children.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        guiPath: { type: 'string', description: 'Path under PlayerGui or full instance path.' },
        maxDepth: { type: 'integer', minimum: 1, maximum: 10, default: 5 },
      },
      required: ['guiPath'],
      additionalProperties: false,
    },
    zodSchema: z.object({
      guiPath: noExternalUrlString(300, 1),
      maxDepth: z.number().int().min(1).max(10).optional(),
    }).strict(),
  },
  {
    name: 'ClickVisibleGuiButton',
    category: TOOL_CATEGORIES.INTERACTION,
    description: 'Activate a visible GuiButton (TextButton/ImageButton) via normal input behaviour (VirtualInputManager or executor signal firing).',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        buttonPath: { type: 'string', description: 'Path to the visible TextButton or ImageButton.' },
      },
      required: ['buttonPath'],
      additionalProperties: false,
    },
    zodSchema: z.object({
      buttonPath: noExternalUrlString(300, 1),
    }).strict(),
  },
  {
    name: 'GetAvailableTools',
    category: TOOL_CATEGORIES.INTERACTION,
    description: 'List Roblox Tool objects currently equipped on the Character or stored in LocalPlayer.Backpack.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        equipToolName: {
          type: 'string',
          description: 'Optional tool name to equip from Backpack during this call.',
        },
      },
      required: [],
      additionalProperties: false,
    },
    zodSchema: z.object({
      equipToolName: noExternalUrlString(120, 1).optional(),
    }).strict(),
  },
  {
    name: 'GetCurrentTasks',
    category: TOOL_CATEGORIES.INTERACTION,
    description: 'Read exposed objectives, quests, leaderstats, or visible task HUD text from the authorised experience.',
    requiresApprovalPolicy: false,
    jsonSchema: { type: 'object', properties: {}, required: [], additionalProperties: false },
    zodSchema: z.object({}).strict(),
  },
  {
    name: 'GetExecutorCapabilities',
    category: TOOL_CATEGORIES.INTERACTION,
    description: 'Report executor identity and supported functions (HTTP request, fireproximityprompt, firetouchinterest, fireclickdetector, loadstring, VirtualInputManager, etc.).',
    requiresApprovalPolicy: false,
    jsonSchema: { type: 'object', properties: {}, required: [], additionalProperties: false },
    zodSchema: z.object({}).strict(),
  },

  // =========================================================================
  // E. SANDBOXED EXECUTOR FILE WORKSPACE (43 - 46)
  // ============================================================================
  {
    name: 'ReadFile',
    category: TOOL_CATEGORIES.FILES,
    description: 'Read a UTF-8 text file from BridgeClient.lua’s sandboxed roblox-ai-bridge-workspace folder. Returns "Not supported" when the executor has no readfile function.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'Safe relative file path inside the bridge workspace.' },
        maxBytes: { type: 'integer', minimum: 1, maximum: 131072, default: 65536, description: 'Maximum UTF-8 bytes returned.' },
      },
      required: ['path'],
      additionalProperties: false,
    },
    zodSchema: z.object({
      path: workspaceRelativePath(),
      maxBytes: z.number().int().min(1).max(131072).optional(),
    }).strict(),
  },
  {
    name: 'ReadFolder',
    category: TOOL_CATEGORIES.FILES,
    description: 'List files and subfolders in the sandboxed bridge workspace. Uses the executor listfiles function and returns "Not supported" if unavailable.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'Optional safe relative folder path; omit for the workspace root.' },
        limit: { type: 'integer', minimum: 1, maximum: 200, default: 100 },
      },
      required: [],
      additionalProperties: false,
    },
    zodSchema: z.object({
      path: workspaceRelativePath().optional(),
      limit: z.number().int().min(1).max(200).optional(),
    }).strict(),
  },
  {
    name: 'MakeFile',
    category: TOOL_CATEGORIES.FILES,
    description: 'Create or overwrite a UTF-8 text file inside the sandboxed bridge workspace using the executor writefile function. Existing files require overwrite: true.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'Safe relative destination path inside the bridge workspace.' },
        content: { type: 'string', minLength: 0, maxLength: 524288, description: 'UTF-8 text content to write.' },
        overwrite: { type: 'boolean', default: false, description: 'Allow replacing an existing file.' },
      },
      required: ['path', 'content'],
      additionalProperties: false,
    },
    zodSchema: z.object({
      path: workspaceRelativePath(),
      content: noExternalUrlString(524288),
      overwrite: z.boolean().optional(),
    }).strict(),
  },
  {
    name: 'MakeFolder',
    category: TOOL_CATEGORIES.FILES,
    description: 'Create a folder inside the sandboxed bridge workspace using the executor makefolder function. Returns "Not supported" if unavailable.',
    requiresApprovalPolicy: false,
    jsonSchema: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'Safe relative folder path inside the bridge workspace.' },
      },
      required: ['path'],
      additionalProperties: false,
    },
    zodSchema: z.object({
      path: workspaceRelativePath(),
    }).strict(),
  },

  // =========================================================================
  // F. CODE EXECUTION (47)
  // =========================================================================
  {
    name: 'ExecuteLuau',
    category: TOOL_CATEGORIES.EXECUTION,
    description: 'Execute diagnostic Luau code inside the authorised Roblox test environment. Use code for direct source up to 16 KB, or sourceFile for a .txt text-file payload up to the configured file limit. Captures output, return values, execution duration, and tracebacks. Subject to server approval policy.',
    requiresApprovalPolicy: true,
    jsonSchema: {
      type: 'object',
      properties: {
        code: {
          type: 'string',
          minLength: 1,
          maxLength: 16384,
          description: 'Direct diagnostic Luau source code (maximum 16 KB). Provide this or sourceFile, not both.',
        },
        sourceFile: {
          type: 'object',
          description: 'A .txt text-file payload for large scripts. This is sent inside the WebSocket tool call and bypasses the 16 KB direct-code limit.',
          properties: {
            name: { type: 'string', pattern: '\.txt$', description: 'Text-file name, ending in .txt.' },
            content: { type: 'string', minLength: 1, maxLength: 1048576, description: 'Luau source stored in the text file.' },
          },
          required: ['name', 'content'],
          additionalProperties: false,
        },
        timeoutMs: {
          type: 'integer',
          minimum: 250,
          maximum: 15000,
          default: 5000,
          description: 'Execution timeout in milliseconds.',
        },
        reason: {
          type: 'string',
          maxLength: 300,
          description: 'Short explanation of why diagnostic code execution is needed (shown in dashboard approval queue).',
        },
      },
      required: [],
      additionalProperties: false,
      oneOf: [
        { required: ['code'] },
        { required: ['sourceFile'] },
      ],
    },
    zodSchema: z.object({
      code: noExternalUrlString(16384, 1).optional(),
      sourceFile: z.object({
        name: z.string().min(5).max(128).regex(/\.txt$/i, 'sourceFile.name must end in .txt'),
        content: noExternalUrlString(1048576, 1),
      }).strict().optional(),
      timeoutMs: z.number().int().min(250).max(15000).optional(),
      reason: noExternalUrlString(300, 1).optional(),
    }).strict().refine(
      (data) => Boolean(data.code) !== Boolean(data.sourceFile),
      'Provide exactly one of code or sourceFile'
    ),
  },
];

const TOOL_MAP = new Map(TOOL_DEFINITIONS.map((tool) => [tool.name, tool]));

function getToolDefinition(name) {
  return TOOL_MAP.get(name) || null;
}

function getAllToolDefinitions() {
  return TOOL_DEFINITIONS;
}

function toOpenAITools() {
  return TOOL_DEFINITIONS.map((tool) => ({
    type: 'function',
    function: {
      name: tool.name,
      description: tool.description,
      parameters: tool.jsonSchema,
    },
  }));
}

function toMcpTools() {
  return TOOL_DEFINITIONS.map((tool) => ({
    name: tool.name,
    description: tool.description,
    inputSchema: tool.jsonSchema,
  }));
}

module.exports = {
  ALLOWLISTED_INSTANCE_PROPERTIES,
  TOOL_DEFINITIONS,
  getToolDefinition,
  getAllToolDefinitions,
  toOpenAITools,
  toMcpTools,
};
