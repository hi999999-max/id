#!/usr/bin/env bash
set -euo pipefail

INSTALL_DIR="/opt/roblox-ai-bridge"
SERVICE_NAME="roblox-ai-bridge"
SERVICE_USER="robloxbridge"

if [[ $EUID -ne 0 ]]; then
  echo "ERROR: Please run uninstall.sh as root (for example: sudo bash uninstall.sh)"
  exit 1
fi

echo "Stopping and disabling ${SERVICE_NAME}..."
systemctl stop "${SERVICE_NAME}.service" 2>/dev/null || true
systemctl disable "${SERVICE_NAME}.service" 2>/dev/null || true
rm -f "/etc/systemd/system/${SERVICE_NAME}.service"
systemctl daemon-reload

read -r -p "Remove ${INSTALL_DIR} directory (including .env)? [y/N]: " REMOVE_FILES
if [[ "${REMOVE_FILES,,}" == "y" ]]; then
  rm -rf "$INSTALL_DIR"
  echo "Removed ${INSTALL_DIR}."
else
  echo "Kept ${INSTALL_DIR}."
fi

if id -u "$SERVICE_USER" >/dev/null 2>&1; then
  userdel "$SERVICE_USER" 2>/dev/null || true
fi

echo "Uninstall complete. SSH and unrelated firewall rules were not modified."
