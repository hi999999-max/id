# Roblox AI Executor Bridge — Beginner-Friendly Setup Guide

This guide walks you step-by-step from zero to a working system on your Fasthosts VPS (`77.68.33.65`, port `3003`).

Every command below is labeled with **where** you should run it:
- **[On Your Computer]** — PowerShell on Windows, Terminal on macOS/Linux, or Termux on Android
- **[In VPS SSH Terminal]** — After you log into your Fasthosts VPS (`77.68.33.65`)
- **[Inside Your Roblox Executor]** — Script editor inside your Roblox executor
- **[In Your AI Agent]** — New AI chat / MCP client

---

## Step 1: Open an SSH Terminal and Access Your VPS

You need your Fasthosts VPS IP (`77.68.33.65`), username (usually `root`), and password or SSH key from your Fasthosts control panel.

### Option A: Windows 10 / 11 (Built-in PowerShell)
**[On Your Computer]**
1. Press `Win + X` and click **Terminal** or **PowerShell**.
2. Run:
   ```powershell
   ssh root@77.68.33.65
   ```
3. If asked `Are you sure you want to continue connecting (yes/no)?`, type `yes` and press Enter.
4. Type your VPS password (nothing shows while typing — that is normal) and press Enter.

**What success looks like:** Your prompt changes to something like `root@vps-12345:~#`.

### Option B: Android (Termux)
**[On Your Computer (Android Termux)]**
1. Install **Termux** (from F-Droid or GitHub Releases).
2. Run:
   ```bash
   pkg update -y && pkg install -y openssh
   ssh root@77.68.33.65
   ```

---

## Step 2: Upload the Project ZIP to Your VPS

1. Download `roblox-ai-bridge.zip` onto your computer.
2. Upload it to your VPS `/root/` folder:

**[On Your Computer — Windows PowerShell]**
```powershell
scp roblox-ai-bridge.zip root@77.68.33.65:/root/
```

*(On Android Termux: first run `termux-setup-storage`, find your ZIP under `~/storage/downloads/roblox-ai-bridge.zip`, then run `scp ~/storage/downloads/roblox-ai-bridge.zip root@77.68.33.65:/root/`.)*

---

## Step 3: Inspect the VPS and Install the Project

**[In VPS SSH Terminal]**
Run these copy-and-paste commands one block at a time:

```bash
# Install unzip if missing, then extract the project
apt-get update -y && apt-get install -y unzip 2>/dev/null || dnf install -y unzip
cd /root
unzip -o roblox-ai-bridge.zip -d /root/roblox-ai-bridge-src
cd /root/roblox-ai-bridge-src
```

Now run the installer (it inspects your Linux OS, Node.js version, port 3003, and firewall before installing into `/opt/roblox-ai-bridge`):

```bash
sudo bash install.sh
```

**What success looks like:**
- Node.js 20 LTS is detected or installed.
- Non-root user `robloxbridge` is created.
- `/opt/roblox-ai-bridge/.env` is created with random high-entropy tokens.
- `SUCCESS: roblox-ai-bridge is running!` is printed.

---

## Step 4: View Your Generated Tokens

**[In VPS SSH Terminal]**
```bash
cat /opt/roblox-ai-bridge/.env
```
Look for these three lines and keep them private:
- `EXECUTOR_API_TOKEN=...` (goes into `BridgeClient.lua`)
- `AI_API_TOKEN=...` (given to your AI agent)
- `DASHBOARD_ADMIN_TOKEN=...` (unlocks the dark-theme web dashboard)

*(Optional: To restrict which Roblox games can connect, edit `ALLOWED_PLACE_IDS=*` to `ALLOWED_PLACE_IDS=123456789` with `nano /opt/roblox-ai-bridge/.env`.)*

---

## Step 5: Configure the Secure Network Connection (Important!)

Because you do not have a domain name, you must **never** send your tokens over unprotected public HTTP (`http://77.68.33.65:3003`). Choose **Option A (WireGuard VPN — Easiest & Free)** or **Option B (Public HTTPS IP Certificate)**.

### Option A: WireGuard Private Tunnel (Recommended)

**[In VPS SSH Terminal]**
Run the included WireGuard helper:
```bash
sudo bash /opt/roblox-ai-bridge/scripts/setup-wireguard.sh
```
Then tell the server to listen on the WireGuard IP `10.66.66.1`:
```bash
sed -i 's/^HOST=.*/HOST=10.66.66.1/' /opt/roblox-ai-bridge/.env
systemctl restart roblox-ai-bridge
```

Now display the client config for your Windows PC (and/or Android phone):
```bash
cat /opt/roblox-ai-bridge/wireguard-clients/pc-client.conf
```

**[On Your Computer — Windows or Android]**
1. Download the official **WireGuard** app (`wireguard.com/install` on Windows, or Google Play Store on Android).
2. Click **Add Tunnel -> Add empty tunnel** (or **Import**), paste the `pc-client.conf` text, name it `RobloxBridge`, and click **Activate**.
3. Your private bridge address is now:
   **`http://10.66.66.1:3003`** (encrypted inside WireGuard!).

### Option B: Public HTTPS on `77.68.33.65:3003` (If You Have an IP TLS Certificate)

If you obtain a trusted TLS certificate for IP `77.68.33.65` (for example via an ACME provider supporting IP certificates such as ZeroSSL or Let's Encrypt IP-cert profile):
**[In VPS SSH Terminal]**
```bash
# Place your cert and key here:
# /opt/roblox-ai-bridge/certs/server.crt
# /opt/roblox-ai-bridge/certs/server.key
chown robloxbridge:robloxbridge /opt/roblox-ai-bridge/certs/*
chmod 600 /opt/roblox-ai-bridge/certs/server.key

sed -i 's/^TLS_ENABLED=.*/TLS_ENABLED=true/' /opt/roblox-ai-bridge/.env
sed -i 's/^HOST=.*/HOST=0.0.0.0/' /opt/roblox-ai-bridge/.env

# Allow TCP 3003 in UFW without touching SSH:
ufw allow 3003/tcp comment "Roblox AI Bridge HTTPS"
systemctl restart roblox-ai-bridge
```
Your bridge URL will then be **`https://77.68.33.65:3003`**.

---

## Step 6: Check Whether the Server & Website Work

**[In VPS SSH Terminal]**
```bash
bash /opt/roblox-ai-bridge/status.sh
```
**What success looks like:**
- `Active: active (running)`
- Node is listening on `:3003`
- Health check prints `{"ok":true,"status":"healthy","service":"roblox-ai-bridge",...}`

**[On Your Computer]**
1. Make sure WireGuard is active (if using Option A).
2. Open your browser to:
   - `http://10.66.66.1:3003` (WireGuard), OR
   - `https://77.68.33.65:3003` (HTTPS IP cert)
3. Enter your `DASHBOARD_ADMIN_TOKEN` from `.env` to unlock the dark-theme dashboard.

---

## Step 7: Test with the Mock Executor (Optional Sanity Check)

Before opening Roblox, you can test the full backend cycle using the included Mock Executor:

**[In VPS SSH Terminal]**
```bash
cd /opt/roblox-ai-bridge
EXECUTOR_API_TOKEN=$(grep '^EXECUTOR_API_TOKEN=' .env | cut -d= -f2-) \
BRIDGE_URL="http://10.66.66.1:3003" \
node scripts/mock-executor.js
```
*(Replace `10.66.66.1` with `127.0.0.1` if testing locally before WireGuard.)*
**What success looks like:** `Mock Executor connected! sessionId=sess_... executorId=exec_...` and the dashboard immediately shows **Executor Status: Connected**. Press `Ctrl+C` when done testing.

---

## Step 8: Run the Executor Script in Roblox

**[On Your Computer]**
1. Open `/opt/roblox-ai-bridge/executor/BridgeClient.lua` (from your extracted ZIP folder `roblox-ai-bridge/executor/BridgeClient.lua`).
2. Edit lines 18–20 at the top:
   ```lua
   ServerUrl = "http://10.66.66.1:3003", -- or https://77.68.33.65:3003
   ExecutorToken = "PASTE_YOUR_EXECUTOR_API_TOKEN_HERE",
   ```
3. Join your authorised Roblox test experience.

**[Inside Your Roblox Executor]**
1. Paste the edited `BridgeClient.lua` script into your executor.
2. Click **Execute**.
3. Check the Roblox Developer Console (`F9`) for:
   `[RobloxAIBridge] Connected! SessionId=sess_... ExecutorId=exec_...`
4. Confirm the Dashboard shows **Executor Status: Connected** and your current Roblox game & Place ID.

---

## Step 9: Connect Your AI Agent

**[In Your AI Agent]**
1. Start a new conversation with an AI agent that can make HTTP requests (or connect an MCP client to `POST /mcp`).
2. Upload the file **`AI_TOOL_GUIDE.md`** from the project folder.
3. Copy the contents of **`AI_START_PROMPT.txt`**, replace `<PASTE_URL_HERE>` and `<PASTE_AI_API_TOKEN_HERE>` with your bridge URL and `AI_API_TOKEN`, and send it.

The AI will register itself, discover all 43 tools, inspect your Roblox world, and wait for your instructions!

---

## Useful VPS Management Commands

**[In VPS SSH Terminal]**
- Check status & health: `bash /opt/roblox-ai-bridge/status.sh`
- Watch live server logs: `bash /opt/roblox-ai-bridge/logs.sh`
- Update after editing files: `sudo bash /opt/roblox-ai-bridge/update.sh`
- Run automated backend tests: `cd /opt/roblox-ai-bridge && npm test`
- Uninstall cleanly: `sudo bash /opt/roblox-ai-bridge/uninstall.sh`

---

## Troubleshooting Guide

### 1. Connection Refused
- **Cause:** Server is stopped, bound to `127.0.0.1` while you connect via `10.66.66.1`, or WireGuard is turned off on your PC.
- **Fix:**
  1. **[In VPS SSH Terminal]** Run `bash /opt/roblox-ai-bridge/status.sh` to see which IP & port Node is listening on.
  2. Check `HOST=` in `/opt/roblox-ai-bridge/.env` matches `10.66.66.1` (WireGuard) or `0.0.0.0` (HTTPS).
  3. **[On Your Computer]** Verify WireGuard tunnel is **Active**.

### 2. Port 3003 Being Blocked
- **Cause:** VPS firewall (`ufw` / `firewalld`) or Fasthosts cloud firewall panel is blocking traffic.
- **Fix:**
  - If using WireGuard: ensure **UDP 51820** is open in both UFW (`ufw allow 51820/udp`) and the **Fasthosts Cloud Panel Firewall**.
  - If using public HTTPS on 3003: ensure **TCP 3003** is open in UFW (`ufw allow 3003/tcp`) and the **Fasthosts Cloud Panel Firewall**.

### 3. VPS Service Not Starting
- **Cause:** Missing/short tokens in `.env`, `HOST=0.0.0.0` without `TLS_ENABLED=true`, or missing cert files.
- **Fix:** **[In VPS SSH Terminal]** Run:
  ```bash
  journalctl -u roblox-ai-bridge -n 40 --no-pager
  ```
  Read the exact `[FATAL]` line, fix `/opt/roblox-ai-bridge/.env`, then run `sudo systemctl restart roblox-ai-bridge`.

### 4. Invalid Authentication (`401 UNAUTHORIZED`)
- **Cause:** Using `AI_API_TOKEN` inside `BridgeClient.lua` or `EXECUTOR_API_TOKEN` in your AI agent, or extra spaces/quotes when pasting.
- **Fix:** Check `/opt/roblox-ai-bridge/.env`:
  - `BridgeClient.lua` uses `EXECUTOR_API_TOKEN`
  - AI agent uses `AI_API_TOKEN`
  - Dashboard login uses `DASHBOARD_ADMIN_TOKEN`

### 5. Executor Not Registering (`403 PLACE_NOT_ALLOWED` or compatibility error)
- **Cause:** Either your Roblox executor lacks a supported `request`/`http_request` function, or `game.PlaceId` is not in `ALLOWED_PLACE_IDS`.
- **Fix:** Press `F9` in Roblox to read the exact message. Set `ALLOWED_PLACE_IDS=*` in `.env` (or add your Place ID) and restart the service.

### 6. AI Not Registering (`404` or `401`)
- **Cause:** Wrong URL path or missing `Authorization: Bearer ...` header.
- **Fix:** Ensure the AI calls `POST <BASE_URL>/api/v1/ai/register` with `Authorization: Bearer <AI_API_TOKEN>` and `Content-Type: application/json`.

### 7. Timeout (`REQUEST_TIMEOUT`)
- **Cause:** `BridgeClient.lua` was stopped, Roblox froze/disconnected, or `MoveTo` took longer than `timeoutMs`.
- **Fix:** Check `F9` console in Roblox and the Dashboard's **Executor Heartbeat** indicator. Increase `timeoutMs` on long `MoveTo` calls (or pass `wait: false` and poll `/api/v1/ai/requests/:requestId`).

### 8. Polling Not Receiving Tasks
- **Cause:** Executor and AI are attached to two different `sessionId`s.
- **Fix:** Look at the Dashboard **Session Selector** or pass the exact `sessionId` returned by `BridgeClient.lua` when calling `POST /api/v1/ai/register`.

### 9. Tool Execution Failing (`EXECUTOR_RUNTIME_ERROR` or `TOOL_DISABLED`)
- **Cause:** Missing executor capability (e.g. `fireproximityprompt`), invalid `instancePath`, or `ExecuteLuau` awaiting manual approval in the Dashboard.
- **Fix:**
  - Call `GetExecutorCapabilities` to verify what your executor supports.
  - If `ExecuteLuau` is pending, open the Dashboard and click **Approve & Run** (or toggle **Manual Approval** if you trust the session).
