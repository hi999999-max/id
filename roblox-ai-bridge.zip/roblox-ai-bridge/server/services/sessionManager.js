'use strict';

const crypto = require('crypto');
const { REQUEST_STATUS, ERROR_CODES } = require('../../shared/constants');

class BridgeError extends Error {
  constructor(statusCode, code, message, details = undefined) {
    super(message);
    this.name = 'BridgeError';
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
  }
}

class SessionManager {
  constructor(config, logger, toolRegistry) {
    this.config = config;
    this.logger = logger;
    this.toolRegistry = toolRegistry;

    // Map<sessionId, SessionState>
    this.sessions = new Map();
    // Bounded global idempotency cache: Map<key, { requestId, sessionId, createdAt }>
    this.idempotencyCache = new Map();
    // Bounded activity & history logs across server
    this.activityFeed = [];
    this.executionHistory = [];
    this.connectionErrors = [];

    this.policy = {
      executeLuauEnabled: config.executeLuauEnabled,
      executeLuauRequireApproval: config.executeLuauRequireApproval,
    };

    this.stats = {
      serverStartedAt: new Date().toISOString(),
      totalCompleted: 0,
      totalFailed: 0,
      totalTimedOut: 0,
      totalCancelled: 0,
    };

    // Background heartbeat sweep
    this.heartbeatTimer = setInterval(() => {
      this._checkHeartbeats();
    }, Math.min(5000, Math.max(1000, Math.floor(config.executorHeartbeatTimeoutMs / 3))));
    if (this.heartbeatTimer.unref) {
      this.heartbeatTimer.unref();
    }
  }

  shutdown() {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }
    for (const session of this.sessions.values()) {
      this._flushPollWaiters(session);
      for (const reqRecord of session.requests.values()) {
        if (reqRecord.timer) clearTimeout(reqRecord.timer);
        if (reqRecord.resolveWaiter) {
          reqRecord.resolveWaiter({
            ok: false,
            requestId: reqRecord.requestId,
            sessionId: session.sessionId,
            toolName: reqRecord.toolName,
            status: REQUEST_STATUS.CANCELLED,
            error: {
              code: ERROR_CODES.REQUEST_CANCELLED,
              message: 'Server is shutting down.',
            },
          });
        }
      }
    }
  }

  isPlaceAllowed(placeId) {
    if (this.config.allowedPlaceIds.allowAll) return true;
    if (placeId === undefined || placeId === null) return false;
    return this.config.allowedPlaceIds.ids.has(Number(placeId));
  }

  _recordActivity(type, message, details = {}) {
    const entry = {
      id: crypto.randomUUID(),
      ts: new Date().toISOString(),
      type,
      message,
      details,
    };
    this.activityFeed.unshift(entry);
    if (this.activityFeed.length > this.config.maxActivityHistory) {
      this.activityFeed.length = this.config.maxActivityHistory;
    }
  }

  _recordConnectionError(source, code, message, sessionId = null) {
    const entry = {
      id: crypto.randomUUID(),
      ts: new Date().toISOString(),
      source,
      code,
      message,
      sessionId,
    };
    this.connectionErrors.unshift(entry);
    if (this.connectionErrors.length > 100) {
      this.connectionErrors.length = 100;
    }
    this._recordActivity('error', `[${source}] ${message}`, { code, sessionId });
  }

  _recordHistory(reqRecord) {
    const summary = {
      requestId: reqRecord.requestId,
      sessionId: reqRecord.sessionId,
      toolName: reqRecord.toolName,
      status: reqRecord.status,
      createdAt: reqRecord.createdAt,
      completedAt: reqRecord.completedAt || new Date().toISOString(),
      durationMs: reqRecord.durationMs ?? null,
      ok: reqRecord.status === REQUEST_STATUS.COMPLETED,
      error: reqRecord.error || null,
      argsPreview: this._previewArgs(reqRecord.toolName, reqRecord.args),
      resultPreview: reqRecord.result ? this._previewResult(reqRecord.result) : null,
    };
    this.executionHistory.unshift(summary);
    if (this.executionHistory.length > this.config.maxActivityHistory) {
      this.executionHistory.length = this.config.maxActivityHistory;
    }
  }

  _previewArgs(toolName, args) {
    try {
      const str = JSON.stringify(args || {});
      return str.length > 260 ? `${str.slice(0, 260)}...` : str;
    } catch {
      return '{}';
    }
  }

  _previewResult(result) {
    try {
      const str = JSON.stringify(result);
      return str.length > 320 ? `${str.slice(0, 320)}...` : str;
    } catch {
      return '[Unserializable]';
    }
  }

  _createSession(preferredSessionId = null) {
    const sessionId = preferredSessionId || `sess_${crypto.randomUUID()}`;
    const now = Date.now();
    const session = {
      sessionId,
      createdAt: new Date(now).toISOString(),
      updatedAt: now,
      executor: {
        connected: false,
        executorId: null,
        executorName: null,
        placeId: null,
        jobId: null,
        gameName: null,
        playerName: null,
        playerUserId: null,
        capabilities: {},
        registeredAt: null,
        lastHeartbeatAt: null,
        lastPollAt: null,
      },
      ai: {
        connected: false,
        aiClientId: null,
        clientName: null,
        registeredAt: null,
        lastSeenAt: null,
      },
      queue: [], // array of requestIds waiting to be polled
      inFlight: new Set(), // requestIds dispatched to executor awaiting result
      pendingApproval: new Set(), // requestIds awaiting dashboard manual approval
      requests: new Map(), // requestId -> RequestRecord
      controlSignals: [], // immediate commands for executor (e.g. EMERGENCY_STOP, CANCEL_REQUEST)
      pollWaiters: [], // waiting long-poll callbacks
    };
    this.sessions.set(sessionId, session);
    return session;
  }

  _findSessionForExecutor({ sessionId }) {
    if (sessionId) {
      return this.sessions.get(sessionId) || this._createSession(sessionId);
    }
    // Prefer an existing session that has an AI waiting without a connected executor
    for (const session of this.sessions.values()) {
      if (session.ai.connected && !session.executor.connected) {
        return session;
      }
    }
    // Or reuse an existing disconnected executor session if nothing else active
    for (const session of this.sessions.values()) {
      if (!session.executor.connected && !session.ai.connected) {
        return session;
      }
    }
    return this._createSession();
  }

  _findSessionForAi({ sessionId }) {
    if (sessionId) {
      const existing = this.sessions.get(sessionId);
      if (!existing) {
        throw new BridgeError(404, ERROR_CODES.SESSION_NOT_FOUND, `Session "${sessionId}" does not exist.`);
      }
      return existing;
    }
    // Prefer a session with a connected executor and no AI yet
    for (const session of this.sessions.values()) {
      if (session.executor.connected && !session.ai.connected) {
        return session;
      }
    }
    // Next, any session with a connected executor
    for (const session of this.sessions.values()) {
      if (session.executor.connected) {
        return session;
      }
    }
    // Otherwise create a fresh session waiting for executor
    return this._createSession();
  }

  registerExecutor(payload) {
    const {
      sessionId,
      executorName = 'RobloxExecutor',
      placeId,
      jobId = '',
      gameName = 'Unknown Experience',
      playerName = null,
      playerUserId = null,
      capabilities = {},
    } = payload;

    if (!this.isPlaceAllowed(placeId)) {
      const msg = `PlaceId ${placeId} is not in ALLOWED_PLACE_IDS.`;
      this._recordConnectionError('executor', ERROR_CODES.PLACE_NOT_ALLOWED, msg, sessionId || null);
      throw new BridgeError(403, ERROR_CODES.PLACE_NOT_ALLOWED, msg);
    }

    const session = this._findSessionForExecutor({ sessionId });
    const now = Date.now();
    const executorId = `exec_${crypto.randomUUID().slice(0, 12)}`;

    session.executor = {
      connected: true,
      executorId,
      executorName,
      placeId: Number(placeId),
      jobId: String(jobId || ''),
      gameName: String(gameName || 'Unknown Experience'),
      playerName: playerName ? String(playerName) : null,
      playerUserId: playerUserId !== null && playerUserId !== undefined ? Number(playerUserId) : null,
      capabilities: capabilities && typeof capabilities === 'object' ? capabilities : {},
      registeredAt: new Date(now).toISOString(),
      lastHeartbeatAt: now,
      lastPollAt: session.executor.lastPollAt,
    };
    session.updatedAt = now;

    this._recordActivity('executor_register', `Executor "${executorName}" connected to "${session.executor.gameName}" (Place ${placeId})`, {
      sessionId: session.sessionId,
      executorId,
      placeId: Number(placeId),
    });

    return {
      sessionId: session.sessionId,
      executorId,
      pairedWithAi: session.ai.connected,
      aiClientName: session.ai.clientName,
      heartbeatIntervalMs: Math.max(3000, Math.floor(this.config.executorHeartbeatTimeoutMs / 3)),
      pollMaxWaitMs: this.config.executorPollMaxWaitMs,
      maxResultBytes: this.config.maxResultBytes,
    };
  }

  executorHeartbeat(payload) {
    const { sessionId, executorId, placeId, jobId, gameName, capabilities } = payload;
    const session = this.sessions.get(sessionId);
    if (!session) {
      throw new BridgeError(404, ERROR_CODES.SESSION_NOT_FOUND, `Session "${sessionId}" not found.`);
    }
    if (!session.executor.connected || (executorId && session.executor.executorId !== executorId)) {
      throw new BridgeError(409, ERROR_CODES.EXECUTOR_OFFLINE, 'Executor is not currently registered on this session. Please re-register.');
    }

    if (placeId !== undefined && placeId !== null && !this.isPlaceAllowed(placeId)) {
      const msg = `PlaceId ${placeId} is not in ALLOWED_PLACE_IDS.`;
      this.disconnectExecutor(sessionId, msg);
      throw new BridgeError(403, ERROR_CODES.PLACE_NOT_ALLOWED, msg);
    }

    const now = Date.now();
    session.executor.lastHeartbeatAt = now;
    if (placeId !== undefined && placeId !== null) session.executor.placeId = Number(placeId);
    if (jobId !== undefined) session.executor.jobId = String(jobId);
    if (gameName !== undefined) session.executor.gameName = String(gameName);
    if (capabilities && typeof capabilities === 'object') session.executor.capabilities = capabilities;
    session.updatedAt = now;

    return {
      ok: true,
      sessionId: session.sessionId,
      connected: true,
      pairedWithAi: session.ai.connected,
      queuedTasks: session.queue.length,
      inFlightTasks: session.inFlight.size,
      serverTime: new Date(now).toISOString(),
    };
  }

  async pollExecutor(payload) {
    const { sessionId, executorId, waitMs, maxTasks = 5 } = payload;
    const session = this.sessions.get(sessionId);
    if (!session) {
      throw new BridgeError(404, ERROR_CODES.SESSION_NOT_FOUND, `Session "${sessionId}" not found.`);
    }
    if (!session.executor.connected || (executorId && session.executor.executorId !== executorId)) {
      throw new BridgeError(409, ERROR_CODES.EXECUTOR_OFFLINE, 'Executor session disconnected. Re-register required.');
    }

    const now = Date.now();
    session.executor.lastPollAt = now;
    session.executor.lastHeartbeatAt = now;
    session.updatedAt = now;

    const immediate = this._drainTasksForExecutor(session, maxTasks);
    if (immediate.tasks.length > 0 || immediate.controlSignals.length > 0) {
      return immediate;
    }

    const effectiveWaitMs = Math.min(
      Math.max(0, waitMs !== undefined ? Number(waitMs) : this.config.executorPollDefaultWaitMs),
      this.config.executorPollMaxWaitMs
    );

    if (effectiveWaitMs === 0) {
      return immediate;
    }

    return new Promise((resolve) => {
      let resolved = false;
      const timer = setTimeout(() => {
        if (resolved) return;
        resolved = true;
        session.pollWaiters = session.pollWaiters.filter((w) => w.wake !== wake);
        resolve({
          sessionId: session.sessionId,
          tasks: [],
          controlSignals: [],
          serverTime: new Date().toISOString(),
        });
      }, effectiveWaitMs);

      const wake = () => {
        if (resolved) return;
        resolved = true;
        clearTimeout(timer);
        if (!session.executor.connected) {
          resolve({
            sessionId: session.sessionId,
            disconnected: true,
            tasks: [],
            controlSignals: session.controlSignals.splice(0),
            serverTime: new Date().toISOString(),
          });
          return;
        }
        resolve(this._drainTasksForExecutor(session, maxTasks));
      };

      session.pollWaiters.push({ wake });
    });
  }

  _drainTasksForExecutor(session, maxTasks) {
    const tasks = [];
    while (tasks.length < maxTasks && session.queue.length > 0) {
      const requestId = session.queue.shift();
      const reqRecord = session.requests.get(requestId);
      if (!reqRecord || reqRecord.status !== REQUEST_STATUS.QUEUED) continue;

      reqRecord.status = REQUEST_STATUS.DISPATCHED;
      reqRecord.dispatchedAt = new Date().toISOString();
      session.inFlight.add(requestId);

      tasks.push({
        requestId: reqRecord.requestId,
        sessionId: session.sessionId,
        toolName: reqRecord.toolName,
        args: reqRecord.args,
        timeoutMs: reqRecord.timeoutMs,
        createdAt: reqRecord.createdAt,
      });
    }

    const controlSignals = session.controlSignals.splice(0);

    return {
      sessionId: session.sessionId,
      tasks,
      controlSignals,
      serverTime: new Date().toISOString(),
    };
  }

  _wakePollWaiters(session) {
    if (session.pollWaiters.length === 0) return;
    const waiter = session.pollWaiters.shift();
    if (waiter && typeof waiter.wake === 'function') {
      waiter.wake();
    }
  }

  _flushPollWaiters(session) {
    while (session.pollWaiters.length > 0) {
      const waiter = session.pollWaiters.shift();
      if (waiter && typeof waiter.wake === 'function') {
        waiter.wake();
      }
    }
  }

  submitExecutorResult(payload) {
    const {
      sessionId,
      executorId,
      requestId,
      ok,
      data = null,
      error = null,
      durationMs = null,
      truncated = false,
    } = payload;

    const session = this.sessions.get(sessionId);
    if (!session) {
      throw new BridgeError(404, ERROR_CODES.SESSION_NOT_FOUND, `Session "${sessionId}" not found.`);
    }
    if (executorId && session.executor.executorId && session.executor.executorId !== executorId) {
      throw new BridgeError(403, ERROR_CODES.FORBIDDEN, 'Executor ID mismatch for session.');
    }

    const reqRecord = session.requests.get(requestId);
    if (!reqRecord) {
      throw new BridgeError(404, ERROR_CODES.INVALID_INPUT, `Request "${requestId}" does not belong to session "${sessionId}".`);
    }

    // Duplicate result submission protection
    if (
      reqRecord.status === REQUEST_STATUS.COMPLETED ||
      reqRecord.status === REQUEST_STATUS.FAILED ||
      reqRecord.status === REQUEST_STATUS.TIMED_OUT ||
      reqRecord.status === REQUEST_STATUS.CANCELLED ||
      reqRecord.status === REQUEST_STATUS.REJECTED
    ) {
      throw new BridgeError(409, ERROR_CODES.DUPLICATE_REQUEST, `Result for request "${requestId}" was already finalized (${reqRecord.status}).`);
    }

    if (reqRecord.timer) {
      clearTimeout(reqRecord.timer);
      reqRecord.timer = null;
    }

    session.inFlight.delete(requestId);
    session.executor.lastHeartbeatAt = Date.now();
    session.updatedAt = Date.now();

    // Enforce output size limit
    const serialized = JSON.stringify({ data, error });
    const byteLength = Buffer.byteLength(serialized, 'utf8');
    if (byteLength > this.config.maxResultBytes) {
      reqRecord.status = REQUEST_STATUS.FAILED;
      reqRecord.completedAt = new Date().toISOString();
      reqRecord.durationMs = durationMs;
      reqRecord.error = {
        code: ERROR_CODES.PAYLOAD_TOO_LARGE,
        message: `Executor result (${byteLength} bytes) exceeded MAX_RESULT_BYTES (${this.config.maxResultBytes} bytes). Reduce search radius or limit.`,
      };
      this.stats.totalFailed += 1;
      this._recordHistory(reqRecord);
      this._recordActivity('tool_failed', `${reqRecord.toolName} result exceeded size limit`, {
        sessionId,
        requestId,
        byteLength,
      });

      if (reqRecord.resolveWaiter) {
        reqRecord.resolveWaiter(this._formatRequestOutcome(reqRecord));
        reqRecord.resolveWaiter = null;
      }

      throw new BridgeError(413, ERROR_CODES.PAYLOAD_TOO_LARGE, reqRecord.error.message);
    }

    reqRecord.completedAt = new Date().toISOString();
    reqRecord.durationMs = durationMs;
    reqRecord.truncated = Boolean(truncated);

    if (ok) {
      reqRecord.status = REQUEST_STATUS.COMPLETED;
      reqRecord.result = data;
      this.stats.totalCompleted += 1;
      this._recordActivity('tool_completed', `${reqRecord.toolName} completed (${durationMs ?? '?'}ms)`, {
        sessionId,
        requestId,
      });
    } else {
      reqRecord.status = REQUEST_STATUS.FAILED;
      reqRecord.error = error && typeof error === 'object'
        ? {
            code: error.code || 'EXECUTOR_ERROR',
            message: String(error.message || 'Executor reported an error'),
            traceback: error.traceback ? String(error.traceback).slice(0, 4000) : undefined,
          }
        : { code: 'EXECUTOR_ERROR', message: String(error || 'Unknown executor error') };
      this.stats.totalFailed += 1;
      this._recordActivity('tool_failed', `${reqRecord.toolName} failed: ${reqRecord.error.message}`, {
        sessionId,
        requestId,
      });
    }

    this._recordHistory(reqRecord);

    if (reqRecord.resolveWaiter) {
      reqRecord.resolveWaiter(this._formatRequestOutcome(reqRecord));
      reqRecord.resolveWaiter = null;
    }

    return {
      ok: true,
      requestId,
      sessionId,
      status: reqRecord.status,
    };
  }

  registerAi(payload) {
    const { sessionId, clientName = 'AIAgent' } = payload;
    const session = this._findSessionForAi({ sessionId });

    const now = Date.now();
    const aiClientId = `ai_${crypto.randomUUID().slice(0, 12)}`;
    session.ai = {
      connected: true,
      aiClientId,
      clientName: String(clientName),
      registeredAt: new Date(now).toISOString(),
      lastSeenAt: now,
    };
    session.updatedAt = now;

    this._recordActivity('ai_register', `AI client "${clientName}" attached to session ${session.sessionId}`, {
      sessionId: session.sessionId,
      aiClientId,
      executorConnected: session.executor.connected,
    });

    return {
      sessionId: session.sessionId,
      aiClientId,
      executorConnected: session.executor.connected,
      executor: session.executor.connected
        ? {
            executorName: session.executor.executorName,
            placeId: session.executor.placeId,
            jobId: session.executor.jobId,
            gameName: session.executor.gameName,
            playerName: session.executor.playerName,
            capabilities: session.executor.capabilities,
          }
        : null,
      policy: { ...this.policy },
      toolCount: this.toolRegistry.listTools().length,
    };
  }

  async enqueueToolCall(payload) {
    const {
      sessionId,
      toolName,
      args = {},
      requestId: clientRequestId,
      idempotencyKey,
      timeoutMs,
      wait = true,
    } = payload;

    const session = this.sessions.get(sessionId);
    if (!session) {
      throw new BridgeError(404, ERROR_CODES.SESSION_NOT_FOUND, `Session "${sessionId}" not found.`);
    }
    if (!session.ai.connected) {
      throw new BridgeError(409, ERROR_CODES.AI_NOT_REGISTERED, 'AI client is not registered on this session. Call POST /api/v1/ai/register first.');
    }
    session.ai.lastSeenAt = Date.now();

    if (!session.executor.connected) {
      throw new BridgeError(503, ERROR_CODES.EXECUTOR_OFFLINE, 'No Roblox executor is currently connected to this session.');
    }

    if (!this.isPlaceAllowed(session.executor.placeId)) {
      throw new BridgeError(403, ERROR_CODES.PLACE_NOT_ALLOWED, `Current PlaceId ${session.executor.placeId} is not permitted by ALLOWED_PLACE_IDS.`);
    }

    // Validate tool & arguments
    const validation = this.toolRegistry.validateToolCall(toolName, args);
    if (!validation.ok) {
      throw new BridgeError(
        validation.code === ERROR_CODES.UNKNOWN_TOOL ? 404 : validation.code === ERROR_CODES.PAYLOAD_TOO_LARGE ? 413 : 400,
        validation.code,
        validation.message,
        validation.details
      );
    }

    // ExecuteLuau policy checks
    let needsApproval = false;
    if (toolName === 'ExecuteLuau') {
      if (!this.policy.executeLuauEnabled) {
        throw new BridgeError(403, ERROR_CODES.TOOL_DISABLED, 'ExecuteLuau is currently disabled by the dashboard administrator.');
      }
      if (this.policy.executeLuauRequireApproval) {
        needsApproval = true;
      }
    }

    // Duplicate requestId / idempotency protection
    const requestId = clientRequestId || `req_${crypto.randomUUID()}`;
    if (session.requests.has(requestId)) {
      throw new BridgeError(409, ERROR_CODES.DUPLICATE_REQUEST, `Duplicate requestId "${requestId}" rejected.`);
    }
    if (idempotencyKey) {
      const scopedKey = `${sessionId}:${idempotencyKey}`;
      if (this.idempotencyCache.has(scopedKey)) {
        throw new BridgeError(409, ERROR_CODES.DUPLICATE_REQUEST, `Duplicate idempotencyKey "${idempotencyKey}" rejected.`);
      }
      this.idempotencyCache.set(scopedKey, { requestId, sessionId, createdAt: Date.now() });
      if (this.idempotencyCache.size > 5000) {
        const oldestKey = this.idempotencyCache.keys().next().value;
        this.idempotencyCache.delete(oldestKey);
      }
    }

    // Capacity limits
    const activeCount = session.queue.length + session.inFlight.size + session.pendingApproval.size;
    if (activeCount >= this.config.maxQueuePerSession) {
      throw new BridgeError(429, ERROR_CODES.QUEUE_FULL, `Session request queue limit (${this.config.maxQueuePerSession}) reached.`);
    }
    if (session.inFlight.size + session.queue.length >= this.config.maxConcurrentRequests && wait === false) {
      // Allow queueing up to maxQueuePerSession; enforce concurrent inFlight separately
    }

    const effectiveTimeoutMs = Math.min(
      Math.max(500, Number(timeoutMs || this.config.defaultToolTimeoutMs)),
      this.config.maxToolTimeoutMs
    );

    const reqRecord = {
      requestId,
      sessionId,
      toolName,
      args: validation.args,
      status: needsApproval ? REQUEST_STATUS.PENDING_APPROVAL : REQUEST_STATUS.QUEUED,
      timeoutMs: effectiveTimeoutMs,
      createdAt: new Date().toISOString(),
      dispatchedAt: null,
      completedAt: null,
      durationMs: null,
      result: null,
      error: null,
      truncated: false,
      timer: null,
      resolveWaiter: null,
    };

    session.requests.set(requestId, reqRecord);
    session.updatedAt = Date.now();

    // Trim old completed requests from memory to stay bounded
    this._pruneSessionRequests(session);

    if (needsApproval) {
      session.pendingApproval.add(requestId);
      this._recordActivity('approval_requested', `ExecuteLuau awaiting manual approval (${requestId})`, {
        sessionId,
        requestId,
        reason: validation.args.reason || 'No reason supplied',
      });
    } else {
      session.queue.push(requestId);
      this._recordActivity('tool_queued', `Queued ${toolName}`, { sessionId, requestId });
      this._wakePollWaiters(session);
    }

    // Set timeout handler
    reqRecord.timer = setTimeout(() => {
      this._timeoutRequest(session, reqRecord);
    }, effectiveTimeoutMs);
    if (reqRecord.timer.unref) {
      reqRecord.timer.unref();
    }

    if (!wait) {
      return {
        ok: true,
        accepted: true,
        requestId,
        sessionId,
        toolName,
        status: reqRecord.status,
        requiresApproval: needsApproval,
      };
    }

    return new Promise((resolve) => {
      reqRecord.resolveWaiter = resolve;
    });
  }

  _timeoutRequest(session, reqRecord) {
    if (
      reqRecord.status !== REQUEST_STATUS.QUEUED &&
      reqRecord.status !== REQUEST_STATUS.DISPATCHED &&
      reqRecord.status !== REQUEST_STATUS.PENDING_APPROVAL
    ) {
      return;
    }

    session.queue = session.queue.filter((id) => id !== reqRecord.requestId);
    session.inFlight.delete(reqRecord.requestId);
    session.pendingApproval.delete(reqRecord.requestId);

    reqRecord.status = REQUEST_STATUS.TIMED_OUT;
    reqRecord.completedAt = new Date().toISOString();
    reqRecord.error = {
      code: ERROR_CODES.REQUEST_TIMEOUT,
      message: `Tool "${reqRecord.toolName}" timed out after ${reqRecord.timeoutMs}ms waiting for ${reqRecord.dispatchedAt ? 'executor result' : 'dispatch/approval'}.`,
    };
    this.stats.totalTimedOut += 1;
    this.stats.totalFailed += 1;
    this._recordHistory(reqRecord);
    this._recordActivity('tool_timeout', `${reqRecord.toolName} timed out after ${reqRecord.timeoutMs}ms`, {
      sessionId: session.sessionId,
      requestId: reqRecord.requestId,
    });

    if (session.executor.connected) {
      session.controlSignals.push({
        type: 'CANCEL_REQUEST',
        requestId: reqRecord.requestId,
      });
      this._wakePollWaiters(session);
    }

    if (reqRecord.resolveWaiter) {
      reqRecord.resolveWaiter(this._formatRequestOutcome(reqRecord));
      reqRecord.resolveWaiter = null;
    }
  }

  _formatRequestOutcome(reqRecord) {
    const ok = reqRecord.status === REQUEST_STATUS.COMPLETED;
    return {
      ok,
      requestId: reqRecord.requestId,
      sessionId: reqRecord.sessionId,
      toolName: reqRecord.toolName,
      status: reqRecord.status,
      durationMs: reqRecord.durationMs,
      truncated: reqRecord.truncated,
      data: ok ? reqRecord.result : undefined,
      error: ok ? undefined : reqRecord.error,
    };
  }

  getRequestStatus(sessionId, requestId) {
    const session = this.sessions.get(sessionId);
    if (!session) {
      throw new BridgeError(404, ERROR_CODES.SESSION_NOT_FOUND, `Session "${sessionId}" not found.`);
    }
    const reqRecord = session.requests.get(requestId);
    if (!reqRecord) {
      throw new BridgeError(404, ERROR_CODES.INVALID_INPUT, `Request "${requestId}" not found in session "${sessionId}".`);
    }
    return {
      ok: reqRecord.status === REQUEST_STATUS.COMPLETED,
      requestId: reqRecord.requestId,
      sessionId: reqRecord.sessionId,
      toolName: reqRecord.toolName,
      status: reqRecord.status,
      createdAt: reqRecord.createdAt,
      dispatchedAt: reqRecord.dispatchedAt,
      completedAt: reqRecord.completedAt,
      durationMs: reqRecord.durationMs,
      truncated: reqRecord.truncated,
      data: reqRecord.status === REQUEST_STATUS.COMPLETED ? reqRecord.result : undefined,
      error: reqRecord.error || undefined,
    };
  }

  cancelRequest(sessionId, requestId, reason = 'Cancelled by caller') {
    const session = this.sessions.get(sessionId);
    if (!session) {
      throw new BridgeError(404, ERROR_CODES.SESSION_NOT_FOUND, `Session "${sessionId}" not found.`);
    }
    const reqRecord = session.requests.get(requestId);
    if (!reqRecord) {
      throw new BridgeError(404, ERROR_CODES.INVALID_INPUT, `Request "${requestId}" not found.`);
    }

    if (
      reqRecord.status === REQUEST_STATUS.COMPLETED ||
      reqRecord.status === REQUEST_STATUS.FAILED ||
      reqRecord.status === REQUEST_STATUS.CANCELLED ||
      reqRecord.status === REQUEST_STATUS.TIMED_OUT ||
      reqRecord.status === REQUEST_STATUS.REJECTED
    ) {
      return { ok: true, requestId, status: reqRecord.status, alreadyFinalized: true };
    }

    if (reqRecord.timer) {
      clearTimeout(reqRecord.timer);
      reqRecord.timer = null;
    }

    session.queue = session.queue.filter((id) => id !== requestId);
    session.inFlight.delete(requestId);
    session.pendingApproval.delete(requestId);

    reqRecord.status = REQUEST_STATUS.CANCELLED;
    reqRecord.completedAt = new Date().toISOString();
    reqRecord.error = { code: ERROR_CODES.REQUEST_CANCELLED, message: reason };
    this.stats.totalCancelled += 1;
    this.stats.totalFailed += 1;
    this._recordHistory(reqRecord);
    this._recordActivity('tool_cancelled', `${reqRecord.toolName} cancelled: ${reason}`, {
      sessionId,
      requestId,
    });

    if (session.executor.connected) {
      session.controlSignals.push({ type: 'CANCEL_REQUEST', requestId });
      this._wakePollWaiters(session);
    }

    if (reqRecord.resolveWaiter) {
      reqRecord.resolveWaiter(this._formatRequestOutcome(reqRecord));
      reqRecord.resolveWaiter = null;
    }

    return { ok: true, requestId, status: reqRecord.status };
  }

  approvePendingRequest(sessionId, requestId) {
    const session = this.sessions.get(sessionId);
    if (!session) throw new BridgeError(404, ERROR_CODES.SESSION_NOT_FOUND, 'Session not found.');
    const reqRecord = session.requests.get(requestId);
    if (!reqRecord || reqRecord.status !== REQUEST_STATUS.PENDING_APPROVAL) {
      throw new BridgeError(404, ERROR_CODES.INVALID_INPUT, 'Request is not awaiting approval.');
    }

    session.pendingApproval.delete(requestId);
    reqRecord.status = REQUEST_STATUS.QUEUED;
    session.queue.push(requestId);

    // Reset timeout window upon approval so user deliberation time doesn't immediately time out execution
    if (reqRecord.timer) clearTimeout(reqRecord.timer);
    reqRecord.timer = setTimeout(() => {
      this._timeoutRequest(session, reqRecord);
    }, reqRecord.timeoutMs);
    if (reqRecord.timer.unref) reqRecord.timer.unref();

    this._recordActivity('approval_granted', `Approved ExecuteLuau (${requestId})`, { sessionId, requestId });
    this._wakePollWaiters(session);
    return { ok: true, requestId, status: reqRecord.status };
  }

  rejectPendingRequest(sessionId, requestId, reason = 'Rejected in dashboard') {
    const session = this.sessions.get(sessionId);
    if (!session) throw new BridgeError(404, ERROR_CODES.SESSION_NOT_FOUND, 'Session not found.');
    const reqRecord = session.requests.get(requestId);
    if (!reqRecord || reqRecord.status !== REQUEST_STATUS.PENDING_APPROVAL) {
      throw new BridgeError(404, ERROR_CODES.INVALID_INPUT, 'Request is not awaiting approval.');
    }

    if (reqRecord.timer) clearTimeout(reqRecord.timer);
    session.pendingApproval.delete(requestId);
    reqRecord.status = REQUEST_STATUS.REJECTED;
    reqRecord.completedAt = new Date().toISOString();
    reqRecord.error = { code: ERROR_CODES.REQUEST_REJECTED, message: reason };
    this.stats.totalFailed += 1;
    this._recordHistory(reqRecord);
    this._recordActivity('approval_rejected', `Rejected ExecuteLuau (${requestId})`, { sessionId, requestId });

    if (reqRecord.resolveWaiter) {
      reqRecord.resolveWaiter(this._formatRequestOutcome(reqRecord));
      reqRecord.resolveWaiter = null;
    }
    return { ok: true, requestId, status: reqRecord.status };
  }

  disconnectExecutor(sessionId, reason = 'Executor disconnected') {
    const session = this.sessions.get(sessionId);
    if (!session) throw new BridgeError(404, ERROR_CODES.SESSION_NOT_FOUND, 'Session not found.');

    const wasConnected = session.executor.connected;
    session.executor.connected = false;
    session.controlSignals.push({ type: 'DISCONNECT', reason });
    this._flushPollWaiters(session);

    // Fail any queued/inFlight requests cleanly
    for (const reqId of [...session.queue, ...session.inFlight, ...session.pendingApproval]) {
      this.cancelRequest(sessionId, reqId, reason);
    }

    if (wasConnected) {
      this._recordActivity('executor_disconnect', reason, { sessionId });
    }
    return { ok: true, sessionId, executorConnected: false };
  }

  disconnectAi(sessionId, reason = 'AI client disconnected') {
    const session = this.sessions.get(sessionId);
    if (!session) throw new BridgeError(404, ERROR_CODES.SESSION_NOT_FOUND, 'Session not found.');
    const wasConnected = session.ai.connected;
    session.ai.connected = false;
    if (wasConnected) {
      this._recordActivity('ai_disconnect', reason, { sessionId });
    }
    return { ok: true, sessionId, aiConnected: false };
  }

  endSession(sessionId, reason = 'Session ended') {
    const session = this.sessions.get(sessionId);
    if (!session) throw new BridgeError(404, ERROR_CODES.SESSION_NOT_FOUND, 'Session not found.');
    this.disconnectExecutor(sessionId, reason);
    this.disconnectAi(sessionId, reason);
    this.sessions.delete(sessionId);
    this._recordActivity('session_ended', `Session ${sessionId} ended`, { sessionId, reason });
    return { ok: true, sessionId, ended: true };
  }

  emergencyStop(sessionId = null) {
    const targetSessions = sessionId
      ? [this.sessions.get(sessionId)].filter(Boolean)
      : Array.from(this.sessions.values());

    let cancelledCount = 0;
    for (const session of targetSessions) {
      for (const reqId of [...session.queue, ...session.inFlight, ...session.pendingApproval]) {
        this.cancelRequest(session.sessionId, reqId, 'Emergency stop triggered');
        cancelledCount += 1;
      }
      if (session.executor.connected) {
        session.controlSignals.push({
          type: 'EMERGENCY_STOP',
          ts: new Date().toISOString(),
        });
        this._wakePollWaiters(session);
      }
    }

    this._recordActivity('emergency_stop', `Emergency stop triggered (${cancelledCount} active requests cancelled)`, {
      sessionId: sessionId || 'ALL',
      cancelledCount,
    });

    return { ok: true, cancelledCount };
  }

  clearHistory() {
    this.activityFeed = [];
    this.executionHistory = [];
    this.connectionErrors = [];
    this._recordActivity('history_cleared', 'Activity and execution history cleared from dashboard', {});
    return { ok: true };
  }

  updatePolicy({ executeLuauEnabled, executeLuauRequireApproval }) {
    if (typeof executeLuauEnabled === 'boolean') {
      this.policy.executeLuauEnabled = executeLuauEnabled;
    }
    if (typeof executeLuauRequireApproval === 'boolean') {
      this.policy.executeLuauRequireApproval = executeLuauRequireApproval;
    }
    this._recordActivity('policy_updated', 'ExecuteLuau policy updated', { ...this.policy });
    return { ok: true, policy: { ...this.policy } };
  }

  _checkHeartbeats() {
    const now = Date.now();
    for (const session of this.sessions.values()) {
      if (
        session.executor.connected &&
        session.executor.lastHeartbeatAt &&
        now - session.executor.lastHeartbeatAt > this.config.executorHeartbeatTimeoutMs
      ) {
        const msg = `Executor heartbeat timed out after ${this.config.executorHeartbeatTimeoutMs}ms`;
        this._recordConnectionError('heartbeat', ERROR_CODES.EXECUTOR_OFFLINE, msg, session.sessionId);
        this.disconnectExecutor(session.sessionId, msg);
      }
    }
  }

  _pruneSessionRequests(session) {
    if (session.requests.size <= 300) return;
    for (const [id, rec] of session.requests.entries()) {
      if (
        rec.status !== REQUEST_STATUS.QUEUED &&
        rec.status !== REQUEST_STATUS.DISPATCHED &&
        rec.status !== REQUEST_STATUS.PENDING_APPROVAL
      ) {
        session.requests.delete(id);
      }
      if (session.requests.size <= 200) break;
    }
  }

  getDashboardState() {
    const now = Date.now();
    const sessionsList = [];
    const pendingRequests = [];
    const pendingApprovals = [];

    for (const session of this.sessions.values()) {
      const hbAgeMs = session.executor.lastHeartbeatAt
        ? Math.max(0, now - session.executor.lastHeartbeatAt)
        : null;

      sessionsList.push({
        sessionId: session.sessionId,
        createdAt: session.createdAt,
        executor: {
          connected: session.executor.connected,
          executorId: session.executor.executorId,
          executorName: session.executor.executorName,
          placeId: session.executor.placeId,
          jobId: session.executor.jobId,
          gameName: session.executor.gameName,
          playerName: session.executor.playerName,
          capabilities: session.executor.capabilities,
          registeredAt: session.executor.registeredAt,
          heartbeatAgeMs: hbAgeMs,
        },
        ai: {
          connected: session.ai.connected,
          aiClientId: session.ai.aiClientId,
          clientName: session.ai.clientName,
          registeredAt: session.ai.registeredAt,
        },
        counts: {
          queued: session.queue.length,
          inFlight: session.inFlight.size,
          pendingApproval: session.pendingApproval.size,
        },
      });

      for (const reqId of [...session.queue, ...session.inFlight]) {
        const rec = session.requests.get(reqId);
        if (rec) {
          pendingRequests.push({
            requestId: rec.requestId,
            sessionId: rec.sessionId,
            toolName: rec.toolName,
            status: rec.status,
            createdAt: rec.createdAt,
            argsPreview: this._previewArgs(rec.toolName, rec.args),
          });
        }
      }

      for (const reqId of session.pendingApproval) {
        const rec = session.requests.get(reqId);
        if (rec) {
          pendingApprovals.push({
            requestId: rec.requestId,
            sessionId: rec.sessionId,
            toolName: rec.toolName,
            createdAt: rec.createdAt,
            code: rec.args.code,
            reason: rec.args.reason || null,
            timeoutMs: rec.args.timeoutMs || 5000,
          });
        }
      }
    }

    return {
      server: {
        status: 'online',
        startedAt: this.stats.serverStartedAt,
        uptimeSeconds: Math.floor(process.uptime()),
        port: this.config.port,
        tlsEnabled: this.config.tlsEnabled,
        allowedPlaceIds: this.config.allowedPlaceIdsRaw,
      },
      policy: { ...this.policy },
      stats: {
        activeSessions: sessionsList.length,
        pendingCount: pendingRequests.length,
        approvalCount: pendingApprovals.length,
        completedCount: this.stats.totalCompleted,
        failedCount: this.stats.totalFailed,
        timedOutCount: this.stats.totalTimedOut,
        cancelledCount: this.stats.totalCancelled,
      },
      sessions: sessionsList,
      pendingRequests,
      pendingApprovals,
      recentActivity: this.activityFeed.slice(0, 80),
      executionHistory: this.executionHistory.slice(0, 80),
      connectionErrors: this.connectionErrors.slice(0, 30),
      tools: this.toolRegistry.listTools().map((t) => ({
        name: t.name,
        category: t.category,
        description: t.description,
        requiresApprovalPolicy: t.requiresApprovalPolicy,
      })),
    };
  }
}

module.exports = {
  SessionManager,
  BridgeError,
};
