'use strict';

const {
  TOOL_DEFINITIONS,
  getToolDefinition,
  toOpenAITools,
  toMcpTools,
} = require('../../shared/toolDefinitions');
const { ERROR_CODES } = require('../../shared/constants');

class ToolRegistry {
  constructor(config) {
    this.config = config;
  }

  listTools() {
    return TOOL_DEFINITIONS.map((tool) => ({
      name: tool.name,
      category: tool.category,
      description: tool.description,
      requiresApprovalPolicy: tool.requiresApprovalPolicy,
      parameters: tool.jsonSchema,
    }));
  }

  getOpenAITools() {
    return toOpenAITools();
  }

  getMcpTools() {
    return toMcpTools();
  }

  getTool(name) {
    return getToolDefinition(name);
  }

  validateToolCall(toolName, rawArgs) {
    const def = getToolDefinition(toolName);
    if (!def) {
      return {
        ok: false,
        code: ERROR_CODES.UNKNOWN_TOOL,
        message: `Unknown tool "${toolName}". Call GET /api/v1/ai/tools to inspect available tools.`,
      };
    }

    const argsObj = rawArgs === undefined || rawArgs === null ? {} : rawArgs;
    if (typeof argsObj !== 'object' || Array.isArray(argsObj)) {
      return {
        ok: false,
        code: ERROR_CODES.INVALID_INPUT,
        message: 'Tool arguments must be a JSON object.',
      };
    }

    const parsed = def.zodSchema.safeParse(argsObj);
    if (!parsed.success) {
      return {
        ok: false,
        code: ERROR_CODES.INVALID_INPUT,
        message: `Invalid arguments for tool "${toolName}".`,
        details: parsed.error.issues.map((issue) => ({
          path: issue.path.join('.') || '(root)',
          message: issue.message,
        })),
      };
    }

    // Extra runtime bounds for ExecuteLuau from config
    if (toolName === 'ExecuteLuau') {
      const codeBytes = Buffer.byteLength(parsed.data.code, 'utf8');
      if (codeBytes > this.config.executeLuauMaxCodeBytes) {
        return {
          ok: false,
          code: ERROR_CODES.PAYLOAD_TOO_LARGE,
          message: `ExecuteLuau code exceeds maximum size of ${this.config.executeLuauMaxCodeBytes} bytes.`,
        };
      }
      if (parsed.data.timeoutMs && parsed.data.timeoutMs > this.config.executeLuauMaxTimeoutMs) {
        return {
          ok: false,
          code: ERROR_CODES.INVALID_INPUT,
          message: `ExecuteLuau timeoutMs cannot exceed ${this.config.executeLuauMaxTimeoutMs} ms.`,
        };
      }
    }

    return {
      ok: true,
      tool: def,
      args: parsed.data,
    };
  }
}

module.exports = {
  ToolRegistry,
};
