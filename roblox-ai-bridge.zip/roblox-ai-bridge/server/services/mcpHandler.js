'use strict';

const { SERVICE_NAME, SERVICE_VERSION } = require('../../shared/constants');

function createMcpHandler({ sessionManager, toolRegistry, logger }) {
  function jsonRpcResult(id, result) {
    return {
      jsonrpc: '2.0',
      id: id ?? null,
      result,
    };
  }

  function jsonRpcError(id, code, message, data = undefined) {
    const err = { code, message };
    if (data !== undefined) err.data = data;
    return {
      jsonrpc: '2.0',
      id: id ?? null,
      error: err,
    };
  }

  function resolveMcpSessionId(req, params) {
    const explicit =
      req.get('x-session-id') ||
      params?._meta?.sessionId ||
      params?.arguments?._sessionId ||
      null;
    if (explicit) return explicit;

    // Look for an active session with AI or Executor connected
    for (const s of sessionManager.sessions.values()) {
      if (s.executor.connected && s.ai.connected) return s.sessionId;
    }
    // Auto-register MCP as AI on an active executor session if available
    for (const s of sessionManager.sessions.values()) {
      if (s.executor.connected) {
        const reg = sessionManager.registerAi({ sessionId: s.sessionId, clientName: 'MCPClient' });
        return reg.sessionId;
      }
    }
    return null;
  }

  async function handleRpc(req, body) {
    if (!body || typeof body !== 'object' || body.jsonrpc !== '2.0' || typeof body.method !== 'string') {
      return {
        status: 400,
        payload: jsonRpcError(body?.id, -32600, 'Invalid JSON-RPC 2.0 request.'),
      };
    }

    const { id, method, params = {} } = body;

    if (method === 'notifications/initialized') {
      return { status: 204, payload: null };
    }

    if (method === 'ping') {
      return { status: 200, payload: jsonRpcResult(id, {}) };
    }

    if (method === 'initialize') {
      return {
        status: 200,
        payload: jsonRpcResult(id, {
          protocolVersion: '2024-11-05',
          capabilities: {
            tools: { listChanged: false },
          },
          serverInfo: {
            name: SERVICE_NAME,
            version: SERVICE_VERSION,
          },
        }),
      };
    }

    if (method === 'tools/list') {
      return {
        status: 200,
        payload: jsonRpcResult(id, {
          tools: toolRegistry.getMcpTools(),
        }),
      };
    }

    if (method === 'tools/call') {
      const toolName = params.name;
      const rawArgs = { ...(params.arguments || {}) };
      delete rawArgs._sessionId;

      if (!toolName || typeof toolName !== 'string') {
        return {
          status: 400,
          payload: jsonRpcError(id, -32602, 'params.name is required.'),
        };
      }

      const sessionId = resolveMcpSessionId(req, params);
      if (!sessionId) {
        return {
          status: 200,
          payload: jsonRpcResult(id, {
            isError: true,
            content: [
              {
                type: 'text',
                text: JSON.stringify({
                  ok: false,
                  error: {
                    code: 'EXECUTOR_OFFLINE',
                    message: 'No active Roblox executor session is currently connected.',
                  },
                }),
              },
            ],
          }),
        };
      }

      try {
        const outcome = await sessionManager.enqueueToolCall({
          sessionId,
          toolName,
          args: rawArgs,
          wait: true,
        });

        return {
          status: 200,
          payload: jsonRpcResult(id, {
            isError: !outcome.ok,
            content: [
              {
                type: 'text',
                text: JSON.stringify(outcome, null, 2),
              },
            ],
          }),
        };
      } catch (err) {
        logger.warn('MCP tool call failed', { toolName, error: err.message });
        return {
          status: 200,
          payload: jsonRpcResult(id, {
            isError: true,
            content: [
              {
                type: 'text',
                text: JSON.stringify({
                  ok: false,
                  error: {
                    code: err.code || 'INTERNAL_ERROR',
                    message: err.message,
                    details: err.details,
                  },
                }),
              },
            ],
          }),
        };
      }
    }

    return {
      status: 404,
      payload: jsonRpcError(id, -32601, `Method "${method}" not found.`),
    };
  }

  return { handleRpc };
}

module.exports = {
  createMcpHandler,
};
