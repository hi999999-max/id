'use strict';

const fs = require('fs');
const http = require('http');
const https = require('https');
const { loadConfig, validateConfigSecurity } = require('./config');
const { createApp } = require('./app');

function startServer(overrides = {}) {
  const config = loadConfig(overrides);
  const securityErrors = validateConfigSecurity(config);

  if (securityErrors.length > 0) {
    console.error('[FATAL] Configuration security check failed:');
    for (const msg of securityErrors) {
      console.error(`  - ${msg}`);
    }
    if (!overrides.returnOnError) {
      process.exit(1);
    }
    throw new Error(securityErrors.join(' '));
  }

  const { app, logger, sessionManager } = createApp(config);

  let server;
  if (config.tlsEnabled) {
    const tlsOptions = {
      cert: fs.readFileSync(config.tlsCertPath),
      key: fs.readFileSync(config.tlsKeyPath),
    };
    server = https.createServer(tlsOptions, app);
  } else {
    server = http.createServer(app);
  }

  server.requestTimeout = Math.max(config.maxToolTimeoutMs + 10000, 70000);
  server.headersTimeout = 30000;

  return new Promise((resolve, reject) => {
    server.on('error', (err) => {
      logger.error('Server failed to start', { error: err });
      reject(err);
    });

    server.listen(config.port, config.host, () => {
      const address = server.address();
      const protocol = config.tlsEnabled ? 'https' : 'http';
      logger.info('Roblox AI Bridge server started', {
        protocol,
        host: config.host,
        port: address && typeof address === 'object' ? address.port : config.port,
        tlsEnabled: config.tlsEnabled,
        nodeEnv: config.nodeEnv,
      });

      const shutdown = (signal) => {
        logger.info(`Received ${signal}, shutting down cleanly...`);
        sessionManager.shutdown();
        server.close(() => {
          logger.info('HTTP server closed.');
          process.exit(0);
        });
        setTimeout(() => process.exit(1), 5000).unref();
      };

      if (!overrides.skipSignalHandlers) {
        process.on('SIGINT', () => shutdown('SIGINT'));
        process.on('SIGTERM', () => shutdown('SIGTERM'));
      }

      resolve({
        server,
        app,
        config,
        logger,
        sessionManager,
        port: address && typeof address === 'object' ? address.port : config.port,
      });
    });
  });
}

if (require.main === module) {
  startServer().catch((err) => {
    console.error('Startup error:', err.message);
    process.exit(1);
  });
}

module.exports = {
  startServer,
};
