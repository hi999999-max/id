'use strict';

const { ERROR_CODES } = require('../../shared/constants');

function validateBody(zodSchema) {
  return (req, res, next) => {
    const result = zodSchema.safeParse(req.body ?? {});
    if (!result.success) {
      return res.status(400).json({
        ok: false,
        error: {
          code: ERROR_CODES.INVALID_INPUT,
          message: 'Request body validation failed.',
          details: result.error.issues.map((issue) => ({
            path: issue.path.join('.') || '(root)',
            message: issue.message,
          })),
        },
      });
    }
    req.validatedBody = result.data;
    return next();
  };
}

module.exports = {
  validateBody,
};
