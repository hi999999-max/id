'use strict';

const { ERROR_CODES } = require('../../shared/constants');

function createReplayGuard(config, logger) {
  // Map<nonceKey, expiresAtMs>
  const seenNonces = new Map();
  const MAX_NONCE_CACHE = 10000;

  function pruneExpired(now) {
    if (seenNonces.size === 0) return;
    for (const [key, exp] of seenNonces.entries()) {
      if (exp <= now) {
        seenNonces.delete(key);
      } else {
        break;
      }
    }
    while (seenNonces.size > MAX_NONCE_CACHE) {
      const oldest = seenNonces.keys().next().value;
      if (oldest === undefined) break;
      seenNonces.delete(oldest);
    }
  }

  return (req, res, next) => {
    const rawTs = req.get('x-request-timestamp');
    const rawNonce = req.get('x-request-nonce');

    const hasHeaders = Boolean(rawTs || rawNonce);
    if (!config.requireReplayHeaders && !hasHeaders) {
      return next();
    }

    if (!rawTs || !rawNonce) {
      return res.status(400).json({
        ok: false,
        error: {
          code: ERROR_CODES.REPLAY_DETECTED,
          message: 'Both X-Request-Timestamp and X-Request-Nonce headers are required when replay headers are used.',
        },
      });
    }

    const tsNum = Number(rawTs);
    const now = Date.now();
    // Accept epoch seconds or epoch milliseconds cleanly
    const tsMs = tsNum < 1e12 ? tsNum * 1000 : tsNum;

    if (!Number.isFinite(tsMs) || Math.abs(now - tsMs) > config.replayWindowMs) {
      logger.warn('Replay guard rejected stale timestamp', { path: req.originalUrl, ip: req.ip });
      return res.status(401).json({
        ok: false,
        error: {
          code: ERROR_CODES.REPLAY_DETECTED,
          message: 'Request timestamp is missing or outside the allowed replay window.',
        },
      });
    }

    const nonce = String(rawNonce).trim();
    if (nonce.length < 8 || nonce.length > 128) {
      return res.status(400).json({
        ok: false,
        error: {
          code: ERROR_CODES.REPLAY_DETECTED,
          message: 'X-Request-Nonce must be between 8 and 128 characters.',
        },
      });
    }

    pruneExpired(now);

    const scopedNonce = `${req.authRole || 'anon'}:${nonce}`;
    if (seenNonces.has(scopedNonce)) {
      logger.warn('Replay guard blocked duplicate nonce', { path: req.originalUrl, ip: req.ip });
      return res.status(409).json({
        ok: false,
        error: {
          code: ERROR_CODES.REPLAY_DETECTED,
          message: 'Duplicate request nonce detected (replay rejected).',
        },
      });
    }

    seenNonces.set(scopedNonce, now + config.replayWindowMs);
    return next();
  };
}

module.exports = {
  createReplayGuard,
};
