'use strict';

const rateLimit = require('express-rate-limit');
const { ERROR_CODES } = require('../../shared/constants');

function makeLimiter({ windowMs, max, message, skipInTest = true }) {
  return rateLimit({
    windowMs,
    max,
    standardHeaders: true,
    legacyHeaders: false,
    skip: () => skipInTest && process.env.NODE_ENV === 'test',
    handler: (req, res) => {
      res.status(429).json({
        ok: false,
        error: {
          code: ERROR_CODES.RATE_LIMITED,
          message,
        },
      });
    },
  });
}

function createRateLimiters() {
  return {
    // High-frequency polling & heartbeats from Roblox executor
    executorPolling: makeLimiter({
      windowMs: 60 * 1000,
      max: 300,
      message: 'Too many executor polling/heartbeat requests. Slow down polling interval.',
    }),

    // AI tool calls & registration
    aiCalls: makeLimiter({
      windowMs: 60 * 1000,
      max: 180,
      message: 'Too many AI API requests per minute.',
    }),

    // Auth / connect / dashboard login (stricter against brute force)
    authActions: makeLimiter({
      windowMs: 60 * 1000,
      max: 30,
      message: 'Too many authentication attempts. Please wait a minute.',
    }),

    // General API fallback
    generalApi: makeLimiter({
      windowMs: 60 * 1000,
      max: 240,
      message: 'Rate limit exceeded.',
    }),
  };
}

module.exports = {
  createRateLimiters,
};
