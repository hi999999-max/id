'use strict';

const express = require('express');
const { z } = require('zod');
const { ROLES } = require('../../shared/constants');
const { validateBody } = require('../middleware/validate');

const AiRegisterSchema = z.object({
  sessionId: z.string().min(4).max(128).optional(),
  clientName: z.string().min(1).max(100).optional(),
}).strict();

const AiToolCallSchema = z.object({
  sessionId: z.string().min(4).max(128),
  toolName: z.string().min(1).max(100),
  args: z.record(z.any()).optional(),
  requestId: z.string().min(4).max(128).optional(),
  idempotencyKey: z.string().min(4).max(128).optional(),
  timeoutMs: z.number().int().min(500).max(120000).optional(),
  wait: z.boolean().optional(),
}).strict();

const CancelSchema = z.object({
  sessionId: z.string().min(4).max(128),
  reason: z.string().max(240).optional(),
}).strict();

function createAiRouter({ auth, sessionManager, toolRegistry, rateLimiters, replayGuard }) {
  const router = express.Router();

  router.get(
    '/api/v1/ai/tools',
    rateLimiters.aiCalls,
    auth.requireRole(ROLES.AI, ROLES.DASHBOARD),
    (req, res) => {
      const format = req.query.format;
      const tools = toolRegistry.listTools();
      const response = {
        ok: true,
        toolCount: tools.length,
        tools,
      };
      if (format === 'openai' || format === 'all') {
        response.openaiTools = toolRegistry.getOpenAITools();
      }
      if (format === 'mcp' || format === 'all') {
        response.mcpTools = toolRegistry.getMcpTools();
      }
      res.json(response);
    }
  );

  router.post(
    '/api/v1/ai/register',
    rateLimiters.authActions,
    auth.requireRole(ROLES.AI),
    replayGuard,
    validateBody(AiRegisterSchema),
    (req, res, next) => {
      try {
        const result = sessionManager.registerAi(req.validatedBody);
        res.json({ ok: true, ...result });
      } catch (err) {
        next(err);
      }
    }
  );

  router.post(
    '/api/v1/ai/tool-call',
    rateLimiters.aiCalls,
    auth.requireRole(ROLES.AI),
    replayGuard,
    validateBody(AiToolCallSchema),
    async (req, res, next) => {
      try {
        const outcome = await sessionManager.enqueueToolCall(req.validatedBody);
        res.json(outcome);
      } catch (err) {
        next(err);
      }
    }
  );

  router.get(
    '/api/v1/ai/requests/:requestId',
    rateLimiters.aiCalls,
    auth.requireRole(ROLES.AI),
    (req, res, next) => {
      try {
        const sessionId = req.query.sessionId || req.get('x-session-id');
        if (!sessionId) {
          return res.status(400).json({
            ok: false,
            error: {
              code: 'INVALID_INPUT',
              message: 'sessionId query parameter or X-Session-Id header is required.',
            },
          });
        }
        const status = sessionManager.getRequestStatus(String(sessionId), req.params.requestId);
        return res.json(status);
      } catch (err) {
        return next(err);
      }
    }
  );

  router.post(
    '/api/v1/ai/requests/:requestId/cancel',
    rateLimiters.aiCalls,
    auth.requireRole(ROLES.AI),
    replayGuard,
    validateBody(CancelSchema),
    (req, res, next) => {
      try {
        const result = sessionManager.cancelRequest(
          req.validatedBody.sessionId,
          req.params.requestId,
          req.validatedBody.reason || 'Cancelled by AI client'
        );
        res.json(result);
      } catch (err) {
        next(err);
      }
    }
  );

  return router;
}

module.exports = {
  createAiRouter,
};
