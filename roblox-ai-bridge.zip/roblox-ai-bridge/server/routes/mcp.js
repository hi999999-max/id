'use strict';

const express = require('express');
const { ROLES } = require('../../shared/constants');

function createMcpRouter({ auth, mcpHandler, rateLimiters }) {
  const router = express.Router();

  router.post(
    '/mcp',
    rateLimiters.aiCalls,
    auth.requireRole(ROLES.AI),
    async (req, res, next) => {
      try {
        const result = await mcpHandler.handleRpc(req, req.body);
        if (result.status === 204) {
          return res.status(204).end();
        }
        return res.status(result.status).json(result.payload);
      } catch (err) {
        return next(err);
      }
    }
  );

  return router;
}

module.exports = {
  createMcpRouter,
};
