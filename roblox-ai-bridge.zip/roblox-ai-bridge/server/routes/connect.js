'use strict';

const express = require('express');
const { z } = require('zod');
const { ROLES, ERROR_CODES } = require('../../shared/constants');
const { validateBody } = require('../middleware/validate');

const ConnectSchema = z.object({
  role: z.enum([ROLES.AI, ROLES.EXECUTOR]),
  sessionId: z.string().min(4).max(128).optional(),
  clientName: z.string().min(1).max(100).optional(),
  executorName: z.string().min(1).max(100).optional(),
  placeId: z.number().int().nonnegative().optional(),
  jobId: z.string().max(128).optional(),
  gameName: z.string().max(200).optional(),
  playerName: z.string().max(100).optional(),
  playerUserId: z.number().int().nonnegative().optional(),
  capabilities: z.record(z.any()).optional(),
}).strict();

function createConnectRouter({ auth, sessionManager, rateLimiters, replayGuard }) {
  const router = express.Router();

  router.post(
    '/api/v1/connect',
    rateLimiters.authActions,
    auth.requireRole(ROLES.AI, ROLES.EXECUTOR),
    replayGuard,
    validateBody(ConnectSchema),
    (req, res, next) => {
      try {
        const body = req.validatedBody;
        if (body.role !== req.authRole) {
          return res.status(403).json({
            ok: false,
            error: {
              code: ERROR_CODES.FORBIDDEN,
              message: `Credential role (${req.authRole}) does not match requested role (${body.role}).`,
            },
          });
        }

        if (body.role === ROLES.EXECUTOR) {
          if (body.placeId === undefined) {
            return res.status(400).json({
              ok: false,
              error: {
                code: ERROR_CODES.INVALID_INPUT,
                message: 'placeId is required when connecting as executor.',
              },
            });
          }
          const result = sessionManager.registerExecutor(body);
          return res.json({ ok: true, role: ROLES.EXECUTOR, ...result });
        }

        const result = sessionManager.registerAi(body);
        return res.json({ ok: true, role: ROLES.AI, ...result });
      } catch (err) {
        return next(err);
      }
    }
  );

  return router;
}

module.exports = {
  createConnectRouter,
};
