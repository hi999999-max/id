'use strict';

const express = require('express');
const { z } = require('zod');
const { ROLES } = require('../../shared/constants');
const { validateBody } = require('../middleware/validate');

const DisconnectSchema = z.object({
  sessionId: z.string().min(4).max(128),
  target: z.enum(['self', 'executor', 'ai', 'session']).optional(),
  reason: z.string().max(240).optional(),
}).strict();

function createSessionRouter({ auth, sessionManager, rateLimiters, replayGuard }) {
  const router = express.Router();

  router.post(
    '/api/v1/session/disconnect',
    rateLimiters.generalApi,
    auth.requireRole(ROLES.AI, ROLES.EXECUTOR, ROLES.DASHBOARD),
    replayGuard,
    validateBody(DisconnectSchema),
    (req, res, next) => {
      try {
        const { sessionId, target = 'self', reason } = req.validatedBody;
        const effectiveTarget = target === 'self'
          ? (req.authRole === ROLES.EXECUTOR ? 'executor' : req.authRole === ROLES.AI ? 'ai' : 'session')
          : target;

        if (effectiveTarget === 'executor') {
          return res.json(sessionManager.disconnectExecutor(sessionId, reason || 'Disconnected by client'));
        }
        if (effectiveTarget === 'ai') {
          return res.json(sessionManager.disconnectAi(sessionId, reason || 'Disconnected by client'));
        }
        return res.json(sessionManager.endSession(sessionId, reason || 'Session ended by client'));
      } catch (err) {
        return next(err);
      }
    }
  );

  return router;
}

module.exports = {
  createSessionRouter,
};
