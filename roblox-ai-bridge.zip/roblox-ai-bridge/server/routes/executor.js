'use strict';

const express = require('express');
const { z } = require('zod');
const { ROLES } = require('../../shared/constants');
const { validateBody } = require('../middleware/validate');

const ExecutorRegisterSchema = z.object({
  sessionId: z.string().min(4).max(128).optional(),
  executorName: z.string().min(1).max(100).optional(),
  placeId: z.number().int().nonnegative(),
  jobId: z.string().max(128).optional(),
  gameName: z.string().max(200).optional(),
  playerName: z.string().max(100).optional(),
  playerUserId: z.number().int().nonnegative().optional(),
  capabilities: z.record(z.any()).optional(),
}).strict();

const ExecutorHeartbeatSchema = z.object({
  sessionId: z.string().min(4).max(128),
  executorId: z.string().min(4).max(128).optional(),
  placeId: z.number().int().nonnegative().optional(),
  jobId: z.string().max(128).optional(),
  gameName: z.string().max(200).optional(),
  capabilities: z.record(z.any()).optional(),
}).strict();

const ExecutorPollSchema = z.object({
  sessionId: z.string().min(4).max(128),
  executorId: z.string().min(4).max(128).optional(),
  waitMs: z.number().int().min(0).max(25000).optional(),
  maxTasks: z.number().int().min(1).max(10).optional(),
}).strict();

const ExecutorResultSchema = z.object({
  sessionId: z.string().min(4).max(128),
  executorId: z.string().min(4).max(128).optional(),
  requestId: z.string().min(4).max(128),
  ok: z.boolean(),
  data: z.any().optional(),
  error: z.any().optional(),
  durationMs: z.number().min(0).max(600000).optional(),
  truncated: z.boolean().optional(),
}).strict();

function createExecutorRouter({ auth, sessionManager, rateLimiters, replayGuard }) {
  const router = express.Router();

  router.post(
    '/api/v1/executor/register',
    rateLimiters.authActions,
    auth.requireRole(ROLES.EXECUTOR),
    replayGuard,
    validateBody(ExecutorRegisterSchema),
    (req, res, next) => {
      try {
        const result = sessionManager.registerExecutor(req.validatedBody);
        res.json({ ok: true, ...result });
      } catch (err) {
        next(err);
      }
    }
  );

  router.post(
    '/api/v1/executor/heartbeat',
    rateLimiters.executorPolling,
    auth.requireRole(ROLES.EXECUTOR),
    replayGuard,
    validateBody(ExecutorHeartbeatSchema),
    (req, res, next) => {
      try {
        const result = sessionManager.executorHeartbeat(req.validatedBody);
        res.json(result);
      } catch (err) {
        next(err);
      }
    }
  );

  router.post(
    '/api/v1/executor/poll',
    rateLimiters.executorPolling,
    auth.requireRole(ROLES.EXECUTOR),
    replayGuard,
    validateBody(ExecutorPollSchema),
    async (req, res, next) => {
      try {
        const result = await sessionManager.pollExecutor(req.validatedBody);
        res.json({ ok: true, ...result });
      } catch (err) {
        next(err);
      }
    }
  );

  router.post(
    '/api/v1/executor/result',
    rateLimiters.executorPolling,
    auth.requireRole(ROLES.EXECUTOR),
    replayGuard,
    validateBody(ExecutorResultSchema),
    (req, res, next) => {
      try {
        const result = sessionManager.submitExecutorResult(req.validatedBody);
        res.json(result);
      } catch (err) {
        next(err);
      }
    }
  );

  return router;
}

module.exports = {
  createExecutorRouter,
};
