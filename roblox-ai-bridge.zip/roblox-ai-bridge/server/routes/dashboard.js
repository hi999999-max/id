'use strict';

const express = require('express');
const { z } = require('zod');
const { ROLES, ERROR_CODES } = require('../../shared/constants');
const { validateBody } = require('../middleware/validate');

const LoginSchema = z.object({
  token: z.string().min(1).max(512),
}).strict();

const SessionActionSchema = z.object({
  sessionId: z.string().min(4).max(128),
}).strict();

const RequestActionSchema = z.object({
  sessionId: z.string().min(4).max(128),
  requestId: z.string().min(4).max(128),
  reason: z.string().max(240).optional(),
}).strict();

const TogglePolicySchema = z.object({
  executeLuauEnabled: z.boolean().optional(),
  executeLuauRequireApproval: z.boolean().optional(),
}).strict();

const EmergencyStopSchema = z.object({
  sessionId: z.string().min(4).max(128).optional(),
}).strict();

function createDashboardRouter({ auth, config, sessionManager, rateLimiters }) {
  const router = express.Router();

  router.post(
    '/api/v1/dashboard/login',
    rateLimiters.authActions,
    validateBody(LoginSchema),
    (req, res) => {
      const valid = auth.timingSafeMatch(req.validatedBody.token.trim(), config.dashboardAdminToken);
      if (!valid) {
        return res.status(401).json({
          ok: false,
          error: {
            code: ERROR_CODES.UNAUTHORIZED,
            message: 'Invalid dashboard admin token.',
          },
        });
      }

      res.cookie('rb_dashboard_session', config.dashboardAdminToken, {
        httpOnly: true,
        sameSite: 'strict',
        secure: config.tlsEnabled,
        maxAge: 12 * 60 * 60 * 1000,
        path: '/',
      });

      return res.json({ ok: true, authenticated: true });
    }
  );

  router.post('/api/v1/dashboard/logout', (req, res) => {
    res.clearCookie('rb_dashboard_session', { path: '/' });
    res.json({ ok: true, authenticated: false });
  });

  router.get(
    '/api/v1/dashboard/state',
    rateLimiters.generalApi,
    auth.requireRole(ROLES.DASHBOARD),
    (req, res) => {
      res.json({ ok: true, ...sessionManager.getDashboardState() });
    }
  );

  router.post(
    '/api/v1/dashboard/actions/disconnect-executor',
    rateLimiters.generalApi,
    auth.requireRole(ROLES.DASHBOARD),
    validateBody(SessionActionSchema),
    (req, res, next) => {
      try {
        res.json(sessionManager.disconnectExecutor(req.validatedBody.sessionId, 'Disconnected from dashboard'));
      } catch (err) {
        next(err);
      }
    }
  );

  router.post(
    '/api/v1/dashboard/actions/disconnect-ai',
    rateLimiters.generalApi,
    auth.requireRole(ROLES.DASHBOARD),
    validateBody(SessionActionSchema),
    (req, res, next) => {
      try {
        res.json(sessionManager.disconnectAi(req.validatedBody.sessionId, 'Disconnected from dashboard'));
      } catch (err) {
        next(err);
      }
    }
  );

  router.post(
    '/api/v1/dashboard/actions/end-session',
    rateLimiters.generalApi,
    auth.requireRole(ROLES.DASHBOARD),
    validateBody(SessionActionSchema),
    (req, res, next) => {
      try {
        res.json(sessionManager.endSession(req.validatedBody.sessionId, 'Ended from dashboard'));
      } catch (err) {
        next(err);
      }
    }
  );

  router.post(
    '/api/v1/dashboard/actions/clear-history',
    rateLimiters.generalApi,
    auth.requireRole(ROLES.DASHBOARD),
    (req, res) => {
      res.json(sessionManager.clearHistory());
    }
  );

  router.post(
    '/api/v1/dashboard/actions/toggle-execute-luau',
    rateLimiters.generalApi,
    auth.requireRole(ROLES.DASHBOARD),
    validateBody(TogglePolicySchema),
    (req, res) => {
      res.json(sessionManager.updatePolicy(req.validatedBody));
    }
  );

  router.post(
    '/api/v1/dashboard/actions/approve-request',
    rateLimiters.generalApi,
    auth.requireRole(ROLES.DASHBOARD),
    validateBody(RequestActionSchema),
    (req, res, next) => {
      try {
        res.json(sessionManager.approvePendingRequest(req.validatedBody.sessionId, req.validatedBody.requestId));
      } catch (err) {
        next(err);
      }
    }
  );

  router.post(
    '/api/v1/dashboard/actions/reject-request',
    rateLimiters.generalApi,
    auth.requireRole(ROLES.DASHBOARD),
    validateBody(RequestActionSchema),
    (req, res, next) => {
      try {
        res.json(
          sessionManager.rejectPendingRequest(
            req.validatedBody.sessionId,
            req.validatedBody.requestId,
            req.validatedBody.reason || 'Rejected from dashboard'
          )
        );
      } catch (err) {
        next(err);
      }
    }
  );

  router.post(
    '/api/v1/dashboard/actions/emergency-stop',
    rateLimiters.generalApi,
    auth.requireRole(ROLES.DASHBOARD),
    validateBody(EmergencyStopSchema),
    (req, res) => {
      res.json(sessionManager.emergencyStop(req.validatedBody.sessionId || null));
    }
  );

  return router;
}

module.exports = {
  createDashboardRouter,
};
