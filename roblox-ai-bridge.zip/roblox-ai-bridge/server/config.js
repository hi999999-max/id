'use strict';

const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');

function parseBool(value, defaultValue) {
  if (value === undefined || value === null || value === '') return defaultValue;
  const normalized = String(value).trim().toLowerCase();
  if (['1', 'true', 'yes', 'on'].includes(normalized)) return true;
  if (['0', 'false', 'no', 'off'].includes(normalized)) return false;
  return defaultValue;
}

function parseIntBounded(value, defaultValue, min, max) {
  const num = Number.parseInt(value, 10);
  if (!Number.isFinite(num)) return defaultValue;
  return Math.min(Math.max(num, min), max);
}

function parseAllowedPlaceIds(raw) {
  if (!raw || String(raw).trim() === '' || String(raw).trim() === '*') {
    return { allowAll: true, ids: new Set() };
  }
  const ids = new Set();
  for (const part of String(raw).split(',')) {
    const trimmed = part.trim();
    if (/^\d+$/.test(trimmed)) {
      ids.add(Number(trimmed));
    }
  }
  return { allowAll: false, ids };
}

function parseCorsOrigins(raw) {
  if (!raw || String(raw).trim() === '') return [];
  return String(raw)
    .split(',')
    .map((s) => s.trim())
    .filter((s) => s && s !== '*');
}

function loadConfig(overrides = {}) {
  if (!overrides.skipDotenv) {
    const envPath = overrides.envPath || path.resolve(process.cwd(), '.env');
    if (fs.existsSync(envPath)) {
      dotenv.config({ path: envPath, override: false });
    }
  }

  const env = { ...process.env, ...overrides };

  const config = {
    nodeEnv: env.NODE_ENV || 'production',
    port: parseIntBounded(env.PORT, 3003, 0, 65535),
    host: env.HOST || '127.0.0.1',
    publicIp: env.PUBLIC_IP || '77.68.33.65',

    tlsEnabled: parseBool(env.TLS_ENABLED, false),
    tlsCertPath: env.TLS_CERT_PATH || path.resolve(process.cwd(), 'certs/server.crt'),
    tlsKeyPath: env.TLS_KEY_PATH || path.resolve(process.cwd(), 'certs/server.key'),
    allowInsecurePublicHttp: parseBool(env.ALLOW_INSECURE_PUBLIC_HTTP, false),

    aiApiToken: env.AI_API_TOKEN || '',
    executorApiToken: env.EXECUTOR_API_TOKEN || '',
    dashboardAdminToken: env.DASHBOARD_ADMIN_TOKEN || '',

    allowedPlaceIds: parseAllowedPlaceIds(env.ALLOWED_PLACE_IDS),
    allowedPlaceIdsRaw: env.ALLOWED_PLACE_IDS || '*',

    executeLuauEnabled: parseBool(env.EXECUTE_LUAU_ENABLED, true),
    executeLuauRequireApproval: parseBool(env.EXECUTE_LUAU_REQUIRE_APPROVAL, true),
    executeLuauMaxCodeBytes: parseIntBounded(env.EXECUTE_LUAU_MAX_CODE_BYTES, 16384, 256, 65536),
    executeLuauMaxTimeoutMs: parseIntBounded(env.EXECUTE_LUAU_MAX_TIMEOUT_MS, 15000, 250, 30000),

    maxRequestBodyBytes: parseIntBounded(env.MAX_REQUEST_BODY_BYTES, 262144, 4096, 1048576),
    maxResultBytes: parseIntBounded(env.MAX_RESULT_BYTES, 262144, 4096, 1048576),
    defaultToolTimeoutMs: parseIntBounded(env.DEFAULT_TOOL_TIMEOUT_MS, 20000, 1000, 60000),
    maxToolTimeoutMs: parseIntBounded(env.MAX_TOOL_TIMEOUT_MS, 60000, 1000, 120000),
    executorHeartbeatTimeoutMs: parseIntBounded(env.EXECUTOR_HEARTBEAT_TIMEOUT_MS, 30000, 5000, 300000),
    executorPollDefaultWaitMs: parseIntBounded(env.EXECUTOR_POLL_DEFAULT_WAIT_MS, 10000, 0, 25000),
    executorPollMaxWaitMs: parseIntBounded(env.EXECUTOR_POLL_MAX_WAIT_MS, 15000, 500, 30000),

    maxQueuePerSession: parseIntBounded(env.MAX_QUEUE_PER_SESSION, 50, 1, 500),
    maxConcurrentRequests: parseIntBounded(env.MAX_CONCURRENT_REQUESTS, 10, 1, 100),
    maxActivityHistory: parseIntBounded(env.MAX_ACTIVITY_HISTORY, 250, 20, 2000),

    requireReplayHeaders: parseBool(env.REQUIRE_REPLAY_HEADERS, false),
    replayWindowMs: parseIntBounded(env.REPLAY_WINDOW_MS, 60000, 5000, 300000),

    corsAllowedOrigins: parseCorsOrigins(env.CORS_ALLOWED_ORIGINS),
    logLevel: (env.LOG_LEVEL || 'info').toLowerCase(),
    trustProxy: parseBool(env.TRUST_PROXY, false),
  };

  return config;
}

function validateConfigSecurity(config) {
  const errors = [];

  const tokens = [
    ['AI_API_TOKEN', config.aiApiToken],
    ['EXECUTOR_API_TOKEN', config.executorApiToken],
    ['DASHBOARD_ADMIN_TOKEN', config.dashboardAdminToken],
  ];

  for (const [name, val] of tokens) {
    if (!val || val.startsWith('REPLACE_WITH_') || val.length < 24) {
      errors.push(`${name} must be configured with a high-entropy token (at least 24 characters).`);
    }
  }

  if (
    config.aiApiToken &&
    config.executorApiToken &&
    config.aiApiToken === config.executorApiToken
  ) {
    errors.push('AI_API_TOKEN and EXECUTOR_API_TOKEN must be distinct.');
  }
  if (
    config.aiApiToken &&
    config.dashboardAdminToken &&
    config.aiApiToken === config.dashboardAdminToken
  ) {
    errors.push('AI_API_TOKEN and DASHBOARD_ADMIN_TOKEN must be distinct.');
  }
  if (
    config.executorApiToken &&
    config.dashboardAdminToken &&
    config.executorApiToken === config.dashboardAdminToken
  ) {
    errors.push('EXECUTOR_API_TOKEN and DASHBOARD_ADMIN_TOKEN must be distinct.');
  }

  const isPublicBind = config.host === '0.0.0.0' || config.host === '::';
  if (isPublicBind && !config.tlsEnabled && !config.allowInsecurePublicHttp && config.nodeEnv !== 'test') {
    errors.push(
      'Refusing to listen with plaintext HTTP on public 0.0.0.0. Enable TLS_ENABLED=true, bind HOST to a WireGuard/local interface (e.g. 10.66.66.1 or 127.0.0.1), or set ALLOW_INSECURE_PUBLIC_HTTP=true only if behind a trusted TLS reverse proxy.'
    );
  }

  if (config.tlsEnabled) {
    if (!fs.existsSync(config.tlsCertPath) || !fs.existsSync(config.tlsKeyPath)) {
      errors.push(`TLS_ENABLED=true but certificate or key file is missing (${config.tlsCertPath}, ${config.tlsKeyPath}).`);
    }
  }

  return errors;
}

module.exports = {
  loadConfig,
  validateConfigSecurity,
  parseAllowedPlaceIds,
};
