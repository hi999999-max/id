'use strict';

const LEVELS = {
  debug: 10,
  info: 20,
  warn: 30,
  error: 40,
};

const SENSITIVE_KEYS = new Set([
  'authorization',
  'x-api-key',
  'x-executor-token',
  'x-ai-token',
  'x-dashboard-token',
  'cookie',
  'set-cookie',
  'token',
  'secret',
  'password',
  'aiapitoken',
  'executorapitoken',
  'dashboardadmintoken',
]);

function createLogger({ level = 'info', secrets = [] } = {}) {
  const minLevel = LEVELS[level] || LEVELS.info;
  const activeSecrets = secrets.filter((s) => typeof s === 'string' && s.length >= 8);

  function redactString(str) {
    let out = str;
    for (const secret of activeSecrets) {
      if (out.includes(secret)) {
        out = out.split(secret).join('[REDACTED]');
      }
    }
    out = out.replace(/(Bearer\s+)[A-Za-z0-9._\-+/=]+/gi, '$1[REDACTED]');
    return out;
  }

  function sanitize(value, depth = 0) {
    if (depth > 6) return '[MaxDepth]';
    if (value === null || value === undefined) return value;
    if (typeof value === 'string') return redactString(value);
    if (typeof value === 'number' || typeof value === 'boolean') return value;
    if (value instanceof Error) {
      return {
        name: value.name,
        message: redactString(value.message),
      };
    }
    if (Array.isArray(value)) {
      return value.slice(0, 50).map((item) => sanitize(item, depth + 1));
    }
    if (typeof value === 'object') {
      const clean = {};
      for (const [k, v] of Object.entries(value)) {
        if (SENSITIVE_KEYS.has(k.toLowerCase())) {
          clean[k] = '[REDACTED]';
        } else {
          clean[k] = sanitize(v, depth + 1);
        }
      }
      return clean;
    }
    return String(value);
  }

  function log(lvl, message, meta) {
    if ((LEVELS[lvl] || LEVELS.info) < minLevel) return;
    const entry = {
      ts: new Date().toISOString(),
      level: lvl,
      msg: redactString(String(message)),
    };
    if (meta && Object.keys(meta).length > 0) {
      entry.meta = sanitize(meta);
    }
    const line = JSON.stringify(entry);
    if (lvl === 'error') {
      console.error(line);
    } else if (lvl === 'warn') {
      console.warn(line);
    } else {
      console.log(line);
    }
  }

  return {
    debug: (msg, meta) => log('debug', msg, meta),
    info: (msg, meta) => log('info', msg, meta),
    warn: (msg, meta) => log('warn', msg, meta),
    error: (msg, meta) => log('error', msg, meta),
    sanitize,
  };
}

module.exports = {
  createLogger,
};
