'use strict';

(function () {
  const state = {
    authenticated: false,
    selectedSessionId: null,
    latestData: null,
    pollTimer: null,
  };

  const el = {
    loginView: document.getElementById('loginView'),
    appView: document.getElementById('appView'),
    loginForm: document.getElementById('loginForm'),
    tokenInput: document.getElementById('tokenInput'),
    loginError: document.getElementById('loginError'),
    logoutBtn: document.getElementById('logoutBtn'),
    sessionSelect: document.getElementById('sessionSelect'),
    emergencyStopBtn: document.getElementById('emergencyStopBtn'),

    serverStatusText: document.getElementById('serverStatusText'),
    serverMetaText: document.getElementById('serverMetaText'),
    executorStatusBadge: document.getElementById('executorStatusBadge'),
    executorSub: document.getElementById('executorSub'),
    aiStatusBadge: document.getElementById('aiStatusBadge'),
    aiSub: document.getElementById('aiSub'),
    gameNameVal: document.getElementById('gameNameVal'),
    placeIdSub: document.getElementById('placeIdSub'),
    sessionIdVal: document.getElementById('sessionIdVal'),
    heartbeatSub: document.getElementById('heartbeatSub'),
    placeAllowlistBadge: document.getElementById('placeAllowlistBadge'),

    pendingCountVal: document.getElementById('pendingCountVal'),
    completedCountVal: document.getElementById('completedCountVal'),
    failedCountVal: document.getElementById('failedCountVal'),
    approvalCountVal: document.getElementById('approvalCountVal'),

    disconnectExecutorBtn: document.getElementById('disconnectExecutorBtn'),
    disconnectAiBtn: document.getElementById('disconnectAiBtn'),
    endSessionBtn: document.getElementById('endSessionBtn'),
    clearHistoryBtn: document.getElementById('clearHistoryBtn'),
    toggleLuauEnabledBtn: document.getElementById('toggleLuauEnabledBtn'),
    toggleLuauApprovalBtn: document.getElementById('toggleLuauApprovalBtn'),

    approvalSection: document.getElementById('approvalSection'),
    approvalList: document.getElementById('approvalList'),
    pendingHeaderCount: document.getElementById('pendingHeaderCount'),
    pendingList: document.getElementById('pendingList'),
    errorHeaderCount: document.getElementById('errorHeaderCount'),
    errorList: document.getElementById('errorList'),
    activityFeed: document.getElementById('activityFeed'),
    historyCountBadge: document.getElementById('historyCountBadge'),
    historyList: document.getElementById('historyList'),

    toolsCountBadge: document.getElementById('toolsCountBadge'),
    toolSearchInput: document.getElementById('toolSearchInput'),
    toolCategorySelect: document.getElementById('toolCategorySelect'),
    toolsGrid: document.getElementById('toolsGrid'),
    toast: document.getElementById('toast'),
  };

  function showToast(message) {
    el.toast.textContent = message;
    el.toast.classList.remove('hidden');
    clearTimeout(showToast._timer);
    showToast._timer = setTimeout(() => {
      el.toast.classList.add('hidden');
    }, 3200);
  }

  async function apiRequest(url, options = {}) {
    const res = await fetch(url, {
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        ...(options.headers || {}),
      },
      ...options,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const msg = data?.error?.message || `HTTP ${res.status}`;
      const err = new Error(msg);
      err.status = res.status;
      throw err;
    }
    return data;
  }

  function clearChildren(node) {
    while (node.firstChild) {
      node.removeChild(node.firstChild);
    }
  }

  function makeEl(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined && text !== null) node.textContent = String(text);
    return node;
  }

  function formatDurationAge(ms) {
    if (ms === null || ms === undefined) return '—';
    if (ms < 1000) return `${ms}ms ago`;
    return `${(ms / 1000).toFixed(1)}s ago`;
  }

  function renderSessions(data) {
    const sessions = data.sessions || [];
    const previousSelection = state.selectedSessionId;

    clearChildren(el.sessionSelect);
    if (sessions.length === 0) {
      const opt = makeEl('option', '', 'No active sessions');
      opt.value = '';
      el.sessionSelect.appendChild(opt);
      state.selectedSessionId = null;
    } else {
      for (const s of sessions) {
        const opt = makeEl(
          'option',
          '',
          `${s.sessionId.slice(0, 14)}… (${s.executor.gameName || 'No Game'})`
        );
        opt.value = s.sessionId;
        el.sessionSelect.appendChild(opt);
      }
      const stillExists = sessions.some((s) => s.sessionId === previousSelection);
      state.selectedSessionId = stillExists ? previousSelection : sessions[0].sessionId;
      el.sessionSelect.value = state.selectedSessionId;
    }

    const active = sessions.find((s) => s.sessionId === state.selectedSessionId) || null;

    if (!active) {
      el.executorStatusBadge.textContent = 'Disconnected';
      el.executorStatusBadge.className = 'status-pill offline';
      el.executorSub.textContent = 'Waiting for BridgeClient.lua';
      el.aiStatusBadge.textContent = 'Disconnected';
      el.aiStatusBadge.className = 'status-pill offline';
      el.aiSub.textContent = 'Waiting for AI registration';
      el.gameNameVal.textContent = '—';
      el.placeIdSub.textContent = 'Place ID: —';
      el.sessionIdVal.textContent = '—';
      el.heartbeatSub.textContent = 'Heartbeat: —';
      el.disconnectExecutorBtn.disabled = true;
      el.disconnectAiBtn.disabled = true;
      el.endSessionBtn.disabled = true;
    } else {
      el.sessionIdVal.textContent = active.sessionId;
      el.disconnectExecutorBtn.disabled = !active.executor.connected;
      el.disconnectAiBtn.disabled = !active.ai.connected;
      el.endSessionBtn.disabled = false;

      if (active.executor.connected) {
        el.executorStatusBadge.textContent = 'Connected';
        el.executorStatusBadge.className = 'status-pill online';
        el.executorSub.textContent = `${active.executor.executorName || 'Executor'} • ${active.executor.playerName || 'LocalPlayer'}`;
        el.gameNameVal.textContent = active.executor.gameName || 'Unknown Experience';
        el.placeIdSub.textContent = `Place ID: ${active.executor.placeId ?? '—'}`;
        el.heartbeatSub.textContent = `Heartbeat: ${formatDurationAge(active.executor.heartbeatAgeMs)}`;
      } else {
        el.executorStatusBadge.textContent = 'Disconnected';
        el.executorStatusBadge.className = 'status-pill offline';
        el.executorSub.textContent = 'Executor offline';
        el.gameNameVal.textContent = active.executor.gameName || '—';
        el.placeIdSub.textContent = `Place ID: ${active.executor.placeId ?? '—'}`;
        el.heartbeatSub.textContent = 'Heartbeat: Offline';
      }

      if (active.ai.connected) {
        el.aiStatusBadge.textContent = 'Connected';
        el.aiStatusBadge.className = 'status-pill online';
        el.aiSub.textContent = `${active.ai.clientName || 'AI Agent'} (${active.ai.aiClientId || ''})`;
      } else {
        el.aiStatusBadge.textContent = 'Disconnected';
        el.aiStatusBadge.className = 'status-pill offline';
        el.aiSub.textContent = 'Waiting for AI registration';
      }
    }
  }

  function renderApprovals(data) {
    const items = data.pendingApprovals || [];
    clearChildren(el.approvalList);
    if (items.length === 0) {
      el.approvalSection.classList.add('hidden');
      return;
    }

    el.approvalSection.classList.remove('hidden');
    for (const item of items) {
      const box = makeEl('div', 'list-item');
      const head = makeEl('div', 'list-item-head');
      head.appendChild(makeEl('strong', '', `ExecuteLuau (${item.requestId.slice(0, 12)}…)`));
      head.appendChild(makeEl('span', 'mono-small', item.createdAt));
      box.appendChild(head);

      if (item.reason) {
        box.appendChild(makeEl('div', 'muted', `Reason: ${item.reason}`));
      }

      const codeBox = makeEl('pre', 'code-preview', item.code);
      box.appendChild(codeBox);

      const actions = makeEl('div', 'approval-actions');
      const approveBtn = makeEl('button', 'btn btn-success', 'Approve & Run');
      approveBtn.addEventListener('click', async () => {
        try {
          await apiRequest('/api/v1/dashboard/actions/approve-request', {
            method: 'POST',
            body: JSON.stringify({ sessionId: item.sessionId, requestId: item.requestId }),
          });
          showToast('Approved ExecuteLuau request');
          await refreshState();
        } catch (err) {
          showToast(`Approve failed: ${err.message}`);
        }
      });

      const rejectBtn = makeEl('button', 'btn btn-danger', 'Reject');
      rejectBtn.addEventListener('click', async () => {
        try {
          await apiRequest('/api/v1/dashboard/actions/reject-request', {
            method: 'POST',
            body: JSON.stringify({ sessionId: item.sessionId, requestId: item.requestId }),
          });
          showToast('Rejected ExecuteLuau request');
          await refreshState();
        } catch (err) {
          showToast(`Reject failed: ${err.message}`);
        }
      });

      actions.appendChild(approveBtn);
      actions.appendChild(rejectBtn);
      box.appendChild(actions);
      el.approvalList.appendChild(box);
    }
  }

  function renderPending(data) {
    const items = data.pendingRequests || [];
    el.pendingHeaderCount.textContent = String(items.length);
    clearChildren(el.pendingList);
    if (items.length === 0) {
      el.pendingList.appendChild(makeEl('div', 'empty-state', 'No pending or in-flight requests.'));
      return;
    }
    for (const item of items) {
      const box = makeEl('div', 'list-item');
      const head = makeEl('div', 'list-item-head');
      head.appendChild(makeEl('strong', '', item.toolName));
      head.appendChild(makeEl('span', 'chip', item.status));
      box.appendChild(head);
      box.appendChild(makeEl('div', 'mono-small', `${item.requestId} • ${item.argsPreview}`));
      el.pendingList.appendChild(box);
    }
  }

  function renderErrors(data) {
    const items = data.connectionErrors || [];
    el.errorHeaderCount.textContent = String(items.length);
    clearChildren(el.errorList);
    if (items.length === 0) {
      el.errorList.appendChild(makeEl('div', 'empty-state', 'No recent connection errors.'));
      return;
    }
    for (const item of items) {
      const box = makeEl('div', 'list-item');
      const head = makeEl('div', 'list-item-head');
      head.appendChild(makeEl('strong', '', `${item.source}: ${item.code}`));
      head.appendChild(makeEl('span', 'mono-small', new Date(item.ts).toLocaleTimeString()));
      box.appendChild(head);
      box.appendChild(makeEl('div', 'muted', item.message));
      el.errorList.appendChild(box);
    }
  }

  function renderActivity(data) {
    const items = data.recentActivity || [];
    clearChildren(el.activityFeed);
    if (items.length === 0) {
      el.activityFeed.appendChild(makeEl('div', 'empty-state', 'No activity recorded yet.'));
      return;
    }
    for (const item of items) {
      const box = makeEl('div', 'list-item');
      const head = makeEl('div', 'list-item-head');
      head.appendChild(makeEl('span', 'chip', item.type));
      head.appendChild(makeEl('span', 'mono-small', new Date(item.ts).toLocaleTimeString()));
      box.appendChild(head);
      box.appendChild(makeEl('div', '', item.message));
      el.activityFeed.appendChild(box);
    }
  }

  function renderHistory(data) {
    const items = data.executionHistory || [];
    el.historyCountBadge.textContent = String(items.length);
    clearChildren(el.historyList);
    if (items.length === 0) {
      el.historyList.appendChild(makeEl('div', 'empty-state', 'No completed or failed tool calls yet.'));
      return;
    }
    for (const item of items) {
      const box = makeEl('div', 'list-item');
      const head = makeEl('div', 'list-item-head');
      head.appendChild(makeEl('strong', '', item.toolName));
      head.appendChild(makeEl('span', `chip ${item.ok ? '' : 'warn'}`, `${item.status} (${item.durationMs ?? '—'}ms)`));
      box.appendChild(head);
      box.appendChild(makeEl('div', 'mono-small', `Args: ${item.argsPreview}`));
      if (item.error) {
        box.appendChild(makeEl('div', 'muted', `Error: ${item.error.message || item.error.code}`));
      } else if (item.resultPreview) {
        box.appendChild(makeEl('div', 'mono-small', `Result: ${item.resultPreview}`));
      }
      el.historyList.appendChild(box);
    }
  }

  function renderTools(data) {
    const tools = data.tools || [];
    const search = el.toolSearchInput.value.trim().toLowerCase();
    const category = el.toolCategorySelect.value;

    const filtered = tools.filter((t) => {
      if (category !== 'all' && t.category !== category) return false;
      if (search && !t.name.toLowerCase().includes(search) && !t.description.toLowerCase().includes(search)) {
        return false;
      }
      return true;
    });

    el.toolsCountBadge.textContent = `${filtered.length} / ${tools.length} tools`;
    clearChildren(el.toolsGrid);

    for (const t of filtered) {
      const card = makeEl('div', 'tool-card');
      const head = makeEl('div', 'tool-card-head');
      head.appendChild(makeEl('span', 'tool-name', t.name));
      head.appendChild(makeEl('span', 'chip', t.category));
      card.appendChild(head);
      card.appendChild(makeEl('div', 'tool-desc', t.description));
      el.toolsGrid.appendChild(card);
    }
  }

  function renderState(data) {
    state.latestData = data;
    const srv = data.server || {};
    el.serverStatusText.textContent = `Server ${srv.status || 'online'} (uptime ${srv.uptimeSeconds ?? 0}s)`;
    el.serverMetaText.textContent = `Port ${srv.port || 3003} • ${srv.tlsEnabled ? 'HTTPS' : 'HTTP'}`;
    el.placeAllowlistBadge.textContent = `Place Allowlist: ${srv.allowedPlaceIds || '*'}`;

    const stats = data.stats || {};
    el.pendingCountVal.textContent = String(stats.pendingCount ?? 0);
    el.completedCountVal.textContent = String(stats.completedCount ?? 0);
    el.failedCountVal.textContent = String(stats.failedCount ?? 0);
    el.approvalCountVal.textContent = String(stats.approvalCount ?? 0);

    const policy = data.policy || {};
    el.toggleLuauEnabledBtn.textContent = `ExecuteLuau: ${policy.executeLuauEnabled ? 'ON' : 'OFF'}`;
    el.toggleLuauApprovalBtn.textContent = `Manual Approval: ${policy.executeLuauRequireApproval ? 'ON' : 'OFF'}`;

    renderSessions(data);
    renderApprovals(data);
    renderPending(data);
    renderErrors(data);
    renderActivity(data);
    renderHistory(data);
    renderTools(data);
  }

  async function refreshState() {
    try {
      const data = await apiRequest('/api/v1/dashboard/state', { method: 'GET' });
      if (!state.authenticated) {
        state.authenticated = true;
        el.loginView.classList.add('hidden');
        el.appView.classList.remove('hidden');
      }
      renderState(data);
    } catch (err) {
      if (err.status === 401) {
        stopPolling();
        state.authenticated = false;
        el.appView.classList.add('hidden');
        el.loginView.classList.remove('hidden');
      }
    }
  }

  function startPolling() {
    stopPolling();
    refreshState();
    state.pollTimer = setInterval(refreshState, 2000);
  }

  function stopPolling() {
    if (state.pollTimer) {
      clearInterval(state.pollTimer);
      state.pollTimer = null;
    }
  }

  // Event listeners
  el.loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    el.loginError.classList.add('hidden');
    try {
      await apiRequest('/api/v1/dashboard/login', {
        method: 'POST',
        body: JSON.stringify({ token: el.tokenInput.value.trim() }),
      });
      el.tokenInput.value = '';
      startPolling();
    } catch (err) {
      el.loginError.textContent = err.message;
      el.loginError.classList.remove('hidden');
    }
  });

  el.logoutBtn.addEventListener('click', async () => {
    stopPolling();
    await apiRequest('/api/v1/dashboard/logout', { method: 'POST', body: '{}' }).catch(() => {});
    state.authenticated = false;
    el.appView.classList.add('hidden');
    el.loginView.classList.remove('hidden');
  });

  el.sessionSelect.addEventListener('change', () => {
    state.selectedSessionId = el.sessionSelect.value || null;
    if (state.latestData) renderSessions(state.latestData);
  });

  el.emergencyStopBtn.addEventListener('click', async () => {
    try {
      const res = await apiRequest('/api/v1/dashboard/actions/emergency-stop', {
        method: 'POST',
        body: JSON.stringify(state.selectedSessionId ? { sessionId: state.selectedSessionId } : {}),
      });
      showToast(`Emergency Stop triggered (${res.cancelledCount} requests cancelled)`);
      await refreshState();
    } catch (err) {
      showToast(`Error: ${err.message}`);
    }
  });

  el.disconnectExecutorBtn.addEventListener('click', async () => {
    if (!state.selectedSessionId) return;
    try {
      await apiRequest('/api/v1/dashboard/actions/disconnect-executor', {
        method: 'POST',
        body: JSON.stringify({ sessionId: state.selectedSessionId }),
      });
      showToast('Executor disconnected');
      await refreshState();
    } catch (err) {
      showToast(`Error: ${err.message}`);
    }
  });

  el.disconnectAiBtn.addEventListener('click', async () => {
    if (!state.selectedSessionId) return;
    try {
      await apiRequest('/api/v1/dashboard/actions/disconnect-ai', {
        method: 'POST',
        body: JSON.stringify({ sessionId: state.selectedSessionId }),
      });
      showToast('AI disconnected');
      await refreshState();
    } catch (err) {
      showToast(`Error: ${err.message}`);
    }
  });

  el.endSessionBtn.addEventListener('click', async () => {
    if (!state.selectedSessionId) return;
    try {
      await apiRequest('/api/v1/dashboard/actions/end-session', {
        method: 'POST',
        body: JSON.stringify({ sessionId: state.selectedSessionId }),
      });
      showToast('Session ended');
      await refreshState();
    } catch (err) {
      showToast(`Error: ${err.message}`);
    }
  });

  el.clearHistoryBtn.addEventListener('click', async () => {
    try {
      await apiRequest('/api/v1/dashboard/actions/clear-history', {
        method: 'POST',
        body: '{}',
      });
      showToast('History cleared');
      await refreshState();
    } catch (err) {
      showToast(`Error: ${err.message}`);
    }
  });

  el.toggleLuauEnabledBtn.addEventListener('click', async () => {
    const current = Boolean(state.latestData?.policy?.executeLuauEnabled);
    try {
      await apiRequest('/api/v1/dashboard/actions/toggle-execute-luau', {
        method: 'POST',
        body: JSON.stringify({ executeLuauEnabled: !current }),
      });
      showToast(`ExecuteLuau ${!current ? 'enabled' : 'disabled'}`);
      await refreshState();
    } catch (err) {
      showToast(`Error: ${err.message}`);
    }
  });

  el.toggleLuauApprovalBtn.addEventListener('click', async () => {
    const current = Boolean(state.latestData?.policy?.executeLuauRequireApproval);
    try {
      await apiRequest('/api/v1/dashboard/actions/toggle-execute-luau', {
        method: 'POST',
        body: JSON.stringify({ executeLuauRequireApproval: !current }),
      });
      showToast(`Manual approval ${!current ? 'enabled' : 'disabled'}`);
      await refreshState();
    } catch (err) {
      showToast(`Error: ${err.message}`);
    }
  });

  el.toolSearchInput.addEventListener('input', () => {
    if (state.latestData) renderTools(state.latestData);
  });
  el.toolCategorySelect.addEventListener('change', () => {
    if (state.latestData) renderTools(state.latestData);
  });

  // Attempt auto-resume if HttpOnly cookie is already valid
  startPolling();
})();
