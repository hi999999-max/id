'use strict';

/**
 * Standalone Mock Roblox Executor for testing without Roblox Studio/Client.
 * Usage:
 *   EXECUTOR_API_TOKEN=... BRIDGE_URL=http://127.0.0.1:3003 node scripts/mock-executor.js
 */

const crypto = require('crypto');

class MockRobloxWorld {
  constructor() {
    this.placeId = Number(process.env.MOCK_PLACE_ID || 123456789);
    this.jobId = process.env.MOCK_JOB_ID || 'mock-job-0001';
    this.gameName = process.env.MOCK_GAME_NAME || 'Mock Authorised Test Obby';
    this.player = {
      userId: 900001,
      name: 'BridgeTestBot',
      displayName: 'Bridge Test Bot',
      team: 'Explorers',
    };
    this.character = {
      position: { x: 0, y: 5, z: 0 },
      lookVector: { x: 0, y: 0, z: -1 },
      velocity: { x: 0, y: 0, z: 0 },
      health: 100,
      maxHealth: 100,
      walkSpeed: 16,
      jumpPower: 50,
      jumpHeight: 7.2,
      humanoidState: 'Running',
      sit: false,
    };
    this.movementActive = false;
    this.doorOpened = false;
    this.objects = [
      {
        name: 'SpawnLocation',
        className: 'SpawnLocation',
        path: 'Workspace.SpawnLocation',
        position: { x: 0, y: 1, z: 0 },
        tags: ['Spawn'],
      },
      {
        name: 'VaultDoor',
        className: 'Model',
        path: 'Workspace.VaultDoor',
        position: { x: 24, y: 5, z: -12 },
        tags: ['Interactable'],
      },
      {
        name: 'DoorPrompt',
        className: 'ProximityPrompt',
        path: 'Workspace.VaultDoor.DoorPart.DoorPrompt',
        position: { x: 24, y: 5, z: -12 },
        actionText: 'Open Vault',
        objectText: 'Vault Door',
        enabled: true,
        holdDuration: 0,
        maxActivationDistance: 12,
        tags: ['Prompt'],
      },
      {
        name: 'SupplyCrate',
        className: 'Part',
        path: 'Workspace.SupplyCrate',
        position: { x: -15, y: 3, z: 18 },
        tags: ['Loot'],
      },
    ];
  }

  dist(a, b) {
    return Math.round(Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z) * 100) / 100;
  }

  executeTool(toolName, args = {}) {
    switch (toolName) {
      case 'GetGameInfo':
        return {
          gameName: this.gameName,
          placeId: this.placeId,
          gameId: 555111222,
          jobId: this.jobId,
          playerCount: 1,
        };
      case 'GetLocalPlayerInfo':
        return { ...this.player, hasCharacter: true, characterPath: `Workspace.${this.player.name}` };
      case 'GetCharacterState':
        return { alive: this.character.health > 0, ...this.character };
      case 'GetCameraState':
        return {
          position: { x: this.character.position.x, y: this.character.position.y + 4, z: this.character.position.z + 10 },
          lookVector: { x: 0, y: -0.2, z: -0.98 },
          fieldOfView: 70,
          cameraType: 'Enum.CameraType.Custom',
          viewportSize: { x: 1920, y: 1080 },
        };
      case 'GetWorkspaceSummary':
        return {
          totalTopLevelChildren: this.objects.length,
          classCounts: { SpawnLocation: 1, Model: 1, Part: 1 },
          topLevel: this.objects.slice(0, 3),
          playerCount: 1,
          gravity: 196.2,
        };
      case 'GetNearbyInteractables': {
        const radius = args.radius || 80;
        const interactables = this.objects
          .filter((o) => o.className === 'ProximityPrompt')
          .map((o) => ({
            kind: 'ProximityPrompt',
            name: o.name,
            path: o.path,
            position: o.position,
            distance: this.dist(this.character.position, o.position),
            actionText: o.actionText,
            objectText: o.objectText,
            enabled: o.enabled,
          }))
          .filter((o) => o.distance <= radius);
        return { origin: this.character.position, radius, count: interactables.length, interactables };
      }
      case 'GetNearbyPrompts': {
        const radius = args.radius || 80;
        const prompts = this.objects
          .filter((o) => o.className === 'ProximityPrompt')
          .map((o) => ({
            ...o,
            distance: this.dist(this.character.position, o.position),
          }))
          .filter((o) => o.distance <= radius);
        return { origin: this.character.position, radius, count: prompts.length, prompts };
      }
      case 'GetNavigationPath': {
        let target = args.targetPosition;
        if (!target && args.targetPath) {
          const found = this.objects.find((o) => o.path === args.targetPath);
          if (!found) throw new Error(`Target instance not found: ${args.targetPath}`);
          target = found.position;
        }
        const mid = {
          x: (this.character.position.x + target.x) / 2,
          y: target.y,
          z: (this.character.position.z + target.z) / 2,
        };
        return {
          available: true,
          status: 'Enum.PathStatus.Success',
          startPosition: this.character.position,
          targetPosition: target,
          waypointCount: 3,
          waypoints: [
            { position: this.character.position, action: 'Enum.PathWaypointAction.Walk' },
            { position: mid, action: 'Enum.PathWaypointAction.Walk' },
            { position: target, action: 'Enum.PathWaypointAction.Walk' },
          ],
        };
      }
      case 'MoveTo': {
        let target = args.targetPosition;
        if (!target && args.targetPath) {
          const found = this.objects.find((o) => o.path === args.targetPath);
          if (!found) throw new Error(`Target instance not found: ${args.targetPath}`);
          target = found.position;
        }
        this.character.position = { ...target };
        return {
          arrived: true,
          reason: 'arrived',
          pathStatus: 'Enum.PathStatus.Success',
          finalPosition: this.character.position,
        };
      }
      case 'StopMovement':
      case 'CancelMovement':
        this.movementActive = false;
        return { stopped: true, cancelled: true };
      case 'InteractWithPrompt': {
        const prompt = this.objects.find((o) => o.path === args.promptPath && o.className === 'ProximityPrompt');
        if (!prompt) throw new Error(`ProximityPrompt not found: ${args.promptPath}`);
        this.doorOpened = true;
        return {
          triggered: true,
          promptPath: prompt.path,
          actionText: prompt.actionText,
          objectText: prompt.objectText,
          doorOpened: true,
        };
      }
      case 'GetExecutorCapabilities':
        return {
          executorIdentity: 'MockExecutor 1.0',
          httpRequestFunction: 'node-fetch',
          fireproximityprompt: true,
          firetouchinterest: true,
          fireclickdetector: true,
          loadstring: true,
        };
      case 'ExecuteLuau':
        return {
          compiled: true,
          succeeded: true,
          output: [`[MockLuau] Executed ${args.code.length} chars`],
          returnValues: ['mock-ok'],
          durationMs: 4,
        };
      default:
        return {
          mocked: true,
          toolName,
          receivedArgs: args,
          characterPosition: this.character.position,
        };
    }
  }
}

class MockExecutorClient {
  constructor({ baseUrl, token, world, customHandler } = {}) {
    this.baseUrl = (baseUrl || process.env.BRIDGE_URL || 'http://127.0.0.1:3003').replace(/\/+$/, '');
    this.token = token || process.env.EXECUTOR_API_TOKEN || '';
    this.world = world || new MockRobloxWorld();
    this.customHandler = customHandler || null;
    this.sessionId = null;
    this.executorId = null;
    this.running = false;
    this.heartbeatTimer = null;
  }

  async _post(path, body) {
    const res = await fetch(`${this.baseUrl}${path}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this.token}`,
        'X-Request-Timestamp': String(Date.now()),
        'X-Request-Nonce': crypto.randomUUID(),
      },
      body: JSON.stringify(body),
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) {
      const err = new Error(json?.error?.message || `HTTP ${res.status}`);
      err.status = res.status;
      err.code = json?.error?.code;
      throw err;
    }
    return json;
  }

  async register(sessionId = undefined) {
    const res = await this._post('/api/v1/executor/register', {
      ...(sessionId ? { sessionId } : {}),
      executorName: 'MockExecutor',
      placeId: this.world.placeId,
      jobId: this.world.jobId,
      gameName: this.world.gameName,
      playerName: this.world.player.name,
      playerUserId: this.world.player.userId,
      capabilities: this.world.executeTool('GetExecutorCapabilities'),
    });
    this.sessionId = res.sessionId;
    this.executorId = res.executorId;
    return res;
  }

  async heartbeat() {
    return this._post('/api/v1/executor/heartbeat', {
      sessionId: this.sessionId,
      executorId: this.executorId,
      placeId: this.world.placeId,
      jobId: this.world.jobId,
    });
  }

  async pollOnce(waitMs = 2000) {
    return this._post('/api/v1/executor/poll', {
      sessionId: this.sessionId,
      executorId: this.executorId,
      waitMs,
      maxTasks: 5,
    });
  }

  async submitResult(payload) {
    return this._post('/api/v1/executor/result', {
      sessionId: this.sessionId,
      executorId: this.executorId,
      ...payload,
    });
  }

  async processTask(task) {
    const start = Date.now();
    try {
      const data = this.customHandler
        ? await this.customHandler(task, this.world)
        : this.world.executeTool(task.toolName, task.args);
      await this.submitResult({
        requestId: task.requestId,
        ok: true,
        data,
        durationMs: Date.now() - start,
      });
    } catch (err) {
      await this.submitResult({
        requestId: task.requestId,
        ok: false,
        error: { code: 'MOCK_EXEC_ERROR', message: err.message },
        durationMs: Date.now() - start,
      }).catch(() => {});
    }
  }

  async startLoop({ pollWaitMs = 3000, heartbeatMs = 8000 } = {}) {
    await this.register();
    this.running = true;

    this.heartbeatTimer = setInterval(() => {
      if (this.running && this.sessionId) {
        this.heartbeat().catch(() => {});
      }
    }, heartbeatMs);
    if (this.heartbeatTimer.unref) this.heartbeatTimer.unref();

    (async () => {
      while (this.running) {
        try {
          const pollRes = await this.pollOnce(pollWaitMs);
          if (pollRes.disconnected) {
            this.running = false;
            break;
          }
          if (Array.isArray(pollRes.tasks)) {
            await Promise.all(pollRes.tasks.map((t) => this.processTask(t)));
          }
        } catch (err) {
          if (!this.running) break;
          await new Promise((r) => setTimeout(r, 500));
        }
      }
    })();

    return { sessionId: this.sessionId, executorId: this.executorId };
  }

  stop() {
    this.running = false;
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }
  }
}

if (require.main === module) {
  if (!process.env.EXECUTOR_API_TOKEN) {
    console.error('Set EXECUTOR_API_TOKEN environment variable before running mock-executor.');
    process.exit(1);
  }
  const client = new MockExecutorClient();
  client.startLoop().then(({ sessionId, executorId }) => {
    console.log(`Mock Executor connected! sessionId=${sessionId} executorId=${executorId}`);
  }).catch((err) => {
    console.error('Mock Executor failed to start:', err.message);
    process.exit(1);
  });
}

module.exports = {
  MockRobloxWorld,
  MockExecutorClient,
};
