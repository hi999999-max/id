#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# WireGuard VPN Setup Helper for Roblox AI Executor Bridge
# Creates a private encrypted tunnel (10.66.66.1/24) so HTTP port 3003 is never
# exposed as plaintext on the public internet.
# Safe to inspect before running; does NOT touch SSH rules.
# =============================================================================

if [[ $EUID -ne 0 ]]; then
  echo "Please run as root (or with sudo)."
  exit 1
fi

WG_DIR="/etc/wireguard"
WG_IFACE="wg0"
WG_PORT="51820"
SERVER_IP="10.66.66.1"
PC_IP="10.66.66.2"
MOBILE_IP="10.66.66.3"
PUBLIC_IP="${PUBLIC_IP:-77.68.33.65}"
OUT_DIR="/opt/roblox-ai-bridge/wireguard-clients"

echo "[1/5] Inspecting OS & WireGuard availability..."
if command -v apt-get >/dev/null 2>&1; then
  apt-get update -y
  DEBIAN_FRONTEND=noninteractive apt-get install -y wireguard wireguard-tools qrencode
elif command -v dnf >/dev/null 2>&1; then
  dnf install -y wireguard-tools qrencode
else
  echo "Unsupported package manager. Install wireguard-tools manually."
  exit 1
fi

mkdir -p "$WG_DIR" "$OUT_DIR"
chmod 700 "$WG_DIR" "$OUT_DIR"

if [[ -f "$WG_DIR/$WG_IFACE.conf" ]]; then
  echo "Existing $WG_DIR/$WG_IFACE.conf found. Refusing to overwrite existing WireGuard config."
  exit 0
fi

echo "[2/5] Generating WireGuard keypairs..."
SRV_PRIV=$(wg genkey)
SRV_PUB=$(echo "$SRV_PRIV" | wg pubkey)

PC_PRIV=$(wg genkey)
PC_PUB=$(echo "$PC_PRIV" | wg pubkey)

MOB_PRIV=$(wg genkey)
MOB_PUB=$(echo "$MOB_PRIV" | wg pubkey)

echo "[3/5] Writing $WG_DIR/$WG_IFACE.conf..."
cat > "$WG_DIR/$WG_IFACE.conf" <<EOF
[Interface]
Address = ${SERVER_IP}/24
ListenPort = ${WG_PORT}
PrivateKey = ${SRV_PRIV}

# Windows / PC client (Roblox executor + Dashboard)
[Peer]
PublicKey = ${PC_PUB}
AllowedIPs = ${PC_IP}/32

# Secondary / Mobile / AI client
[Peer]
PublicKey = ${MOB_PUB}
AllowedIPs = ${MOBILE_IP}/32
EOF
chmod 600 "$WG_DIR/$WG_IFACE.conf"

echo "[4/5] Writing client configs in $OUT_DIR..."
cat > "$OUT_DIR/pc-client.conf" <<EOF
[Interface]
PrivateKey = ${PC_PRIV}
Address = ${PC_IP}/32

[Peer]
PublicKey = ${SRV_PUB}
Endpoint = ${PUBLIC_IP}:${WG_PORT}
AllowedIPs = 10.66.66.0/24
PersistentKeepalive = 25
EOF

cat > "$OUT_DIR/ai-client.conf" <<EOF
[Interface]
PrivateKey = ${MOB_PRIV}
Address = ${MOBILE_IP}/32

[Peer]
PublicKey = ${SRV_PUB}
Endpoint = ${PUBLIC_IP}:${WG_PORT}
AllowedIPs = 10.66.66.0/24
PersistentKeepalive = 25
EOF
chmod 600 "$OUT_DIR"/*.conf

echo "[5/5] Enabling WireGuard & allowing UDP ${WG_PORT}..."
if command -v ufw >/dev/null 2>&1 && ufw status | grep -q "Status: active"; then
  ufw allow "${WG_PORT}/udp" comment "WireGuard VPN"
  ufw allow in on "$WG_IFACE" to any port 3003 proto tcp comment "Roblox AI Bridge over WireGuard"
elif command -v firewall-cmd >/dev/null 2>&1 && systemctl is-active --quiet firewalld; then
  firewall-cmd --permanent --add-port="${WG_PORT}/udp"
  firewall-cmd --permanent --add-interface="$WG_IFACE" --zone=trusted
  firewall-cmd --reload
fi

systemctl enable "wg-quick@${WG_IFACE}"
systemctl restart "wg-quick@${WG_IFACE}"

echo ""
echo "WireGuard is active on ${SERVER_IP} (UDP ${WG_PORT})."
echo "Client configs saved to:"
echo "  - ${OUT_DIR}/pc-client.conf"
echo "  - ${OUT_DIR}/ai-client.conf"
echo "Next: In /opt/roblox-ai-bridge/.env, set HOST=${SERVER_IP} and restart roblox-ai-bridge."
