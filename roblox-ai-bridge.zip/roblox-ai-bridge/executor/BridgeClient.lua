--!strict
--[[
===============================================================================
  ROBLOX AI EXECUTOR BRIDGE - EXECUTOR CLIENT (BridgeClient.lua)
  Self-contained Luau bridge client for HTTP Request/Response + Polling.
  Compatible with standard Roblox executors supporting request/http_request.
===============================================================================
]]

-- Stop any previous instance cleanly before starting a new one
if _G.RobloxAIBridge and type(_G.RobloxAIBridge.Stop) == "function" then
	pcall(_G.RobloxAIBridge.Stop, "Restarting BridgeClient")
end

-- ============================================================================
-- CONFIGURATION (EDIT BEFORE EXECUTING)
-- ============================================================================
local Config = {
	-- Use WireGuard tunnel URL (http://10.66.66.1:3003) OR HTTPS IP URL (https://77.68.33.65:3003)
	-- Never send EXECUTOR_API_TOKEN over unencrypted public HTTP.
	ServerUrl = "http://10.66.66.1:3003",
	ExecutorToken = "REPLACE_WITH_EXECUTOR_API_TOKEN",
	ExecutorName = "RobloxExecutor",

	-- Set to {} to allow any PlaceId during authorised testing,
	-- or list specific PlaceIds e.g. { 123456789, 987654321 }
	AllowedPlaceIds = {},

	PollWaitMs = 8000,
	PollLoopDelaySeconds = 0.15,
	HeartbeatIntervalSeconds = 8,
	ReconnectMinSeconds = 2,
	ReconnectMaxSeconds = 30,

	MaxResultBytes = 220000,
	DefaultRadius = 75,
	MaxRadius = 500,
	MaxResults = 100,
	MaxDepth = 12,
}

-- ============================================================================
-- SERVICES & ENVIRONMENT DETECTION
-- ============================================================================
local Players = game:GetService("Players")
local Workspace = game:GetService("Workspace")
local HttpService = game:GetService("HttpService")
local Lighting = game:GetService("Lighting")
local PathfindingService = game:GetService("PathfindingService")
local CollectionService = game:GetService("CollectionService")
local MarketplaceService = game:GetService("MarketplaceService")
local RunService = game:GetService("RunService")

local function DetectHttpRequestFunction()
	local env = (getgenv and getgenv()) or _G
	if type(request) == "function" then
		return request, "request"
	end
	if type(http_request) == "function" then
		return http_request, "http_request"
	end
	if type(env) == "table" then
		if type(env.request) == "function" then
			return env.request, "getgenv().request"
		end
		if type(env.http_request) == "function" then
			return env.http_request, "getgenv().http_request"
		end
	end
	if type(syn) == "table" and type(syn.request) == "function" then
		return syn.request, "syn.request"
	end
	if type(http) == "table" and type(http.request) == "function" then
		return http.request, "http.request"
	end
	if type(fluxus) == "table" and type(fluxus.request) == "function" then
		return fluxus.request, "fluxus.request"
	end
	return nil, "none"
end

local HttpRequestFn, HttpRequestFnName = DetectHttpRequestFunction()
if not HttpRequestFn then
	error(
		"[RobloxAIBridge] COMPATIBILITY ERROR: This executor does not expose a supported HTTP request function "
			.. "(checked request, http_request, syn.request, http.request, fluxus.request). "
			.. "Cannot connect to the bridge server."
	)
end

local function DetectExecutorCapabilities()
	local execName = Config.ExecutorName
	if type(identifyexecutor) == "function" then
		local ok, name, ver = pcall(identifyexecutor)
		if ok and type(name) == "string" then
			execName = ver and (name .. " " .. tostring(ver)) or name
		end
	end

	local vimOk = pcall(function()
		return game:GetService("VirtualInputManager")
	end)

	return {
		executorIdentity = execName,
		httpRequestFunction = HttpRequestFnName,
		fireproximityprompt = type(fireproximityprompt) == "function",
		firetouchinterest = type(firetouchinterest) == "function",
		fireclickdetector = type(fireclickdetector) == "function",
		loadstring = type(loadstring) == "function",
		gethui = type(gethui) == "function",
		setclipboard = type(setclipboard) == "function",
		virtualInputManager = vimOk,
	}
end

local Capabilities = DetectExecutorCapabilities()

-- ============================================================================
-- PLACE ID ALLOWLIST CHECK
-- ============================================================================
local function IsPlaceAllowed(placeId: number): boolean
	if #Config.AllowedPlaceIds == 0 then
		return true
	end
	for _, allowedId in ipairs(Config.AllowedPlaceIds) do
		if tonumber(allowedId) == tonumber(placeId) then
			return true
		end
	end
	return false
end

if not IsPlaceAllowed(game.PlaceId) then
	error(string.format("[RobloxAIBridge] PlaceId %d is not in Config.AllowedPlaceIds.", game.PlaceId))
end

if Config.ExecutorToken == "REPLACE_WITH_EXECUTOR_API_TOKEN" or #Config.ExecutorToken < 16 then
	error("[RobloxAIBridge] Please configure Config.ExecutorToken with your EXECUTOR_API_TOKEN before running.")
end

-- ============================================================================
-- CLIENT STATE & CANCELLATION TRACKING
-- ============================================================================
local State = {
	Running = true,
	Connected = false,
	SessionId = nil :: string?,
	ExecutorId = nil :: string?,
	MovementToken = 0,
	ActiveMovement = {
		Active = false,
		Mode = "idle",
		TargetPosition = nil :: { x: number, y: number, z: number }?,
		WaypointsRemaining = 0,
		StartedAt = nil :: number?,
	},
	CancelledRequests = {} :: { [string]: boolean },
	ProcessedRequests = {} :: { [string]: boolean },
	ProcessedOrder = {} :: { string },
}

local function MarkRequestProcessed(requestId: string)
	if State.ProcessedRequests[requestId] then
		return
	end
	State.ProcessedRequests[requestId] = true
	table.insert(State.ProcessedOrder, requestId)
	if #State.ProcessedOrder > 200 then
		local oldest = table.remove(State.ProcessedOrder, 1)
		if oldest then
			State.ProcessedRequests[oldest] = nil
		end
	end
end

local function IsRequestCancelled(requestId: string?): boolean
	if not State.Running then
		return true
	end
	if requestId and State.CancelledRequests[requestId] then
		return true
	end
	return false
end

-- ============================================================================
-- HTTP HELPERS
-- ============================================================================
local function NormalizeBaseUrl(url: string): string
	return (string.gsub(url, "/+$", ""))
end

local BaseUrl = NormalizeBaseUrl(Config.ServerUrl)

local function SendHttp(method: string, path: string, bodyTable: any?)
	local nonce = HttpService:GenerateGUID(false)
	local ts = tostring(os.time())
	local encodedBody = bodyTable and HttpService:JSONEncode(bodyTable) or "{}"

	local ok, response = pcall(HttpRequestFn, {
		Url = BaseUrl .. path,
		Method = method,
		Headers = {
			["Content-Type"] = "application/json",
			["Authorization"] = "Bearer " .. Config.ExecutorToken,
			["X-Request-Timestamp"] = ts,
			["X-Request-Nonce"] = nonce,
		},
		Body = method == "GET" and nil or encodedBody,
	})

	if not ok then
		return false, 0, nil, "Executor HTTP call error: " .. tostring(response)
	end

	local statusCode = tonumber(response.StatusCode or response.status_code or 0) or 0
	local rawBody = response.Body or response.body or ""
	local decoded = nil
	if type(rawBody) == "string" and #rawBody > 0 then
		local decOk, decData = pcall(function()
			return HttpService:JSONDecode(rawBody)
		end)
		if decOk then
			decoded = decData
		end
	end

	if statusCode >= 200 and statusCode < 300 then
		return true, statusCode, decoded, nil
	end

	local errMsg = (type(decoded) == "table" and decoded.error and decoded.error.message)
		or ("HTTP " .. tostring(statusCode))
	return false, statusCode, decoded, errMsg
end

-- ============================================================================
-- SERIALIZATION & INSTANCE PATH HELPERS
-- ============================================================================
local function Vector3ToTable(v: Vector3)
	return {
		x = math.round(v.X * 1000) / 1000,
		y = math.round(v.Y * 1000) / 1000,
		z = math.round(v.Z * 1000) / 1000,
	}
end

local function TableToVector3(t: { x: number, y: number, z: number }): Vector3
	return Vector3.new(tonumber(t.x) or 0, tonumber(t.y) or 0, tonumber(t.z) or 0)
end

local function Color3ToTable(c: Color3)
	return {
		r = math.round(c.R * 255),
		g = math.round(c.G * 255),
		b = math.round(c.B * 255),
	}
end

local function SafeSerializeValue(val: any): any
	local t = typeof(val)
	if t == "nil" or t == "boolean" or t == "number" or t == "string" then
		return val
	elseif t == "Vector3" then
		return Vector3ToTable(val)
	elseif t == "Vector2" then
		return { x = math.round(val.X * 1000) / 1000, y = math.round(val.Y * 1000) / 1000 }
	elseif t == "UDim2" then
		return {
			x = { scale = val.X.Scale, offset = val.X.Offset },
			y = { scale = val.Y.Scale, offset = val.Y.Offset },
		}
	elseif t == "CFrame" then
		return {
			position = Vector3ToTable(val.Position),
			lookVector = Vector3ToTable(val.LookVector),
		}
	elseif t == "Color3" then
		return Color3ToTable(val)
	elseif t == "BrickColor" then
		return val.Name
	elseif t == "EnumItem" then
		return tostring(val)
	elseif t == "Instance" then
		return val:GetFullName()
	elseif t == "table" then
		local out = {}
		local count = 0
		for k, v in pairs(val) do
			count += 1
			if count > 50 then
				out.__truncated = true
				break
			end
			out[tostring(k)] = SafeSerializeValue(v)
		end
		return out
	end
	return tostring(val)
end

local function GetInstancePath(inst: Instance?): string
	if not inst then
		return ""
	end
	return inst:GetFullName()
end

local function ResolveInstancePath(pathStr: string?): Instance?
	if type(pathStr) ~= "string" or #pathStr == 0 then
		return Workspace
	end

	local segments = {}
	for seg in string.gmatch(pathStr, "[^%.]+") do
		table.insert(segments, seg)
	end
	if #segments == 0 then
		return Workspace
	end

	local current: Instance = game
	local startIdx = 1

	local first = segments[1]
	if first == "game" or first == "DataModel" then
		startIdx = 2
	elseif first == "Workspace" or first == "workspace" then
		current = Workspace
		startIdx = 2
	elseif first == "LocalPlayer" then
		current = Players.LocalPlayer
		startIdx = 2
	elseif first == "PlayerGui" then
		current = Players.LocalPlayer:FindFirstChild("PlayerGui") :: Instance
		startIdx = 2
	elseif first == "Backpack" then
		current = Players.LocalPlayer:FindFirstChild("Backpack") :: Instance
		startIdx = 2
	else
		local svcOk, svc = pcall(function()
			return game:GetService(first)
		end)
		if svcOk and svc then
			current = svc
			startIdx = 2
		end
	end

	if not current then
		return nil
	end

	for i = startIdx, #segments do
		local name = segments[i]
		if current == Players and name == "LocalPlayer" then
			current = Players.LocalPlayer
		else
			local child = current:FindFirstChild(name)
			if not child then
				return nil
			end
			current = child
		end
	end

	return current
end

local function GetWorldPositionOfInstance(inst: Instance): Vector3?
	if inst:IsA("BasePart") then
		return inst.Position
	elseif inst:IsA("Model") then
		if inst.PrimaryPart then
			return inst.PrimaryPart.Position
		end
		local pivotOk, pivot = pcall(function()
			return inst:GetPivot()
		end)
		if pivotOk and typeof(pivot) == "CFrame" then
			return pivot.Position
		end
	elseif inst:IsA("Attachment") then
		return inst.WorldPosition
	elseif inst.Parent then
		return GetWorldPositionOfInstance(inst.Parent)
	end
	return nil
end

local function GetLocalCharacterParts()
	local lp = Players.LocalPlayer
	if not lp then
		return nil, nil, nil
	end
	local char = lp.Character
	if not char then
		return lp, nil, nil
	end
	local humanoid = char:FindFirstChildOfClass("Humanoid")
	local root = char:FindFirstChild("HumanoidRootPart") :: BasePart?
	return lp, char, humanoid, root
end

local function GetOriginPosition(originTable: any?): Vector3
	if type(originTable) == "table" then
		return TableToVector3(originTable)
	end
	local _, _, _, root = GetLocalCharacterParts()
	if root then
		return root.Position
	end
	local cam = Workspace.CurrentCamera
	if cam then
		return cam.CFrame.Position
	end
	return Vector3.new(0, 0, 0)
end

local function ClampNumber(val: any, defaultVal: number, minVal: number, maxVal: number): number
	local n = tonumber(val)
	if not n then
		return defaultVal
	end
	return math.clamp(n, minVal, maxVal)
end

-- ============================================================================
-- MOVEMENT CONTROLLER (NORMAL HUMANOID MOVEMENT)
-- ============================================================================
local function StopActiveMovement()
	State.MovementToken += 1
	State.ActiveMovement.Active = false
	State.ActiveMovement.Mode = "idle"
	State.ActiveMovement.TargetPosition = nil
	State.ActiveMovement.WaypointsRemaining = 0

	local _, _, humanoid, root = GetLocalCharacterParts()
	if humanoid then
		if root then
			pcall(function()
				humanoid:MoveTo(root.Position)
			end)
		end
		pcall(function()
			humanoid:Move(Vector3.zero, false)
		end)
	end
end

local function WalkDirectToPosition(humanoid: Humanoid, root: BasePart, targetPos: Vector3, stopDist: number, timeoutSec: number, token: number, requestId: string?)
	local startTime = os.clock()
	humanoid:MoveTo(targetPos)
	local lastRepush = os.clock()

	while os.clock() - startTime < timeoutSec do
		if State.MovementToken ~= token or IsRequestCancelled(requestId) then
			return false, "cancelled"
		end
		if humanoid.Health <= 0 then
			return false, "character_dead"
		end
		local dist = (root.Position - targetPos).Magnitude
		if dist <= stopDist then
			return true, "arrived"
		end
		if os.clock() - lastRepush >= 1.5 then
			humanoid:MoveTo(targetPos)
			lastRepush = os.clock()
		end
		task.wait(0.1)
	end

	return false, "timeout"
end

local function ExecuteWaypointFollow(waypointsList: { Vector3 }, stopDist: number, timeoutSec: number, requestId: string?)
	local _, _, humanoid, root = GetLocalCharacterParts()
	if not humanoid or not root then
		return false, { code = "NO_CHARACTER", message = "LocalPlayer character or HumanoidRootPart is not available." }
	end

	State.MovementToken += 1
	local token = State.MovementToken
	State.ActiveMovement.Active = true
	State.ActiveMovement.Mode = "following_path"
	State.ActiveMovement.StartedAt = os.clock()

	local deadline = os.clock() + timeoutSec
	local reachedAll = true
	local finalReason = "arrived"

	for idx, wpPos in ipairs(waypointsList) do
		if State.MovementToken ~= token or IsRequestCancelled(requestId) then
			reachedAll = false
			finalReason = "cancelled"
			break
		end
		State.ActiveMovement.TargetPosition = Vector3ToTable(wpPos)
		State.ActiveMovement.WaypointsRemaining = #waypointsList - idx + 1

		local remaining = math.max(0.5, deadline - os.clock())
		local isLast = idx == #waypointsList
		local wpStop = isLast and stopDist or math.max(2.5, stopDist)
		local ok, reason = WalkDirectToPosition(humanoid, root, wpPos, wpStop, remaining, token, requestId)
		if not ok then
			reachedAll = false
			finalReason = reason
			break
		end
	end

	if State.MovementToken == token then
		State.ActiveMovement.Active = false
		State.ActiveMovement.Mode = "idle"
		State.ActiveMovement.WaypointsRemaining = 0
	end

	return true, {
		arrived = reachedAll,
		reason = finalReason,
		finalPosition = Vector3ToTable(root.Position),
	}
end

-- ============================================================================
-- TOOL IMPLEMENTATIONS (ALL 43 TOOLS)
-- ============================================================================
local ToolHandlers = {}

-- A. Environment Inspection (1 - 15)
function ToolHandlers.GetGameInfo()
	local infoName = "Unknown"
	local creatorName = nil
	local creatorId = nil
	pcall(function()
		local productInfo = MarketplaceService:GetProductInfo(game.PlaceId)
		if productInfo then
			infoName = productInfo.Name or infoName
			if productInfo.Creator then
				creatorName = productInfo.Creator.Name
				creatorId = productInfo.Creator.Id
			end
		end
	end)

	return {
		gameName = infoName,
		placeId = game.PlaceId,
		gameId = game.GameId,
		jobId = game.JobId,
		placeVersion = game.PlaceVersion,
		creatorName = creatorName,
		creatorId = creatorId,
		playerCount = #Players:GetPlayers(),
	}
end

function ToolHandlers.GetLocalPlayerInfo()
	local lp = Players.LocalPlayer
	if not lp then
		error("LocalPlayer is not available.")
	end
	return {
		userId = lp.UserId,
		name = lp.Name,
		displayName = lp.DisplayName,
		team = lp.Team and lp.Team.Name or nil,
		hasCharacter = lp.Character ~= nil,
		characterPath = lp.Character and GetInstancePath(lp.Character) or nil,
	}
end

function ToolHandlers.GetCharacterState()
	local _, char, humanoid, root = GetLocalCharacterParts()
	if not char or not humanoid or not root then
		return {
			alive = false,
			hasCharacter = char ~= nil,
		}
	end
	local cf = root.CFrame
	return {
		alive = humanoid.Health > 0,
		position = Vector3ToTable(root.Position),
		lookVector = Vector3ToTable(cf.LookVector),
		velocity = Vector3ToTable(root.AssemblyLinearVelocity),
		health = humanoid.Health,
		maxHealth = humanoid.MaxHealth,
		walkSpeed = humanoid.WalkSpeed,
		jumpPower = humanoid.JumpPower,
		jumpHeight = humanoid.JumpHeight,
		humanoidState = tostring(humanoid:GetState()),
		sit = humanoid.Sit,
		moveDirection = Vector3ToTable(humanoid.MoveDirection),
		floorMaterial = tostring(humanoid.FloorMaterial),
	}
end

function ToolHandlers.GetCameraState()
	local cam = Workspace.CurrentCamera
	if not cam then
		error("CurrentCamera is not available.")
	end
	return {
		position = Vector3ToTable(cam.CFrame.Position),
		lookVector = Vector3ToTable(cam.CFrame.LookVector),
		focus = Vector3ToTable(cam.Focus.Position),
		fieldOfView = cam.FieldOfView,
		cameraType = tostring(cam.CameraType),
		viewportSize = { x = cam.ViewportSize.X, y = cam.ViewportSize.Y },
	}
end

function ToolHandlers.GetWorkspaceSummary(args)
	local maxItems = ClampNumber(args.maxTopLevelItems, 40, 1, 100)
	local children = Workspace:GetChildren()
	local topLevel = {}
	local classCounts = {}

	for i, child in ipairs(children) do
		classCounts[child.ClassName] = (classCounts[child.ClassName] or 0) + 1
		if i <= maxItems then
			local pos = GetWorldPositionOfInstance(child)
			table.insert(topLevel, {
				name = child.Name,
				className = child.ClassName,
				path = GetInstancePath(child),
				childCount = #child:GetChildren(),
				position = pos and Vector3ToTable(pos) or nil,
			})
		end
	end

	return {
		totalTopLevelChildren = #children,
		classCounts = classCounts,
		topLevel = topLevel,
		playerCount = #Players:GetPlayers(),
		gravity = Workspace.Gravity,
	}
end

function ToolHandlers.GetDescendants(args)
	local root = ResolveInstancePath(args.rootPath or "Workspace")
	if not root then
		error("Root instance not found: " .. tostring(args.rootPath))
	end

	local classFilter = args.classFilter
	local maxDepth = ClampNumber(args.maxDepth, 4, 1, Config.MaxDepth)
	local limit = ClampNumber(args.limit, 25, 1, Config.MaxResults)
	local offset = ClampNumber(args.offset, 0, 0, 5000)

	local matches = {}
	local totalVisited = 0

	local function Traverse(node: Instance, depth: number)
		if depth > maxDepth or totalVisited > 4000 then
			return
		end
		for _, child in ipairs(node:GetChildren()) do
			totalVisited += 1
			if not classFilter or child:IsA(classFilter) or child.ClassName == classFilter then
				local pos = GetWorldPositionOfInstance(child)
				table.insert(matches, {
					name = child.Name,
					className = child.ClassName,
					path = GetInstancePath(child),
					depth = depth,
					position = pos and Vector3ToTable(pos) or nil,
				})
			end
			if depth < maxDepth then
				Traverse(child, depth + 1)
			end
		end
	end

	Traverse(root, 1)

	local page = {}
	for i = offset + 1, math.min(#matches, offset + limit) do
		table.insert(page, matches[i])
	end

	return {
		rootPath = GetInstancePath(root),
		totalMatched = #matches,
		offset = offset,
		limit = limit,
		hasMore = (offset + limit) < #matches,
		items = page,
	}
end

function ToolHandlers.GetChildren(args)
	local target = ResolveInstancePath(args.instancePath)
	if not target then
		error("Instance not found: " .. tostring(args.instancePath))
	end
	local limit = ClampNumber(args.limit, 50, 1, Config.MaxResults)
	local classFilter = args.classFilter
	local items = {}
	for _, child in ipairs(target:GetChildren()) do
		if not classFilter or child:IsA(classFilter) or child.ClassName == classFilter then
			local pos = GetWorldPositionOfInstance(child)
			table.insert(items, {
				name = child.Name,
				className = child.ClassName,
				path = GetInstancePath(child),
				childCount = #child:GetChildren(),
				position = pos and Vector3ToTable(pos) or nil,
			})
			if #items >= limit then
				break
			end
		end
	end
	return {
		instancePath = GetInstancePath(target),
		count = #items,
		children = items,
	}
end

function ToolHandlers.FindInstances(args)
	local root = ResolveInstancePath(args.rootPath or "Workspace")
	if not root then
		error("Root instance not found: " .. tostring(args.rootPath))
	end
	local nameQuery = args.nameContains and string.lower(args.nameContains) or nil
	local classFilter = args.className
	local maxResults = ClampNumber(args.maxResults, 25, 1, Config.MaxResults)

	local results = {}
	for _, desc in ipairs(root:GetDescendants()) do
		local classOk = (not classFilter) or desc:IsA(classFilter) or (desc.ClassName == classFilter)
		local nameOk = (not nameQuery) or (string.find(string.lower(desc.Name), nameQuery, 1, true) ~= nil)
		if classOk and nameOk then
			local pos = GetWorldPositionOfInstance(desc)
			table.insert(results, {
				name = desc.Name,
				className = desc.ClassName,
				path = GetInstancePath(desc),
				position = pos and Vector3ToTable(pos) or nil,
			})
			if #results >= maxResults then
				break
			end
		end
	end

	return {
		rootPath = GetInstancePath(root),
		count = #results,
		results = results,
	}
end

function ToolHandlers.SearchWorkspace(args)
	local query = string.lower(args.query)
	local classFilter = args.classFilter
	local maxResults = ClampNumber(args.maxResults, 25, 1, Config.MaxResults)

	local results = {}
	for _, desc in ipairs(Workspace:GetDescendants()) do
		local classOk = (not classFilter) or desc:IsA(classFilter) or (desc.ClassName == classFilter)
		if classOk then
			local matched = string.find(string.lower(desc.Name), query, 1, true) ~= nil
			if not matched and desc:IsA("ProximityPrompt") then
				matched = string.find(string.lower(desc.ActionText .. " " .. desc.ObjectText), query, 1, true) ~= nil
			end
			if matched then
				local pos = GetWorldPositionOfInstance(desc)
				table.insert(results, {
					name = desc.Name,
					className = desc.ClassName,
					path = GetInstancePath(desc),
					position = pos and Vector3ToTable(pos) or nil,
				})
				if #results >= maxResults then
					break
				end
			end
		end
	end

	return {
		query = args.query,
		count = #results,
		results = results,
	}
end

function ToolHandlers.GetInstanceInfo(args)
	local inst = ResolveInstancePath(args.instancePath)
	if not inst then
		error("Instance not found: " .. tostring(args.instancePath))
	end
	local pos = GetWorldPositionOfInstance(inst)
	local info = {
		name = inst.Name,
		className = inst.ClassName,
		path = GetInstancePath(inst),
		parentPath = inst.Parent and GetInstancePath(inst.Parent) or nil,
		childCount = #inst:GetChildren(),
		position = pos and Vector3ToTable(pos) or nil,
		tags = CollectionService:GetTags(inst),
	}
	if inst:IsA("BasePart") then
		info.size = Vector3ToTable(inst.Size)
		info.canCollide = inst.CanCollide
		info.anchored = inst.Anchored
		info.transparency = inst.Transparency
	elseif inst:IsA("ProximityPrompt") then
		info.actionText = inst.ActionText
		info.objectText = inst.ObjectText
		info.enabled = inst.Enabled
		info.maxActivationDistance = inst.MaxActivationDistance
		info.holdDuration = inst.HoldDuration
	end
	return info
end

function ToolHandlers.GetInstanceProperties(args)
	local inst = ResolveInstancePath(args.instancePath)
	if not inst then
		error("Instance not found: " .. tostring(args.instancePath))
	end
	local props = {}
	for _, propName in ipairs(args.properties) do
		local ok, val = pcall(function()
			return (inst :: any)[propName]
		end)
		if ok then
			props[propName] = SafeSerializeValue(val)
		else
			props[propName] = nil
		end
	end
	return {
		instancePath = GetInstancePath(inst),
		className = inst.ClassName,
		properties = props,
	}
end

function ToolHandlers.GetInstanceAttributes(args)
	local inst = ResolveInstancePath(args.instancePath)
	if not inst then
		error("Instance not found: " .. tostring(args.instancePath))
	end
	local attrs = {}
	for k, v in pairs(inst:GetAttributes()) do
		attrs[k] = SafeSerializeValue(v)
	end
	return {
		instancePath = GetInstancePath(inst),
		attributes = attrs,
	}
end

function ToolHandlers.GetCollectionServiceTags(args)
	if args.instancePath then
		local inst = ResolveInstancePath(args.instancePath)
		if not inst then
			error("Instance not found: " .. tostring(args.instancePath))
		end
		return {
			instancePath = GetInstancePath(inst),
			tags = CollectionService:GetTags(inst),
		}
	end

	local maxResults = ClampNumber(args.maxResults, 25, 1, Config.MaxResults)
	local tagged = CollectionService:GetTagged(args.tagName)
	local items = {}
	for i, inst in ipairs(tagged) do
		if i > maxResults then
			break
		end
		local pos = GetWorldPositionOfInstance(inst)
		table.insert(items, {
			name = inst.Name,
			className = inst.ClassName,
			path = GetInstancePath(inst),
			position = pos and Vector3ToTable(pos) or nil,
		})
	end
	return {
		tagName = args.tagName,
		totalTagged = #tagged,
		items = items,
	}
end

function ToolHandlers.GetLightingInfo()
	return {
		clockTime = Lighting.ClockTime,
		timeOfDay = Lighting.TimeOfDay,
		brightness = Lighting.Brightness,
		ambient = Color3ToTable(Lighting.Ambient),
		outdoorAmbient = Color3ToTable(Lighting.OutdoorAmbient),
		fogStart = Lighting.FogStart,
		fogEnd = Lighting.FogEnd,
		fogColor = Color3ToTable(Lighting.FogColor),
		globalShadows = Lighting.GlobalShadows,
		geographicLatitude = Lighting.GeographicLatitude,
	}
end

local function SerializeGuiNode(inst: Instance, depth: number, maxDepth: number, includeInvisible: boolean, counter: { count: number, max: number })
	if depth > maxDepth or counter.count >= counter.max then
		return nil
	end

	if inst:IsA("GuiObject") and not includeInvisible and not inst.Visible then
		return nil
	end
	if inst:IsA("LayerCollector") and not includeInvisible and not inst.Enabled then
		return nil
	end

	counter.count += 1
	local node: any = {
		name = inst.Name,
		className = inst.ClassName,
		path = GetInstancePath(inst),
	}

	if inst:IsA("GuiObject") then
		node.visible = inst.Visible
		node.position = { x = inst.AbsolutePosition.X, y = inst.AbsolutePosition.Y }
		node.size = { x = inst.AbsoluteSize.X, y = inst.AbsoluteSize.Y }
	elseif inst:IsA("LayerCollector") then
		node.enabled = inst.Enabled
	end

	if inst:IsA("TextLabel") or inst:IsA("TextButton") or inst:IsA("TextBox") then
		node.text = inst.Text
	end
	if inst:IsA("GuiButton") then
		node.isButton = true
		node.active = inst.Active
	end

	if depth < maxDepth and counter.count < counter.max then
		local childrenOut = {}
		for _, child in ipairs(inst:GetChildren()) do
			if child:IsA("GuiBase") or child:IsA("Folder") then
				local serialized = SerializeGuiNode(child, depth + 1, maxDepth, includeInvisible, counter)
				if serialized then
					table.insert(childrenOut, serialized)
				end
			end
			if counter.count >= counter.max then
				break
			end
		end
		if #childrenOut > 0 then
			node.children = childrenOut
		end
	end

	return node
end

function ToolHandlers.GetVisibleGuiTree(args)
	local lp = Players.LocalPlayer
	local playerGui = lp and lp:FindFirstChild("PlayerGui")
	if not playerGui then
		error("PlayerGui is not available.")
	end

	local maxDepth = ClampNumber(args.maxDepth, 6, 1, 10)
	local maxNodes = ClampNumber(args.maxNodes, 60, 1, 150)
	local includeInvisible = args.includeInvisible == true
	local counter = { count = 0, max = maxNodes }

	local screens = {}
	for _, child in ipairs(playerGui:GetChildren()) do
		local serialized = SerializeGuiNode(child, 1, maxDepth, includeInvisible, counter)
		if serialized then
			table.insert(screens, serialized)
		end
	end

	return {
		nodeCount = counter.count,
		truncated = counter.count >= maxNodes,
		screens = screens,
	}
end

-- B. Surrounding Environment (16 - 24)
function ToolHandlers.GetNearbyParts(args)
	local origin = GetOriginPosition(args.origin)
	local radius = ClampNumber(args.radius, 60, 1, Config.MaxRadius)
	local maxResults = ClampNumber(args.maxResults, 25, 1, Config.MaxResults)
	local nameQuery = args.nameContains and string.lower(args.nameContains) or nil

	local candidates = {}
	local overlapOk, partsInRadius = pcall(function()
		return Workspace:GetPartBoundsInRadius(origin, radius)
	end)

	local sourceParts = overlapOk and partsInRadius or Workspace:GetDescendants()
	for _, inst in ipairs(sourceParts) do
		if inst:IsA("BasePart") then
			if not nameQuery or string.find(string.lower(inst.Name), nameQuery, 1, true) then
				local dist = (inst.Position - origin).Magnitude
				if dist <= radius then
					table.insert(candidates, {
						name = inst.Name,
						className = inst.ClassName,
						path = GetInstancePath(inst),
						position = Vector3ToTable(inst.Position),
						size = Vector3ToTable(inst.Size),
						distance = math.round(dist * 100) / 100,
						canCollide = inst.CanCollide,
						anchored = inst.Anchored,
					})
				end
			end
		end
	end

	table.sort(candidates, function(a, b)
		return a.distance < b.distance
	end)
	while #candidates > maxResults do
		table.remove(candidates)
	end

	return {
		origin = Vector3ToTable(origin),
		radius = radius,
		count = #candidates,
		parts = candidates,
	}
end

function ToolHandlers.GetNearbyModels(args)
	local origin = GetOriginPosition(args.origin)
	local radius = ClampNumber(args.radius, 80, 1, Config.MaxRadius)
	local maxResults = ClampNumber(args.maxResults, 25, 1, Config.MaxResults)
	local nameQuery = args.nameContains and string.lower(args.nameContains) or nil

	local results = {}
	for _, desc in ipairs(Workspace:GetDescendants()) do
		if desc:IsA("Model") then
			if not nameQuery or string.find(string.lower(desc.Name), nameQuery, 1, true) then
				local pos = GetWorldPositionOfInstance(desc)
				if pos then
					local dist = (pos - origin).Magnitude
					if dist <= radius then
						table.insert(results, {
							name = desc.Name,
							path = GetInstancePath(desc),
							position = Vector3ToTable(pos),
							distance = math.round(dist * 100) / 100,
							hasHumanoid = desc:FindFirstChildOfClass("Humanoid") ~= nil,
						})
					end
				end
			end
		end
	end

	table.sort(results, function(a, b)
		return a.distance < b.distance
	end)
	while #results > maxResults do
		table.remove(results)
	end

	return {
		origin = Vector3ToTable(origin),
		radius = radius,
		count = #results,
		models = results,
	}
end

function ToolHandlers.GetNearbyPlayers(args)
	local lp = Players.LocalPlayer
	local origin = GetOriginPosition(nil)
	local radius = ClampNumber(args.radius, 150, 1, Config.MaxRadius)
	local maxResults = ClampNumber(args.maxResults, 20, 1, 50)

	local playersOut = {}
	for _, plr in ipairs(Players:GetPlayers()) do
		if plr ~= lp and plr.Character then
			local root = plr.Character:FindFirstChild("HumanoidRootPart") :: BasePart?
			local hum = plr.Character:FindFirstChildOfClass("Humanoid")
			if root then
				local dist = (root.Position - origin).Magnitude
				if dist <= radius then
					table.insert(playersOut, {
						name = plr.Name,
						displayName = plr.DisplayName,
						team = plr.Team and plr.Team.Name or nil,
						position = Vector3ToTable(root.Position),
						distance = math.round(dist * 100) / 100,
						health = hum and hum.Health or nil,
						maxHealth = hum and hum.MaxHealth or nil,
					})
				end
			end
		end
	end

	table.sort(playersOut, function(a, b)
		return a.distance < b.distance
	end)
	while #playersOut > maxResults do
		table.remove(playersOut)
	end

	return {
		origin = Vector3ToTable(origin),
		radius = radius,
		count = #playersOut,
		players = playersOut,
	}
end

function ToolHandlers.GetNearbyInteractables(args)
	local origin = GetOriginPosition(nil)
	local radius = ClampNumber(args.radius, 80, 1, Config.MaxRadius)
	local maxResults = ClampNumber(args.maxResults, 25, 1, Config.MaxResults)

	local items = {}
	for _, desc in ipairs(Workspace:GetDescendants()) do
		local kind = nil
		if desc:IsA("ProximityPrompt") then
			kind = "ProximityPrompt"
		elseif desc:IsA("ClickDetector") then
			kind = "ClickDetector"
		elseif desc:IsA("TouchTransmitter") then
			kind = "TouchInterest"
		elseif desc:IsA("Seat") or desc:IsA("VehicleSeat") then
			kind = desc.ClassName
		end

		if kind then
			local pos = GetWorldPositionOfInstance(desc)
			if pos then
				local dist = (pos - origin).Magnitude
				if dist <= radius then
					local entry: any = {
						kind = kind,
						name = desc.Name,
						path = GetInstancePath(desc),
						parentName = desc.Parent and desc.Parent.Name or nil,
						position = Vector3ToTable(pos),
						distance = math.round(dist * 100) / 100,
					}
					if desc:IsA("ProximityPrompt") then
						entry.enabled = desc.Enabled
						entry.actionText = desc.ActionText
						entry.objectText = desc.ObjectText
					elseif desc:IsA("ClickDetector") then
						entry.maxActivationDistance = desc.MaxActivationDistance
					end
					table.insert(items, entry)
				end
			end
		end
	end

	table.sort(items, function(a, b)
		return a.distance < b.distance
	end)
	while #items > maxResults do
		table.remove(items)
	end

	return {
		origin = Vector3ToTable(origin),
		radius = radius,
		count = #items,
		interactables = items,
	}
end

function ToolHandlers.GetNearbyPrompts(args)
	local origin = GetOriginPosition(nil)
	local radius = ClampNumber(args.radius, 80, 1, Config.MaxRadius)
	local maxResults = ClampNumber(args.maxResults, 25, 1, Config.MaxResults)
	local onlyEnabled = args.onlyEnabled ~= false

	local prompts = {}
	for _, desc in ipairs(Workspace:GetDescendants()) do
		if desc:IsA("ProximityPrompt") then
			if not onlyEnabled or desc.Enabled then
				local pos = GetWorldPositionOfInstance(desc)
				if pos then
					local dist = (pos - origin).Magnitude
					if dist <= radius then
						table.insert(prompts, {
							name = desc.Name,
							path = GetInstancePath(desc),
							actionText = desc.ActionText,
							objectText = desc.ObjectText,
							enabled = desc.Enabled,
							holdDuration = desc.HoldDuration,
							maxActivationDistance = desc.MaxActivationDistance,
							position = Vector3ToTable(pos),
							distance = math.round(dist * 100) / 100,
						})
					end
				end
			end
		end
	end

	table.sort(prompts, function(a, b)
		return a.distance < b.distance
	end)
	while #prompts > maxResults do
		table.remove(prompts)
	end

	return {
		origin = Vector3ToTable(origin),
		radius = radius,
		count = #prompts,
		prompts = prompts,
	}
end

function ToolHandlers.GetNearestObject(args)
	local origin = GetOriginPosition(nil)
	local maxRadius = ClampNumber(args.maxRadius, 300, 1, Config.MaxRadius)
	local nameQuery = args.nameContains and string.lower(args.nameContains) or nil
	local classFilter = args.className
	local tagName = args.tagName

	local pool = tagName and CollectionService:GetTagged(tagName) or Workspace:GetDescendants()
	local best: any = nil
	local bestDist = maxRadius + 0.001

	for _, inst in ipairs(pool) do
		local classOk = (not classFilter) or inst:IsA(classFilter) or (inst.ClassName == classFilter)
		local nameOk = (not nameQuery) or (string.find(string.lower(inst.Name), nameQuery, 1, true) ~= nil)
		if classOk and nameOk then
			local pos = GetWorldPositionOfInstance(inst)
			if pos then
				local dist = (pos - origin).Magnitude
				if dist < bestDist then
					bestDist = dist
					best = {
						name = inst.Name,
						className = inst.ClassName,
						path = GetInstancePath(inst),
						position = Vector3ToTable(pos),
						distance = math.round(dist * 100) / 100,
					}
				end
			end
		end
	end

	return {
		found = best ~= nil,
		object = best,
	}
end

function ToolHandlers.GetObjectsInRadius(args)
	local origin = GetOriginPosition(args.origin)
	local radius = ClampNumber(args.radius, 60, 1, Config.MaxRadius)
	local maxResults = ClampNumber(args.maxResults, 25, 1, Config.MaxResults)
	local nameQuery = args.nameContains and string.lower(args.nameContains) or nil
	local classFilter = args.className

	local items = {}
	for _, desc in ipairs(Workspace:GetDescendants()) do
		if desc:IsA("BasePart") or desc:IsA("Model") or desc:IsA("ProximityPrompt") then
			local classOk = (not classFilter) or desc:IsA(classFilter) or (desc.ClassName == classFilter)
			local nameOk = (not nameQuery) or (string.find(string.lower(desc.Name), nameQuery, 1, true) ~= nil)
			if classOk and nameOk then
				local pos = GetWorldPositionOfInstance(desc)
				if pos then
					local dist = (pos - origin).Magnitude
					if dist <= radius then
						table.insert(items, {
							name = desc.Name,
							className = desc.ClassName,
							path = GetInstancePath(desc),
							position = Vector3ToTable(pos),
							distance = math.round(dist * 100) / 100,
						})
					end
				end
			end
		end
	end

	table.sort(items, function(a, b)
		return a.distance < b.distance
	end)
	while #items > maxResults do
		table.remove(items)
	end

	return {
		origin = Vector3ToTable(origin),
		radius = radius,
		count = #items,
		objects = items,
	}
end

function ToolHandlers.GetNavigationPath(args)
	local _, _, _, root = GetLocalCharacterParts()
	if not root then
		error("LocalPlayer character HumanoidRootPart is not available.")
	end

	local targetPos: Vector3? = nil
	if args.targetPosition then
		targetPos = TableToVector3(args.targetPosition)
	elseif args.targetPath then
		local targetInst = ResolveInstancePath(args.targetPath)
		if not targetInst then
			error("Target instance not found: " .. tostring(args.targetPath))
		end
		targetPos = GetWorldPositionOfInstance(targetInst)
	end

	if not targetPos then
		error("Could not determine target position for pathfinding.")
	end

	local path = PathfindingService:CreatePath({
		AgentRadius = ClampNumber(args.agentRadius, 2, 0.5, 10),
		AgentHeight = ClampNumber(args.agentHeight, 5, 1, 20),
		AgentCanJump = args.agentCanJump ~= false,
	})

	local ok, err = pcall(function()
		path:ComputeAsync(root.Position, targetPos :: Vector3)
	end)
	if not ok then
		error("PathfindingService ComputeAsync failed: " .. tostring(err))
	end

	local rawWaypoints = path:GetWaypoints()
	local waypoints = {}
	for i, wp in ipairs(rawWaypoints) do
		if i > 150 then
			break
		end
		table.insert(waypoints, {
			position = Vector3ToTable(wp.Position),
			action = tostring(wp.Action),
		})
	end

	return {
		available = path.Status == Enum.PathStatus.Success,
		status = tostring(path.Status),
		startPosition = Vector3ToTable(root.Position),
		targetPosition = Vector3ToTable(targetPos),
		waypointCount = #waypoints,
		waypoints = waypoints,
	}
end

function ToolHandlers.GetMapOverview(args)
	local maxLandmarks = ClampNumber(args.maxLandmarks, 25, 5, 60)
	local spawns = {}
	local landmarks = {}

	for _, child in ipairs(Workspace:GetChildren()) do
		if child:IsA("SpawnLocation") then
			table.insert(spawns, {
				name = child.Name,
				path = GetInstancePath(child),
				position = Vector3ToTable(child.Position),
			})
		elseif (child:IsA("Model") or child:IsA("Folder")) and not Players:GetPlayerFromCharacter(child) then
			if #landmarks < maxLandmarks then
				local pos = GetWorldPositionOfInstance(child)
				table.insert(landmarks, {
					name = child.Name,
					className = child.ClassName,
					path = GetInstancePath(child),
					childCount = #child:GetChildren(),
					position = pos and Vector3ToTable(pos) or nil,
				})
			end
		end
	end

	for _, desc in ipairs(Workspace:GetDescendants()) do
		if desc:IsA("SpawnLocation") and #spawns < 20 then
			local already = false
			local p = GetInstancePath(desc)
			for _, sp in ipairs(spawns) do
				if sp.path == p then
					already = true
					break
				end
			end
			if not already then
				table.insert(spawns, {
					name = desc.Name,
					path = p,
					position = Vector3ToTable(desc.Position),
				})
			end
		end
	end

	return {
		spawnCount = #spawns,
		spawns = spawns,
		landmarkCount = #landmarks,
		landmarks = landmarks,
	}
end

-- C. Movement and Navigation (25 - 35)
function ToolHandlers.MoveTo(args, requestId)
	local _, _, humanoid, root = GetLocalCharacterParts()
	if not humanoid or not root then
		error("LocalPlayer character is not available.")
	end

	local targetPos: Vector3? = nil
	if args.targetPosition then
		targetPos = TableToVector3(args.targetPosition)
	elseif args.targetPath then
		local inst = ResolveInstancePath(args.targetPath)
		if not inst then
			error("Target instance not found: " .. tostring(args.targetPath))
		end
		targetPos = GetWorldPositionOfInstance(inst)
	end
	if not targetPos then
		error("Unable to resolve target position.")
	end

	local stopDist = ClampNumber(args.stopDistance, 3, 0.5, 25)
	local timeoutSec = ClampNumber(args.timeoutSeconds, 15, 1, 45)
	local usePathfinding = args.usePathfinding ~= false
	local waitForArrival = args.waitForArrival ~= false

	local waypointsList: { Vector3 } = { targetPos }
	local pathStatus = "Direct"

	if usePathfinding then
		local path = PathfindingService:CreatePath({ AgentRadius = 2, AgentHeight = 5, AgentCanJump = true })
		local ok = pcall(function()
			path:ComputeAsync(root.Position, targetPos :: Vector3)
		end)
		if ok and path.Status == Enum.PathStatus.Success then
			local computed = path:GetWaypoints()
			if #computed > 0 then
				waypointsList = {}
				for _, wp in ipairs(computed) do
					table.insert(waypointsList, wp.Position)
				end
				pathStatus = tostring(path.Status)
			end
		else
			pathStatus = ok and tostring(path.Status) or "FallbackDirect"
		end
	end

	if not waitForArrival then
		task.spawn(function()
			ExecuteWaypointFollow(waypointsList, stopDist, timeoutSec, requestId)
		end)
		return {
			started = true,
			pathStatus = pathStatus,
			waypointCount = #waypointsList,
			targetPosition = Vector3ToTable(targetPos),
		}
	end

	local execOk, resultOrErr = ExecuteWaypointFollow(waypointsList, stopDist, timeoutSec, requestId)
	if not execOk then
		error(resultOrErr.message)
	end
	resultOrErr.pathStatus = pathStatus
	resultOrErr.waypointCount = #waypointsList
	return resultOrErr
end

function ToolHandlers.MoveDirection(args, requestId)
	local _, _, humanoid, root = GetLocalCharacterParts()
	if not humanoid or not root then
		error("LocalPlayer character is not available.")
	end

	local dir = TableToVector3(args.direction)
	if dir.Magnitude < 0.001 then
		error("Direction vector cannot be zero.")
	end
	dir = dir.Unit

	local duration = ClampNumber(args.durationSeconds, 1, 0.1, 10)
	local relCam = args.relativeToCamera == true

	State.MovementToken += 1
	local token = State.MovementToken
	State.ActiveMovement.Active = true
	State.ActiveMovement.Mode = "move_direction"
	State.ActiveMovement.StartedAt = os.clock()

	local startTime = os.clock()
	while os.clock() - startTime < duration do
		if State.MovementToken ~= token or IsRequestCancelled(requestId) then
			break
		end
		humanoid:Move(dir, relCam)
		task.wait(0.05)
	end

	if State.MovementToken == token then
		humanoid:Move(Vector3.zero, false)
		State.ActiveMovement.Active = false
		State.ActiveMovement.Mode = "idle"
	end

	return {
		completed = State.MovementToken == token,
		finalPosition = Vector3ToTable(root.Position),
	}
end

function ToolHandlers.StopMovement()
	StopActiveMovement()
	return { stopped = true }
end

function ToolHandlers.Jump()
	local _, _, humanoid = GetLocalCharacterParts()
	if not humanoid then
		error("LocalPlayer Humanoid is not available.")
	end
	humanoid.Jump = true
	return { jumped = true }
end

function ToolHandlers.FacePosition(args)
	local _, _, _, root = GetLocalCharacterParts()
	if not root then
		error("LocalPlayer HumanoidRootPart is not available.")
	end

	local targetPos: Vector3? = nil
	if args.targetPosition then
		targetPos = TableToVector3(args.targetPosition)
	elseif args.targetPath then
		local inst = ResolveInstancePath(args.targetPath)
		if not inst then
			error("Target instance not found: " .. tostring(args.targetPath))
		end
		targetPos = GetWorldPositionOfInstance(inst)
	end
	if not targetPos then
		error("Could not resolve target position.")
	end

	local flatTarget = Vector3.new(targetPos.X, root.Position.Y, targetPos.Z)
	if (flatTarget - root.Position).Magnitude > 0.01 then
		root.CFrame = CFrame.lookAt(root.Position, flatTarget)
	end

	return {
		facing = Vector3ToTable(root.CFrame.LookVector),
		targetPosition = Vector3ToTable(targetPos),
	}
end

function ToolHandlers.FollowPath(args, requestId)
	local waypointsList = {}
	for _, wp in ipairs(args.waypoints) do
		table.insert(waypointsList, TableToVector3(wp))
	end
	local stopDist = ClampNumber(args.stopDistance, 3, 0.5, 20)
	local timeoutSec = ClampNumber(args.timeoutSeconds, 20, 1, 45)
	local execOk, resultOrErr = ExecuteWaypointFollow(waypointsList, stopDist, timeoutSec, requestId)
	if not execOk then
		error(resultOrErr.message)
	end
	return resultOrErr
end

function ToolHandlers.CancelMovement()
	StopActiveMovement()
	return { cancelled = true }
end

function ToolHandlers.GetMovementStatus()
	local _, _, humanoid, root = GetLocalCharacterParts()
	return {
		active = State.ActiveMovement.Active,
		mode = State.ActiveMovement.Mode,
		targetPosition = State.ActiveMovement.TargetPosition,
		waypointsRemaining = State.ActiveMovement.WaypointsRemaining,
		position = root and Vector3ToTable(root.Position) or nil,
		speed = root and math.round(root.AssemblyLinearVelocity.Magnitude * 100) / 100 or 0,
		humanoidState = humanoid and tostring(humanoid:GetState()) or nil,
	}
end

function ToolHandlers.GetDistanceTo(args)
	local _, _, _, root = GetLocalCharacterParts()
	if not root then
		error("LocalPlayer HumanoidRootPart is not available.")
	end
	local targetPos: Vector3? = nil
	if args.targetPosition then
		targetPos = TableToVector3(args.targetPosition)
	elseif args.targetPath then
		local inst = ResolveInstancePath(args.targetPath)
		if not inst then
			error("Target instance not found: " .. tostring(args.targetPath))
		end
		targetPos = GetWorldPositionOfInstance(inst)
	end
	if not targetPos then
		error("Could not resolve target position.")
	end

	local delta = targetPos - root.Position
	local horizontal = Vector3.new(delta.X, 0, delta.Z).Magnitude
	return {
		distance = math.round(delta.Magnitude * 1000) / 1000,
		horizontalDistance = math.round(horizontal * 1000) / 1000,
		verticalDelta = math.round(delta.Y * 1000) / 1000,
		origin = Vector3ToTable(root.Position),
		target = Vector3ToTable(targetPos),
	}
end

function ToolHandlers.WaitForObject(args, requestId)
	local root = ResolveInstancePath(args.rootPath or "Workspace")
	if not root then
		error("Root instance not found: " .. tostring(args.rootPath))
	end
	local targetName = args.name
	local timeoutSec = ClampNumber(args.timeoutSeconds, 10, 0.5, 25)
	local startTime = os.clock()

	while os.clock() - startTime < timeoutSec do
		if IsRequestCancelled(requestId) then
			return { found = false, cancelled = true }
		end
		local found = root:FindFirstChild(targetName, true)
		if found then
			local pos = GetWorldPositionOfInstance(found)
			return {
				found = true,
				name = found.Name,
				className = found.ClassName,
				path = GetInstancePath(found),
				position = pos and Vector3ToTable(pos) or nil,
				elapsedSeconds = math.round((os.clock() - startTime) * 100) / 100,
			}
		end
		task.wait(0.2)
	end

	return {
		found = false,
		timedOut = true,
		elapsedSeconds = timeoutSec,
	}
end

function ToolHandlers.WaitForStateChange(args, requestId)
	local watchType = args.watchType
	local timeoutSec = ClampNumber(args.timeoutSeconds, 10, 0.5, 25)
	local startTime = os.clock()

	local _, _, humanoid, root = GetLocalCharacterParts()
	if watchType == "humanoid_state" then
		if not humanoid then error("Humanoid unavailable") end
		local initial = tostring(humanoid:GetState())
		while os.clock() - startTime < timeoutSec do
			if IsRequestCancelled(requestId) then return { changed = false, cancelled = true } end
			local curr = tostring(humanoid:GetState())
			if curr ~= initial then
				return { changed = true, previous = initial, current = curr }
			end
			task.wait(0.1)
		end
		return { changed = false, timedOut = true, current = initial }
	elseif watchType == "health" then
		if not humanoid then error("Humanoid unavailable") end
		local initial = humanoid.Health
		while os.clock() - startTime < timeoutSec do
			if IsRequestCancelled(requestId) then return { changed = false, cancelled = true } end
			if math.abs(humanoid.Health - initial) > 0.01 then
				return { changed = true, previous = initial, current = humanoid.Health }
			end
			task.wait(0.1)
		end
		return { changed = false, timedOut = true, current = initial }
	elseif watchType == "position_moved" then
		if not root then error("HumanoidRootPart unavailable") end
		local initial = root.Position
		while os.clock() - startTime < timeoutSec do
			if IsRequestCancelled(requestId) then return { changed = false, cancelled = true } end
			if (root.Position - initial).Magnitude >= 1.5 then
				return { changed = true, previous = Vector3ToTable(initial), current = Vector3ToTable(root.Position) }
			end
			task.wait(0.1)
		end
		return { changed = false, timedOut = true }
	elseif watchType == "attribute" then
		local inst = ResolveInstancePath(args.instancePath or "")
		if not inst or not args.attributeName then
			error("instancePath and attributeName are required for attribute watch.")
		end
		local initial = inst:GetAttribute(args.attributeName)
		while os.clock() - startTime < timeoutSec do
			if IsRequestCancelled(requestId) then return { changed = false, cancelled = true } end
			local curr = inst:GetAttribute(args.attributeName)
			if curr ~= initial then
				return { changed = true, previous = SafeSerializeValue(initial), current = SafeSerializeValue(curr) }
			end
			task.wait(0.15)
		end
		return { changed = false, timedOut = true }
	end

	error("Unsupported watchType: " .. tostring(watchType))
end

-- D. Interaction (36 - 42)
function ToolHandlers.InteractWithPrompt(args)
	local inst = ResolveInstancePath(args.promptPath)
	if not inst or not inst:IsA("ProximityPrompt") then
		error("ProximityPrompt not found at: " .. tostring(args.promptPath))
	end
	if not inst.Enabled then
		error("ProximityPrompt is currently disabled.")
	end
	if type(fireproximityprompt) ~= "function" then
		error("Executor does not support fireproximityprompt.")
	end

	local pos = GetWorldPositionOfInstance(inst)
	local _, _, _, root = GetLocalCharacterParts()
	local distance = (pos and root) and (pos - root.Position).Magnitude or nil

	local ok, err = pcall(fireproximityprompt, inst, args.holdDurationOverride)
	if not ok then
		error("fireproximityprompt failed: " .. tostring(err))
	end

	return {
		triggered = true,
		promptPath = GetInstancePath(inst),
		actionText = inst.ActionText,
		objectText = inst.ObjectText,
		distance = distance and (math.round(distance * 100) / 100) or nil,
	}
end

function ToolHandlers.InspectInteractable(args)
	local inst = ResolveInstancePath(args.instancePath)
	if not inst then
		error("Instance not found: " .. tostring(args.instancePath))
	end

	local _, _, _, root = GetLocalCharacterParts()
	local pos = GetWorldPositionOfInstance(inst)
	local dist = (pos and root) and (pos - root.Position).Magnitude or nil

	local prompt = inst:IsA("ProximityPrompt") and inst or inst:FindFirstChildWhichIsA("ProximityPrompt", true)
	local clickDetector = inst:IsA("ClickDetector") and inst or inst:FindFirstChildWhichIsA("ClickDetector", true)
	local touchTransmitter = inst:IsA("TouchTransmitter") and inst or inst:FindFirstChildWhichIsA("TouchTransmitter", true)

	local actionsPerformed = {}

	if args.triggerTouchInterest == true and touchTransmitter then
		if type(firetouchinterest) ~= "function" then
			error("Executor does not support firetouchinterest.")
		end
		if not root then
			error("LocalPlayer HumanoidRootPart is unavailable for touch interaction.")
		end
		local touchPart = touchTransmitter.Parent
		if touchPart and touchPart:IsA("BasePart") then
			pcall(firetouchinterest, root, touchPart, 0)
			task.wait(0.05)
			pcall(firetouchinterest, root, touchPart, 1)
			table.insert(actionsPerformed, "firetouchinterest")
		end
	end

	if args.triggerClickDetector == true and clickDetector then
		if type(fireclickdetector) ~= "function" then
			error("Executor does not support fireclickdetector.")
		end
		pcall(fireclickdetector, clickDetector)
		table.insert(actionsPerformed, "fireclickdetector")
	end

	return {
		name = inst.Name,
		className = inst.ClassName,
		path = GetInstancePath(inst),
		position = pos and Vector3ToTable(pos) or nil,
		distance = dist and (math.round(dist * 100) / 100) or nil,
		hasProximityPrompt = prompt ~= nil,
		promptPath = prompt and GetInstancePath(prompt) or nil,
		hasClickDetector = clickDetector ~= nil,
		clickDetectorPath = clickDetector and GetInstancePath(clickDetector) or nil,
		hasTouchInterest = touchTransmitter ~= nil,
		actionsPerformed = actionsPerformed,
	}
end

function ToolHandlers.InspectGui(args)
	local inst = ResolveInstancePath(args.guiPath)
	if not inst then
		local lp = Players.LocalPlayer
		local pg = lp and lp:FindFirstChild("PlayerGui")
		if pg then
			inst = pg:FindFirstChild(args.guiPath, true)
		end
	end
	if not inst then
		error("GUI instance not found: " .. tostring(args.guiPath))
	end

	local maxDepth = ClampNumber(args.maxDepth, 5, 1, 10)
	local counter = { count = 0, max = 100 }
	return SerializeGuiNode(inst, 1, maxDepth, true, counter)
end

function ToolHandlers.ClickVisibleGuiButton(args)
	local inst = ResolveInstancePath(args.buttonPath)
	if not inst then
		local lp = Players.LocalPlayer
		local pg = lp and lp:FindFirstChild("PlayerGui")
		if pg then
			inst = pg:FindFirstChild(args.buttonPath, true)
		end
	end
	if not inst or not inst:IsA("GuiButton") then
		error("GuiButton not found at: " .. tostring(args.buttonPath))
	end
	if not inst.Visible then
		error("Target GuiButton is not visible.")
	end

	-- Prefer normal input simulation via VirtualInputManager
	local clickedVia = nil
	local vimOk, vim = pcall(function()
		return game:GetService("VirtualInputManager")
	end)
	if vimOk and vim then
		local absPos = inst.AbsolutePosition
		local absSize = inst.AbsoluteSize
		local cx = absPos.X + (absSize.X / 2)
		local cy = absPos.Y + (absSize.Y / 2) + 36
		pcall(function()
			vim:SendMouseButtonEvent(cx, cy, 0, true, game, 1)
			task.wait(0.04)
			vim:SendMouseButtonEvent(cx, cy, 0, false, game, 1)
		end)
		clickedVia = "VirtualInputManager"
	elseif type(firesignal) == "function" then
		pcall(firesignal, inst.MouseButton1Click)
		pcall(firesignal, inst.Activated)
		clickedVia = "firesignal"
	else
		error("Neither VirtualInputManager nor firesignal is available to click the button.")
	end

	return {
		clicked = true,
		method = clickedVia,
		buttonPath = GetInstancePath(inst),
		text = (inst:IsA("TextButton") and inst.Text) or nil,
	}
end

function ToolHandlers.GetAvailableTools(args)
	local lp, char, humanoid = GetLocalCharacterParts()
	if not lp then
		error("LocalPlayer unavailable.")
	end

	local equipped = {}
	local backpackTools = {}

	if char then
		for _, child in ipairs(char:GetChildren()) do
			if child:IsA("Tool") then
				table.insert(equipped, {
					name = child.Name,
					toolTip = child.ToolTip,
					path = GetInstancePath(child),
				})
			end
		end
	end

	local backpack = lp:FindFirstChild("Backpack")
	if backpack then
		for _, child in ipairs(backpack:GetChildren()) do
			if child:IsA("Tool") then
				if args.equipToolName and child.Name == args.equipToolName and humanoid then
					pcall(function()
						humanoid:EquipTool(child)
					end)
				end
				table.insert(backpackTools, {
					name = child.Name,
					toolTip = child.ToolTip,
					path = GetInstancePath(child),
				})
			end
		end
	end

	return {
		equipped = equipped,
		backpack = backpackTools,
	}
end

function ToolHandlers.GetCurrentTasks()
	local lp = Players.LocalPlayer
	if not lp then
		error("LocalPlayer unavailable.")
	end

	local leaderstatsOut = {}
	local ls = lp:FindFirstChild("leaderstats")
	if ls then
		for _, valObj in ipairs(ls:GetChildren()) do
			if valObj:IsA("ValueBase") then
				leaderstatsOut[valObj.Name] = SafeSerializeValue((valObj :: any).Value)
			end
		end
	end

	local taskTexts = {}
	local pg = lp:FindFirstChild("PlayerGui")
	if pg then
		for _, desc in ipairs(pg:GetDescendants()) do
			if (desc:IsA("TextLabel") or desc:IsA("TextButton")) and desc.Visible and #desc.Text > 0 then
				local lowerName = string.lower(desc.Name)
				local lowerParent = desc.Parent and string.lower(desc.Parent.Name) or ""
				if string.find(lowerName, "quest")
					or string.find(lowerName, "task")
					or string.find(lowerName, "objective")
					or string.find(lowerParent, "quest")
					or string.find(lowerParent, "task")
					or string.find(lowerParent, "objective") then
					table.insert(taskTexts, {
						path = GetInstancePath(desc),
						text = desc.Text,
					})
					if #taskTexts >= 30 then
						break
					end
				end
			end
		end
	end

	return {
		leaderstats = leaderstatsOut,
		visibleTaskLabels = taskTexts,
	}
end

function ToolHandlers.GetExecutorCapabilities()
	return Capabilities
end

-- E. Code Execution (43)
function ToolHandlers.ExecuteLuau(args, requestId)
	if type(loadstring) ~= "function" then
		error("Executor does not expose loadstring.")
	end

	local code = args.code
	if type(code) ~= "string" or #code == 0 then
		error("code must be a non-empty string.")
	end

	local timeoutMs = ClampNumber(args.timeoutMs, 5000, 250, 15000)
	local compileFn, compileErr = loadstring(code)
	if not compileFn then
		return {
			compiled = false,
			output = {},
			runtimeError = tostring(compileErr),
			durationMs = 0,
		}
	end

	local logs = {}
	local totalChars = 0
	local function AppendLog(prefix: string, ...)
		if totalChars >= 65536 then
			return
		end
		local parts = {}
		for i = 1, select("#", ...) do
			table.insert(parts, tostring(select(i, ...)))
		end
		local line = prefix .. table.concat(parts, "\t")
		totalChars += #line
		if #logs < 200 then
			table.insert(logs, line)
		end
	end

	local sandboxEnv = setmetatable({
		print = function(...)
			AppendLog("", ...)
		end,
		warn = function(...)
			AppendLog("[WARN] ", ...)
		end,
		IsCancelled = function()
			return IsRequestCancelled(requestId)
		end,
	}, { __index = getfenv and getfenv() or _G })

	if setfenv then
		pcall(setfenv, compileFn, sandboxEnv)
	end

	local done = false
	local execOk = false
	local returnValues = {}
	local tracebackStr = nil
	local startClock = os.clock()

	task.spawn(function()
		local results = table.pack(xpcall(compileFn, function(err)
			return tostring(err) .. "\n" .. debug.traceback("", 2)
		end))
		execOk = results[1] == true
		if execOk then
			for i = 2, results.n do
				table.insert(returnValues, SafeSerializeValue(results[i]))
			end
		else
			tracebackStr = tostring(results[2])
		end
		done = true
	end)

	local deadline = startClock + (timeoutMs / 1000)
	while not done and os.clock() < deadline do
		if IsRequestCancelled(requestId) then
			return {
				compiled = true,
				cancelled = true,
				output = logs,
				durationMs = math.round((os.clock() - startClock) * 1000),
			}
		end
		task.wait(0.02)
	end

	if not done then
		return {
			compiled = true,
			timedOut = true,
			output = logs,
			runtimeError = string.format("ExecuteLuau timed out after %d ms", timeoutMs),
			durationMs = timeoutMs,
		}
	end

	return {
		compiled = true,
		succeeded = execOk,
		output = logs,
		returnValues = execOk and returnValues or nil,
		runtimeError = not execOk and tracebackStr or nil,
		durationMs = math.round((os.clock() - startClock) * 1000),
	}
end

-- ============================================================================
-- TASK EXECUTION & BRIDGE LOOP
-- ============================================================================
local function HandleTask(taskObj)
	local requestId = taskObj.requestId
	local sessionId = taskObj.sessionId
	local toolName = taskObj.toolName
	local args = taskObj.args or {}

	if not requestId or State.ProcessedRequests[requestId] then
		return
	end
	MarkRequestProcessed(requestId)

	local handler = ToolHandlers[toolName]
	if not handler then
		SendHttp("POST", "/api/v1/executor/result", {
			sessionId = sessionId,
			executorId = State.ExecutorId,
			requestId = requestId,
			ok = false,
			error = {
				code = "UNSUPPORTED_TOOL",
				message = "Tool not implemented on executor: " .. tostring(toolName),
			},
			durationMs = 0,
		})
		return
	end

	local startedAt = os.clock()
	local ok, resultOrErr = xpcall(function()
		return handler(args, requestId)
	end, function(err)
		return {
			message = tostring(err),
			traceback = debug.traceback("", 2),
		}
	end)
	local durationMs = math.round((os.clock() - startedAt) * 1000)

	if ok then
		local payload = {
			sessionId = sessionId,
			executorId = State.ExecutorId,
			requestId = requestId,
			ok = true,
			data = resultOrErr,
			durationMs = durationMs,
			truncated = false,
		}
		local encodedOk, encoded = pcall(function()
			return HttpService:JSONEncode(payload)
		end)
		if encodedOk and #encoded > Config.MaxResultBytes then
			SendHttp("POST", "/api/v1/executor/result", {
				sessionId = sessionId,
				executorId = State.ExecutorId,
				requestId = requestId,
				ok = false,
				error = {
					code = "PAYLOAD_TOO_LARGE",
					message = string.format("Result size (%d bytes) exceeded MaxResultBytes (%d). Use smaller radius or limit.", #encoded, Config.MaxResultBytes),
				},
				durationMs = durationMs,
			})
			return
		end
		SendHttp("POST", "/api/v1/executor/result", payload)
	else
		local errObj = type(resultOrErr) == "table" and resultOrErr or { message = tostring(resultOrErr) }
		SendHttp("POST", "/api/v1/executor/result", {
			sessionId = sessionId,
			executorId = State.ExecutorId,
			requestId = requestId,
			ok = false,
			error = {
				code = "EXECUTOR_RUNTIME_ERROR",
				message = errObj.message or "Unknown error",
				traceback = errObj.traceback,
			},
			durationMs = durationMs,
		})
	end
end

local function HandleControlSignal(sig)
	if type(sig) ~= "table" then
		return
	end
	if sig.type == "EMERGENCY_STOP" then
		warn("[RobloxAIBridge] EMERGENCY STOP received from server. Halting movement.")
		StopActiveMovement()
	elseif sig.type == "CANCEL_REQUEST" and sig.requestId then
		State.CancelledRequests[sig.requestId] = true
	elseif sig.type == "DISCONNECT" then
		warn("[RobloxAIBridge] Disconnect signal received: " .. tostring(sig.reason))
		StopActiveMovement()
		State.Connected = false
	end
end

local function RegisterExecutor(): boolean
	local lp = Players.LocalPlayer
	local gameInfoOk, gameInfo = pcall(ToolHandlers.GetGameInfo)
	local ok, _, data, errMsg = SendHttp("POST", "/api/v1/executor/register", {
		sessionId = State.SessionId,
		executorName = Capabilities.executorIdentity,
		placeId = game.PlaceId,
		jobId = game.JobId,
		gameName = (gameInfoOk and gameInfo.gameName) or "Roblox Experience",
		playerName = lp and lp.Name or nil,
		playerUserId = lp and lp.UserId or nil,
		capabilities = Capabilities,
	})

	if not ok or type(data) ~= "table" then
		warn("[RobloxAIBridge] Registration failed: " .. tostring(errMsg))
		return false
	end

	State.SessionId = data.sessionId
	State.ExecutorId = data.executorId
	State.Connected = true
	print(string.format("[RobloxAIBridge] Connected! SessionId=%s ExecutorId=%s", tostring(State.SessionId), tostring(State.ExecutorId)))
	return true
end

-- Expose clean control handle
_G.RobloxAIBridge = {
	Stop = function(reason: string?)
		State.Running = false
		StopActiveMovement()
		if State.Connected and State.SessionId then
			pcall(SendHttp, "POST", "/api/v1/session/disconnect", {
				sessionId = State.SessionId,
				target = "executor",
				reason = reason or "Stopped locally",
			})
		end
		State.Connected = false
		print("[RobloxAIBridge] Client stopped.")
	end,
	GetStatus = function()
		return {
			running = State.Running,
			connected = State.Connected,
			sessionId = State.SessionId,
			executorId = State.ExecutorId,
			capabilities = Capabilities,
		}
	end,
}

-- Heartbeat loop
task.spawn(function()
	while State.Running do
		if State.Connected and State.SessionId then
			local ok, statusCode, _, errMsg = SendHttp("POST", "/api/v1/executor/heartbeat", {
				sessionId = State.SessionId,
				executorId = State.ExecutorId,
				placeId = game.PlaceId,
				jobId = game.JobId,
			})
			if not ok then
				warn(string.format("[RobloxAIBridge] Heartbeat failed (%d): %s", statusCode, tostring(errMsg)))
				if statusCode == 404 or statusCode == 409 then
					State.Connected = false
				end
			end
		end
		task.wait(Config.HeartbeatIntervalSeconds)
	end
end)

-- Main poll + reconnect loop
task.spawn(function()
	local backoff = Config.ReconnectMinSeconds
	while State.Running do
		if not State.Connected then
			if RegisterExecutor() then
				backoff = Config.ReconnectMinSeconds
			else
				task.wait(backoff)
				backoff = math.min(Config.ReconnectMaxSeconds, backoff * 2)
				continue
			end
		end

		local ok, statusCode, data, errMsg = SendHttp("POST", "/api/v1/executor/poll", {
			sessionId = State.SessionId,
			executorId = State.ExecutorId,
			waitMs = Config.PollWaitMs,
			maxTasks = 5,
		})

		if not ok then
			warn(string.format("[RobloxAIBridge] Poll error (%d): %s", statusCode, tostring(errMsg)))
			State.Connected = false
			task.wait(backoff)
			backoff = math.min(Config.ReconnectMaxSeconds, backoff * 2)
		else
			backoff = Config.ReconnectMinSeconds
			if type(data) == "table" then
				if data.disconnected then
					State.Connected = false
				end
				if type(data.controlSignals) == "table" then
					for _, sig in ipairs(data.controlSignals) do
						HandleControlSignal(sig)
					end
				end
				if type(data.tasks) == "table" then
					for _, taskObj in ipairs(data.tasks) do
						task.spawn(HandleTask, taskObj)
					end
				end
			end
			task.wait(Config.PollLoopDelaySeconds)
		end
	end
end)
