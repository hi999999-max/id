#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# Roblox AI Executor Bridge - Idempotent VPS Installer
# Safe to rerun. Inspects OS, Node.js, services, and firewall before acting.
# Never modifies SSH configuration or unrelated services.
# =============================================================================

INSTALL_DIR="/opt/roblox-ai-bridge"
SERVICE_NAME="roblox-ai-bridge"
SERVICE_USER="robloxbridge"
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ $EUID -ne 0 ]]; then
  echo "ERROR: Please run install.sh as root (for example: sudo bash install.sh)"
  exit 1
fi

echo "=== [1/7] Inspecting VPS environment ==="
if [[ -f /etc/os-release ]]; then
  # shellcheck disable=SC1091
  source /etc/os-release
  echo "OS: ${PRETTY_NAME:-Unknown}"
else
  echo "OS: Unknown Linux"
fi
echo "Architecture: $(uname -m)"
echo "Kernel: $(uname -r)"

if ss -tlnp 2>/dev/null | grep -q ':3003 '; then
  echo "Notice: Port 3003 currently has a listener:"
  ss -tlnp | grep ':3003 ' || true
fi

echo "=== [2/7] Checking Node.js LTS (>= 20) ==="
NEED_NODE=0
if command -v node >/dev/null 2>&1; then
  NODE_MAJOR=$(node -v | sed 's/^v//' | cut -d. -f1)
  echo "Found Node.js $(node -v)"
  if [[ "$NODE_MAJOR" -lt 20 ]]; then
    NEED_NODE=1
  fi
else
  NEED_NODE=1
fi

if [[ "$NEED_NODE" -eq 1 ]]; then
  echo "Installing Node.js 20 LTS..."
  if command -v apt-get >/dev/null 2>&1; then
    apt-get update -y
    DEBIAN_FRONTEND=noninteractive apt-get install -y ca-certificates curl gnupg
    mkdir -p /etc/apt/keyrings
    curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | gpg --dearmor --yes -o /etc/apt/keyrings/nodesource.gpg
    echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_20.x nodistro main" > /etc/apt/sources.list.d/nodesource.list
    apt-get update -y
    DEBIAN_FRONTEND=noninteractive apt-get install -y nodejs
  elif command -v dnf >/dev/null 2>&1; then
    curl -fsSL https://rpm.nodesource.com/setup_20.x | bash -
    dnf install -y nodejs
  else
    echo "ERROR: Could not auto-install Node.js 20 LTS on this package manager. Install Node.js >= 20 manually and rerun."
    exit 1
  fi
fi

echo "=== [3/7] Creating non-root service user (${SERVICE_USER}) ==="
if ! id -u "$SERVICE_USER" >/dev/null 2>&1; then
  useradd --system --home-dir "$INSTALL_DIR" --shell /usr/sbin/nologin "$SERVICE_USER"
  echo "Created system user ${SERVICE_USER}."
else
  echo "System user ${SERVICE_USER} already exists."
fi

echo "=== [4/7] Installing project files into ${INSTALL_DIR} ==="
mkdir -p "$INSTALL_DIR" "$INSTALL_DIR/certs"
if [[ "$SOURCE_DIR" != "$INSTALL_DIR" ]]; then
  # Copy files while preserving existing .env, certs, and wireguard-clients
  tar -C "$SOURCE_DIR" \
    --exclude='.env' \
    --exclude='node_modules' \
    --exclude='certs/*' \
    -cf - . | tar -C "$INSTALL_DIR" -xf -
fi

chmod +x "$INSTALL_DIR"/*.sh "$INSTALL_DIR"/scripts/*.sh 2>/dev/null || true

cd "$INSTALL_DIR"
echo "Installing npm production dependencies..."
if [[ -f package-lock.json ]]; then
  npm ci --omit=dev
else
  npm install --omit=dev
fi

echo "=== [5/7] Configuring .env and high-entropy credentials ==="
if [[ ! -f "$INSTALL_DIR/.env" ]]; then
  cp "$INSTALL_DIR/.env.example" "$INSTALL_DIR/.env"
  node "$INSTALL_DIR/scripts/generate-tokens.js"
  # Default to localhost if WireGuard isn't configured yet, or WireGuard IP if wg0 exists
  if ip link show wg0 >/dev/null 2>&1; then
    sed -i 's/^HOST=.*/HOST=10.66.66.1/' "$INSTALL_DIR/.env"
  else
    sed -i 's/^HOST=.*/HOST=127.0.0.1/' "$INSTALL_DIR/.env"
    echo ""
    echo "IMPORTANT SECURITY NOTE:"
    echo "  .env defaulted HOST=127.0.0.1 so plaintext tokens are never exposed publicly."
    echo "  Choose one of these secure options before connecting remote clients:"
    echo "    Option A (Recommended): Run 'sudo bash /opt/roblox-ai-bridge/scripts/setup-wireguard.sh'"
    echo "                          and set HOST=10.66.66.1 in /opt/roblox-ai-bridge/.env"
    echo "    Option B (Trusted IP TLS cert): Place server.crt and server.key in /opt/roblox-ai-bridge/certs/,"
    echo "                          set TLS_ENABLED=true and HOST=0.0.0.0 in .env"
    echo ""
  fi
else
  echo "Existing .env preserved. Checking for placeholder tokens..."
  node "$INSTALL_DIR/scripts/generate-tokens.js"
fi

chown -R "${SERVICE_USER}:${SERVICE_USER}" "$INSTALL_DIR"
chmod 600 "$INSTALL_DIR/.env"

echo "=== [6/7] Installing systemd service ==="
NODE_BIN=$(command -v node)
sed "s|/usr/bin/node|${NODE_BIN}|g" "$INSTALL_DIR/deploy/roblox-ai-bridge.service" > "/etc/systemd/system/${SERVICE_NAME}.service"
systemctl daemon-reload
systemctl enable "${SERVICE_NAME}.service"

echo "=== [7/7] Checking firewall (read-only unless WireGuard/TLS active) ==="
if command -v ufw >/dev/null 2>&1; then
  ufw status || true
elif command -v firewall-cmd >/dev/null 2>&1 && systemctl is-active --quiet firewalld; then
  firewall-cmd --list-all || true
fi

systemctl restart "${SERVICE_NAME}.service"
sleep 2

if systemctl is-active --quiet "${SERVICE_NAME}.service"; then
  echo "SUCCESS: ${SERVICE_NAME} is running!"
  systemctl --no-pager status "${SERVICE_NAME}.service" | head -n 15
else
  echo "WARNING: ${SERVICE_NAME} failed to stay active. Check logs with: bash ${INSTALL_DIR}/logs.sh"
  exit 1
fi
