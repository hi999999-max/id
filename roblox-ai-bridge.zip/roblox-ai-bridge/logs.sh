#!/usr/bin/env bash
set -euo pipefail

SERVICE_NAME="roblox-ai-bridge"
LINES="${1:-100}"

echo "Showing last ${LINES} log lines for ${SERVICE_NAME} (Ctrl+C to exit)..."
journalctl -u "${SERVICE_NAME}.service" -n "${LINES}" -f --no-pager
