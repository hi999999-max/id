#!/usr/bin/env bash
set -euo pipefail

INSTALL_DIR="/opt/roblox-ai-bridge"
SERVICE_NAME="roblox-ai-bridge"
SERVICE_USER="robloxbridge"
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ $EUID -ne 0 ]]; then
  echo "ERROR: Please run update.sh as root (for example: sudo bash update.sh)"
  exit 1
fi

echo "Updating ${SERVICE_NAME} in ${INSTALL_DIR} (preserving .env and certs)..."
if [[ "$SOURCE_DIR" != "$INSTALL_DIR" ]]; then
  tar -C "$SOURCE_DIR" \
    --exclude='.env' \
    --exclude='node_modules' \
    --exclude='certs/*' \
    -cf - . | tar -C "$INSTALL_DIR" -xf -
fi

chmod +x "$INSTALL_DIR"/*.sh "$INSTALL_DIR"/scripts/*.sh 2>/dev/null || true
cd "$INSTALL_DIR"

if [[ -f package-lock.json ]]; then
  npm ci --omit=dev
else
  npm install --omit=dev
fi

chown -R "${SERVICE_USER}:${SERVICE_USER}" "$INSTALL_DIR"
chmod 600 "$INSTALL_DIR/.env"

systemctl restart "${SERVICE_NAME}.service"
sleep 2
systemctl --no-pager status "${SERVICE_NAME}.service" | head -n 15
