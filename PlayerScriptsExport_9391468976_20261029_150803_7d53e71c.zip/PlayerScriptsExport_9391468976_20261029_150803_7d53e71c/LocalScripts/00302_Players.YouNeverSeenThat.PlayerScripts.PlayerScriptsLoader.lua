-- Original instance: Players.YouNeverSeenThat.PlayerScripts.PlayerScriptsLoader
-- Class: LocalScript
-- Decompiled output; accuracy is not guaranteed.

require(script.Parent:WaitForChild("PlayerModule"))