-- Original instance: Players.YouNeverSeenThat.PlayerScripts.KnitRunClient
-- Class: LocalScript
-- Decompiled output; accuracy is not guaranteed.

local v1 = require(game.ReplicatedStorage.Knit.Knit)
v1.AddControllersDeep(script.Parent:WaitForChild("Controllers"))
v1.Start({
	["ServicePromises"] = false
}):catch(warn)
print("Loaded Knit on client!")
require(game.ReplicatedStorage:WaitForChild("CmdrClient")):SetActivationKeys({ Enum.KeyCode.F2, Enum.KeyCode.Semicolon })
local v_u_2 = game.Players.LocalPlayer
local v_u_3 = {
	[1241352401] = true,
	[31070091] = true,
	[174332536] = true
}
local function v5(p4) -- name: checkList
	-- upvalues: (copy) v_u_3
	if v_u_3[p4.UserId] then
		p4:SetAttribute("HidePlayer", true)
	end
end
for _, v6 in game.Players:GetPlayers() do
	if not v_u_3[v6.UserId] then
		continue
	end
	v6:SetAttribute("HidePlayer", true)
end
game.Players.PlayerAdded:Connect(v5)
game:GetService("RunService").Stepped:Connect(function()
	-- upvalues: (copy) v_u_2
	for _, v7 in game.Players:GetPlayers() do
		if v7 == v_u_2 then
			continue
		end
		if v7:GetAttribute("HidePlayer") then
			v7.Parent = nil
		else
			if v7.Parent == game.Players then
				continue
			end
			v7.Parent = game.Players
		end
	end
end)