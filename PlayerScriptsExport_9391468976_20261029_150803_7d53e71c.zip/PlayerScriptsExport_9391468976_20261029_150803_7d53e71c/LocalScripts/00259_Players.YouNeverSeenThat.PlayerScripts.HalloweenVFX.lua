-- Original instance: Players.YouNeverSeenThat.PlayerScripts.HalloweenVFX
-- Class: LocalScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("TweenService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("SoundService")
local v_u_6 = game.Players.LocalPlayer
local v7 = game.ReplicatedStorage
local _ = v7.Animations
local _ = v7.Utils
local _ = v7.Sounds
local v_u_8 = nil
v_u_1.OnStart():andThen(function()
	-- upvalues: (ref) v_u_8, (copy) v_u_1
	v_u_8 = v_u_1.GetController("FXController")
end)
local v_u_9 = TweenInfo.new(3, Enum.EasingStyle.Linear)
local v_u_10 = 0
workspace:GetAttributeChangedSignal("ST"):Connect(function()
	-- upvalues: (copy) v_u_6, (copy) v_u_4, (ref) v_u_10, (copy) v_u_9, (copy) v_u_2
	if _G.LocalSettings.Goodnight == true or (_G.LocalSettings.Darkness == true or _G.LocalSettings.Sunset == true) then
		return
	elseif v_u_6.Name == "Frostholl" and v_u_4:IsStudio() then
		return
	else
		local v11 = game.Lighting.Config
		local v12 = workspace:GetAttribute("ST") or 14.5
		local v13 = v12 / 24
		if v13 > 0.5 then
			v13 = 1 - v13
		end
		local v14 = v13 * 2
		local v15 = math.clamp(v14, 0, 1)
		local v16 = v12 > 5 and v12 < 19 and 14.5 or 2
		if game.Lighting.ClockTime == v16 then
			return
		elseif tick() - v_u_10 > v_u_9.Time then
			v_u_10 = tick()
			local v17 = {
				["ClockTime"] = v16,
				["Ambient"] = Color3.fromRGB(100, 100, 100):Lerp(v11:GetAttribute("Ambient"), v15),
				["OutdoorAmbient"] = Color3.fromRGB(40, 50, 75):Lerp(v11:GetAttribute("OutdoorAmbient"), v15),
				["EnvironmentDiffuseScale"] = v15
			}
			v_u_2:Create(game.Lighting, v_u_9, v17):Play()
		end
	end
end)
local v_u_18 = TweenInfo.new(0.8, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out)
local function v_u_24(p19, p20) -- name: createPumpkin
	-- upvalues: (copy) v_u_5
	local v21
	if p19 then
		v21 = p19:FindFirstChild("Head") or nil
	else
		v21 = nil
	end
	if v21 then
		local v22 = script.Pumpkin:Clone()
		v22.Highlight.Adornee = p19
		v22.Weld.Part0 = v21
		v22.Parent = p19
		for _, v23 in v22.Attachment:GetChildren() do
			v23.Enabled = true
		end
		v22.WearFX.Sparks:Emit(15)
		v22.Wear.SoundGroup = v_u_5.Effect
		v22.Voice2.SoundGroup = v_u_5.Voice
		if not p20 then
			v22.Wear:Play()
			v22.Voice2:Play()
			v22.Appear:Play()
		end
	end
end
local v_u_55 = {
	["OpenDoor"] = function(p25)
		-- upvalues: (copy) v_u_2
		local v26 = p25.Frame:FindFirstChild("Door", true)
		local _ = p25.Door.CFrame
		p25.Door.OpenSound:Play()
		v_u_2:Create(v26, TweenInfo.new(0.8, Enum.EasingStyle.Back), {
			["C1"] = v26.C1 * CFrame.Angles(0, -2.792526803190927, 0)
		}):Play()
		task.wait(1.5)
		for _, v27 in p25:GetDescendants() do
			if not v27:IsA("BasePart") then
				continue
			end
			v_u_2:Create(v27, TweenInfo.new(1), {
				["Transparency"] = 1
			}):Play()
		end
	end,
	["Candy"] = function(p_u_28, p29, p30, p_u_31)
		-- upvalues: (copy) v_u_6, (copy) v_u_2, (copy) v_u_18, (copy) v_u_3, (ref) v_u_8
		local v_u_32 = p_u_28.Character
		if v_u_32 then
			local v_u_33 = v_u_32:FindFirstChild("HumanoidRootPart")
			if v_u_33 then
				if p_u_28 == v_u_6 then
					p_u_28:SetAttribute("Candies2026", p30)
				end
				local v34 = p_u_31 - p30
				local v_u_35 = math.ceil(v34)
				for v_u_36 = 1, v_u_35 do
					local v_u_37 = script.Candy:Clone()
					v_u_37.Position = p29
					v_u_37.Parent = workspace.Effects
					v_u_37.Icon.Size = UDim2.new(0, 0, 0, 0)
					v_u_2:Create(v_u_37.Icon, v_u_18, {
						["Size"] = UDim2.new(1.5, 0, 1.5, 0)
					}):Play()
					local v38 = v_u_2
					local v39 = TweenInfo.new(v_u_36 * 0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
					local v40 = {}
					local v41 = math.random(-30, 30) / 10
					local v42 = math.random(-30, 30) / 10
					local v43 = math.random(-30, 30) / 10
					v40.Position = p29 + Vector3.new(v41, v42, v43)
					v38:Create(v_u_37, v39, v40):Play()
					task.delay(v_u_36 * 0.15, function()
						-- upvalues: (copy) v_u_37, (copy) v_u_33, (ref) v_u_3, (ref) v_u_8, (copy) v_u_32, (copy) p_u_28, (copy) v_u_36, (copy) v_u_35, (copy) p_u_31
						local _ = v_u_37.Position
						local v44 = 10
						repeat
							local v45 = task.wait()
							local v46 = CFrame.new(v_u_37.Position, v_u_33.Position).LookVector
							local v47 = v_u_37
							v47.Position = v47.Position + v46 * v44 * v45
							v44 = v44 + v45 * 50
						until (v_u_37.Position - v_u_33.Position).Magnitude <= 0.5
						v_u_37.Icon:Destroy()
						v_u_37.Pop.SoundGroup = game.SoundService.Effect
						v_u_37.Pop:Play()
						v_u_3:AddItem(v_u_37, 1)
						v_u_8:Flash(v_u_32, Color3.new(1, 0.66, 0), 0.2)
						if p_u_28 == game.Players.LocalPlayer then
							if v_u_36 == v_u_35 then
								p_u_28:SetAttribute("Candies2026", p_u_31)
								return
							end
							p_u_28:SetAttribute("Candies2026", p_u_28:GetAttribute("Candies2026") + 1)
						end
					end)
				end
			end
		else
			return
		end
	end,
	["CreatePumpkin"] = v_u_24,
	["SwitchPumpkin"] = function(p48, p49)
		-- upvalues: (copy) v_u_24
		local v50 = p48 and p48:FindFirstChild("Pumpkin") or nil
		local v51
		if p49 then
			v51 = p49:FindFirstChild("Head") or nil
		else
			v51 = nil
		end
		if v51 then
			if v50 then
				v50.Parent = p49
				v50.Weld.Part0 = v51
				v50.Highlight.Adornee = p49
				v50.Wear:Play()
				v50.WearFX.Sparks:Emit(5)
			else
				v_u_24(p49)
			end
		else
			return
		end
	end,
	["DestroyPumpkin"] = function(p52)
		-- upvalues: (copy) v_u_3, (copy) v_u_5
		local v_u_53 = p52 and p52:FindFirstChild("Pumpkin") or nil
		if v_u_53 then
			v_u_53.Highlight:Destroy()
			v_u_53.Progress:Destroy()
			v_u_53.Weld:Destroy()
			v_u_53.Anchored = true
			v_u_53.Parent = workspace.Effects
			v_u_3:AddItem(v_u_53, 5.5)
			v_u_53.Voice3.SoundGroup = v_u_5.Voice
			v_u_53.Explode.SoundGroup = v_u_5.Effect
			v_u_53.Voice3:Play()
			v_u_53.Explode:Play()
			for _, v54 in v_u_53.Attachment:GetChildren() do
				v54.Enabled = false
			end
			v_u_53.ExplodeFX.impactframeines3.Enabled = true
			v_u_53.ExplodeFX.impactframelines1.Enabled = true
			task.delay(0.1, function()
				-- upvalues: (copy) v_u_53
				if v_u_53 and v_u_53.Parent then
					v_u_53.ExplodeFX.impactframelines1.Enabled = false
					v_u_53.ExplodeFX.impactframeines3.Enabled = false
					v_u_53.Handle:Destroy()
					v_u_53.ExplodeFX.Wind2:Emit(20)
					v_u_53.ExplodeFX.WindCrescents1:Emit(20)
				end
			end)
			task.delay(1.1, function()
				-- upvalues: (copy) v_u_53
				if v_u_53 and v_u_53.Parent then
					v_u_53.Appear:Play()
					v_u_53.ExplodeFX.Hit:Emit(20)
					v_u_53.WearFX.Sparks:Emit(20)
					v_u_53.Attachment.Flames:Emit(15)
				end
			end)
		end
	end
}
v7.Remotes:WaitForChild("HALLOWEEN_VFX").OnClientEvent:Connect(function(p56, ...)
	-- upvalues: (copy) v_u_55
	if v_u_55[p56] then
		v_u_55[p56](...)
	end
end)