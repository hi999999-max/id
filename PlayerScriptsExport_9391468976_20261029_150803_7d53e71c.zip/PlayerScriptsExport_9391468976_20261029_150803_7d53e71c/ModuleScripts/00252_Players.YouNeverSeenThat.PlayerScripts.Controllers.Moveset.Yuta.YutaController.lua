-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Yuta.YutaController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "YutaController"
})
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_4, (copy) v_u_8, (copy) v_u_3, (ref) v_u_9
	local v_u_95 = {
		["Hit"] = function(p13, p14, p15, p16, p17)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2
			local v18 = p13:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = p14:FindFirstChild("HumanoidRootPart")
				if v19 then
					v_u_11:Flash(p14, Color3.new(1, 1, 1))
					if p17 or p16 == false then
						v_u_11:PlaySound(v_u_7.Gojo.M1:FindFirstChild("Hit" .. p15), v19, game.SoundService.Effect)
						if p17 then
							v_u_11:PlaySound(v_u_7.Yuta.MetalHit3, v19, game.SoundService.Effect)
						end
					else
						local v20
						if p16 == "Up" or p16 == "Down" then
							v20 = p16
						else
							v20 = p15
						end
						v_u_11:PlaySound(v_u_7.Yuta.M1:FindFirstChild("Hit" .. v20), v19, game.SoundService.Effect)
						if p16 then
							local v21 = v_u_6.Yuta.SlashHit:Clone()
							v21.CFrame = CFrame.lookAlong(v19.Position, v18.CFrame.LookVector)
							if p15 == 2 then
								v21.CFrame = v21.CFrame * CFrame.Angles(0, 0, -0.2617993877991494)
							elseif p15 == 3 then
								v21.CFrame = v21.CFrame * CFrame.Angles(0, 0, 0.4363323129985824)
							elseif p16 == "Up" then
								v21.CFrame = v21.CFrame * CFrame.Angles(0, 0, -1.3089969389957472)
							end
							v21.Parent = workspace.Effects
							v_u_2:AddItem(v21, 0.5)
							v21.Slash:Emit(5)
						end
					end
				else
					return
				end
			else
				return
			end
		end,
		["ChaseHit"] = function(p22, p23, p24)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2
			local v25 = p22:FindFirstChild("HumanoidRootPart")
			if v25 then
				local v26 = p23:FindFirstChild("HumanoidRootPart")
				if v26 then
					if p24 then
						v_u_11:Flash(p23, Color3.new(1, 1, 1))
						v_u_11:PlaySound(v_u_7.Yuta.M1:FindFirstChild("Hit" .. math.random(1, 3)), v26, game.SoundService.Effect)
					else
						v_u_11:Flash(p23, Color3.new(1, 1, 1))
						v_u_11:PlaySound(v_u_7.Gojo.M1:FindFirstChild("Hit3"), v26, game.SoundService.Effect)
					end
					local v27 = v_u_6.ChaseHit:Clone()
					local v28 = CFrame.new
					local v29 = v26.Position
					local v30 = v25.Position.X
					local v31 = v26.Position.Y
					local v32 = v25.Position.Z
					v27.CFrame = v28(v29, (Vector3.new(v30, v31, v32))) * CFrame.Angles(0, 3.141592653589793, 0)
					v27.Parent = workspace.Effects
					v_u_2:AddItem(v27, 0.5)
					v27.Ring:Emit(7)
					v27.Sparks:Emit(12)
				end
			else
				return
			end
		end,
		["AerialHit"] = function(p33, p34)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (ref) v_u_6, (ref) v_u_2
			local v35 = p33:FindFirstChild("HumanoidRootPart")
			if v35 then
				local v36 = p34:FindFirstChild("HumanoidRootPart")
				if v36 then
					v_u_11:Flash(p34, Color3.new(1, 1, 1))
					v_u_11:PlaySound(v_u_7.Itadori.CraniumSmash.Hit2, v36, game.SoundService.Effect)
					if v_u_4.Character == p33 or v_u_4.Character == p34 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
					local v37 = CFrame.new(v35.Position, v36.Position - Vector3.new(0, 4, 0))
					local v38 = v_u_6.Gojo.HardHit:Clone()
					v38.CFrame = v37 + v37.LookVector * 4
					v38.Parent = workspace.Effects
					v38.Dust:Emit(5)
					v38.Ring:Emit(5)
					v38.Sparks:Emit(10)
					v_u_2:AddItem(v38, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p39)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7
			local v40 = p39.HumanoidRootPart
			if v40 then
				local v41 = v_u_6.Gojo.LapseBlue.Throw:Clone()
				v41.CFrame = v40.CFrame * CFrame.new(0, 1, -4)
				v41.Size = Vector3.new(0, 0, 2)
				v41.Parent = workspace.Effects
				v_u_3:Create(v41, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v41, 0.3)
				v_u_11:PlaySound(v_u_7.Misc.Chase, v40, game.SoundService.Effect)
				v_u_11:DustTrail(p39, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p42, p43, p44, p45)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v46 = p42:FindFirstChild("HumanoidRootPart")
			if v46 then
				if p42:GetAttribute("InUlt") and not p45 then
					v_u_11:PlaySound(v_u_7.Misc.Swing.Fist, v46, game.SoundService.Effect)
				else
					local v47 = (p44 == "Up" or p44 == "Down") and "4Sword" or (p43 or 4)
					v_u_11:PlaySound(v_u_7.Yuta.M1:FindFirstChild("Swing" .. v47), v46, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Swing2"] = function(p48, p49, p50, p51)
			-- upvalues: (ref) v_u_11, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2
			if p51 == false then
				if p49 == 1 then
					v_u_11:ArmFlash(p48["Left Arm"], Color3.fromRGB(255, 85, 255), 0.3)
					task.wait(0.233)
					v_u_11:ArmFlash(p48["Right Arm"], Color3.fromRGB(255, 85, 255), 0.2)
					return
				elseif p49 == 2 then
					v_u_11:ArmFlash(p48["Right Arm"], Color3.fromRGB(255, 85, 255), 0.3)
					task.wait(0.233)
					v_u_11:ArmFlash(p48["Left Arm"], Color3.fromRGB(255, 85, 255), 0.2)
					return
				elseif p49 == 3 then
					v_u_11:ArmFlash(p48["Left Arm"], Color3.fromRGB(255, 85, 255), 0.6)
				else
					v_u_11:ArmFlash(p48["Right Arm"], Color3.fromRGB(255, 85, 255), 0.4)
				end
			elseif p49 == 4 and not p50 then
				v_u_11:ArmFlash(p48["Left Leg"], Color3.fromRGB(255, 85, 255), 0.4)
			else
				local v52 = p48.SetAssets:FindFirstChild("YutaSword")
				if v52 and p51 then
					local v53 = v_u_6.Yuta.CombatTrail:Clone()
					v53.Weld.Part0 = v52.Sword.MeshPart
					v53.Parent = workspace.Effects
					task.wait(p49 == 4 and 0.425 or 0.275)
					v53.Trail.Enabled = false
					v_u_3:Create(v53, TweenInfo.new(0.1), {
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v53, 0.2)
				end
			end
		end,
		["Launch"] = function(p54, p55)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v56 = p54:FindFirstChild("HumanoidRootPart")
			if v56 then
				local v57 = v_u_6.Gojo.LapseBlue.Throw:Clone()
				v57.CFrame = CFrame.new(v56.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v57.Size = Vector3.new(0, 0, 5)
				v57.Parent = workspace.Effects
				v_u_3:Create(v57, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v57.Position + Vector3.new(0, p55, 0)
				}):Play()
				v_u_2:AddItem(v57, 0.3)
				if p55 < 0 then
					v_u_11:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Break, v56, game.SoundService.Effect)
					v_u_11:DustBreak(v56.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_4:DistanceFromCharacter(v56.Position) < 20 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
					end
				end
			end
		end,
		["SwordSound"] = function(p58, p59)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v60 = p58:FindFirstChild("HumanoidRootPart")
			if v60 then
				local v61 = v_u_11:PlaySound(v_u_7.Yuta.SwordGrab, v60, game.SoundService.Effect)
				if p59 then
					v61.Volume = v61.Volume * 0.2
					v61.PlaybackSpeed = 1.5
				end
				local v62 = p58.SetAssets:FindFirstChild("YutaSword")
				if v62 then
					v62.Sheath.Glow.Glow:Emit(2)
				end
			else
				return
			end
		end,
		["BreakChainSound"] = function(p63)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v64 = p63:FindFirstChild("HumanoidRootPart")
			if v64 then
				v_u_11:PlaySound(v_u_7.Yuta.Ultimate.BreakChain, v64, game.SoundService.Effect)
			end
		end,
		["MetalArmSound"] = function(p65)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v66 = p65:FindFirstChild("HumanoidRootPart")
			if v66 then
				v_u_11:PlaySound(v_u_7.Yuta.Ultimate.EquipArm, v66, game.SoundService.Effect)
			end
		end,
		["ShakeArmSound"] = function(p67)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v68 = p67:FindFirstChild("HumanoidRootPart")
			if v68 then
				v_u_11:PlaySound(v_u_7.Yuta.Ultimate.ShakeArm, v68, game.SoundService.Effect)
			end
		end,
		["PutRingSound"] = function(p69)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v70 = p69:FindFirstChild("HumanoidRootPart")
			if v70 then
				v_u_11:PlaySound(v_u_7.Yuta.Ultimate.PutRing, v70, game.SoundService.Effect)
			end
		end,
		["BreakChain"] = function(p71)
			local v72 = p71:FindFirstChild("HumanoidRootPart")
			if v72 then
				local v73 = p71.SetAssets:FindFirstChild("YutaSword")
				if v73 then
					local v74 = v73:FindFirstChild("ChainRing")
					if v74 then
						local v75 = 0
						local v76 = {}
						for _, v77 in v74:GetChildren() do
							if v77:IsA("Weld") then
								v77:Destroy()
							elseif v77:IsA("Part") then
								v75 = v75 + 1
								if v75 % 3 == 0 then
									v77:SetAttribute("Velocity", v72.Velocity + v72.CFrame.LookVector * math.random(5, 10) + Vector3.new(0, 1, 0) * math.random(5, 15) + v72.CFrame.RightVector * math.random(-5, 5))
									table.insert(v76, v77)
								else
									v77:Destroy()
								end
							else
								if not v77:IsA("Model") then
									continue
								end
								v77:Destroy()
							end
						end
						local v78 = Vector3.new(0, 1, 0) * -workspace.Gravity
						local v79 = task.wait()
						for _, v80 in v76 do
							local v81 = v80:GetAttribute("Velocity")
							v80.Position = v80.Position + v80:GetAttribute("Velocity") * v79
							v80:SetAttribute("Velocity", v81 + v78 * v79)
						end
						if v74.Parent then
							break
						end
					end
				else
					return
				end
			else
				return
			end
		end,
		["Chat"] = function(p82, p83)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2
			local v84 = p82:FindFirstChild("HumanoidRootPart")
			if v84 then
				local v85 = p82:FindFirstChild("Torso")
				if v85 then
					v_u_11:PlaySound(v_u_7.Yuta.Ultimate[p83 == "Zero" and "VLZero" or "VL"], v84, game.SoundService.Voice)
					local v86 = v_u_6.Yuta.Dialogue:Clone()
					v86.Parent = v85
					task.wait(0.45)
					local v87 = v86.Text1.Position
					v86.Text1.Position = v87 - UDim2.new(0, 0, 0.15, 0)
					v_u_3:Create(v86.Text1, TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Position"] = v87
					}):Play()
					v_u_3:Create(v86.Text1, TweenInfo.new(0.3), {
						["TextTransparency"] = 0
					}):Play()
					v_u_3:Create(v86.Text1.UIStroke, TweenInfo.new(0.3), {
						["Transparency"] = 0
					}):Play()
					task.wait(0.5)
					local v88 = v86.Text2.Position
					v86.Text2.Position = v88 + UDim2.new(0, 0, 0.15, 0)
					v_u_3:Create(v86.Text2, TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Position"] = v88
					}):Play()
					v_u_3:Create(v86.Text2, TweenInfo.new(0.3), {
						["TextTransparency"] = 0
					}):Play()
					v_u_3:Create(v86.Text2.UIStroke, TweenInfo.new(0.3), {
						["Transparency"] = 0
					}):Play()
					task.wait(1)
					local v89 = v86.Chat.Position
					v86.Chat.Position = v89 - UDim2.new(0, 0, 0.15, 0)
					v_u_3:Create(v86.Chat, TweenInfo.new(0.9, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Position"] = v89
					}):Play()
					v_u_3:Create(v86.Chat, TweenInfo.new(0.3), {
						["BackgroundTransparency"] = 0
					}):Play()
					v_u_3:Create(v86.Chat.Sub, TweenInfo.new(0.3), {
						["TextTransparency"] = 0
					}):Play()
					task.wait(1.2)
					v_u_2:AddItem(v86, 0.6)
					for _, v90 in v86:GetDescendants() do
						if v90:IsA("ImageLabel") then
							v_u_3:Create(v90, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
								["Position"] = nil,
								["BackgroundTransparency"] = 1,
								["Position"] = v90.Position - UDim2.new(0, 0, 0.2, 0)
							}):Play()
						else
							if not v90:IsA("TextLabel") then
								continue
							end
							v_u_3:Create(v90, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
								["TextTransparency"] = 1
							}):Play()
							if not v90:FindFirstChild("UIStroke") then
								continue
							end
							v_u_3:Create(v90:FindFirstChild("UIStroke"), TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
								["Transparency"] = 1
							}):Play()
						end
					end
				end
			else
				return
			end
		end,
		["RingEmit"] = function(p91)
			-- upvalues: (ref) v_u_3
			if p91:FindFirstChild("HumanoidRootPart") then
				local v92 = p91.SetAssets:FindFirstChild("YutaRing")
				if v92 then
					v92.Diamond.Visuals.ConstantGlow.Enabled = true
					task.wait(0.3)
					local v93 = v92.Diamond.Visuals.Beam
					local v94 = v93.Beam
					v94.TextureLength = 0.1
					v93.Position = Vector3.new(0, 0, 0)
					v94.Enabled = true
					v_u_3:Create(v94, TweenInfo.new(0.6, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
						["TextureLength"] = 1
					}):Play()
					v_u_3:Create(v93, TweenInfo.new(0.6, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
						["Position"] = Vector3.new(-0, -2, -0)
					}):Play()
					task.wait(0.7)
					v92.Diamond.Visuals.ConstantGlow.Enabled = false
					v_u_3:Create(v94, TweenInfo.new(0.3), {
						["TextureLength"] = 0.1,
						["Width1"] = 0,
						["Width0"] = 0
					}):Play()
					v_u_3:Create(v93, TweenInfo.new(0.3, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
						["Position"] = Vector3.new(-0, -0.5, -0)
					}):Play()
					task.wait(0.3)
					v93:Destroy()
				end
			else
				return
			end
		end
	}
	v_u_9.Effects:Connect(function(p96, ...)
		-- upvalues: (copy) v_u_95
		local v97 = v_u_95[p96]
		if v97 then
			v97(...)
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("YutaService")
	v_u_10 = v_u_1.GetController("HitboxController")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12