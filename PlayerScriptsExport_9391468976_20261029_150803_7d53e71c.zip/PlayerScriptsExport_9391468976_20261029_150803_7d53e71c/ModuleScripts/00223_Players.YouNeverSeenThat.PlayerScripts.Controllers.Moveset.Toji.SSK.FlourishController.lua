-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Toji.SSK.FlourishController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
game:GetService("Players")
local v_u_5 = Random.new()
local v_u_6 = workspace.CurrentCamera
local v_u_7 = game.Players.LocalPlayer
local v8 = game.ReplicatedStorage
local v_u_9 = v8.Animations
local v_u_10 = v8.Utils
local v_u_11 = v8.Sounds
local v_u_12 = require(v8.Modules.CameraShaker)
require(v8.Modules.BloodyZee)
local v_u_13 = nil
local v_u_14 = nil
local v15 = v_u_1.CreateController({
	["Name"] = "FlourishController"
})
function v15.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_14, (copy) v_u_11, (copy) v_u_10, (copy) v_u_3, (copy) v_u_7, (copy) v_u_12, (copy) v_u_4, (copy) v_u_6, (copy) v_u_2, (copy) v_u_5, (copy) v_u_9, (ref) v_u_13
	local v_u_195 = {
		["Spin"] = function(p16, p17)
			-- upvalues: (ref) v_u_14, (ref) v_u_11, (ref) v_u_10, (ref) v_u_3, (ref) v_u_7, (ref) v_u_12, (ref) v_u_4
			local v18 = p16:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19
				if p16 then
					v19 = p16:FindFirstChild("SetAssets") or nil
				else
					v19 = nil
				end
				local v20 = v19 and v19:FindFirstChild("SSK") or nil
				if v20 and (p17 and p17.Parent) then
					local v21 = v_u_14:PlaySound(v_u_11.Toji.SSK.Flourish.Start, v18, game.SoundService.Effect)
					local v22 = v_u_10.Toji.SSKCombatTrail:Clone()
					v22.Weld.Part0 = v20.Blade
					v22.Transparency = 1
					v22.Trail1.Color = ColorSequence.new(Color3.new(0.486275, 0.486275, 0.486275))
					v22.Trail2.Color = ColorSequence.new(Color3.new(0.486275, 0.486275, 0.486275))
					v22.Parent = workspace.Effects
					v_u_3:AddItem(v22, 0.4)
					task.wait(0.4)
					if not p17.Parent then
						v21:Destroy()
						return
					end
					if p16 == v_u_7.Character then
						local v23 = v_u_12.CameraShakeInstance.new(3, 8, 0.1, 0.45)
						v23.PositionInfluence = Vector3.new(0.3, 0.3, 0)
						v23.RotationInfluence = Vector3.new(0, 0, 0)
						v_u_12.CurrentShaker:Shake(v23)
					end
					local v_u_24 = v_u_10.Toji.SSKCombatTrail:Clone()
					v_u_24.Weld.Part0 = v20.Blade
					v_u_24.Parent = workspace.Effects
					task.delay(0.18, function()
						-- upvalues: (copy) v_u_24, (ref) v_u_4, (ref) v_u_3
						if v_u_24 and v_u_24.Parent then
							v_u_24.Trail1.Enabled = false
							v_u_24.Trail2.Enabled = false
							v_u_4:Create(v_u_24, TweenInfo.new(0.1), {
								["Transparency"] = 1
							}):Play()
							v_u_3:AddItem(v_u_24, 0.2)
						end
					end)
					local v25 = v_u_10.Toji.ShineHolder.Attachment:Clone()
					v25.Parent = v20.HandleSSK
					v25.CFrame = CFrame.new(0, -0.1, -2.6)
					v25.StarShine:Emit(1)
					v_u_4:Create(v25, TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["CFrame"] = CFrame.new(0, 0, -4.2)
					}):Play()
					v_u_3:AddItem(v25, 0.2)
					local v26 = v_u_10.Toji.Smears1:Clone()
					v26.InsideBlade.Transparency = 0.75
					v26.OutsideBlade.Transparency = 0.75
					local v27 = Instance.new("Weld")
					v27.Part0 = v20.HandleSSK
					v27.Part1 = v26.PivotPart
					v27.C0 = CFrame.new(0, 0, -2.5) * CFrame.Angles(0, 0, 1.5707963267948966)
					v27.Parent = v26.PivotPart
					v26.Parent = workspace.Effects
					v26.InsideBlade.Size = Vector3.new(2.1, 0.13, 6)
					v26.OutsideBlade.Size = Vector3.new(4, 0.025, 5)
					v_u_4:Create(v27, TweenInfo.new(0.075, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
						["C0"] = v27.C0 * CFrame.Angles(0, -0.7853981633974483, 0)
					}):Play()
					v_u_4:Create(v26.InsideBlade, TweenInfo.new(0.075, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
						["Size"] = Vector3.new(1, 0.2, 4)
					}):Play()
					v_u_4:Create(v26.OutsideBlade, TweenInfo.new(0.075, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
						["Size"] = Vector3.new(1, 0.015, 3.695)
					}):Play()
					v_u_3:AddItem(v26, 0.075)
				end
			end
		end,
		["Hit"] = function(p28, p29)
			-- upvalues: (ref) v_u_14, (ref) v_u_11, (ref) v_u_10, (ref) v_u_3, (ref) v_u_7, (ref) v_u_12
			local v30 = p28:FindFirstChild("HumanoidRootPart")
			if v30 then
				local v31 = p29:FindFirstChild("HumanoidRootPart")
				if v31 then
					v_u_14:Flash(p29, Color3.new(1, 1, 1))
					v_u_14:PlaySound(v_u_11.Choso.BloodEdge.StabHit, v31, game.SoundService.Effect).PlaybackSpeed = math.random(90, 110) / 100
					local v32 = v_u_10.Yuta.SlashHit:Clone()
					v32.CFrame = CFrame.lookAlong(v31.Position, v30.CFrame.LookVector)
					local v33 = v32.CFrame
					local v34 = CFrame.Angles
					local v35 = -90 + math.random(-4, 4)
					v32.CFrame = v33 * v34(0, 0, (math.rad(v35)))
					v32.Parent = workspace.Effects
					v32.Slash:Emit(5)
					v_u_3:AddItem(v32, 0.5)
					if v_u_7.Character == p28 or v_u_7.Character == p29 then
						v_u_12.CurrentShaker:Shake(v_u_12.Presets.Snap)
					end
				end
			else
				return
			end
		end,
		["Hit2"] = function(p36, p37, p38)
			-- upvalues: (ref) v_u_14, (ref) v_u_11, (ref) v_u_10, (ref) v_u_3, (ref) v_u_7, (ref) v_u_12
			local v39 = p36:FindFirstChild("HumanoidRootPart")
			if v39 then
				local v40 = p37:FindFirstChild("HumanoidRootPart")
				if v40 then
					v_u_14:Flash(p37, Color3.new(1, 1, 1))
					v_u_14:PlaySound(v_u_11.Toji.SSK.Flourish["Hit" .. p38], v40, game.SoundService.Effect)
					local v41 = {}
					local v42 = CFrame.Angles
					local v43 = -15 + math.random(-2, 2)
					local v44 = v42(0, 0, (math.rad(v43)))
					local v45 = CFrame.Angles
					local v46 = -15 + math.random(-2, 2)
					local v47 = v45(0, 0, (math.rad(v46)))
					local v48 = CFrame.Angles
					local v49 = -50 + math.random(-2, 2)
					__set_list(v41, 1, {v44, v47, v48(0, 0, (math.rad(v49)))})
					local v50 = v_u_10.Yuta.SlashHit:Clone()
					v50.CFrame = CFrame.lookAlong(p37.Torso.Position, v39.CFrame.LookVector)
					v50.CFrame = v50.CFrame * (v41[p38] or CFrame.new())
					v50.Parent = workspace.Effects
					v50.Slash.LockedToPart = true
					v50.Slash.LightEmission = 1
					v50.Slash.Color = ColorSequence.new(Color3.fromRGB(255, 73, 76), Color3.fromRGB(0, 0, 0))
					v50.Slash:Emit(5)
					v_u_3:AddItem(v50, 0.5)
					if v_u_7.Character == p36 or v_u_7.Character == p37 then
						v_u_12.CurrentShaker:Shake(p38 == 4 and v_u_12.Presets.HeavyHit or v_u_12.Presets.Snap)
					end
					repeat
						task.wait()
						v50.Position = p37.Torso.Position + Vector3.new(0, -1, 0)
					until not v50.Parent
				end
			else
				return
			end
		end,
		["AfterImage"] = function(p_u_51, p52, p53)
			-- upvalues: (ref) v_u_4, (ref) v_u_3
			if p_u_51:FindFirstChild("HumanoidRootPart") then
				(function(p54, p55, p56) -- name: AfterImage
					-- upvalues: (ref) v_u_4, (copy) p_u_51, (ref) v_u_3
					p54.Archivable = true
					local v57 = p54:Clone()
					v57.Name = "Afterimage"
					v57.PrimaryPart = v57.HumanoidRootPart
					for _, v58 in v57:GetDescendants() do
						if v58:IsA("Script") or (v58:IsA("LocalScript") or (v58:IsA("ModuleScript") or (v58:IsA("ParticleEmitter") or (v58:IsA("Beam") or (v58:IsA("Trail") or (v58:IsA("Animator") or (v58:IsA("AnimationController") or (v58:IsA("Highlight") or v58.Name == "AnimSaves")))))))) then
							v58:Destroy()
						end
						if not v58 or (not v58.Parent or (v58.Parent.Name ~= "SetAssets" or (v58.Name == "SSK" or (v58.Name == "Worm" or v58.Name == "ISOH")))) then
							continue
						end
						v58:Destroy()
					end
					for _, v59 in v57:QueryDescendants("BasePart") do
						if v59.Transparency ~= 1 then
							v59.Transparency = 0
						end
						v_u_4:Create(v59, TweenInfo.new(p55, Enum.EasingStyle.Linear), {
							["Transparency"] = 1
						}):Play()
						v59.Anchored = true
						v59.CanCollide = false
						v59.CollisionGroup = "NoCollision"
						v59.CanQuery = false
						v59.CanTouch = false
						v59.CastShadow = false
					end
					local v60 = v57.Humanoid
					v60.BreakJointsOnDeath = false
					v60.PlatformStand = true
					v60.EvaluateStateMachine = false
					v60.RequiresNeck = false
					v60.Health = 0
					if p56 then
						v57:PivotTo(p56)
					end
					v57.Parent = workspace.Effects
					for _, v_u_61 in p_u_51:GetDescendants() do
						if not (v_u_61:IsA("BasePart") or v_u_61:IsA("Decal")) or (v_u_61.Transparency == 1 or v_u_61.Name == "HumanoidRootPart") then
							continue
						end
						v_u_61.LocalTransparencyModifier = 1
						task.delay(0.03, function()
							-- upvalues: (copy) v_u_61
							v_u_61.LocalTransparencyModifier = 0.7
							task.wait(0.03)
							v_u_61.LocalTransparencyModifier = 1
							task.wait(0.03)
							v_u_61.LocalTransparencyModifier = 0.2
							task.wait(0.03)
							v_u_61.LocalTransparencyModifier = 1
							task.wait(0.03)
							v_u_61.LocalTransparencyModifier = 0
						end)
					end
					v_u_3:AddItem(v57, p55)
					return v57
				end)(p_u_51, p52, p53)
			end
		end,
		["Slowmo"] = function(p62, p63)
			-- upvalues: (ref) v_u_4, (ref) v_u_6, (ref) v_u_14, (ref) v_u_11
			local v_u_64 = v_u_4:Create(v_u_6, TweenInfo.new(1.2, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
				["FieldOfView"] = 60
			})
			local v65 = v_u_4:Create(v_u_6, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
				["FieldOfView"] = 70
			})
			local v_u_66 = v_u_14:PlaySound(v_u_11.Toji.SSK.Flourish.SlowMo, workspace, game.SoundService.Effect)
			v_u_64:Play()
			p62.Destroying:Connect(function()
				-- upvalues: (copy) v_u_64, (ref) v_u_4, (ref) v_u_6, (copy) v_u_66
				v_u_64:Cancel()
				v_u_4:Create(v_u_6, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
					["FieldOfView"] = 70
				}):Play()
				v_u_4:Create(v_u_66, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
					["Volume"] = 0
				})
			end)
			task.wait(p63)
			v_u_64:Cancel()
			v65:Play()
			v_u_4:Create(v_u_66, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
				["Volume"] = 0
			})
		end,
		["Slash"] = function(p67, p68)
			-- upvalues: (ref) v_u_10, (ref) v_u_14, (ref) v_u_11, (ref) v_u_4, (ref) v_u_3, (ref) v_u_7, (ref) v_u_12
			local v69 = p67:FindFirstChild("HumanoidRootPart")
			if v69 then
				if v_u_10.Toji.Flourish:FindFirstChild("Slash" .. p68) then
					local v_u_70 = v_u_10.Toji.Flourish:FindFirstChild("Slash" .. p68):Clone()
					v_u_70.CFrame = v69.CFrame * v_u_70.Weld.C0
					v_u_70.Parent = workspace.Effects
					v_u_14:PlaySound(v_u_11.Toji.SSK.Flourish["Slash" .. p68], v69, game.SoundService.Effect)
					v_u_4:Create(v_u_70, TweenInfo.new(0.4), {
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v_u_70, 0.4)
					if _G.Settings.Flash == true then
						task.delay(0.05, function()
							-- upvalues: (copy) v_u_70
							v_u_70.Material = Enum.Material.Neon
							v_u_70.Color = Color3.fromRGB(85, 0, 0)
						end)
					else
						v_u_70.Material = Enum.Material.Neon
						v_u_70.Color = Color3.fromRGB(85, 0, 0)
					end
					if p68 == 3 then
						v_u_14:DustBreak(v69.Position + v69.CFrame.LookVector * 8 + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
						if v_u_7.Character == p67 then
							v_u_12.CurrentShaker:Shake(v_u_12.Presets.LightHit)
						end
					end
					local v71 = tick()
					local v72 = 1
					local v73 = task.wait()
					if v_u_70.Parent and v69.Parent then
						v_u_70.Weld.C0 = v_u_70.Weld.C0:Lerp(v_u_70.Weld:GetAttribute("Goal"), 7 * v73)
						if tick() - v71 > 0.1 then
							local v74 = 12 * v73
							v72 = math.lerp(v72, 0, v74)
						end
						v_u_70.CFrame = v_u_70.CFrame:Lerp(v69.CFrame * v_u_70.Weld.C0, v72)
						if v69.Parent then
							continue
						end
					end
				end
			else
				return
			end
		end,
		["ChainSpin"] = function(p75)
			-- upvalues: (ref) v_u_14, (ref) v_u_11, (ref) v_u_10, (ref) v_u_3
			local v76 = p75:FindFirstChild("HumanoidRootPart")
			if v76 then
				v_u_14:PlaySound(v_u_11.Ryu.Unsatisfied.Weave, v76, game.SoundService.Effect)
				local v77 = p75.SetAssets:FindFirstChild("COATM")
				for v78 = 5, 6 do
					local v79 = v77:FindFirstChild("Beam" .. v78)
					if not v79 then
						continue
					end
					local v_u_80 = v_u_10.Toji.COATMCombatTrail:Clone()
					v_u_80.Parent = v77
					v_u_80.Attachment0 = v79.Attachment0
					v_u_80.Attachment1 = v79.Attachment1
					v_u_80.Enabled = true
					task.delay(0.6, function()
						-- upvalues: (copy) v_u_80, (ref) v_u_3
						v_u_80.Enabled = false
						v_u_3:AddItem(v_u_80, 0.2)
					end)
				end
			end
		end,
		["ChainGrab"] = function(p81, p_u_82, p83)
			-- upvalues: (ref) v_u_10, (ref) v_u_4, (ref) v_u_2, (ref) v_u_5
			if p81:FindFirstChild("HumanoidRootPart") then
				if p_u_82:FindFirstChild("HumanoidRootPart") then
					local v84 = p81.SetAssets:FindFirstChild("COATM")
					if v84 then
						local v85 = v84.Beam2
						local v_u_86 = Instance.new("Attachment", workspace.Terrain)
						local v87 = Instance.new("Attachment", workspace.Terrain)
						v84["Beam" .. 2].Enabled = false
						v84["Beam" .. 3].Enabled = false
						v84["Beam" .. 4].Enabled = false
						v84["Beam" .. 5].Enabled = false
						v84["Beam" .. 6].Enabled = false
						local v_u_88 = v85:Clone()
						v_u_88.Parent = workspace.Effects
						v_u_88.Attachment0 = v_u_86
						v_u_88.Attachment1 = v87
						v_u_88.Enabled = true
						v_u_86.WorldCFrame = CFrame.lookAt(p_u_82.Torso.Position, v84["1"].Position) * CFrame.Angles(0, 0, 1.5707963267948966)
						v87.WorldCFrame = CFrame.lookAt(v84["1"].Position, p_u_82.Torso.Position)
						task.spawn(function()
							-- upvalues: (copy) v_u_86, (copy) v_u_88, (ref) v_u_10
							local v89 = {}
							local function v99(p90, p91) -- name: getBeamCFrame
								local v92 = p90.Attachment0
								local v93 = p90.Attachment1
								local v94 = v92.WorldPosition
								local v95 = v94 + v92.WorldCFrame.RightVector * p90.CurveSize0
								local v96 = v93.WorldPosition
								local v97 = v96 - v93.WorldCFrame.RightVector * p90.CurveSize1
								local v98 = 1 - p91
								return v98 ^ 3 * v94 + v98 ^ 2 * 3 * p91 * v95 + v98 * 3 * p91 ^ 2 * v97 + p91 ^ 3 * v96
							end
							for v100 = 1, 6 do
								local v101 = v100 == 1 and v_u_86 or v89[v100 - 1]
								local v102 = Instance.new("Attachment", v_u_88)
								v102.WorldPosition = v99(v_u_88, v100 / 6)
								local v103 = v_u_10.Toji.COATMCombatTrail:Clone()
								v103.Lifetime = 0.2
								v103.Enabled = true
								v103.Parent = v102
								v103.Attachment0 = v101
								v103.Attachment1 = v102
								v89[v100] = v102
							end
							for v104, v105 in v89 do
								v105.WorldPosition = v99(v_u_88, v104 / 6)
							end
							task.wait()
							if v_u_88.Enabled and v_u_88.Parent then
								break
							end
						end)
						local v106 = tick()
						local v_u_107 = v_u_4:Create(v_u_88, TweenInfo.new(0.55, Enum.EasingStyle.Exponential), {
							["CurveSize0"] = 25
						})
						v_u_107:Play()
						v_u_107.Completed:Connect(function()
							-- upvalues: (ref) v_u_107, (ref) v_u_4, (copy) v_u_88
							v_u_107 = v_u_4:Create(v_u_88, TweenInfo.new(0.2), {
								["CurveSize0"] = -20
							})
							v_u_107:Play()
							v_u_107.Completed:Connect(function()
								-- upvalues: (ref) v_u_107, (ref) v_u_4, (ref) v_u_88
								v_u_107 = v_u_4:Create(v_u_88, TweenInfo.new(0.15), {
									["CurveSize0"] = 0
								})
								v_u_107:Play()
							end)
						end)
						local v_u_108 = p_u_82:GetScale() * 0.3
						task.spawn(function()
							local v109 = Instance.new("Part")
							v109.CanCollide = false
							v109.Massless = false
							v109.Size = Vector3.new(1, 1, 1)
							v109.Transparency = 1
						end)
						local v_u_110 = {}
						local v_u_111 = 0
						local v_u_112 = 30
						local v_u_113 = Instance.new("Part")
						v_u_113.CanCollide = false
						v_u_113.Massless = false
						v_u_113.Size = Vector3.new(1, 1, 1)
						v_u_113.Transparency = 1
						v_u_113.Parent = workspace.Effects
						local v_u_114 = Instance.new("Weld")
						v_u_114.Part0 = p_u_82.Torso
						v_u_114.Part1 = v_u_113
						v_u_114.C0 = CFrame.new(0, 0.5, 0)
						v_u_114.Parent = v_u_113
						v_u_4:Create(v_u_114, TweenInfo.new(0.15, Enum.EasingStyle.Linear), {
							["C0"] = CFrame.new(0, -1, 0)
						}):Play()
						local v_u_115 = v_u_10.Toji.ChainTip:Clone()
						local v_u_116 = Instance.new("Weld")
						v_u_116.Part0 = v_u_113
						v_u_116.Part1 = v_u_115.ChainTip
						v_u_116.Parent = v_u_115
						v_u_115:ScaleTo(v_u_108)
						v_u_115.Parent = workspace.Effects
						local v_u_122 = v_u_2.PreSimulation:Connect(function(p117)
							-- upvalues: (copy) v_u_114, (copy) v_u_116
							local v118 = v_u_114
							local v119 = v118.C1
							local v120 = CFrame.Angles
							local v121 = -5000 * p117
							v118.C1 = v119 * v120(0, math.rad(v121), 0)
							v_u_116.C0 = CFrame.new(0, 0, -1.7463007959288808 * p117)
						end)
						task.delay(0.075, function()
							-- upvalues: (ref) v_u_4, (copy) v_u_115, (ref) v_u_122, (copy) v_u_113
							v_u_4:Create(v_u_115.ChainTip.Attachment1, TweenInfo.new(0.075, Enum.EasingStyle.Linear), {
								["CFrame"] = CFrame.new(0, 0, 0)
							}):Play()
							task.wait(0.075)
							v_u_122:Disconnect()
							v_u_113:Destroy()
							v_u_115:Destroy()
						end)
						task.spawn(function()
							-- upvalues: (ref) v_u_111, (ref) v_u_112, (ref) v_u_10, (ref) v_u_5, (copy) p_u_82, (copy) v_u_108, (ref) v_u_4, (copy) v_u_110, (copy) v_u_115
							for _ = 1, 3 do
								v_u_111 = v_u_111 + 0.35
								v_u_112 = v_u_112 / 1.5
								local v123 = v_u_10.Toji.ChainCircles:Clone()
								local v124 = CFrame.new(0, 0.5 - v_u_111, 0)
								local v125 = CFrame.Angles
								local v126 = v_u_5:NextNumber(-25, 25)
								local v127 = v124 * v125(math.rad(v126), 0, 0)
								local v128 = CFrame.Angles
								local v129 = v_u_5:NextNumber(-5, 5)
								local v130 = v127 * v128(0, 0, (math.rad(v129)))
								v123:PivotTo(p_u_82.Torso.CFrame * v130)
								local v131 = Instance.new("WeldConstraint")
								v131.Part0 = p_u_82.Torso
								v131.Part1 = v123.PrimaryPart
								v131.Parent = v123
								local v132 = v_u_5:NextNumber(0, 1)
								for _, v133 in v123.PrimaryPart:GetChildren() do
									if not v133:IsA("Beam") then
										continue
									end
									v133:SetTextureOffset(v132)
									v133.TextureSpeed = v_u_112
									v133.Width0 = 1 * v_u_108
									v133.Width1 = 1 * v_u_108
									v_u_4:Create(v133, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
										["Width0"] = 2 * v_u_108,
										["Width1"] = 2 * v_u_108
									}):Play()
									v_u_4:Create(v133, TweenInfo.new(0.16666666666666666, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
										["TextureSpeed"] = 0
									}):Play()
									if v133.Name == "Beam0" then
										v133.CurveSize0 = -4
										v133.CurveSize1 = 4
									else
										v133.CurveSize0 = 4
										v133.CurveSize1 = -4
									end
								end
								v123:ScaleTo(v_u_108)
								local v134 = v_u_110
								table.insert(v134, v123)
								v123.Parent = workspace.Effects
								task.wait(0.049999999999999996)
							end
							v_u_115:Destroy()
						end)
						local v135 = v_u_122
						local v136 = v_u_107
						repeat
							task.wait()
							v_u_86.WorldCFrame = CFrame.lookAt(p_u_82.Torso.Position, v84["1"].Position) * CFrame.Angles(0, 0, 1.5707963267948966)
							v87.WorldCFrame = CFrame.lookAt(v84["1"].Position, p_u_82.Torso.Position)
						until not p83 or (not p83.Parent or tick() - v106 > 4)
						if v136 then
							v136:Cancel()
						end
						v135:Disconnect()
						v_u_113:Destroy()
						v_u_115:Destroy()
						for _, v137 in v_u_110 do
							v137:Destroy()
						end
						v_u_86:Destroy()
						v87:Destroy()
						v_u_88:Destroy()
						v84["Beam" .. 2].Enabled = true
						v84["Beam" .. 3].Enabled = true
						v84["Beam" .. 4].Enabled = true
						v84["Beam" .. 5].Enabled = true
						v84["Beam" .. 6].Enabled = true
					end
				else
					return
				end
			else
				return
			end
		end,
		["ChainHit"] = function(p138, p139)
			-- upvalues: (ref) v_u_10, (ref) v_u_3, (ref) v_u_14, (ref) v_u_11, (ref) v_u_7, (ref) v_u_12
			if p138:FindFirstChild("HumanoidRootPart") then
				local v140 = p139:FindFirstChild("HumanoidRootPart")
				if v140 then
					local v141 = v_u_10.Toji.ChainHit:Clone()
					v141.Position = v140.Position
					v141.Parent = workspace.Effects
					v_u_3:AddItem(v141, 0.5)
					for _, v142 in v141:GetChildren() do
						v142:Emit(v142:GetAttribute("EmitCount"))
					end
					v_u_14:Flash(p139, Color3.new(1, 1, 1))
					v_u_14:PlaySound(v_u_11.Haruta.AnkleCutterHit, v140, game.SoundService.Effect)
					if v_u_7.Character == p138 or v_u_7.Character == p139 then
						v_u_12.CurrentShaker:Shake(v_u_12.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["ISOHHit"] = function(p143, p144)
			-- upvalues: (ref) v_u_14, (ref) v_u_11, (ref) v_u_10, (ref) v_u_3, (ref) v_u_9, (ref) v_u_4, (ref) v_u_7, (ref) v_u_12
			local v145 = p143:FindFirstChild("HumanoidRootPart")
			if v145 then
				local v146 = p144:FindFirstChild("HumanoidRootPart")
				if v146 then
					v_u_14:Flash(p144, Color3.new(1, 1, 1))
					v_u_14:PlaySound(v_u_11.Choso.BloodEdge.StabHit, v146, game.SoundService.Effect).PlaybackSpeed = math.random(90, 110) / 100
					local v147 = v_u_10.Yuta.SlashHit:Clone()
					v147.CFrame = CFrame.lookAlong(v146.Position, v145.CFrame.LookVector)
					local v148 = v147.CFrame
					local v149 = CFrame.Angles
					local v150 = math.random(-180, 180)
					v147.CFrame = v148 * v149(0, 0, (math.rad(v150)))
					v147.Parent = workspace.Effects
					v147.Slash:Emit(5)
					v_u_3:AddItem(v147, 0.5)
					local v151 = v_u_10.Mahito.Worms.DashSlash.Attachment.Slashes:Clone()
					v151.Color = ColorSequence.new(Color3.fromRGB(255, 255, 127))
					v151.Brightness = 7
					v151.Parent = v146
					v_u_3:AddItem(v151, 2)
					v151.Enabled = false
					v151:Emit(2)
					local v_u_152 = p143:Clone()
					local v153 = v_u_152.HumanoidRootPart
					for _, v154 in v_u_152:GetDescendants() do
						if v154:IsA("BillboardGui") or (v154:IsA("Sound") or v154:IsA("ParticleEmitter")) then
							v154:Destroy()
						else
							if not v154:IsA("BasePart") then
								continue
							end
							v154.CollisionGroup = "NoCollision"
							v154.CanCollide = false
						end
					end
					v_u_152.Humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
					v_u_152.Parent = workspace.Effects
					v153.Anchored = true
					v_u_3:AddItem(v_u_152, 1)
					local v155 = v_u_152.Humanoid:LoadAnimation(v_u_9.Toji.SSK.Greed)
					v155:Play(0, nil, 0.01)
					local v156 = p143.Humanoid.Animator:GetTrackByAnimationId(v_u_9.Toji.SSK.Greed.AnimationId)
					if v156 then
						v155.TimePosition = v156.TimePosition
					end
					for _, v_u_157 in v_u_152:GetDescendants() do
						if not v_u_157:IsA("BasePart") or v_u_157.Transparency ~= 0 then
							continue
						end
						v_u_157.Transparency = 1
						v_u_157.LocalTransparencyModifier = 0
						v_u_4:Create(v_u_157, TweenInfo.new(0.1), {
							["Transparency"] = 0
						}):Play()
						task.delay(0.6, function()
							-- upvalues: (copy) v_u_157
							v_u_157.Transparency = 1
							task.wait(0.06)
							v_u_157.Transparency = 0
							local v158 = v_u_157
							local v159 = v_u_157.Size
							local v160 = math.random(90, 110) / 100
							local v161 = math.random(90, 110) / 100
							local v162 = math.random(90, 110) / 100
							v158.Size = v159 * Vector3.new(v160, v161, v162)
							task.wait(0.06)
							v_u_157.Transparency = 0.9
							local v163 = v_u_157
							local v164 = v_u_157.Size
							local v165 = math.random(90, 110) / 100
							local v166 = math.random(90, 110) / 100
							local v167 = math.random(90, 110) / 100
							v163.Size = v164 * Vector3.new(v165, v166, v167)
							task.wait(0.05)
							v_u_157.Transparency = 0.2
							local v168 = v_u_157
							local v169 = v_u_157.Size
							local v170 = math.random(90, 110) / 100
							local v171 = math.random(90, 110) / 100
							local v172 = math.random(90, 110) / 100
							v168.Size = v169 * Vector3.new(v170, v171, v172)
							task.wait(0.04)
							v_u_157.Transparency = 1
						end)
					end
					task.delay(0.6, function()
						-- upvalues: (copy) v_u_152, (ref) v_u_4, (ref) v_u_10, (ref) v_u_3
						local v173 = v_u_152.HumanoidRootPart:FindFirstChild("RootJoint")
						if v173 then
							local v174 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 1, -0)
							v_u_4:Create(v173, TweenInfo.new(0.15, Enum.EasingStyle.Elastic, Enum.EasingDirection.In), {
								["C0"] = v174 * CFrame.new(3, 0, 0)
							}):Play()
						end
						task.wait(0.1)
						local v175 = v_u_10.Toji.Teleport:Clone()
						v175.Position = v_u_152.Torso.Position
						v175.Parent = workspace.Effects
						v175.Lines2:Emit(8)
						v_u_3:AddItem(v175, 0.2)
					end)
					if v_u_7.Character == p143 or v_u_7.Character == p144 then
						v_u_12.CurrentShaker:Shake(v_u_12.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["KickHit"] = function(p176, p177)
			-- upvalues: (ref) v_u_10, (ref) v_u_3, (ref) v_u_14, (ref) v_u_11, (ref) v_u_7, (ref) v_u_12
			if p176:FindFirstChild("HumanoidRootPart") then
				local v178 = p177:FindFirstChild("HumanoidRootPart")
				if v178 then
					local v179 = v_u_10.Mahito.CrushingRushdown.DrillImpact:Clone()
					v179.Position = v178.Position
					v179.Parent = workspace.Effects
					v_u_3:AddItem(v179, 1)
					v179.Sparks.Color = ColorSequence.new(Color3.new(0, 0, 0))
					v179.Wind.Color = v179.Sparks.Color
					v179.Wind2.Color = v179.Sparks.Color
					v179.Sparks:Emit(30)
					v179.Wind2:Emit(7)
					v_u_14:Flash(p176, Color3.new(1, 1, 1))
					v_u_14:PlaySound(v_u_11.Reggie.Homerun.Hit, v178, game.SoundService.Effect)
					if v_u_7.Character == p177 or v_u_7.Character == p176 then
						v_u_12.CurrentShaker:Shake(v_u_12.Presets.SnapOh)
					end
				end
			else
				return
			end
		end,
		["ISOHTrail"] = function(p180)
			-- upvalues: (ref) v_u_10, (ref) v_u_4, (ref) v_u_3
			if p180:FindFirstChild("HumanoidRootPart") then
				local v181 = p180.SetAssets:FindFirstChild("ISOH")
				if v181 then
					local v_u_182 = v_u_10.Toji.ISOHCombatTrail:Clone()
					v_u_182.Trail.Texture = "rbxassetid://10168460874"
					v_u_182.Trail.Lifetime = 0.3
					v_u_182.Trail.Transparency = NumberSequence.new(0)
					v_u_182.Weld.Part0 = v181.Blade
					v_u_182.Parent = workspace.Effects
					task.delay(1, function()
						-- upvalues: (copy) v_u_182, (ref) v_u_4, (ref) v_u_3
						if v_u_182.Parent ~= nil then
							v_u_182.Trail.Enabled = false
							v_u_4:Create(v_u_182, TweenInfo.new(0.1), {
								["Transparency"] = 1
							}):Play()
							v_u_3:AddItem(v_u_182, 0.6)
						end
					end)
				end
			end
		end,
		["FasterDash"] = function(p183, p184)
			-- upvalues: (ref) v_u_2, (ref) v_u_10, (ref) v_u_4, (ref) v_u_3
			local v185 = p183.HumanoidRootPart
			if v185 then
				v_u_2.Stepped:Wait()
				local v186 = CFrame.new(p184, v185.Position)
				local v187 = (p184 - v185.Position).Magnitude
				local v188 = v_u_10.Mahito.Dash:Clone()
				v188.Color = Color3.fromRGB(255, 255, 127)
				v188.CFrame = v186 + v186.LookVector * v187 / 2
				v188.Size = Vector3.new(9, 9, v187)
				v188.Parent = workspace.Effects
				v_u_4:Create(v188, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(0, 0, v187),
					["CFrame"] = v188.CFrame * CFrame.Angles(0, 0, 3.141592653589793)
				}):Play()
				v_u_3:AddItem(v188, 0.7)
			end
		end,
		["FinalLand"] = function(p189, p190)
			-- upvalues: (ref) v_u_10, (ref) v_u_3, (ref) v_u_4
			local v191 = p189:FindFirstChild("HumanoidRootPart")
			if v191 then
				local v192 = v_u_10.Gojo.Teleport:Clone()
				v192.CFrame = v191.CFrame
				v192.Parent = workspace.Effects
				v192.Center.Flash:Emit(1)
				v192.Floor.Dust:Emit(30)
				v192.Lines:Emit(20)
				v_u_3:AddItem(v192, 1.1)
				local v193 = v_u_10.Naoya.Fall:Clone()
				v193:PivotTo(CFrame.new(p190 + Vector3.new(0, 4, 0)))
				v193.Parent = workspace.Effects
				v_u_3:AddItem(v193, 1.5)
				v193.Mesh.Start.Transparency = 0.7
				v193.Mesh2.Start.Transparency = 0.7
				v193.Mesh3.Start.Transparency = 0.7
				v_u_4:Create(v193.Mesh.Start, TweenInfo.new(0.7, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = nil,
					["Size"] = v193.Mesh.End.Size,
					["CFrame"] = v193.Mesh.End.CFrame
				}):Play()
				v_u_4:Create(v193.Mesh2.Start, TweenInfo.new(1, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = nil,
					["Size"] = v193.Mesh2.End.Size,
					["CFrame"] = v193.Mesh2.End.CFrame
				}):Play()
				v_u_4:Create(v193.Mesh3.Start, TweenInfo.new(1.5, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = nil,
					["Size"] = v193.Mesh3.End.Size,
					["CFrame"] = v193.Mesh3.End.CFrame
				}):Play()
				v193.Mesh.End:Destroy()
				v193.Mesh2.End:Destroy()
				v193.Mesh3.End:Destroy()
				for _, v_u_194 in p189:GetDescendants() do
					if not (v_u_194:IsA("BasePart") or v_u_194:IsA("Decal")) or v_u_194.Transparency == 1 then
						continue
					end
					v_u_194.LocalTransparencyModifier = 1
					task.delay(0.03, function()
						-- upvalues: (copy) v_u_194
						v_u_194.LocalTransparencyModifier = 0.7
						task.wait(0.03)
						v_u_194.LocalTransparencyModifier = 1
						task.wait(0.03)
						v_u_194.LocalTransparencyModifier = 0.2
						task.wait(0.03)
						v_u_194.LocalTransparencyModifier = 1
						task.wait(0.03)
						v_u_194.LocalTransparencyModifier = 0
						task.wait(0.04)
						v_u_194.LocalTransparencyModifier = 1
						task.wait(0.04)
						v_u_194.LocalTransparencyModifier = 0
					end)
				end
			end
		end
	}
	v_u_13.Effects:Connect(function(p196, ...)
		-- upvalues: (copy) v_u_195
		local v197 = v_u_195[p196]
		if v197 then
			v197(...)
		end
	end)
end
function v15.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_13, (copy) v_u_1, (ref) v_u_14
	v_u_13 = v_u_1.GetService("FlourishService")
	v_u_14 = v_u_1.GetController("FXController")
end
return v15