-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Character.ToolController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Debris")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game.Players.LocalPlayer
local v_u_7 = game.ReplicatedStorage
local v_u_8 = UserSettings().GameSettings
local v_u_9 = require(v_u_7.Modules.Icon)
local v_u_10 = require(v_u_7.Modules.KeybindIcons)
local v_u_11 = require(v_u_7.Modules.UltNames)
local v_u_12 = v_u_7.Animations
local v_u_13 = v_u_7.Utils
local v_u_14 = v_u_7.Sounds
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = nil
local v_u_18 = nil
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = nil
local v_u_22 = nil
local v_u_23 = {}
local v_u_24 = v_u_1.CreateController({
	["Name"] = "ToolController"
})
v_u_24.ShowReady = false
local v_u_25 = {
	["Cursed Strikes"] = 1,
	["Crushing Blow"] = 1,
	["Dismantle"] = 1,
	["Cleave"] = 1,
	["Lapse Blue"] = 2,
	["Reversal Red MAX"] = 1,
	["Lapse Blue MAX"] = 1,
	["Hollow Purple"] = 1,
	["Shutter Doors"] = 2,
	["Rough Energy"] = 1,
	["Rabbit Escape"] = 2,
	["Nue"] = 2,
	["Toad"] = 2,
	["Divine Dog: Totality"] = 2,
	["Mahoraga"] = 2,
	["Takedown"] = 2,
	["Stockpile"] = 1,
	["Body Disfigure"] = 2,
	["Face Blitz"] = 2,
	["Crushing Rushdown"] = 2,
	["Flowing Red Scale"] = 1,
	["Slicing Exorcism"] = 1,
	["Swift Kick"] = 6,
	["Kamehameha"] = 1,
	["Ki Spam"] = 1,
	["Staff Extend"] = 1,
	["Judgement\'s Reach"] = 2,
	["Grapple"] = 2,
	["Execution"] = 1,
	["Garuda Rebound"] = 2,
	["Mass Breaker"] = 1,
	["Shut Up!"] = 1,
	["Severing Path"] = 4,
	["Veilstep"] = 1,
	["Revolve"] = 1,
	["Outburst"] = 1,
	["Second Wind"] = 1,
	["Resolute Slash OLD"] = 2,
	["Resolute Slash"] = 5,
	["Copy"] = 5,
	["Authentic Mutual Love"] = 2,
	["Rika Launch"] = 1,
	["Puppet Barrage"] = 2,
	["Pigeon Viola"] = 2,
	["Technique Charge"] = 2,
	["Decisive Strike"] = 2,
	["Tendril Grab"] = 2,
	["Severance Kick"] = 4,
	["Blunt Cut"] = 1,
	["Collapse"] = 1,
	["Sharpen"] = 1,
	["Ambush"] = 1,
	["Impetus Updraft"] = 1,
	["Circling"] = 1,
	["Murmurate"] = 1,
	["Bird Control"] = 5,
	["Root Swarm"] = 1,
	["Surging Thorns"] = 1,
	["Defense Response"] = 1,
	["Tracking Roots"] = 5,
	["Root Rampage"] = 1,
	["Flower Field"] = 2,
	["Granite Blast"] = 1,
	["Second Helping"] = 2,
	["\"What are you after?\""] = 1,
	["Detach"] = 1,
	["Roach Swarm"] = 1,
	["Piano Drop"] = 3,
	["Passenger Cars"] = 2,
	["Blind Rage"] = 2,
	["Sky Distortion"] = 1,
	["Thin Ice Breaker"] = 2,
	["Turbulence"] = 7,
	["Transcend"] = 1,
	["Debilitate"] = 6
}
local v_u_29 = {
	["Custom"] = function()
		-- upvalues: (copy) v_u_6, (copy) v_u_24
		local v26 = v_u_6.Character
		local v27 = {}
		local v28
		if v26.Humanoid.FloorMaterial == Enum.Material.Air then
			v28 = v26.Humanoid:GetState() ~= Enum.HumanoidStateType.Swimming
		else
			v28 = false
		end
		__set_list(v27, 1, {v28, v_u_24:GetTarget(), require(v_u_6.PlayerScripts.PlayerModule.ControlModule):GetMoveVector(), v26.Humanoid.Jump == true})
		return v27
	end
}
v_u_24.ExtraData = v_u_29
function v_u_24.GetPlatform(_, p30) -- name: GetPlatform
	-- upvalues: (copy) v_u_2
	if p30 == Enum.PreferredInput.Touch then
		return "Mobile"
	end
	if p30 == Enum.PreferredInput.Gamepad then
		return v_u_2:GetStringForKeyCode(Enum.KeyCode.ButtonB) == "ButtonCircle" and "Playstation" or "Xbox"
	end
	if p30 == Enum.PreferredInput.KeyboardAndMouse then
		return "Keyboard"
	end
end
local v_u_31 = Instance.new("ObjectValue")
v_u_24.Selected = v_u_31
local v_u_32 = v_u_6:GetMouse()
local v_u_33 = {
	"Keyboard",
	"Playstation",
	"Xbox",
	"Mobile"
}
local v_u_34 = game:GetService("CollectionService")
v_u_6:GetMouse().TargetFilter = workspace.Effects
local function v_u_38() -- name: updateControls
	-- upvalues: (copy) v_u_33, (copy) v_u_24, (copy) v_u_34, (copy) v_u_10
	for _, v35 in v_u_33 do
		if v35 == v_u_24.LastInput then
			continue
		end
		for _, v36 in v_u_34:GetTagged(v35) do
			v36.Visible = false
		end
	end
	for _, v37 in v_u_34:GetTagged(v_u_24.LastInput) do
		v37.Visible = true
	end
	v_u_10:updateAll()
end
function v_u_24.GetMouseTarget(p39, p40, p41) -- name: GetMouseTarget
	-- upvalues: (copy) v_u_6, (copy) v_u_32
	local v42 = workspace.CurrentCamera
	local v43 = p40 == nil and 300 or p40
	local v44 = v_u_6.Character:GetAttribute("Moveset") == "Hanami" and 600 or v43
	if p39.LastInput == "Mobile" or p41 then
		local v45 = RaycastParams.new()
		v45.FilterType = Enum.RaycastFilterType.Exclude
		v45.FilterDescendantsInstances = { p41 and workspace.Characters or v_u_6.Character, workspace.Effects, workspace.Logic }
		local v46 = v42.CFrame.LookVector * v44
		local v47 = workspace:Raycast((v42.CFrame + v42.CFrame.UpVector * 1).Position, v46, v45)
		if v47 then
			return v47.Position
		else
			return v42.CFrame.Position + v46
		end
	else
		local v48 = RaycastParams.new()
		v48.FilterType = Enum.RaycastFilterType.Exclude
		v48.FilterDescendantsInstances = { p41 and workspace.Characters or v_u_6.Character, workspace.Effects, workspace.Logic }
		local v49 = CFrame.lookAt(v42.CFrame.Position, v_u_32.Hit.Position).LookVector * v44
		local v50 = workspace:Raycast(v42.CFrame.Position, v49, v48)
		if v50 then
			return v50.Position
		else
			return v42.CFrame.Position + v49
		end
	end
end
function v_u_24.GetTarget(p51, _) -- name: GetTarget
	-- upvalues: (copy) v_u_6, (copy) v_u_32
	local v52 = v_u_6.Character
	if v52 then
		local v53 = nil
		local v54 = workspace.CurrentCamera
		local v55 = v54.ViewportSize.Y / 5
		local v56
		if p51.LastInput == "Mobile" then
			v56 = v_u_6.PlayerGui.Controls.Crosshair.AbsolutePosition
		else
			v56 = Vector2.new(v_u_32.X, v_u_32.Y)
		end
		local v57 = v52:GetAttribute("Moveset") == "SuperTze" and 1000 or (v52:GetAttribute("Moveset") == "Haruta" and 350 or (v52:GetAttribute("Moveset") == "Mechamaru" and 300 or (v52:GetAttribute("Moveset") == "Chara" and 60 or (v52:GetAttribute("Moveset") == "Hanami" and 300 or 100))))
		local v58 = next
		local v59, v60 = workspace.Characters:GetChildren()
		for _, v61 in v58, v59, v60 do
			if not v61:FindFirstChild("Info") then
				continue
			end
			local v62 = v61:FindFirstChildOfClass("Humanoid")
			if v62 then
				v62 = v61:FindFirstChild("HumanoidRootPart")
			end
			if v61.Info:FindFirstChild("UroDistort") or (v61.Name == "HarutaSwordNPC" or (v61 == v_u_6.Character or (not v62 or v57 < (v54.CFrame.Position - v62.Position).Magnitude))) then
				continue
			end
			local v63, v64 = v54:WorldToScreenPoint(v62.Position)
			local v65 = (Vector2.new(v63.X, v63.Y) - Vector2.new(v56.X, v56.Y)).Magnitude
			if not v64 or v65 >= v55 then
				continue
			end
			v53 = v61
			v55 = v65
		end
		return v53
	end
end
function v_u_24.GetTargetOrProjectile(p66) -- name: GetTargetOrProjectile
	-- upvalues: (copy) v_u_6, (copy) v_u_32, (copy) v_u_34
	if v_u_6.Character then
		local v67 = nil
		local v68 = workspace.CurrentCamera
		local v69 = v68.ViewportSize.Y / 5
		local v70
		if p66.LastInput == "Mobile" then
			v70 = v_u_6.PlayerGui.Controls.Crosshair.AbsolutePosition
		else
			v70 = Vector2.new(v_u_32.X, v_u_32.Y)
		end
		local v71 = {}
		for _, v72 in workspace.Characters:GetChildren() do
			if not v72:FindFirstChild("Info") then
				continue
			end
			local v73 = v72:FindFirstChildOfClass("Humanoid")
			if v73 then
				v73 = v72:FindFirstChild("HumanoidRootPart")
			end
			if v72 == v_u_6.Character or not v73 then
				continue
			end
			table.insert(v71, v73)
		end
		if workspace.Map.Destructible:FindFirstChild("Throwable") then
			for _, v74 in workspace.Map.Destructible.Throwable:GetChildren() do
				local v75 = v74.PrimaryPart
				if not v75 or (v75:GetAttribute("Ignore") or v75:FindFirstChildWhichIsA("Weld")) then
					continue
				end
				table.insert(v71, v75)
			end
		end
		for _, v76 in v_u_34:GetTagged("CanBoogieWoogie") do
			local v77 = v76.PrimaryPart
			table.insert(v71, v77)
		end
		for _, v78 in v71 do
			if (v68.CFrame.Position - v78.Position).Magnitude > 100 then
				continue
			end
			local v79, v80 = v68:WorldToScreenPoint(v78.Position)
			local v81 = (Vector2.new(v79.X, v79.Y) - Vector2.new(v70.X, v70.Y)).Magnitude
			if not v80 or v81 >= v69 then
				continue
			end
			v67 = v78
			v69 = v81
		end
		if v67 then
			v67 = v67.Parent
		end
		return v67
	end
end
function v_u_24.GetToolService(_, p82) -- name: GetToolService
	-- upvalues: (copy) v_u_23, (copy) v_u_1
	local v83 = v_u_23[p82]
	if v83 then
		return v83
	end
	local v84 = v_u_1.GetService(p82)
	v_u_23[p82] = v84
	return v84
end
function v_u_24.UseSetService(p85, p86, ...) -- name: UseSetService
	-- upvalues: (copy) v_u_6, (copy) v_u_1, (copy) v_u_29
	local v87 = v_u_6.Character
	if v87 then
		if p86 == "Ultimate" then
			if v87:FindFirstChild("CustomChar") and v87.CustomChar:GetAttribute("CustomUltData") then
				v_u_1.GetService("CustomService").Awaken:Fire(v_u_29.Custom())
				return
			end
			if v87:GetAttribute("Enchain") then
				local v88 = p85:GetToolService("ItadoriService")
				if v88 then
					v88.UltimateEnchain:Fire(...)
				end
				return
			end
		end
		local v89 = p85:GetToolService(v87:GetAttribute("Moveset") .. "Service")
		if v89 and v89[p86] then
			v89[p86]:Fire(...)
		end
	end
end
function v_u_24.ReturnKey(_, p90) -- name: ReturnKey
	-- upvalues: (copy) v_u_6
	local v91 = v_u_6.Character
	if v91 then
		for _, v92 in v91.Moveset:GetChildren() do
			if v92:GetAttribute("Key") ~= p90 or (not v92:GetAttribute("Service") or v92:GetAttribute("AWK") and v91:GetAttribute("InUlt")) or v92:GetAttribute("AWK2") and not v91:GetAttribute("InUlt") then
				continue
			end
			return v92
		end
	end
end
function v_u_24.UseTool(p93, p_u_94, p95) -- name: UseTool
	-- upvalues: (copy) v_u_6, (ref) v_u_21, (copy) v_u_25, (copy) v_u_24, (copy) v_u_29, (copy) v_u_1
	local v_u_96 = v_u_6.Character
	local v97
	if v_u_96 then
		v97 = v_u_96:FindFirstChild("Info") or nil
	else
		v97 = nil
	end
	if v_u_96 and (v_u_96.Parent and (v97 and v97.Parent)) then
		local v98 = p93:GetToolService(p_u_94:GetAttribute("Service"))
		local v99 = require(v_u_6.PlayerScripts.PlayerModule.ControlModule)
		if v98 and v98[p95] then
			local v100
			if v_u_96.Humanoid.FloorMaterial == Enum.Material.Air then
				v100 = v_u_96.Humanoid:GetState() ~= Enum.HumanoidStateType.Swimming
			else
				v100 = false
			end
			if v100 then
				v100 = not workspace:Raycast(v_u_96.PrimaryPart.Position, Vector3.new(0, 1, 0) * -(v_u_21:GetCharacterHeight(v_u_96) + 1), _G.MapParams)
			end
			local v101 = v97:FindFirstChild("InDash") and true or false
			local v102 = v97:FindFirstChild("InRoll") and true or false
			local v_u_103 = v_u_25[p_u_94.Name] == 1 and v100 or v_u_25[p_u_94.Name] == 2 and p93:GetTarget() or (v_u_25[p_u_94.Name] == 3 and v_u_24:GetMouseTarget(75) or v_u_25[p_u_94.Name] == 4 and v99:GetMoveVector() or (v_u_25[p_u_94.Name] == 5 and {
				v100,
				p93:GetTarget(),
				v_u_24:GetMouseTarget(75),
				v99:GetMoveVector()
			} or v_u_25[p_u_94.Name] == 6 and { v100, v101, v102 }))
			if not v_u_103 then
				if v_u_25[p_u_94.Name] == 7 then
					v_u_103 = v100 or v_u_96.Humanoid.Jump == true
				else
					v_u_103 = false
				end
			end
			if p95 == "Activated" then
				local v104 = v98[p95]
				local v105 = not v_u_103 and v_u_29[p_u_94.Name]
				if v105 then
					v105 = v_u_29[p_u_94.Name]()
				end
				v104:Fire(p_u_94, v105)
			elseif p95 == "Deactivated" then
				local function v110()
					-- upvalues: (copy) p_u_94, (ref) v_u_1, (ref) v_u_103, (copy) v_u_96
					local v106 = p_u_94:GetAttribute("Service")
					local v107 = #p_u_94:GetAttribute("Service") - 7
					local v108 = string.sub(v106, 0, v107)
					local v109 = v_u_1.GetController(v108 .. "Controller")
					if v109 and v109.ToolDeactivate then
						v_u_103 = v109.ToolDeactivate(v_u_96)
					end
				end
				pcall(v110)
				v98[p95]:Fire(p_u_94, v_u_103)
			end
		end
	end
end
function v_u_24.UseKey(p111, p112, p113) -- name: UseKey
	-- upvalues: (copy) v_u_6
	if v_u_6.Character then
		local v114 = p111:ReturnKey(p112)
		if v114 then
			p111:UseTool(v114, p113)
		end
	else
		return
	end
end
function v_u_24.UpdateShift(_) -- name: UpdateShift
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (copy) v_u_8
	local v115 = v_u_6.PlayerGui.Controls
	if _G.Shift == true then
		v115.Crosshair.ImageTransparency = 0.5
		v_u_2.MouseIcon = "rbxasset://textures/collapsibleArrowDown.png"
	else
		v_u_8.RotationType = Enum.RotationType.MovementRelative
		v_u_2.MouseBehavior = Enum.MouseBehavior.Default
		v115.Crosshair.ImageTransparency = 1
		v_u_2.MouseIcon = ""
	end
end
local v_u_116 = false
local function v_u_125(p117) -- name: ThrowableFire
	-- upvalues: (ref) v_u_17
	if not p117.Info:FindFirstChild("NoThrowable") then
		local v118 = p117.HumanoidRootPart
		local v119 = 4 * p117:GetScale()
		local v120 = nil
		local v121 = v118.Position + v118.CFrame.LookVector * 3
		if workspace.Map.Destructible:FindFirstChild("Throwable") then
			for _, v122 in workspace.Map.Destructible.Throwable:GetChildren() do
				if not v122:IsA("Model") or (v122:GetAttribute("Ignore") or (not v122.PrimaryPart or (v122:GetAttribute("B") or v122:GetAttribute("Hold")))) then
					continue
				end
				local v123 = (v121 - v122.PrimaryPart.Position).Magnitude
				if v119 < v123 then
					continue
				end
				v120 = v122
				v119 = v123
			end
		end
		local v124 = p117.Info:FindFirstChild("Throwable")
		if v120 and not v124 then
			v_u_17.Throwable:Fire(v120)
			return true
		end
		if v124 and (v124.Value and not v124.Value:GetAttribute("Stored")) then
			v_u_17.Throwable:Fire(v124.Value)
			return true
		end
	end
end
function v_u_24.Melee(p126) -- name: Melee
	-- upvalues: (copy) v_u_6, (ref) v_u_18, (copy) v_u_125, (copy) v_u_31, (ref) v_u_116, (ref) v_u_19, (copy) v_u_29, (copy) v_u_24
	local v127 = v_u_6.Character
	if v127 then
		if _G.Crow and _G.Crow:IsDescendantOf(workspace.Effects.Crows) then
			_G.Crow:FireServer(true)
			return
		else
			_G.Crow = nil
			if v127.Info:FindFirstChild("Emote") then
				v_u_18.EmoteEnd:Fire()
			end
			if v_u_125(v127) then
				return
			elseif _G.Settings.AutoUse == false and v_u_31.Value then
				v_u_116 = true
				local v128 = v_u_31.Value:GetAttribute("Key")
				p126:UseKey(v128, "Activated")
				repeat
					task.wait()
				until not v127.Parent or v_u_116 == false
				p126:UseKey(v128, "Deactivated")
			else
				v_u_116 = true
				local v129 = v127.Info:FindFirstChild("Item")
				if v129 and v129:FindFirstChild("M1") then
					local v130 = v127.Humanoid.Jump == true
					local v131
					if v127.Humanoid.FloorMaterial == Enum.Material.Air then
						v131 = v127.Humanoid:GetState() ~= Enum.HumanoidStateType.Swimming
					else
						v131 = false
					end
					v_u_19.M1:Fire(v131 and "Down" or v130 and "Up", p126:GetTarget())
				else
					local v132 = v127.Humanoid.Jump == true
					local v133
					if v127.Humanoid.FloorMaterial == Enum.Material.Air then
						v133 = v127.Humanoid:GetState() ~= Enum.HumanoidStateType.Swimming
					else
						v133 = false
					end
					local v134
					if v127:GetAttribute("Moveset") == "Hanami" then
						v134 = v132 and "Up" or v133 and "Down"
					else
						v134 = v133 and "Down" or v132 and "Up"
					end
					if v127.Info:FindFirstChild("DomainClash") then
						p126:GetToolService("DomainService").Activated:Fire(v134)
					elseif v127:FindFirstChild("CustomM1") then
						p126:GetToolService("CustomService").Melee:Fire(v_u_29.Custom())
					else
						p126:UseSetService("Activated", v134, v_u_24:GetTarget())
					end
				end
				task.wait(0.025)
				if v127.Parent and v_u_116 ~= false then
					continue
				end
			end
		end
	else
		return
	end
end
function v_u_24.Special(p135) -- name: Special
	-- upvalues: (copy) v_u_6, (copy) v_u_1, (copy) v_u_14, (copy) v_u_5, (ref) v_u_15, (ref) v_u_19, (copy) v_u_29
	local v136 = v_u_6.Character
	if v136 then
		if v136.Info:FindFirstChild("InstantDomainClash") then
			v_u_1.GetService("DomainService").Activated2:Fire()
		end
		local v137 = v_u_6.PlayerGui.Main
		if v137.Respawn.Visible == true then
			v_u_1.GetController("FXController"):PlaySound(v_u_14.Misc.UI.Click, workspace, game.SoundService.Effect)
			v137.Respawn.Size = UDim2.new(0, 290, 0, 50)
			v_u_5:Create(v137.Respawn, TweenInfo.new(0.1), {
				["Size"] = UDim2.new(0, 300, 0, 60)
			}):Play()
			v_u_15.Respawn:Fire()
			return
		else
			local v138
			if v136 and v136:FindFirstChild("Info") then
				v138 = v136.Info:FindFirstChild("Item") or nil
			else
				v138 = nil
			end
			if v138 and v138:FindFirstChild("M2") then
				v_u_19.M2:Fire()
				return
			elseif v136:FindFirstChild("CustomChar") and v136.CustomChar:GetAttribute("CustomSpecial") then
				p135:GetToolService("CustomService").Special:Fire(v_u_29.Custom())
				return
			else
				local v139 = v136:GetAttribute("Moveset")
				if v139 == "Todo" then
					p135:UseSetService("RightActivated", p135:GetTargetOrProjectile())
					return
				elseif v139 == "Naoya" or v139 == "Hanami" then
					p135:UseSetService("RightActivated", p135:GetMouseTarget(75), p135:GetTarget())
					return
				elseif v139 == "MeiMei" then
					p135:UseSetService("RightActivated", require(v_u_6.PlayerScripts.PlayerModule.ControlModule):GetMoveVector())
				else
					p135:UseSetService("RightActivated", p135:GetTarget())
				end
			end
		end
	else
		return
	end
end
function v_u_24.ReleaseSpecial(p140) -- name: ReleaseSpecial
	-- upvalues: (copy) v_u_6
	if v_u_6.Character then
		p140:UseSetService("RightDeactivated")
	end
end
function v_u_24.Block(p141) -- name: Block
	-- upvalues: (copy) v_u_6, (ref) v_u_18, (ref) v_u_16
	local v142 = v_u_6.Character
	if v142 then
		if v142.Info:FindFirstChild("Emote") then
			if _G.UsingPiano == 2 then
				return
			end
			v_u_18.EmoteEnd:Fire()
		end
		local v143 = p141:GetTarget()
		v_u_16.Activated:Fire(v143)
	end
end
function v_u_24.KnitStart(p_u_144) -- name: KnitStart
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (ref) v_u_116, (ref) v_u_16, (ref) v_u_19, (ref) v_u_20, (ref) v_u_22, (copy) v_u_31, (copy) v_u_9, (ref) v_u_15, (copy) v_u_2, (copy) v_u_3, (copy) v_u_32, (copy) v_u_1, (copy) v_u_14, (copy) v_u_5, (copy) v_u_4, (copy) v_u_24, (copy) v_u_10, (copy) v_u_13, (copy) v_u_11, (copy) v_u_12, (copy) v_u_38, (copy) v_u_34
	local v_u_145 = v_u_6.PlayerGui:WaitForChild("Main")
	local v_u_146 = v_u_145.Controls.Ultimate.Bar
	local v_u_147 = v_u_145.Controls.Ultimate.Title
	local v_u_148 = v_u_6.PlayerGui:WaitForChild("Menus"):WaitForChild("Group")
	local v_u_149 = v_u_6.PlayerGui:WaitForChild("Controls").Mobile
	v_u_7.Keybind.Combat.Melee.Pressed:Connect(function()
		-- upvalues: (copy) p_u_144
		p_u_144:Melee()
	end)
	v_u_7.Keybind.Combat.Melee.Released:Connect(function()
		-- upvalues: (ref) v_u_116
		v_u_116 = false
	end)
	v_u_7.Keybind.Combat.Block.Pressed:Connect(function()
		-- upvalues: (copy) p_u_144
		p_u_144:Block()
	end)
	v_u_7.Keybind.Combat.Block.Released:Connect(function()
		-- upvalues: (ref) v_u_16
		v_u_16.Deactivated:Fire()
	end)
	v_u_7.Keybind.Combat.Special.Pressed:Connect(function()
		-- upvalues: (copy) p_u_144
		p_u_144:Special()
	end)
	v_u_7.Keybind.Combat.Special.Released:Connect(function()
		-- upvalues: (copy) p_u_144
		p_u_144:ReleaseSpecial()
	end)
	v_u_7.Keybind.Combat.Awaken.Pressed:Connect(function()
		-- upvalues: (copy) p_u_144
		p_u_144:UseSetService("Ultimate")
	end)
	v_u_7.Keybind.Combat.Awaken.Released:Connect(function()
		-- upvalues: (copy) p_u_144
		p_u_144:UseSetService("Deultimate")
	end)
	v_u_7.Keybind.Combat["Drop Item"].Pressed:Connect(function()
		-- upvalues: (ref) v_u_19
		v_u_19.Drop:Fire()
	end)
	v_u_7.Keybind.Combat["Shift Lock"].Pressed:Connect(function()
		-- upvalues: (copy) p_u_144
		_G.Shift = not _G.Shift
		p_u_144:UpdateShift()
	end)
	v_u_7.Keybind.Combat["Lock On"].Pressed:Connect(function()
		-- upvalues: (ref) v_u_20, (copy) p_u_144
		if v_u_20.LockOn then
			v_u_20.LockOn = nil
		else
			v_u_20.LockOn = p_u_144:GetTarget()
		end
	end)
	for _, v150 in v_u_7.Keybind.Combat:GetChildren() do
		local v151 = v150.Name
		if string.sub(v151, 1, 6) ~= "Skill " then
			continue
		end
		local v152 = v150.Name
		local v153 = string.sub(v152, 7, 7)
		local v_u_154 = tonumber(v153)
		v150.Pressed:Connect(function()
			-- upvalues: (ref) v_u_22, (copy) v_u_154, (copy) p_u_144, (ref) v_u_31
			if v_u_22.SelectRemote then
				v_u_22:SelectWheel(v_u_154)
				return
			elseif _G.Settings.AutoUse == true then
				p_u_144:UseKey(v_u_154, "Activated")
				return
			else
				local v155 = p_u_144:ReturnKey(v_u_154)
				if v155 and v155 ~= v_u_31.Value then
					v_u_31.Value = v155
				else
					v_u_31.Value = nil
				end
			end
		end)
		v150.Released:Connect(function()
			-- upvalues: (ref) v_u_22, (copy) p_u_144, (copy) v_u_154
			if v_u_22.SelectRemote then
				return
			elseif _G.Settings.AutoUse == true then
				p_u_144:UseKey(v_u_154, "Deactivated")
			end
		end)
	end
	v_u_146.Touch.MouseButton1Down:Connect(function()
		-- upvalues: (copy) p_u_144
		p_u_144:UseSetService("Ultimate")
	end)
	v_u_146.Touch.MouseButton1Up:Connect(function()
		-- upvalues: (copy) p_u_144
		p_u_144:UseSetService("Deultimate")
	end)
	local v_u_156 = v_u_9.new()
	v_u_156:setImage(15117261700)
	local v_u_157 = false
	local v_u_158 = nil
	local v_u_159 = nil
	local v_u_160 = v_u_9.new()
	v_u_160:setLabel("Lock Layout")
	v_u_160:select()
	v_u_160:autoDeselect(false)
	v_u_160.toggled:Connect(function(p161)
		-- upvalues: (ref) v_u_157, (ref) v_u_158, (ref) v_u_159, (copy) v_u_149, (ref) v_u_15
		v_u_157 = not p161
		if v_u_157 == false then
			v_u_158 = nil
			v_u_159 = nil
			local v162 = Color3.fromRGB(255, 255, 255)
			v_u_149.ShiftLock.Lock.ImageColor3 = v162
			v_u_149.ShiftLock.Lock.ImageLabel.ImageColor3 = v162
			for _, v163 in v_u_149.Jump:GetChildren() do
				v163.ImageColor3 = v162
				v163.ImageLabel.ImageColor3 = v162
			end
			local v164 = v_u_15.MobileLayout
			local v165 = {
				["Block"] = {
					["X"] = v_u_149.Jump.Block.Position.X.Offset,
					["Y"] = v_u_149.Jump.Block.Position.Y.Offset,
					["S"] = v_u_149.Jump.Block.Size.X.Scale
				},
				["Dash"] = {
					["X"] = v_u_149.Jump.Dash.Position.X.Offset,
					["Y"] = v_u_149.Jump.Dash.Position.Y.Offset,
					["S"] = v_u_149.Jump.Dash.Size.X.Scale
				},
				["Melee"] = {
					["X"] = v_u_149.Jump.Melee.Position.X.Offset,
					["Y"] = v_u_149.Jump.Melee.Position.Y.Offset,
					["S"] = v_u_149.Jump.Melee.Size.X.Scale
				},
				["Special"] = {
					["X"] = v_u_149.Jump.Special.Position.X.Offset,
					["Y"] = v_u_149.Jump.Special.Position.Y.Offset,
					["S"] = v_u_149.Jump.Special.Size.X.Scale
				},
				["Lock"] = {
					["X"] = v_u_149.ShiftLock.Lock.Position.X.Offset,
					["Y"] = v_u_149.ShiftLock.Lock.Position.Y.Offset,
					["S"] = v_u_149.ShiftLock.Lock.Size.X.Scale
				}
			}
			v164:Fire(v165)
		else
			local v166 = Color3.fromRGB(85, 255, 255)
			v_u_149.ShiftLock.Lock.ImageColor3 = v166
			v_u_149.ShiftLock.Lock.ImageLabel.ImageColor3 = v166
			for _, v167 in v_u_149.Jump:GetChildren() do
				v167.ImageColor3 = v166
				v167.ImageLabel.ImageColor3 = v166
			end
		end
	end)
	v_u_15.MobileLayout:Connect(function(p168)
		-- upvalues: (copy) v_u_149
		local v169 = p168 and p168[1] and {
			["Block"] = {
				["X"] = p168[1],
				["Y"] = p168[2]
			},
			["Dash"] = {
				["X"] = p168[3],
				["Y"] = p168[4]
			},
			["Melee"] = {
				["X"] = p168[5],
				["Y"] = p168[6]
			},
			["Special"] = {
				["X"] = p168[7],
				["Y"] = p168[8]
			}
		} or p168
		for _, v170 in {
			"Block",
			"Dash",
			"Melee",
			"Special",
			"Lock"
		} do
			local v171, v172, v173
			if v169 and v169[v170] then
				v171 = v169[v170].X or 0
				v172 = v169[v170].Y or 0
				v173 = v169[v170].S or 1
			else
				v171 = 0
				v172 = 0
				v173 = 1
			end
			local v174
			if v170 == "Lock" then
				v174 = v_u_149.ShiftLock.Lock
			else
				v174 = v_u_149.Jump:FindFirstChild(v170)
			end
			if not v174 then
				continue
			end
			v174.Position = UDim2.new(v174.Position.X.Scale, v171, v174.Position.Y.Scale, v172)
			v174.Size = UDim2.new(v173, 0, v173, 0)
		end
	end)
	local v175 = v_u_9.new()
	v175:setLabel("Reset Layout")
	v175:oneClick(true)
	v175.selected:Connect(function(_)
		-- upvalues: (copy) v_u_149, (copy) v_u_160
		v_u_149.ShiftLock.Lock.Size = UDim2.new(1, 0, 1, 0)
		v_u_149.ShiftLock.Lock.Position = UDim2.new(0.5, 0, 0.5, 0)
		for _, v176 in v_u_149.Jump:GetChildren() do
			v176.Position = UDim2.new(v176.Position.X.Scale, 0, v176.Position.Y.Scale, 0)
			v176.Size = UDim2.new(1, 0, 1, 0)
		end
		v_u_160:select()
	end)
	v_u_156:setDropdown({ v_u_160, v175 })
	local v_u_177 = v_u_159
	local v_u_178 = v_u_158
	local v_u_179 = v_u_157
	for _, v_u_180 in v_u_149.Jump:GetChildren() do
		v_u_180.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_179, (ref) v_u_178, (copy) v_u_180, (ref) v_u_177, (copy) p_u_144, (ref) v_u_20
			if v_u_179 == true then
				if v_u_178 == nil then
					v_u_178 = v_u_180
					v_u_177 = nil
				end
				return
			elseif v_u_180.Name == "Melee" then
				p_u_144:Melee()
				return
			elseif v_u_180.Name == "Block" then
				p_u_144:Block()
				return
			elseif v_u_180.Name == "Special" then
				p_u_144:Special()
			elseif v_u_180.Name == "Dash" then
				v_u_20:DashRequest()
			end
		end)
		v_u_180.InputEnded:Connect(function()
			-- upvalues: (copy) v_u_180, (ref) v_u_116, (ref) v_u_16, (copy) p_u_144
			if v_u_180.Name == "Melee" then
				v_u_116 = false
				return
			elseif v_u_180.Name == "Block" then
				v_u_16.Deactivated:Fire()
			elseif v_u_180.Name == "Special" then
				p_u_144:ReleaseSpecial()
			end
		end)
		v_u_180.MouseButton1Up:Connect(function()
			-- upvalues: (ref) v_u_179, (ref) v_u_178, (copy) v_u_180, (ref) v_u_177
			if v_u_179 == true and v_u_178 == v_u_180 then
				v_u_178 = nil
				v_u_177 = nil
			end
		end)
	end
	v_u_149.ShiftLock.Lock.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_179, (ref) v_u_178, (copy) v_u_149, (ref) v_u_177, (copy) p_u_144
		if v_u_179 == true then
			if v_u_178 == nil then
				v_u_178 = v_u_149.ShiftLock.Lock
				v_u_177 = nil
			end
		else
			_G.Shift = not _G.Shift
			p_u_144:UpdateShift()
		end
	end)
	v_u_149.ShiftLock.Lock.MouseButton1Up:Connect(function()
		-- upvalues: (ref) v_u_179, (ref) v_u_178, (copy) v_u_149, (ref) v_u_177
		if v_u_179 == true and v_u_178 == v_u_149.ShiftLock.Lock then
			v_u_178 = nil
			v_u_177 = nil
		end
	end)
	v_u_2.TouchPinch:Connect(function(p181, p182, _, p183)
		-- upvalues: (ref) v_u_178, (ref) v_u_177
		if v_u_178 then
			if p183 == Enum.UserInputState.Change then
				if not v_u_177 then
					v_u_177 = v_u_178.Size.X.Scale
				end
				local v184 = v_u_177 * p182
				local v185 = math.clamp(v184, 0.5, 2)
				v_u_178.Size = UDim2.new(v185, 0, v185, 0)
				local v186 = Vector2.new(0, 0)
				for _, v187 in p181 do
					v186 = v186 + v187
				end
				local v188 = v186 / #p181
				local v189 = v_u_178.Parent.AbsoluteSize * Vector2.new(v_u_178.Position.X.Scale, v_u_178.Position.Y.Scale)
				local v190 = v_u_178.Parent.AbsolutePosition + v189
				local v191 = Vector2.new(v188.X, v188.Y) - v190
				v_u_178.Position = UDim2.new(v_u_178.Position.X.Scale, v191.X, v_u_178.Position.Y.Scale, v191.Y)
			elseif p183 == Enum.UserInputState.End then
				v_u_177 = nil
				v_u_178 = nil
			end
		else
			v_u_177 = nil
			return
		end
	end)
	v_u_3.RenderStepped:Connect(function()
		-- upvalues: (copy) p_u_144, (copy) v_u_148, (ref) v_u_6, (copy) v_u_149, (ref) v_u_178, (ref) v_u_177, (ref) v_u_32, (copy) v_u_145
		if p_u_144.LastInput == "Mobile" then
			local v192 = false
			for _, v193 in v_u_148:GetChildren() do
				if not v193:IsA("Frame") or v193.Visible ~= true then
					continue
				end
				v192 = true
			end
			if v_u_6.PlayerGui:FindFirstChild("BuildTools") or v192 == true then
				v_u_149.Visible = false
			else
				v_u_149.Visible = true
			end
		end
		if v_u_149.Visible == true then
			if v_u_178 and not v_u_177 then
				local v194 = v_u_178.Parent.AbsoluteSize * Vector2.new(v_u_178.Position.X.Scale, v_u_178.Position.Y.Scale)
				local v195 = v_u_178.Parent.AbsolutePosition + v194
				local v196 = Vector2.new(v_u_32.X, v_u_32.Y) - v195
				v_u_178.Position = UDim2.new(v_u_178.Position.X.Scale, v196.X, v_u_178.Position.Y.Scale, v196.Y)
			end
			local v197 = v_u_145.AbsoluteSize
			local v198 = v197.X
			local v199 = v197.Y
			local v200 = math.min(v198, v199) <= 500
			local v201 = v200 and 70 or 120
			v_u_149.Jump.Size = UDim2.new(0, v201, 0, v201)
			v_u_149.Jump.Position = v200 and UDim2.new(1, -(v201 * 1.5 - 10), 1, -v201 - 20) or UDim2.new(1, -(v201 * 1.5 - 10), 1, -v201 * 1.75)
		end
	end)
	v_u_145.Respawn.MouseButton1Click:Connect(function()
		-- upvalues: (ref) v_u_1, (ref) v_u_14, (copy) v_u_145, (ref) v_u_5, (ref) v_u_15
		v_u_1.GetController("FXController"):PlaySound(v_u_14.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_145.Respawn.Size = UDim2.new(0, 290, 0, 50)
		v_u_5:Create(v_u_145.Respawn, TweenInfo.new(0.1), {
			["Size"] = UDim2.new(0, 300, 0, 60)
		}):Play()
		v_u_15.Respawn:Fire()
	end)
	local v_u_202 = 0
	local v_u_203 = true
	local v_u_204 = false
	v_u_3.Stepped:Connect(function(p205, p206)
		-- upvalues: (ref) v_u_6, (copy) v_u_146, (copy) p_u_144, (ref) v_u_202, (ref) v_u_4, (ref) v_u_5, (ref) v_u_204, (copy) v_u_145, (ref) v_u_203, (copy) v_u_147
		local v207 = v_u_6.Character
		if v207:FindFirstChild("Info") then
			local v208 = v_u_6:GetAttribute("Ultimate")
			local v209 = v_u_146.Fill
			local v210 = UDim2.new
			local v211 = v_u_146.Fill.Size.X.Scale
			local v212 = v208 / 100
			local v213 = 10 * p206
			v209.Size = v210(v211 + (v212 - v211) * v213, 0, 1, 0)
			local v214 = false
			local v215
			if v207 and not v207:GetAttribute("InUlt") then
				v215 = not v207.Info:GetAttribute("Ult") or false
			else
				v215 = false
			end
			if v207:GetAttribute("Moveset") == "Yuki" then
				v215 = v215 and v207:GetAttribute("Dead")
				if v215 then
					v215 = not v207:GetAttribute("LastResort")
				end
			end
			if v207:GetAttribute("Moveset") == "Haruta" then
				if v215 then
					v215 = v207:GetAttribute("Sword") == nil
				end
			end
			if v207:GetAttribute("Moveset") == "MeiMei" then
				v214 = v207.Info:FindFirstChild("ControlRemote")
				if v214 then
					v214 = v207.Info.ControlRemote:GetAttribute("Active")
				end
			end
			if v207:GetAttribute("Moveset") == "Reggie" then
				v214 = v207:GetAttribute("InUlt") == true
			end
			if v207:GetAttribute("Moveset") == "Uro" then
				v214 = v207:GetAttribute("InUlt") == true and v208 >= 100 and true or v207:GetAttribute("Ult2") == 100
			end
			v_u_146.Ready.Visible = p_u_144.ShowReady == true and p_u_144.ShowReady or (v215 and v208 >= 100 and true or v214 == true)
			if v207:GetAttribute("Ult2") then
				v_u_146.Fill2.Visible = true
				local v216 = v_u_146.Fill2
				local v217 = UDim2.new
				local v218 = v_u_146.Fill2.Size.X.Scale
				local v219 = v207:GetAttribute("Ult2") / 100
				local v220 = 10 * p206
				v216.Size = v217(v218 + (v219 - v218) * v220, 0, 0, 4)
				v_u_146.Fill2.BackgroundColor3 = Color3.fromHSV(p205 % 1, 0.7, 1)
			else
				v_u_146.Fill2.Visible = false
				v_u_146.Fill2.Size = UDim2.new(0, 0, 0, 4)
			end
			if v208 >= 100 and (v_u_202 < 100 and (v207 and not v207:GetAttribute("InUlt"))) then
				local v221 = Instance.new("Highlight", v207)
				v_u_4:AddItem(v221, 2)
				v221.FillColor = Color3.new(1, 1, 1)
				v221.FillTransparency = 0
				v_u_5:Create(v221, TweenInfo.new(1.25), {
					["FillTransparency"] = 1
				}):Play()
				v_u_5:Create(v221, TweenInfo.new(2), {
					["OutlineTransparency"] = 1
				}):Play()
				local v222 = Instance.new("PointLight", v207.Torso)
				v222.Brightness = 10
				v_u_4:AddItem(v222, 2)
				v_u_5:Create(v222, TweenInfo.new(2), {
					["Brightness"] = 0,
					["Range"] = 4
				}):Play()
			end
			v_u_202 = v208
			local v223 = v_u_6:GetAttribute("UI") ~= false and not v207.Info:FindFirstChild("DomainClash") and true or false
			local v224
			if v207:GetAttribute("CanRespawn") and not (v207.Info:GetAttribute("NoRes") or v207.Info:FindFirstChild("NoRes")) then
				v224 = true
				v223 = false
			else
				v224 = false
			end
			if v_u_204 == false and v224 == true then
				v_u_204 = true
				v_u_145.Respawn.Visible = true
				v_u_145.Respawn.BackgroundTransparency = 1
				v_u_145.Respawn.TextTransparency = 1
				v_u_145.Respawn.Key.Key.TextTransparency = 1
				v_u_145.Respawn.Key.KeyIcon.ImageTransparency = 1
				local v225 = TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
				v_u_5:Create(v_u_145.Respawn, v225, {
					["BackgroundTransparency"] = 0.5,
					["TextTransparency"] = 0
				}):Play()
				v_u_5:Create(v_u_145.Respawn.Key.Key, v225, {
					["TextTransparency"] = 0.5
				}):Play()
				v_u_5:Create(v_u_145.Respawn.Key.KeyIcon, v225, {
					["ImageTransparency"] = 0.5
				}):Play()
			elseif v_u_204 == true and v224 == false then
				v_u_204 = false
				v_u_145.Respawn.Visible = false
			end
			if v_u_203 == true and v223 == false then
				v_u_5:Create(v_u_147, TweenInfo.new(0.9), {
					["Position"] = UDim2.new(0.5, 0, 1, 50)
				}):Play()
				v_u_5:Create(v_u_146, TweenInfo.new(0.9), {
					["Position"] = UDim2.new(0.5, 0, 1, 75)
				}):Play()
				v_u_5:Create(v_u_146.Parent.Evade, TweenInfo.new(0.9), {
					["Position"] = UDim2.new(0.5, -150, 1, 87)
				}):Play()
				v_u_5:Create(v_u_146.Parent.Special, TweenInfo.new(0.9), {
					["Position"] = UDim2.new(0.5, 150, 1, 87)
				}):Play()
				v_u_5:Create(v_u_145.Controls.Moveset, TweenInfo.new(0.6), {
					["Position"] = UDim2.new(0.5, 0, 1, 160)
				}):Play()
				if v_u_145.Parent:FindFirstChild("Miracles") then
					v_u_5:Create(v_u_145.Parent.Miracles.Miracles, TweenInfo.new(0.9), {
						["Position"] = UDim2.new(0.5, 0, 1, 50)
					}):Play()
				end
			elseif v_u_203 == false and v223 == true then
				v_u_5:Create(v_u_147, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Position"] = UDim2.new(0.5, 0, 1, -115)
				}):Play()
				v_u_5:Create(v_u_146, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Position"] = UDim2.new(0.5, 0, 1, -90)
				}):Play()
				v_u_5:Create(v_u_146.Parent.Evade, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Position"] = UDim2.new(0.5, -150, 1, -78)
				}):Play()
				v_u_5:Create(v_u_146.Parent.Special, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Position"] = UDim2.new(0.5, 150, 1, -78)
				}):Play()
				v_u_5:Create(v_u_145.Controls.Moveset, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Position"] = UDim2.new(0.5, 0, 1, -5)
				}):Play()
				if v_u_145.Parent:FindFirstChild("Miracles") then
					v_u_5:Create(v_u_145.Parent.Miracles.Miracles, TweenInfo.new(1.5), {
						["Position"] = UDim2.new(0.5, 0, 1, -115)
					}):Play()
				end
			end
			v_u_203 = v223
		end
	end)
	local function v_u_229() -- name: updateVisibility
		-- upvalues: (ref) v_u_6, (copy) v_u_145
		local v226 = v_u_6.Character:GetAttribute("InUlt") == true and true or nil
		for _, v227 in v_u_145.Controls.Moveset:GetChildren() do
			if not v227:IsA("Frame") or v227:GetAttribute("FakeMove") then
				continue
			end
			local v228 = v227.Item.Value
			if v228 and v228:IsDescendantOf(workspace.Characters) then
				if v228:GetAttribute("AWK") and v226 or (v228:GetAttribute("AWK2") and not v226 or v228.Parent.Name ~= "Moveset") then
					v227.Visible = false
				else
					v227.Visible = true
				end
			else
				v227.Visible = false
			end
		end
	end
	local v_u_230 = {}
	local function v_u_249(p_u_231, p_u_232) -- name: createItem
		-- upvalues: (copy) v_u_230, (ref) v_u_24, (copy) v_u_145, (ref) v_u_7, (ref) v_u_10, (copy) p_u_144, (ref) v_u_31, (copy) v_u_229, (ref) v_u_6, (ref) v_u_5, (ref) v_u_13, (ref) v_u_14, (ref) v_u_4
		if p_u_231:IsA("NumberValue") then
			if not v_u_230[p_u_231] then
				if p_u_231.Name == "Custom" and p_u_231:GetAttribute("USE") then
					task.spawn(function()
						-- upvalues: (ref) v_u_24, (copy) p_u_231
						repeat
							v_u_24:UseTool(p_u_231, "Activated")
							task.wait(0.5)
						until not (p_u_231:IsDescendantOf(workspace.Characters) and p_u_231:GetAttribute("USE"))
					end)
				end
				local v_u_233 = v_u_145.Preset.Item:Clone()
				local v_u_234 = v_u_233.Cooldown
				v_u_233.Name = p_u_231.Name
				v_u_233.ItemName.Text = p_u_231:GetAttribute("Tag") or p_u_231.Name
				v_u_233.Parent = v_u_145.Controls.Moveset
				v_u_230[p_u_231] = v_u_233
				if p_u_231:GetAttribute("Key") then
					v_u_233.LayoutOrder = p_u_231:GetAttribute("Key")
					v_u_233.Key.Key.Text = p_u_231:GetAttribute("Key")
					local v235 = v_u_7.Keybind.Combat:FindFirstChild("Skill " .. p_u_231:GetAttribute("Key"))
					if v235 then
						v_u_10:updateKeyText(v_u_233.Key, v235)
					end
					v_u_233.ItemName.MouseButton1Down:Connect(function()
						-- upvalues: (ref) p_u_144, (copy) p_u_231
						local v236 = p_u_231
						p_u_144:UseKey(tonumber(v236:GetAttribute("Key")), "Activated")
					end)
					v_u_233.ItemName.MouseButton1Up:Connect(function()
						-- upvalues: (ref) p_u_144, (copy) p_u_231
						local v237 = p_u_231
						p_u_144:UseKey(tonumber(v237:GetAttribute("Key")), "Deactivated")
					end)
				end
				p_u_231:GetAttributeChangedSignal("Tip"):Connect(function() -- name: updateTip
					-- upvalues: (copy) p_u_231, (copy) v_u_233
					if p_u_231:GetAttribute("Tip") then
						v_u_233.Tip.Text = p_u_231:GetAttribute("Tip")
						v_u_233.Tip.Visible = true
					else
						v_u_233.Tip.Visible = false
					end
				end)
				if p_u_231:GetAttribute("Tip") then
					v_u_233.Tip.Text = p_u_231:GetAttribute("Tip")
					v_u_233.Tip.Visible = true
				else
					v_u_233.Tip.Visible = false
				end
				v_u_233.Item.Value = p_u_231
				v_u_233:GetPropertyChangedSignal("Visible"):Connect(function()
					-- upvalues: (copy) v_u_233, (ref) v_u_31, (copy) p_u_231
					if not v_u_233.Visible then
						if v_u_31.Value == p_u_231 then
							v_u_31.Value = nil
						end
					end
				end)
				p_u_231.AncestryChanged:Connect(function()
					-- upvalues: (copy) p_u_231, (ref) v_u_229, (copy) p_u_232, (copy) v_u_233, (ref) v_u_230, (ref) v_u_31
					if p_u_231:IsDescendantOf(workspace.Characters) then
						task.defer(v_u_229)
						return
					elseif p_u_231.Parent ~= p_u_232 and not p_u_231:IsDescendantOf(p_u_232) then
						v_u_233:Destroy()
						v_u_230[p_u_231] = nil
						if v_u_31.Value == p_u_231 then
							v_u_31.Value = nil
						end
					end
				end)
				p_u_231:GetPropertyChangedSignal("Name"):Connect(function()
					-- upvalues: (copy) v_u_233, (copy) p_u_231
					v_u_233.Name = p_u_231.Name
					v_u_233.ItemName.Text = p_u_231:GetAttribute("Tag") or p_u_231.Name
				end)
				p_u_231:GetAttributeChangedSignal("Tag"):Connect(function()
					-- upvalues: (copy) v_u_233, (copy) p_u_231
					v_u_233.Name = p_u_231.Name
					v_u_233.ItemName.Text = p_u_231:GetAttribute("Tag") or p_u_231.Name
				end)
				if p_u_231:GetAttribute("LastUse") then
					local v_u_238 = false
					p_u_231:GetAttributeChangedSignal("LastUse"):Connect(function()
						-- upvalues: (ref) v_u_238, (copy) p_u_231, (copy) v_u_234, (copy) v_u_233, (ref) v_u_6, (ref) v_u_5
						if v_u_238 ~= true then
							v_u_238 = true
							local v_u_239 = p_u_231:GetAttribute("SkipTo")
							local v240 = p_u_231:GetAttribute("ReadyAt") or 0
							local v241 = v240 - workspace:GetServerTimeNow()
							local v242 = nil
							local v243 = p_u_231:GetAttribute("ReadyAt") or 0
							if p_u_231:GetAttribute("Paused") then
								if not v242 then
									workspace:GetServerTimeNow()
									v242 = p_u_231:GetAttributeChangedSignal("Paused"):Once(function()
										-- upvalues: (ref) p_u_231, (ref) v_u_239
										p_u_231:GetAttributeChangedSignal("SkipTo"):Once(function()
											-- upvalues: (ref) v_u_239, (ref) p_u_231
											v_u_239 = p_u_231:GetAttribute("SkipTo")
										end)
									end)
								end
								task.wait()
							else
								if v240 == v243 then
									v243 = v240
								else
									v241 = v243 - workspace:GetServerTimeNow()
									v_u_239 = nil
								end
								local v244 = ((v_u_239 or v243) - workspace:GetServerTimeNow()) / v241
								local v245 = math.clamp(v244, 0, 1)
								v_u_234.Size = UDim2.new(1, 0, v245, 0)
								task.wait()
								v240 = v243
							end
							if (v_u_239 or v240) > workspace:GetServerTimeNow() and (p_u_231.Parent and (v_u_233.Parent and not (v_u_6.Character and (v_u_6.Character:FindFirstChild("Info") and v_u_6.Character.Info:GetAttribute("CD"))))) then
								continue
							end
							if v242 then
								v242:Disconnect()
							end
							v_u_238 = false
							if v_u_233.Parent then
								v_u_234.Size = UDim2.new(1, 0, 0, 0)
								v_u_233.BackgroundColor3 = Color3.new(1, 1, 1)
								v_u_5:Create(v_u_233, TweenInfo.new(1), {
									["BackgroundColor3"] = Color3.fromRGB(31, 31, 31)
								}):Play()
							end
						end
					end)
				end
				local v_u_246 = nil
				local function v248() -- name: reggieSeal
					-- upvalues: (copy) p_u_231, (ref) v_u_246, (ref) v_u_13, (copy) v_u_233, (ref) v_u_5, (ref) v_u_14, (ref) v_u_6, (ref) v_u_4
					if p_u_231:GetAttribute("Seal") then
						if v_u_246 == nil then
							v_u_246 = v_u_13.Reggie.ReggieSeal:Clone()
							v_u_246.Visible = true
							v_u_246.Parent = v_u_233
						end
						v_u_246.Icon.ImageColor3 = p_u_231:GetAttribute("Seal") == 2 and Color3.fromRGB(255, 200, 0) or Color3.fromRGB(255, 0, 0)
						v_u_246.Icon.UIGradient.Enabled = false
						if p_u_231:GetAttribute("Seal") == 3 then
							v_u_246.Icon.ImageColor3 = Color3.fromRGB(255, 255, 255)
							v_u_246.Icon.UIGradient.Enabled = true
						end
						v_u_233.BackgroundColor3 = Color3.new(1, 1, 1)
						v_u_5:Create(v_u_233, TweenInfo.new(1), {
							["BackgroundColor3"] = Color3.fromRGB(31, 31, 31)
						}):Play()
						local v247 = v_u_14.Reggie.Stamp:Clone()
						v247.SoundGroup = game.SoundService.Effect
						v247.Parent = v_u_6.PlayerGui
						v247:Play()
						v_u_4:AddItem(v247, v247.TimeLength)
					elseif v_u_246 and v_u_246.Parent then
						v_u_246:Destroy()
						v_u_246 = nil
					end
				end
				v248()
				p_u_231:GetAttributeChangedSignal("Seal"):Connect(v248)
			end
		else
			return
		end
	end
	local function v_u_263(p250) -- name: getColorSequenceFromStr
		local v251 = {}
		for _, v252 in string.split(p250, " ") do
			local v253 = string.split(v252, ",")
			local v254 = v253[1]
			local v255 = tonumber(v254)
			local v256 = v253[2]
			local v257 = tonumber(v256)
			local v258 = v253[3]
			local v259 = tonumber(v258)
			if not (v255 and (v257 and v259)) then
				continue
			end
			v251[#v251 + 1] = Color3.fromRGB(math.clamp(v255, 0, 255), math.clamp(v257, 0, 255), (math.clamp(v259, 0, 255)))
		end
		if #v251 == 0 then
			return ColorSequence.new(Color3.new(1, 1, 1))
		end
		if #v251 == 1 then
			return ColorSequence.new(v251[1])
		end
		local v260 = {}
		for v261, v262 in v251 do
			v260[v261] = ColorSequenceKeypoint.new((v261 - 1) / (#v251 - 1), v262)
		end
		return ColorSequence.new(v260)
	end
	local function v_u_268(p264) -- name: updateUlt
		-- upvalues: (ref) v_u_11, (copy) v_u_147, (copy) v_u_146, (copy) v_u_263
		local v265 = p264:GetAttribute("Moveset")
		if v_u_11[v265] then
			v_u_147.Visible = true
			v_u_146.Visible = true
			v_u_147.Text = p264:GetAttribute("CustomUlt") or v_u_11[v265][1]
			if p264:GetAttribute("CustomUltC") then
				v_u_146.Fill.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
				v_u_146.Fill.UIGradient.Color = v_u_263(p264:GetAttribute("CustomUltC"))
			else
				v_u_146.Fill.BackgroundColor3 = v_u_11[v265][2]
				v_u_146.Fill.UIGradient.Color = ColorSequence.new(v_u_11[v265][3], Color3.new(1, 1, 1))
			end
			v_u_146.Parent.Special.Fill.BackgroundColor3 = v_u_146.Fill.BackgroundColor3
			v_u_146.Parent.Special.Fill.UIGradient.Color = v_u_146.Fill.UIGradient.Color
			for _, v266 in v_u_146.Ready:GetDescendants() do
				if v266:IsA("TextLabel") then
					v266.TextTransparency = v_u_11[v265][4] and 0 or 1
				else
					if not v266:IsA("UIStroke") then
						continue
					end
					v266.Enabled = v_u_11[v265][4]
				end
			end
			if v_u_11[v265][5] and not v_u_146.Fill:FindFirstChild("CustomImage") then
				local v267 = Instance.new("ImageLabel")
				v267.Image = "rbxassetid://" .. v_u_11[v265][5]
				v267.Size = UDim2.fromScale(1, 1)
				v267.BackgroundTransparency = 1
				v267.Name = "CustomImage"
				v267.Parent = v_u_146
				return
			end
			if v_u_146:FindFirstChild("CustomImage") then
				v_u_146.CustomImage:Destroy()
				return
			end
		else
			v_u_147.Visible = false
			v_u_146.Visible = false
		end
	end
	v_u_31:GetPropertyChangedSignal("Value"):Connect(function()
		-- upvalues: (ref) v_u_31, (copy) v_u_145, (copy) v_u_230
		local v269 = v_u_31.Value
		for _, v270 in v_u_145.Controls.Moveset:GetChildren() do
			if not v270:IsA("Frame") then
				continue
			end
			v270.Outline.Enabled = false
		end
		if v269 ~= nil and v_u_230[v269] then
			v_u_230[v269].Outline.Enabled = true
		end
	end)
	local function v291(p_u_271) -- name: characterLoad
		-- upvalues: (ref) v_u_5, (ref) v_u_6, (copy) v_u_145, (copy) v_u_230, (copy) v_u_268, (ref) v_u_31, (copy) v_u_249, (copy) v_u_229, (copy) v_u_146, (ref) v_u_3, (ref) v_u_12
		v_u_5:Create(workspace.CurrentCamera, TweenInfo.new(0), {
			["FieldOfView"] = 70
		}):Play()
		v_u_5:Create(v_u_6, TweenInfo.new(0), {
			["CameraMaxZoomDistance"] = 30
		}):Play()
		if not p_u_271:IsDescendantOf(workspace.Effects) then
			local v272 = p_u_271:WaitForChild("Moveset")
			for _, v273 in v_u_145.Controls.Moveset:GetChildren() do
				if not v273:IsA("Frame") or v273:GetAttribute("FakeMove") then
					continue
				end
				for v276, v275 in v_u_230 do
					if v275 ~= v273 then
						continue
					end
				end
				local v276 = nil
				if v276 and (v276.Parent == v272 and v276:IsDescendantOf(v272)) then
					break
				end
				v273:Destroy()
			end
			p_u_271:GetAttributeChangedSignal("Moveset"):Connect(function()
				-- upvalues: (ref) v_u_268, (copy) p_u_271
				v_u_268(p_u_271)
			end)
			p_u_271:GetAttributeChangedSignal("CustomUlt"):Connect(function()
				-- upvalues: (ref) v_u_268, (copy) p_u_271
				v_u_268(p_u_271)
			end)
			p_u_271:GetAttributeChangedSignal("CustomUltC"):Connect(function()
				-- upvalues: (ref) v_u_268, (copy) p_u_271
				v_u_268(p_u_271)
			end)
			v_u_31.Value = nil
			v_u_268(p_u_271)
			local v_u_277 = p_u_271:WaitForChild("Moveset")
			local v_u_278 = p_u_271:WaitForChild("Info")
			if #v_u_277:GetChildren() > 0 then
				for _, v279 in v_u_277:GetDescendants() do
					v_u_249(v279, v_u_277)
				end
				v_u_229()
			end
			v_u_277.DescendantAdded:Connect(function(p280)
				-- upvalues: (ref) v_u_249, (copy) v_u_277, (ref) v_u_229
				v_u_249(p280, v_u_277)
				v_u_229()
			end)
			p_u_271:GetAttributeChangedSignal("InUlt"):Connect(v_u_229)
			v_u_229()
			local v_u_281 = false
			v_u_146.Parent.Special.Fill.Size = UDim2.new(1, 0, 1, 0)
			p_u_271:GetAttributeChangedSignal("LastM2"):Connect(function()
				-- upvalues: (ref) v_u_281, (copy) p_u_271, (ref) v_u_146, (ref) v_u_6, (copy) v_u_278
				if v_u_281 == true then
					return
				else
					v_u_281 = true
					local v282 = p_u_271:GetAttribute("M2_CD") or 0
					local _ = p_u_271:GetAttribute("LastM2") or 0
					if v282 <= 0 then
						v_u_146.Parent.Special.Fill.Size = UDim2.new(1, 0, 1, 0)
						v_u_281 = false
					else
						repeat
							local v283 = p_u_271:GetAttribute("M2_CD") or 0
							local v284 = p_u_271:GetAttribute("LastM2") or 0
							local v285 = (workspace:GetServerTimeNow() - v284) / v283
							local v286 = math.clamp(v285, 0, 1)
							v_u_146.Parent.Special.Fill.Size = UDim2.new(v286, 0, 1, 0)
							task.wait()
						until not v_u_6.Character.Parent or (v283 <= workspace:GetServerTimeNow() - v284 or v_u_278:GetAttribute("CD"))
						v_u_146.Parent.Special.Fill.Size = UDim2.new(1, 0, 1, 0)
						v_u_281 = false
					end
				end
			end)
			task.spawn(function()
				-- upvalues: (copy) p_u_271, (ref) v_u_3, (ref) v_u_12
				local v287 = p_u_271:GetAttribute("Moveset")
				if not v287 then
					p_u_271:GetAttributeChangedSignal("Moveset"):Wait()
					v287 = p_u_271:GetAttribute("Moveset")
				end
				v_u_3.Stepped:Wait()
				local v288 = v_u_12:FindFirstChild(v287)
				if not v288 then
					if v287 == "Mokou" then
						v288 = v_u_12.Misc.M
					elseif v287 == "Chara" then
						v288 = v_u_12.Misc.C
					end
					if not v288 then
						return
					end
				end
				for _, v289 in v288:GetDescendants() do
					if not v289:IsA("Animation") then
						continue
					end
					p_u_271.Humanoid:LoadAnimation(v289)
				end
				for _, v290 in v_u_12.Misc.Hits:GetDescendants() do
					if not v290:IsA("Animation") then
						continue
					end
					p_u_271.Humanoid:LoadAnimation(v290)
				end
			end)
		end
	end
	if v_u_6.Character then
		v291(v_u_6.Character)
	end
	v_u_6.CharacterAdded:Connect(v291)
	p_u_144.LastInput = v_u_24:GetPlatform(v_u_2.PreferredInput)
	v_u_38()
	if p_u_144.LastInput ~= "Mobile" then
		v_u_156:setEnabled(false)
	end
	v_u_2:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		-- upvalues: (copy) p_u_144, (ref) v_u_2, (ref) v_u_38, (copy) v_u_156, (ref) v_u_20
		local v292 = p_u_144:GetPlatform(v_u_2.PreferredInput)
		if v292 and v292 ~= p_u_144.LastInput then
			p_u_144.LastInput = v292
			v_u_38()
			v_u_156:setEnabled(v292 == "Mobile")
			if v292 ~= "Xbox" and v292 ~= "Playstation" then
				v_u_20.LockOn = nil
			end
		end
	end)
	local function v296(p293) -- name: removeFromView
		-- upvalues: (ref) v_u_34, (copy) p_u_144
		local v294 = true
		for _, v295 in v_u_34:GetTags(p293) do
			if v295 ~= p_u_144.LastInput then
				continue
			end
			v294 = false
		end
		if v294 == true then
			p293.Visible = false
		end
	end
	v_u_34:GetInstanceAddedSignal("Xbox"):Connect(v296)
	v_u_34:GetInstanceAddedSignal("Playstation"):Connect(v296)
	v_u_34:GetInstanceAddedSignal("Mobile"):Connect(v296)
	v_u_34:GetInstanceAddedSignal("Keyboard"):Connect(v296)
end
function v_u_24.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_15, (copy) v_u_1, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18, (ref) v_u_19, (ref) v_u_20, (ref) v_u_21, (ref) v_u_22
	v_u_15 = v_u_1.GetService("JoinService")
	v_u_16 = v_u_1.GetService("BlockService")
	v_u_17 = v_u_1.GetService("MovementService")
	v_u_18 = v_u_1.GetService("EmoteService")
	v_u_19 = v_u_1.GetService("ItemService")
	v_u_20 = v_u_1.GetController("MovementController")
	v_u_21 = v_u_1.GetController("HandicapController")
	v_u_22 = v_u_1.GetController("CopyController")
end
return v_u_24