-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Combat.HitboxController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v3 = game.ReplicatedStorage
local v4 = v3.Remotes
local v5 = v3.Utils
local v_u_6 = v_u_1.CreateController({
	["Name"] = "HitboxController"
})
local v_u_7 = OverlapParams.new()
v_u_7.FilterType = Enum.RaycastFilterType.Include
v_u_7.FilterDescendantsInstances = { workspace.Characters }
local v_u_8 = nil
v4.GetClient.OnClientEvent:Connect(function(p9)
	local v10 = workspace.CurrentCamera.CFrame
	if p9 and p9.Parent then
		p9:FireServer(v10)
	end
end)
local v_u_11 = v5.Hitbox.HitSphere
function v_u_6.SphereHitbox(_, p12, p13, p14) -- name: SphereHitbox
	-- upvalues: (copy) v_u_11, (copy) v_u_2, (copy) v_u_7
	if p12 then
		p13 = (p12.HumanoidRootPart.CFrame * p13).Position
	end
	if v_u_11.Transparency ~= 1 then
		local _ = Vector3.new(1, 1, 1) * p14
		local v15 = v_u_11:Clone()
		v15.Position = p13
		v15.Size = Vector3.new(1, 1, 1) * p14
		v15.Parent = workspace.Effects
		v_u_2:AddItem(v15, 0.5)
	end
	local v16 = {}
	for _, v17 in workspace:GetPartBoundsInRadius(p13, p14 / 2, v_u_7) do
		if v17.Name ~= "HumanoidRootPart" or (v17.Parent == p12 or not v17.Parent:FindFirstChild("Humanoid")) then
			continue
		end
		local v18 = v17.Parent
		table.insert(v16, v18)
	end
	return v16
end
function v_u_6.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_8, (copy) v_u_6
	v_u_8.Hitbox:Connect(function(p19, p20, p21, p22, p23)
		-- upvalues: (ref) v_u_6
		if p19.HumanoidRootPart then
			local v24 = v_u_6:SphereHitbox(p19, p20, p21)
			if #v24 > 0 then
				p22:FireServer(v24)
			end
			task.wait(0.025)
			if p22.Parent and (not p23 or p23.Parent) then
				continue
			end
		end
	end)
end
function v_u_6.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_8, (copy) v_u_1
	v_u_8 = v_u_1.GetService("HitboxService")
end
return v_u_6