-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Hiromi.HiromiController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local v_u_7 = v_u_6.Animations
local v_u_8 = v_u_6.Utils
local v_u_9 = v_u_6.Sounds
local v_u_10 = require(v_u_6.Modules.CameraShaker)
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "HiromiController"
})
local function v_u_18(p15, p16) -- name: dialogBox
	-- upvalues: (ref) v_u_13, (copy) v_u_9, (copy) v_u_8, (copy) v_u_3, (copy) v_u_4
	if p15.Head:FindFirstChild("HiromiText") then
		p15.Head.HiromiText:Destroy()
	end
	v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.Talk, p15.Head, game.SoundService.Voice)
	local v_u_17 = v_u_8.Hiromi.DeadlySentencing.HiromiText:Clone()
	v_u_17.TextLabel.Text = p16
	v_u_17.Parent = p15.Head
	v_u_3:AddItem(v_u_17, 1.5)
	task.delay(1, function()
		-- upvalues: (copy) v_u_17, (ref) v_u_4
		if v_u_17.Parent then
			v_u_4:Create(v_u_17.TextLabel, TweenInfo.new(0.5), {
				["BackgroundTransparency"] = 1,
				["TextTransparency"] = 1
			}):Play()
			v_u_4:Create(v_u_17.TextLabel.UIStroke, TweenInfo.new(0.5), {
				["Transparency"] = 1
			}):Play()
		end
	end)
end
function v14.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_13, (copy) v_u_9, (copy) v_u_8, (copy) v_u_3, (copy) v_u_4, (copy) v_u_7, (copy) v_u_5, (copy) v_u_10, (copy) v_u_6, (copy) v_u_18, (copy) v_u_2, (ref) v_u_11
	local v_u_240 = {
		["Hit"] = function(p19, p20)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v21 = p19:FindFirstChild("HumanoidRootPart")
			if v21 then
				v_u_13:Flash(p19, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit" .. p20), v21, game.SoundService.Effect)
			end
		end,
		["Dodge2"] = function(p22)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_7
			local v23 = p22:FindFirstChild("HumanoidRootPart")
			if v23 then
				local v24 = v_u_8.Damage.HitGlow:Clone()
				if p22:GetScale() ~= 1 then
					v24:ScaleTo(p22:GetScale())
				end
				v24.Parent = workspace.Effects
				v_u_3:AddItem(v24, 0.5)
				for _, v25 in v24:GetChildren() do
					local v26 = p22:FindFirstChild(v25.Name)
					if v26 then
						v25.CFrame = v26.CFrame
					end
					v25.Color = Color3.new(0, 0, 0)
					v25.Anchored = true
					v_u_4:Create(v25, TweenInfo.new(0.5), {
						["Transparency"] = 1
					}):Play()
				end
				v_u_13:PlaySound(v_u_9.Itadori.ManjiKick.Dodge, v23, game.SoundService.Effect)
				local v27 = {
					"Dodge1",
					"Dodge2",
					"Dodge3",
					"Dodge4",
					"Dodge5"
				}
				for _, v28 in p22.Humanoid:GetPlayingAnimationTracks() do
					if not table.find(v27, v28.Name) then
						continue
					end
					v28:Stop(0.02)
				end
				p22.Humanoid:LoadAnimation(v_u_7.Hiromi.Dodge:GetChildren()[math.random(1, 5)]):Play(0.02)
			end
		end,
		["Dodge"] = function(p29)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_7
			local v30 = p29:FindFirstChild("HumanoidRootPart")
			if v30 then
				local v31 = v_u_8.Damage.HitGlow:Clone()
				if p29:GetScale() ~= 1 then
					v31:ScaleTo(p29:GetScale())
				end
				v31.Parent = workspace.Effects
				v_u_3:AddItem(v31, 0.5)
				for _, v32 in v31:GetChildren() do
					local v33 = p29:FindFirstChild(v32.Name)
					if v33 then
						v32.CFrame = v33.CFrame
					end
					v32.Color = Color3.new(1, 0.807843, 0.423529)
					v32.Anchored = true
					v32.Transparency = 0.1
					v_u_4:Create(v32, TweenInfo.new(0.5), {
						["Transparency"] = 1
					}):Play()
				end
				v_u_13:PlaySound(v_u_9.Itadori.ManjiKick.Dodge, v30, game.SoundService.Effect)
				local v34 = {
					"Dodge1",
					"Dodge2",
					"Dodge3",
					"Dodge4",
					"Dodge5"
				}
				for _, v35 in p29.Humanoid:GetPlayingAnimationTracks() do
					if not table.find(v34, v35.Name) then
						continue
					end
					v35:Stop(0.02)
				end
				p29.Humanoid:LoadAnimation(v_u_7.Hiromi.Dodge:GetChildren()[math.random(1, 5)]):Play(0.02)
			end
		end,
		["ChaseHit"] = function(p36, p37)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3
			local v38 = p36:FindFirstChild("HumanoidRootPart")
			if v38 then
				local v39 = p37:FindFirstChild("HumanoidRootPart")
				if v39 then
					v_u_13:Flash(p37, Color3.new(1, 1, 1))
					v_u_13:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit3"), v39, game.SoundService.Effect)
					local v40 = v_u_8.ChaseHit:Clone()
					local v41 = CFrame.new
					local v42 = v39.Position
					local v43 = v38.Position.X
					local v44 = v39.Position.Y
					local v45 = v38.Position.Z
					v40.CFrame = v41(v42, (Vector3.new(v43, v44, v45))) * CFrame.Angles(0, 3.141592653589793, 0)
					v40.Parent = workspace.Effects
					v40.Ring:Emit(7)
					v40.Sparks:Emit(12)
					v_u_3:AddItem(v40, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p46)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9
			local v47 = p46.HumanoidRootPart
			if v47 then
				local v48 = v_u_8.Gojo.LapseBlue.Throw:Clone()
				v48.CFrame = v47.CFrame * CFrame.new(0, 1, -4)
				v48.Size = Vector3.new(0, 0, 2)
				v48.Parent = workspace.Effects
				v_u_4:Create(v48, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v48, 0.3)
				v_u_13:PlaySound(v_u_9.Misc.Chase, v47, game.SoundService.Effect)
				v_u_13:DustTrail(p46, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p49)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v50 = p49:FindFirstChild("HumanoidRootPart")
			if v50 then
				v_u_13:PlaySound(v_u_9.Misc.Swing.Fist, v50, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p51, p52, p53)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3
			local v54 = p51.HumanoidRootPart
			if v54 then
				if p53 == "Down" then
					v_u_13:ArmFlash(p51["Right Leg"], Color3.fromRGB(179, 130, 61), 0.4)
					v_u_13:PlaySound(v_u_9.Misc.Swing.Fist, v54, game.SoundService.Effect)
					return
				elseif p53 == "Up" then
					v_u_13:ArmFlash(p51["Left Arm"], Color3.fromRGB(179, 130, 61), 0.3)
					v_u_13:PlaySound(v_u_9.Misc.Swing.Fist, v54, game.SoundService.Effect)
					return
				else
					local v55 = p51.SetAssets:FindFirstChild("Gavel")
					local v56 = p51.SetAssets:FindFirstChild("ExecSword")
					if v55 then
						v_u_13:PlaySound(v_u_9.Hiromi.M1Swing["Swing" .. p52], v54, game.SoundService.Effect)
						if p52 == 3 then
							local v57 = v_u_8.Hiromi.CombatTrail2:Clone()
							v57.Color = Color3.fromRGB(179, 130, 61)
							v57.Trail.Color = ColorSequence.new(Color3.fromRGB(179, 130, 61))
							v57.Weld.Part0 = v55
							v57.Parent = workspace.Effects
							task.wait(0.35)
							v57.Trail.Enabled = false
							v_u_4:Create(v57, TweenInfo.new(0.1), {
								["Transparency"] = 1
							}):Play()
							v_u_3:AddItem(v57, 0.2)
						else
							local v58 = v_u_8.Hiromi.CombatTrail:Clone()
							v58.Color = Color3.fromRGB(179, 130, 61)
							v58.Trail.Color = ColorSequence.new(Color3.fromRGB(179, 130, 61))
							v58.Weld.Part0 = v55
							v58.Parent = workspace.Effects
							task.wait(p52 == 2 and 0.6 or 0.35)
							v58.Trail.Enabled = false
							v_u_4:Create(v58, TweenInfo.new(0.1), {
								["Transparency"] = 1
							}):Play()
							v_u_3:AddItem(v58, 0.2)
						end
					else
						if v56 then
							if p52 == 4 then
								v_u_13:ArmFlash(p51["Left Arm"], Color3.fromRGB(179, 130, 61), 0.3)
								v_u_13:PlaySound(v_u_9.Misc.Swing.Fist, v54, game.SoundService.Effect)
								return
							end
							v_u_13:PlaySound(v_u_9.Hiromi.M1SwordSwing["Swing" .. p52], v54, game.SoundService.Effect)
						end
						return
					end
				end
			else
				return
			end
		end,
		["Chat"] = function(p_u_59, p60, p_u_61)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v62 = p_u_59:FindFirstChild("HumanoidRootPart")
			if v62 then
				task.spawn(function()
					-- upvalues: (ref) v_u_8, (copy) p_u_59, (ref) v_u_4, (ref) v_u_3
					local v63 = v_u_8.Hiromi.Dialogue:Clone()
					v63.Parent = p_u_59.Torso
					local v64 = v63.Chat1.Position
					v63.Chat1.Position = v64 - UDim2.new(0, 0, 0.15, 0)
					v_u_4:Create(v63.Chat1, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Position"] = v64
					}):Play()
					v_u_4:Create(v63.Chat1, TweenInfo.new(0.3), {
						["BackgroundTransparency"] = 0
					}):Play()
					v_u_4:Create(v63.Chat1.Sub, TweenInfo.new(0.3), {
						["TextTransparency"] = 0
					}):Play()
					task.wait(0.7)
					local v65 = v63.Chat2.Position
					v63.Chat2.Position = v65 - UDim2.new(0, 0, 0.15, 0)
					v_u_4:Create(v63.Chat2, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Position"] = v65
					}):Play()
					v_u_4:Create(v63.Chat2, TweenInfo.new(0.3), {
						["BackgroundTransparency"] = 0
					}):Play()
					v_u_4:Create(v63.Chat2.Sub, TweenInfo.new(0.3), {
						["TextTransparency"] = 0
					}):Play()
					task.wait(1.3)
					v_u_3:AddItem(v63, 0.6)
					for _, v66 in v63:GetDescendants() do
						if v66:IsA("Frame") then
							v_u_4:Create(v66, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
								["Position"] = nil,
								["BackgroundTransparency"] = 1,
								["Position"] = v66.Position - UDim2.new(0, 0, 0.2, 0)
							}):Play()
						else
							if not v66:IsA("TextLabel") then
								continue
							end
							v_u_4:Create(v66, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
								["TextTransparency"] = 1
							}):Play()
						end
					end
				end)
				v_u_13:PlaySound(v_u_9.Hiromi.Awaken, v62, game.SoundService.Effect)
				for _, v67 in p_u_61:GetChildren() do
					if v67.Name ~= "Attachment" then
						continue
					end
					local v68 = v67.Position
					v67.Position = Vector3.new(0, 0, 0)
					v_u_4:Create(v67, TweenInfo.new(0.6, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
						["Position"] = v68
					}):Play()
				end
				p60.Weld.C0 = CFrame.new(0, 0, 0)
				p60.Weld.Part0 = p_u_61
				task.delay(0.5, function()
					-- upvalues: (ref) v_u_8, (copy) p_u_61, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (copy) p_u_59, (ref) v_u_10
					for _ = 1, 10 do
						local v_u_69 = v_u_8.Hiromi.GavelShard:Clone()
						v_u_69.Position = p_u_61.Position
						v_u_69.Size = v_u_69.Size * (math.random(30, 100) / 100)
						local v70 = math.random(-50, 50)
						local v71 = math.random(-50, 50)
						local v72 = math.random
						v_u_69.Velocity = Vector3.new(v70, v71, v72(-50, 50))
						local v73 = math.random(-50, 50)
						local v74 = math.random(-50, 50)
						local v75 = math.random
						v_u_69.RotVelocity = Vector3.new(v73, v74, v75(-50, 50))
						v_u_69.Parent = workspace.Effects
						v_u_3:AddItem(v_u_69, 2)
						task.delay(1, function()
							-- upvalues: (ref) v_u_4, (copy) v_u_69
							v_u_4:Create(v_u_69, TweenInfo.new(1), {
								["Size"] = Vector3.new(0, 0, 0)
							}):Play()
						end)
					end
					if v_u_5.Character == p_u_59 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
					end
				end)
				local v76 = v_u_8.Hiromi.SwordBuild.Charge:Clone()
				v_u_3:AddItem(v76, 1)
				v76.Parent = p_u_61
				task.wait(0.7)
				v76:Destroy()
				for _, v77 in v_u_8.Hiromi.SwordBuild.Create:GetChildren() do
					local v78 = v77:Clone()
					v78.Parent = p_u_61
					v_u_3:AddItem(v78, 1.5)
					v78:Emit(v78:GetAttribute("EmitCount"))
				end
			end
		end,
		["Launch"] = function(p79, p80)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v81 = p79:FindFirstChild("HumanoidRootPart")
			if v81 then
				local v82 = v_u_8.Gojo.LapseBlue.Throw:Clone()
				v82.CFrame = CFrame.new(v81.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v82.Size = Vector3.new(0, 0, 5)
				v82.Parent = workspace.Effects
				v_u_4:Create(v82, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v82.Position + Vector3.new(0, p80, 0)
				}):Play()
				v_u_3:AddItem(v82, 0.3)
				if p80 < 0 then
					v_u_13:PlaySound(v_u_9.Megumi.Mahoraga.Throw.Break, v81, game.SoundService.Effect)
					v_u_13:DustBreak(v81.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v81.Position) < 20 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
					end
				end
			end
		end,
		["Startup"] = function(p_u_83)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_7, (ref) v_u_8, (ref) v_u_4
			local v84 = p_u_83:FindFirstChild("HumanoidRootPart")
			if v84 then
				v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.Voice, v84, game.SoundService.Voice)
				v_u_13:DomainBurst(v84)
				local v85 = v_u_5.Character
				if v85 and v85:FindFirstChild("HumanoidRootPart") then
					local v86 = v85:FindFirstChild("HumanoidRootPart")
					if (v84.Position - v86.Position).Magnitude <= 37.5 then
						v_u_13:Domain(p_u_83, function(p87, p88)
							-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_4, (copy) p_u_83
							p88.Humanoid:LoadAnimation(v_u_7.Hiromi.DomainWarn):Play(0)
							p87.Panel.ImageLabel:Destroy()
							local v89 = v_u_8.Hiromi.DeadlySentencing.JudgemanPanel:Clone()
							v89.Parent = p87.Panel
							p87.Panel.BackgroundColor3 = Color3.new(0, 0, 0)
							v_u_4:Create(v89, TweenInfo.new(1.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {
								["Position"] = nil,
								["ImageTransparency"] = 0,
								["Position"] = UDim2.new(0.41, 0, 0.3, 0)
							}):Play()
							p87.Panel.Camera.CFrame = p88.HumanoidRootPart.CFrame * CFrame.new(2.16096544, -1.70169497, -4.07498741, -0.891988277, 0.183446124, 0.41316402, -1.49011612e-8, 0.913961232, -0.405801684, -0.452058613, -0.361970335, -0.815242589)
							p87.Panel.Viewport.LightColor = Color3.fromRGB(255, 249, 166)
							p87.Panel.Viewport.Ambient = Color3.fromRGB(0, 0, 0)
							p87.Panel.Viewport.LightDirection = Vector3.new(1, -1, -1)
							local v90 = p_u_83.SetAssets:FindFirstChild("Gavel")
							if v90 then
								local v91 = v90:Clone()
								v91.Extensions:Destroy()
								v91.Weld.Part0 = p88["Right Arm"]
								v91.Parent = p88
							end
						end)
					end
				end
			end
		end,
		["Opening"] = function(p92, p_u_93, p_u_94, p_u_95, p96, p_u_97, p98, p_u_99)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10, (ref) v_u_5, (ref) v_u_6, (ref) v_u_18
			local v_u_100 = v_u_8.Hiromi.DeadlySentencing.DomainBG:Clone()
			v_u_100.Parent = p92
			v_u_100.CFrame = p92.CFrame
			v_u_100.Domain:PivotTo(p92.CFrame + Vector3.new(0, 1, 0))
			v_u_100.Judgeman:PivotTo(CFrame.new(1, 10000, 1))
			task.spawn(function()
				-- upvalues: (copy) p_u_94, (copy) v_u_100, (ref) v_u_4
				repeat
					task.wait()
				until not (p_u_94.Parent and (p_u_94.Parent.Parent and p_u_94.Parent.Parent.Parent))
				v_u_100:Destroy()
				v_u_4:Create(game.Lighting, TweenInfo.new(0.2), {
					["ExposureCompensation"] = 0
				}):Play()
			end)
			v_u_4:Create(game.Lighting, TweenInfo.new(0.75), {
				["ExposureCompensation"] = -3
			}):Play()
			for _, v101 in v_u_100.Lights.Spotlight:GetDescendants() do
				if not (v101:IsA("Beam") or v101:IsA("SpotLight")) then
					continue
				end
				v101.Enabled = false
			end
			if not p98 then
				local v_u_102 = p_u_93.DomainGround
				v_u_102.Surround.ShapePartial = 1
				v_u_102.Surround.Enabled = true
				v_u_3:AddItem(v_u_102, 2)
				task.spawn(function()
					-- upvalues: (copy) v_u_100, (copy) p_u_93, (ref) v_u_4, (ref) v_u_3
					local v103 = TweenInfo.new(0.4)
					local v104 = v_u_100.Judgeman:Clone()
					v104:PivotTo(p_u_93.CFrame * CFrame.Angles(0, 3.141592653589793, 0) - p_u_93.CFrame.LookVector * 25 + Vector3.new(0, 10, 0))
					for _, v105 in v104:GetDescendants() do
						if not (v105:IsA("Decal") or v105:IsA("BasePart")) or v105.Transparency ~= 0 then
							continue
						end
						v105.Transparency = 1
						v_u_4:Create(v105, v103, {
							["Transparency"] = 0
						}):Play()
					end
					v104.Parent = p_u_93
					v_u_3:AddItem(v104, 2)
				end)
				task.delay(0.5, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_102, (ref) v_u_13
					v_u_4:Create(v_u_102, TweenInfo.new(0.25), {
						["Transparency"] = 0
					}):Play()
					v_u_13:DomainMapFade(Color3.new(0, 0, 0), 0.25, 1)
				end)
				task.wait(1)
				if not (p_u_94 and p_u_94.Parent) then
					return
				end
				v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.Create, workspace, game.SoundService.Effect)
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
				for _, v106 in v_u_100.Domain:GetDescendants() do
					if not v106:IsA("BasePart") or v106.Transparency ~= 0 then
						continue
					end
					local v107 = v106.CFrame
					local v108 = math.random(100, 200)
					v106.CFrame = (v107 - Vector3.new(0, v108, 0)) * CFrame.Angles(math.random(-3.141592653589793, 3.141592653589793), math.random(-3.141592653589793, 3.141592653589793), math.random(-3.141592653589793, 3.141592653589793))
					v106.Transparency = 0
					v_u_4:Create(v106, TweenInfo.new(math.random(1, 2), Enum.EasingStyle.Exponential), {
						["CFrame"] = nil,
						["Transparency"] = 0,
						["CFrame"] = v107
					}):Play()
				end
				for _, v109 in v_u_100:GetDescendants() do
					if not v109:IsA("Beam") or v109.Parent.Parent ~= v_u_100 then
						continue
					end
					v109.LightEmission = 1
					v_u_4:Create(v109, TweenInfo.new(1), {
						["LightEmission"] = 0
					}):Play()
				end
			end
			for _, v_u_110 in v_u_100.Lights.Spotlight:GetDescendants() do
				if not (v_u_110:IsA("Beam") or v_u_110:IsA("SpotLight")) then
					continue
				end
				task.delay(0.4, function()
					-- upvalues: (copy) v_u_110
					v_u_110.Enabled = true
					task.wait(0.05)
					v_u_110.Enabled = false
					task.wait(0.05)
					v_u_110.Enabled = true
					task.wait(0.05)
					v_u_110.Enabled = false
					task.wait(0.05)
					v_u_110.Enabled = true
					task.wait(0.05)
					v_u_110.Enabled = false
					task.wait(0.3)
					v_u_110.Enabled = true
				end)
			end
			task.spawn(function()
				-- upvalues: (copy) v_u_100, (copy) p_u_97
				local v111 = v_u_100.Judgeman
				v111:PivotTo(v_u_100.CFrame * CFrame.Angles(0, 3.141592653589793, 0) - v_u_100.CFrame.LookVector * 25 + Vector3.new(0, 10, 0))
				local v112 = 0
				local v113 = task.wait()
				v112 = v112 + v113 * 2
				if v111.Parent and (p_u_97 and p_u_97.Parent) then
					local v114 = p_u_97.HumanoidRootPart.Position
					local v115 = CFrame.lookAt
					local v116 = v_u_100.Position
					local v117 = v114.X
					local v118 = v_u_100.Position.Y
					local v119 = v114.Z
					local v120 = v115(v116, (Vector3.new(v117, v118, v119)))
					local v121 = v111:GetPivot()
					local v122 = v120 + v120.LookVector * 40
					local v123 = math.sin(v112) * 1.5 + 10
					v111:PivotTo((v121:Lerp(v122 + Vector3.new(0, v123, 0), 4 * v113)))
				end
				if v_u_100.Parent then
					continue
				end
			end)
			task.delay(p98 and 0 or 2, function()
				-- upvalues: (copy) v_u_100, (copy) p_u_93, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
				if v_u_100.Parent then
					local _ = v_u_100.Domain.Saws.MainBlade.Blade.CFrame
					for _, v124 in pairs(v_u_100.Domain.Saws:GetChildren()) do
						v124:SetAttribute("cf", v124.Blade.CFrame)
					end
					p_u_93:GetAttributeChangedSignal("VisualHealth"):Connect(function()
						-- upvalues: (ref) v_u_100, (ref) p_u_93, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
						if v_u_100.Parent then
							local v125 = p_u_93:GetAttribute("VisualHealth")
							local v126 = v_u_100.Domain.Saws:GetChildren()
							local v127 = TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
							local v128 = false
							for _, v129 in pairs(v126) do
								if v125 >= v129:GetAttribute("DecreaseHP") then
									continue
								end
								v_u_4:Create(v129.Blade, v127, {
									["CFrame"] = v129:GetAttribute("cf") - Vector3.new(0, 45, 0)
								}):Play()
								if v128 then
									continue
								end
								v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.BladeFallRope, workspace, game.SoundService.Effect)
								task.delay(0.3, function()
									-- upvalues: (ref) v_u_10, (ref) v_u_13, (ref) v_u_9
									v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
									v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence["BladeFall" .. math.random(1, 2)], workspace, game.SoundService.Effect)
								end)
								v128 = true
							end
						end
					end)
				end
			end)
			local v_u_130 = v_u_8.Hiromi.DeadlySentencing.Choose:Clone()
			v_u_130.Parent = v_u_5.PlayerGui
			local v_u_131 = TweenInfo.new(0.5)
			v_u_4:Create(v_u_130.Title, v_u_131, {
				["TextTransparency"] = 0.5
			}):Play()
			v_u_4:Create(v_u_130.Crime, v_u_131, {
				["TextTransparency"] = 0.5
			}):Play()
			local v_u_132 = require(v_u_6.Modules.DeadlyData)
			task.delay(p98 and 0 or 1.2, function()
				-- upvalues: (copy) v_u_130, (ref) v_u_4, (copy) v_u_131, (copy) p_u_93, (ref) v_u_5, (copy) p_u_97, (ref) v_u_13, (ref) v_u_9, (copy) p_u_95, (copy) p_u_99, (ref) v_u_18, (copy) v_u_132, (copy) v_u_100
				if v_u_130.Parent then
					v_u_4:Create(v_u_130.Confess, v_u_131, {
						["BackgroundTransparency"] = 0.5,
						["TextTransparency"] = 0
					}):Play()
					v_u_4:Create(v_u_130.Silence, v_u_131, {
						["BackgroundTransparency"] = 0.5,
						["TextTransparency"] = 0
					}):Play()
					v_u_4:Create(v_u_130.Denial, v_u_131, {
						["BackgroundTransparency"] = 0.5,
						["TextTransparency"] = 0
					}):Play()
					v_u_4:Create(v_u_130.Health, v_u_131, {
						["BackgroundTransparency"] = 0.5
					}):Play()
					v_u_4:Create(v_u_130.Health.Bar, v_u_131, {
						["BackgroundTransparency"] = 0
					}):Play()
					v_u_4:Create(v_u_130.Health.Marks.Bar1, v_u_131, {
						["BackgroundTransparency"] = 0.5
					}):Play()
					v_u_4:Create(v_u_130.Health.Marks.Bar2, v_u_131, {
						["BackgroundTransparency"] = 0.5
					}):Play()
					p_u_93:GetAttributeChangedSignal("UI"):Connect(function()
						-- upvalues: (ref) v_u_5, (ref) p_u_97, (ref) p_u_93, (ref) v_u_130, (ref) v_u_13, (ref) v_u_9
						if v_u_5.Character == p_u_97 then
							return
						end
						if p_u_93:GetAttribute("UI") ~= true == false then
							v_u_130.Timer.Visible = true
							for v133 = 3, 1, -1 do
								if v_u_130.Timer.Visible == false then
									break
								end
								v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.Tick, workspace, game.SoundService.Effect)
								v_u_130.Timer.Text = v133
								task.wait(1)
							end
						end
					end)
					p_u_93:GetAttributeChangedSignal("UI2"):Connect(function()
						-- upvalues: (ref) v_u_5, (ref) p_u_97, (ref) p_u_93, (ref) v_u_130, (ref) v_u_13, (ref) v_u_9
						if v_u_5.Character ~= p_u_97 then
							return
						end
						local v134 = p_u_93:GetAttribute("UI2")
						if v134 == nil then
							v_u_130.Confess.Visible = true
							v_u_130.Silence.Visible = true
							v_u_130.Denial.Visible = true
							v_u_130.Timer.Visible = false
							v_u_130.Confess.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							v_u_130.Silence.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							v_u_130.Denial.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							return
						end
						if v134 == true then
							v_u_130.Confess.Visible = false
							v_u_130.Silence.Visible = false
							v_u_130.Denial.Visible = false
							return
						end
						if v134 == false then
							v_u_130.Timer.Visible = true
							for v135 = 3, 1, -1 do
								if v_u_130.Timer.Visible == false then
									break
								end
								v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.Tick, workspace, game.SoundService.Effect)
								v_u_130.Timer.Text = v135
								task.wait(1)
							end
							v_u_130.Timer.Visible = false
						end
					end)
					local v_u_136 = v_u_130.Denial
					local v_u_137 = "DenialCount"
					local v_u_138 = "DENIAL"
					p_u_93:GetAttributeChangedSignal("DenialCount"):Connect(function()
						-- upvalues: (ref) p_u_93, (copy) v_u_137, (ref) v_u_5, (ref) p_u_97, (copy) v_u_136, (copy) v_u_138
						local v139 = p_u_93:GetAttribute(v_u_137) or 0
						if v139 > 0 and v_u_5.Character ~= p_u_97 then
							v_u_136.Text = v_u_138 .. " (" .. v139 .. ")"
						else
							v_u_136.Text = v_u_138
							v_u_136.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
						end
					end)
					local v_u_140 = v_u_130.Silence
					local v_u_141 = "SilenceCount"
					local v_u_142 = "SILENCE"
					p_u_93:GetAttributeChangedSignal("SilenceCount"):Connect(function()
						-- upvalues: (ref) p_u_93, (copy) v_u_141, (ref) v_u_5, (ref) p_u_97, (copy) v_u_140, (copy) v_u_142
						local v143 = p_u_93:GetAttribute(v_u_141) or 0
						if v143 > 0 and v_u_5.Character ~= p_u_97 then
							v_u_140.Text = v_u_142 .. " (" .. v143 .. ")"
						else
							v_u_140.Text = v_u_142
							v_u_140.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
						end
					end)
					local v_u_144 = v_u_130.Confess
					local v_u_145 = "ConfessCount"
					local v_u_146 = "CONFESS"
					p_u_93:GetAttributeChangedSignal("ConfessCount"):Connect(function()
						-- upvalues: (ref) p_u_93, (copy) v_u_145, (ref) v_u_5, (ref) p_u_97, (copy) v_u_144, (copy) v_u_146
						local v147 = p_u_93:GetAttribute(v_u_145) or 0
						if v147 > 0 and v_u_5.Character ~= p_u_97 then
							v_u_144.Text = v_u_146 .. " (" .. v147 .. ")"
						else
							v_u_144.Text = v_u_146
							v_u_144.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
						end
					end)
					local function v150(p_u_148, p_u_149) -- name: bindClick
						-- upvalues: (ref) v_u_5, (ref) p_u_97, (ref) v_u_130, (ref) v_u_13, (ref) v_u_9, (ref) p_u_95
						if v_u_5.Character == p_u_97 then
							p_u_148.AutoButtonColor = false
							p_u_148.MouseEnter:Connect(function()
								-- upvalues: (copy) p_u_148
								p_u_148.BackgroundColor3 = Color3.fromRGB(160, 160, 160)
							end)
							p_u_148.MouseLeave:Connect(function()
								-- upvalues: (copy) p_u_148
								p_u_148.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							end)
						end
						p_u_148.MouseButton1Down:Connect(function()
							-- upvalues: (ref) v_u_5, (ref) p_u_97, (ref) v_u_130, (copy) p_u_148, (ref) v_u_13, (ref) v_u_9, (ref) p_u_95, (copy) p_u_149
							if v_u_5.Character == p_u_97 then
								v_u_130.Confess.Visible = false
								v_u_130.Silence.Visible = false
								v_u_130.Denial.Visible = false
							end
							v_u_130.Confess.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							v_u_130.Silence.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							v_u_130.Denial.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							p_u_148.BackgroundColor3 = Color3.fromRGB(160, 160, 160)
							v_u_13:PlaySound(v_u_9.Misc.UI.Click, workspace, game.SoundService.Effect)
							p_u_95:FireServer(p_u_149)
						end)
					end
					v150(v_u_130.Denial, 1)
					v150(v_u_130.Silence, 2)
					v150(v_u_130.Confess, 3)
					local v_u_151 = 0
					local function v_u_153(p152) -- name: healthChanged
						-- upvalues: (ref) v_u_151, (ref) p_u_99, (ref) v_u_4, (ref) v_u_130, (ref) v_u_13, (ref) v_u_9
						v_u_151 = p_u_99
						v_u_4:Create(v_u_130.Health.Bar, TweenInfo.new(p152 >= 3 and 0.65 or 0.8, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
							["Size"] = UDim2.new(p152 / 3, 0, 1, 0)
						}):Play()
						v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.Fill, workspace, game.SoundService.Effect)
					end
					if p_u_99 ~= 0 then
						v_u_153(p_u_99)
					end
					p_u_95.OnClientEvent:Connect(function(p154, p155, p156, p157, p158, p159)
						-- upvalues: (ref) v_u_130, (ref) v_u_18, (ref) v_u_132, (ref) p_u_93, (ref) p_u_97, (ref) v_u_100, (ref) v_u_13, (ref) v_u_9, (ref) v_u_151, (copy) v_u_153
						if p154 and (p155 and p156) then
							v_u_130.Timer.Visible = false
							if p159 and p159.Parent then
								v_u_18(p159, v_u_132.Dialog[p154][1][p155])
							end
							task.wait(0.75)
							if p_u_93 and (p_u_93.Parent and (p_u_97 and p_u_97.Parent)) then
								v_u_18(p154 == 3 and (p155 == 3 and p156 == p155) and v_u_100.Judgeman or p_u_97, p155 == p156 and v_u_132.Dialog[p154][2][p155] or v_u_132.DialogFail[p157])
								if p155 ~= p156 then
									if p157 == 4 then
										v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.Sure, p_u_97.Head, game.SoundService.Voice)
									else
										v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.TalkFail, p_u_97.Head, game.SoundService.Voice)
									end
								end
							end
							if v_u_151 ~= p158 then
								v_u_153(p158)
							end
							if p158 then
								if p158 < 3 then
									task.wait(0.75)
									v_u_130.Confess.Visible = true
									v_u_130.Silence.Visible = true
									v_u_130.Denial.Visible = true
									return
								end
								v_u_100.Judgeman.Face.Face.Transparency = 1
								v_u_100.Judgeman.Face.Face2.Transparency = 0
							end
						end
					end)
				end
			end)
			v_u_130.Crime.Text = v_u_132.Crimes[p96]
			local v_u_160 = v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.Music, workspace, game.SoundService.Music, true)
			local v_u_161 = v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.Travel, workspace, game.SoundService.Effect, true)
			v_u_4:Create(v_u_161, TweenInfo.new(2), {
				["Volume"] = 0.7
			}):Play()
			game.SoundService.AmbientReverb = Enum.ReverbType.Auditorium
			task.spawn(function()
				-- upvalues: (copy) p_u_94, (ref) v_u_4, (copy) v_u_160, (ref) v_u_3, (copy) v_u_161, (copy) v_u_130
				repeat
					task.wait()
				until not (p_u_94.Parent and (p_u_94.Parent.Parent and p_u_94.Parent.Parent.Parent))
				game.SoundService.AmbientReverb = Enum.ReverbType.NoReverb
				v_u_4:Create(v_u_160, TweenInfo.new(2), {
					["Volume"] = 0
				}):Play()
				v_u_3:AddItem(v_u_160, 2)
				if v_u_161 then
					v_u_161:Destroy()
				end
				if v_u_130 then
					v_u_130:Destroy()
				end
			end)
		end,
		["Shatter"] = function(p162)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_4
			local v163 = v_u_8.Domain:Clone()
			v163.Transparency = 1
			v163.CanCollide = false
			v163.Position = p162
			v163.Shatter.Color = ColorSequence.new(Color3.new(0, 0, 0))
			v163.Parent = workspace.Effects
			v_u_3:AddItem(v163, 3)
			for _, v164 in v163:GetChildren() do
				if v164.Name == "Shatter" then
					v164:Emit(100)
				else
					v164:Destroy()
				end
			end
			v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.Shatter, v163, game.SoundService.Effect)
			v163.Transparency = 0
			v163.Color = Color3.new(0, 0, 0)
			v_u_4:Create(v163, TweenInfo.new(0.2), {
				["Transparency"] = 1
			}):Play()
			if _G.Settings.DesPHY then
				task.wait(0.04)
				if (workspace.CurrentCamera.CFrame.Position - v163.Position).Magnitude > 150 then
					return
				end
				local v165 = Random.new()
				local v166 = TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
				for _ = 1, 80 do
					local v167 = v_u_8.Gojo.Shard:Clone()
					local v168 = v165:NextUnitVector().Unit
					local v169 = math.random(1, 8)
					local v170 = math.random
					v167.Size = Vector3.new(0.1, v169, v170(1, 8))
					v167.CFrame = CFrame.lookAlong(p162, v168) * CFrame.Angles(1.5707963267948966, 0, 0) + v168 * 37.5
					v167.CFrame = v167.CFrame * CFrame.Angles(0, math.random(0, 3.141592653589793), 0)
					v167.Color = Color3.new(0, 0, 0)
					v167.CanCollide = true
					v167.CollisionGroup = "Effects"
					v167.Parent = workspace.Effects
					local v171 = math.random(-50, 50)
					local v172 = math.random(-50, 50)
					local v173 = math.random
					v167.RotVelocity = Vector3.new(v171, v172, v173(-50, 50))
					v167.Transparency = 0
					v167.Material = Enum.Material.Neon
					v_u_4:Create(v167, v166, {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_3:AddItem(v167, 4)
				end
			end
		end,
		["LightShatter"] = function(p174)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5
			local v175 = v_u_8.Hiromi.DeadlySentencing.LightShatter:Clone()
			v175.Position = p174
			v175.Parent = workspace.Effects
			v_u_3:AddItem(v175, 3)
			v175.Shatter.Color = ColorSequence.new(Color3.new(0, 0, 0))
			v175.Surround.Color = ColorSequence.new(Color3.new(0, 0, 0))
			v175.Shatter:Emit(50)
			v175.Surround:Emit(150)
			v_u_4:Create(v175, TweenInfo.new(0.2), {
				["Transparency"] = 1
			}):Play()
			v_u_13:PlaySound(v_u_9.Gojo.Teleport, v175, game.SoundService.Effect)
			if v_u_5.Character and (v_u_5.Character.HumanoidRootPart.Position - p174).Magnitude < 35 then
				v_u_13:DomainMapFade(Color3.new(0, 0, 0), 0, 0.15)
				v175.DomainGround.Position = p174 - Vector3.new(0, 3, 0)
				v175.Surround:Emit(100)
			end
			if _G.Settings.DesPHY then
				if (workspace.CurrentCamera.CFrame.Position - v175.Position).Magnitude > 150 then
					return
				end
				local v176 = Random.new()
				local v177 = TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
				for _ = 1, 80 do
					local v178 = v_u_8.Gojo.Shard:Clone()
					local v179 = v176:NextUnitVector().Unit
					local v180 = math.random(1, 8) / 2
					local v181 = math.random(1, 8) / 2
					v178.Size = Vector3.new(0.1, v180, v181)
					v178.CFrame = CFrame.lookAlong(p174, v179) * CFrame.Angles(1.5707963267948966, 0, 0) + v179 * 37.5
					v178.CFrame = v178.CFrame * CFrame.Angles(0, math.random(0, 3.141592653589793), 0)
					v178.Color = Color3.new(0, 0, 0)
					v178.CanCollide = true
					v178.CollisionGroup = "Effects"
					v178.Parent = workspace.Effects
					local v182 = math.random(-50, 50)
					local v183 = math.random(-50, 50)
					local v184 = math.random
					v178.RotVelocity = Vector3.new(v182, v183, v184(-50, 50))
					v178.Transparency = 0
					v178.Material = Enum.Material.Neon
					v_u_4:Create(v178, v177, {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_3:AddItem(v178, 4)
				end
			end
		end,
		["Confiscate"] = function(p185, p186, p_u_187)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3
			if p185:FindFirstChild("HumanoidRootPart") then
				local v188 = p185.Head:FindFirstChild("Confiscate")
				if p_u_187 or not v188 then
					local v_u_189 = v_u_8.Hiromi.Confiscate:Clone()
					v_u_189.Parent = p185.Head
					if p_u_187 then
						v_u_189.TextLabel.TextColor3 = p_u_187
					end
					task.delay(p_u_187 and 0.5 or 3, function()
						-- upvalues: (ref) v_u_4, (ref) v_u_189, (copy) p_u_187
						v_u_4:Create(v_u_189.TextLabel, TweenInfo.new(p_u_187 and 0.5 or 1), {
							["TextTransparency"] = 1
						}):Play()
					end)
					v_u_3:AddItem(v_u_189, p_u_187 and 1 or 4)
					local v190 = v_u_189.TextLabel
					v190.Size = v190.Size + UDim2.new(0, 0, 1, 0)
					v_u_189.TextLabel.Text = "- [" .. p186 .. "]"
				else
					local v191 = v188.TextLabel
					v191.Size = v191.Size + UDim2.new(0, 0, 1, 0)
					v188.TextLabel.Text = v188.TextLabel.Text .. "\n- [" .. p186 .. "]"
				end
			end
		end,
		["AmpliStart"] = function(p192)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v193 = p192:FindFirstChild("HumanoidRootPart")
			if v193 then
				v_u_13:Flash(p192, Color3.new(0.666667, 1, 1), 1)
				v_u_13:PlaySound(v_u_9.Hiromi.Amplification.Start, v193, game.SoundService.Effect)
				if v_u_5.Character == p192 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
				end
			end
		end,
		["AmpliAbsorb"] = function(p194)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v195 = p194:FindFirstChild("HumanoidRootPart")
			if v195 then
				local v196 = v_u_8.Hiromi.AmpliAbsorb:Clone()
				v196.CFrame = v195.CFrame
				v196.Parent = workspace.Effects
				v_u_3:AddItem(v196, 1)
				v196.Aura:Emit(50)
				v196.Hit:Emit(50)
				v196.Wind2:Emit(10)
				local v197 = v_u_8.Gojo.LapseBlue.LapseBlue.Grab:Clone()
				v197.Size = Vector3.new(20, 20, 20)
				v197.Anchored = true
				v197.CFrame = v195.CFrame
				v197.Parent = workspace.Effects
				local v198 = Instance.new("Highlight", v197)
				v198.FillTransparency = 1
				v198.OutlineTransparency = 1
				v197.Transparency = 50
				v_u_4:Create(v197, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Transparency"] = 1,
					["Size"] = Vector3.new(13, 13, 13)
				}):Play()
				v_u_3:AddItem(v197, 1)
				v_u_13:Flash(p194, Color3.new(0.666667, 1, 1), 1)
				v_u_13:PlaySound(v_u_9.Hiromi.Amplification.Absorb, v195, game.SoundService.Effect)
				if v_u_5.Character == p194 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
				end
			end
		end,
		["Interp"] = function(p_u_199)
			-- upvalues: (ref) v_u_2
			local v_u_200 = p_u_199.CFrame
			local v_u_201 = tick()
			local v_u_202 = p_u_199:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_200, (copy) p_u_199, (ref) v_u_201
				v_u_200 = p_u_199.CFrame
				v_u_201 = tick()
			end)
			local v_u_203 = nil
			v_u_203 = v_u_2.Stepped:Connect(function(_, _)
				-- upvalues: (copy) p_u_199, (ref) v_u_203, (copy) v_u_202, (ref) v_u_200, (ref) v_u_201
				if p_u_199.Parent and not p_u_199:GetAttribute("Rebound") then
					workspace:BulkMoveTo({ p_u_199 }, { v_u_200 + v_u_200.LookVector * (120 * (tick() - v_u_201)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_203:Disconnect()
					v_u_202:Disconnect()
				end
			end)
		end,
		["Recall"] = function(p204, p205, p206, p207)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v208 = p204:FindFirstChild("HumanoidRootPart")
			if v208 then
				local v209 = tick()
				v_u_13:PlaySound(v_u_9.Yuki.Rebound.Bounce, v208, game.SoundService.Effect)
				p205:SetAttribute("Rebound", true)
				local v210 = 15 * (p207 / 0.5)
				local v211 = task.wait()
				local v212 = (tick() - v209) / p207
				local v213 = p206:Lerp(v208.Position, v212)
				local v214 = v212 * 3.14
				local v215 = math.sin(v214) * v210
				local v216 = v213 + Vector3.new(0, v215, 0)
				p205.CFrame = CFrame.lookAlong(v216, p206 - v208.Position)
				if p205:FindFirstChild("Gavel") then
					local v217 = p205.Gavel.Weld
					local v218 = v217.C1
					local v219 = CFrame.Angles
					local v220 = -600 * v211
					v217.C1 = v218 * v219(math.rad(v220), 0, 0)
				end
				if v208.Parent and p207 >= tick() - v209 then
					continue
				end
				if p205 then
					p205:Destroy()
				end
			end
		end,
		["HammerHit"] = function(p221, p222)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v223 = p222:FindFirstChild("HumanoidRootPart")
			if v223 then
				local v224 = v_u_8.Hiromi.Whack:Clone()
				v224.CFrame = v223.CFrame
				v224.Parent = workspace.Effects
				v_u_3:AddItem(v224, 1.5)
				for _, v225 in v224:GetDescendants() do
					if not v225:IsA("ParticleEmitter") then
						continue
					end
					v225:Emit(v225:GetAttribute("EmitCount"))
				end
				v_u_13:Flash(p222, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Hiromi.Verdict.Hit1, v223, game.SoundService.Effect)
				if v_u_5 == p221 or v_u_5.Character == p222 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
				end
			end
		end,
		["Dash"] = function(p226, _)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3, (ref) v_u_4
			local v_u_227 = p226:FindFirstChild("HumanoidRootPart")
			if v_u_227 then
				v_u_13:PlaySound(v_u_9.Itadori.Rush.Rush, v_u_227, game.SoundService.Effect)
				local v228 = v_u_8.Choso.CounterSwing.Shock:Clone()
				v228.Size = Vector3.new(6, 30, 6)
				v228.CFrame = v_u_227.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v228.Parent = workspace.Effects
				v_u_3:AddItem(v228, 0.2)
				v_u_4:Create(v228, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(25, 0, 25),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v228.Position + v_u_227.CFrame.LookVector * 10
				}):Play()
				for v229 = 1, 4 do
					task.delay(v229 * 0.04, function()
						-- upvalues: (ref) v_u_8, (copy) v_u_227, (ref) v_u_4, (ref) v_u_3
						local v230 = v_u_8.Itadori.Shock:Clone()
						v230.CFrame = CFrame.lookAlong(v_u_227.Position, v_u_227.Velocity) * CFrame.Angles(1.5707963267948966, 0, 0)
						v230.Transparency = 0.3
						v230.Parent = workspace.Effects
						v_u_4:Create(v230, TweenInfo.new(0.15), {
							["Size"] = Vector3.new(20, 0, 20),
							["Transparency"] = 1
						}):Play()
						v_u_3:AddItem(v230, 0.15)
					end)
				end
			end
		end,
		["HammerSwap"] = function(p231, p232)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_6, (ref) v_u_3
			local v233 = p231:FindFirstChild("HumanoidRootPart")
			if v233 then
				v_u_13:PlaySound(v_u_9.Hiromi.Recall, v233, game.SoundService.Effect)
				local v234 = v_u_6.Utils.Hiromi.HammerSwap:Clone()
				v234.Parent = v233
				v234.WorldPosition = p232:IsA("Attachment") and p232.WorldPosition or p232.Position
				v234.Sparks:Emit(10)
				v234.Star:Emit(1)
				v_u_3:AddItem(v234, 0.1)
			end
		end,
		["HammerIFrame"] = function(p235, p236)
			-- upvalues: (ref) v_u_13
			if p235:FindFirstChild("HumanoidRootPart") then
				local v_u_237 = v_u_13:Flash(p235, Color3.fromRGB(255, 170, 0), 1)
				p236.AncestryChanged:Once(function()
					-- upvalues: (copy) v_u_237
					v_u_237:Destroy()
				end)
			end
		end,
		["Bang"] = function(p238)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v239 = p238:FindFirstChild("HumanoidRootPart")
			if v239 then
				v_u_13:PlaySound(v_u_9.Hiromi.Bang, v239, game.SoundService.Effect)
			end
		end
	}
	v_u_11.Effects:Connect(function(p241, ...)
		-- upvalues: (copy) v_u_240
		local v242 = v_u_240[p241]
		if v242 then
			v242(...)
		end
	end)
end
function v14.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13
	v_u_11 = v_u_1.GetService("HiromiService")
	v_u_12 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("FXController")
end
return v14