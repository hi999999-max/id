-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Haruta.Base.TripController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
game:GetService("TweenService")
local v_u_2 = game.Players.LocalPlayer
local v3 = game.ReplicatedStorage
local _ = v3.Animations
local _ = v3.Utils
local v_u_4 = v3.Sounds
local v_u_5 = require(v3.Modules.CameraShaker)
require(v3.Modules.BloodyZee)
local v6 = RaycastParams.new()
v6.FilterType = Enum.RaycastFilterType.Include
v6.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v10 = v_u_1.CreateController({
	["Name"] = "TripController"
})
function v10.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_8, (copy) v_u_4, (copy) v_u_2, (copy) v_u_5, (ref) v_u_7
	local v_u_18 = {
		["Start"] = function(p11)
			-- upvalues: (ref) v_u_8, (ref) v_u_4
			local v12 = p11:FindFirstChild("HumanoidRootPart")
			if v12 then
				v_u_8:PlaySound(v_u_4.Naoya.Cursory.Kick, v12, game.SoundService.Effect).TimePosition = 0.3
				v_u_8:ArmFlash(p11["Right Leg"], Color3.fromRGB(167, 125, 203), 0.4)
			end
		end,
		["Hit"] = function(p13, p14, p15)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_2, (ref) v_u_5
			local v16 = p13:FindFirstChild("HumanoidRootPart")
			if v16 then
				local v17 = p14:FindFirstChild("HumanoidRootPart")
				if v17 then
					v_u_8:Flash(p14, Color3.new(1, 1, 1))
					v_u_8:PlaySound(v_u_4.Haruta.Trip, v16, game.SoundService.Effect)
					v_u_8:PlaySound(v_u_4.Haruta.Trip2, v16, game.SoundService.Effect)
					if p15 then
						v_u_8:PlaySound(v_u_4.Haruta.Trip3, v17, game.SoundService.Effect)
					end
					if p14:GetAttribute("Ragdoll") > 0 then
						v_u_8:PlaySound(v_u_4.Nanami.CleavingWhirlwind.Hit, v16, game.SoundService.Effect)
					end
					if p13 == v_u_2.Character or p14 == v_u_2.Character then
						v_u_5.CurrentShaker:Shake(v_u_5.Presets.MediumHit)
					end
				end
			else
				return
			end
		end
	}
	v_u_7.Effects:Connect(function(p19, ...)
		-- upvalues: (copy) v_u_18
		local v20 = v_u_18[p19]
		if v20 then
			v20(...)
		end
	end)
end
function v10.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (ref) v_u_9, (ref) v_u_8
	v_u_7 = v_u_1.GetService("TripService")
	v_u_9 = v_u_1.GetController("HitboxController")
	v_u_8 = v_u_1.GetController("FXController")
end
return v10