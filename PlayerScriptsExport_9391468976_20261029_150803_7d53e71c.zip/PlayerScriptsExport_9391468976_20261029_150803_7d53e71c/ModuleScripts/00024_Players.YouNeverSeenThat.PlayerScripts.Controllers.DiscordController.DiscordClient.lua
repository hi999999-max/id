-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.DiscordController.DiscordClient
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v1 = game:GetService("ReplicatedStorage"):WaitForChild("Modules"):WaitForChild("Discord")
local v_u_2 = require(v1:WaitForChild("RemoteEvents"))
local v_u_3 = require(v1:WaitForChild("Logger"))
local v_u_4 = require(v1:WaitForChild("Utils"))
local v_u_5 = nil
local v_u_6 = false
local v_u_7 = false
return {
	["isReady"] = function() -- name: isReady
		-- upvalues: (ref) v_u_6
		return v_u_6
	end,
	["setActivity"] = function(p8, ...) -- name: setActivity
		-- upvalues: (copy) v_u_4, (ref) v_u_7, (ref) v_u_5, (copy) v_u_2, (copy) v_u_3
		if type(p8) ~= "table" then
			local v9, v10, v11, v12, v13 = ...
			p8 = {
				["details"] = p8,
				["state"] = v9,
				["assets"] = v10,
				["type"] = v11,
				["party"] = v12,
				["secret"] = v13
			}
		end
		local v14 = v_u_4.createGameActivity(p8)
		if not v_u_7 then
			v_u_5.updateActivity = v_u_2.tryGet("UpdateActivity", 2)
			v_u_7 = true
		end
		if v_u_5.updateActivity then
			v_u_5.updateActivity:FireServer(v14)
			return true
		else
			v_u_3.error("NETWORK", "SocialSDKClient: updateActivity remote event not available")
			return false
		end
	end
}