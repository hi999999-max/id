-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Hiromi.Awake.VerdictController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "VerdictController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (copy) v_u_9, (copy) v_u_6, (copy) v_u_2, (copy) v_u_8, (ref) v_u_10
	local v_u_47 = {
		["Swing"] = function(p14)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_12:PlaySound(v_u_7.Hiromi.Verdict.Start, v15, game.SoundService.Effect)
			end
		end,
		["Jump"] = function(p16, p17, p18)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			local v19 = p17.Parent.Parent:FindFirstChild("HumanoidRootPart")
			if v19 then
				if p18 == true then
					v_u_12:PlaySound(v_u_7.Hiromi.Verdict.RunSmack, v19, game.SoundService.Effect)
				else
					v_u_12:PlaySound(v_u_7.Hiromi.Verdict.RunSlash, v19, game.SoundService.Effect)
				end
				local v20 = v19.CFrame.LookVector * 6 - Vector3.new(0, 2, 0)
				if v_u_4.Character == v19.Parent then
					v_u_3:Create(p17, TweenInfo.new(0.5), {
						["P"] = 100000
					}):Play()
					repeat
						p17.Position = p16.Position - v20
						task.wait()
					until not (p17.Parent and p16)
				else
					repeat
						local v21 = v19.CFrame - v19.Position + p16.Position - v20
						v19.CFrame = v19.CFrame:Lerp(v21, 0.15)
						task.wait()
					until not (p17.Parent and p16)
				end
				v_u_3:Create(p17, TweenInfo.new(0.5), {
					["P"] = 100000
				}):Play()
				repeat
					p17.Position = p16.Position - v20
					task.wait()
				until not (p17.Parent and p16)
			end
		end,
		["Arm"] = function(p22, p_u_23)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_9, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v24 = p22:FindFirstChild("HumanoidRootPart")
			if v24 then
				if p_u_23:FindFirstChild("HumanoidRootPart") then
					v_u_12:PlaySound(v_u_7.Hiromi.Execution.Sever, v24, game.SoundService.Effect)
					for _ = 1, 30 do
						v_u_9:Blood(p_u_23["Left Arm"].CFrame, math.random(5, 150), 25, 25)
					end
					local v_u_25 = p22.SetAssets:FindFirstChild("ExecSword")
					if v_u_25 then
						task.spawn(function()
							-- upvalues: (ref) v_u_6, (copy) p_u_23, (ref) v_u_2, (copy) v_u_25
							local v26 = v_u_6.Hiromi.Limb:Clone()
							local v27 = p_u_23["Left Arm"]
							v26["Left Arm"].Size = v27.Size
							v26["Left Arm"].Color = v27.Color
							if p_u_23:FindFirstChildWhichIsA("Shirt") then
								p_u_23:FindFirstChildWhichIsA("Shirt"):Clone().Parent = v26
							end
							v_u_2:AddItem(v26, 6)
							v26.Parent = workspace.Effects
							repeat
								v26:PivotTo(v_u_25.CFrame * CFrame.new(0, 0, 5))
								task.wait()
							until not (v26.Parent and v_u_25.Parent)
						end)
					end
					if v_u_4.Character == p22 or v_u_4.Character == p_u_23 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["Leg"] = function(p28, p_u_29)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_9, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v30 = p28:FindFirstChild("HumanoidRootPart")
			if v30 then
				if p_u_29:FindFirstChild("HumanoidRootPart") then
					v_u_12:PlaySound(v_u_7.Hiromi.Execution.Sever2, v30, game.SoundService.Effect)
					for _ = 1, 30 do
						v_u_9:Blood(p_u_29["Right Leg"].CFrame, math.random(5, 150), 25, 25)
					end
					local v_u_31 = p28.SetAssets:FindFirstChild("ExecSword")
					if v_u_31 then
						task.spawn(function()
							-- upvalues: (ref) v_u_6, (copy) p_u_29, (ref) v_u_2, (copy) v_u_31
							local v32 = v_u_6.Hiromi.Limb:Clone()
							v32["Left Arm"].Transparency = 1
							v32["Right Leg"].Transparency = 0
							local v33 = p_u_29["Right Leg"]
							v32["Right Leg"].Size = v33.Size
							v32["Right Leg"].Color = v33.Color
							if p_u_29:FindFirstChildWhichIsA("Pants") then
								p_u_29:FindFirstChildWhichIsA("Pants"):Clone().Parent = v32
							end
							v_u_2:AddItem(v32, 6)
							v32.Parent = workspace.Effects
							repeat
								v32:PivotTo(v_u_31.CFrame * CFrame.new(0, 0, 5))
								task.wait()
							until not (v32.Parent and v_u_31.Parent)
						end)
					end
					if v_u_4.Character == p28 or v_u_4.Character == p_u_29 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["HitSlash"] = function(p34, p35)
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v36 = p35:FindFirstChild("HumanoidRootPart")
			if v36 then
				for _ = 1, 30 do
					v_u_9:Blood(p35.Torso.CFrame, math.random(5, 150), 25, 25)
				end
				if _G.Settings.Gore then
					local v37 = v_u_6.Heian.BloodSpread:Clone()
					v37.Parent = p35.Torso
					v37:Emit(20)
					v_u_2:AddItem(v37, 2)
				end
				v_u_12:PlaySound(v_u_7.Hiromi.Execution.Sever, v36, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_7.Hiromi.Execution.Flash, v36, game.SoundService.Effect)
				if v_u_4 == p34 or v_u_4.Character == p35 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["HitBreak"] = function(p38, p39)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v40 = p39:FindFirstChild("HumanoidRootPart")
			if v40 then
				local v41 = v_u_6.Hiromi.Whack:Clone()
				v41.CFrame = v40.CFrame
				v41.Parent = workspace.Effects
				v_u_2:AddItem(v41, 1.5)
				for _, v_u_42 in v41:GetDescendants() do
					if not v_u_42:IsA("ParticleEmitter") then
						continue
					end
					v_u_42:Emit(v_u_42:GetAttribute("EmitCount"))
					task.delay(0.02, function()
						-- upvalues: (copy) v_u_42
						v_u_42.TimeScale = 0
						task.wait(0.3)
						v_u_42.TimeScale = 1
					end)
				end
				v_u_12:Flash(p39, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_7.Hiromi.Verdict.Hit1, v40, game.SoundService.Effect)
				if v_u_4 == p38 or v_u_4.Character == p39 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
				task.wait(0.3)
				v_u_12:Flash(p39, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_7.Hiromi.Verdict.Hit2, v40, game.SoundService.Effect)
				if v_u_4 == p38 or v_u_4.Character == p39 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["Hit"] = function(p43, p44)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v45 = p44:FindFirstChild("HumanoidRootPart")
			if v45 then
				local v46 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v46.Position = v45.Position
				v46.Parent = workspace.Effects
				v_u_2:AddItem(v46, 1)
				v46.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 0.498039))
				v46.Wind.Color = v46.Sparks.Color
				v46.Wind2.Color = v46.Sparks.Color
				v46.Sparks:Emit(30)
				v46.Wind2:Emit(7)
				v_u_12:Flash(p44, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_7.Hakari.EnergySurge.Hit1, v45, game.SoundService.Effect)
				if v_u_4 == p43 or v_u_4.Character == p44 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p48, ...)
		-- upvalues: (copy) v_u_47
		local v49 = v_u_47[p48]
		if v49 then
			v49(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("VerdictService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13