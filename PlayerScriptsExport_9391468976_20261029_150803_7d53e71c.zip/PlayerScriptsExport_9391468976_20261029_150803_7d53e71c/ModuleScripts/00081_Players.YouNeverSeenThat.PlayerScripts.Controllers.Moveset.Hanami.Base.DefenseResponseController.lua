-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Hanami.Base.DefenseResponseController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v4 = game.ReplicatedStorage
local v_u_5 = v4.Animations
local v_u_6 = v4.Utils
local v_u_7 = v4.Sounds
require(v4.Modules.CameraShaker)
require(v4.Modules.BloodyZee)
local v_u_8 = nil
local v_u_9 = nil
local v10 = v_u_1.CreateController({
	["Name"] = "DefenseResponseController"
})
function v10.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_9, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_5, (ref) v_u_8
	local v_u_80 = {
		["Weave"] = function(p11, p12)
			-- upvalues: (ref) v_u_9, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v13 = p11:FindFirstChild("HumanoidRootPart")
			if v13 then
				v_u_9:ArmFlash(p11["Right Arm"], Color3.fromRGB(172, 203, 163), 1)
				v_u_9:PlaySound(v_u_7.Hanami.DefenseResponse[("%*Startup"):format(p12 and "Air" or "")], v13, game.SoundService.Effect)
				local v14 = v_u_6.Naoya.Fall:Clone()
				v14:PivotTo(v13.CFrame)
				v14.Parent = workspace.Effects
				v_u_2:AddItem(v14, 1.5)
				v14.Mesh.Start.Transparency = 0.15
				v14.Mesh2.Start.Transparency = 0.3
				v14.Mesh3.Start.Transparency = 0.3
				v_u_3:Create(v14.Mesh.Start, TweenInfo.new(0.7, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = nil,
					["Size"] = v14.Mesh.End.Size,
					["CFrame"] = v14.Mesh.End.CFrame
				}):Play()
				v_u_3:Create(v14.Mesh2.Start, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = nil,
					["Size"] = v14.Mesh2.End.Size,
					["CFrame"] = v14.Mesh2.End.CFrame
				}):Play()
				v_u_3:Create(v14.Mesh3.Start, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = nil,
					["Size"] = v14.Mesh3.End.Size,
					["CFrame"] = v14.Mesh3.End.CFrame
				}):Play()
				v14.Mesh.End:Destroy()
				v14.Mesh2.End:Destroy()
				v14.Mesh3.End:Destroy()
			end
		end,
		["Hit"] = function(p15, p16)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_9, (ref) v_u_7
			local v17 = p15:FindFirstChild("HumanoidRootPart")
			if v17 then
				local v18 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v18.Position = v17.Position
				v18.Parent = workspace.Effects
				v_u_2:AddItem(v18, 1)
				v18.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 0.498039))
				v18.Wind.Color = v18.Sparks.Color
				v18.Wind2.Color = v18.Sparks.Color
				v18.Sparks:Emit(30)
				v18.Wind2:Emit(7)
				v_u_9:Flash(p15, Color3.new(1, 1, 1))
				v_u_9:PlaySound(v_u_7.Hanami.DefenseResponse[("Hit%*"):format(p16)], v17, game.SoundService.Effect)
			end
		end,
		["Spike"] = function(p19, p_u_20, p_u_21, p22)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_9, (ref) v_u_7, (ref) v_u_2
			local v_u_23 = v_u_6.Hanami[p22 and "TreeMonster" or "360Spike"]:Clone()
			local v24 = 6 * p_u_21
			v_u_23.Position = p19 - Vector3.new(0, v24, 0)
			if p_u_21 then
				local v25 = Instance.new("Model")
				v_u_23.Parent = v25
				v25:ScaleTo(p_u_21)
				v_u_23.Parent = workspace.Effects
				v25:Destroy()
			end
			v_u_23.Parent = workspace.Effects
			p_u_20:GetPropertyChangedSignal("CFrame"):Connect(function()
				-- upvalues: (ref) v_u_3, (copy) v_u_23, (copy) p_u_20, (copy) p_u_21
				v_u_3:Create(v_u_23, TweenInfo.new(0.3), {
					["CFrame"] = p_u_20.CFrame * CFrame.new(0, 4 * p_u_21, 0)
				}):Play()
			end)
			for v26 = 1, 5 do
				local v27 = v_u_6.Hanami.ParticleDissipationHolder:Clone()
				v27.BlackDust.Size = NumberSequence.new(8 - v26 / 2, 12 - v26 / 2)
				v27.RedDust1.Size = v27.BlackDust.Size
				v27.RedDust2.Size = v27.BlackDust.Size
				local v28 = v26 * 2.5 + -6
				v27.Position = Vector3.new(0, v28, 0)
				v27.Parent = v_u_23
			end
			v_u_9:DustBreak(p19 + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
			v_u_9:PlaySound(v_u_7.Hanami.DefenseResponse.Root, v_u_23, game.SoundService.Effect)
			local v29 = v_u_6.Choso.CounterSwing.Shock:Clone()
			v29.Size = Vector3.new(10, 30, 10)
			v29.CFrame = CFrame.new(p19)
			v29.Parent = workspace.Effects
			v_u_2:AddItem(v29, 0.3)
			v_u_3:Create(v29, TweenInfo.new(0.3), {
				["Size"] = Vector3.new(36, 7, 36),
				["Transparency"] = 1,
				["Position"] = nil,
				["Position"] = v29.Position - Vector3.new(0, 3, 0)
			}):Play()
			local v30 = v_u_6.Choso.CounterSwing.Shock:Clone()
			v30.Size = Vector3.new(20, 10, 20)
			v30.CFrame = CFrame.new(p19)
			v30.Parent = workspace.Effects
			v_u_2:AddItem(v30, 0.2)
			v_u_3:Create(v30, TweenInfo.new(0.2), {
				["Size"] = Vector3.new(0, 36, 0),
				["Transparency"] = 1,
				["Position"] = nil,
				["Position"] = v30.Position + Vector3.new(0, 10, 0)
			}):Play()
			local v31 = v_u_3
			local v32 = TweenInfo.new(0.2)
			local v33 = {}
			local v34 = 4 * p_u_21
			v33.Position = p19 + Vector3.new(0, v34, 0)
			v31:Create(v_u_23, v32, v33):Play()
			if p_u_20 then
				repeat
					task.wait()
				until not (p_u_20 and p_u_20:IsDescendantOf(workspace.Effects))
				print(p_u_20.Parent)
				v_u_9:PlaySound(v_u_7.Hanami.RootDisappear, v_u_23, game.SoundService.Effect)
				if _G.Settings.DesPHY then
					v_u_23:Destroy()
					if (workspace.CurrentCamera.CFrame.Position - p19).Magnitude <= 150 then
						Random.new()
						for _ = 1, 15 do
							local v35 = math.random(100, 250) / 100
							local v36 = math.random(250, 500) / 100
							local v_u_37 = v_u_6.Hiromi.GavelShard:Clone()
							local v38 = math.random(-5, 5)
							local v39 = math.random(-5, 5)
							local v40 = math.random
							v_u_37.Position = p19 + Vector3.new(v38, v39, v40(-5, 5))
							v_u_37.Size = Vector3.new(v35, v36, v35)
							local v41 = math.random(-80, 80)
							local v42 = math.random(30, 60)
							local v43 = math.random
							v_u_37.Velocity = Vector3.new(v41, v42, v43(-80, 80))
							local v44 = math.random(-50, 50)
							local v45 = math.random(-50, 50)
							local v46 = math.random
							v_u_37.RotVelocity = Vector3.new(v44, v45, v46(-50, 50))
							v_u_37.Color = v_u_23.Color
							v_u_37.Parent = workspace.Effects
							v_u_2:AddItem(v_u_37, 2)
							task.delay(1, function()
								-- upvalues: (ref) v_u_3, (copy) v_u_37
								v_u_3:Create(v_u_37, TweenInfo.new(1), {
									["Size"] = Vector3.new(0, 0, 0)
								}):Play()
							end)
						end
					end
				else
					v_u_3:Create(v_u_23, TweenInfo.new(0.2), {
						["Transparency"] = 1
					}):Play()
					v_u_9:PlayParticles(v_u_23)
					v_u_2:AddItem(v_u_23, 1)
					return
				end
			else
				task.wait(1.3)
				v_u_3:Create(v_u_23, TweenInfo.new(0.2), {
					["Transparency"] = 1
				}):Play()
				v_u_9:PlayParticles(v_u_23)
				v_u_9:PlaySound(v_u_7.Hanami.RootDisappear, v_u_23, game.SoundService.Effect)
				v_u_2:AddItem(v_u_23, 1)
				return
			end
		end,
		["TreeMonster"] = function(p47, p_u_48, p_u_49)
			-- upvalues: (ref) v_u_6, (ref) v_u_5, (ref) v_u_3, (ref) v_u_9, (ref) v_u_7, (ref) v_u_2
			local v_u_50 = v_u_6.Hanami.TreeMonster:Clone()
			v_u_50.PrimaryPart.Position = p47 + Vector3.new(0, 1, 0) - Vector3.new(0, p_u_49, 0)
			if p_u_49 then
				local v51 = Instance.new("Model")
				v_u_50.Parent = v51
				v51:ScaleTo(p_u_49)
				v_u_50.Parent = workspace.Effects
				v51:Destroy()
			end
			v_u_50.Parent = workspace.Effects
			v_u_50.AnimationController.Animator:LoadAnimation(v_u_5.Hanami.EvilTreeIdle):Play(0)
			p_u_48:GetPropertyChangedSignal("CFrame"):Connect(function()
				-- upvalues: (ref) v_u_3, (copy) v_u_50, (copy) p_u_48, (copy) p_u_49
				v_u_3:Create(v_u_50.PrimaryPart, TweenInfo.new(0.3), {
					["CFrame"] = p_u_48.CFrame * CFrame.new(0, 4 * p_u_49, 0)
				}):Play()
			end)
			p_u_48:GetAttributeChangedSignal("Lasso"):Connect(function()
				-- upvalues: (copy) v_u_50, (ref) v_u_5
				v_u_50.AnimationController:LoadAnimation(v_u_5.Hanami.EvilTreeThrow):Play(0)
			end)
			for v52 = 1, 5 do
				local v53 = v_u_6.Hanami.ParticleDissipationHolder:Clone()
				v53.BlackDust.Size = NumberSequence.new(8 - v52 / 2, 12 - v52 / 2)
				v53.RedDust1.Size = v53.BlackDust.Size
				v53.RedDust2.Size = v53.BlackDust.Size
				local v54 = v52 * 2.5 + -6
				v53.Position = Vector3.new(0, v54, 0)
				v53.Parent = v_u_50.Jaw
			end
			v_u_9:DustBreak(p47 + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
			v_u_9:PlaySound(v_u_7.Hanami.DefenseResponse.Root, v_u_50.PrimaryPart, game.SoundService.Effect)
			local v55 = v_u_6.Choso.CounterSwing.Shock:Clone()
			v55.Size = Vector3.new(10, 30, 10)
			v55.CFrame = CFrame.new(p47)
			v55.Parent = workspace.Effects
			v_u_2:AddItem(v55, 0.3)
			v_u_3:Create(v55, TweenInfo.new(0.3), {
				["Size"] = Vector3.new(36, 7, 36),
				["Transparency"] = 1,
				["Position"] = nil,
				["Position"] = v55.Position - Vector3.new(0, 3, 0)
			}):Play()
			local v56 = v_u_6.Choso.CounterSwing.Shock:Clone()
			v56.Size = Vector3.new(20, 10, 20)
			v56.CFrame = CFrame.new(p47)
			v56.Parent = workspace.Effects
			v_u_2:AddItem(v56, 0.2)
			v_u_3:Create(v56, TweenInfo.new(0.2), {
				["Size"] = Vector3.new(0, 36, 0),
				["Transparency"] = 1,
				["Position"] = nil,
				["Position"] = v56.Position + Vector3.new(0, 10, 0)
			}):Play()
			local v57 = v_u_3
			local v58 = v_u_50.PrimaryPart
			local v59 = TweenInfo.new(0.2)
			local v60 = {}
			local v61 = 4 * p_u_49
			v60.Position = p47 + Vector3.new(0, v61, 0)
			v57:Create(v58, v59, v60):Play()
			if p_u_48 then
				repeat
					task.wait()
				until not (p_u_48 and p_u_48:IsDescendantOf(workspace.Effects))
				print(p_u_48.Parent)
				v_u_9:PlaySound(v_u_7.Hanami.RootDisappear, v_u_50.PrimaryPart, game.SoundService.Effect)
				if _G.Settings.DesPHY then
					v_u_50:Destroy()
					if (workspace.CurrentCamera.CFrame.Position - p47).Magnitude <= 150 then
						Random.new()
						for _ = 1, 15 do
							local v62 = math.random(100, 250) / 100
							local v63 = math.random(250, 500) / 100
							local v_u_64 = v_u_6.Hiromi.GavelShard:Clone()
							local v65 = math.random(-5, 5)
							local v66 = math.random(-5, 5)
							local v67 = math.random
							v_u_64.Position = p47 + Vector3.new(v65, v66, v67(-5, 5))
							v_u_64.Size = Vector3.new(v62, v63, v62)
							local v68 = math.random(-80, 80)
							local v69 = math.random(30, 60)
							local v70 = math.random
							v_u_64.Velocity = Vector3.new(v68, v69, v70(-80, 80))
							local v71 = math.random(-50, 50)
							local v72 = math.random(-50, 50)
							local v73 = math.random
							v_u_64.RotVelocity = Vector3.new(v71, v72, v73(-50, 50))
							v_u_64.Color = Color3.fromRGB(76, 60, 51)
							v_u_64.Parent = workspace.Effects
							v_u_2:AddItem(v_u_64, 2)
							task.delay(1, function()
								-- upvalues: (ref) v_u_3, (copy) v_u_64
								v_u_3:Create(v_u_64, TweenInfo.new(1), {
									["Size"] = Vector3.new(0, 0, 0)
								}):Play()
							end)
						end
					end
				else
					v_u_3:Create(v_u_50, TweenInfo.new(0.2), {
						["Transparency"] = 1
					}):Play()
					v_u_9:PlayParticles(v_u_50)
					v_u_2:AddItem(v_u_50, 1)
					return
				end
			else
				task.wait(1.3)
				v_u_3:Create(v_u_50, TweenInfo.new(0.2), {
					["Transparency"] = 1
				}):Play()
				v_u_9:PlayParticles(v_u_50)
				v_u_9:PlaySound(v_u_7.Hanami.RootDisappear, v_u_50.PrimaryPart, game.SoundService.Effect)
				v_u_2:AddItem(v_u_50, 1)
				return
			end
		end,
		["SmallField"] = function(p74)
			-- upvalues: (ref) v_u_6, (ref) v_u_9, (ref) v_u_7, (ref) v_u_2
			local v75 = v_u_6.Hanami.SmallFieldWindup:Clone()
			v75.Position = p74
			v75.Parent = workspace.Effects
			v_u_9:PlaySound(v_u_7.Hanami.FlowersField.Field, v75, game.SoundService.Effect)
			task.wait(0.8)
			for _, v76 in v75:GetChildren() do
				if not v76:IsA("ParticleEmitter") then
					continue
				end
				v76.Enabled = false
			end
			v_u_2:AddItem(v75, 1)
			local v77 = v_u_6.Hanami.SmallFieldExplosion:Clone()
			v77.Position = p74 - Vector3.new(0, 1, 0)
			v77.Parent = workspace.Effects
			for _, v78 in v77:GetChildren() do
				v78:Emit(50)
			end
			task.wait(0.1)
			v77.Size = v77.Size * Vector3.new(1.3, 1, 1.3)
			for _, v79 in v77:GetChildren() do
				if v79.Name:sub(1, 1) ~= "F" then
					continue
				end
				v79.ShapePartial = 0.3
				v79:Emit(10)
			end
			v_u_2:AddItem(v77, 6)
		end
	}
	v_u_8.Effects:Connect(function(p81, ...)
		-- upvalues: (copy) v_u_80
		local v82 = v_u_80[p81]
		if v82 then
			v82(...)
		end
	end)
end
function v10.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_8, (copy) v_u_1, (ref) v_u_9
	v_u_8 = v_u_1.GetService("DefenseResponseService")
	v_u_9 = v_u_1.GetController("FXController")
end
return v10