-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.BeamController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
require(v5.Modules.CameraShaker)
require(v5.Modules.BloodyZee)
require(v5.Modules.UltNames)
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "BeamController"
})
function v11.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_6, (copy) v_u_4, (copy) v_u_3, (ref) v_u_9, (ref) v_u_10, (copy) v_u_7, (copy) v_u_2, (ref) v_u_8
	local v_u_33 = {
		["ClashQTE"] = function(p_u_12, p_u_13, p_u_14)
			-- upvalues: (ref) v_u_6, (ref) v_u_4, (ref) v_u_3, (ref) v_u_9, (ref) v_u_10, (ref) v_u_7, (ref) v_u_2
			local v_u_15 = v_u_6.Misc.BeamQTE:Clone()
			v_u_15.Health:WaitForChild("Bar1").BackgroundColor3 = p_u_13:GetAttribute("BeamColor")
			v_u_15.Health:WaitForChild("Bar2").BackgroundColor3 = p_u_14:GetAttribute("BeamColor")
			v_u_15.Parent = v_u_4.PlayerGui
			v_u_3:Create(v_u_15.Health, TweenInfo.new(0.5), {
				["BackgroundTransparency"] = 0.5
			}):Play()
			v_u_3:Create(v_u_15.Health.Bar1, TweenInfo.new(0.5), {
				["BackgroundTransparency"] = 0
			}):Play()
			v_u_3:Create(v_u_15.Health.Bar2, TweenInfo.new(0.5), {
				["BackgroundTransparency"] = 0
			}):Play()
			v_u_3:Create(v_u_15.Health.Center.Ball, TweenInfo.new(0.5), {
				["BackgroundTransparency"] = 0
			}):Play()
			local v_u_16 = {
				Enum.KeyCode.W,
				Enum.KeyCode.A,
				Enum.KeyCode.D,
				Enum.KeyCode.ButtonX,
				Enum.KeyCode.ButtonY,
				Enum.KeyCode.ButtonB
			}
			local v_u_17 = { Enum.KeyCode.W, Enum.KeyCode.A, Enum.KeyCode.D }
			local v_u_18 = {
				{ Enum.KeyCode.ButtonX, "rbxassetid://8981031512" },
				{ Enum.KeyCode.ButtonY, "rbxassetid://8981031340" },
				{ Enum.KeyCode.ButtonB, "rbxassetid://8981032988" }
			}
			local v_u_19 = {
				{ Enum.KeyCode.ButtonX, "rbxassetid://126768975062846" },
				{ Enum.KeyCode.ButtonY, "rbxassetid://140161712330460" },
				{ Enum.KeyCode.ButtonB, "rbxassetid://137275294114393" }
			}
			local v_u_20 = nil
			local function v_u_23() -- name: updateKeycode
				-- upvalues: (ref) v_u_9, (ref) v_u_20, (copy) v_u_17, (copy) v_u_15, (copy) v_u_18, (copy) v_u_19
				local v21 = v_u_9.LastInput
				if v21 == "Keyboard" then
					v_u_20 = v_u_17[math.random(1, #v_u_17)]
					v_u_15.QTE_PC.Text = v_u_20.Name
				elseif v21 == "Xbox" or v21 == "Playstation" then
					local v22 = (v21 == "Xbox" and v_u_18 or v_u_19)[math.random(1, #v_u_18)]
					v_u_20 = v22[1]
					v_u_15.QTE_CONSOLE.ImageContent = Content.fromUri(v22[2])
				end
			end
			v_u_23()
			v_u_15.QTE_MOBILE.Position = UDim2.new(math.random(20, 70) / 100, 0, math.random(20, 70) / 100, 0)
			v_u_15.QTE_MOBILE.MouseButton1Down:Connect(function()
				-- upvalues: (copy) v_u_15, (ref) v_u_10, (ref) v_u_7, (copy) p_u_12
				v_u_15.QTE_MOBILE.Position = UDim2.new(math.random(20, 70) / 100, 0, math.random(20, 70) / 100, 0)
				v_u_10:PlaySound(v_u_7.Misc.UI.Click, workspace, game.SoundService.Effect)
				p_u_12:FireServer(true)
			end)
			local v26 = v_u_2.InputBegan:Connect(function(p24, p25)
				-- upvalues: (copy) v_u_16, (ref) v_u_20, (copy) p_u_12, (ref) v_u_10, (ref) v_u_7, (copy) v_u_15, (ref) v_u_3, (copy) v_u_23
				if p25 then
					return
				elseif table.find(v_u_16, p24.KeyCode) then
					if p24.KeyCode == v_u_20 then
						p_u_12:FireServer(true)
						v_u_10:PlaySound(v_u_7.Misc.UI.Click, workspace, game.SoundService.Effect)
						v_u_10:PlaySound(v_u_7.Misc.UI.Switch, workspace, game.SoundService.Effect)
						v_u_15.QTE_PC.BackgroundColor3 = Color3.fromRGB(0, 255, 127)
						v_u_15.QTE_PC.Size = UDim2.new(0, 65, 0, 65)
						v_u_3:Create(v_u_15.QTE_PC, TweenInfo.new(0.5), {
							["BackgroundColor3"] = Color3.new(1, 1, 1),
							["Size"] = UDim2.new(0, 75, 0, 75)
						}):Play()
						v_u_15.QTE_CONSOLE.ImageColor3 = Color3.fromRGB(0, 255, 127)
						v_u_15.QTE_CONSOLE.Size = UDim2.new(0, 65, 0, 65)
						v_u_3:Create(v_u_15.QTE_CONSOLE, TweenInfo.new(0.5), {
							["ImageColor3"] = Color3.new(1, 1, 1),
							["Size"] = UDim2.new(0, 75, 0, 75)
						}):Play()
					else
						p_u_12:FireServer()
						v_u_10:PlaySound(v_u_7.Misc.UI.Switch, workspace, game.SoundService.Effect)
						v_u_15.QTE_PC.BackgroundColor3 = Color3.fromRGB(170, 0, 0)
						v_u_15.QTE_PC.Size = UDim2.new(0, 65, 0, 65)
						v_u_3:Create(v_u_15.QTE_PC, TweenInfo.new(0.5), {
							["BackgroundColor3"] = Color3.new(1, 1, 1),
							["Size"] = UDim2.new(0, 75, 0, 75)
						}):Play()
						v_u_15.QTE_CONSOLE.ImageColor3 = Color3.fromRGB(170, 0, 0)
						v_u_15.QTE_CONSOLE.Size = UDim2.new(0, 65, 0, 65)
						v_u_3:Create(v_u_15.QTE_CONSOLE, TweenInfo.new(0.5), {
							["ImageColor3"] = Color3.new(1, 1, 1),
							["Size"] = UDim2.new(0, 75, 0, 75)
						}):Play()
					end
					v_u_23()
				end
			end)
			local function v32() -- name: updateBar
				-- upvalues: (copy) p_u_13, (copy) p_u_14, (copy) v_u_15
				if p_u_13.Parent and p_u_14.Parent then
					local v27 = p_u_13:GetAttribute("Weight")
					local v28 = p_u_14:GetAttribute("Weight")
					local v29
					if v27 < 0 then
						v29 = 1 / math.abs(v27)
					else
						v29 = v27 == 0 and 1 or v27
					end
					local v30
					if v28 < 0 then
						v30 = 1 / math.abs(v28)
					else
						v30 = v28 == 0 and 1 or v28
					end
					local v31 = v29 + v30
					v_u_15.Health.Bar1.Size = UDim2.new(v29 / v31, 0, 1, 0)
				end
			end
			v32()
			p_u_13:GetAttributeChangedSignal("Weight"):Connect(v32)
			p_u_14:GetAttributeChangedSignal("Weight"):Connect(v32)
			repeat
				task.wait()
			until not p_u_12.Parent
			v_u_15:Destroy()
			if v26 then
				v26:Disconnect()
			end
		end
	}
	v_u_8.Effects:Connect(function(p34, ...)
		-- upvalues: (copy) v_u_33
		local v35 = v_u_33[p34]
		if v35 then
			v35(...)
		end
	end)
end
function v11.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_8, (copy) v_u_1, (ref) v_u_10, (ref) v_u_9
	v_u_8 = v_u_1.GetService("BeamService")
	v_u_10 = v_u_1.GetController("FXController")
	v_u_9 = v_u_1.GetController("ToolController")
end
return v11