-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Ryu.Base.GraniteBlastController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "GraniteBlastController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_7, (copy) v_u_4, (ref) v_u_11, (copy) v_u_8, (copy) v_u_3, (copy) v_u_1, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2, (ref) v_u_12, (ref) v_u_10
	local v_u_46 = {
		["Startup"] = function(p14, p15)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_11, (ref) v_u_8
			local v16 = p14:FindFirstChild("HumanoidRootPart")
			if v16 then
				local v_u_17 = v_u_7.Ryu.Charge:Clone()
				v_u_17.Weld.Part0 = p14.Head
				v_u_17.Parent = workspace.Effects
				v_u_17.Attachment.Flare:Emit(1)
				v_u_4:Create(v_u_17.Attachment.PointLight, TweenInfo.new(1), {
					["Brightness"] = 5
				}):Play()
				local v_u_18 = v_u_11:PlaySound(v_u_8.Ryu.GraniteBlast.Charge, v16, game.SoundService.Effect)
				p15.AncestryChanged:Once(function()
					-- upvalues: (copy) v_u_18, (copy) v_u_17
					if v_u_18.Parent then
						v_u_18:Destroy()
					end
					if v_u_17.Parent then
						v_u_17:Destroy()
					end
				end)
			end
		end,
		["Warn"] = function(p19)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			if p19:FindFirstChild("HumanoidRootPart") then
				local v20 = v_u_7.Ryu.ChargeWarn:Clone()
				v20.Weld.Part0 = p19.Head
				v20.Parent = workspace.Effects
				v20.Attachment.Warn:Emit(1)
				v_u_4:Create(v20.Attachment.PointLight, TweenInfo.new(1), {
					["Brightness"] = 5
				}):Play()
				v_u_3:AddItem(v20, 0.2)
			end
		end,
		["Fire"] = function(p21, _)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_1
			local v22 = p21:FindFirstChild("HumanoidRootPart")
			if v22 then
				v_u_11:PlaySound(v_u_8.Ryu.GraniteBlast.Fire, v22, game.SoundService.Effect)
				for _, v23 in v_u_7.Ryu.Launch:GetChildren() do
					v23:PivotTo(v22.CFrame * CFrame.Angles(1.5707963267948966, 0, 0))
					v_u_1.GetController("MokouController"):ArcTween(v23.Start, true)
				end
			end
		end,
		["FireHard"] = function(p24, p25)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_1, (ref) v_u_4, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v26 = p24:FindFirstChild("HumanoidRootPart")
			if v26 then
				v_u_11:PlaySound(v_u_8.Ryu.GraniteBlast.FireHard, v26, game.SoundService.Effect)
				for _, v27 in v_u_7.Misc.M.Awk.mokultMeh["3"]:GetChildren() do
					v27:PivotTo(p25 * CFrame.Angles(1.5707963267948966, 0, 0))
					v_u_1.GetController("MokouController"):ArcTween(v27.Start, true)
				end
				for _, v28 in v_u_7.Ryu.Launch:GetChildren() do
					v28:PivotTo(v26.CFrame * CFrame.Angles(1.5707963267948966, 0, 0))
					v_u_1.GetController("MokouController"):ArcTween(v28.Start, true)
				end
				local v29 = v_u_7.Ryu.GraniteBeam:Clone()
				v29.Parent = workspace.Effects
				v29.CFrame = p25 * CFrame.new(0, 2, -50)
				v_u_4:Create(v29, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(0, 0, 100)
				}):Play()
				v_u_3:AddItem(v29, 1)
				if v_u_5.Character == p24 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Hit"] = function(p30)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v31 = p30:FindFirstChild("HumanoidRootPart")
			if v31 then
				v_u_11:Flash(p30, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_8.Ryu.GraniteBlast.Hit, v31, game.SoundService.Effect)
				local v32 = v_u_7.Mahito.CrushingRushdown.DrillImpact:Clone()
				v32.Position = v31.Position
				v32.Parent = workspace.Effects
				v_u_3:AddItem(v32, 1)
				v32.Sparks.Color = ColorSequence.new(Color3.fromRGB(170, 255, 255))
				v32.Wind.Color = v32.Sparks.Color
				v32.Wind2.Color = v32.Sparks.Color
				v32.Sparks:Emit(30)
				v32.Wind2:Emit(7)
			end
		end,
		["Interp"] = function(p_u_33)
			-- upvalues: (ref) v_u_2
			local v_u_34 = p_u_33.CFrame
			local v_u_35 = tick()
			local v_u_36 = p_u_33:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_34, (copy) p_u_33, (ref) v_u_35
				v_u_34 = p_u_33.CFrame
				v_u_35 = tick()
			end)
			local v_u_37 = nil
			v_u_37 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_33, (ref) v_u_37, (copy) v_u_36, (ref) v_u_34, (ref) v_u_35
				if p_u_33.Parent then
					workspace:BulkMoveTo({ p_u_33 }, { v_u_34 + v_u_34.LookVector * (180 * (tick() - v_u_35)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_37:Disconnect()
					v_u_36:Disconnect()
				end
			end)
		end,
		["Aerial"] = function(p38, p39)
			-- upvalues: (ref) v_u_12
			local v40 = p38:FindFirstChild("HumanoidRootPart")
			if v40 then
				local v41 = p38:FindFirstChild("Humanoid")
				if v41 then
					local v42 = Instance.new("BodyGyro", v40)
					v42.P = 10000
					v42.MaxTorque = Vector3.new(40000, 40000, 40000)
					local v43 = workspace:Raycast(v40.Position, Vector3.new(0, -12, 0), _G.MapParams)
					if v43 then
						p39.Position = v43.Position + Vector3.new(0, 4, 0)
					else
						p39.Position = v40.Position
					end
					v41.PlatformStand = true
					local v44 = v_u_12:GetMouseTarget()
					if not v42:GetAttribute("Lock") then
						v42.CFrame = CFrame.new(v40.Position, v44)
					end
					task.wait()
					if p39.Parent then
						continue
					end
					v42:Destroy()
					v41.PlatformStand = false
				end
			else
				return
			end
		end,
		["Finisher"] = function(p45)
			-- upvalues: (ref) v_u_11
			if p45.HumanoidRootPart then
				v_u_11:Burn(p45)
			end
		end
	}
	v_u_10.Effects:Connect(function(p47, ...)
		-- upvalues: (copy) v_u_46
		local v48 = v_u_46[p47]
		if v48 then
			v48(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("GraniteBlastService")
	v_u_11 = v_u_1.GetController("FXController")
	v_u_12 = v_u_1.GetController("ToolController")
end
return v13