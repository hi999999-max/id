-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Toji.TojiController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
require(v5.Modules.UltNames)
local v_u_8 = require(v5.Modules.BloodyZee)
local v_u_9 = require(v5.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "TojiController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_2, (copy) v_u_9, (ref) v_u_12, (copy) v_u_7, (copy) v_u_6, (copy) v_u_8, (ref) v_u_10
	local v_u_142 = {
		["Setup"] = function(p14)
			-- upvalues: (ref) v_u_4, (ref) v_u_3, (ref) v_u_2
			local v15 = v_u_4.Character
			local v16 = v15 and v15:FindFirstChild("Info") or nil
			if v16 then
				if p14 then
					local v_u_21 = v16.ChildAdded:Connect(function(p17)
						-- upvalues: (ref) v_u_4, (ref) v_u_3, (ref) v_u_2
						local v18 = v_u_4.PlayerGui.Main.Controls.Ultimate.Special
						if p17.Name == "FastSwap" then
							local v19 = p17:GetAttribute("Duration")
							local v_u_20 = v18.Fill:Clone()
							v_u_20.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							v_u_20.BackgroundTransparency = 0.6
							v_u_20.UIGradient:Destroy()
							v_u_20.Size = UDim2.fromScale(0, 1)
							v_u_20.ZIndex = 2
							v_u_20.Parent = v18
							v_u_3:Create(v_u_20, TweenInfo.new(v19), {
								["Size"] = UDim2.fromScale(1, 1)
							}):Play()
							v_u_3:Create(v_u_20, TweenInfo.new(v19, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
								["BackgroundTransparency"] = 1
							}):Play()
							v_u_2:AddItem(v_u_20, v19)
							p17.Destroying:Once(function()
								-- upvalues: (copy) v_u_20
								v_u_20:Destroy()
							end)
						end
					end)
					local v_u_22 = nil
					v_u_22 = p14.AncestryChanged:Connect(function(_, p23)
						-- upvalues: (copy) v_u_21, (ref) v_u_22
						if p23 == nil then
							v_u_21:Disconnect()
							v_u_22:Disconnect()
						end
					end)
				end
			else
				return
			end
		end,
		["StanceHide"] = function()
			-- upvalues: (ref) v_u_9
			local v24 = v_u_9.CameraShakeInstance.new(2.3, 5, 0.1, 0.5)
			v24.PositionInfluence = Vector3.new(0.25, 0.25, 0)
			v24.RotationInfluence = Vector3.new(0, 0, 0)
			v_u_9.CurrentShaker:Shake(v24)
		end,
		["StanceUnequip"] = function(p25, p26)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v27 = p25 and p25:FindFirstChild("HumanoidRootPart") or nil
			if v27 then
				v_u_12:PlaySound(v_u_7.Toji.Stance[("%*Unequip"):format(p26)], v27, game.SoundService.Effect)
			end
		end,
		["StanceEquip"] = function(p28, p29)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v30 = p28 and p28:FindFirstChild("HumanoidRootPart") or nil
			if v30 then
				v_u_12:PlaySound(v_u_7.Toji.Stance[("%*Equip"):format(p29)], v30, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_7.Toji.Worm[("Laugh%*"):format((math.random(1, 2)))], v30, game.SoundService.Effect)
			end
		end,
		["Chase1Hit"] = function(p31, p32, p33)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_9
			local v34
			if p31 then
				v34 = p31:FindFirstChild("HumanoidRootPart") or nil
			else
				v34 = nil
			end
			local v35
			if p32 then
				v35 = p32:FindFirstChild("HumanoidRootPart") or nil
			else
				v35 = nil
			end
			if v34 then
				if v35 then
					v_u_12:Flash(p32, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Choso.BloodEdge.StabHit, v35, game.SoundService.Effect).PlaybackSpeed = math.random(90, 110) / 100
					local v36 = v_u_6.Yuta.SlashHit:Clone()
					v36.CFrame = CFrame.lookAlong(v35.Position, v34.CFrame.LookVector)
					local v37 = v36.CFrame
					local v38 = CFrame.Angles
					local v39 = -90 + math.random(-4, 4)
					v36.CFrame = v37 * v38(0, 0, (math.rad(v39)))
					v36.Parent = workspace.Effects
					v36.Slash:Emit(5)
					v_u_2:AddItem(v36, 0.5)
					if v_u_4.Character == p31 or v_u_4.Character == p32 then
						local v40 = v_u_9.CameraShakeInstance.new(p33 and 5 or 4, 8, 0.1, 0.7)
						v40.PositionInfluence = Vector3.new(0.25, 0.25, 0)
						v40.RotationInfluence = Vector3.new(0, 0, 0)
						v_u_9.CurrentShaker:Shake(v40)
					end
				end
			else
				return
			end
		end,
		["Chase1Spin"] = function(p41, p42)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2
			local v43 = p41 and p41:FindFirstChild("SetAssets") or nil
			local v44 = v43 and v43:FindFirstChild("SSK") or nil
			if v44 then
				if p42 then
					local v_u_45 = v_u_6.Toji.SSKCombatTrail:Clone()
					v_u_45.Weld.Part0 = v44.Blade
					v_u_45.Parent = workspace.Effects
					p42.AncestryChanged:Once(function()
						-- upvalues: (copy) v_u_45
						if v_u_45 then
							v_u_45:Destroy()
						end
					end)
					task.delay(0.4, function()
						-- upvalues: (copy) v_u_45, (ref) v_u_3, (ref) v_u_2
						if v_u_45 and v_u_45.Parent then
							v_u_45.Trail1.Enabled = false
							v_u_45.Trail2.Enabled = false
							v_u_3:Create(v_u_45, TweenInfo.new(0.1), {
								["Transparency"] = 1
							}):Play()
							v_u_2:AddItem(v_u_45, 0.2)
						end
					end)
				end
			else
				return
			end
		end,
		["Chase3Crush"] = function(p46, p47)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_9
			local v48 = v_u_6.Itadori.CrushingBlow:Clone()
			v48.Position = p47
			v48.PointLight:Destroy()
			v48.Parent = workspace.Effects
			v_u_3:Create(v48.Air, TweenInfo.new(0.2), {
				["Position"] = Vector3.new(0, 0, 0)
			}):Play()
			for _, v49 in v48:GetDescendants() do
				if not (v49:IsA("ParticleEmitter") or v49:IsA("Beam")) then
					continue
				end
				v49.Color = ColorSequence.new(Color3.fromRGB(255, 255, 255))
			end
			v48.Floor.Ring:Emit(10)
			v48.Floor.Wind2:Emit(8)
			v_u_2:AddItem(v48, 1.5)
			v_u_12:PlaySound(v_u_7.Itadori.CrushingBlow.GroundImpact, v48, game.SoundService.Effect)
			if v_u_4.Character == p46 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
			end
		end,
		["Chase3Hit"] = function(p50, p51)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_4, (ref) v_u_9
			if p50:FindFirstChild("HumanoidRootPart") then
				local v52 = p51:FindFirstChild("HumanoidRootPart")
				if v52 then
					v_u_12:Flash(p51, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Itadori.CrushingBlow.Hit2, v52, game.SoundService.Effect)
					local v53 = v_u_6.Toji.ChainHit:Clone()
					v53.Position = v52.Position
					v53.Parent = workspace.Effects
					v_u_2:AddItem(v53, 0.5)
					for _, v54 in v53:GetChildren() do
						v54:Emit(v54:GetAttribute("EmitCount"))
					end
					local v55 = v_u_6.Gojo.LapseBlue.Throw:Clone()
					v55.CFrame = CFrame.new(v52.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
					v55.Size = Vector3.new(0, 0, 5)
					v55.Parent = workspace.Effects
					v_u_3:Create(v55, TweenInfo.new(0.3), {
						["Size"] = Vector3.new(8, 8, 0),
						["Transparency"] = 1,
						["Position"] = nil,
						["Position"] = v55.Position + Vector3.new(0, -1, 0)
					}):Play()
					v_u_2:AddItem(v55, 0.3)
					v_u_12:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Break, v52, game.SoundService.Effect)
					v_u_12:DustBreak(v52.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_4:DistanceFromCharacter(v52.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			else
				return
			end
		end,
		["Chase3Finisher"] = function(p56)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_8, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_4, (ref) v_u_9
			local v57 = p56:FindFirstChild("HumanoidRootPart")
			if v57 then
				if p56.Parent then
					v_u_12:PlaySound(v_u_7.Itadori.Dismantle.Explode, v57, game.SoundService.Effect)
					v_u_12:PlaySound(v_u_7.Megumi.Elephant.Explode, v57, game.SoundService.Effect)
					for _, v58 in p56:GetDescendants() do
						if not (v58:IsA("BasePart") or v58:IsA("Decal")) then
							continue
						end
						v58.Transparency = 1
					end
					for _ = 1, 50 do
						v_u_8:Blood(v57.CFrame, 200, 360, 360)
					end
					if _G.Settings.Gore then
						local v59 = v_u_6.Heian.BloodSpread:Clone()
						v59.Parent = p56.Head
						v59:Emit(20)
						v_u_2:AddItem(v59, 2)
					end
					for _ = 1, 20 do
						local v_u_60 = v_u_6.Damage.Chunk:Clone()
						v_u_60.CFrame = v57.CFrame
						v_u_60.CollisionGroup = "Effects"
						local v61 = math.random(-90, 90)
						local v62 = math.random(20, 50)
						local v63 = math.random
						v_u_60.Velocity = Vector3.new(v61, v62, v63(-90, 90))
						local v64 = math.random(-200, 200)
						local v65 = math.random(-200, 200)
						local v66 = math.random
						v_u_60.RotVelocity = Vector3.new(v64, v65, v66(-200, 200))
						v_u_60.Parent = workspace.Effects
						v_u_2:AddItem(v_u_60, 3)
						task.delay(0.1, function()
							-- upvalues: (copy) v_u_60, (ref) v_u_3
							v_u_60.CanCollide = true
							task.wait(1.9)
							v_u_3:Create(v_u_60, TweenInfo.new(1), {
								["Size"] = Vector3.new(0, 0, 0)
							}):Play()
							v_u_60.Blood.Enabled = false
							v_u_60.Trail.Enabled = false
						end)
						if _G.Settings.Gore ~= false then
							continue
						end
						v_u_60.Color = Color3.fromRGB(255, 85, 255)
						v_u_60.Trail.Color = ColorSequence.new(Color3.fromRGB(255, 85, 255))
						v_u_60.Blood.Color = v_u_60.Trail.Color
					end
					if v_u_4:DistanceFromCharacter(v57.Position) < 40 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
					end
				end
			else
				return
			end
		end,
		["ChaseHit"] = function(p67, p68)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2
			local v69 = p67:FindFirstChild("HumanoidRootPart")
			if v69 then
				local v70 = p68:FindFirstChild("HumanoidRootPart")
				if v70 then
					v_u_12:Flash(p68, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Haruta.M1:FindFirstChild("Hit" .. math.random(1, 3)), v70, game.SoundService.Effect)
					local v71 = v_u_6.ChaseHit:Clone()
					local v72 = CFrame.new
					local v73 = v70.Position
					local v74 = v69.Position.X
					local v75 = v70.Position.Y
					local v76 = v69.Position.Z
					v71.CFrame = v72(v73, (Vector3.new(v74, v75, v76))) * CFrame.Angles(0, 3.141592653589793, 0)
					v71.Parent = workspace.Effects
					v_u_2:AddItem(v71, 0.5)
					v71.Ring:Emit(7)
					v71.Sparks:Emit(12)
					local v77 = v_u_6.Yuta.SlashHit:Clone()
					v77.CFrame = CFrame.lookAlong(v70.Position, v69.CFrame.LookVector)
					v77.CFrame = v77.CFrame * CFrame.Angles(0, 0, 0.17453292519943295)
					v77.Parent = workspace.Effects
					v77.Slash:Emit(5)
					v_u_2:AddItem(v77, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p78)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7
			local v79 = p78.HumanoidRootPart
			if v79 then
				local v80 = v_u_6.Gojo.LapseBlue.Throw:Clone()
				v80.CFrame = v79.CFrame * CFrame.new(0, 1, -4)
				v80.Size = Vector3.new(0, 0, 2)
				v80.Parent = workspace.Effects
				v_u_3:Create(v80, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v80, 0.3)
				v_u_12:PlaySound(v_u_7.Misc.Chase, v79, game.SoundService.Effect)
				v_u_12:DustTrail(p78, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p81, p82, p83, p84)
			-- upvalues: (ref) v_u_7, (ref) v_u_12
			local v85 = p81:FindFirstChild("HumanoidRootPart")
			if v85 then
				if p84 == "ISOH" then
					local v86 = p83 == "Down" and "Down" or p82
					local v87 = v_u_7.Toji.ISOH.M1:FindFirstChild("Swing" .. v86)
					if v87 then
						v_u_12:PlaySound(v87, v85, game.SoundService.Effect)
					else
						v_u_12:PlaySound(v_u_7.Misc.Swing.Fist, v85, game.SoundService.Effect)
					end
				elseif p84 == "COATM" then
					local v88 = p83 == "Up" and "Up" or p82
					local v89 = v_u_7.Toji.COATM.M1:FindFirstChild("Swing" .. v88)
					if v89 and p83 ~= "Down" then
						v_u_12:PlaySound(v89, v85, game.SoundService.Effect)
					else
						v_u_12:PlaySound(v_u_7.Misc.Swing.Fist, v85, game.SoundService.Effect)
					end
				else
					local v90 = p83 or p82
					local v91 = v90 and v_u_7.Toji.SSK.M1:FindFirstChild("Swing" .. v90) or nil
					if v91 then
						v_u_12:PlaySound(v91, v85, game.SoundService.Effect)
					else
						v_u_12:PlaySound(v_u_7.Misc.Swing.Fist, v85, game.SoundService.Effect)
					end
				end
			else
				return
			end
		end,
		["Swing2"] = function(p_u_92, p93, p94, p95)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			if p_u_92:FindFirstChild("HumanoidRootPart") then
				local function v101(p96) -- name: chainTrail
					-- upvalues: (copy) p_u_92, (ref) v_u_6, (ref) v_u_2
					local v97 = p_u_92.SetAssets:FindFirstChild("COATM")
					if v97 then
						for v98 = 5, 6 do
							local v99 = v97:FindFirstChild("Beam" .. v98)
							if not v99 then
								continue
							end
							local v_u_100 = v_u_6.Toji.COATMCombatTrail:Clone()
							v_u_100.Parent = v97
							v_u_100.Attachment0 = v99.Attachment0
							v_u_100.Attachment1 = v99.Attachment1
							v_u_100.Enabled = true
							task.delay(p96, function()
								-- upvalues: (copy) v_u_100, (ref) v_u_2
								v_u_100.Enabled = false
								v_u_2:AddItem(v_u_100, 0.2)
							end)
						end
					end
				end
				if p95 == "SSK" then
					local v102 = p_u_92.SetAssets:FindFirstChild("SSK")
					if v102 then
						local v103 = v_u_6.Toji.SSKCombatTrail:Clone()
						v103.Weld.Part0 = v102.Blade
						v103.Parent = workspace.Effects
						task.wait(p93 == 4 and 0.425 or 0.325)
						v103.Trail1.Enabled = false
						v103.Trail2.Enabled = false
						v_u_3:Create(v103, TweenInfo.new(0.1), {
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v103, 0.2)
					end
				elseif p95 == "ISOH" and (p93 ~= 4 or p94 == "Down") then
					local v104 = p_u_92.SetAssets:FindFirstChild("ISOH")
					if v104 then
						local v105 = v_u_6.Toji.ISOHCombatTrail:Clone()
						v105.Weld.Part0 = v104.Blade
						v105.Parent = workspace.Effects
						task.wait(0.275)
						v105.Trail.Enabled = false
						v_u_3:Create(v105, TweenInfo.new(0.1), {
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v105, 0.2)
					end
				else
					if p95 == "COATM" and p94 ~= "Down" then
						v101(0.45)
					end
					return
				end
			else
				return
			end
		end,
		["Hit"] = function(p106, p107, p108, p109, p110)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2
			local v111 = p106:FindFirstChild("HumanoidRootPart")
			if v111 then
				local v112 = p107:FindFirstChild("HumanoidRootPart")
				if v112 then
					v_u_12:Flash(p107, Color3.new(1, 1, 1))
					if p110 == "COATM" then
						local v113 = p109 == "Up" and "Up" or p108
						local v114 = v_u_7.Toji.COATM.M1:FindFirstChild("Hit" .. v113)
						if v114 and p109 ~= "Down" then
							v_u_12:PlaySound(v114, v112, game.SoundService.Effect)
						else
							v_u_12:PlaySound(v_u_7.Gojo.M1:FindFirstChild("Hit" .. p108), v112, game.SoundService.Effect)
						end
						if p109 ~= "Down" then
							local v115 = v_u_6.Toji.ChainHit:Clone()
							v115.Position = v112.Position
							v115.Parent = workspace.Effects
							v_u_2:AddItem(v115, 0.5)
							for _, v116 in v115:GetChildren() do
								v116:Emit(v116:GetAttribute("EmitCount"))
							end
						end
					elseif p110 == "ISOH" then
						local v117 = {}
						local v118 = CFrame.Angles
						local v119 = -30 + math.random(-2, 2)
						local v120 = v118(0, 0, (math.rad(v119)))
						local v121 = CFrame.Angles
						local v122 = 15 + math.random(-2, 2)
						local v123 = v121(0, 0, (math.rad(v122)))
						local v124 = CFrame.Angles
						local v125 = 50 + math.random(-2, 2)
						__set_list(v117, 1, {v120, v123, v124(0, 0, (math.rad(v125)))})
						local v126 = p109 == "Down" and 1 or p108
						local v127 = v_u_7.Toji.ISOH.M1:FindFirstChild("Hit" .. v126)
						if v127 then
							v_u_12:PlaySound(v127, v112, game.SoundService.Effect)
						else
							v_u_12:PlaySound(v_u_7.Gojo.M1:FindFirstChild("Hit" .. p108), v112, game.SoundService.Effect)
						end
						if p108 <= 3 then
							local v128 = v_u_6.Yuta.SlashHit:Clone()
							v128.CFrame = CFrame.lookAlong(v112.Position, v111.CFrame.LookVector)
							if v117[p108] then
								v128.CFrame = v128.CFrame * v117[p108]
							elseif p109 == "Up" then
								v128.CFrame = v128.CFrame * CFrame.Angles(0, 0, -1.3089969389957472)
							end
							v128.Parent = workspace.Effects
							v128.Slash:Emit(5)
							v_u_2:AddItem(v128, 0.5)
						end
					else
						if p110 == "SSK" then
							local v129 = { CFrame.Angles(0, 0, 0.6108652381980153), CFrame.Angles(0, 0, -0.17453292519943295), CFrame.Angles(0, 0, -0.7853981633974483) }
							local v130 = v_u_7.Toji.SSK.M1:FindFirstChild("Hit" .. (p109 or p108))
							if v130 then
								v_u_12:PlaySound(v130, v112, game.SoundService.Effect)
							else
								v_u_12:PlaySound(v_u_7.Gojo.M1:FindFirstChild("Hit" .. p108), v112, game.SoundService.Effect)
							end
							local v131 = v_u_6.Yuta.SlashHit:Clone()
							v131.CFrame = CFrame.lookAlong(v112.Position, v111.CFrame.LookVector)
							if p109 == "Down" then
								v131.CFrame = v131.CFrame * CFrame.Angles(0, 0, 1.5707963267948966)
							elseif p109 == "Up" then
								v131.CFrame = v131.CFrame * CFrame.Angles(0, 0, -1.3089969389957472)
							elseif v129[p108] then
								v131.CFrame = v131.CFrame * v129[p108]
							end
							v131.Parent = workspace.Effects
							v131.Slash:Emit(5)
							v_u_2:AddItem(v131, 0.5)
						end
						return
					end
				else
					return
				end
			else
				return
			end
		end,
		["Launch"] = function(p132, p133, p134)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_9, (ref) v_u_8
			local v135 = p132:FindFirstChild("HumanoidRootPart")
			if v135 then
				local v136 = v_u_6.Gojo.LapseBlue.Throw:Clone()
				v136.CFrame = CFrame.new(v135.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v136.Size = Vector3.new(0, 0, 5)
				v136.Parent = workspace.Effects
				v_u_3:Create(v136, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v136.Position + Vector3.new(0, p133, 0)
				}):Play()
				v_u_2:AddItem(v136, 0.3)
				if p133 < 0 then
					v_u_12:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Break, v135, game.SoundService.Effect)
					v_u_12:DustBreak(v135.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_4:DistanceFromCharacter(v135.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
					if p134 ~= "ISOH" then
						return
					end
					v_u_12:PlaySound(v_u_7.Choso.BloodEdge.StabHit, v135, game.SoundService.Effect).PlaybackSpeed = math.random(90, 110) / 100
					for _ = 1, 8 do
						v_u_8:Blood(CFrame.lookAt(p132.Torso.Position, p132.Torso.Position + Vector3.new(0, 10, 0)), math.random(20, 40), math.random(20, 40), math.random(20, 40))
					end
				end
			end
		end,
		["Equip"] = function(p137, p138)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v139 = p137:FindFirstChild("HumanoidRootPart")
			if v139 then
				if p137.SetAssets:FindFirstChild("Worm") then
					v139 = p137.SetAssets.Worm.head
				end
				v_u_12:PlaySound(p138 and v_u_7.Toji.Worm.Unequip or v_u_7.Toji.Worm.Equip, v139, game.SoundService.Effect)
			end
		end,
		["Chase3Whoosh"] = function(p140)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v141 = p140:FindFirstChild("HumanoidRootPart")
			if v141 then
				v_u_12:PlaySound(v_u_7.Toji.COATM.Chase, v141, game.SoundService.Effect)
			end
		end
	}
	v_u_10.Effects:Connect(function(p143, ...)
		-- upvalues: (copy) v_u_142
		local v144 = v_u_142[p143]
		if v144 then
			v144(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_12, (ref) v_u_11
	v_u_10 = v_u_1.GetService("TojiService")
	v_u_12 = v_u_1.GetController("FXController")
	v_u_11 = v_u_1.GetController("HitboxController")
end
return v13