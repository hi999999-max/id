-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.DomainController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
local v_u_10 = require(v6.Modules.UltNames)
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "DomainController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_7, (copy) v_u_3, (ref) v_u_12, (copy) v_u_8, (copy) v_u_9, (copy) v_u_2, (copy) v_u_10, (ref) v_u_11
	local v_u_198 = {
		["Clash"] = function(p14, p_u_15, p_u_16, p17)
			-- upvalues: (ref) v_u_5, (ref) v_u_4, (ref) v_u_7, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9, (ref) v_u_2
			local v_u_18 = p_u_15:FindFirstChild("ClashFolder")
			if v_u_18 then
				task.spawn(function()
					-- upvalues: (ref) v_u_5, (ref) v_u_4, (copy) p_u_15, (copy) p_u_16
					local v_u_19 = v_u_5.PlayerGui:WaitForChild("Main")
					local v_u_20 = v_u_19.Controls.Ultimate.Time
					if not v_u_20.Visible then
						local v_u_21 = {}
						local function v_u_24() -- name: Cleanup
							-- upvalues: (copy) v_u_21, (copy) v_u_20, (ref) v_u_4
							for v22, v23 in v_u_21 do
								v23:Disconnect()
								v_u_21[v22] = nil
							end
							v_u_20.Visible = false
							v_u_4:Create(v_u_20, TweenInfo.new(0.3, Enum.EasingStyle.Quad), {
								["TextTransparency"] = 1
							}):Play()
							v_u_4:Create(v_u_20.UIStroke, TweenInfo.new(0.3, Enum.EasingStyle.Quad), {
								["Transparency"] = 1
							}):Play()
						end
						local function v26() -- name: onTimerChanged
							-- upvalues: (ref) p_u_15, (copy) v_u_24, (copy) v_u_20, (copy) v_u_19, (ref) v_u_4
							local v25 = p_u_15:GetAttribute("Timer")
							if v25 then
								v_u_20.Text = v25
								if not v_u_19.Controls.Ultimate.Time.Visible then
									v_u_20.TextTransparency = 1
									v_u_20.UIStroke.Transparency = 1
									v_u_20.Visible = true
									v_u_4:Create(v_u_20, TweenInfo.new(0.15, Enum.EasingStyle.Quad), {
										["TextTransparency"] = 0
									}):Play()
									v_u_4:Create(v_u_20.UIStroke, TweenInfo.new(0.15, Enum.EasingStyle.Quad), {
										["Transparency"] = 0
									}):Play()
								end
							else
								v_u_24()
							end
						end
						if p_u_15:GetAttribute("Timer") then
							v26()
						end
						local v27 = p_u_15:GetAttributeChangedSignal("Timer")
						table.insert(v_u_21, v27:Connect(v26))
						local v28 = p_u_15.Destroying
						table.insert(v_u_21, v28:Once(v_u_24))
						local v29 = p_u_16.Destroying
						table.insert(v_u_21, v29:Once(v_u_24))
						local v30 = game.Players.LocalPlayer.Character
						if v30 then
							local v31 = v30.Destroying
							table.insert(v_u_21, v31:Once(v_u_24))
						end
					end
				end)
				local v_u_32 = v_u_7.Misc.DomainClash.ClashBG:Clone()
				v_u_32.Parent = p14
				v_u_32.CFrame = p14.CFrame
				task.spawn(function()
					-- upvalues: (copy) v_u_18, (copy) p_u_16, (copy) v_u_32, (ref) v_u_4
					repeat
						task.wait()
					until not (v_u_18:IsDescendantOf(workspace) and p_u_16:IsDescendantOf(workspace))
					for _, v33 in v_u_32:GetDescendants() do
						if v33:IsA("ParticleEmitter") then
							v33.Enabled = false
						else
							if not v33:IsA("BasePart") then
								continue
							end
							v_u_4:Create(v33, TweenInfo.new(0.5), {
								["Transparency"] = 1
							}):Play()
						end
					end
					task.wait(0.5)
					v_u_32:Destroy()
				end)
				if not p17 then
					local v_u_34 = p_u_15.DomainGround
					v_u_34.Surround.Enabled = true
					v_u_4:Create(v_u_34.Surround, TweenInfo.new(0.8), {
						["ShapePartial"] = 1
					}):Play()
					v_u_3:AddItem(v_u_34, 2)
					v_u_12:PlaySound(v_u_8.Hakari.IdleDeath.IdleDeath, workspace, game.SoundService.Effect)
					task.delay(0.5, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_34, (ref) v_u_12
						v_u_4:Create(v_u_34, TweenInfo.new(0.25), {
							["Transparency"] = 0
						}):Play()
						v_u_12:DomainMapFade(Color3.new(0, 0, 0), 0.25, 1)
					end)
					task.wait(1.25)
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
				if p_u_16 and p_u_16.Parent then
					if v_u_18 and v_u_18:IsDescendantOf(workspace) then
						local v_u_35 = v_u_12:PlaySound(v_u_8.Misc.Domain.ClashMusic, workspace, game.SoundService.Music, true)
						task.spawn(function()
							-- upvalues: (copy) v_u_18, (copy) p_u_16, (copy) v_u_35, (ref) v_u_4, (ref) v_u_3
							repeat
								task.wait()
							until not (v_u_18:IsDescendantOf(workspace) and p_u_16:IsDescendantOf(workspace))
							if v_u_35 then
								v_u_4:Create(v_u_35, TweenInfo.new(2), {
									["Volume"] = 0
								}):Play()
								v_u_3:AddItem(v_u_35, 2)
							end
						end)
						local v_u_36 = {}
						for _, v37 in v_u_18:GetChildren() do
							local v38 = v37:GetAttribute("Type") or "None"
							local v39 = v_u_7.Misc.DomainClash:FindFirstChild(v38)
							if not v39 then
								continue
							end
							local v_u_40 = v39:Clone()
							v_u_40.CFrame = v_u_32.CFrame
							v_u_40.Parent = v_u_32
							v_u_36[v37] = v_u_40
							if v37:GetAttribute("Offset") then
								local v41 = -(v37:GetAttribute("Offset") or Vector3.new(0, 0, 1)).Unit
								v_u_40.CFrame = CFrame.lookAlong(v_u_32.Position, v41 * Vector3.new(1, 0, 1))
							end
							if v38 == "MS" then
								for _, v42 in v_u_40:GetDescendants() do
									if not v42:IsA("ParticleEmitter") then
										continue
									end
									local v43 = TweenInfo.new(1, Enum.EasingStyle.Circular, Enum.EasingDirection.In)
									v42.TimeScale = 0
									v_u_4:Create(v42, v43, {
										["TimeScale"] = 1
									}):Play()
								end
								local v44 = v_u_7.Itadori.MalevolantShrine.DomainBG.Floor:Clone()
								v44.Transparency = 1
								local v45 = v44.Shrine
								v44.CFrame = v_u_40.CFrame - Vector3.new(0, 6, 0)
								local v46 = v44.CFrame - v_u_40.CFrame.LookVector * 30
								v45:SetPrimaryPartCFrame(v46 - Vector3.new(0, 30, 0))
								v44.CanCollide = false
								v44.Anchored = true
								v44.Parent = v_u_40
								v_u_4:Create(v45.Shrine, TweenInfo.new(1.5, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
									["CFrame"] = v46 + Vector3.new(0, 10, 0)
								}):Play()
								v_u_4:Create(v45.Skulls, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
									["CFrame"] = v46 + Vector3.new(0, 3, 0)
								}):Play()
								v44.Water.Splash:Emit(10)
								v44.Water.Splash.ZOffset = 2
							elseif v38 == "IV" then
								local v47 = v_u_7.Gojo.InfiniteVoid.DomainTravel.SpaceBG:Clone()
								v47.Enabled = true
								v47.Image.ImageTransparency = 1
								v47.Parent = v_u_40
								v_u_4:Create(v47.Image, TweenInfo.new(1), {
									["ImageTransparency"] = 0
								}):Play()
								v_u_4:Create(v_u_32, TweenInfo.new(1), {
									["Transparency"] = 1
								}):Play()
								local v_u_48 = v_u_7.Gojo.InfiniteVoid.DomainTravel.Lines:Clone()
								v_u_48.Size = Vector3.new(60, 60, 20)
								for _, v49 in v_u_48:GetChildren() do
									if not v49:IsA("ParticleEmitter") then
										continue
									end
									v49.ZOffset = -100
								end
								v_u_48.CFrame = v_u_40.CFrame
								v_u_48.Parent = v_u_40
								local v_u_50 = nil
								v_u_50 = v_u_2.RenderStepped:Connect(function()
									-- upvalues: (copy) v_u_48, (copy) v_u_40, (ref) v_u_50
									if v_u_48:IsDescendantOf(workspace) then
										v_u_48.CFrame = v_u_40.CFrame - v_u_40.Position + workspace.CurrentCamera.CFrame.Position + workspace.CurrentCamera.CFrame.LookVector * 5
									else
										v_u_50:Disconnect()
									end
								end)
							elseif v38 == "DS" then
								v_u_40.Domain:PivotTo(v_u_40.CFrame + Vector3.new(0, 1, 0))
								v_u_40.UpParticlesHolder:PivotTo(v_u_40.CFrame)
								local v_u_51 = v_u_40.Domain.Saws:GetChildren()
								for _, v52 in pairs(v_u_51) do
									v52:SetAttribute("cf", v52.Blade.CFrame)
								end
								for _, v53 in v_u_40.Lights.Spotlight:GetDescendants() do
									if not (v53:IsA("Beam") or v53:IsA("SpotLight")) then
										continue
									end
									v53.Enabled = false
								end
								for _, v54 in v_u_40.Domain:GetDescendants() do
									if not v54:IsA("BasePart") or v54.Transparency ~= 0 then
										continue
									end
									local v55 = v54.CFrame
									local v56 = math.random(100, 200)
									v54.CFrame = (v55 - vector.create(0, v56, 0)) * CFrame.Angles(math.random(-3.141592653589793, 3.141592653589793), math.random(-3.141592653589793, 3.141592653589793), math.random(-3.141592653589793, 3.141592653589793))
									v54.Transparency = 0
									v_u_4:Create(v54, TweenInfo.new(math.random(1, 2), Enum.EasingStyle.Exponential), {
										["CFrame"] = nil,
										["Transparency"] = 0,
										["CFrame"] = v55
									}):Play()
								end
								for _, v57 in v_u_40:GetDescendants() do
									if not v57:IsA("Beam") or v57.Parent.Parent ~= v_u_40 then
										continue
									end
									v57.LightEmission = 1
									v_u_4:Create(v57, TweenInfo.new(1), {
										["LightEmission"] = 0
									}):Play()
								end
								task.spawn(function()
									-- upvalues: (copy) v_u_51, (copy) v_u_40, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9
									local v58 = #v_u_51
									local v59 = TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
									local v60 = TweenInfo.new(0.65, Enum.EasingStyle.Cubic, Enum.EasingDirection.In)
									TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
									local v61 = 0
									while v_u_40:IsDescendantOf(workspace.Domains) do
										if v58 < v61 + 1 then
											for v62 = 1, v58 do
												local v63 = v_u_40.Parent and v_u_40.Domain.Saws:FindFirstChild("Blade" .. v62)
												if not v63 then
													break
												end
												v_u_4:Create(v63.Blade, v60, {
													["CFrame"] = v63:GetAttribute("cf")
												}):Play()
												v_u_12:PlaySound(v_u_8.Hiromi.DeadlySentence.BladeUp, v63.Blade, game.SoundService.Effect)
												task.wait(0.035)
											end
											task.wait(0.65)
											if not v_u_40.Parent then
												break
											end
											for _, v64 in next, v_u_51 do
												v64.Blade.CFrame = v64:GetAttribute("cf")
											end
											task.wait(0.75)
											if not v_u_40.Parent then
												break
											end
											v61 = 0
										end
										for _ = 1, 2 do
											v61 = v61 + 1
											local v65 = v_u_40.Domain.Saws:FindFirstChild("Blade" .. v61)
											if not v65 then
												break
											end
											v_u_4:Create(v65.Blade, v59, {
												["CFrame"] = v65:GetAttribute("cf") - Vector3.new(0, 45, 0)
											}):Play()
											local v66 = v_u_12:PlaySound(v_u_8.Hiromi.DeadlySentence.BladeFallRope, workspace, game.SoundService.Effect)
											v66.Volume = v66.Volume * 0.4
											task.delay(0.3, function()
												-- upvalues: (ref) v_u_9, (ref) v_u_12, (ref) v_u_8
												v_u_9.CurrentShaker:Shake(v_u_9.Presets.GreaterMediumHit)
												local v67 = v_u_12:PlaySound(v_u_8.Hiromi.DeadlySentence["BladeFall" .. math.random(1, 2)], workspace, game.SoundService.Effect)
												v67.Volume = v67.Volume * 0.4
											end)
										end
										task.wait(2)
									end
								end)
							elseif v38 == "JP" then
								local v_u_68 = CFrame.new(0, 0, 195)
								local function v_u_72(p69, p70, p71) -- name: setSegmentOffset
									-- upvalues: (copy) v_u_40, (copy) v_u_68
									p69.CFrame = v_u_40.CFrame * v_u_68 * CFrame.new(-p71.X, 0, p71.Z) * CFrame.Angles(0, 3.141592653589793, 0)
									p70.CFrame = v_u_40.CFrame * v_u_68 * CFrame.new(-p71.X, 0, p71.Z)
								end
								local v_u_79, v_u_80 = (function(p73) -- name: createSegments
									-- upvalues: (ref) v_u_7, (copy) v_u_72, (copy) v_u_40
									local v74 = v_u_7.Hakari.IdleDeath.Segment:Clone()
									local v75 = v_u_7.Hakari.IdleDeath.Segment:Clone()
									v_u_72(v74, v75, p73)
									for v76 = 1, 50 do
										local v77 = v_u_7.Hakari.IdleDeath.Segment:Clone()
										v77.CFrame = v74.CFrame * CFrame.new(0, 0, v76 * -8)
										v77.Anchored = false
										v77.WeldConstraint.Part1 = v74
										v77.Parent = v74
										local v78 = v77:Clone()
										v78.CFrame = v75.CFrame * CFrame.new(0, 0, v76 * 8)
										v78.WeldConstraint.Part1 = v75
										v78.Parent = v75
									end
									v74.Parent = v_u_40
									v75.Parent = v_u_40
									return v74, v75
								end)(Vector3.new(40, 0, 400))
								v_u_4:Create(v_u_79, TweenInfo.new(0.5), {
									["CFrame"] = v_u_40.CFrame * v_u_68 * CFrame.new(40, 0, -200) * CFrame.Angles(0, 3.141592653589793, 0)
								}):Play()
								v_u_4:Create(v_u_80, TweenInfo.new(0.5), {
									["CFrame"] = v_u_40.CFrame * v_u_68 * CFrame.new(-40, 0, -200)
								}):Play()
								local v_u_81 = v_u_12:PlaySound(v_u_8.Hakari.IdleDeath.ClashTravel, workspace, game.SoundService.Effect)
								task.delay(0.5, function()
									-- upvalues: (copy) v_u_79, (copy) v_u_40, (copy) v_u_68, (copy) v_u_80, (copy) v_u_81
									repeat
										v_u_79.CFrame = v_u_40.CFrame * v_u_68 * CFrame.new(40, 0, -200 + math.random(-200, 200) / 100) * CFrame.Angles(0, 3.141592653589793, 0)
										v_u_80.CFrame = v_u_40.CFrame * v_u_68 * CFrame.new(-40, 0, -200 + math.random(-200, 200) / 100)
										task.wait()
									until not (v_u_79.Parent and v_u_40:IsDescendantOf(workspace.Domains))
									v_u_81:Destroy()
								end)
							elseif v38 == "ML" then
								Random.new()
								local v_u_82 = v_u_40.YutaDomain
								v_u_82:PivotTo(v_u_40.CFrame * CFrame.new(0, 29.5, 61.5) * CFrame.Angles(0, 4.71238898038469, 1.5707963267948966))
								local v_u_83 = {}
								for _, v84 in v_u_82.Props:QueryDescendants("BasePart") do
									v_u_83[v84] = v84.CFrame
									v84.Transparency = 1
									v84.CFrame = v84.CFrame * CFrame.new(0, -20, 0)
								end
								for _, v85 in v_u_82.AllBows:QueryDescendants("BasePart") do
									v85.Transparency = 1
								end
								for _, v86 in v_u_82.AllBows:GetChildren() do
									if v86.Name ~= "Bow" then
										continue
									end
									for _, v87 in v86:GetChildren() do
										if v87.Name ~= "Bow1" and v87.Name ~= "Bow2" then
											continue
										end
										local v88 = v87.Name == "Bow2" and 1 or -1
										local v_u_89 = {}
										for _, v90 in v87:GetChildren() do
											if not v90:IsA("BasePart") then
												continue
											end
											local v91 = v90.CFrame:VectorToObjectSpace(v90.CFrame.RightVector * (v90.Size.X / 2 * v88))
											local v92 = v90.Name
											v_u_89[tonumber(v92)] = {
												["Part"] = v90,
												["Original"] = {
													["CFrame"] = v90.CFrame,
													["Size"] = v90.Size
												},
												["Offset"] = v91
											}
											local v93 = v90.Size.Y
											local v94 = v90.Size.Z
											v90.Size = vector.create(0, v93, v94)
											v90.Transparency = 1
										end
										task.spawn(function()
											-- upvalues: (copy) v_u_89, (ref) v_u_4
											local v95 = #v_u_89
											for v96 = 1, #v_u_89 do
												if not v_u_89[v96] then
													continue
												end
												local v97 = v_u_89[v96].Part
												local v98 = v_u_89[v96].Original
												local v99 = v_u_89[v96].Offset
												local v100 = v98.CFrame * CFrame.new(-v99)
												local v101 = CFrame.Angles
												local v102 = math.random(-15, 15)
												v97.CFrame = v100 * v101(-1.5707963267948966, math.rad(v102), 0)
												v97.Transparency = 0
												local _ = v96 / v95
												local v103 = v_u_4:Create(v97, TweenInfo.new(0.015), {
													["Size"] = v98.Size,
													["CFrame"] = v98.CFrame
												})
												v103:Play()
												v103.Completed:Wait()
											end
										end)
									end
								end
								task.spawn(function()
									-- upvalues: (copy) v_u_82, (ref) v_u_4, (copy) v_u_40, (copy) v_u_83, (ref) v_u_2
									local v104 = TweenInfo.new(0.3)
									local v_u_105 = {}
									for _, v106 in v_u_82.AllBows:QueryDescendants("BasePart") do
										local v107 = v106:Clone()
										v107.Parent = v106.Parent
										v107.Material = Enum.Material.Plastic
										v107.Color = Color3.new(1, 1, 1)
										v107.CFrame = v106.CFrame
										v107.Size = v106.Size
										v_u_4:Create(v107, v104, {
											["Size"] = nil,
											["Transparency"] = 1,
											["Size"] = v107.Size * Vector3.new(2, 5, 5)
										}):Play()
										table.insert(v_u_105, v107)
									end
									local v_u_108 = Instance.new("Vector3Value")
									v_u_108.Value = Vector3.new(2, 0, 0)
									v_u_4:Create(v_u_108, TweenInfo.new(2, Enum.EasingStyle.Linear), {
										["Value"] = v_u_40.Size
									}):Play()
									task.spawn(function()
										-- upvalues: (copy) v_u_108, (ref) v_u_40, (ref) v_u_83, (ref) v_u_4
										while v_u_108.Value ~= v_u_40.Size do
											local v109 = (v_u_108.Value * Vector3.new(0, 1, 1)).Magnitude
											for v110, v111 in v_u_83 do
												if v110.Transparency == 0 or (v110.Position - (v_u_40.CFrame * CFrame.new(0, 0, -v_u_40.Size.Z / 2)).Position).Magnitude > v109 then
													continue
												end
												v110.Transparency = 0
												v_u_4:Create(v110, TweenInfo.new(0.3, Enum.EasingStyle.Circular, Enum.EasingDirection.InOut), {
													["CFrame"] = v111
												}):Play()
											end
											task.wait(0.05)
										end
										v_u_108:Destroy()
									end)
									task.delay(0.5, function()
										-- upvalues: (copy) v_u_105, (ref) v_u_40
										for _, v112 in v_u_105 do
											v112:Destroy()
										end
										v_u_40.Stars.Enabled = true
									end)
									local v_u_113 = v_u_82.AllBows:GetPivot().Position.Y
									local v_u_114 = 0
									local v_u_115 = nil
									v_u_115 = v_u_2.RenderStepped:Connect(function(p116)
										-- upvalues: (ref) v_u_40, (ref) v_u_115, (ref) v_u_82, (ref) v_u_114, (copy) v_u_113
										if v_u_40.Parent then
											local v117 = v_u_82.AllBows:GetPivot()
											local v118, v119, v120 = v117:ToOrientation()
											local v121 = v117.Position
											v_u_114 = (v_u_114 + p116) % 15
											local v122 = v_u_82.AllBows
											local v123 = CFrame.new
											local v124 = v121.X
											local v125 = v_u_113
											local v126 = v_u_114 * 45 * 0.15
											v122:PivotTo(v123(v124, v125 + math.sin(v126), v121.Z) * CFrame.fromOrientation(v118, v119, v120))
										else
											v_u_115:Disconnect()
										end
									end)
								end)
							elseif v38 == "SP" then
								local v127 = v_u_40.Hands
								local v_u_128 = v127.AnimationController:LoadAnimation(v127.AnimationController.Animation)
								local v129 = TweenInfo.new(1, Enum.EasingStyle.Back, Enum.EasingDirection.InOut)
								local v130 = next
								local v131, v132 = v127:QueryDescendants("BasePart")
								for _, v133 in v130, v131, v132 do
									v133.Size = Vector3.new(0, 0, 0)
								end
								for _, v134 in v127:QueryDescendants("BasePart") do
									v_u_4:Create(v134, v129, {
										["Size"] = Vector3.new(20, 80, 20)
									}):Play()
								end
								v127:SetPrimaryPartCFrame(v_u_40.CFrame * CFrame.new(0, 10, 120))
								v_u_128:Play(0)
								v_u_128:GetMarkerReachedSignal("Loop"):Connect(function()
									-- upvalues: (copy) v_u_128
									v_u_128.TimePosition = 1.5
								end)
								task.spawn(function()
									-- upvalues: (copy) v_u_40, (ref) v_u_7, (ref) v_u_4
									for v135 = 1, 10 do
										local v_u_136 = v135 * 36
										local v_u_137 = CFrame.Angles(0, 0, (math.rad(v_u_136)))
										local v_u_138 = (v_u_40.CFrame * v_u_137 - (v_u_40.CFrame * v_u_137).LookVector * 120).Position
										task.delay(v135 % 2 == 0 and 0 or 0.2, function()
											-- upvalues: (ref) v_u_136, (copy) v_u_137, (ref) v_u_40, (ref) v_u_138, (ref) v_u_7, (ref) v_u_4
											for v139 = 1, 8 do
												v_u_136 = v139 * 12
												local v140 = v_u_136
												local v141 = v_u_137 * CFrame.Angles(math.rad(v140), 0, 0)
												local v142 = (v_u_40.CFrame * v141 - (v_u_40.CFrame * v141).LookVector * 120).Position
												local v143 = CFrame.new(v_u_138, v142)
												local v144 = v_u_7.Mahito.SelfPerfection.Hand:Clone()
												v144.CFrame = v143
												v144.Parent = v_u_40.HandFolder
												v_u_138 = v142
												local v145 = v_u_4
												local v146 = TweenInfo.new(0.4, Enum.EasingStyle.Back)
												local v147 = {
													["Size"] = Vector3.new(10, 10, 30),
													["CFrame"] = nil
												}
												local v148 = v143 + v143.LookVector * 5
												local v149 = CFrame.Angles
												local v150 = math.random(-10, 10)
												local v151 = math.rad(v150)
												local v152 = math.random(-10, 10)
												local v153 = math.rad(v152)
												local v154 = math.random(0, 360)
												v147.CFrame = v148 * v149(v151, v153, (math.rad(v154)))
												v145:Create(v144, v146, v147):Play()
												task.wait(0.2)
												if v_u_40.Parent then
													continue
												end
												return
											end
										end)
									end
								end)
							elseif v38 == "TCMP" then
								local v_u_155 = v_u_40.Model
								v_u_155:PivotTo(v_u_40.CFrame * CFrame.new(0, 0, 92.5) * CFrame.Angles(0, -1.5707963267948966, 0) - Vector3.new(0, 9, 0))
								for _, v156 in v_u_155:QueryDescendants("BasePart") do
									local v157 = v156.Size
									v156.Size = Vector3.new(0, 0, 0)
									local v158 = v156.CFrame
									local v159 = math.random(100, 200)
									v156.CFrame = (v158 - Vector3.new(0, v159, 0)) * CFrame.Angles(math.random(-3.141592653589793, 3.141592653589793), math.random(-3.141592653589793, 3.141592653589793), math.random(-3.141592653589793, 3.141592653589793))
									v_u_4:Create(v156, TweenInfo.new(math.random(10, 20) / 10, Enum.EasingStyle.Exponential), {
										["CFrame"] = v158
									}):Play()
									v_u_4:Create(v156, TweenInfo.new(math.random(15, 40) / 10, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out), {
										["Size"] = v157
									}):Play()
								end
								task.spawn(function()
									-- upvalues: (ref) v_u_4, (copy) v_u_155, (copy) v_u_40
									task.wait(0.5)
									v_u_4:Create(v_u_155.Eye, TweenInfo.new(0.5), {
										["Size"] = Vector3.new(30, 30, 30)
									}):Play()
									repeat
										v_u_155.Eye.CFrame = CFrame.lookAt(v_u_155.Eye.Position, workspace.CurrentCamera.CFrame.Position)
										task.wait()
									until not v_u_40.Parent
								end)
							else
								if v38 ~= "SOB" then
									continue
								end
								v_u_40.CFrame = v_u_40.CFrame * (CFrame.new(0, -5.5, 0) * CFrame.Angles(-1.5707963267948966, 0, 1.5707963267948966))
								local v_u_160 = v_u_40.SeaOfBranch
								v_u_160.Center.Transparency = 1
								v_u_160:PivotTo(v_u_40.CFrame)
								v_u_4:Create(v_u_160.Center, TweenInfo.new(1), {
									["Transparency"] = 0
								}):Play()
								task.delay(1, function()
									-- upvalues: (copy) v_u_160
									for _, v161 in v_u_160.Emitters:GetChildren() do
										if not v161:IsA("BasePart") then
											continue
										end
										for _, v_u_162 in v161:GetChildren() do
											v_u_162:Clear()
											task.delay(v_u_162:GetAttribute("EmitDelay") or 0, function()
												-- upvalues: (copy) v_u_162
												v_u_162:Emit(v_u_162:GetAttribute("EmitCount"))
												task.wait(0.5)
												v_u_162.TimeScale = 0
											end)
										end
									end
									v_u_160.Center:GetPropertyChangedSignal("Transparency"):Once(function()
										-- upvalues: (ref) v_u_160
										for _, v_u_163 in v_u_160.Emitters:GetChildren() do
											if not v_u_163:IsA("BasePart") then
												continue
											end
											task.spawn(function()
												-- upvalues: (copy) v_u_163
												for v164 = 1, 10 do
													for _, v165 in v_u_163:GetChildren() do
														v165.Transparency = NumberSequence.new(v164 / 10)
														task.wait(0.05)
													end
												end
											end)
										end
									end)
								end)
							end
						end
						local v166 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.LightHit)
						repeat
							local function v170()
								-- upvalues: (copy) v_u_36, (ref) v_u_4, (ref) v_u_3
								for v167, v168 in v_u_36 do
									if v167.Value and v167.Parent then
										continue
									end
									for _, v169 in v168:GetDescendants() do
										if v169:IsA("ParticleEmitter") then
											v169.Enabled = false
										else
											if not v169:IsA("BasePart") then
												continue
											end
											v_u_4:Create(v169, TweenInfo.new(0.5), {
												["Transparency"] = 1
											}):Play()
										end
									end
									v_u_3:AddItem(v168, 5)
									v_u_36[v167] = nil
								end
							end
							pcall(v170)
							task.wait()
						until not (p_u_16:IsDescendantOf(workspace) and v_u_18:IsDescendantOf(workspace))
						if v166 then
							v166:StartFadeOut(1)
						end
						if p_u_16:IsDescendantOf(workspace) and not v_u_18:IsDescendantOf(workspace) then
							v_u_9.CurrentShaker:Shake(v_u_9.Presets.SnapOh)
							if _G.Settings.Flash ~= true then
								return
							end
							local v171 = Instance.new("ColorCorrectionEffect")
							v_u_3:AddItem(v171, 1)
							v171.Saturation = -1
							v171.Contrast = -10
							v171.Name = "InvertCC"
							v171.Parent = game.Lighting
							v_u_4:Create(v171, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
								["Saturation"] = 0,
								["Contrast"] = 0
							}):Play()
						end
					end
				else
					return
				end
			else
				return
			end
		end,
		["Hit"] = function(p172, p173)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			local v174 = p172:FindFirstChild("HumanoidRootPart")
			if v174 then
				v_u_12:Flash(p172, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit" .. p173), v174, game.SoundService.Effect)
				local v175 = math.random(140, 200) / 10
				local v176 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v176.Transparency = 0.7
				v176.Position = p172.Head.Position
				local v177 = math.random(-180, 180)
				local v178 = math.random(-180, 180)
				local v179 = math.random
				v176.Orientation = Vector3.new(v177, v178, v179(-180, 180))
				v176.Size = Vector3.new(0, 0, 7)
				v176.Parent = workspace.Effects
				v_u_4:Create(v176, TweenInfo.new(0.1, Enum.EasingStyle.Quad), {
					["Size"] = nil,
					["Transparency"] = 1,
					["Size"] = Vector3.new(v175, v175, 0)
				}):Play()
				v_u_3:AddItem(v176, 0.1)
			end
		end,
		["Swing"] = function(p180)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v181 = p180:FindFirstChild("HumanoidRootPart")
			if v181 then
				v_u_12:PlaySound(v_u_8.Misc.Swing.Fist, v181, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p182, p183, p184)
			-- upvalues: (ref) v_u_10, (ref) v_u_12
			local v185 = v_u_10[p182:GetAttribute("Moveset")]
			if v185 then
				v185 = v185[2]
			end
			if p184 == "Down" then
				v_u_12:ArmFlash(p182["Right Leg"], v185 or Color3.fromRGB(255, 255, 255), 0.4)
				return
			elseif p183 == 1 or p183 == 4 then
				v_u_12:ArmFlash(p182["Right Arm"], v185 or Color3.fromRGB(255, 255, 255), 0.3)
			else
				v_u_12:ArmFlash(p182["Left Arm"], v185 or Color3.fromRGB(255, 255, 255), 0.3)
			end
		end,
		["Launch"] = function(p186, p187)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v188 = p186:FindFirstChild("HumanoidRootPart")
			if v188 then
				local v189 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v189.CFrame = CFrame.new(v188.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v189.Size = Vector3.new(0, 0, 5)
				v189.Parent = workspace.Effects
				v_u_4:Create(v189, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v189.Position + Vector3.new(0, p187, 0)
				}):Play()
				v_u_3:AddItem(v189, 0.3)
				if p187 < 0 then
					v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v188, game.SoundService.Effect)
					v_u_12:DustBreak(v188.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v188.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			end
		end,
		["ClashHighlight"] = function(p190, p_u_191)
			-- upvalues: (ref) v_u_4
			for _, v192 in next, p190 do
				if not (v192.Parent and p_u_191.Parent) then
					continue
				end
				local v_u_193 = Instance.new("Highlight")
				v_u_193.DepthMode = Enum.HighlightDepthMode.Occluded
				v_u_193.FillTransparency = 1
				v_u_193.OutlineTransparency = 1
				v_u_193.Parent = v192
				v_u_4:Create(v_u_193, TweenInfo.new(0.5), {
					["OutlineTransparency"] = 0
				}):Play()
				task.spawn(function()
					-- upvalues: (copy) p_u_191, (copy) v_u_193
					repeat
						task.wait()
					until not (p_u_191.Parent and (p_u_191.Parent.Parent and p_u_191.Parent.Parent.Parent))
					v_u_193:Destroy()
				end)
			end
		end,
		["TojiDisableCollider"] = function(p194)
			-- upvalues: (ref) v_u_5
			local v195 = p194:FindFirstChild("DomainCollider")
			while p194.Parent do
				task.wait(0.1)
				local v196 = v_u_5.Character
				if v196 and v196:GetAttribute("Moveset") == "Toji" then
					p194.CanCollide = false
					local v197 = p194:FindFirstChild("DomainHole")
					if not v197 then
						continue
					end
					v197.CanCollide = false
				else
					p194.CanCollide = not p194:FindFirstChild("DomainHole")
					v195.CanCollide = not p194:FindFirstChild("DomainHole")
				end
			end
		end
	}
	v_u_11.Effects:Connect(function(p199, ...)
		-- upvalues: (copy) v_u_198
		local v200 = v_u_198[p199]
		if v200 then
			v200(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12
	v_u_11 = v_u_1.GetService("DomainService")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13