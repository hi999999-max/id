-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Yuta.Base.VeilstepController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "VeilstepController"
})
local v_u_12 = RaycastParams.new()
v_u_12.FilterType = Enum.RaycastFilterType.Include
v_u_12.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
function v11.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_9, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_8, (copy) v_u_4, (copy) v_u_12, (ref) v_u_10
	local v_u_58 = {
		["Sound"] = function(p13)
			-- upvalues: (ref) v_u_9, (ref) v_u_7
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_9:PlaySound(v_u_7.Yuta.Veilstep, v14, game.SoundService.Effect)
			end
		end,
		["Sound2"] = function(p15)
			-- upvalues: (ref) v_u_9, (ref) v_u_7
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_9:PlaySound(v_u_7.Yuta.VeilstepJump, v16, game.SoundService.Effect)
			end
		end,
		["Dust"] = function(p17, p18)
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_2
			local v19 = p18:FindFirstChild("HumanoidRootPart")
			if v19 then
				v_u_9:DustTrail(p18, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
				local v20 = workspace
				local v21 = p17.Position - Vector3.new(0, 2, 0)
				local v22 = -v19.Size.Y * 1.6
				local v23 = v20:Raycast(v21, Vector3.new(0, v22, 0), _G.MapParams)
				if v23 then
					local v24 = v_u_6.Yuta.Veilstep.Dust:Clone()
					v24.CFrame = CFrame.lookAlong(v23.Position + Vector3.new(0, 2, 0), p17.LookVector, Vector3.new(0, 1, 0))
					v24.Parent = workspace.Effects
					v_u_2:AddItem(v24, 1)
					for _, v_u_25 in v24:GetDescendants() do
						if not v_u_25:IsA("ParticleEmitter") then
							continue
						end
						if v_u_25.Name == "Smoke2" then
							v_u_25.Color = ColorSequence.new(v23.Instance.Color)
						end
						task.delay(v_u_25:GetAttribute("EmitDelay"), function()
							-- upvalues: (copy) v_u_25
							v_u_25:Emit(v_u_25:GetAttribute("EmitCount"))
						end)
					end
				end
			end
		end,
		["SecondWind"] = function(p26, p27)
			-- upvalues: (ref) v_u_9, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2
			local v28 = p27:FindFirstChild("HumanoidRootPart")
			if v28 then
				v_u_9:PlaySound(v_u_7.Yuta.SecondWind.Dash, v28, game.SoundService.Effect)
				v_u_9:DustTrail(p27, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
				local v29 = p26 * CFrame.new(0, -3.5, 0)
				local v30 = v_u_6.Yuta.SecondWind:Clone()
				v30.CFrame = CFrame.lookAlong(v29.Position, p26.LookVector, Vector3.new(0, 1, 0))
				v30.Parent = workspace.Effects
				v_u_2:AddItem(v30, 1)
				for _, v_u_31 in v30:GetDescendants() do
					if not v_u_31:IsA("ParticleEmitter") then
						continue
					end
					task.delay(v_u_31:GetAttribute("EmitDelay"), function()
						-- upvalues: (copy) v_u_31
						v_u_31:Emit(v_u_31:GetAttribute("EmitCount"))
					end)
				end
				task.wait(0.14)
				v30.CFrame = CFrame.lookAlong(v30.Position, v28.CFrame.LookVector)
			end
		end,
		["SecondWindGrab"] = function(p32)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_9, (ref) v_u_7
			local v33 = p32:FindFirstChild("HumanoidRootPart")
			if v33 then
				local v34 = v_u_6.Yuta.Veilstep.Spin.SpinRing:Clone()
				v34.Parent = v33
				v_u_2:AddItem(v34, 0.5)
				v34.Ring:Emit(10)
				v_u_9:PlaySound(v_u_7.Yuta.SecondWind.Grab, v33, game.SoundService.Effect)
			end
		end,
		["DiveFloorHit"] = function(p35)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_9, (ref) v_u_7, (ref) v_u_8
			local v36 = -p35.LookVector
			local v37 = workspace:Raycast(p35.Position - v36, v36 * 10, _G.MapParams)
			if v37 then
				local v38 = v_u_6.Hiromi.Shockwave:Clone()
				v38.Position = v37.Position
				v38.Parent = workspace.Effects
				local v39 = v38.CFrame
				local v40 = CFrame.Angles
				local v41 = math.random(-179, 179)
				v38.CFrame = v39 * v40(0, math.rad(v41), 0)
				v_u_3:Create(v38.mesh.Mesh, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
					["Scale"] = Vector3.new(15, 0, 15)
				}):Play()
				v_u_3:Create(v38.mesh.Decal, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
					["Transparency"] = 1
				}):Play()
				v38.Floor.Glow:Emit(1)
				v38.Floor.Ring:Emit(10)
				v_u_2:AddItem(v38, 1.5)
				local v42 = v_u_6.Yuta.Veilstep.CEImpact:Clone()
				v42.Position = v37.Position
				v42.Parent = workspace.Effects
				v_u_2:AddItem(v42, 2)
				v_u_3:Create(v42.PointLight, TweenInfo.new(0.6), {
					["Brightness"] = 0
				}):Play()
				v42.Glow:Emit(1)
				v42.Sparks:Emit(50)
				v42.Sparks2:Emit(20)
				v42.Wind2:Emit(7)
				v_u_3:Create(v42.Air, TweenInfo.new(0.2), {
					["Position"] = Vector3.new(0, 0, 0)
				}):Play()
				v_u_9:PlaySound(v_u_7.Hakari.Shock, v42, game.SoundService.Effect)
				v_u_9:PlaySound(v_u_7.Yuta.VeilstepHit, v42, game.SoundService.Effect)
				v_u_9:PlaySound(v_u_7.Hakari.Impact, v42, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v37.Position).Magnitude < 150 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
			if (p35.Position - workspace.CurrentCamera.CFrame.Position).Magnitude < 25 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
			end
		end,
		["SpinRing"] = function(p43)
			-- upvalues: (ref) v_u_6, (ref) v_u_2
			local v44 = p43:FindFirstChild("HumanoidRootPart")
			if v44 then
				local v45 = v_u_6.Yuta.Veilstep.Spin.SpinRing:Clone()
				v45.Parent = v44
				v_u_2:AddItem(v45, 0.5)
				v45.Ring:Emit(10)
			end
		end,
		["Hit"] = function(p46, p47)
			-- upvalues: (ref) v_u_9, (ref) v_u_7
			local v48 = p46:FindFirstChild("HumanoidRootPart")
			if v48 then
				v_u_9:Flash(p46, p47 and Color3.fromRGB(255, 170, 255) or Color3.new(1, 1, 1))
				local v49 = v_u_9:PlaySound(v_u_7.Yuta.M1.Hit4, v48, game.SoundService.Effect)
				v49.Volume = v49.Volume * 2
			end
		end,
		["DiveHitbox"] = function(p50, p51, p52)
			-- upvalues: (ref) v_u_9, (ref) v_u_7, (ref) v_u_4, (ref) v_u_12
			local v53 = p50:FindFirstChild("HumanoidRootPart")
			if v53 then
				local v54 = p50:FindFirstChild("Humanoid")
				if v54 then
					local v55 = p50:FindFirstChild("Right Arm")
					if v55 then
						local v_u_56 = v_u_9:PlaySound(v_u_7.Yuta.VeilstepDive, v53, game.SoundService.Effect)
						p51.AncestryChanged:Once(function()
							-- upvalues: (copy) v_u_56
							v_u_56:Destroy()
						end)
						if p50 == v_u_4.Character then
							local v57 = workspace:Raycast(v55.Position, p51.Velocity.Unit * 10, v_u_12)
							if not v57 and v54.FloorMaterial ~= Enum.Material.Air then
								v57 = workspace:Raycast(v55.Position + p51.Velocity.Unit, Vector3.new(0, -6, 0), v_u_12)
							end
							if v57 then
								p52:FireServer(v57.Position, v57.Normal)
								p51:Destroy()
							end
							task.wait(0.025)
							if p51.Parent then
								continue
							end
						end
					end
				else
					return
				end
			else
				return
			end
		end
	}
	v_u_10.Effects:Connect(function(p59, ...)
		-- upvalues: (copy) v_u_58
		local v60 = v_u_58[p59]
		if v60 then
			v60(...)
		end
	end)
end
function v11.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_9
	v_u_10 = v_u_1.GetService("VeilstepService")
	v_u_9 = v_u_1.GetController("FXController")
end
return v11