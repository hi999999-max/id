-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Hanami.Awake.SeaOfBranchesController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local v_u_6 = v_u_5.Animations
local v_u_7 = v_u_5.Utils
local v_u_8 = v_u_5.Sounds
require(v_u_5.Modules.CameraShaker)
require(v_u_5.Modules.BloodyZee)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "SeaOfBranchesController"
})
function v11.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_10, (copy) v_u_8, (copy) v_u_4, (copy) v_u_6, (copy) v_u_3, (copy) v_u_5, (copy) v_u_2, (copy) v_u_7, (ref) v_u_9
	local v_u_65 = {
		["Startup"] = function(p12)
			-- upvalues: (ref) v_u_10, (ref) v_u_8, (ref) v_u_4, (ref) v_u_6, (ref) v_u_3
			local v13 = p12:FindFirstChild("HumanoidRootPart")
			if v13 then
				v_u_10:PlaySound(v_u_8.Hanami.DomainVL, v13, game.SoundService.Voice)
				v_u_10:DomainBurst(v13)
				local v14 = v_u_4.Character
				if v14 and v14:FindFirstChild("HumanoidRootPart") then
					local v15 = v14:FindFirstChild("HumanoidRootPart")
					if (v13.Position - v15.Position).Magnitude <= 37.5 then
						v_u_10:Domain(p12, function(p16, p17)
							-- upvalues: (ref) v_u_6, (ref) v_u_3
							local v18 = p17.HumanoidRootPart
							v18.CFrame = v18.CFrame * CFrame.new(0, 1.5, 1.5)
							p17.Humanoid:LoadAnimation(v_u_6.Hanami.Domain):Play(0)
							p16.Panel.ImageLabel.Image = "rbxassetid://114997336495273"
							p16.Panel.ImageLabel.Size = UDim2.new(0.8, 0, 0.25, 0)
							p16.Panel.Viewport.LightColor = Color3.fromRGB(170, 255, 255)
							p16.Panel.Viewport.Ambient = Color3.fromRGB(255, 255, 255)
							p16.Panel.Viewport.LightDirection = Vector3.new(0, -1, 0)
							v_u_3:Create(p16.Panel.Viewport, TweenInfo.new(1.5), {
								["LightColor"] = Color3.fromRGB(254, 255, 197),
								["Ambient"] = Color3.fromRGB(255, 251, 194)
							}):Play()
							local v19 = game.ReplicatedStorage.Utils.Hanami.FlowerCannon:Clone()
							v19.Weld.Part0 = p17["Left Arm"]
							v19.Parent = p17
							p17["Right Arm"].FingersR:Destroy()
							p17["Left Arm"].FingersL:Destroy()
						end)
					end
				end
			end
		end,
		["Absorb"] = function(p20, p_u_21)
			-- upvalues: (ref) v_u_5, (ref) v_u_3, (ref) v_u_2
			local v22 = p20:FindFirstChild("HumanoidRootPart")
			if v22 then
				local v23 = p20["Left Arm"]
				local v_u_24 = v_u_5.Utils.Hanami.EmpowerCharge:Clone()
				local v25 = Instance.new("Model")
				v_u_24.Parent = v25
				v25:ScaleTo(2)
				v_u_24.Parent = workspace.Effects
				v25:Destroy()
				v_u_24.CFrame = v22.CFrame * CFrame.new(0, -3 * p20:GetScale(), 0) * CFrame.new(0, 0.1, 0)
				local v26 = workspace:Raycast(v23.Position, Vector3.new(-0, -20, -0), _G.MapParams)
				if v26 then
					v_u_24.Position = v26.Position + Vector3.new(0, 0.1, 0)
				end
				v_u_3:Create(v_u_24.PointLight, TweenInfo.new(0.7), {
					["Brightness"] = 5
				}):Play()
				task.spawn(function()
					-- upvalues: (copy) v_u_24
					for _ = 1, 3 do
						if not v_u_24.Parent then
							break
						end
						v_u_24.Charge.Ring:Emit(1)
						task.wait(0.3)
					end
				end)
				v_u_2:AddItem(v_u_24, 4)
				p_u_21:GetPropertyChangedSignal("Value"):Connect(function()
					-- upvalues: (ref) v_u_3, (copy) v_u_24
					v_u_3:Create(v_u_24.PointLight, TweenInfo.new(0.4), {
						["Brightness"] = 0
					}):Play()
					v_u_24.Charge.Light:Emit(1)
				end)
				p_u_21.Destroying:Connect(function()
					-- upvalues: (copy) p_u_21, (copy) v_u_24
					if p_u_21.Value ~= true then
						v_u_24:Destroy()
					end
				end)
				task.wait()
				local v27 = workspace:Raycast(v23.Position, Vector3.new(-0, -20, -0), _G.MapParams)
				if v27 then
					v_u_24.Position = v27.Position + Vector3.new(0, 0.1, 0)
				end
				if p_u_21.Parent ~= nil and p_u_21.Value ~= true then
					continue
				end
			end
		end,
		["FloorEffect"] = function(p28)
			-- upvalues: (ref) v_u_7, (ref) v_u_3
			local v29 = p28:FindFirstChild("HumanoidRootPart")
			if v29 then
				local v30 = v_u_7.Hanami.Domain.CenterGround:Clone()
				v30.Parent = workspace.Effects
				local v31 = workspace:Raycast(v29.Position, Vector3.new(-0, -20, -0), _G.MapParams)
				if v31 then
					v30.Position = v31.Position - Vector3.new(0, 1, 0)
				end
				local v32 = v30.Size * Vector3.new(0.5, 1, 0.5)
				v30.Size = Vector3.new(1, 1, 1)
				v_u_3:Create(v30, TweenInfo.new(0.5), {
					["Size"] = v32
				}):Play()
				for _, v33 in v30:GetChildren() do
					v33.Enabled = true
				end
				task.wait(0.5)
				for _, v34 in v30:GetChildren() do
					if v34.Name:sub(1, 1) == "F" then
						v34.ShapePartial = 1
					else
						v34.Enabled = false
					end
				end
				task.wait(1.5)
				v30:Destroy()
			end
		end,
		["Fade"] = function(p35, p36)
			-- upvalues: (ref) v_u_2
			for _, v37 in p36 do
				local v_u_38 = Instance.new("Part")
				v_u_38.CanCollide = false
				v_u_38.Massless = true
				v_u_38.Anchored = true
				v_u_38.Position = v37[1]
				v_u_38.Orientation = v37[2]
				v_u_38.Color = v37[3]
				v_u_38.Material = v37[4]
				v_u_38.Size = v37[5] * Vector3.new(1.3, 1.3, 1.3)
				v_u_38.Parent = workspace.Effects
				v_u_2:AddItem(v_u_38, 3)
				local v39 = (v_u_38.Position - p35).Magnitude / 75
				task.delay(v39 * 1.5, function()
					-- upvalues: (copy) v_u_38
					v_u_38.Color = Color3.fromRGB(111, 111, 111)
				end)
			end
		end,
		["Opening"] = function(p40, p41, p_u_42, p43, _)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_10, (ref) v_u_8
			local v_u_44 = nil
			local v_u_45 = v_u_7.Hanami.Domain.HanamiDomain:Clone()
			v_u_45:PivotTo(p40.CFrame)
			task.spawn(function()
				-- upvalues: (copy) p_u_42, (copy) v_u_45, (ref) v_u_44
				repeat
					task.wait()
				until not (p_u_42.Parent and (p_u_42.Parent.Parent and p_u_42.Parent.Parent.Parent))
				v_u_45:Destroy()
				if v_u_44 and v_u_44.Parent then
					v_u_44:Destroy()
				end
			end)
			if not p43 then
				p40.Transparency = 0
				v_u_45.DomainBG.Center.Size = Vector3.new(141.37, 2, 141.37)
				local v46 = v_u_45.DomainBG.Center
				v46.Position = v46.Position + Vector3.new(0, 9, 0)
				v_u_45.DomainBG.Center.Transparency = 1
			end
			v_u_45.Parent = p40
			local v_u_47 = p41:FindFirstChild("DomainGround")
			if v_u_47 then
				v_u_47.Surround.Enabled = true
				v_u_3:Create(v_u_47.Surround, TweenInfo.new(0.8), {
					["ShapePartial"] = 1
				}):Play()
				v_u_2:AddItem(v_u_47, 2)
				task.delay(0.8, function()
					-- upvalues: (ref) v_u_3, (copy) v_u_47, (ref) v_u_10
					v_u_3:Create(v_u_47, TweenInfo.new(0.4), {
						["Transparency"] = 0
					}):Play()
					v_u_10:DomainMapFade(Color3.fromRGB(0, 0, 0), 0.5, 1.5)
				end)
			end
			if not p43 then
				task.wait(1.5)
				v_u_3:Create(v_u_45.DomainBG.Center, TweenInfo.new(0.5), {
					["Transparency"] = 0
				}):Play()
				task.wait(0.3)
			end
			v_u_44 = v_u_10:PlaySound(v_u_8.Hanami.DomainOST, workspace, game.SoundService.Music)
			for _, v_u_48 in v_u_45.DomainBG.Emitters:GetChildren() do
				if not v_u_48:IsA("BasePart") then
					continue
				end
				for _, v_u_49 in v_u_48:GetChildren() do
					v_u_49:Clear()
					task.delay(v_u_49:GetAttribute("EmitDelay") or 0, function()
						-- upvalues: (copy) v_u_49, (copy) v_u_48
						v_u_49:Emit(v_u_48:GetAttribute("EmitCount"))
						if v_u_49.Name:sub(1, 1) == "F" then
							task.wait(0.5)
							v_u_49.TimeScale = 0
						end
					end)
				end
			end
			task.spawn(function()
				-- upvalues: (copy) v_u_45
				local v50 = v_u_45.DomainBG.Skybox.Center
				local _ = v50.Position.Y
				local v51 = workspace.CurrentCamera
				while v50.Parent do
					local v52 = v51.CFrame.Position
					v50.CFrame = CFrame.lookAlong(v52, v50.CFrame.LookVector)
					task.wait()
				end
			end)
			task.wait(0.5)
			v_u_3:Create(p40, TweenInfo.new(1), {
				["Transparency"] = 1
			}):Play()
		end,
		["Shatter"] = function(p53)
			-- upvalues: (ref) v_u_7, (ref) v_u_2, (ref) v_u_10, (ref) v_u_8, (ref) v_u_3
			local v54 = v_u_7.Domain:Clone()
			v54.Transparency = 1
			v54.CanCollide = false
			v54.Position = p53
			v54.Shatter.Color = ColorSequence.new(Color3.new(0, 0, 0))
			v54.Parent = workspace.Effects
			v_u_2:AddItem(v54, 3)
			for _, v55 in v54:GetChildren() do
				if v55.Name == "Shatter" then
					v55:Emit(100)
				else
					v55:Destroy()
				end
			end
			v_u_10:PlaySound(v_u_8.Itadori.MalevolantShrine.Shatter, v54, game.SoundService.Effect)
			v54.Transparency = 0
			v54.Color = Color3.new(0, 0, 0)
			v_u_3:Create(v54, TweenInfo.new(0.2), {
				["Transparency"] = 1
			}):Play()
			if _G.Settings.DesPHY then
				if (workspace.CurrentCamera.CFrame.Position - v54.Position).Magnitude > 150 then
					return
				end
				local v56 = Random.new()
				local v57 = TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
				for _ = 1, 80 do
					local v58 = v_u_7.Gojo.Shard:Clone()
					local v59 = v56:NextUnitVector().Unit
					local v60 = math.random(1, 8)
					local v61 = math.random
					v58.Size = Vector3.new(0.1, v60, v61(1, 8))
					v58.CFrame = CFrame.lookAlong(p53, v59) * CFrame.Angles(1.5707963267948966, 0, 0) + v59 * 37.5
					v58.CFrame = v58.CFrame * CFrame.Angles(0, math.random(0, 3.141592653589793), 0)
					v58.Color = Color3.new(0, 0, 0)
					v58.CanCollide = true
					v58.CollisionGroup = "Effects"
					v58.Parent = workspace.Effects
					local v62 = math.random(-50, 50)
					local v63 = math.random(-50, 50)
					local v64 = math.random
					v58.RotVelocity = Vector3.new(v62, v63, v64(-50, 50))
					v58.Transparency = 0
					v58.Material = Enum.Material.Neon
					v_u_3:Create(v58, v57, {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_2:AddItem(v58, 4)
				end
			end
		end
	}
	v_u_9.Effects:Connect(function(p66, ...)
		-- upvalues: (copy) v_u_65
		local v67 = v_u_65[p66]
		if v67 then
			v67(...)
		end
	end)
end
function v11.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("SeaOfBranchesService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11