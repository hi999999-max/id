-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Hanami.Awake.FlowerFieldController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
require(v_u_6.Modules.CameraShaker)
require(v_u_6.Modules.BloodyZee)
local v_u_9 = require(v_u_6.Modules.SraikoVFX)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "FlowerFieldController"
})
Random.new()
local _ = workspace.CurrentCamera
local _ = { Color3.fromRGB(86, 66, 54), Color3.fromRGB(76, 60, 51), Color3.fromRGB(86, 60, 51) }
local v14 = RaycastParams.new()
v14.FilterType = Enum.RaycastFilterType.Include
v14.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_7, (ref) v_u_11, (copy) v_u_8, (copy) v_u_5, (copy) v_u_4, (copy) v_u_3, (copy) v_u_9, (copy) v_u_2, (copy) v_u_6, (ref) v_u_10
	local v_u_135 = {
		["Windup"] = function(_) end,
		["FlowerTrail"] = function(p15, p16)
			-- upvalues: (ref) v_u_7, (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_4, (ref) v_u_3
			local v17 = v_u_7.Hanami.FlowerFieldTrail:Clone()
			v17.Parent = workspace.Effects
			v17.Anchored = false
			local v18 = Instance.new("Weld")
			v18.Part1 = v17
			v18.Part0 = p15
			v18.Parent = p15
			v_u_11:PlaySound(v_u_8.Hanami.FlowersField.Field, v17, game.SoundService.Effect)
			local v19
			if p16 == v_u_5 then
				v19 = v_u_7.Megumi.HitArea:Clone()
				v19.Size = Vector3.new(30, 0, 30)
				v19.Parent = workspace.Effects
			else
				v19 = nil
			end
			while p15.Parent do
				if v19 then
					local v20 = workspace:Raycast(p15.Position, Vector3.new(0, -15, 0), _G.MapParams)
					if v20 then
						v_u_4:Create(v19, TweenInfo.new(0.05), {
							["Position"] = v20.Position + Vector3.new(0, 0.1, 0)
						}):Play()
						if not v19.Parent then
							v19.Parent = workspace.Effects
						end
					else
						v19.Parent = nil
					end
				end
				task.wait()
			end
			if v19 then
				v19:Destroy()
			end
			for _, v21 in v17:GetDescendants() do
				if not v21:IsA("ParticleEmitter") then
					continue
				end
				v21.Enabled = false
			end
			v_u_3:AddItem(v17, 2)
		end,
		["FlowerExplosion"] = function(p22)
			-- upvalues: (ref) v_u_7, (ref) v_u_9, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8, (ref) v_u_4
			local v23 = v_u_7.Hanami.FlowerFieldExplosion:Clone()
			v23.Position = p22 - Vector3.new(0, 0.5, 0)
			v23.Size = Vector3.new(3, 1, 3)
			v23.Parent = workspace.Effects
			for _, v24 in pairs(v_u_7.Nanami.BluntCut.Charge:GetChildren()) do
				if not v24:IsA("Model") then
					continue
				end
				v24:SetAttribute("Duration", v24:GetAttribute("Duration"))
				local v25 = v24:Clone()
				v25:ScaleTo(3)
				if v25.Name == "NewSlash" then
					v25:SetAttribute("StartTransparency", 0.5)
				end
				local v26 = v_u_9.HandleMesh(v25, CFrame.lookAlong(p22, Vector3.new(0, 1, 0)) * CFrame.Angles(-1.5707963267948966, 0, 0))
				v25.Parent = workspace.Effects
				v_u_3:AddItem(v25, v26)
			end
			v_u_11:PlaySound(v_u_8.Hanami.FlowersField.Hit, v23, game.SoundService.Effect)
			v_u_4:Create(v23, TweenInfo.new(0.4), {
				["Size"] = Vector3.new(40, 1, 40)
			}):Play()
			task.wait(0.4)
			for _, v27 in v23:GetChildren() do
				if not v27:IsA("ParticleEmitter") then
					continue
				end
				v27:Emit(20)
				v27.Enabled = false
			end
			v_u_3:AddItem(v23, 7)
		end,
		["Lasso"] = function(p28, p_u_29, p_u_30)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_2, (ref) v_u_4
			local v_u_31 = p28.Position + Vector3.new(0, 8, 0)
			Random.new()
			local v32 = Color3.fromRGB(76, 60, 51)
			v_u_11:DustBreak(v_u_31 + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
			v_u_11:PlaySound(v_u_8.Hanami.AOESpikes.WoodBallsAppear, p28, game.SoundService.Effect)
			v_u_11:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, p28, game.SoundService.Effect)
			local v33 = v_u_31
			local v_u_34 = v33
			local v_u_35 = v_u_34
			local v36 = v33
			v33 = v_u_35
			v36 = v_u_34
			v_u_34 = v33
			v36 = v_u_35
			local v_u_37 = {}
			local v_u_38 = nil
			local v_u_39 = nil
			local v_u_40 = nil
			local v_u_41 = nil
			for v42 = 1, 8 do
				local v43 = v42 / 8
				local v44 = v43 * -0.9 + 1.3
				local v45 = v_u_34 + (v_u_31 - v_u_34) * v43
				local v46 = v45 + (v_u_31 + (v_u_35 - v_u_31) * v43 - v45) * v43
				local v47 = Instance.new("Part")
				v47.Name = v42
				v47.CanCollide = false
				v47.Transparency = 0
				v47.Anchored = true
				v47.Color = v32
				v47.Material = Enum.Material.Wood
				v47.CFrame = CFrame.new(v46, v33) * CFrame.new(0, 0, -(v33 - v46).Magnitude / 2)
				local v48 = (v46 - v33).Magnitude * 1.25
				v47.Size = vector.create(v44, v44, v48)
				v_u_37[v42] = v47
				v47.Parent = p_u_29.Parts
				v33 = v46
			end
			local v_u_49 = 0
			local v_u_50 = 0
			local v_u_51 = 0.4
			local v52 = CFrame.lookAt(v_u_34, p_u_30.Position)
			local _ = v52.LookVector
			local _ = v52.RightVector
			local v_u_53 = v52 * CFrame.new(10, 2.5, 10)
			local v_u_54 = v52 * CFrame.new(10, 10, 0)
			local v_u_55 = v52 * CFrame.new(0, 10, -10)
			local v_u_56 = v52 * CFrame.new(0, 2.5, 10)
			local v_u_57 = false
			local _ = v_u_2.PreRender:Connect(function()
				-- upvalues: (copy) p_u_29, (ref) v_u_57, (ref) v_u_38, (ref) v_u_39, (ref) v_u_40, (ref) v_u_41, (copy) v_u_34, (copy) v_u_37, (ref) v_u_31, (ref) v_u_35
				if p_u_29.Parent then
					if v_u_57 == false and p_u_29.Grab.Value then
						v_u_57 = true
					end
				else
					if v_u_38 then
						v_u_38:Disconnect()
						v_u_38 = nil
					end
					if v_u_39 then
						v_u_39:Disconnect()
						v_u_39 = nil
					end
					if v_u_40 then
						v_u_40:Disconnect()
						v_u_40 = nil
					end
					if v_u_41 then
						v_u_41:Disconnect()
						v_u_41 = nil
					end
				end
				local v58 = v_u_34
				for v59, v60 in ipairs(v_u_37) do
					local v61 = v59 / #v_u_37
					local v62 = v_u_34
					local v63 = v_u_31
					local v64 = v_u_35
					local v65 = v62 + (v63 - v62) * v61
					local v66 = v65 + (v63 + (v64 - v63) * v61 - v65) * v61
					local v67 = (v66 - v58).Magnitude
					v60.CFrame = CFrame.new(v66, v58) * CFrame.new(0, 0, -v67 / 2)
					local v68 = v60.Size.X
					local v69 = v60.Size.Y
					local v70 = v67 * 1.25
					v60.Size = vector.create(v68, v69, v70)
					v58 = v66
				end
			end)
			local v79 = v_u_2.PreRender:Connect(function(p71)
				-- upvalues: (copy) v_u_34, (copy) p_u_30, (ref) v_u_53, (ref) v_u_54, (ref) v_u_49, (ref) v_u_31, (ref) v_u_40
				local v72 = CFrame.lookAt(v_u_34, p_u_30.Position)
				local _ = v72.LookVector
				local _ = v72.RightVector
				v_u_53 = (v72 * CFrame.new(10, 2.5, 10)).Position
				v_u_54 = (v72 * CFrame.new(10, 10, 0)).Position
				v_u_49 = v_u_49 + p71
				local v73 = v_u_49 / 0.2
				local v74 = math.min(v73, 1)
				local v75 = v_u_31
				local v76 = v_u_53
				local v77 = v_u_54
				local v78 = v75 + (v76 - v75) * v74
				v_u_31 = v78 + (v76 + (v77 - v76) * v74 - v78) * v74
				if v74 >= 1 then
					v_u_40:Disconnect()
					v_u_40 = nil
				end
			end)
			local v88 = v_u_2.PreRender:Connect(function(p80)
				-- upvalues: (copy) v_u_34, (copy) p_u_30, (ref) v_u_55, (ref) v_u_56, (ref) v_u_50, (ref) v_u_51, (ref) v_u_35, (ref) v_u_41
				local v81 = CFrame.lookAt(v_u_34, p_u_30.Position)
				local _ = v81.LookVector
				local _ = v81.RightVector
				v_u_55 = (v81 * CFrame.new(0, 10, -10)).Position
				v_u_56 = (v81 * CFrame.new(0, 2.5, 10)).Position
				v_u_50 = v_u_50 + p80
				local v82 = v_u_50 / v_u_51
				local v83 = math.min(v82, 1)
				local v84 = v_u_35
				local v85 = v_u_55
				local v86 = v_u_56
				local v87 = v84 + (v85 - v84) * v83
				v_u_35 = v87 + (v85 + (v86 - v85) * v83 - v87) * v83
				if v83 >= 1 then
					v_u_41:Disconnect()
					v_u_41 = nil
				end
			end)
			task.wait(0.2)
			v_u_11:PlaySound(v_u_8.Hanami.DefenseResponse.Startup, p28, game.SoundService.Effect)
			if v79 then
				v79:Disconnect()
			end
			if v88 then
				v88:Disconnect()
			end
			v_u_49 = 0
			v79 = v_u_2.PreRender:Connect(function(p89)
				-- upvalues: (copy) v_u_34, (copy) p_u_30, (ref) v_u_54, (ref) v_u_53, (ref) v_u_49, (ref) v_u_31
				local v90 = CFrame.lookAt(v_u_34, p_u_30.Position)
				local _ = v90.LookVector
				local v91 = v90.RightVector
				local v92 = p_u_30.Position
				v_u_53 = (v_u_54 + v92) / 2 + v91 * 2.5
				v_u_49 = v_u_49 + p89
				local v93 = v_u_49 / 0.2
				local v94 = math.min(v93, 1)
				local v95 = v_u_31
				local v96 = v_u_53
				local v97 = v95 + (v96 - v95) * v94
				v_u_31 = v97 + (v96 + (v92 - v96) * v94 - v97) * v94
			end)
			v_u_50 = 0
			v88 = v_u_2.PreRender:Connect(function(p98)
				-- upvalues: (ref) v_u_50, (ref) v_u_51, (copy) p_u_30, (copy) v_u_34, (ref) v_u_55, (ref) v_u_54, (ref) v_u_35
				v_u_50 = v_u_50 + p98
				local v99 = v_u_50 / v_u_51
				local v100 = math.min(v99, 1)
				local v101 = p_u_30.Position
				local v102 = CFrame.lookAt(v_u_34, p_u_30.Position)
				local _ = v102.LookVector
				local v103 = v102.RightVector
				v_u_55 = (v_u_54 + v101) / 2 + Vector3.new(0, 5, 0) + v103 * 10
				local v104 = v_u_35
				local v105 = v_u_55
				local v106 = v104 + (v105 - v104) * v100
				v_u_35 = v106 + (v105 + (v101 - v105) * v100 - v106) * v100
			end)
			task.wait(0.1)
			if v_u_57 and p_u_29.Grab.Value then
				v_u_51 = 0.13333333333333333
				local v_u_107 = p_u_29.Grab.Value
				local v108 = {}
				for v109 = 1, 2 do
					local v110 = Instance.new("Part")
					v110.Name = "StrangleRoot" .. v109
					v110.CanCollide = false
					v110.Anchored = false
					v110.Massless = true
					v110.Color = v32
					v110.Material = Enum.Material.Wood
					v110.Size = Vector3.new(1, 0.5, 1.5)
					v110.CFrame = v_u_107.HumanoidRootPart.CFrame * CFrame.new(0, 1, 0)
					if v109 == 2 then
						v110.CFrame = v110.CFrame * (CFrame.new(0, 0.25, 0) * CFrame.Angles(0, 0, 0.2617993877991494))
					end
					v_u_4:Create(v110, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["Size"] = Vector3.new(2.3, 0.6, 1.5)
					}):Play()
					v110.Parent = p_u_29.Parts
					local v111 = Instance.new("WeldConstraint")
					v111.Part0 = v_u_107.HumanoidRootPart
					v111.Part1 = v110
					v111.Parent = v110
					table.insert(v108, v110)
				end
				local v_u_112 = Instance.new("Part")
				v_u_112.Name = "WrappingRoot"
				v_u_112.CanCollide = false
				v_u_112.Anchored = true
				v_u_112.Color = v32
				v_u_112.Material = Enum.Material.Wood
				v_u_112.Size = Vector3.new(1, 7, 1)
				v_u_112.CFrame = CFrame.lookAt(v_u_107.HumanoidRootPart.CFrame * CFrame.new(0, 3, 3).Position, v_u_107.HumanoidRootPart.CFrame * CFrame.new(0, 2, 0).Position)
				v_u_112.Parent = p_u_29.Parts
				v_u_4:Create(v_u_112, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
					["Size"] = Vector3.new(0.5, 0, 0.5)
				}):Play()
				local v_u_113 = nil
				local v_u_114 = 0
				local v_u_115 = 0
				local _ = v_u_2.PreRender:Connect(function(p116)
					-- upvalues: (ref) v_u_113, (copy) v_u_112, (copy) v_u_107, (ref) v_u_114, (ref) v_u_115
					v_u_113 = v_u_112.Size.Y / 1.5
					local v117 = (v_u_107.HumanoidRootPart.CFrame * CFrame.new(0, v_u_107.HumanoidRootPart.Size.Y / 2, 0)).Position
					v_u_114 = v_u_114 - 40 * p116
					v_u_115 = v_u_115 + 20 * p116
					local v118 = v_u_114
					local v119 = math.cos(v118) * v_u_113
					local v120 = v_u_115
					local v121 = math.cos(v120) * 0.5
					local v122 = v_u_114
					local v123 = math.sin(v122) * v_u_113
					local v124 = v117 + vector.create(v119, v121, v123)
					local v125 = (v_u_107.HumanoidRootPart.CFrame * CFrame.new(0, 1, 0)).Position
					v_u_112.CFrame = CFrame.lookAt(v124, v125) * CFrame.Angles(0, 0, 0.7853981633974483) * CFrame.Angles(1.5707963267948966, 0, 0)
				end)
			end
		end,
		["LassoFail"] = function(p126, p127)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_6
			local v128 = p126:FindFirstChild("HumanoidRootPart")
			if v128 then
				v_u_11:PlaySound(v_u_8.Hanami.RootDisappear, v128, game.SoundService.Effect)
				local v129 = v_u_6.Utils.Hanami.ParticleDissipationHolder
				for _, v130 in p127.Parts:GetChildren() do
					for _, v131 in v129:GetChildren() do
						local v132 = v131:Clone()
						v132.Shape = Enum.ParticleEmitterShape.Box
						v132.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v130.Size.X * 2, 0), NumberSequenceKeypoint.new(1, v130.Size.X * 2, 0) })
						v132.Parent = v130
					end
					v_u_11:PlayParticles(v130)
					v130.Transparency = 1
				end
			end
		end,
		["GrappleHit"] = function(p133)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v134 = p133:FindFirstChild("HumanoidRootPart")
			if v134 then
				v_u_11:Flash(p133, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_8.Gojo.LapseBlue.Grab, v134, game.SoundService.Effect)
			end
		end
	}
	v_u_10.Effects:Connect(function(p136, ...)
		-- upvalues: (copy) v_u_135
		local v137 = v_u_135[p136]
		if v137 then
			v137(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("FlowerFieldService")
	v_u_11 = v_u_1.GetController("FXController")
	v_u_12 = v_u_1.GetController("ToolController")
end
return v13