-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Yuta.Base.ResoluteSlashController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("AssetService")
game:GetService("HttpService")
local v_u_3 = game:GetService("EncodingService")
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_4 = game:GetService("Debris")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game.Players.LocalPlayer
local v7 = game.ReplicatedStorage
local _ = v7.Animations
local v_u_8 = v7.Utils
local v_u_9 = v7.Sounds
local v_u_10 = require(v7.Modules.CameraShaker)
local v_u_11 = require(v7.Modules.StaticLightning)
local v_u_12 = require(v7.Modules.LightningBeams)
local v_u_13 = Random.new()
local v_u_14 = nil
local v_u_15 = nil
local v16 = v_u_1.CreateController({
	["Name"] = "ResoluteSlashController"
})
function decode(p17) -- name: decode
	-- upvalues: (copy) v_u_3
	return v_u_3:DecompressBuffer(p17, Enum.CompressionAlgorithm.Zstd)
end
function v16.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_8, (copy) v_u_4, (ref) v_u_14, (copy) v_u_9, (copy) v_u_6, (copy) v_u_10, (copy) v_u_5, (copy) v_u_13, (copy) v_u_12, (copy) v_u_2, (copy) v_u_11, (ref) v_u_15
	local v_u_18 = {}
	for v19, v20 in v_u_8.Yuta.ResoluteSlash.BlackFlashFlipbook:GetChildren() do
		v_u_18[v19] = decode(buffer.fromstring(v20:GetAttribute("Image")))
	end
	local v_u_21 = v_u_8.Yuta.ResoluteSlash.BlackFlashFlipbook:GetAttribute("Size")
	local v_u_22 = Random.new()
	v_u_8.Yuta.ResoluteSlash.BlackFlashFlipbook:Destroy()
	local v_u_146 = {
		["WarnAndTrack"] = function(p23, p24, p25, p26)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_14, (ref) v_u_9, (ref) v_u_6
			local v27 = p23:FindFirstChild("HumanoidRootPart")
			if v27 then
				local v28 = v_u_8.Itadori.CounterHit.Feint:Clone()
				for _, v29 in v28:GetChildren() do
					v29.Color = ColorSequence.new(Color3.fromRGB(255, 170, 255))
					v29.TimeScale = 0.7
				end
				v28.Parent = v27
				v28.Sparks:Emit(30)
				v28.Ring:Emit(6)
				v_u_4:AddItem(v28, 1)
				local v30 = p25:FindFirstChild("HumanoidRootPart")
				if v30 then
					if not p26 then
						v_u_14:PlaySound(v_u_9.Yuta.SwordGrab, v30, game.SoundService.Effect)
					end
					if p25 == v_u_6.Character then
						repeat
							task.wait()
							p24.CFrame = CFrame.new(v30.Position, v27.Position)
						until not p24.Parent
					end
				end
			else
				return
			end
		end,
		["Teleport"] = function(p31, p32)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4
			local v33 = p31:FindFirstChild("HumanoidRootPart")
			if v33 then
				v_u_14:PlaySound(v_u_9.Yuta.Leap, v33, game.SoundService.Effect)
				v_u_14:DustTrail(p31, 0.2, CFrame.Angles(0, -1.5707963267948966, 0))
				local v34 = v_u_8.Goku.Vanish
				local v35 = v34.Limb.Attachment
				local v36 = v34.Head.Attachment
				local v37 = v34.Torso.Attachment
				local v38 = v34.Limb2.Attachment
				local v39 = v34.Head2.Attachment
				local v40 = v34.Torso2.Attachment
				local function v46(p41, p_u_42, p_u_43) -- name: playParticles
					-- upvalues: (ref) v_u_4
					local v44 = p41:Clone()
					v44.Parent = p_u_43
					v44.Vanish:Emit(1)
					v_u_4:AddItem(v44, 0.3)
					task.delay(0.1, function()
						-- upvalues: (copy) p_u_42, (copy) p_u_43, (ref) v_u_4
						local v45 = p_u_42:Clone()
						v45.Parent = p_u_43
						v45.Vanish:Emit(1)
						v_u_4:AddItem(v45, 0.3)
					end)
				end
				v46(v37, v40, p31.Torso)
				v46(v36, v39, p31.Head)
				v46(v35, v38, p31["Right Arm"])
				v46(v35, v38, p31["Left Arm"])
				v46(v35, v38, p31["Right Leg"])
				v46(v35, v38, p31["Left Leg"])
				task.wait(0.15)
				if not p32 then
					local v47 = p31.SetAssets:FindFirstChild("YutaSword")
					if not v47 then
						return
					end
					local v48 = v47.Sword.Blade
					local v49 = v_u_8.Yuta.ResoluteSlash.SwordBurst2.SwordB2:Clone()
					v49.Parent = v48
					v_u_4:AddItem(v49, 1)
					for _, v_u_50 in v49:GetDescendants() do
						if not v_u_50:IsA("ParticleEmitter") then
							continue
						end
						task.delay(v_u_50:GetAttribute("EmitDelay"), function()
							-- upvalues: (copy) v_u_50
							v_u_50:Emit(v_u_50:GetAttribute("EmitCount"))
						end)
					end
					task.wait(0.1)
					local v51 = v_u_8.Yuta.ResoluteSlash.SwordBurst.Center:Clone()
					v51.Parent = v48
					v_u_4:AddItem(v51, 0.2)
					v51.Glow:Emit(1)
				end
			end
		end,
		["ChargeEffect"] = function(p52)
			-- upvalues: (ref) v_u_8, (ref) v_u_4
			local v53 = p52.SetAssets:FindFirstChild("YutaSword")
			if v53 then
				local v54 = v53.Sword.Blade
				local v55 = v_u_8.Yuta.ResoluteSlash.SwordBurst.Attachment0:Clone()
				local v56 = v_u_8.Yuta.ResoluteSlash.SwordBurst.Center:Clone()
				v55.Parent = v54
				v56.Parent = v54
				v_u_4:AddItem(v55, 0.5)
				v_u_4:AddItem(v56, 4)
				v55.Burst1:Emit(1)
				v56.Burst2:Emit(1)
				task.wait(0.2)
				v56:Destroy()
				local v57 = v_u_8.Yuta.ResoluteSlash.SwordBurst.Sparks:Clone()
				v57.Parent = v54
				v_u_4:AddItem(v57, 0.7)
				v57:Emit(30)
			end
		end,
		["Confused"] = function(p58)
			-- upvalues: (ref) v_u_8, (ref) v_u_4
			local v59 = p58:FindFirstChild("Head")
			if v59 then
				local v60 = v_u_8.Yuta.ResoluteSlash.Confused.Attachment:Clone()
				v60.Parent = v59
				v60.Question:Emit(1)
				v_u_4:AddItem(v60, 1)
			end
		end,
		["Swing"] = function(p61)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4
			local v62 = p61:FindFirstChild("HumanoidRootPart")
			if v62 then
				if p61.SetAssets:FindFirstChild("YutaSword") then
					v_u_14:PlaySound(v_u_9.Yuta.Swing, v62, game.SoundService.Effect)
					local v63 = v_u_8.Yuta.ResoluteSlash.RingSwing.Attachment:Clone()
					v63.Parent = v62
					v63.Ring:Emit(8)
					v_u_4:AddItem(v63, 0.6)
				end
			else
				return
			end
		end,
		["Swing2"] = function(p64)
			-- upvalues: (ref) v_u_8, (ref) v_u_4
			local v65 = p64:FindFirstChild("HumanoidRootPart")
			if v65 then
				local v66 = v_u_8.Yuta.ResoluteSlash.RingSwing.Attachment:Clone()
				v66.Parent = v65
				v66.Ring:Emit(8)
				v_u_4:AddItem(v66, 0.6)
			end
		end,
		["Slash"] = function(p67, p68)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_14, (ref) v_u_9
			local v69 = v_u_8.Yuta.ResoluteSlash.SlashHit.Attachment:Clone()
			v69.Parent = p68.Head
			v69.WorldCFrame = CFrame.lookAlong(v69.WorldPosition, p67)
			v69.Slash:Emit(2)
			v_u_4:AddItem(v69, 0.5)
			v_u_14:PlaySound(v_u_9.Yuta.ResoluteSlash, p68.Head, game.SoundService.Effect)
		end,
		["Hit"] = function(p70, p71)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			v_u_14:Flash(p70, Color3.fromRGB(255, 170, 255))
			if p71 then
				v_u_14:PlaySound(v_u_9.Yuta.ResoluteHit, p70.Head, game.SoundService.Effect)
			end
		end,
		["BlackFlashWindup"] = function(p72, p_u_73, p74)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_6, (ref) v_u_8, (ref) v_u_10, (ref) v_u_5, (ref) v_u_4, (ref) v_u_13, (ref) v_u_12, (ref) v_u_2, (copy) v_u_21, (copy) v_u_18, (copy) v_u_22
			local v75 = p72:FindFirstChild("HumanoidRootPart")
			if v75 then
				local v76 = p72["Left Arm"].LeftGripAttachment
				if v76 then
					if p74 then
						v_u_14:PlaySound(v_u_9.Yuta.BlackFlash.Windup, v75, game.SoundService.Music)
						if v_u_6.Character == p72 or v_u_6.Character == p_u_73 then
							local v_u_77 = v_u_8.Itadori.DivergentFist.BlackFlashCC:Clone()
							v_u_77.Parent = game.Lighting
							v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
							v_u_5:Create(v_u_77, TweenInfo.new(1.1, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
								["TintColor"] = nil,
								["Brightness"] = 2,
								["TintColor"] = Color3.new(1, 1, 1)
							}):Play()
							v_u_5:Create(workspace.CurrentCamera, TweenInfo.new(0.8, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
								["FieldOfView"] = 40
							}):Play()
							task.delay(1.1, function()
								-- upvalues: (copy) v_u_77, (ref) v_u_5
								v_u_77:Destroy()
								v_u_5:Create(workspace.CurrentCamera, TweenInfo.new(0.8, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
									["FieldOfView"] = 70
								}):Play()
								game.Lighting.ExposureCompensation = 2
								v_u_5:Create(game.Lighting, TweenInfo.new(1), {
									["ExposureCompensation"] = 0
								}):Play()
							end)
						end
						task.spawn(function()
							-- upvalues: (copy) p_u_73, (ref) v_u_4, (ref) v_u_13, (ref) v_u_12
							local v78 = p_u_73:FindFirstChild("HumanoidRootPart")
							if v78 then
								local v79 = p_u_73.Head.FaceFrontAttachment
								local v80 = Instance.new("Model", workspace.Effects)
								local v81 = Instance.new("Highlight", v80)
								v81.DepthMode = Enum.HighlightDepthMode.Occluded
								v81.OutlineColor = Color3.new(1, 0, 0)
								v81.FillColor = Color3.new(0, 0, 0)
								v81.FillTransparency = 0
								v_u_4:AddItem(v80, 1.1)
								for _ = 1, 10 do
									local v_u_82 = Instance.new("Attachment", v78)
									v_u_82.Position = v_u_13:NextUnitVector() * 40
									local v_u_83 = v_u_12.new(v79, v_u_82, nil, v80)
									v_u_83.Color = Color3.new(1, 0, 0)
									v_u_83.PulseSpeed = 100
									v_u_83.MaxRadius = 16
									v_u_83.MinRadius = 0
									v_u_83.AnimationSpeed = 10
									v_u_83.MinThicknessMultiplier = 0.1
									v_u_83.MaxThicknessMultiplier = 2
									task.delay(0.1, function()
										-- upvalues: (copy) v_u_83, (copy) v_u_82
										v_u_83.AnimationSpeed = 5
										task.wait(0.1)
										v_u_83.AnimationSpeed = 2.5
										task.wait(0.1)
										v_u_83.AnimationSpeed = 1
										task.wait(0.1)
										v_u_83.AnimationSpeed = 0.5
										task.wait(0.2)
										v_u_83.AnimationSpeed = 0.1
										task.wait(0.1)
										v_u_83:Destroy()
										v_u_82:Destroy()
									end)
								end
							end
						end)
					end
					v_u_14:PlaySound(v_u_9.Yuta.BlackFlash.Windup2, v75, game.SoundService.Effect)
					local v84 = v_u_8.Yuta.ResoluteSlash.BlackFlashWindup:Clone()
					local v85 = v84.BB.Frame
					v84.Parent = workspace.Effects
					local v86 = v_u_2:CreateEditableImage({
						["Size"] = v_u_21
					})
					v85.ImageContent = Content.fromObject(v86)
					local v87 = 0.3 / #v_u_18
					local v88 = #v_u_18 * 1.8
					local v89 = 0
					for _ = 1, 2 do
						for _, v90 in v_u_18 do
							local v91 = v75.Position + v_u_22:NextUnitVector() * 4
							local v92 = v76.WorldPosition
							local v93 = v89 / v88
							v84.Position = v91:Lerp(v92, (math.clamp(v93, 0, 1)))
							v89 = v89 + 1
							v86:WritePixelsBuffer(Vector2.zero, v86.Size, v90)
							task.wait(v87)
						end
					end
					v84:Destroy()
				end
			else
				return
			end
		end,
		["BlackFlash"] = function(p_u_94, p_u_95, p_u_96)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_5, (ref) v_u_8, (ref) v_u_4, (ref) v_u_13, (ref) v_u_12, (ref) v_u_6, (ref) v_u_10
			local v97 = p_u_94:FindFirstChild("HumanoidRootPart")
			if v97 then
				local v_u_98 = p_u_95:FindFirstChild("HumanoidRootPart")
				if v_u_98 then
					v_u_14:PlaySound(v_u_9.Yuta.BlackFlash.Land2, v97, game.SoundService.Effect)
					local v_u_99 = v_u_14:PlaySound(v_u_9.Yuta.BlackFlash.Land, v97, game.SoundService.Music)
					task.delay(5, function()
						-- upvalues: (ref) v_u_5, (copy) v_u_99
						v_u_5:Create(v_u_99, TweenInfo.new(3), {
							["Volume"] = 0
						}):Play()
					end)
					local v_u_100 = p_u_95.Head.FaceFrontAttachment
					local v_u_101 = v_u_8.Itadori.DivergentFist.BlackFlashHit:Clone()
					v_u_101.Position = v_u_98.Position
					v_u_101.Parent = workspace.Effects
					v_u_4:AddItem(v_u_101, 1)
					v_u_101.Wind2:Emit(8)
					v_u_5:Create(v_u_101.PointLight, TweenInfo.new(1), {
						["Brightness"] = 0
					}):Play()
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_101
						v_u_101.Blast:Emit(8)
						v_u_101.Sparks:Emit(15)
						v_u_101.Lightning:Emit(6)
						v_u_101.Wind:Emit(7)
					end)
					v_u_14:Flash(p_u_95, Color3.new(1, 0, 0))
					v_u_14:PlaySound(v_u_9.Itadori.DivergentFist.BlackFlashHit, v_u_98, game.SoundService.Effect)
					task.spawn(function()
						-- upvalues: (copy) v_u_98, (ref) v_u_13, (ref) v_u_12, (copy) v_u_100, (copy) p_u_96, (copy) p_u_95, (copy) p_u_94
						local v102 = Instance.new("Model", workspace.Effects)
						local v103 = Instance.new("Highlight", v102)
						v103.DepthMode = Enum.HighlightDepthMode.Occluded
						v103.OutlineColor = Color3.new(1, 0, 0)
						v103.FillColor = Color3.new(0, 0, 0)
						v103.FillTransparency = 0
						repeat
							local v_u_104 = Instance.new("Attachment", v_u_98)
							v_u_104.Position = v_u_13:NextUnitVector() * 30
							local v_u_105 = v_u_12.new(v_u_100, v_u_104, nil, v102)
							v_u_105.Color = Color3.new(1, 0, 0)
							v_u_105.PulseSpeed = 300
							v_u_105.FadeLength = 0.35
							v_u_105.MaxRadius = 20
							v_u_105.MinRadius = 0
							v_u_105.AnimationSpeed = _G.Settings.Flash == true and 75 or 5
							v_u_105.MinThicknessMultiplier = 0.1
							v_u_105.MaxThicknessMultiplier = 3
							task.delay(0.1, function()
								-- upvalues: (copy) v_u_105, (copy) v_u_104
								v_u_105:Destroy()
								v_u_104:Destroy()
							end)
							task.wait(0.02)
						until not (p_u_96.Parent and (p_u_95.Parent and p_u_94.Parent))
						v102:Destroy()
					end)
					if v_u_6.Character == p_u_94 or v_u_6.Character == p_u_95 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
						if _G.Settings.Flash ~= true then
							return
						end
						local v106 = v_u_8.Itadori.DivergentFist.BlackFlashCC:Clone()
						v106.Parent = game.Lighting
						task.wait(0.04)
						v106.TintColor = Color3.new(1, 1, 1)
						task.wait(0.04)
						v106.Brightness = 200
						v106.Contrast = -1000
						task.wait(0.04)
						v106:Destroy()
						local v107 = v_u_10.CurrentShaker:ShakeSustain(v_u_10.Presets.HeavyHit)
						repeat
							task.wait()
						until not (p_u_96.Parent and (p_u_95.Parent and p_u_94.Parent))
						v107:StartFadeOut(0.5)
					end
				end
			else
				return
			end
		end,
		["BlackFlashTrail"] = function(p108, p109)
			-- upvalues: (ref) v_u_8, (ref) v_u_11, (ref) v_u_5
			local v110 = Random.new()
			local v111 = v_u_8.Yuta.ResoluteSlash.Disk
			local v112 = Instance.new("Model", workspace.Effects)
			local v113 = Instance.new("Highlight")
			v113.FillColor = Color3.new()
			v113.OutlineTransparency = 1
			v113.FillTransparency = 0
			v113.DepthMode = Enum.HighlightDepthMode.Occluded
			v113.Parent = v112
			local v114 = workspace:Raycast(p108.Position, p108.LookVector * 100, _G.MapParams)
			local v115 = (not v114 and (p109 or 100) or v114.Distance) / 20
			if v115 >= 1 then
				local v116 = v_u_11.ThicknessFade(0.5, 1.2)
				local v117 = {}
				for v118 = 1, v115 do
					local v119 = (p108 * CFrame.new(0, 0, v118 * -20 + 5)).Position
					for _ = 1, 5 do
						local v120 = 20
						local v121 = v110:NextUnitVector()
						local v122 = workspace:Raycast(v119, v121 * v120, _G.MapParams)
						if v122 then
							v120 = v122.Distance
						end
						local v123 = v_u_11.CreateBolt
						local v124 = {
							["Position1"] = v119,
							["Position2"] = v119 + v121 * v120
						}
						local v125 = v120 / 6
						v124.PartCount = math.floor(v125)
						v124.Thickness = v116
						v124.Color = Color3.new(1, 0, 0)
						v124.Parent = v112
						local v_u_126 = v123(v124)
						if v122 then
							local v127 = v110:NextNumber(2, 4)
							local v128 = v111:Clone()
							v128.CFrame = CFrame.lookAlong(v122.Position, v122.Normal) * CFrame.Angles(0, 1.5707963267948966, 0)
							v128.Size = v128.Size * Vector3.new(1, v127, v127)
							v128.Parent = v112
							table.insert(v_u_126, v128)
						end
						table.insert(v117, v_u_126)
						for _, v129 in v_u_126 do
							v129.Transparency = 1
						end
						task.spawn(function()
							-- upvalues: (copy) v_u_126, (ref) v_u_5
							for _, v130 in v_u_126 do
								task.wait(0.02)
								v130.Transparency = 0
								v_u_5:Create(v130, TweenInfo.new(0.2), {
									["Size"] = v130.Size * Vector3.new(0.5, 0.5, 1)
								}):Play()
							end
							task.wait(0.1)
							for _, v131 in v_u_126 do
								v131:Destroy()
								task.wait(0.02)
							end
						end)
					end
					task.wait(0.1)
				end
				task.wait(0.3)
				v112:Destroy()
			end
		end,
		["SmallThrow"] = function(p132, p133)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_14, (ref) v_u_9, (ref) v_u_6, (ref) v_u_10
			local v134 = p133:FindFirstChild("HumanoidRootPart")
			if v134 then
				local _ = p133.Head.FaceFrontAttachment
				local v_u_135 = v_u_8.Itadori.DivergentFist.BlackFlashHit:Clone()
				v_u_135.Position = v134.Position
				v_u_135.Parent = workspace.Effects
				v_u_4:AddItem(v_u_135, 1)
				v_u_135.Wind2:Emit(8)
				v_u_5:Create(v_u_135.PointLight, TweenInfo.new(1), {
					["Brightness"] = 0
				}):Play()
				task.delay(0.1, function()
					-- upvalues: (copy) v_u_135
					v_u_135.Blast:Emit(8)
					v_u_135.Sparks:Emit(15)
					v_u_135.Lightning:Emit(6)
					v_u_135.Wind:Emit(7)
				end)
				v_u_14:Flash(p133, Color3.new(1, 0, 0))
				v_u_14:PlaySound(v_u_9.Itadori.DivergentFist.BlackFlashHit, v134, game.SoundService.Effect)
				if v_u_6.Character == p132 or v_u_6.Character == p133 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
					if _G.Settings.Flash ~= true then
						return
					end
					local v136 = v_u_8.Itadori.DivergentFist.BlackFlashCC:Clone()
					v136.Parent = game.Lighting
					task.wait(0.04)
					v136.TintColor = Color3.new(1, 1, 1)
					task.wait(0.04)
					v136.Brightness = 200
					v136.Contrast = -1000
					task.wait(0.04)
					v136:Destroy()
				end
				task.wait(0.4)
				for _, v137 in p133:GetChildren() do
					if not v137:IsA("BasePart") then
						continue
					end
					local v138 = v_u_8.Itadori.DivergentFist.FlashBurn:Clone()
					v138.Parent = v137
					v_u_4:AddItem(v138, 0.5)
				end
			end
		end,
		["FinalThrow"] = function(p139, p140, p141)
			-- upvalues: (ref) v_u_8, (ref) v_u_5, (ref) v_u_4, (ref) v_u_6, (ref) v_u_14, (ref) v_u_10
			local v142 = p139:FindFirstChild("HumanoidRootPart")
			if v142 then
				local v143 = p140.Position
				local _ = p140.LookVector
				local v144 = v_u_8.Itadori.DivergentFist.BlackFlashLaunch:Clone()
				v144.CFrame = v142.CFrame * CFrame.new(2, 1, -5)
				v144.Parent = workspace.Effects
				v144.Wind:Emit(20)
				v144.Sparks:Emit(20)
				v144.Flare:Emit(20)
				v144.Back1.Back:Emit(1)
				v144.Back2.Back:Emit(1)
				v_u_5:Create(v144.Back1, TweenInfo.new(2), {
					["CFrame"] = v144.Back1.CFrame - v144.Back1.CFrame.LookVector * 20
				}):Play()
				v_u_5:Create(v144.Back2, TweenInfo.new(2), {
					["CFrame"] = v144.Back2.CFrame - v144.Back2.CFrame.LookVector * 20
				}):Play()
				v_u_5:Create(v144.PointLight, TweenInfo.new(1), {
					["Brightness"] = 0
				}):Play()
				v_u_4:AddItem(v144, 3)
				if (v_u_6.Character == p139 or v_u_6.Character == p141) and _G.Settings.Flash == true then
					local v145 = v_u_8.Itadori.DivergentFist.BlackFlashCC:Clone()
					v145.Parent = game.Lighting
					task.wait(0.04)
					v145.TintColor = Color3.new(1, 1, 1)
					task.wait(0.04)
					v145.Brightness = 200
					v145.Contrast = -1000
					task.wait(0.04)
					v145:Destroy()
				end
				v_u_14:Flash(p139, Color3.new(1, 0, 0))
				v_u_14:Bleed(p141)
				if (workspace.CurrentCamera.CFrame.Position - v143).Magnitude <= 80 then
					v_u_10.CurrentShaker:ShakeSustain(v_u_10.Presets.Snap):StartFadeOut(1)
				end
			end
		end
	}
	v_u_15.Effects:Connect(function(p147, ...)
		-- upvalues: (copy) v_u_146
		local v148 = v_u_146[p147]
		if v148 then
			v148(...)
		end
	end)
end
function v16.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_15, (copy) v_u_1, (ref) v_u_14
	v_u_15 = v_u_1.GetService("ResoluteSlashService")
	v_u_14 = v_u_1.GetController("FXController")
end
return v16