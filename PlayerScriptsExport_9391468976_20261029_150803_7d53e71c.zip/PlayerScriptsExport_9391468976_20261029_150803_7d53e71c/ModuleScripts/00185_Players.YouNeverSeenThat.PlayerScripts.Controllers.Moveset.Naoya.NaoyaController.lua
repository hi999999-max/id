-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Naoya.NaoyaController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "NaoyaController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2, (ref) v_u_10
	local v_u_177 = {
		["Hit"] = function(p14, p15)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v16 = p14:FindFirstChild("HumanoidRootPart")
			if v16 then
				if not (p14:FindFirstChild("Info") and p14.Info:FindFirstChild("NaoyaFrame")) then
					v_u_12:Flash(p14, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit" .. p15), v16, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Chase"] = function(p17)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8
			local v18 = p17.HumanoidRootPart
			if v18 then
				local v19 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v19.CFrame = v18.CFrame * CFrame.new(0, 1, -4)
				v19.Size = Vector3.new(0, 0, 2)
				v19.Parent = workspace.Effects
				v_u_4:Create(v19, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v19, 0.3)
				v_u_12:PlaySound(v_u_8.Misc.Chase, v18, game.SoundService.Effect)
				v_u_12:DustTrail(p17, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p20, _)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v21 = p20:FindFirstChild("HumanoidRootPart")
			if v21 then
				v_u_12:PlaySound(v_u_8.Misc.Swing.Fist, v21, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p22, p23, _, p24)
			-- upvalues: (ref) v_u_12
			if p23 == 1 or p23 == 2 then
				v_u_12:ArmFlash(p22["Left Arm"], Color3.fromRGB(128, 126, 255), 0.4)
				return
			elseif p23 == 3 or p24 then
				v_u_12:ArmFlash(p22["Right Arm"], Color3.fromRGB(128, 126, 255), 0.4)
			else
				v_u_12:ArmFlash(p22["Right Leg"], Color3.fromRGB(128, 126, 255), 0.4)
			end
		end,
		["Swing3"] = function(p25, p26, p27)
			-- upvalues: (ref) v_u_12
			if p26 == 1 or p26 == 3 then
				v_u_12:ArmFlash(p25["Right Arm"], Color3.fromRGB(128, 126, 255), 0.4)
				return
			elseif p26 == 2 or p27 == "Up" then
				v_u_12:ArmFlash(p25["Left Arm"], Color3.fromRGB(128, 126, 255), 0.4)
			else
				v_u_12:ArmFlash(p25["Left Arm"], Color3.fromRGB(128, 126, 255), 0.4)
				v_u_12:ArmFlash(p25["Right Arm"], Color3.fromRGB(128, 126, 255), 0.4)
			end
		end,
		["Launch"] = function(p28, p29)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v30 = p28:FindFirstChild("HumanoidRootPart")
			if v30 then
				local v31 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v31.CFrame = CFrame.new(v30.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v31.Size = Vector3.new(0, 0, 5)
				v31.Parent = workspace.Effects
				v_u_4:Create(v31, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v31.Position + Vector3.new(0, p29, 0)
				}):Play()
				v_u_3:AddItem(v31, 0.3)
				if p29 < 0 then
					v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v30, game.SoundService.Effect)
					v_u_12:DustBreak(v30.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v30.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			end
		end,
		["Frame"] = function(p_u_32, p_u_33)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9
			local v_u_34 = p_u_32:FindFirstChild("HumanoidRootPart")
			if v_u_34 then
				local v35 = v_u_34:FindFirstChild("ChargeMeter")
				if v35 then
					v35:Destroy()
				end
				local v_u_36 = v_u_7.Naoya.NaoyaGlass:Clone()
				if p_u_32:GetScale() ~= 1 then
					v_u_36.Size = v_u_36.Size * p_u_32:GetScale()
					local v37 = v_u_36.Part
					v37.Size = v37.Size * p_u_32:GetScale()
				end
				v_u_36.CFrame = p_u_32.Torso.CFrame
				v_u_36.Parent = workspace.Effects
				v_u_36.Front.Transparency = 1
				v_u_36.Back.Transparency = 1
				v_u_3:AddItem(v_u_36, 4)
				local v_u_38 = {}
				task.spawn(function()
					-- upvalues: (ref) v_u_7, (copy) v_u_38, (ref) v_u_5, (copy) v_u_36, (copy) p_u_32
					for v39 = 1, 2 do
						local v40 = v_u_7.Naoya.NaoyaGlassUI:Clone()
						local v41 = v_u_38
						table.insert(v41, v40)
						v40.Parent = v_u_5.PlayerGui
						v40.Adornee = v_u_36
						local v42 = p_u_32:Clone()
						for _, v43 in pairs(v42:GetDescendants()) do
							if not v43:IsA("LocalScript") and (not v43:IsA("Script") and (v43.Name ~= "Stunna" and v43.Name ~= "ChargeMeter")) then
								continue
							end
							v43:Destroy()
						end
						for _, v44 in pairs(p_u_32:GetDescendants()) do
							if not v44:IsA("Motor6D") then
								continue
							end
							local v45 = v42:FindFirstChild(v44.Name, true)
							if not (v45 and v45:IsA("Motor6D")) then
								continue
							end
							v45.C0 = v44.C0
							v45.C1 = v44.C1
							v45.Transform = v44.Transform
						end
						v42.Parent = v40.ViewportFrame.WorldModel
						v42:PivotTo(CFrame.new())
						if v39 == 2 then
							v40.Face = Enum.NormalId.Back
						end
						local v46 = Instance.new("Camera", v40.ViewportFrame)
						local v47 = CFrame.new(0, 0, (v39 == 2 and 400 or -400) * p_u_32:GetScale())
						local v48 = CFrame.Angles
						local v49 = v39 == 2 and 0 or 180
						v46.CFrame = v47 * v48(0, math.rad(v49), 0)
						v46.FieldOfView = 1
						v40.ViewportFrame.CurrentCamera = v46
					end
				end)
				local v_u_50 = {}
				for _, v51 in p_u_32:GetDescendants() do
					if not (v51:IsA("BasePart") or v51:IsA("Decal")) or v51.Transparency == 1 then
						continue
					end
					local v52 = v51.Transparency
					v51.Transparency = 1
					v_u_50[v51] = v52
				end
				v_u_36.Transparency = 0
				v_u_4:Create(v_u_36, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
					["Transparency"] = 0.5
				}):Play()
				v_u_12:PlaySound(v_u_8.Naoya.Frame, v_u_34, game.SoundService.Effect)
				task.delay(0.5, function()
					-- upvalues: (copy) v_u_36, (ref) v_u_4
					if v_u_36.Transparency ~= 1 then
						v_u_4:Create(v_u_36, TweenInfo.new(2.45, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
							["Transparency"] = 0
						}):Play()
					end
				end)
				task.spawn(function()
					-- upvalues: (copy) v_u_36, (copy) p_u_32, (copy) v_u_34, (copy) p_u_33, (copy) v_u_50, (copy) v_u_38, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9, (ref) v_u_7, (ref) v_u_3
					repeat
						v_u_36.CFrame = p_u_32.Torso.CFrame
						task.wait()
					until not (p_u_32.Parent and (v_u_34.Parent and p_u_33:IsDescendantOf(workspace.Characters)))
					for v53, v54 in v_u_50 do
						if not v53.Parent then
							continue
						end
						v53.Transparency = v54
					end
					for _, v55 in v_u_38 do
						v55:Destroy()
					end
					v_u_4:Create(v_u_36, TweenInfo.new(0), {
						["Transparency"] = 1
					}):Play()
					v_u_36.Part.Transparency = 1
					v_u_36.Front.Transparency = 1
					v_u_36.Back.Transparency = 1
					v_u_36.Attachment.Flash:Emit(3)
					v_u_36.Attachment.Wind:Emit(5)
					v_u_36.Attachment.WindCircle:Emit(5)
					v_u_36.Attachment.Shockwave:Emit(4)
					v_u_36.Shatter:Emit(40)
					v_u_12:PlaySound(v_u_8.Naoya.FrameBreak, v_u_34, game.SoundService.Effect)
					if (workspace.CurrentCamera.CFrame.Position - v_u_36.Position).Magnitude < 40 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
					end
					if _G.Settings.DesPHY then
						if (workspace.CurrentCamera.CFrame.Position - v_u_36.Position).Magnitude > 100 then
							return
						end
						task.wait(0.1)
						local v56 = Random.new()
						local v57 = TweenInfo.new(3, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
						for _ = 1, 20 do
							local v58 = v_u_7.Gojo.Shard:Clone()
							local v59 = v56:NextUnitVector().Unit
							local v60 = math.random(5, 20) / 10
							local v61 = math.random(5, 20) / 10
							v58.Size = Vector3.new(0.2, v60, v61)
							v58.CFrame = v_u_36.CFrame * CFrame.new(math.random(-2, 2), math.random(-4, 4), 0)
							v58.CFrame = v58.CFrame * CFrame.Angles(0, math.random(0, 3.141592653589793), 0)
							v58.CanCollide = true
							v58.CollisionGroup = "Effects"
							v58.Parent = workspace.Effects
							v58.Transparency = 0.5
							v58.Color = v_u_36.Color
							v58.Material = Enum.Material.Neon
							local v62 = math.random(-50, 50)
							local v63 = math.random(-50, 50)
							local v64 = math.random
							v58.RotVelocity = Vector3.new(v62, v63, v64(-50, 50))
							v58.Velocity = v59 * math.random(30, 60) + v_u_34.Velocity
							v_u_4:Create(v58, v57, {
								["Size"] = Vector3.new(0, 0, 0)
							}):Play()
							v_u_3:AddItem(v58, 3)
						end
					end
				end)
			end
		end,
		["Zwoosh"] = function(p65, _, p66)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v67 = p65:FindFirstChild("HumanoidRootPart")
			if v67 then
				local v68 = p66 or Color3.fromRGB(128, 126, 255)
				local v69 = TweenInfo.new(1.2)
				v_u_12:PlaySound(v_u_8.Naoya.Decisive.Startup, v67, game.SoundService.Effect)
				local v70 = v_u_7.Damage.HitGlow:Clone()
				v_u_3:AddItem(v70, 1.2)
				v70.Parent = workspace.Effects
				for _, v71 in v70:GetChildren() do
					v71.Color = v68
					v71.Anchored = true
					v71.CFrame = p65[v71.Name].CFrame
					v_u_4:Create(v71, v69, {
						["Transparency"] = 1,
						["Position"] = nil,
						["Position"] = v71.Position
					}):Play()
				end
				local v72 = v_u_7.Naoya.Teleport:Clone()
				v72.CFrame = v67.CFrame
				v72.Parent = workspace.Effects
				v72.Lines.Color = ColorSequence.new(v68)
				v72.Lines:Emit(8)
				v72.Floor.Dust:Emit(30)
				v_u_3:AddItem(v72, 1)
				local v73 = {}
				for _, v74 in p65:GetDescendants() do
					if not (v74:IsA("BasePart") or v74:IsA("Decal")) or v74.Transparency == 1 then
						continue
					end
					local v75 = v74.Transparency
					v74.Transparency = 1
					v73[v74] = v75
				end
				task.wait(0.25)
				v_u_12:PlaySound(v_u_8.Naoya.Decisive.Flicker2, v67, game.SoundService.Effect)
				for v76, v77 in v73 do
					if not v76.Parent then
						continue
					end
					v76.Transparency = v77
				end
				local v78 = v_u_7.Naoya.Teleport:Clone()
				v78.CFrame = v67.CFrame
				v78.Parent = workspace.Effects
				v78.Lines.Color = ColorSequence.new(v68)
				v78.Lines:Emit(8)
				v78.Floor.Dust:Emit(30)
				v_u_3:AddItem(v78, 1)
			end
		end,
		["Trail"] = function(p79, p80, p81)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v82 = p79:FindFirstChild("HumanoidRootPart")
			if v82 then
				local v83 = TweenInfo.new(1.2)
				local v84 = (p81 - p80).Unit
				local v85 = (p80 - p81).Magnitude / 4
				for v86 = 0, math.floor(v85) do
					local v87 = v_u_7.Damage.HitGlow:Clone()
					v_u_3:AddItem(v87, 1.2)
					v87.Parent = workspace.Effects
					for _, v88 in v87:GetChildren() do
						v88.Color = Color3.fromRGB(128, 126, 255)
						v88.Anchored = true
						v88.CFrame = p79[v88.Name].CFrame - v82.Position + p80 + v84 * v86 * 4
						v_u_4:Create(v88, v83, {
							["Transparency"] = 1
						}):Play()
					end
				end
				local v89 = TweenInfo.new(0.2)
				for _ = 1, 10 do
					local v90 = v_u_7.Damage.HitGlow:Clone()
					v_u_3:AddItem(v90, 0.2)
					v90.Parent = workspace.Effects
					for _, v91 in v90:GetChildren() do
						v91.Color = Color3.fromRGB(128, 126, 255)
						v91.Anchored = true
						v91.CFrame = p79[v91.Name].CFrame
						v_u_4:Create(v91, v89, {
							["Transparency"] = 1
						}):Play()
					end
					task.wait(0.04)
				end
			end
		end,
		["Blink"] = function(p92, p93)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_3
			v_u_12:DomainMapFade(Color3.new(0, 0, 0), 0.2, 0.3)
			local v94 = p92:FindFirstChild("HumanoidRootPart")
			if v94 then
				local v95 = v94.Position
				TweenInfo.new(1.2)
				local v96 = (p93 - v95).Unit
				local v97 = (v95 - p93).Magnitude / 4
				for v98 = 0, math.floor(v97) do
					local v99 = v_u_7.Damage.HitGlow:Clone()
					v_u_3:AddItem(v99, 0.25)
					v99.Parent = workspace.Effects
					for _, v100 in v99:GetChildren() do
						v100.Color = Color3.fromRGB(128, 126, 255)
						v100.Anchored = true
						v100.Transparency = 0
						v100.CFrame = p92[v100.Name].CFrame - v94.Position + v95 + v96 * v98 * 4
					end
					task.wait(0.02)
				end
			end
		end,
		["Parry"] = function(p101, p102)
			-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v103 = p101:FindFirstChild("HumanoidRootPart")
			if v103 then
				if v_u_5.Character == p102 or v_u_5.Character == p101 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
					v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(1)
				end
				local v104 = v103:FindFirstChild("Startup")
				if v104 and v104:IsA("Sound") then
					v_u_4:Create(v104, TweenInfo.new(0.2), {
						["Volume"] = 0
					}):Play()
				end
				v_u_12:PlaySound(v_u_8.Naoya.Ultimate.Parry, v103, game.SoundService.Effect)
				local v105 = v_u_7.Misc.C.M1.Hit1:Clone()
				v105.Parent = p101["Right Arm"]
				v105.Position = Vector3.new(0, -1, 0)
				for _, v106 in v105:GetDescendants() do
					if not v106:IsA("ParticleEmitter") then
						continue
					end
					v106:Emit(v106:GetAttribute("EmitCount"))
					v106.LockedToPart = true
				end
				v_u_3:AddItem(v105, 0.5)
				for _ = 1, 7 do
					local v107 = v_u_7.Damage.HitGlow:Clone()
					v_u_3:AddItem(v107, 0.5)
					v107.Parent = workspace.Effects
					local v108 = TweenInfo.new(0.5)
					for _, v109 in v107:GetChildren() do
						v109.Color = Color3.fromRGB(128, 126, 255)
						v109.Transparency = 0.5
						v109.Anchored = true
						v109.CFrame = p101[v109.Name].CFrame
						v_u_4:Create(v109, v108, {
							["Transparency"] = 1
						}):Play()
					end
					task.wait(0.02)
				end
			end
		end,
		["Lost"] = function(p110, p111, p112)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9
			local v113 = p110:FindFirstChild("HumanoidRootPart")
			if v113 then
				if p112 then
					task.wait(0.45)
					v_u_12:PlaySound(v_u_8.Naoya.Ultimate.Fall, v113, game.SoundService.Effect)
					task.wait(0.4)
					local v114 = v_u_7.Naoya.Fall:Clone()
					v114:PivotTo(v113.CFrame)
					v114.Parent = workspace.Effects
					v_u_3:AddItem(v114, 1.5)
					v_u_4:Create(v114.Mesh.Start, TweenInfo.new(0.7, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
						["Size"] = nil,
						["Transparency"] = 1,
						["CFrame"] = nil,
						["Size"] = v114.Mesh.End.Size,
						["CFrame"] = v114.Mesh.End.CFrame
					}):Play()
					v_u_4:Create(v114.Mesh2.Start, TweenInfo.new(1, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
						["Size"] = nil,
						["Transparency"] = 1,
						["CFrame"] = nil,
						["Size"] = v114.Mesh2.End.Size,
						["CFrame"] = v114.Mesh2.End.CFrame
					}):Play()
					v_u_4:Create(v114.Mesh3.Start, TweenInfo.new(1.5, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
						["Size"] = nil,
						["Transparency"] = 1,
						["CFrame"] = nil,
						["Size"] = v114.Mesh3.End.Size,
						["CFrame"] = v114.Mesh3.End.CFrame
					}):Play()
					v114.Mesh.End:Destroy()
					v114.Mesh2.End:Destroy()
					v114.Mesh3.End:Destroy()
					if v_u_5.Character == p110 or v_u_5.Character == p111 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
						return
					end
				else
					v_u_12:PlaySound(v_u_8.Naoya.Ultimate.Catch, v113, game.SoundService.Effect)
					task.wait(0.3)
					local v115 = v_u_7.Naoya.Dialogue:Clone()
					v115.Parent = p110.Head
					local v116 = v115.Chat1.Position
					v115.Chat1.Position = v116 - UDim2.new(0, 0, 0.15, 0)
					v_u_4:Create(v115.Chat1, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Position"] = v116
					}):Play()
					v_u_4:Create(v115.Chat1, TweenInfo.new(0.3), {
						["BackgroundTransparency"] = 0
					}):Play()
					v_u_4:Create(v115.Chat1.Sub, TweenInfo.new(0.3), {
						["TextTransparency"] = 0
					}):Play()
					task.wait(1.3)
					local v117 = v115.Chat2.Position
					v115.Chat2.Position = v117 - UDim2.new(0, 0, 0.15, 0)
					v_u_4:Create(v115.Chat2, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Position"] = v117
					}):Play()
					v_u_4:Create(v115.Chat2, TweenInfo.new(0.3), {
						["BackgroundTransparency"] = 0
					}):Play()
					v_u_4:Create(v115.Chat2.Sub, TweenInfo.new(0.3), {
						["TextTransparency"] = 0
					}):Play()
					task.wait(0.8)
					v_u_3:AddItem(v115, 0.6)
					for _, v118 in v115:GetDescendants() do
						if v118:IsA("Frame") then
							v_u_4:Create(v118, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
								["Position"] = nil,
								["BackgroundTransparency"] = 1,
								["Position"] = v118.Position - UDim2.new(0, 0, 0.2, 0)
							}):Play()
						else
							if not v118:IsA("TextLabel") then
								continue
							end
							v_u_4:Create(v118, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
								["TextTransparency"] = 1
							}):Play()
						end
					end
				end
			end
		end,
		["Grip"] = function(p119, p120)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v_u_121 = p119:FindFirstChild("HumanoidRootPart")
			if v_u_121 then
				v_u_12:PlaySound(v_u_8.Naoya.Ultimate.Grab, v_u_121, game.SoundService.Effect)
				task.delay(0.2, function()
					-- upvalues: (ref) v_u_12, (ref) v_u_8, (copy) v_u_121
					v_u_12:PlaySound(v_u_8.Naoya.Ultimate.Grab2, v_u_121, game.SoundService.Effect)
				end)
				if v_u_5.Character == p120 or v_u_5.Character == p119 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Form"] = function(p122)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9
			local v123 = p122:FindFirstChild("HumanoidRootPart")
			if v123 then
				v_u_12:PlaySound(v_u_8.Naoya.Ultimate.Form, v123, game.SoundService.Effect)
				local v124 = {}
				for _, v125 in p122:GetChildren() do
					if not v125:IsA("BasePart") or v125 == v123 then
						continue
					end
					local v126 = v125.Color
					table.insert(v124, v126)
				end
				local v_u_127 = v_u_7.Naoya.Form:Clone()
				v_u_127.Color = v124[math.random(1, #v124)]
				v_u_127.Weld.Part0 = p122.Torso
				v_u_127.Parent = workspace.Effects
				v_u_3:AddItem(v_u_127, 4)
				v_u_4:Create(v_u_127, TweenInfo.new(0.4), {
					["Size"] = Vector3.new(4, 4, 4)
				}):Play()
				if v_u_5.Character == p122 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
				local v128 = v_u_7.Misc.M.WingFly:Clone()
				v128.WHAT:Destroy()
				v128:PivotTo(v123.CFrame)
				v128:ScaleTo(2)
				v128.Parent = workspace.Effects
				v_u_3:AddItem(v128, 1.5)
				v_u_4:Create(v128.Mesh.Start, TweenInfo.new(0.7, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = nil,
					["Size"] = v128.Mesh.End.Size,
					["CFrame"] = v128.Mesh.End.CFrame
				}):Play()
				v_u_4:Create(v128.Mesh2.Start, TweenInfo.new(1, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = nil,
					["Size"] = v128.Mesh2.End.Size,
					["CFrame"] = v128.Mesh2.End.CFrame
				}):Play()
				v_u_4:Create(v128.Mesh3.Start, TweenInfo.new(1.5, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = nil,
					["Size"] = v128.Mesh3.End.Size,
					["CFrame"] = v128.Mesh3.End.CFrame
				}):Play()
				v128.Mesh.End:Destroy()
				v128.Mesh2.End:Destroy()
				v128.Mesh3.End:Destroy()
				local v129 = v_u_7.Mahito.CrushingRushdown.DrillImpact:Clone()
				v129.Position = v123.Position
				v129.Parent = workspace.Effects
				v_u_3:AddItem(v129, 1)
				v129.Sparks.Color = ColorSequence.new(p122.Torso.Color)
				v129.Wind.Color = v129.Sparks.Color
				v129.Wind2.Color = v129.Sparks.Color
				v129.Sparks:Emit(50)
				v129.Wind:Emit(7)
				v129.Wind2:Emit(7)
				local v130 = v_u_127.Attachment
				for _ = 1, 30 do
					local v_u_131 = v130:Clone()
					local v132 = v_u_131.CFrame
					local v133 = CFrame.Angles
					local v134 = math.random(0, 360)
					local v135 = math.rad(v134)
					local v136 = math.random(0, 360)
					local v137 = math.rad(v136)
					local v138 = math.random(0, 360)
					v_u_131.CFrame = v132 * v133(v135, v137, (math.rad(v138)))
					v_u_131.Beam.Color = ColorSequence.new(v_u_127.Color, v124[math.random(1, #v124)])
					v_u_131.Parent = v_u_127
					local v_u_139 = math.random(100, 200) / 100
					local v_u_140 = TweenInfo.new(0.4 * v_u_139, Enum.EasingStyle.Back, Enum.EasingDirection.InOut)
					local v141 = v_u_4
					local v142 = v_u_131.Attachment
					local v143 = v_u_140
					local v144 = {}
					local v145 = math.random(30, 50)
					v144.Position = Vector3.new(0, v145, 0)
					v141:Create(v142, v143, v144):Play()
					v_u_4:Create(v_u_131.Beam, v_u_140, {
						["CurveSize0"] = 0
					}):Play()
					v_u_4:Create(v_u_131.Attachment, TweenInfo.new(0.6 * v_u_139, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
						["Orientation"] = Vector3.new(0, 0, -90)
					}):Play()
					task.delay(0.4 * v_u_139, function()
						-- upvalues: (ref) v_u_140, (copy) v_u_139, (ref) v_u_4, (copy) v_u_131
						v_u_140 = TweenInfo.new(0.4 * v_u_139, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
						v_u_4:Create(v_u_131.Attachment, v_u_140, {
							["Position"] = Vector3.new(0, 0, 0)
						}):Play()
						v_u_4:Create(v_u_131.Beam, v_u_140, {
							["CurveSize0"] = -15
						}):Play()
					end)
				end
				v130:Destroy()
				task.wait(0.4)
				v_u_127.Core.Wrap.Enabled = true
				v_u_4:Create(v_u_127, TweenInfo.new(0.8, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {
					["Size"] = Vector3.new(16, 16, 16)
				}):Play()
				task.spawn(function()
					-- upvalues: (copy) v_u_127
					repeat
						v_u_127.Core.Wrap.Size = NumberSequence.new(v_u_127.Size.X / 2 + 0.1)
						task.wait()
					until not v_u_127.Parent
				end)
				task.wait(0.8)
				v_u_4:Create(v_u_127, TweenInfo.new(0.5, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
					["Size"] = Vector3.new(0, 0, 0)
				}):Play()
				local v_u_146 = TweenInfo.new(0.4, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
				for v147 = 1, 15 do
					if (workspace.CurrentCamera.CFrame.Position - v123.Position).Magnitude > 300 then
						task.wait()
					else
						local v_u_148 = math.random(90, 130) / 100
						local v_u_149 = v_u_7.Mahito.Worms.Morph2:Clone()
						if v147 % 4 ~= 0 then
							v_u_149.Decal:Destroy()
						end
						v_u_149.Color = v124[math.random(1, #v124)]
						local v150 = v_u_149.Weld
						v150.C0 = v150.C0 * CFrame.Angles(math.random(0, 3.141592653589793), math.random(0, 3.141592653589793), math.random(0, 3.141592653589793))
						v_u_149.Weld.Part0 = v123
						v_u_149.Parent = workspace.Effects
						v_u_3:AddItem(v_u_149, 2)
						v_u_4:Create(v_u_149.Weld, TweenInfo.new(v_u_148 + 0.4, Enum.EasingStyle.Exponential), {
							["C0"] = v_u_149.Weld.C0 * CFrame.Angles(math.random(0, 3.141592653589793), math.random(0, 3.141592653589793), math.random(0, 3.141592653589793))
						}):Play()
						task.spawn(function()
							-- upvalues: (copy) v_u_148, (ref) v_u_4, (copy) v_u_149, (copy) v_u_146
							local v151 = v_u_148 / 5
							v_u_4:Create(v_u_149, TweenInfo.new(v_u_148 * 0.66, Enum.EasingStyle.Elastic), {
								["Size"] = Vector3.new(1, 1, 1) * math.random(80, 140) / 10
							}):Play()
							task.delay(v_u_148 * 0.33, function()
								-- upvalues: (ref) v_u_4, (ref) v_u_149, (ref) v_u_148
								v_u_4:Create(v_u_149, TweenInfo.new(v_u_148 * 0.33, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
									["Size"] = Vector3.new(0, 0, 10)
								}):Play()
							end)
							local v152 = TweenInfo.new(v151, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
							for v153 = 1, 5 do
								local v154 = CFrame.new(math.random(-40, 40) / 3, math.random(-10, 50) / 5, math.random(-20, 20) / 3)
								local v155 = v153 / 6
								local v156 = {
									["C1"] = v154:Lerp(CFrame.new(), v155)
								}
								v_u_4:Create(v_u_149.Weld, v152, v156):Play()
								task.wait(v151)
							end
							v_u_4:Create(v_u_149, v_u_146, {
								["Size"] = Vector3.new(0, 0, 0)
							}):Play()
						end)
						task.wait()
					end
				end
				task.wait(0.5)
				v_u_127:Destroy()
			end
		end,
		["Spin"] = function(p157, p158)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9, (ref) v_u_3, (ref) v_u_2
			local v159 = p157:FindFirstChild("HumanoidRootPart")
			if v159 then
				local v160 = v_u_7.Naoya.HitArea:Clone()
				v160.Parent = workspace.Effects
				v_u_4:Create(v160.groundwaveing.Spin, TweenInfo.new(1), {
					["TimeScale"] = 1
				}):Play()
				local _ = p157.Torso.Position
				local v161
				if v_u_5.Character == p157 then
					v161 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.HeavyHit)
				else
					v161 = nil
				end
				local v162 = tick()
				v160.Position = v159.Position
				local _ = p157.Torso.Position
				if tick() > v162 + 0.1 then
					v162 = tick()
					local v163 = p157:FindFirstChild("Curse")
					if v163 then
						local v164 = v163:Clone()
						for _, v165 in v164:GetDescendants() do
							if v165:IsA("Decal") then
								v165.Transparency = 1
							elseif v165:IsA("BasePart") and v165.Transparency ~= 1 then
								v165.Transparency = 0.5
								v165.Material = Enum.Material.Neon
								v165.Anchored = true
								v165.Color = Color3.fromRGB(128, 126, 255)
								if v165:IsA("UnionOperation") then
									v165.UsePartColor = true
								end
								v_u_4:Create(v165, TweenInfo.new(1), {
									["Transparency"] = 1
								}):Play()
							else
								if not (v165:IsA("Weld") or v165:IsA("Motor6D")) then
									continue
								end
								v165:Destroy()
							end
						end
						v164.Parent = workspace.Effects
						v_u_3:AddItem(v164, 1)
					end
				end
				v_u_2.Stepped:Wait()
				if p158:IsDescendantOf(workspace) and v159.Parent then
					continue
				end
				v160.groundwaveing.Spin.Enabled = false
				v_u_4:Create(v160.groundwaveing.Spin, TweenInfo.new(0.35, Enum.EasingStyle.Quad), {
					["TimeScale"] = 0.1
				}):Play()
				if v161 then
					v161:StartFadeOut(0.5)
				end
				local v166 = v_u_7.Misc.M.WingFly:Clone()
				v166.WHAT:Destroy()
				v166:PivotTo(v159.CFrame)
				v166:ScaleTo(2)
				v166.Parent = workspace.Effects
				v_u_3:AddItem(v166, 1.5)
				v_u_4:Create(v166.Mesh.Start, TweenInfo.new(0.7, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = nil,
					["Size"] = v166.Mesh.End.Size,
					["CFrame"] = v166.Mesh.End.CFrame
				}):Play()
				v_u_4:Create(v166.Mesh2.Start, TweenInfo.new(1, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = nil,
					["Size"] = v166.Mesh2.End.Size,
					["CFrame"] = v166.Mesh2.End.CFrame
				}):Play()
				v_u_4:Create(v166.Mesh3.Start, TweenInfo.new(1.5, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = nil,
					["Size"] = v166.Mesh3.End.Size,
					["CFrame"] = v166.Mesh3.End.CFrame
				}):Play()
				v166.Mesh.End:Destroy()
				v166.Mesh2.End:Destroy()
				v166.Mesh3.End:Destroy()
			end
		end,
		["SpinStart"] = function(p167)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			local v168 = p167:FindFirstChild("HumanoidRootPart")
			if v168 then
				v_u_12:PlaySound(v_u_8.Naoya.Acceleration, v168, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_8.Naoya.Frames, v168, game.SoundService.Effect)
				local v_u_169 = v_u_7.Naoya.Air:Clone()
				v_u_169.Parent = p167.Torso
				for _, v170 in v_u_169:GetDescendants() do
					if not v170:IsA("Beam") then
						continue
					end
					v_u_4:Create(v170, TweenInfo.new(0.5), {
						["Width1"] = 8,
						["TextureSpeed"] = -4
					}):Play()
				end
				task.spawn(function()
					-- upvalues: (copy) v_u_169
					for _, v171 in v_u_169:GetDescendants() do
						if not v171:IsA("Beam") then
							continue
						end
						v171.CurveSize1 = math.random(-60, 60) / 10
					end
					task.wait(0.04)
					if v_u_169.Parent then
						break
					end
				end)
				task.wait(1)
				v_u_3:AddItem(v_u_169, 0.2)
				for _, v172 in v_u_169:GetDescendants() do
					if v172:IsA("Beam") then
						v_u_4:Create(v172, TweenInfo.new(0.2), {
							["Width0"] = 0,
							["Width1"] = 0
						}):Play()
					else
						if not v172:IsA("ParticleEmitter") then
							continue
						end
						v172.Enabled = false
					end
				end
			end
		end,
		["Velocity"] = function(p173, p174)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			if p173:FindFirstChild("HumanoidRootPart") then
				local v175 = v_u_7.Yuki.Buildup:Clone()
				v175.Bar.Bar.UIGradient.Color = ColorSequence.new(Color3.fromRGB(255, 255, 255), Color3.fromRGB(128, 126, 255))
				v175.Parent = p173.Torso
				v_u_4:Create(v175.BG, TweenInfo.new(0.2), {
					["BackgroundTransparency"] = 0.5
				}):Play()
				v_u_4:Create(v175.Bar.Bar, TweenInfo.new(0.2), {
					["BackgroundTransparency"] = 0
				}):Play()
				repeat
					local v176 = ((p173.Humanoid:GetAttribute("Speed") or 2) - 2) / 2
					v175.Bar.Size = UDim2.new(1, 0, v176, 0)
					v175.Bar.Bar.Size = UDim2.new(1, 0, 1 / v176, 0)
					task.wait()
				until not (p173.Parent and p174.Parent)
				v_u_4:Create(v175.BG, TweenInfo.new(0.4), {
					["BackgroundTransparency"] = 1
				}):Play()
				v_u_4:Create(v175.Bar.Bar, TweenInfo.new(0.4), {
					["BackgroundTransparency"] = 1
				}):Play()
				v_u_3:AddItem(v175, 0.4)
			end
		end
	}
	v_u_10.Effects:Connect(function(p178, ...)
		-- upvalues: (copy) v_u_177
		local v179 = v_u_177[p178]
		if v179 then
			v179(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("NaoyaService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13