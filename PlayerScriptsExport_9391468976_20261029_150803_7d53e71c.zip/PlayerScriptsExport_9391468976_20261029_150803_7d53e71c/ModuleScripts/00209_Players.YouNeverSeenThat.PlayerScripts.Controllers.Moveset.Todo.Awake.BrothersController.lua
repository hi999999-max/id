-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Todo.Awake.BrothersController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local v_u_6 = v5.Animations
local v_u_7 = v5.Utils
local v_u_8 = v5.Sounds
local v_u_9 = require(v5.Modules.CameraShaker)
local v_u_10 = require(v5.Modules.LightningBeams)
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "BrothersController"
})
function v14.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_13, (copy) v_u_8, (copy) v_u_9, (copy) v_u_2, (copy) v_u_3, (copy) v_u_7, (copy) v_u_6, (copy) v_u_4, (copy) v_u_10, (ref) v_u_11
	local v_u_43 = {
		["Clap"] = function(p15)
			-- upvalues: (ref) v_u_13, (ref) v_u_8, (ref) v_u_9
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_13:PlaySound(v_u_8.Todo.Clap, v16, game.SoundService.Effect)
				if (v16.Position - workspace.CurrentCamera.CFrame.Position).Magnitude < 130 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Swap"] = function(p_u_17, p_u_18)
			-- upvalues: (ref) v_u_2, (ref) v_u_3, (ref) v_u_13, (ref) v_u_8, (ref) v_u_7, (ref) v_u_6, (ref) v_u_4
			local v_u_19 = p_u_17:FindFirstChild("HumanoidRootPart")
			if v_u_19 then
				local v_u_20 = {}
				for _, v21 in p_u_17:GetDescendants() do
					if not (v21:IsA("BasePart") or v21:IsA("Decal")) or v21.Transparency == 1 then
						continue
					end
					local v22 = v21.Transparency
					v21.Transparency = 1
					v_u_20[v21] = v22
				end
				local v23 = game.ReplicatedStorage.Utils.Todo.Clap:Clone()
				v23.Position = v_u_19.Position
				v23.Parent = workspace.Effects
				v_u_2:AddItem(v23, 1.5)
				v23.Attachment.Sparks:Emit(20)
				v_u_3:Create(v23, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(0, 0, 0),
					["Transparency"] = 1
				}):Play()
				v_u_13:PlaySound(v_u_8.Itadori.ManjiKick.Startup, v23, game.SoundService.Effect)
				local v_u_24 = nil
				local function v27()
					-- upvalues: (ref) v_u_24, (ref) v_u_7, (copy) v_u_19, (ref) v_u_6
					v_u_24 = v_u_7.Todo.Yuji:Clone()
					for _, v25 in v_u_24:GetDescendants() do
						if not v25:IsA("BasePart") then
							continue
						end
						v25.CollisionGroup = "Effects"
					end
					v_u_24.HumanoidRootPart.CFrame = v_u_19.CFrame
					v_u_24.Parent = workspace.Effects
					local v26 = v_u_24.Humanoid:LoadAnimation(v_u_6.Todo.Brothers)
					v26:Play(0)
					v26.TimePosition = 2.4
				end
				pcall(v27)
				task.spawn(function()
					-- upvalues: (ref) v_u_24, (copy) v_u_19, (copy) p_u_17, (copy) p_u_18, (copy) v_u_20, (ref) v_u_2, (ref) v_u_3, (ref) v_u_13, (ref) v_u_8
					if v_u_24 and v_u_24:FindFirstChild("HumanoidRootPart") then
						v_u_24.HumanoidRootPart.CFrame = v_u_19.CFrame
					end
					task.wait()
					if p_u_17.Parent and (v_u_19.Parent and (p_u_18 and (p_u_18.Parent and p_u_18.Value ~= true))) then
						continue
					end
					if v_u_24 then
						v_u_24:Destroy()
					end
					for v28, v29 in v_u_20 do
						if not v28.Parent then
							continue
						end
						v28.Transparency = v29
					end
					local v30 = game.ReplicatedStorage.Utils.Todo.Clap:Clone()
					v30.Position = v_u_19.Position
					v30.Parent = workspace.Effects
					v_u_2:AddItem(v30, 1.5)
					v30.Attachment.Sparks:Emit(20)
					v_u_3:Create(v30, TweenInfo.new(0.3), {
						["Size"] = Vector3.new(0, 0, 0),
						["Transparency"] = 1
					}):Play()
					v_u_13:PlaySound(v_u_8.Itadori.ManjiKick.Startup, v30, game.SoundService.Effect)
				end)
				if v_u_4.Character == p_u_17 then
					local v_u_31 = workspace.Effects:FindFirstChild("FollowTakada")
					if v_u_31 and v_u_4.Character == p_u_17 then
						v_u_31:ScaleTo(0.01)
						task.delay(1.34, function()
							-- upvalues: (copy) v_u_31
							v_u_31:ScaleTo(1)
						end)
					end
				end
			end
		end,
		["BlackFlash"] = function(p32, p33)
			-- upvalues: (ref) v_u_7, (ref) v_u_2, (ref) v_u_3, (ref) v_u_13, (ref) v_u_8, (ref) v_u_10, (ref) v_u_4, (ref) v_u_9
			local v34 = p32:FindFirstChild("HumanoidRootPart")
			if v34 then
				local v35 = p33:FindFirstChild("HumanoidRootPart")
				if v35 then
					for _, v36 in p33:GetChildren() do
						if not v36:IsA("BasePart") then
							continue
						end
						local v37 = v_u_7.Itadori.DivergentFist.FlashBurn:Clone()
						v37.Parent = v36
						v_u_2:AddItem(v37, 1)
					end
					local v38 = v_u_7.Itadori.DivergentFist.BlackFlashLaunch:Clone()
					v38.CFrame = v34.CFrame * CFrame.new(2, 1, -5)
					v38.Parent = workspace.Effects
					v38.Wind:Emit(20)
					v38.Sparks:Emit(20)
					v38.Flare:Emit(20)
					v38.Lightning:Emit(25)
					v38.Back1.Back:Emit(1)
					v38.Back2.Back:Emit(1)
					v_u_3:Create(v38.Back1, TweenInfo.new(2), {
						["CFrame"] = v38.Back1.CFrame - v38.Back1.CFrame.LookVector * 20
					}):Play()
					v_u_3:Create(v38.Back2, TweenInfo.new(2), {
						["CFrame"] = v38.Back2.CFrame - v38.Back2.CFrame.LookVector * 20
					}):Play()
					v_u_3:Create(v38.PointLight, TweenInfo.new(1), {
						["Brightness"] = 0
					}):Play()
					v_u_2:AddItem(v38, 3)
					v_u_13:PlaySound(v_u_8.Itadori.DivergentFist.BlackFlashHit, v35, game.SoundService.Effect)
					v_u_13:PlaySound(v_u_8.Itadori.DivergentFist.Voice, v34, game.SoundService.Effect)
					local v39 = Instance.new("Model", workspace.Effects.Bolt)
					local v40 = Instance.new("Highlight", v39)
					v40.DepthMode = Enum.HighlightDepthMode.Occluded
					v40.OutlineColor = Color3.new(1, 0, 0)
					v40.FillColor = Color3.new(0, 0, 0)
					v40.FillTransparency = 0
					v_u_2:AddItem(v39, 1.2)
					local v_u_41 = v_u_10.new(v38.Core, v35.RootAttachment, nil, v39)
					v_u_41.Color = Color3.new(1, 0, 0)
					v_u_41.PulseSpeed = 1000
					v_u_41.FadeLength = 0.35
					v_u_41.MaxRadius = 20
					v_u_41.MinRadius = 0
					v_u_41.AnimationSpeed = 300
					v_u_41.MinThicknessMultiplier = 0.5
					v_u_41.MaxThicknessMultiplier = 10
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_41
						v_u_41.MaxThicknessMultiplier = 5
						task.wait(0.1)
						v_u_41.MaxThicknessMultiplier = 3
						task.wait(0.1)
						v_u_41.MaxThicknessMultiplier = 2
						task.wait(0.1)
						v_u_41.MaxThicknessMultiplier = 1
						task.wait(0.4)
						v_u_41:Destroy()
					end)
					if v_u_4.Character == p32 or v_u_4.Character == p33 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
						if _G.Settings.Flash ~= true then
							return
						end
						local v42 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
						v42.Parent = game.Lighting
						task.wait(0.04)
						v42.TintColor = Color3.new(1, 1, 1)
						task.wait(0.04)
						v42.Brightness = 200
						v42.Contrast = -1000
						task.wait(0.04)
						v42:Destroy()
					end
				end
			else
				return
			end
		end
	}
	v_u_11.Effects:Connect(function(p44, ...)
		-- upvalues: (copy) v_u_43
		local v45 = v_u_43[p44]
		if v45 then
			v45(...)
		end
	end)
end
function v14.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13
	v_u_11 = v_u_1.GetService("BrothersService")
	v_u_12 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("FXController")
end
return v14