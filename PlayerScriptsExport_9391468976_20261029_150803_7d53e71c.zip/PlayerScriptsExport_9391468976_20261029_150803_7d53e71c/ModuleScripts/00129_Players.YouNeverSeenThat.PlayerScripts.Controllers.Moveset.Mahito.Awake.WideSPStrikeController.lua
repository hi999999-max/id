-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Mahito.Awake.WideSPStrikeController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local v_u_7 = v6.Animations
local v_u_8 = v6.Utils
local v_u_9 = v6.Sounds
local v_u_10 = require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "WideSPStrikeController"
})
function v14.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_8, (copy) v_u_4, (copy) v_u_3, (ref) v_u_13, (copy) v_u_9, (copy) v_u_7, (copy) v_u_10, (copy) v_u_2, (copy) v_u_5, (ref) v_u_11
	local v_u_55 = {
		["Afterimages"] = function(p15)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_7, (ref) v_u_10, (ref) v_u_2
			local v_u_16 = p15:FindFirstChild("HumanoidRootPart")
			if v_u_16 then
				local v_u_17 = v_u_8.Mahito.WideSPStrike.HitArea:Clone()
				v_u_17.Parent = workspace.Effects
				v_u_4:Create(v_u_17.Overlay, TweenInfo.new(0.4), {
					["Transparency"] = 0.5
				}):Play()
				v_u_17.Prog.Size = Vector3.new(25, 0, 25)
				v_u_4:Create(v_u_17.Prog, TweenInfo.new(2.1, Enum.EasingStyle.Linear), {
					["Size"] = Vector3.new(0, 0, 0)
				}):Play()
				v_u_17.groundwaveing.Flare:Emit(10)
				v_u_17.groundwaveing.Wind:Emit(15)
				v_u_3:AddItem(v_u_17, 4.3)
				v_u_13:PlaySound(v_u_9.Mahito.WideSPStrike.Start, v_u_16, game.SoundService.Effect)
				local v_u_18 = {}
				for v19 = 1, 4 do
					local v20 = p15:Clone()
					local v21 = v20.HumanoidRootPart
					for _, v22 in v20:GetDescendants() do
						if v22:IsA("BillboardGui") or (v22:IsA("Sound") or v22:IsA("ParticleEmitter")) then
							v22:Destroy()
						else
							if not v22:IsA("BasePart") then
								continue
							end
							v22.CollisionGroup = "NoCollision"
							v22.CanCollide = false
						end
					end
					v20.Parent = workspace.Effects
					v21.Anchored = true
					v_u_3:AddItem(v20, 2.1)
					local v23 = v20.Humanoid:LoadAnimation(v_u_7.Mahito.WideStrike)
					v23:Play(0)
					v23.TimePosition = 0.5
					v_u_8.Mahito.WideSPStrike.Afterimage:Clone().Parent = v20.Torso
					local v_u_24 = v21:FindFirstChild("RootJoint")
					if not v_u_24 then
						break
					end
					table.insert(v_u_18, v_u_24)
					local v25 = CFrame.Angles
					local v26 = (v19 - 1) * 90
					local v27 = v25(0, 0, (math.rad(v26)))
					local v_u_28 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 1, -0) * v27
					v_u_4:Create(v_u_24, TweenInfo.new(1.5, Enum.EasingStyle.Exponential), {
						["C0"] = v_u_28 * CFrame.new(0, math.random(14, 16), 0)
					}):Play()
					task.delay(1.5, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_24, (copy) v_u_28
						local v29 = {
							["C0"] = v_u_28
						}
						v_u_4:Create(v_u_24, TweenInfo.new(0.6, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), v29):Play()
					end)
				end
				local v_u_30 = {}
				for _, v31 in p15:GetDescendants() do
					if v31:IsA("ParticleEmitter") and v31.Name == "Aura" then
						v31.Enabled = false
						v_u_30[v31] = true
					else
						if not v31:IsA("BasePart") and (not v31:IsA("Decal") or v31.Transparency == 1) then
							continue
						end
						v_u_30[v31] = v31.Transparency
						v31.Transparency = 1
					end
				end
				local v_u_32 = tick()
				if (workspace.CurrentCamera.CFrame.Position - v_u_16.Position).Magnitude < 200 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
				end
				local v_u_33 = nil
				v_u_33 = v_u_2.Stepped:Connect(function(_, p34)
					-- upvalues: (copy) v_u_16, (copy) v_u_32, (ref) v_u_33, (copy) v_u_17, (ref) v_u_30, (ref) v_u_10, (copy) v_u_18
					if v_u_16.Parent and tick() <= v_u_32 + 2.1 then
						local v35 = (1 - (tick() - v_u_32) / 2) * 4000
						local v36 = CFrame.Angles
						local v37 = v35 * p34
						local v38 = v36(0, math.rad(v37), 0)
						for _, v39 in v_u_18 do
							v39.Parent.CFrame = (v39.Parent.CFrame - v39.Parent.Position + v_u_16.Position) * v38
						end
						local v40 = workspace:Raycast(v_u_16.Position, Vector3.new(0, -200, 0), _G.MapParams)
						if v40 then
							v_u_17.Position = v40.Position
						else
							v_u_17.Position = Vector3.new(0, 1000000, 0)
						end
						v_u_17.Prog.Position = v_u_17.Position
						if (workspace.CurrentCamera.CFrame.Position - v_u_16.Position).Magnitude < 200 then
							v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
						end
					else
						v_u_33:Disconnect()
						for _, v41 in v_u_17:GetDescendants() do
							if not v41:IsA("ParticleEmitter") then
								continue
							end
							v41.Enabled = false
						end
						v_u_17.Overlay:Destroy()
						v_u_17.Prog:Destroy()
						v_u_17.groundwaveing.Spin.Enabled = false
						v_u_17.groundwaveing.Flare:Emit(10)
						v_u_17.groundwaveing.Wind:Emit(15)
						for v42, v43 in v_u_30 do
							if not v42.Parent then
								continue
							end
							if v42:IsA("BasePart") or v42:IsA("Decal") then
								v42.Transparency = v43
							else
								if not v42:IsA("ParticleEmitter") then
									continue
								end
								v42.Enabled = v43
							end
						end
						v_u_30 = nil
						if (workspace.CurrentCamera.CFrame.Position - v_u_16.Position).Magnitude < 200 then
							v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
						end
					end
				end)
			end
		end,
		["Voice"] = function(p44, p45)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v46 = p44:FindFirstChild("HumanoidRootPart")
			if v46 then
				task.wait(0.35)
				if p45 then
					v_u_13:PlaySound(v_u_9.Mahito.WideSPStrike.Voice, v46, game.SoundService.Voice)
				else
					v_u_13:PlaySound(v_u_9.Mahito.WideSPStrike.Voice, v46, game.SoundService.Voice)
				end
			else
				return
			end
		end,
		["Voice2"] = function(p47)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_3
			local v48 = p47:FindFirstChild("HumanoidRootPart")
			if v48 then
				v_u_3:AddItem(v_u_13:PlaySound(v_u_9.Mahito.WideSPStrike.Flash, v48, game.SoundService.Voice), 1)
			end
		end,
		["Hit"] = function(p49, p50)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_10, (ref) v_u_8, (ref) v_u_3, (ref) v_u_5, (ref) v_u_4
			local v51 = p49:FindFirstChild("HumanoidRootPart")
			if v51 then
				v_u_13:Flash(p50, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Mahito.WideSPStrike["Hit" .. math.random(1, 5)], v51, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v51.Position).Magnitude < 50 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
				elseif (workspace.CurrentCamera.CFrame.Position - v51.Position).Magnitude < 100 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HardHit)
				end
				local v52 = v_u_8.Mahito.Worms.DashSlash.Attachment:Clone()
				v52.Parent = v51
				v_u_3:AddItem(v52, 2)
				for _, v53 in v52:GetChildren() do
					v53.Enabled = false
					v53:Emit(2)
				end
				if v_u_5.Character == p49 or v_u_5.Character == p50 then
					if _G.Settings.Flash ~= true then
						return
					end
					local v54 = v_u_8.Mahito.WideSPStrike.ScreenSlash:Clone()
					v54.Base.Rotation = math.random(0, 360)
					v54.Parent = v51
					v_u_4:Create(v54.Base.Base2, TweenInfo.new(0.3, Enum.EasingStyle.Exponential), {
						["BackgroundTransparency"] = 1
					}):Play()
					v_u_4:Create(v54.Base.Frame, TweenInfo.new(0.1), {
						["BackgroundTransparency"] = 1
					}):Play()
					v_u_3:AddItem(v54, 0.3)
				end
			end
		end
	}
	v_u_11.Effects:Connect(function(p56, ...)
		-- upvalues: (copy) v_u_55
		local v57 = v_u_55[p56]
		if v57 then
			v57(...)
		end
	end)
end
function v14.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13
	v_u_11 = v_u_1.GetService("WideSPStrikesService")
	v_u_12 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("FXController")
end
return v14