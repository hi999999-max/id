-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Heian.HeianController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local v_u_7 = v6.Animations
local v_u_8 = v6.Utils
local v_u_9 = v6.Sounds
local v_u_10 = require(v6.Modules.CameraShaker)
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "HeianController"
})
function v14.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_13, (copy) v_u_9, (copy) v_u_8, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_10, (copy) v_u_7, (copy) v_u_2, (ref) v_u_11
	local v_u_99 = {
		["Hit"] = function(p15, p16)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v17 = p15:FindFirstChild("HumanoidRootPart")
			if v17 then
				v_u_13:Flash(p15, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit" .. p16), v17, game.SoundService.Effect)
			end
		end,
		["ChaseHit"] = function(p18, p19)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3
			local v20 = p18:FindFirstChild("HumanoidRootPart")
			if v20 then
				local v21 = p19:FindFirstChild("HumanoidRootPart")
				if v21 then
					v_u_13:Flash(p19, Color3.new(1, 1, 1))
					v_u_13:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit3"), v21, game.SoundService.Effect)
					local v22 = v_u_8.ChaseHit:Clone()
					local v23 = CFrame.new
					local v24 = v21.Position
					local v25 = v20.Position.X
					local v26 = v21.Position.Y
					local v27 = v20.Position.Z
					v22.CFrame = v23(v24, (Vector3.new(v25, v26, v27))) * CFrame.Angles(0, 3.141592653589793, 0)
					v22.Parent = workspace.Effects
					v22.Ring:Emit(7)
					v22.Sparks:Emit(12)
					v_u_3:AddItem(v22, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p28)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9
			local v29 = p28.HumanoidRootPart
			if v29 then
				local v30 = v_u_8.Gojo.LapseBlue.Throw:Clone()
				v30.CFrame = v29.CFrame * CFrame.new(0, 1, -4)
				v30.Size = Vector3.new(0, 0, 2)
				v30.Parent = workspace.Effects
				v_u_4:Create(v30, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v30, 0.3)
				v_u_13:PlaySound(v_u_9.Misc.Chase, v29, game.SoundService.Effect)
				v_u_13:DustTrail(p28, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p31)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v32 = p31:FindFirstChild("HumanoidRootPart")
			if v32 then
				v_u_13:PlaySound(v_u_9.Misc.Swing.Fist, v32, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p33, p34, p35)
			-- upvalues: (ref) v_u_13
			if p34 == 1 or (p34 == 3 or p35 == "Up") then
				v_u_13:ArmFlash(p33["Right Arm"], Color3.fromRGB(85, 0, 0))
				return
			elseif p34 == 2 then
				v_u_13:ArmFlash(p33["Left Arm"], Color3.fromRGB(85, 0, 0))
			elseif p34 == 4 then
				v_u_13:ArmFlash(p33["Right Leg"], Color3.fromRGB(85, 0, 0), p35 == "Down" and 0.4 or false)
			end
		end,
		["Launch"] = function(p36, p37)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v38 = p36:FindFirstChild("HumanoidRootPart")
			if v38 then
				local v39 = v_u_8.Gojo.LapseBlue.Throw:Clone()
				v39.CFrame = CFrame.new(v38.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v39.Size = Vector3.new(0, 0, 5)
				v39.Parent = workspace.Effects
				v_u_4:Create(v39, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v39.Position + Vector3.new(0, p37, 0)
				}):Play()
				v_u_3:AddItem(v39, 0.3)
				if p37 < 0 then
					v_u_13:PlaySound(v_u_9.Megumi.Mahoraga.Throw.Break, v38, game.SoundService.Effect)
					v_u_13:DustBreak(v38.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v38.Position) < 20 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
					end
				end
			end
		end,
		["Startup"] = function(p40)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_7, (ref) v_u_4
			local v41 = p40:FindFirstChild("HumanoidRootPart")
			if v41 then
				v_u_13:PlaySound(v_u_9.Heian.MalevolentShrine.Voice, v41, game.SoundService.Voice)
				v_u_13:DomainBurst(v41)
				v_u_13:Domain(p40, function(p42, p43)
					-- upvalues: (ref) v_u_7, (ref) v_u_4
					p43.Humanoid:LoadAnimation(v_u_7.Heian.DomainWarn):Play(0)
					p42.Panel.ImageLabel.Image = "rbxassetid://17668583842"
					local v44 = p43.HumanoidRootPart
					v44.CFrame = v44.CFrame * CFrame.Angles(0, 0, 0.17453292519943295)
					v_u_4:Create(p43.HumanoidRootPart, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["CFrame"] = p43.HumanoidRootPart.CFrame * CFrame.Angles(0, -0.3490658503988659, 0.3490658503988659)
					}):Play()
					p42.Panel.Viewport.LightColor = Color3.fromRGB(255, 155, 155)
					p42.Panel.Viewport.Ambient = Color3.fromRGB(0, 0, 0)
					p42.Panel.Viewport.LightDirection = Vector3.new(1, 0, 1)
				end)
			end
		end,
		["Chant"] = function(p45, p46)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_7, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			local v47 = p45:FindFirstChild("HumanoidRootPart")
			if v47 then
				local v48 = v_u_8.Heian.Chant.Attachment:Clone()
				v48.Parent = v47
				v_u_3:AddItem(v48, 2)
				v48.Dust:Emit(50)
				v48.Ring:Emit(10)
				v48.Attachment.Burst:Emit(1)
				v48.Attachment.Ring:Emit(1)
				local v_u_49 = v_u_8.Heian.Chant.Chant:Clone()
				v_u_49.Parent = v47
				v_u_3:AddItem(v_u_49, 1)
				v_u_4:Create(v_u_49, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
					["StudsOffset"] = Vector3.new(2, 4, 2)
				}):Play()
				task.delay(0.5, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_49
					v_u_4:Create(v_u_49.Chat, TweenInfo.new(0.5), {
						["ImageTransparency"] = 1
					}):Play()
					v_u_4:Create(v_u_49.Chat.Sub, TweenInfo.new(0.5), {
						["TextTransparency"] = 1
					}):Play()
				end)
				local v50 = p45.SetAssets:FindFirstChild("HeianArms")
				if v50 then
					local v51 = v50:FindFirstChild("HeianArmsModel")
					if not v51 then
						return
					end
					v51.Humanoid:LoadAnimation(v_u_7.Heian.ChantArms):Play(0)
				end
				if p46 == 1 then
					v_u_13:Flash(p45, Color3.fromRGB(255, 255, 255), 2)
					v_u_13:PlaySound(v_u_9.Itadori.Dismantle.WorldSlash1, v47, game.SoundService.Effect)
					return
				elseif p46 == 2 then
					v_u_13:Flash(p45, Color3.fromRGB(255, 255, 127), 2)
					v_u_13:PlaySound(v_u_9.Itadori.Dismantle.WorldSlash2, v47, game.SoundService.Effect)
					v_u_49.Chat.Sub.Text = "RECOIL..."
					return
				elseif p46 == 3 then
					v_u_13:Flash(p45, Color3.fromRGB(255, 85, 0), 2)
					v_u_13:PlaySound(v_u_9.Itadori.Dismantle.WorldSlash1, v47, game.SoundService.Effect)
					v_u_49.Chat.Sub.Text = "TWIN METEORS."
				elseif p46 == 4 then
					v_u_13:Flash(p45, Color3.fromRGB(255, 0, 0), 2)
					v_u_13:PlaySound(v_u_9.Heian.WorldSlash3, v47, game.SoundService.Effect)
					v_u_49:Destroy()
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
					v_u_13:PlaySound(v_u_9.Heian.Dismantle.WCSCharge, v47, game.SoundService.Effect)
					task.wait(0.3)
					v_u_13:PlaySound(v_u_9.Heian.Dismantle.Start, v47, game.SoundService.Effect)
					v_u_13:PlaySound(v_u_9.Heian.Dismantle4, v47, game.SoundService.Voice)
				end
			else
				return
			end
		end,
		["Interp"] = function(p_u_52)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_10, (ref) v_u_2
			local v_u_53 = p_u_52.CFrame
			local v_u_54 = tick()
			local v_u_55 = p_u_52:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_53, (copy) p_u_52, (ref) v_u_54
				v_u_53 = p_u_52.CFrame
				v_u_54 = tick()
			end)
			v_u_13:PlaySound(v_u_9.Heian.Dismantle.FireWCS, p_u_52, game.SoundService.Effect)
			v_u_13:PlaySound(v_u_9.Heian.Dismantle.Fire, p_u_52, game.SoundService.Effect)
			v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
			local v_u_56 = nil
			v_u_56 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_52, (ref) v_u_56, (copy) v_u_55, (ref) v_u_53, (ref) v_u_54
				if p_u_52.Parent then
					workspace:BulkMoveTo({ p_u_52 }, { v_u_53 + v_u_53.LookVector * (300 * (tick() - v_u_54)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_56:Disconnect()
					v_u_55:Disconnect()
				end
			end)
		end,
		["DebreeOverlay"] = function(p_u_57, p58, p59)
			-- upvalues: (ref) v_u_8, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10, (ref) v_u_3, (ref) v_u_4
			local v60 = {}
			for v61, _ in p59 do
				local v62 = Color3.fromHex
				table.insert(v60, v62(v61))
			end
			local v63 = workspace.CurrentCamera
			local v64 = tick() + 20
			local v65 = v_u_8.Heian.Slashes:Clone()
			v65.Parent = workspace.Effects
			v65.Position = v63.CFrame.Position
			local v66 = {}
			local v_u_67 = true
			local function v71(p68) -- name: handleChar
				-- upvalues: (ref) v_u_8, (ref) v_u_13, (ref) v_u_9, (ref) v_u_67, (copy) p_u_57
				local v69 = p68.HumanoidRootPart
				local v70 = v_u_8.Itadori.MalevolantShrine.Hit:Clone()
				v70.Parent = workspace.Effects
				v70.Weld.Part1 = v69
				task.wait(math.random(10, 20) / 100)
				if v69.Parent then
					v_u_13:PlaySound(v_u_9.Itadori.Dismantle.Slash, v69, game.SoundService.Effect)
					if v_u_67 and (not p68:GetAttribute("Dead") and (not p_u_57:GetAttribute("Dead") and (p_u_57.Parent and v69.Parent))) then
						continue
					end
				end
				v70:Destroy()
				if p68:GetAttribute("Dead") and v69.Parent then
					v_u_13:PlaySound(v_u_9.Itadori.Dismantle.Explode, v69, game.SoundService.Effect)
					v_u_13:Bleed(p68)
				end
			end
			local v72 = v_u_10.CurrentShaker:ShakeSustain(v_u_10.Presets.HeavyHit)
			local v73 = v_u_13:PlaySound(v_u_9.Heian.MalevolentShrine.Slashes, workspace, game.SoundService.Effect)
			v_u_13:PlaySound(v_u_9.Heian.MalevolentShrine.Voice3, workspace, game.SoundService.Voice)
			v65.Position = v63.CFrame.Position + v63.CFrame.LookVector * 100
			for _, v74 in workspace.Characters:GetChildren() do
				if not v74:FindFirstChild("HumanoidRootPart") or (v66[v74] or v74 == p_u_57) then
					continue
				end
				v66[v74] = true
				task.spawn(v71, v74)
			end
			if _G.Settings.DesPHY and ((v63.CFrame.Position - p58.Position).Magnitude < 250 and #v60 > 0) then
				for _ = 1, 8 do
					local v_u_75 = v_u_8.Damage.DebreeRef:Clone()
					local v76 = math.random(5, 60) / 10
					local v77 = math.random(5, 60) / 10
					v_u_75.Size = Vector3.new(v76, 2, v77)
					v_u_75.CFrame = v63.CFrame * CFrame.new(math.random(-120, 120) / 10, math.random(-80, 80) / 10, 10)
					v_u_75.CollisionGroup = "Effects"
					v_u_75.Anchored = false
					local v78 = v63.CFrame * CFrame.Angles(math.random(-90, 90), math.random(-90, 90), math.random(-90, 90))
					v_u_75.Color = v60[math.random(1, #v60)]
					task.delay(1.4, function()
						-- upvalues: (copy) v_u_75
						if v_u_75.Parent then
							v_u_75:Destroy()
						end
					end)
					v_u_75.Velocity = v78.LookVector * math.random(100, 400)
					local v79 = math.random(-300, 300)
					local v80 = math.random(-300, 300)
					local v81 = math.random
					v_u_75.RotVelocity = Vector3.new(v79, v80, v81(-300, 300))
					v_u_75.Parent = workspace.Effects
				end
			end
			task.wait(0.025)
			if v64 >= tick() and (p_u_57.Parent and not p_u_57:GetAttribute("Dead")) then
				break
			end
			v_u_67 = false
			v65.Slash1.Enabled = false
			v65.Slash2.Enabled = false
			v65.Sparks.Enabled = false
			v_u_3:AddItem(v65, 1)
			if v72 then
				v72:StartFadeOut(1)
			end
			if v73 then
				v_u_4:Create(v73, TweenInfo.new(1.5), {
					["Volume"] = 0
				}):Play()
			end
		end,
		["DomainOpen"] = function(p_u_82, _)
			-- upvalues: (ref) v_u_8, (ref) v_u_5, (ref) v_u_13, (ref) v_u_9, (ref) v_u_4, (ref) v_u_10, (ref) v_u_3
			local v_u_83 = p_u_82:FindFirstChild("HumanoidRootPart")
			if v_u_83 then
				local v_u_84 = tick() + 25.5
				local v_u_85 = v_u_8.Heian.DomainFade:Clone()
				v_u_85.Parent = v_u_5.PlayerGui
				v_u_13:PlaySound(v_u_9.Heian.MalevolentShrine.UhohStart, workspace, game.SoundService.Effect)
				local v_u_86 = v_u_13:PlaySound(v_u_9.Heian.MalevolentShrine.Music, workspace, game.SoundService.Music, true)
				v_u_85.BG.BackgroundTransparency = 1
				v_u_4:Create(v_u_85.BG, TweenInfo.new(0.2), {
					["BackgroundTransparency"] = 0
				}):Play()
				task.delay(0.5, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_85, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10, (copy) p_u_82, (copy) v_u_83, (ref) v_u_8, (ref) v_u_3, (copy) v_u_84, (copy) v_u_86
					v_u_4:Create(v_u_85.BG.Bubble, TweenInfo.new(1.2), {
						["ImageTransparency"] = 1
					}):Play()
					v_u_4:Create(v_u_85.BG.Bubble.Texta, TweenInfo.new(1.2), {
						["TextTransparency"] = 1
					}):Play()
					v_u_13:PlaySound(v_u_9.Itadori.MalevolantShrine.Ring, workspace, game.SoundService.Effect)
					task.wait(1.2)
					v_u_85.BG.Visible = false
					v_u_85.Frame1.Visible = true
					v_u_85.Frame2.Visible = true
					v_u_5.PlayerGui.Main.Enabled = false
					local v_u_87 = Instance.new("ColorCorrectionEffect", game.Lighting)
					v_u_87.Brightness = -1
					v_u_13:DomainMapFade(Color3.new(1, 0, 0), 0, 0.5)
					task.delay(0.5, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_87
						v_u_4:Create(v_u_87, TweenInfo.new(0.5), {
							["Brightness"] = 0,
							["Saturation"] = -0.5
						}):Play()
					end)
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
					v_u_13:PlaySound(v_u_9.Heian.MalevolentShrine.Uhoh, workspace, game.SoundService.Effect)
					if p_u_82:GetAttribute("Moveset") == "Heian" then
						v_u_13:PlaySound(v_u_9.Heian.MalevolentShrine.Voice2, v_u_83, game.SoundService.Voice)
					end
					local v88 = v_u_8.Heian.Shrine:Clone()
					v88:PivotTo(v_u_83.CFrame * CFrame.new(0, 11, 20))
					v88.Parent = workspace.Effects
					local v89 = TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
					for _, v90 in v88:GetDescendants() do
						if not v90:IsA("BasePart") then
							continue
						end
						local v91 = v90.CFrame
						local v92 = v90.CFrame * CFrame.new(math.random(-30, 30), math.random(-30, 30), math.random(-30, 30))
						local v93 = CFrame.Angles
						local v94 = math.random(0, 360)
						local v95 = math.rad(v94)
						local v96 = math.random(0, 360)
						local v97 = math.rad(v96)
						local v98 = math.random(0, 360)
						v90.CFrame = v92 * v93(v95, v97, (math.rad(v98)))
						v_u_4:Create(v90, v89, {
							["CFrame"] = v91
						}):Play()
					end
					task.delay(3, function()
						-- upvalues: (copy) v_u_87, (ref) v_u_4, (ref) v_u_3, (ref) v_u_85, (ref) v_u_5, (ref) v_u_10
						if v_u_87 then
							v_u_4:Create(v_u_87, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
								["Brightness"] = 1
							}):Play()
							task.wait(0.5)
							v_u_87.TintColor = Color3.new(1, 0, 0)
							v_u_4:Create(v_u_87, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
								["Brightness"] = 0,
								["Saturation"] = 0
							}):Play()
							v_u_4:Create(v_u_87, TweenInfo.new(2, Enum.EasingStyle.Sine), {
								["TintColor"] = Color3.new(1, 1, 1)
							}):Play()
							v_u_3:AddItem(v_u_87, 2)
						end
						if v_u_85 then
							v_u_5.PlayerGui.Main.Enabled = true
							v_u_4:Create(v_u_85.Frame1, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
								["Position"] = UDim2.new(0, 0, -0.15, 0)
							}):Play()
							v_u_4:Create(v_u_85.Frame2, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
								["Position"] = UDim2.new(0, 0, 1.15, 0)
							}):Play()
							v_u_3:AddItem(v_u_85, 1)
							v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
						end
					end)
					repeat
						task.wait()
					until v_u_84 < tick() or (not p_u_82.Parent or p_u_82:GetAttribute("Dead"))
					v88:Destroy()
					if v_u_86 then
						v_u_4:Create(v_u_86, TweenInfo.new(2), {
							["Volume"] = 0
						}):Play()
						v_u_3:AddItem(v_u_86, 2)
					end
				end)
			end
		end
	}
	v_u_11.Effects:Connect(function(p100, ...)
		-- upvalues: (copy) v_u_99
		local v101 = v_u_99[p100]
		if v101 then
			v101(...)
		end
	end)
end
function v14.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13
	v_u_11 = v_u_1.GetService("HeianService")
	v_u_12 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("FXController")
end
return v14