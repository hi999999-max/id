-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Kurourushi.Base.ChokeholdController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local v_u_6 = v5.Animations
local v_u_7 = v5.Utils
local v_u_8 = v5.Sounds
local v_u_9 = require(v5.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "ChokeholdController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_11, (copy) v_u_8, (ref) v_u_12, (copy) v_u_6, (copy) v_u_4, (copy) v_u_9, (copy) v_u_7, (copy) v_u_2, (copy) v_u_3, (ref) v_u_10
	local v_u_37 = {
		["Start"] = function(p14)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_12, (ref) v_u_6
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_11:PlaySound(v_u_8.Kurourushi.Chokehold.Start, v15, game.SoundService.Effect)
				local v16, v17 = v_u_12:PlayArms(p14, v_u_6.Kurourushi.Chokehold, v_u_6.Kurourushi.Chokehold)
				if v17 then
					v17.Parent.Attach.Value = v15
					repeat
						task.wait()
					until v16.IsPlaying == false or v15.Parent == nil
					v17.Parent.Attach.Value = nil
				end
			else
				return
			end
		end,
		["Hit"] = function(p18, p19, p20)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_9, (ref) v_u_12, (ref) v_u_6
			local v21 = p18:FindFirstChild("HumanoidRootPart")
			if v21 then
				if p19:FindFirstChild("HumanoidRootPart") then
					v_u_11:Flash(p19, Color3.new(1, 1, 1))
					v_u_11:PlaySound(p20 and v_u_8.Kurourushi.Chokehold.PunchGrab or v_u_8.Kurourushi.Chokehold.CleaveGrab, v21, game.SoundService.Effect)
					if p18 == v_u_4.Character or p19 == v_u_4.Character then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
					end
					local _, v22 = v_u_12:PlayArms(p18, v_u_6.Kurourushi.ChokeholdHitArms, v_u_6.Kurourushi.ChokeholdHit)
					if not v22 then
					end
				else
					return
				end
			else
				return
			end
		end,
		["Hit2"] = function(p23, p24, p25)
			-- upvalues: (ref) v_u_7, (ref) v_u_2, (ref) v_u_11, (ref) v_u_4, (ref) v_u_9, (ref) v_u_8
			local v26 = p23:FindFirstChild("HumanoidRootPart")
			if v26 then
				local v27 = p24:FindFirstChild("HumanoidRootPart")
				if v27 then
					local v28 = v_u_7.Mahito.CrushingRushdown.DrillImpact:Clone()
					v28.Position = v27.Position
					v28.Parent = workspace.Effects
					v_u_2:AddItem(v28, 1)
					v28.Sparks.Color = ColorSequence.new(Color3.fromRGB(101, 35, 44))
					v28.Wind.Color = v28.Sparks.Color
					v28.Wind2.Color = v28.Sparks.Color
					v28.Sparks:Emit(30)
					v28.Wind2:Emit(7)
					v_u_11:Flash(p24, Color3.new(1, 1, 1))
					if p23 == v_u_4.Character or p24 == v_u_4.Character then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.SnapOh)
					end
					v_u_11:PlaySound(p25 and v_u_8.Kurourushi.Chokehold.PunchHit1 or v_u_8.Kurourushi.Chokehold.CleaveHit1, v26, game.SoundService.Effect)
					task.wait(0.025)
					for _, v29 in pairs(v28:GetDescendants()) do
						if not v29:IsA("ParticleEmitter") then
							continue
						end
						v29.TimeScale = 0
					end
					task.wait(0.1225)
					v_u_11:PlaySound(p25 and v_u_8.Kurourushi.Chokehold.PunchHit2 or v_u_8.Kurourushi.Chokehold.CleaveHit2, v26, game.SoundService.Effect)
					for _, v30 in pairs(v28:GetDescendants()) do
						if not v30:IsA("ParticleEmitter") then
							continue
						end
						v30.TimeScale = 1
					end
					v_u_11:Flash(p24, Color3.new(1, 1, 1))
					if p23 == v_u_4.Character or p24 == v_u_4.Character then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["Slash"] = function(p31, p32)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_2, (ref) v_u_3
			local v33 = p31:FindFirstChild("HumanoidRootPart")
			if v33 then
				v_u_11:PlaySound(v_u_8.Kurourushi.FesteringStrikes["Swing" .. p32], v33, game.SoundService.Effect)
				local v34 = p31.SetAssets:FindFirstChild("FesteringSword")
				if v34 then
					local v35 = v_u_7.Kurourushi.CombatTrail:Clone()
					local v36 = Instance.new("Model")
					v35.Parent = v36
					v36:ScaleTo(v34:GetScale())
					v_u_2:AddItem(v36, 0.1)
					v35.Weld.Part0 = v34.Union
					v35.Parent = workspace.Effects
					v35.Trail.FaceCamera = false
					task.wait(0.5)
					v35.Trail.Enabled = false
					v_u_3:Create(v35, TweenInfo.new(0.1), {
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v35, 0.2)
				end
			else
				return
			end
		end
	}
	v_u_10.Effects:Connect(function(p38, ...)
		-- upvalues: (copy) v_u_37
		local v39 = v_u_37[p38]
		if v39 then
			v39(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("ChokeholdService")
	v_u_11 = v_u_1.GetController("FXController")
	v_u_12 = v_u_1.GetController("KurourushiController")
end
return v13