-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Ryu.Awake.WerentInvitedController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "WerentInvitedController"
})
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_11, (copy) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_1, (copy) v_u_2, (copy) v_u_9, (copy) v_u_4, (copy) v_u_5, (ref) v_u_10
	local v_u_63 = {
		["Startup"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_11:PlaySound(v_u_8.Ryu.NotInvited.Windup, v14, game.SoundService.Effect)
			end
		end,
		["Charge"] = function(p15)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_11:PlaySound(v_u_8.Ryu.NotInvited.ChargeStart, v16, game.SoundService.Effect)
				local v17 = v_u_7.Mechamaru.Dust:Clone()
				v17.bigimpact:Destroy()
				v17.Smoke2:Destroy()
				v17.Position = v16.Position - Vector3.new(0, 3, 0)
				v17.Parent = workspace.Effects
				v_u_3:AddItem(v17, 4)
				for _, v18 in v17:GetChildren() do
					v18.TimeScale = 0.5
					v18:Emit(v18:GetAttribute("EmitCount"))
				end
			end
		end,
		["Charged"] = function(p19)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v20 = p19:FindFirstChild("HumanoidRootPart")
			if v20 then
				v_u_11:PlaySound(v_u_8.Ryu.NotInvited.FullCharge, v20, game.SoundService.Effect)
				v_u_11:Flash(p19, Color3.fromRGB(0, 255, 255), 1)
			end
		end,
		["Dash"] = function(p21, _, p22)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_1
			local v23 = p21:FindFirstChild("HumanoidRootPart")
			if v23 then
				v_u_11:PlaySound(p22 and v_u_8.Ryu.NotInvited.PowerDash or v_u_8.Ryu.NotInvited.Dash, v23, game.SoundService.Effect)
				for _, v24 in v_u_7.Ryu.Launch:GetChildren() do
					v24:PivotTo(v23.CFrame * CFrame.Angles(1.5707963267948966, 0, 0))
					v_u_1.GetController("MokouController"):ArcTween(v24.Start, true)
				end
			end
		end,
		["Swing"] = function(p25)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v26 = p25:FindFirstChild("HumanoidRootPart")
			if v26 then
				v_u_11:PlaySound(v_u_8.Ryu.NotInvited.Swing, v26, game.SoundService.Effect)
			end
		end,
		["Interp"] = function(p_u_27)
			-- upvalues: (ref) v_u_2, (ref) v_u_7, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8, (ref) v_u_9, (ref) v_u_4
			local v_u_28 = p_u_27.CFrame
			local v_u_29 = tick()
			local v_u_30 = p_u_27:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_28, (copy) p_u_27, (ref) v_u_29
				v_u_28 = p_u_27.CFrame
				v_u_29 = tick()
			end)
			local v_u_31 = nil
			v_u_31 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_27, (ref) v_u_31, (copy) v_u_30, (ref) v_u_28, (ref) v_u_29
				if p_u_27.Parent then
					workspace:BulkMoveTo({ p_u_27 }, { v_u_28 + v_u_28.LookVector * (120 * (tick() - v_u_29)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_31:Disconnect()
					v_u_30:Disconnect()
				end
			end)
			p_u_27.Destroying:Connect(function()
				-- upvalues: (copy) p_u_27, (ref) v_u_7, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8, (ref) v_u_9, (ref) v_u_4
				local v32 = p_u_27.Ring
				local v33 = v_u_7.Megumi.Mahoraga.Rock:Clone()
				v33.Transparency = 1
				v33.Anchored = true
				v33.CFrame = p_u_27.CFrame
				v33.Parent = workspace.Effects
				v32.Parent = v33
				v33.Attachment.Dust:Emit(20)
				v33.Attachment.Hit:Emit(20)
				v33.Attachment.Sparks:Emit(20)
				v_u_3:AddItem(v33, 1.5)
				v_u_11:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v33, game.SoundService.Effect)
				local v34 = (workspace.CurrentCamera.CFrame.Position - p_u_27.Position).Magnitude
				if v34 < 40 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
				if v34 < 100 then
					local v35 = TweenInfo.new(3, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
					for v36, v37 in p_u_27.Rocks:GetChildren() do
						if v36 > 25 then
							continue
						end
						v37.CanCollide = true
						v37.CollisionGroup = "Effects"
						v37.Parent = workspace.Effects
						v_u_3:AddItem(v37, 3)
						v_u_4:Create(v37, v35, {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
					end
				end
			end)
		end,
		["Crunch"] = function(p38, p39, p40, p41)
			-- upvalues: (ref) v_u_9
			if p38:FindFirstChild("HumanoidRootPart") then
				if (workspace.CurrentCamera.CFrame.Position - p39.Position).Magnitude < 40 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
				for _, v42 in p40 do
					local v43 = Instance.new("Part")
					v43.CanCollide = false
					v43.Massless = true
					v43.Position = v42[1]
					v43.Orientation = v42[2]
					v43.Color = v42[3]
					v43.Material = v42[4]
					v43.Size = v42[5]
					v43.Transparency = v42[6]
					if p41 then
						v43.Position = v43.Position + p39.CFrame.LookVector * p41
					end
					v43.Parent = p39.Rocks
					local v44 = Instance.new("Weld")
					v44.C1 = p39.CFrame:ToObjectSpace(v43.CFrame)
					v44.Part1 = v43
					v44.Part0 = p39
					v44.Parent = v43
				end
			end
		end,
		["Hit"] = function(p45, p46, p47)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_7, (ref) v_u_1, (ref) v_u_3, (ref) v_u_9
			local v48 = p45:FindFirstChild("HumanoidRootPart")
			if v48 then
				local v49 = p46:FindFirstChild("HumanoidRootPart")
				if v49 then
					v_u_11:Flash(p46, Color3.new(1, 1, 1))
					local v50 = v_u_11
					local v51 = v_u_8.Ryu.NotInvited.Hit
					local v52
					if v_u_5.Character == p45 then
						v52 = v48 or v49
					else
						v52 = v49
					end
					v50:PlaySound(v51, v52, game.SoundService.Effect)
					local v53 = CFrame.lookAlong(v49.Position, -p47.RightVector)
					for _, v54 in v_u_7.Ryu.Doosh:GetChildren() do
						v54:PivotTo(v53 * CFrame.Angles(1.5707963267948966, 0, 0))
						v_u_1.GetController("MokouController"):ArcTween(v54.Start, true)
					end
					local v55 = v_u_7.Mechamaru.Dust:Clone()
					v55.bigimpact:Destroy()
					v55.Smoke2:Destroy()
					v55.Position = v49.Position - Vector3.new(0, 3, 0)
					v55.Parent = workspace.Effects
					v_u_3:AddItem(v55, 2)
					for _, v56 in v55:GetChildren() do
						v56:Emit(v56:GetAttribute("EmitCount"))
					end
					if v_u_5.Character == p45 or v_u_5.Character == p46 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.SnapOh)
						if _G.Settings.Flash == true then
							local v57 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
							v57.Parent = game.Lighting
							v57.TintColor = Color3.new(1, 1, 1)
							task.wait(0.03)
							v57.Brightness = 200
							v57.Contrast = -1000
							task.wait(0.03)
							v57.Brightness = -200
							v57.Contrast = 1000
							task.wait(0.03)
							v57:Destroy()
						end
					end
				end
			else
				return
			end
		end,
		["PunchWall"] = function(p58, p59)
			-- upvalues: (ref) v_u_7, (ref) v_u_1, (ref) v_u_9
			local v60 = p58:FindFirstChild("HumanoidRootPart")
			if v60 then
				for _, v61 in v_u_7.Misc.M.Awk.mokultMeh["3"]:GetChildren() do
					v61:PivotTo(p59 * CFrame.Angles(1.5707963267948966, 0, 0))
					v_u_1.GetController("MokouController"):ArcTween(v61.Start, true)
				end
				for _, v62 in v_u_7.Ryu.Launch:GetChildren() do
					v62:PivotTo(v60.CFrame * CFrame.Angles(1.5707963267948966, 0, 0))
					v_u_1.GetController("MokouController"):ArcTween(v62.Start, true)
				end
				if (workspace.CurrentCamera.CFrame.Position - p59.Position).Magnitude < 100 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.SnapOh)
					v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(1.8)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p64, ...)
		-- upvalues: (copy) v_u_63
		local v65 = v_u_63[p64]
		if v65 then
			v65(...)
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("WerentInvitedService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12