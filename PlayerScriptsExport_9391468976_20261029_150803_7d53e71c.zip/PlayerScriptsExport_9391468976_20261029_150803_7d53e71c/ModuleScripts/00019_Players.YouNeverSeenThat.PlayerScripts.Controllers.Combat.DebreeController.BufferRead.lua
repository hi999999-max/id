-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Combat.DebreeController.BufferRead
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = game:GetService("EncodingService")
local v_u_2 = Enum.CompressionAlgorithm.Zstd
local function v_u_9(p3, p4) -- name: readF16
	local v5 = p4 * 8
	local v6 = buffer.readbits(p3, v5 + 0, 10)
	local v7 = buffer.readbits(p3, v5 + 10, 5)
	local v8 = buffer.readbits(p3, v5 + 15, 1)
	if v6 == 0 then
		if v7 == 0 then
			return 0
		end
		if v7 == 31 then
			return v8 == 0 and (1 / 0) or (-1 / 0)
		end
	elseif v7 == 31 then
		return (0 / 0)
	end
	if v8 == 0 then
		return (v6 / 1024 + 1) * 2 ^ (v7 - 15)
	else
		return -(v6 / 1024 + 1) * 2 ^ (v7 - 15)
	end
end
local function v_u_16(p10, p11) -- name: readF24
	local v12 = p11 * 8
	local v13 = buffer.readbits(p10, v12 + 0, 17)
	local v14 = buffer.readbits(p10, v12 + 17, 6)
	local v15 = buffer.readbits(p10, v12 + 23, 1)
	if v13 == 0 then
		if v14 == 0 then
			return 0
		end
		if v14 == 63 then
			return v15 == 0 and (1 / 0) or (-1 / 0)
		end
	elseif v14 == 63 then
		return (0 / 0)
	end
	if v15 == 0 then
		return (v13 / 131072 + 1) * 2 ^ (v14 - 31)
	else
		return -(v13 / 131072 + 1) * 2 ^ (v14 - 31)
	end
end
local function v_u_26(p17) -- name: readSizes
	-- upvalues: (copy) v_u_16
	local v18 = buffer.len(p17) // 9
	local v19 = table.create(v18)
	for v20 = 1, v18 do
		local v21 = (v20 - 1) * 9
		local v22 = v_u_16(p17, v21)
		local v23 = v_u_16(p17, v21 + 3)
		local v24 = v_u_16(p17, v21 + 6)
		local v25 = Vector3.new(v22, v23, v24)
		table.insert(v19, v25)
	end
	return v19
end
local function v_u_38(p27) -- name: readColors
	local v28 = buffer.len(p27) // 3
	local v29 = table.create(v28)
	for v30 = 1, v28 do
		local v31 = (v30 - 1) * 3
		local v32 = buffer.readu8(p27, v31) / 255
		local v33 = v31 + 1
		local v34 = buffer.readu8(p27, v33) / 255
		local v35 = v31 + 2
		local v36 = buffer.readu8(p27, v35) / 255
		local v37 = Color3.new
		table.insert(v29, v37(v32, v34, v36))
	end
	return v29
end
local function v_u_44(p39) -- name: readTransparencies
	-- upvalues: (copy) v_u_9
	local v40 = buffer.len(p39) // 2
	local v41 = table.create(v40)
	for v42 = 1, v40 do
		local v43 = v_u_9(p39, (v42 - 1) * 2)
		table.insert(v41, v43)
	end
	return v41
end
return {
	["Sound"] = function(p45, p46) -- name: readSound
		for v47 = 0, buffer.len(p45) - 1, 3 do
			p46((buffer.readbits(p45, v47 * 8, 24)))
		end
	end,
	["MoveIn"] = function(p48) -- name: readMoveIn
		-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_16
		local v49 = v_u_1:DecompressBuffer(p48, v_u_2)
		local v50 = buffer.len(v49) // 18
		local v51 = table.create(v50)
		for v52 = 1, v50 do
			local v53 = (v52 - 1) * 18
			local v54 = v_u_16(v49, v53)
			local v55 = v_u_16(v49, v53 + 3)
			local v56 = v_u_16(v49, v53 + 6)
			local v57 = v_u_16(v49, v53 + 9)
			local v58 = v_u_16(v49, v53 + 12)
			local v59 = v_u_16(v49, v53 + 15)
			local v60 = Vector3.new(v54, v55, v56)
			local v61 = CFrame.new(v60) * CFrame.fromEulerAnglesYXZ(math.rad(v57), math.rad(v58), (math.rad(v59)))
			table.insert(v51, v61)
		end
		return v51
	end,
	["Create"] = function(p62, p63, p64, p65, p66) -- name: readCreate
		-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_26, (copy) v_u_38, (copy) v_u_44, (copy) v_u_16, (copy) v_u_9
		local v67 = v_u_1:DecompressBuffer(p65, v_u_2)
		local v68 = v_u_26(p62)
		local v69 = v_u_38(p63)
		local v70 = v_u_44(p64)
		for v71 = 0, buffer.len(v67) - 1, 23 do
			local v72 = v_u_16(v67, v71)
			local v73 = v_u_16(v67, v71 + 3)
			local v74 = v_u_16(v67, v71 + 6)
			local v75 = v_u_9(v67, v71 + 9)
			local v76 = v_u_9(v67, v71 + 11)
			local v77 = v_u_9(v67, v71 + 13)
			local v78 = v71 + 15
			local v79 = buffer.readbits(v67, v78 * 8, 24)
			local v80 = v71 + 18
			local v81 = buffer.readu16(v67, v80)
			local v82 = v71 + 20
			local v83 = buffer.readu8(v67, v82)
			local v84 = v71 + 21
			local v85 = buffer.readu8(v67, v84)
			local v86 = v71 + 22
			local v87 = buffer.readu8(v67, v86)
			local v88 = Vector3.new(v72, v73, v74)
			p66(v79, CFrame.new(v88) * CFrame.fromEulerAnglesYXZ(math.rad(v75), math.rad(v76), (math.rad(v77))), v68[v83 + 1], v69[v85 + 1], v70[v87 + 1], Enum.Material:FromValue(v81))
		end
	end,
	["Physics"] = function(p89, p90) -- name: readPhysics
		-- upvalues: (copy) v_u_9
		for v91 = 0, buffer.len(p89) - 1, 12 do
			local v92 = v_u_9(p89, v91)
			local v93 = v_u_9(p89, v91 + 2)
			local v94 = v_u_9(p89, v91 + 4)
			local v95 = v91 + 6
			local v96 = buffer.readu8(p89, v95) * 0.024639942381096416
			local v97 = v91 + 7
			local v98 = buffer.readu8(p89, v97) * 0.024639942381096416
			local v99 = v91 + 8
			local v100 = buffer.readu8(p89, v99) * 0.024639942381096416
			local v101 = v91 + 9
			local v102 = buffer.readbits(p89, v101 * 8, 24)
			local v103 = Vector3.new(v92, v93, v94)
			p90(v102, CFrame.new(v103) * CFrame.fromOrientation(v96, v98, v100))
		end
	end,
	["Destroy"] = function(p104, p105) -- name: readDestroy
		-- upvalues: (copy) v_u_1, (copy) v_u_2
		if v_u_1:GetDecompressedBufferSize(p104, v_u_2) and true or false then
			p104 = v_u_1:DecompressBuffer(p104, v_u_2)
		end
		for v106 = 0, buffer.len(p104) - 1, 3 do
			p105((buffer.readbits(p104, v106 * 8, 24)))
		end
	end
}