-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Mahito.PreAwk.SelfPerfectionController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local v_u_6 = v5.Animations
local v_u_7 = v5.Utils
local v_u_8 = v5.Sounds
require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "SelfPerfectionController"
})
function v11.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_10, (copy) v_u_8, (copy) v_u_4, (copy) v_u_6, (copy) v_u_3, (copy) v_u_7, (copy) v_u_2, (ref) v_u_9
	local v_u_72 = {
		["Startup"] = function(p12)
			-- upvalues: (ref) v_u_10, (ref) v_u_8, (ref) v_u_4, (ref) v_u_6, (ref) v_u_3, (ref) v_u_7
			local v13 = p12:FindFirstChild("HumanoidRootPart")
			if v13 then
				v_u_10:PlaySound(v_u_8.Mahito.SelfPerfection.Voice, v13, game.SoundService.Voice)
				v_u_10:DomainBurst(v13)
				local v14 = v_u_4.Character
				if v14 and v14:FindFirstChild("HumanoidRootPart") then
					local v15 = v14:FindFirstChild("HumanoidRootPart")
					if (v13.Position - v15.Position).Magnitude <= 37.5 then
						v_u_10:Domain(p12, function(p16, p17)
							-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_7
							p17.Humanoid:LoadAnimation(v_u_6.Mahito.DomainWarn):Play(0)
							p16.Panel.ImageLabel.Image = "rbxassetid://15049595421"
							p16.Panel.ImageLabel.Size = UDim2.new(0.8, 0, 0.8, 0)
							p16.Panel.Viewport.LightColor = Color3.fromRGB(255, 170, 255)
							p16.Panel.Viewport.Ambient = Color3.fromRGB(50, 30, 50)
							p16.Panel.Viewport.LightDirection = Vector3.new(0, -1, 0)
							v_u_3:Create(p16.Panel.Viewport, TweenInfo.new(1.5), {
								["LightColor"] = Color3.fromRGB(170, 255, 255),
								["Ambient"] = Color3.fromRGB(0, 55, 85)
							}):Play()
							local v18 = v_u_7.Mahito.SelfPerfection.Head:Clone()
							v18.Head.Weld.Part0 = p17.Head
							v18.Mouth.Weld.Part0 = p17.Head
							v18.Head.Transparency = 1
							v18.Mouth.Transparency = 1
							v18.Mouth.Hands.Color = p17.Head.Color
							v18.Parent = p17
						end)
					end
				end
			end
		end,
		["Opening"] = function(p19, p20, p_u_21, p22, p_u_23)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_10, (ref) v_u_8
			local v_u_24 = v_u_7.Mahito.SelfPerfection.DomainBG:Clone()
			v_u_24.Parent = p19
			v_u_24.CFrame = p19.CFrame
			task.spawn(function()
				-- upvalues: (copy) p_u_21, (copy) v_u_24
				repeat
					task.wait()
				until not (p_u_21.Parent and (p_u_21.Parent.Parent and p_u_21.Parent.Parent.Parent))
				v_u_24:Destroy()
			end)
			local v25 = v_u_24.Hands
			local v_u_26 = v25.AnimationController:LoadAnimation(v25.AnimationController.Animation)
			local v27 = TweenInfo.new(1, Enum.EasingStyle.Back, Enum.EasingDirection.InOut)
			for _, v28 in v25:QueryDescendants("BasePart") do
				v28.Size = Vector3.new(0, 0, 0)
			end
			if p22 then
				local v_u_29 = v_u_10:PlaySound(v_u_8.Mahito.SelfPerfection.Music, workspace, game.SoundService.Music, true)
				game.SoundService.AmbientReverb = Enum.ReverbType.Arena
				task.spawn(function()
					-- upvalues: (copy) p_u_21, (ref) v_u_3, (copy) v_u_29, (ref) v_u_2
					repeat
						task.wait()
					until not (p_u_21.Parent and (p_u_21.Parent.Parent and p_u_21.Parent.Parent.Parent))
					game.SoundService.AmbientReverb = Enum.ReverbType.NoReverb
					v_u_3:Create(v_u_29, TweenInfo.new(3), {
						["Volume"] = 0
					}):Play()
					v_u_2:AddItem(v_u_29, 3)
				end)
			else
				local v_u_30 = p20.DomainGround
				v_u_30.Surround.Enabled = true
				v_u_3:Create(v_u_30.Surround, TweenInfo.new(0.8), {
					["ShapePartial"] = 1
				}):Play()
				v_u_2:AddItem(v_u_30, 2)
				task.delay(0.8, function()
					-- upvalues: (ref) v_u_3, (copy) v_u_30, (ref) v_u_10
					v_u_3:Create(v_u_30, TweenInfo.new(0.4), {
						["Transparency"] = 0
					}):Play()
					v_u_10:DomainMapFade(Color3.fromRGB(0, 0, 0), 0.4, 1.6)
				end)
				local v_u_31 = nil
				game.SoundService.AmbientReverb = Enum.ReverbType.Arena
				task.spawn(function()
					-- upvalues: (copy) p_u_21, (ref) v_u_31, (ref) v_u_3, (ref) v_u_2
					repeat
						task.wait()
					until not (p_u_21.Parent and (p_u_21.Parent.Parent and p_u_21.Parent.Parent.Parent))
					game.SoundService.AmbientReverb = Enum.ReverbType.NoReverb
					if v_u_31 then
						v_u_3:Create(v_u_31, TweenInfo.new(3), {
							["Volume"] = 0
						}):Play()
						v_u_2:AddItem(v_u_31, 3)
					end
				end)
				task.wait(1)
				v_u_31 = v_u_10:PlaySound(v_u_8.Mahito.SelfPerfection.Music, workspace, game.SoundService.Music, true)
				task.wait(0.5)
			end
			v_u_24.Stars.Enabled = true
			v_u_24.Rays.Enabled = true
			for _, v32 in v25:GetDescendants() do
				if not v32:IsA("BasePart") then
					continue
				end
				v_u_3:Create(v32, v27, {
					["Size"] = Vector3.new(20, 80, 20)
				}):Play()
			end
			v_u_10:PlaySound(v_u_8.Mahito.SelfPerfection.Perfection, workspace, game.SoundService.Effect)
			v25:SetPrimaryPartCFrame(v_u_24.CFrame * CFrame.new(0, 10, 120))
			v_u_26:Play(0)
			v_u_26:GetMarkerReachedSignal("Loop"):Connect(function()
				-- upvalues: (copy) v_u_26
				v_u_26.TimePosition = 1.5
			end)
			for v33 = 1, 10 do
				local v_u_34 = v33 * 36
				local v_u_35 = CFrame.Angles(0, 0, (math.rad(v_u_34)))
				local v_u_36 = (v_u_24.CFrame * v_u_35 - (v_u_24.CFrame * v_u_35).LookVector * 120).Position
				task.delay(v33 % 2 == 0 and 0 or 0.2, function()
					-- upvalues: (ref) v_u_34, (copy) v_u_35, (copy) v_u_24, (ref) v_u_36, (ref) v_u_7, (copy) p_u_23, (ref) v_u_3
					for v37 = 1, 15 do
						v_u_34 = v37 * 12
						local v38 = v_u_34
						local v39 = v_u_35 * CFrame.Angles(math.rad(v38), 0, 0)
						local v40 = (v_u_24.CFrame * v39 - (v_u_24.CFrame * v39).LookVector * 120).Position
						local v41 = CFrame.new(v_u_36, v40)
						local v42 = v_u_7.Mahito.SelfPerfection.Hand:Clone()
						v42.CFrame = v41
						v42.Parent = v_u_24.HandFolder
						if p_u_23 and v37 <= 8 then
							v42.Size = Vector3.new(10, 10, 30)
							local v43 = v41 + v41.LookVector * 5
							local v44 = CFrame.Angles
							local v45 = math.random(-10, 10)
							local v46 = math.rad(v45)
							local v47 = math.random(-10, 10)
							local v48 = math.rad(v47)
							local v49 = math.random(0, 360)
							v42.CFrame = v43 * v44(v46, v48, (math.rad(v49)))
						else
							local v50 = v_u_3
							local v51 = TweenInfo.new(0.4, Enum.EasingStyle.Back)
							local v52 = {
								["Size"] = Vector3.new(10, 10, 30),
								["CFrame"] = nil
							}
							local v53 = v41 + v41.LookVector * 5
							local v54 = CFrame.Angles
							local v55 = math.random(-10, 10)
							local v56 = math.rad(v55)
							local v57 = math.random(-10, 10)
							local v58 = math.rad(v57)
							local v59 = math.random(0, 360)
							v52.CFrame = v53 * v54(v56, v58, (math.rad(v59)))
							v50:Create(v42, v51, v52):Play()
							task.wait(0.2)
						end
						v_u_36 = v40
						if v_u_24.Parent then
							continue
						end
						return
					end
				end)
			end
		end,
		["Shatter"] = function(p60)
			-- upvalues: (ref) v_u_7, (ref) v_u_2, (ref) v_u_10, (ref) v_u_8, (ref) v_u_3
			local v61 = v_u_7.Domain:Clone()
			v61.Transparency = 1
			v61.CanCollide = false
			v61.Position = p60
			v61.Shatter.Color = ColorSequence.new(Color3.new(0, 0, 0))
			v61.Parent = workspace.Effects
			v_u_2:AddItem(v61, 3)
			for _, v62 in v61:GetChildren() do
				if v62.Name == "Shatter" then
					v62:Emit(100)
				else
					v62:Destroy()
				end
			end
			v_u_10:PlaySound(v_u_8.Itadori.MalevolantShrine.Shatter, v61, game.SoundService.Effect)
			v61.Transparency = 0
			v61.Color = Color3.new(0, 0, 0)
			v_u_3:Create(v61, TweenInfo.new(0.2), {
				["Transparency"] = 1
			}):Play()
			if _G.Settings.DesPHY then
				if (workspace.CurrentCamera.CFrame.Position - v61.Position).Magnitude > 150 then
					return
				end
				local v63 = Random.new()
				local v64 = TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
				for _ = 1, 80 do
					local v65 = v_u_7.Gojo.Shard:Clone()
					local v66 = v63:NextUnitVector().Unit
					local v67 = math.random(1, 8)
					local v68 = math.random
					v65.Size = Vector3.new(0.1, v67, v68(1, 8))
					v65.CFrame = CFrame.lookAlong(p60, v66) * CFrame.Angles(1.5707963267948966, 0, 0) + v66 * 37.5
					v65.CFrame = v65.CFrame * CFrame.Angles(0, math.random(0, 3.141592653589793), 0)
					v65.Color = Color3.new(0, 0, 0)
					v65.CanCollide = true
					v65.CollisionGroup = "Effects"
					v65.Parent = workspace.Effects
					local v69 = math.random(-50, 50)
					local v70 = math.random(-50, 50)
					local v71 = math.random
					v65.RotVelocity = Vector3.new(v69, v70, v71(-50, 50))
					v65.Transparency = 0
					v65.Material = Enum.Material.Neon
					v_u_3:Create(v65, v64, {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_2:AddItem(v65, 4)
				end
			end
		end
	}
	v_u_9.Effects:Connect(function(p73, ...)
		-- upvalues: (copy) v_u_72
		local v74 = v_u_72[p73]
		if v74 then
			v74(...)
		end
	end)
end
function v11.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("SelfPerfectionService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11