-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.MeiMei.MeiMeiController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = Random.new()
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = RaycastParams.new()
v_u_14.FilterType = Enum.RaycastFilterType.Include
v_u_14.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v15 = v_u_1.CreateController({
	["Name"] = "MeiMeiController"
})
function v15.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_2, (copy) v_u_5, (copy) v_u_9, (copy) v_u_3, (copy) v_u_6, (copy) v_u_4, (copy) v_u_14, (ref) v_u_10
	local v_u_117 = {
		["Hit"] = function(p16, p17, p18, p19)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_2
			local v20 = p16:FindFirstChild("HumanoidRootPart")
			if v20 then
				local v21 = p17:FindFirstChild("HumanoidRootPart")
				if v21 then
					if p19 ~= nil then
						p18 = p19
					end
					v_u_12:Flash(p17, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.MeiMei.M1:FindFirstChild("Hit" .. p18), v21, game.SoundService.Effect)
					local v22 = v_u_7.MeiMei.SlashHit:Clone()
					v22.CFrame = CFrame.lookAlong(v21.Position, v20.CFrame.LookVector)
					local v23 = {
						CFrame.Angles(0, 0, -0.17453292519943295),
						CFrame.Angles(0, 0, 0.7853981633974483),
						CFrame.Angles(0, 0, -1.0471975511965976),
						CFrame.Angles(0, 0, 0.7853981633974483)
					}
					if p19 then
						v22.CFrame = v22.CFrame * CFrame.Angles(0, 0, 1.5707963267948966)
					elseif v23[p18] then
						v22.CFrame = v22.CFrame * v23[p18]
					end
					v22.Parent = workspace.Effects
					v_u_2:AddItem(v22, 0.5)
					v_u_12:PlayParticles(v22)
				end
			else
				return
			end
		end,
		["ChaseHit"] = function(p24, p25)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_2
			local v26 = p24:FindFirstChild("HumanoidRootPart")
			if v26 then
				local v27 = p25:FindFirstChild("HumanoidRootPart")
				if v27 then
					v_u_12:Flash(p25, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.MeiMei.M1:FindFirstChild("Hit3"), v27, game.SoundService.Effect).PlaybackSpeed = 0.9
					local v28 = v_u_7.Yuta.SlashHit:Clone()
					v28.CFrame = CFrame.lookAlong(v27.Position, v26.CFrame.LookVector) * CFrame.Angles(0, 0, -0.17453292519943295)
					v28.Slash.Size = NumberSequence.new(3, 0)
					v28.Slash.Lifetime = NumberRange.new(0.2)
					v28.Slash.Color = ColorSequence.new(Color3.fromRGB(34, 48, 56))
					v28.Parent = workspace.Effects
					v_u_2:AddItem(v28, 0.5)
					v28.Slash:Emit(5)
				end
			else
				return
			end
		end,
		["AerialHit"] = function(p29, p30)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (ref) v_u_2
			local v31 = p29:FindFirstChild("HumanoidRootPart")
			if v31 then
				local v32 = p30:FindFirstChild("HumanoidRootPart")
				if v32 then
					v_u_12:Flash(p30, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Itadori.CraniumSmash.Hit2, v32, game.SoundService.Effect)
					if v_u_5.Character == p29 or v_u_5.Character == p30 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					end
					local v33 = CFrame.new(v31.Position, v32.Position - Vector3.new(0, 4, 0))
					local v34 = v_u_7.Gojo.HardHit:Clone()
					v34.CFrame = v33 + v33.LookVector * 4
					v34.Parent = workspace.Effects
					v34.Dust:Emit(5)
					v34.Ring:Emit(5)
					v34.Sparks:Emit(10)
					v_u_2:AddItem(v34, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p35)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_12, (ref) v_u_8
			local v36 = p35.HumanoidRootPart
			if v36 then
				local v37 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v37.CFrame = v36.CFrame * CFrame.new(0, 1, -4)
				v37.Size = Vector3.new(0, 0, 2)
				v37.Parent = workspace.Effects
				v_u_3:Create(v37, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v37, 0.3)
				v_u_12:PlaySound(v_u_8.Misc.Chase, v36, game.SoundService.Effect)
				v_u_12:DustTrail(p35, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p38, p39, p40)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v41 = p38:FindFirstChild("HumanoidRootPart")
			if v41 then
				local v42 = p40 ~= "Up" and p40 ~= "Down" and (p39 or 2) or p40
				v_u_12:PlaySound(v_u_8.MeiMei.M1:FindFirstChild("Swing" .. v42), v41, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p43, p44, p45)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_2
			local v46 = p43.SetAssets:FindFirstChild("MeiMeiAxe")
			if v46 then
				local v47 = v_u_7.MeiMei.CombatTrail:Clone()
				v47.Weld.Part0 = v46.Axe
				v47.Parent = workspace.Effects
				task.wait(p44 == 4 and p45 == nil and 0.75 or 0.35)
				v47.Trail.Enabled = false
				v_u_3:Create(v47, TweenInfo.new(0.1), {
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v47, 0.2)
			end
		end,
		["Launch"] = function(p48, p49)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v50 = p48:FindFirstChild("HumanoidRootPart")
			if v50 then
				local v51 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v51.CFrame = CFrame.new(v50.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v51.Size = Vector3.new(0, 0, 5)
				v51.Parent = workspace.Effects
				v_u_3:Create(v51, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v51.Position + Vector3.new(0, p49, 0)
				}):Play()
				v_u_2:AddItem(v51, 0.3)
				if p49 < 0 then
					v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v50, game.SoundService.Effect)
					v_u_12:DustBreak(v50.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v50.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			end
		end,
		["Flock"] = function(p52)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v53 = p52:FindFirstChild("HumanoidRootPart")
			if v53 then
				v_u_12:PlaySound(v_u_8.MeiMei.Flock, v53, game.SoundService.Effect)
			end
		end,
		["FlockHit"] = function(p54, p55)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v56 = p54:FindFirstChild("HumanoidRootPart")
			if v56 then
				if p55:FindFirstChild("HumanoidRootPart") then
					v_u_12:Flash(p55, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Hiromi.Grapple.Hit, v56, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Jump"] = function(p57, _)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v58 = p57:FindFirstChild("HumanoidRootPart")
			if v58 then
				v_u_12:PlaySound(v_u_8.Gojo.InfiniteVoid.Hits.Hit3, v58, game.SoundService.Effect)
			end
		end,
		["Crowstep"] = function(p59)
			-- upvalues: (ref) v_u_7, (ref) v_u_2
			local v60 = p59:FindFirstChild("HumanoidRootPart")
			if v60 then
				local v61 = v_u_7.MeiMei.Crow:Clone()
				v61:PivotTo(v60.CFrame * CFrame.new(0, -3.5 * p59:GetScale(), 0))
				v61.Parent = workspace.Effects
				v61.HumanoidRootPart.Anchored = false
				v61.HumanoidRootPart.AssemblyLinearVelocity = v60.AssemblyLinearVelocity
				local v62 = v_u_7.Damage.CrowExplode:Clone()
				v62.Parent = workspace.Effects
				v62.Position = v61.PrimaryPart.Position
				v_u_2:AddItem(v62, 4)
				for _, v63 in v62:GetDescendants() do
					if not v63:IsA("ParticleEmitter") or v63.Name == "Sparks" then
						continue
					end
					v63:Emit(v63:GetAttribute("EmitCount"))
				end
			end
		end,
		["UltimateStart"] = function(p64)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v65 = p64:FindFirstChild("HumanoidRootPart")
			if v65 then
				v_u_12:PlaySound(v_u_8.MeiMei.UltStart, v65, game.SoundService.Effect)
			end
		end,
		["CrowUltimate"] = function(p66, p67, p68)
			-- upvalues: (ref) v_u_5
			if p66:FindFirstChild("HumanoidRootPart") then
				if p66 == v_u_5.Character then
					workspace.CurrentCamera.CameraSubject = p67.PrimaryPart
					v_u_5.CameraMinZoomDistance = 5
					while p67 and (p67.Parent and p67:GetAttribute("InControl")) do
						task.wait()
						p68:FireServer(workspace.CurrentCamera.CFrame.Position + workspace.CurrentCamera.CFrame.LookVector * 100)
					end
					if not p67 and p67:GetAttribute("InControl") then
						task.wait(1)
					end
					workspace.CurrentCamera.CameraSubject = v_u_5.Character:WaitForChild("Humanoid")
					v_u_5.CameraMinZoomDistance = game.StarterPlayer.CameraMinZoomDistance
				end
			end
		end,
		["CrowControl"] = function(p69, p70)
			-- upvalues: (ref) v_u_6, (ref) v_u_2
			if p69:FindFirstChild("HumanoidRootPart") then
				local v71 = v_u_6.Utils.MeiMei.CrowControl:Clone()
				v71.Parent = p70.PrimaryPart
				v71.Ring:Emit(5)
				v71.Star:Emit(1)
				v_u_2:AddItem(v71, 0.8)
			end
		end,
		["CrowStart"] = function(_, p72)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			v_u_12:PlaySound(v_u_8.Misc.CrowMad2, p72.PrimaryPart, game.SoundService.Effect).Volume = 0.9
			task.wait(0.1)
			for _ = 1, 2 do
				v_u_12:PlaySound(v_u_8.MeiMei.WingFlap, p72.PrimaryPart, game.SoundService.Effect)
				task.wait(0.1)
			end
		end,
		["CrowHit"] = function(p73, p74, p_u_75)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_6, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9
			local v76 = p73:FindFirstChild("HumanoidRootPart")
			if v76 then
				if p_u_75 then
					v_u_12:PlaySound(v_u_8.MeiMei.BirdoStrike, v76, game.SoundService.Voice)
					v_u_12:PlaySound(v_u_8.MeiMei.CrowHit, p74.PrimaryPart, game.SoundService.Effect)
					task.spawn(function()
						-- upvalues: (ref) v_u_7, (copy) p_u_75, (ref) v_u_3, (ref) v_u_2
						for _ = 1, 5 do
							local v77 = math.random(250, 400) / 10
							local v78 = v_u_7.Gojo.LapseBlue.Throw:Clone()
							v78.Transparency = 0.7
							local v79 = p_u_75
							v78.Position = typeof(v79) == "CFrame" and p_u_75.Position or p_u_75.HumanoidRootPart.Position
							local v80 = math.random(-180, 180)
							local v81 = math.random(-180, 180)
							local v82 = math.random
							v78.Orientation = Vector3.new(v80, v81, v82(-180, 180))
							v78.Size = Vector3.new(0, 0, 7)
							v78.Parent = workspace.Effects
							v_u_3:Create(v78, TweenInfo.new(0.2, Enum.EasingStyle.Quad), {
								["Size"] = nil,
								["Transparency"] = 1,
								["Size"] = Vector3.new(v77, v77, 0)
							}):Play()
							v_u_2:AddItem(v78, 0.2)
							task.wait()
						end
					end)
					task.delay(0.3, function()
						-- upvalues: (ref) v_u_7, (copy) p_u_75, (ref) v_u_3, (ref) v_u_2
						local v83 = v_u_7.Gojo.LapseBlue.LapseBlue.Grab:Clone()
						v83.Weld:Destroy()
						v83.Anchored = true
						local v84 = p_u_75
						v83.Position = typeof(v84) == "CFrame" and p_u_75.Position or p_u_75.HumanoidRootPart.Position
						v83.Size = Vector3.new(50, 50, 50)
						v83.Parent = workspace.Effects
						local v85 = Instance.new("Highlight", v83)
						v85.FillTransparency = 1
						v85.OutlineTransparency = 1
						v_u_3:Create(v83, TweenInfo.new(0.226, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
							["Size"] = Vector3.new(0, 0, 0),
							["Transparency"] = 50
						}):Play()
						v_u_2:AddItem(v83, 0.5)
					end)
					local v86 = v_u_6.Utils.MeiMei.BirdStrikeHit1:Clone()
					local v87 = p74.HumanoidRootPart.CFrame * CFrame.new(0, 0, -2)
					local v88 = CFrame.Angles
					local v89 = v_u_4:NextNumber(-180, 180)
					v86.CFrame = v87 * v88(0, 3.141592653589793, (math.rad(v89)))
					for _, v90 in v86:GetDescendants() do
						if v90:IsA("Beam") then
							v90.TextureSpeed = 10
							v90.TextureLength = 1
							v90.Width1 = 25
							v90.Width0 = 2
							v_u_3:Create(v90, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
								["TextureSpeed"] = 0,
								["TextureLength"] = 0.5,
								["Width1"] = 0,
								["Width0"] = 0
							}):Play()
							local v91 = v90.Parent
							v91.CFrame = v91.CFrame * CFrame.new(0, 0, 12)
							v_u_3:Create(v90.Parent, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
								["CFrame"] = v90.Parent.CFrame * CFrame.new(0, 0, -12)
							}):Play()
						elseif v90.Parent.Name == "Particles" then
							v90.Enabled = true
						end
						v86.Parent = workspace.Effects
						v_u_2:AddItem(v86, 0.5)
					end
					v_u_12:PlayParticles(v86)
				end
				if v_u_5.Character == p73 or v_u_5.Character == p_u_75 or (workspace.CurrentCamera.CFrame.Position - (typeof(p_u_75) == "CFrame" and p_u_75.Position or p_u_75.HumanoidRootPart.Position)).Magnitude < 90 then
					v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.HeavyHit):StartFadeOut(0.5)
				end
			end
		end,
		["CrowSmash"] = function(p92, p93, p_u_94)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_6, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			if p92:FindFirstChild("HumanoidRootPart") then
				if p_u_94 then
					task.spawn(function()
						-- upvalues: (ref) v_u_7, (copy) p_u_94, (ref) v_u_3, (ref) v_u_2
						for _ = 1, 5 do
							local v95 = math.random(350, 500) / 10
							local v96 = v_u_7.Gojo.LapseBlue.Throw:Clone()
							v96.Transparency = 0.7
							local v97 = p_u_94
							v96.Position = typeof(v97) == "CFrame" and p_u_94.Position or p_u_94.HumanoidRootPart.Position
							local v98 = math.random(-180, 180)
							local v99 = math.random(-180, 180)
							local v100 = math.random
							v96.Orientation = Vector3.new(v98, v99, v100(-180, 180))
							v96.Size = Vector3.new(0, 0, 7)
							v96.Parent = workspace.Effects
							v_u_3:Create(v96, TweenInfo.new(0.1, Enum.EasingStyle.Quad), {
								["Size"] = nil,
								["Transparency"] = 1,
								["Size"] = Vector3.new(v95, v95, 0)
							}):Play()
							v_u_2:AddItem(v96, 0.2)
							task.wait()
						end
					end)
					local v101 = v_u_6.Utils.MeiMei.BirdStrikeHit2:Clone()
					local v102 = p93.HumanoidRootPart.CFrame * CFrame.new(0, 0, -2)
					local v103 = CFrame.Angles
					local v104 = v_u_4:NextNumber(-180, 180)
					v101.CFrame = v102 * v103(0, 3.141592653589793, (math.rad(v104)))
					v_u_12:PlayParticles(v101)
					v101.Parent = workspace.Effects
					v_u_3:Create(v101.PointLight, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["Brightness"] = 0
					}):Play()
					v_u_2:AddItem(v101, 2)
					v_u_12:PlaySound(v_u_8.MeiMei.CrowSmash, p_u_94.PrimaryPart, game.SoundService.Effect)
				end
				if v_u_5.Character == p92 or v_u_5.Character == p_u_94 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.SnapOh)
				end
			end
		end,
		["CrowBoom"] = function(p105, _, p106)
			-- upvalues: (ref) v_u_6, (ref) v_u_12, (ref) v_u_3, (ref) v_u_2, (ref) v_u_8, (ref) v_u_9
			if p105:FindFirstChild("HumanoidRootPart") then
				local v107 = v_u_6.Utils.MeiMei.BirdStrikeAOE:Clone()
				v107.Position = p106
				v107.Parent = workspace.Effects
				v_u_12:PlayParticles(v107)
				v_u_3:Create(v107.PointLight, TweenInfo.new(0.75), {
					["Brightness"] = 0
				}):Play()
				v_u_2:AddItem(v107, 3)
				v_u_12:PlaySound(v_u_8.MeiMei.CrowExplode, v107, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - p106).Magnitude < 90 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end,
		["TeleportStart"] = function(p108)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v109 = p108:FindFirstChild("HumanoidRootPart")
			if v109 then
				v_u_12:PlaySound(v_u_8.MeiMei.Teleport, v109, game.SoundService.Effect)
			end
		end,
		["Teleport"] = function(p110, p111, p112)
			-- upvalues: (ref) v_u_14, (ref) v_u_7, (ref) v_u_2
			if p110:FindFirstChild("HumanoidRootPart") then
				local v113 = workspace:Raycast(p111.Position, Vector3.new(-0, -7.5, -0), v_u_14)
				local v114 = workspace:Raycast(p112.Position, Vector3.new(-0, -7.5, -0), v_u_14)
				local v115 = v_u_7.Naoya.Teleport:Clone()
				v115.CFrame = p111
				v115.Parent = workspace.Effects
				v115.Lines.Color = ColorSequence.new(Color3.new(1, 1, 1))
				v115.Lines:Emit(8)
				if v113 then
					v115.Floor.Dust:Emit(30)
				end
				v_u_2:AddItem(v115, 1)
				local v116 = v_u_7.Naoya.Teleport:Clone()
				v116.CFrame = p112
				v116.Parent = workspace.Effects
				v116.Lines.Color = ColorSequence.new(Color3.new(1, 1, 1))
				v116.Lines:Emit(8)
				if v114 then
					v116.Floor.Dust:Emit(30)
				end
				v_u_2:AddItem(v116, 1)
			end
		end
	}
	v_u_10.Effects:Connect(function(p118, ...)
		-- upvalues: (copy) v_u_117
		local v119 = v_u_117[p118]
		if v119 then
			v119(...)
		end
	end)
end
function v15.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13
	v_u_10 = v_u_1.GetService("MeiMeiService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
	v_u_13 = v_u_1.GetController("ToolController")
end
return v15