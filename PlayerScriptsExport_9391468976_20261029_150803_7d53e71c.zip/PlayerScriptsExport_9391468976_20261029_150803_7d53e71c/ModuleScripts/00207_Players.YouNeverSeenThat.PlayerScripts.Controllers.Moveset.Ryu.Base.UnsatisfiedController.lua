-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Ryu.Base.UnsatisfiedController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v_u_4 = game.ReplicatedStorage
local _ = v_u_4.Animations
local v_u_5 = v_u_4.Utils
local v_u_6 = v_u_4.Sounds
local v_u_7 = require(v_u_4.Modules.CameraShaker)
require(v_u_4.Modules.StaticLightning)
local v_u_8 = require(v_u_4.Modules.LightningBeams)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "UnsatisfiedController"
})
function v11.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_10, (copy) v_u_6, (copy) v_u_4, (copy) v_u_3, (copy) v_u_2, (copy) v_u_5, (copy) v_u_8, (copy) v_u_7, (copy) v_u_1, (ref) v_u_9
	local v_u_43 = {
		["Startup"] = function(p12)
			-- upvalues: (ref) v_u_10, (ref) v_u_6
			local v13 = p12:FindFirstChild("HumanoidRootPart")
			if v13 then
				v_u_10:PlaySound(v_u_6.Ryu.Unsatisfied.Weave, v13, game.SoundService.Effect)
				task.wait(0.2)
				v_u_10:ArmFlash(p12["Right Arm"], Color3.fromRGB(170, 255, 255), 0.6)
				task.wait(0.2)
				v_u_10:ArmFlash(p12["Left Arm"], Color3.fromRGB(170, 255, 255), 0.4)
			end
		end,
		["Dash"] = function(p14, p15)
			-- upvalues: (ref) v_u_10, (ref) v_u_6, (ref) v_u_4, (ref) v_u_3, (ref) v_u_2
			local v16 = p14:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_10:PlaySound(v_u_6.Ryu.Unsatisfied.Dash, v16, game.SoundService.Effect)
				local v17 = Instance.new("Model")
				local v18 = v_u_4.Utils.Itadori.RushWind:Clone()
				v18.CFrame = p15 * CFrame.new(0, -1, 0)
				v18.Parent = v17
				v17.Parent = workspace.Effects
				v17:ScaleTo(0.8)
				for _, v19 in v18:GetDescendants() do
					if not v19:IsA("ParticleEmitter") then
						continue
					end
					v19.LockedToPart = true
				end
				v18.Ring:Emit(7)
				v18.Dash1.Dash:Emit(1)
				v18.Dash2.Dash:Emit(1)
				v_u_3:Create(v18, TweenInfo.new(0.6), {
					["CFrame"] = v18.CFrame * CFrame.new(0, 0, -7)
				}):Play()
				v_u_2:AddItem(v17, 2)
			end
		end,
		["Dash2"] = function(p20)
			-- upvalues: (ref) v_u_10
			if p20:FindFirstChild("HumanoidRootPart") then
				v_u_10:DustTrail(p20, 0.6, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Hit"] = function(p21, p22)
			-- upvalues: (ref) v_u_10, (ref) v_u_6, (ref) v_u_5, (ref) v_u_3, (ref) v_u_2
			local v23 = p21:FindFirstChild("HumanoidRootPart")
			if v23 then
				v_u_10:Flash(p21, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_6.Ryu.Unsatisfied["Hit" .. p22], v23, game.SoundService.Effect)
				local v24 = math.random(140, 200) / 10
				local v25 = v_u_5.Gojo.LapseBlue.Throw:Clone()
				v25.Transparency = 0.7
				v25.Position = p21.Head.Position
				local v26 = math.random(-180, 180)
				local v27 = math.random(-180, 180)
				local v28 = math.random
				v25.Orientation = Vector3.new(v26, v27, v28(-180, 180))
				v25.Size = Vector3.new(0, 0, 7)
				v25.Parent = workspace.Effects
				v_u_3:Create(v25, TweenInfo.new(0.1, Enum.EasingStyle.Quad), {
					["Size"] = nil,
					["Transparency"] = 1,
					["Size"] = Vector3.new(v24, v24, 0)
				}):Play()
				v_u_2:AddItem(v25, 0.1)
			end
		end,
		["Hit2"] = function(p_u_29)
			-- upvalues: (ref) v_u_10, (ref) v_u_6, (ref) v_u_5, (ref) v_u_2, (ref) v_u_3, (ref) v_u_8, (ref) v_u_7
			local v_u_30 = p_u_29:FindFirstChild("HumanoidRootPart")
			if v_u_30 then
				v_u_10:Flash(p_u_29, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_6.Ryu.Unsatisfied.FinalHit1, v_u_30, game.SoundService.Effect)
				local v_u_31 = v_u_5.Mahito.CrushingRushdown.DrillImpact:Clone()
				v_u_31.Position = v_u_30.Position
				v_u_31.Parent = workspace.Effects
				v_u_2:AddItem(v_u_31, 1)
				v_u_31.Sparks.Color = ColorSequence.new(Color3.fromRGB(170, 255, 255))
				v_u_31.Wind.Color = v_u_31.Sparks.Color
				v_u_31.Wind2.Color = v_u_31.Sparks.Color
				v_u_31.Sparks:Emit(30)
				v_u_31.Wind2:Emit(7)
				task.spawn(function()
					-- upvalues: (ref) v_u_2, (copy) v_u_31, (ref) v_u_3, (ref) v_u_8, (copy) v_u_30, (copy) p_u_29
					local v32 = Instance.new("Model", workspace.Effects)
					local v33 = Instance.new("Highlight", v32)
					v33.DepthMode = Enum.HighlightDepthMode.Occluded
					v33.FillTransparency = 1
					v33.OutlineColor = Color3.new(0, 0, 0)
					v_u_2:AddItem(v32, 0.6)
					local v34 = Random.new()
					Instance.new("Attachment", v_u_31)
					tick()
					for _ = 1, 7 do
						local v_u_35 = Instance.new("Attachment", v_u_31)
						v_u_35.Position = v34:NextUnitVector() * 30
						v_u_3:Create(v_u_35, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
							["Position"] = v34:NextUnitVector() * 30
						}):Play()
						local v_u_36 = v_u_8.new(v_u_30.RootAttachment, v_u_35, nil, v32)
						if p_u_29:GetAttribute("Moveset") == "Yuta" then
							v_u_36.Color = ColorSequence.new(Color3.fromRGB(223, 108, 255), Color3.fromRGB(90, 118, 219))
							v_u_36.ColorOffsetSpeed = 0
						else
							v_u_36.Color = ColorSequence.new(Color3.fromRGB(108, 104, 219), Color3.fromRGB(90, 118, 219))
						end
						v_u_36.PulseSpeed = 6
						v_u_36.FadeLength = 0.5
						v_u_36.CurveSize0 = math.random(-10, 10)
						v_u_36.CurveSize1 = math.random(-10, 10)
						v_u_36.MaxRadius = 3
						v_u_36.MinRadius = 0
						v_u_36.AnimationSpeed = 10
						v_u_36.MinThicknessMultiplier = 0.2
						v_u_36.MaxThicknessMultiplier = 0.6
						task.delay(0.4, function()
							-- upvalues: (ref) v_u_3, (copy) v_u_35, (copy) v_u_36
							v_u_3:Create(v_u_35, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
								["Position"] = Vector3.new(0, 0, 0)
							}):Play()
							task.wait(0.2)
							v_u_36:Destroy()
						end)
					end
					repeat
						v_u_31.Position = v_u_30.Position
						task.wait()
					until not (v_u_30.Parent and v32.Parent)
				end)
				if (workspace.CurrentCamera.CFrame.Position - v_u_30.Position).Magnitude < 60 then
					v_u_7.CurrentShaker:Shake(v_u_7.Presets.Snap)
				end
			end
		end,
		["HitEnd"] = function(p37, p38)
			-- upvalues: (ref) v_u_10, (ref) v_u_6, (ref) v_u_5, (ref) v_u_2, (ref) v_u_7, (ref) v_u_1
			local v39 = p37:FindFirstChild("HumanoidRootPart")
			if v39 then
				local v40 = p38:FindFirstChild("HumanoidRootPart")
				if v40 then
					v_u_10:Flash(p37, Color3.new(1, 1, 1))
					v_u_10:PlaySound(v_u_6.Ryu.Unsatisfied.FinalHit2, v39, game.SoundService.Effect)
					local v41 = v_u_5.Mahito.CrushingRushdown.DrillImpact:Clone()
					v41.Position = v40.Position
					v41.Parent = workspace.Effects
					v_u_2:AddItem(v41, 1)
					v41.Sparks.Color = ColorSequence.new(Color3.fromRGB(170, 255, 255))
					v41.Wind.Color = v41.Sparks.Color
					v41.Wind2.Color = v41.Sparks.Color
					v41.Sparks:Emit(30)
					v41.Wind2:Emit(7)
					if (workspace.CurrentCamera.CFrame.Position - v39.Position).Magnitude < 60 then
						v_u_7.CurrentShaker:Shake(v_u_7.Presets.HeavyHit)
					end
					task.wait(0.1)
					for _, v42 in v_u_5.Ryu.Launch:GetChildren() do
						v42:PivotTo(v39.CFrame * CFrame.Angles(1.9198621771937625, 0, 0))
						v_u_1.GetController("MokouController"):ArcTween(v42.Start, true)
					end
				end
			else
				return
			end
		end
	}
	v_u_9.Effects:Connect(function(p44, ...)
		-- upvalues: (copy) v_u_43
		local v45 = v_u_43[p44]
		if v45 then
			v45(...)
		end
	end)
end
function v11.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("UnsatisfiedService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11