-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Kurourushi.Base.FesteringStrikesController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local v_u_6 = v_u_5.Animations
local v_u_7 = v_u_5.Utils
local v_u_8 = v_u_5.Sounds
local v_u_9 = require(v_u_5.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "FesteringStrikesController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_11, (copy) v_u_8, (copy) v_u_4, (copy) v_u_9, (copy) v_u_7, (copy) v_u_2, (copy) v_u_3, (ref) v_u_12, (copy) v_u_6, (copy) v_u_5, (ref) v_u_10
	local v_u_145 = {
		["Hit"] = function(p14, p15, p16, p17)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_9, (ref) v_u_7, (ref) v_u_2
			local v18 = p14:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = p15:FindFirstChild("HumanoidRootPart")
				if v19 then
					v_u_11:Flash(p15, Color3.new(1, 1, 1))
					if p17 == nil then
						v_u_11:PlaySound(v_u_8.Kurourushi.FesteringStrikes["Hit" .. p16], v18, game.SoundService.Effect)
						if p14 == v_u_4.Character or p15 == v_u_4.Character then
							v_u_9.CurrentShaker:Shake(p16 >= 3 and v_u_9.Presets.HeavyHit or v_u_9.Presets.MediumHit)
						end
					else
						v_u_11:PlaySound(v_u_8.Kurourushi.FesteringStrikes.FinalHit2, v19, game.SoundService.Effect)
					end
					local v20 = { CFrame.new() * CFrame.Angles(0, 0, 0.2617993877991494), CFrame.new() * CFrame.Angles(0, 0, 2.530727415391778), CFrame.new() * CFrame.Angles(0, 0, -0.6108652381980153) }
					if v20[p16] then
						local v21 = v_u_7.Yuta.SlashHit:Clone()
						v21.CFrame = CFrame.lookAlong(v19.Position + Vector3.new(0, 0.75, 0), v18.CFrame.LookVector)
						v21.CFrame = v21.CFrame * v20[p16]
						v21.Slash.Color = ColorSequence.new(Color3.fromRGB(101, 35, 44))
						v21.Slash.Squash = NumberSequence.new(-1 * (p17 and -2.5 or 1), -10)
						v21.Slash.Size = NumberSequence.new(2 * (p17 and 1.5 or 1), 0)
						v21.Parent = workspace.Effects
						v_u_2:AddItem(v21, 0.5)
						v21.Slash:Emit(5)
					end
				else
					return
				end
			else
				return
			end
		end,
		["Arms"] = function(p22, p23)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_3, (ref) v_u_12, (ref) v_u_6
			local v24 = p22:FindFirstChild("HumanoidRootPart")
			if v24 then
				if p23 then
					local v25 = v_u_11:PlaySound(v_u_8.Kurourushi.FesteringStrikes.Throw, v24, game.SoundService.Effect)
					local v26 = v25.Volume
					v25.Volume = 0
					v_u_3:Create(v25, TweenInfo.new(0.5), {
						["Volume"] = v26
					}):Play()
				end
				v_u_12:PlayArms(p22, v_u_6.Kurourushi.FesteringStrikesArms, v_u_6.Kurourushi.FesteringStrikes)
			end
		end,
		["Clash"] = function(p27, p28)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_2, (ref) v_u_3, (ref) v_u_9
			local v29 = p27:FindFirstChild("HumanoidRootPart")
			if v29 then
				v_u_11:Flash(p28, Color3.new(1, 1, 0.498039), 0.6)
				v_u_11:Flash(p27, Color3.new(1, 1, 0.498039), 0.6)
				v_u_11:PlaySound(v_u_8.Misc.Items.Clash, v29, game.SoundService.Effect)
				local v30 = v_u_7.Misc.Items.Clash.Attachment:Clone()
				v30.Parent = v29
				v_u_2:AddItem(v30, 0.9)
				for _, v31 in v30:GetChildren() do
					if v31:IsA("PointLight") then
						v_u_3:Create(v31, TweenInfo.new(v31:GetAttribute("Duration")), {
							["Brightness"] = 0
						}):Play()
					else
						v31:Emit(v31:GetAttribute("EmitCount"))
					end
				end
				if (workspace.CurrentCamera.CFrame.Position - v29.Position).Magnitude < 150 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end,
		["Slash"] = function(p32, p33, p34)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_5
			local v35 = p32:FindFirstChild("HumanoidRootPart")
			if v35 then
				v_u_11:PlaySound(v_u_8.Kurourushi.FesteringStrikes["Swing" .. p33], v35, game.SoundService.Effect)
				local v36 = v_u_7.Kurourushi.KurourushiSwing:Clone()
				v36.Weld.Part0 = v35
				local v37 = v36.Mesh.VertexColor
				v36.Mesh.VertexColor = v36.Mesh.VertexColor * 2
				if p33 == 1 then
					local v38 = v_u_7.Kurourushi.KurourushiSwing:Clone()
					v38.Weld.Part0 = v35
					local v39 = v38.Mesh.VertexColor
					v38.Mesh.VertexColor = v38.Mesh.VertexColor * 2
					v38.Mesh.Scale = Vector3.new(-0.25, -0.05, -0.25)
					v38.Weld.C0 = CFrame.new(1.5, 0.15, 0) * CFrame.Angles(-0.1308996938995747, 0.4363323129985824, -2.6179938779914944)
					v_u_3:Create(v38.Weld, TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
						["C0"] = CFrame.new(1.5, 0.15, 0) * CFrame.Angles(-0.1308996938995747, -2.6179938779914944, 2.6179938779914944)
					}):Play()
					v_u_3:Create(v38.Mesh, TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["Scale"] = Vector3.new(-0.25, -0.25, -0.25),
						["VertexColor"] = nil,
						["VertexColor"] = v39
					}):Play()
					v_u_3:Create(v38, TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
						["Transparency"] = 1
					}):Play()
					v38.Parent = workspace.Effects
					for _, v40 in v38.SwingWindParticles:GetChildren() do
						v40.RotSpeed = NumberRange.new(90, 180)
					end
					v_u_11:PlayParticles(v38)
					v_u_2:AddItem(v38, 1)
					local v41 = v_u_5.Utils.MeiMei.WindMesh2:Clone()
					v41.Weld.Part0 = v35
					local v42 = v41.Weld
					local v43 = CFrame.new(0, -2, 0)
					local v44 = CFrame.Angles
					local v45 = math.random(-180, 180)
					v42.C0 = v43 * v44(0, math.rad(v45), 0)
					v41.Transparency = 0.975
					v41.Size = Vector3.new(5, 2.5, 5)
					v_u_3:Create(v41, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Size"] = Vector3.new(20, 5, 20),
						["Transparency"] = 1
					}):Play()
					v_u_3:Create(v41.Weld, TweenInfo.new(0.2, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
						["C0"] = v41.Weld.C0 * CFrame.new(0, -0.25, 0) * CFrame.Angles(0, -3.12413936106985, 0)
					}):Play()
					v41.Parent = workspace.Effects
					v_u_2:AddItem(v41, 0.2)
					local v46 = v_u_5.Utils.Kurourushi.KurourushiSwingThinner:Clone()
					v46.Transparency = 0.75
					v46.Mesh.Scale = Vector3.new(0.2, 0.1, 0.2)
					v46.Mesh.VertexColor = Vector3.new(0, 0, 0)
					v46.Weld.Part0 = v35
					v46.Weld.C0 = v38.Weld.C0
					v46.Weld.C1 = CFrame.Angles(0, 3.141592653589793, 0)
					v_u_3:Create(v46.Weld, TweenInfo.new(0.15, Enum.EasingStyle.Linear), {
						["C0"] = CFrame.Angles(-0.1308996938995747, -2.6179938779914944, 2.792526803190927)
					}):Play()
					v_u_3:Create(v46.Mesh, TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["Scale"] = Vector3.new(0.255, 0.3, 0.255)
					}):Play()
					v_u_3:Create(v46, TweenInfo.new(0.15, Enum.EasingStyle.Linear), {
						["Transparency"] = 1
					}):Play()
					v46.Parent = workspace.Effects
					v_u_2:AddItem(v46, 0.15)
					local v47 = v_u_5.Utils.Kurourushi.SwirlMesh1:Clone()
					v47.Transparency = 0.75
					v47.Size = Vector3.new(5, 2, 5)
					v47.Weld.Part0 = v35
					local v48 = v47.Weld
					local v49 = v38.Weld.C0
					local v50 = CFrame.Angles
					local v51 = math.random(-180, 180)
					v48.C0 = v49 * v50(0, math.rad(v51), 0)
					v_u_3:Create(v47.Weld, TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["C1"] = CFrame.Angles(0, -3.0543261909900767, 0)
					}):Play()
					v_u_3:Create(v47, TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["Transparency"] = 1,
						["Size"] = Vector3.new(20, 5, 20)
					}):Play()
					v47.Parent = workspace.Effects
					v_u_2:AddItem(v47, 0.2)
				elseif p33 == 2 then
					local v52 = v_u_7.Kurourushi.KurourushiSwing:Clone()
					v52.Weld.Part0 = v35
					local v53 = v52.Mesh.VertexColor
					v52.Mesh.VertexColor = v52.Mesh.VertexColor * 2
					v52.Mesh.Scale = Vector3.new(-0.225, -0.05, -0.225)
					v52.Weld.C0 = CFrame.new(-1, 1, 0) * CFrame.Angles(0, 0.2617993877991494, -0.6108652381980153)
					v_u_3:Create(v52.Weld, TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
						["C1"] = CFrame.Angles(0, -2.6179938779914944, 0)
					}):Play()
					v_u_3:Create(v52.Mesh, TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["Scale"] = Vector3.new(-0.25, -0.25, -0.25),
						["VertexColor"] = nil,
						["VertexColor"] = v53
					}):Play()
					v_u_3:Create(v52, TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
						["Transparency"] = 1
					}):Play()
					v52.Parent = workspace.Effects
					for _, v54 in v52.SwingWindParticles:GetChildren() do
						v54.RotSpeed = NumberRange.new(180, 360)
					end
					v_u_11:PlayParticles(v52)
					v_u_2:AddItem(v52, 1)
					local v55 = v_u_5.Utils.MeiMei.WindMesh2:Clone()
					v55.Weld.Part0 = v35
					local v56 = v55.Weld
					local v57 = CFrame.new(0, -2, 0)
					local v58 = CFrame.Angles
					local v59 = math.random(-180, 180)
					v56.C0 = v57 * v58(0, math.rad(v59), 0)
					v55.Transparency = 0.95
					v55.Size = Vector3.new(5, 2.5, 5)
					v_u_3:Create(v55, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Size"] = Vector3.new(22.5, 7.5, 22.5),
						["Transparency"] = 1
					}):Play()
					v_u_3:Create(v55.Weld, TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
						["C0"] = v55.Weld.C0 * CFrame.new(0, -0.325, 0) * CFrame.Angles(0, 4.71238898038469, 0)
					}):Play()
					v55.Parent = workspace.Effects
					v_u_2:AddItem(v55, 0.15)
					local v60 = v_u_5.Utils.Kurourushi.KurourushiSwingThinner:Clone()
					v60.Transparency = 0.75
					v60.Mesh.Scale = Vector3.new(0.225, 0.1, 0.225)
					v60.Mesh.VertexColor = Vector3.new(0, 0, 0)
					v60.Weld.Part0 = v35
					v60.Weld.C0 = v52.Weld.C0
					v60.Weld.C1 = CFrame.Angles(0, 3.141592653589793, 0)
					v_u_3:Create(v60.Weld, TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
						["C1"] = v60.Weld.C1 * CFrame.Angles(0, -2.6179938779914944, 0)
					}):Play()
					v_u_3:Create(v60.Mesh, TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["Scale"] = Vector3.new(0.255, 0.3, 0.255)
					}):Play()
					v_u_3:Create(v60, TweenInfo.new(0.15, Enum.EasingStyle.Linear), {
						["Transparency"] = 1
					}):Play()
					v60.Parent = workspace.Effects
					v_u_2:AddItem(v60, 0.15)
					local v61 = v_u_5.Utils.Kurourushi.SwirlMesh1:Clone()
					v61.Transparency = 0.75
					v61.Size = Vector3.new(5, 2, 5)
					v61.Weld.Part0 = v35
					local v62 = v61.Weld
					local v63 = v52.Weld.C0
					local v64 = CFrame.Angles
					local v65 = math.random(-180, 180)
					v62.C0 = v63 * v64(0, math.rad(v65), 0)
					v_u_3:Create(v61.Weld, TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["C1"] = CFrame.Angles(0, -3.0543261909900767, 0)
					}):Play()
					v_u_3:Create(v61, TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["Transparency"] = 1,
						["Size"] = Vector3.new(20, 5, 20)
					}):Play()
					v61.Parent = workspace.Effects
					v_u_2:AddItem(v61, 0.2)
				elseif p33 == 3 and not p34 then
					v36.Mesh.Scale = Vector3.new(-0.225, -0.05, -0.225)
					v36.Weld.C0 = CFrame.new(0.35, -0.1, 0) * CFrame.Angles(0.17453292519943295, -0.08726646259971647, 2.530727415391778)
					v_u_3:Create(v36.Weld, TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
						["C1"] = CFrame.Angles(0, -2.181661564992912, 0)
					}):Play()
					v_u_3:Create(v36.Mesh, TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["Scale"] = Vector3.new(-0.25, -0.25, -0.25),
						["VertexColor"] = nil,
						["VertexColor"] = v37
					}):Play()
					v_u_3:Create(v36, TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
						["Transparency"] = 1
					}):Play()
					v36.Parent = workspace.Effects
					for _, v66 in v36.SwingWindParticles:GetChildren() do
						v66.RotSpeed = NumberRange.new(360, 720)
					end
					v_u_11:PlayParticles(v36)
					v_u_2:AddItem(v36, 1)
					local v67 = v_u_5.Utils.MeiMei.WindMesh2:Clone()
					v67.Weld.Part0 = v35
					local v68 = v67.Weld
					local v69 = CFrame.new(0, -2, 0)
					local v70 = CFrame.Angles
					local v71 = math.random(-180, 180)
					v68.C0 = v69 * v70(0, math.rad(v71), 0)
					v67.Transparency = 0.9
					v67.Size = Vector3.new(5, 2.5, 5)
					v_u_3:Create(v67, TweenInfo.new(0.175, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Size"] = Vector3.new(25, 10, 25),
						["Transparency"] = 1
					}):Play()
					v_u_3:Create(v67.Weld, TweenInfo.new(0.175, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
						["C0"] = v67.Weld.C0 * CFrame.new(0, -0.5, 0) * CFrame.Angles(0, -4.71238898038469, 0)
					}):Play()
					v67.Parent = workspace.Effects
					v_u_2:AddItem(v67, 0.175)
					local v72 = v_u_5.Utils.Kurourushi.KurourushiSwingThinner:Clone()
					v72.Transparency = 0.5
					v72.Mesh.Scale = Vector3.new(0.225, 0.1, 0.225)
					v72.Weld.Part0 = v35
					v72.Weld.C0 = v36.Weld.C0
					v72.Weld.C1 = CFrame.Angles(0, 3.141592653589793, 0)
					v_u_3:Create(v72.Weld, TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
						["C1"] = v72.Weld.C1 * CFrame.Angles(0, -2.181661564992912, 0)
					}):Play()
					v_u_3:Create(v72.Mesh, TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["Scale"] = Vector3.new(0.255, 0.3, 0.255)
					}):Play()
					v_u_3:Create(v72, TweenInfo.new(0.15, Enum.EasingStyle.Linear), {
						["Transparency"] = 1
					}):Play()
					v72.Parent = workspace.Effects
					v_u_2:AddItem(v72, 0.15)
					local v73 = v_u_5.Utils.Kurourushi.SwirlMesh1:Clone()
					v73.Transparency = 0.75
					v73.Size = Vector3.new(5, 2, 5)
					v73.Weld.Part0 = v35
					local v74 = v73.Weld
					local v75 = v36.Weld.C0
					local v76 = CFrame.Angles
					local v77 = math.random(-180, 180)
					v74.C0 = v75 * v76(0, math.rad(v77), 0)
					v_u_3:Create(v73.Weld, TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["C1"] = CFrame.Angles(0, -3.0543261909900767, 0)
					}):Play()
					v_u_3:Create(v73, TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["Transparency"] = 1,
						["Size"] = Vector3.new(20, 5, 20)
					}):Play()
					v73.Parent = workspace.Effects
					v_u_2:AddItem(v73, 0.2)
				end
				local v78 = p32.SetAssets:FindFirstChild("FesteringSword")
				if v78 then
					local v79 = v_u_7.Kurourushi.CombatTrail:Clone()
					local v80 = Instance.new("Model")
					v79.Parent = v80
					v80:ScaleTo(v78:GetScale())
					v_u_2:AddItem(v80, 0.1)
					v79.Weld.Part0 = v78.Union
					v79.Parent = workspace.Effects
					v79.Trail.FaceCamera = false
					task.wait(0.3)
					v79.Trail.Enabled = false
					v_u_3:Create(v79, TweenInfo.new(0.1), {
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v79, 0.2)
				end
			else
				return
			end
		end,
		["Hit2"] = function(p81, p82)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_11, (ref) v_u_2, (ref) v_u_5, (ref) v_u_8, (ref) v_u_9
			local v_u_83 = p81:FindFirstChild("HumanoidRootPart")
			if v_u_83 then
				local v84 = p82:FindFirstChild("HumanoidRootPart")
				if v84 then
					task.spawn(function()
						-- upvalues: (ref) v_u_7, (copy) v_u_83, (ref) v_u_3, (ref) v_u_11, (ref) v_u_2, (ref) v_u_5
						local v_u_85 = v_u_7.Kurourushi.KurourushiSwing:Clone()
						v_u_85.Weld.Part0 = v_u_83
						local v_u_86 = v_u_85.Mesh.VertexColor
						v_u_85.Mesh.VertexColor = v_u_85.Mesh.VertexColor * 2
						v_u_85.Mesh.Scale = Vector3.new(-0.225, -0.05, -0.225)
						v_u_85.Weld.C0 = CFrame.new(0.35, -0.1, 0) * CFrame.Angles(0.17453292519943295, -0.08726646259971647, 2.530727415391778)
						local v_u_87 = CFrame.Angles(0, -2.181661564992912, 0)
						local v_u_88 = v_u_3:Create(v_u_85.Weld, TweenInfo.new(1.4999999999999998, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
							["C1"] = v_u_87
						})
						local v_u_89 = v_u_3:Create(v_u_85.Mesh, TweenInfo.new(1.4999999999999998, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
							["Scale"] = Vector3.new(-0.25, -0.25, -0.25),
							["VertexColor"] = nil,
							["VertexColor"] = v_u_86
						})
						local v_u_90 = v_u_3:Create(v_u_85, TweenInfo.new(1.4999999999999998, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
							["Transparency"] = 1
						})
						v_u_88:Play()
						v_u_89:Play()
						v_u_90:Play()
						v_u_85.Parent = workspace.Effects
						for _, v91 in v_u_85.SwingWindParticles:GetChildren() do
							v91.RotSpeed = NumberRange.new(360, 720)
							v91.TimeScale = 0.1
						end
						v_u_11:PlayParticles(v_u_85)
						v_u_2:AddItem(v_u_85, 3)
						local v_u_92 = v_u_5.Utils.MeiMei.WindMesh2:Clone()
						v_u_92.Weld.Part0 = v_u_83
						local v93 = v_u_92.Weld
						local v94 = CFrame.new(0, -2, 0)
						local v95 = CFrame.Angles
						local v96 = math.random(-180, 180)
						v93.C0 = v94 * v95(0, math.rad(v96), 0)
						v_u_92.Transparency = 0.9
						v_u_92.Size = Vector3.new(5, 2.5, 5)
						local v_u_97 = v_u_92.Weld.C0 * CFrame.new(0, -0.5, 0) * CFrame.Angles(0, -4.71238898038469, 0)
						local v_u_98 = v_u_3:Create(v_u_92, TweenInfo.new(1.7499999999999998, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
							["Size"] = Vector3.new(25, 10, 25),
							["Transparency"] = 1
						})
						local v_u_99 = v_u_3:Create(v_u_92.Weld, TweenInfo.new(1.7499999999999998, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
							["C0"] = v_u_97
						})
						v_u_98:Play()
						v_u_99:Play()
						v_u_92.Parent = workspace.Effects
						v_u_2:AddItem(v_u_92, 3)
						local v_u_100 = v_u_5.Utils.Kurourushi.KurourushiSwingThinner:Clone()
						v_u_100.Transparency = 0.5
						v_u_100.Mesh.Scale = Vector3.new(0.225, 0.1, 0.225)
						v_u_100.Mesh.VertexColor = Vector3.new(0, 0, 0)
						v_u_100.Weld.Part0 = v_u_83
						v_u_100.Weld.C0 = v_u_85.Weld.C0
						v_u_100.Weld.C1 = CFrame.Angles(0, 3.141592653589793, 0)
						local v_u_101 = v_u_100.Weld.C1 * CFrame.Angles(0, -2.181661564992912, 0)
						local v_u_102 = v_u_3:Create(v_u_100.Weld, TweenInfo.new(1.4999999999999998, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
							["C1"] = v_u_101
						})
						local v_u_103 = v_u_3:Create(v_u_100.Mesh, TweenInfo.new(1.4999999999999998, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
							["Scale"] = Vector3.new(0.255, 0.3, 0.255)
						})
						local v_u_104 = v_u_3:Create(v_u_100, TweenInfo.new(1.4999999999999998, Enum.EasingStyle.Linear), {
							["Transparency"] = 1
						})
						v_u_102:Play()
						v_u_103:Play()
						v_u_104:Play()
						v_u_100.Parent = workspace.Effects
						v_u_2:AddItem(v_u_100, 3)
						local v_u_105 = v_u_5.Utils.Kurourushi.SwirlMesh1:Clone()
						v_u_105.Transparency = 0.75
						v_u_105.Size = Vector3.new(5, 2, 5)
						v_u_105.Weld.Part0 = v_u_83
						local v106 = v_u_105.Weld
						local v107 = v_u_85.Weld.C0
						local v108 = CFrame.Angles
						local v109 = math.random(-180, 180)
						v106.C0 = v107 * v108(0, math.rad(v109), 0)
						local v_u_110 = v_u_3:Create(v_u_105.Weld, TweenInfo.new(2, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
							["C1"] = CFrame.Angles(0, -3.0543261909900767, 0)
						})
						local v_u_111 = v_u_3:Create(v_u_105, TweenInfo.new(2, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
							["Transparency"] = 1,
							["Size"] = Vector3.new(20, 5, 20)
						})
						v_u_110:Play()
						v_u_111:Play()
						v_u_105.Parent = workspace.Effects
						v_u_2:AddItem(v_u_105, 3)
						task.delay(0.5, function()
							-- upvalues: (copy) v_u_88, (copy) v_u_89, (copy) v_u_90, (copy) v_u_98, (copy) v_u_99, (copy) v_u_102, (copy) v_u_103, (copy) v_u_104, (copy) v_u_110, (copy) v_u_111, (copy) v_u_85, (ref) v_u_3, (copy) v_u_87, (copy) v_u_86, (copy) v_u_92, (copy) v_u_97, (copy) v_u_100, (copy) v_u_101, (copy) v_u_105
							v_u_88:Cancel()
							v_u_89:Cancel()
							v_u_90:Cancel()
							v_u_98:Cancel()
							v_u_99:Cancel()
							v_u_102:Cancel()
							v_u_103:Cancel()
							v_u_104:Cancel()
							v_u_110:Cancel()
							v_u_111:Cancel()
							for _, v112 in v_u_85.SwingWindParticles:GetChildren() do
								v112.TimeScale = 1
							end
							local v113 = {
								["C1"] = v_u_87
							}
							v_u_3:Create(v_u_85.Weld, TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), v113):Play()
							local v114 = {
								["Scale"] = Vector3.new(-0.25, -0.25, -0.25),
								["VertexColor"] = nil,
								["VertexColor"] = v_u_86
							}
							v_u_3:Create(v_u_85.Mesh, TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), v114):Play()
							v_u_3:Create(v_u_85, TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
								["Transparency"] = 1
							}):Play()
							v_u_3:Create(v_u_92, TweenInfo.new(0.175, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
								["Size"] = Vector3.new(25, 10, 25),
								["Transparency"] = 1
							}):Play()
							local v115 = {
								["C0"] = v_u_97
							}
							v_u_3:Create(v_u_92.Weld, TweenInfo.new(0.175, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), v115):Play()
							local v116 = {
								["C1"] = v_u_101
							}
							v_u_3:Create(v_u_100.Weld, TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), v116):Play()
							v_u_3:Create(v_u_100.Mesh, TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
								["Scale"] = Vector3.new(0.255, 0.3, 0.255)
							}):Play()
							v_u_3:Create(v_u_100, TweenInfo.new(0.15, Enum.EasingStyle.Linear), {
								["Transparency"] = 1
							}):Play()
							v_u_3:Create(v_u_105.Weld, TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
								["C1"] = CFrame.Angles(0, -3.0543261909900767, 0)
							}):Play()
							v_u_3:Create(v_u_105, TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
								["Transparency"] = 1,
								["Size"] = Vector3.new(20, 5, 20)
							}):Play()
						end)
					end)
					if p81.SetAssets:FindFirstChild("FesteringSword") then
						v_u_11:Flash(p82, Color3.new(1, 1, 0.498039), 0.6)
						v_u_11:PlaySound(v_u_8.Kurourushi.FesteringStrikes.FinalHit1, v84, game.SoundService.Effect)
						local v117 = v_u_7.Misc.Items.Clash.Attachment:Clone()
						v117.Parent = p82
						v_u_2:AddItem(v117, 1)
						for _, v118 in v117:GetChildren() do
							if v118:IsA("PointLight") then
								v_u_3:Create(v118, TweenInfo.new(v118:GetAttribute("Duration")), {
									["Brightness"] = 0
								}):Play()
							else
								v118.Color = ColorSequence.new(Color3.fromRGB(141, 49, 63), Color3.fromRGB(0, 0, 0))
								v118:Emit(v118:GetAttribute("EmitCount"))
							end
						end
						v117.ParticleEmitter.Enabled = true
						v117["spikes 1"].Enabled = true
						local v119 = v117.ParticleEmitter.Rate
						local _ = v117.ParticleEmitter.Size
						v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(0.65)
						for v120 = 20, 0, -1 do
							local v121 = v120 / 20
							v117.ParticleEmitter.Rate = v119 * v121
							v117["spikes 1"].Rate = v117["spikes 1"].Rate * v121
							task.wait(0.0325)
						end
					end
				else
					return
				end
			else
				return
			end
		end,
		["Hit3"] = function(p122, p123, p124)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_2
			if p122:FindFirstChild("HumanoidRootPart") then
				local v125 = p123:FindFirstChild("HumanoidRootPart")
				if v125 then
					v_u_11:Flash(p123, Color3.new(1, 1, 1))
					v_u_11:PlaySound(p124 == 3 and v_u_8.Kurourushi.Chokehold.PunchHit1 or v_u_8.Kurourushi.Chokehold.PunchHit2, v125, game.SoundService.Effect).PlaybackSpeed = math.random(90, 110) / 100
					local v126 = math.random(140, 200) / 10
					local v127 = v_u_7.Gojo.LapseBlue.Throw:Clone()
					v127.Transparency = 0.7
					v127.Position = p123.Head.Position
					local v128 = math.random(-180, 180)
					local v129 = math.random(-180, 180)
					local v130 = math.random
					v127.Orientation = Vector3.new(v128, v129, v130(-180, 180))
					v127.Size = Vector3.new(0, 0, 7)
					v127.Parent = workspace.Effects
					v_u_3:Create(v127, TweenInfo.new(0.1, Enum.EasingStyle.Quad), {
						["Size"] = nil,
						["Transparency"] = 1,
						["Size"] = Vector3.new(v126, v126, 0)
					}):Play()
					v_u_2:AddItem(v127, 0.1)
				end
			else
				return
			end
		end,
		["PunchSwing"] = function(p131, p132)
			-- upvalues: (ref) v_u_12, (ref) v_u_11, (ref) v_u_8
			local v133 = p131:FindFirstChild("HumanoidRootPart")
			if v133 then
				local v134 = v_u_12:PlayArms(p131)
				if v134 then
					v_u_11:PlaySound(v_u_8.Kurourushi.FesteringStrikes["PunchSwing" .. p132], v133, game.SoundService.Effect)
					if p132 == 1 then
						local v135 = v134["Right Arm"]
						local v136 = Color3.fromRGB(101, 35, 44)
						if v135.Transparency ~= 1 then
							v_u_11:ArmFlash(v135, v136, 0.25)
						end
						local v137 = p131["Right Arm"]
						local v138 = Color3.fromRGB(101, 35, 44)
						if v137.Transparency ~= 1 then
							v_u_11:ArmFlash(v137, v138, 0.25)
						end
					else
						if p132 == 2 then
							local v139 = v134["Left Arm"]
							local v140 = Color3.fromRGB(101, 35, 44)
							if v139.Transparency ~= 1 then
								v_u_11:ArmFlash(v139, v140, 0.25)
							end
							local v141 = p131["Left Arm"]
							local v142 = Color3.fromRGB(101, 35, 44)
							if v141.Transparency ~= 1 then
								v_u_11:ArmFlash(v141, v142, 0.25)
							end
							task.wait(0.2)
							local v143 = v134["Right Arm"]
							local v144 = Color3.fromRGB(101, 35, 44)
							if v143.Transparency == 1 then
								return
							end
							v_u_11:ArmFlash(v143, v144, 0.45)
						end
						return
					end
				else
					return
				end
			else
				return
			end
		end
	}
	v_u_10.Effects:Connect(function(p146, ...)
		-- upvalues: (copy) v_u_145
		local v147 = v_u_145[p146]
		if v147 then
			v147(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("FesteringStrikesService")
	v_u_11 = v_u_1.GetController("FXController")
	v_u_12 = v_u_1.GetController("KurourushiController")
end
return v13