-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Uro.ThinIceBreakerController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v_u_4 = game.ReplicatedStorage
local _ = v_u_4.Animations
local v_u_5 = v_u_4.Utils
local v_u_6 = v_u_4.Sounds
local v_u_7 = require(v_u_4.Modules.CameraShaker)
require(v_u_4.Modules.StaticLightning)
require(v_u_4.Modules.LightningBeams)
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "ThinIceBreakerController"
})
function v11.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_10, (ref) v_u_9, (copy) v_u_6, (copy) v_u_5, (copy) v_u_2, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (copy) v_u_1, (ref) v_u_8
	local v_u_54 = {
		["Aerial"] = function(p12, p13)
			-- upvalues: (ref) v_u_10
			local v14 = p12:FindFirstChild("HumanoidRootPart")
			if v14 then
				local v15 = p12:FindFirstChild("Humanoid")
				if v15 then
					local v16 = Instance.new("BodyGyro", v14)
					v16.P = 10000
					v16.MaxTorque = Vector3.new(40000, 40000, 40000)
					v15.PlatformStand = true
					local v17 = v_u_10:GetMouseTarget()
					if not v16:GetAttribute("Lock") then
						v16.CFrame = CFrame.new(v14.Position, v17)
					end
					task.wait()
					if p13.Parent then
						continue
					end
					v16:Destroy()
					v15.PlatformStand = false
				end
			else
				return
			end
		end,
		["Startup"] = function(p18)
			-- upvalues: (ref) v_u_9, (ref) v_u_6
			local v19 = p18:FindFirstChild("HumanoidRootPart")
			if v19 then
				v_u_9:PlaySound(v_u_6.Uro.ThinIceBreaker.Start, v19, game.SoundService.Effect)
				v_u_9:ArmFlash(p18["Right Arm"], Color3.fromRGB(255, 133, 172), 0.6)
				v_u_9:ArmFlash(p18["Left Arm"], Color3.fromRGB(255, 133, 172), 0.6)
			end
		end,
		["Crack"] = function(p20, p21, p22, p23)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_9, (ref) v_u_6, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_1
			local v24 = p20:FindFirstChild("HumanoidRootPart")
			if v24 then
				local v25 = p23 or 1
				local v26 = v_u_5.Uro.IceBreaker:Clone()
				v26:ScaleTo(3 * v25)
				v26.SmallShard.Weld.C0 = v26.SmallShard.Weld.C0 - Vector3.new(0, 0, 3.5)
				v26.SmallShard.Weld.Part0 = v24
				v26.Parent = workspace.Effects
				v_u_2:AddItem(v26, p21 + p22 + 1)
				local v27 = Instance.new("Highlight", v26)
				v27.FillColor = Color3.fromRGB(255, 255, 255)
				v27.OutlineColor = Color3.fromRGB(255, 170, 255)
				v27.FillTransparency = 0.9
				v27.OutlineTransparency = 0.8
				v27.DepthMode = Enum.HighlightDepthMode.Occluded
				if p21 == 0.5 then
					v_u_9:PlaySound(v_u_6.Uro.ThinIceBreaker.Die, v24, game.SoundService.Effect)
					v27.FillTransparency = -1
					v27.FillColor = Color3.fromRGB(127, 127, 127)
					if (workspace.CurrentCamera.CFrame.Position - v24.Position).Magnitude < 60 then
						local v_u_28 = v_u_7.CurrentShaker:ShakeSustain(v_u_7.Presets.HeavyHit)
						task.delay(p22, function()
							-- upvalues: (copy) v_u_28
							v_u_28:StartFadeOut(0.3)
						end)
					end
				elseif p21 == 0.15 then
					v27.FillTransparency = -1
					v27.FillColor = Color3.fromRGB(127, 127, 127)
					v26.SmallShard.Weld.C0 = v26.SmallShard.Weld.C0 - Vector3.new(0, 0, 4)
					if (workspace.CurrentCamera.CFrame.Position - v24.Position).Magnitude < 60 then
						v_u_7.CurrentShaker:Shake(v_u_7.Presets.LightHit)
					end
				elseif (workspace.CurrentCamera.CFrame.Position - v24.Position).Magnitude < 60 then
					v_u_7.CurrentShaker:Shake(v_u_7.Presets.LightHit)
				end
				v_u_9:PlaySound(v_u_6.Uro.ThinIceBreaker.Impact, v24, game.SoundService.Effect)
				v_u_3:Create(v26.SmallShard, TweenInfo.new(p21, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = v26.SmallShard.Size * 1.1
				}):Play()
				task.wait(p21)
				v_u_9:PlaySound(v_u_6.Uro.ThinIceBreaker.Crack, v24, game.SoundService.Effect)
				v_u_3:Create(v26.BigShard, TweenInfo.new(p22, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = v26.BigShard.Size * 1.2
				}):Play()
				v26.SmallShard.Transparency = 7
				v26.BigShard.Material = Enum.Material.Glass
				v26.BigShard.Transparency = 5
				if (workspace.CurrentCamera.CFrame.Position - v24.Position).Magnitude < 60 then
					v_u_7.CurrentShaker:Shake(v_u_7.Presets.Snap)
				end
				local v29 = p22 - p21
				task.wait(v29)
				v_u_9:PlaySound(v_u_6.Uro.ThinIceBreaker.Explode, v24, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v24.Position).Magnitude < 60 then
					v_u_7.CurrentShaker:Shake(v_u_7.Presets.Snap)
				end
				local v30 = v26.SmallShard.CFrame
				v26.SmallShard.Material = Enum.Material.Plastic
				v26.BigShard.Material = Enum.Material.Plastic
				local v31 = v_u_5.Itadori.DivergentFist.BlackFlashLaunch:Clone()
				v31.CFrame = v24.CFrame * CFrame.new(2, 1, -5)
				v31.Parent = workspace.Effects
				v31.Wind.Lifetime = NumberRange.new(0.8, 1.2)
				v31.Wind:Emit(10)
				v31.PointLight:Destroy()
				v31.Back1.Back:Emit(1)
				v31.Back2.Back:Emit(1)
				v_u_3:Create(v31.Back1, TweenInfo.new(2), {
					["CFrame"] = v31.Back1.CFrame - v31.Back1.CFrame.LookVector * 20
				}):Play()
				v_u_3:Create(v31.Back2, TweenInfo.new(2), {
					["CFrame"] = v31.Back2.CFrame - v31.Back2.CFrame.LookVector * 20
				}):Play()
				v_u_2:AddItem(v31, 2)
				local v32 = v_u_5.Mechamaru.BoostOnVFX.BoostHit.Meshes.Mesh
				require(v_u_4.Modules.SraikoVFX).EmitMesh(v32, v24.CFrame * v32.Offset.Value)
				if p21 == 0.5 then
					for _, v33 in v_u_5.Misc.M.Awk.mokultMeh["3"]:GetChildren() do
						v33:PivotTo(v24.CFrame * CFrame.Angles(1.5707963267948966, 0, 0))
						v_u_1.GetController("MokouController"):ArcTween(v33.Start, true)
					end
				end
				if _G.Settings.DesPHY then
					if (workspace.CurrentCamera.CFrame.Position - v24.Position).Magnitude > 100 then
						return
					end
					Random.new()
					local v34 = TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
					for _ = 1, 20 do
						local v35 = v_u_5.Gojo.Shard:Clone()
						local v36 = CFrame.Angles
						local v37 = math.random(-60, 60)
						local v38 = math.rad(v37)
						local v39 = math.random(-60, 60)
						local v40 = (v30 * v36(v38, math.rad(v39), 0)).LookVector
						local v41 = math.random(10, 80) / 10
						local v42 = math.random(10, 80) / 10
						v35.Size = Vector3.new(0.2, v41, v42) * v25
						v35.CFrame = v30 * CFrame.new(math.random(-10, 10) * v25, math.random(-5, 10) * v25, 0)
						v35.CFrame = v35.CFrame * CFrame.Angles(0, math.random(0, 3.141592653589793), 0)
						v35.CanCollide = true
						v35.CollisionGroup = "Effects"
						v35.Parent = v26
						v35.Transparency = 5
						v35.Material = Enum.Material.Glass
						local v43 = math.random(-50, 50)
						local v44 = math.random(-50, 50)
						local v45 = math.random
						v35.RotVelocity = Vector3.new(v43, v44, v45(-50, 50))
						v35.Velocity = v40 * math.random(30, 60) + v24.Velocity
						v_u_3:Create(v35, v34, {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
						v_u_2:AddItem(v35, 1)
					end
				end
			end
		end,
		["Hit"] = function(p46, p47)
			-- upvalues: (ref) v_u_9, (ref) v_u_6
			local v48 = p46:FindFirstChild("HumanoidRootPart")
			if v48 then
				v_u_9:Flash(p46, Color3.new(1, 1, 1))
				v_u_9:PlaySound(v_u_6.Ryu.Unsatisfied["Hit" .. p47], v48, game.SoundService.Effect)
			end
		end,
		["HitEnd"] = function(p49, p50)
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_5, (ref) v_u_2
			local v51 = p49:FindFirstChild("HumanoidRootPart")
			if v51 then
				local v52 = p50:FindFirstChild("HumanoidRootPart")
				if v52 then
					v_u_9:Flash(p49, Color3.new(1, 1, 1))
					v_u_9:PlaySound(v_u_6.Ryu.Unsatisfied.FinalHit2, v51, game.SoundService.Effect)
					local v53 = v_u_5.Mahito.CrushingRushdown.DrillImpact:Clone()
					v53.Position = v52.Position
					v53.Parent = workspace.Effects
					v_u_2:AddItem(v53, 1)
					v53.Sparks.Color = ColorSequence.new(Color3.fromRGB(255, 165, 165))
					v53.Wind.Color = v53.Sparks.Color
					v53.Wind2.Color = v53.Sparks.Color
					v53.Sparks:Emit(30)
					v53.Wind2:Emit(7)
				end
			else
				return
			end
		end
	}
	v_u_8.Effects:Connect(function(p55, ...)
		-- upvalues: (copy) v_u_54
		local v56 = v_u_54[p55]
		if v56 then
			v56(...)
		end
	end)
end
function v11.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_8, (copy) v_u_1, (ref) v_u_9, (ref) v_u_10
	v_u_8 = v_u_1.GetService("ThinIceBreakerService")
	v_u_9 = v_u_1.GetController("FXController")
	v_u_10 = v_u_1.GetController("ToolController")
end
return v11