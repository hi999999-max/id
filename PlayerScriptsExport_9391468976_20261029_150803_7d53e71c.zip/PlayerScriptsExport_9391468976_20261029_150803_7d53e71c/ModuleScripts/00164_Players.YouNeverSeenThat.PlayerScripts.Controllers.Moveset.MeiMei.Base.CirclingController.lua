-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.MeiMei.Base.CirclingController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = require(v_u_5.Modules.SraikoVFX)
local v_u_12 = RaycastParams.new()
v_u_12.FilterType = Enum.RaycastFilterType.Include
v_u_12.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_13 = Random.new()
local v14 = v_u_1.CreateController({
	["Name"] = "CirclingController"
})
function v14.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (ref) v_u_10, (copy) v_u_7, (copy) v_u_8, (copy) v_u_5, (copy) v_u_13, (copy) v_u_12, (copy) v_u_11, (copy) v_u_4, (ref) v_u_9
	local v_u_15 = nil
	v_u_15 = {
		["Crush"] = function(_, p16, p17)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_10, (ref) v_u_7, (ref) v_u_8
			local v18 = 0.8 + 0.2 * p17
			local v19 = v_u_6.Hiromi.Shockwave:Clone()
			local v20 = Instance.new("Model")
			v19.Parent = v20
			v20:ScaleTo(v18)
			v_u_2:AddItem(v20, 0.1)
			v19.Position = p16
			v19.Parent = workspace.Effects
			local v21 = v19.CFrame
			local v22 = CFrame.Angles
			local v23 = math.random(-179, 179)
			v19.CFrame = v21 * v22(0, math.rad(v23), 0)
			v_u_3:Create(v19.mesh.Mesh, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
				["Scale"] = Vector3.new(15, 0, 15) * v18
			}):Play()
			v_u_3:Create(v19.mesh.Decal, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
				["Transparency"] = 1
			}):Play()
			v19.Floor.Glow:Emit(1)
			v19.Floor.Ring:Emit(10)
			v_u_2:AddItem(v19, 1.5)
			local v24 = v_u_6.Choso.CounterSwing.Shock:Clone()
			local v25 = Instance.new("Model")
			v24.Parent = v25
			v25:ScaleTo(v18)
			v_u_2:AddItem(v25, 0.1)
			v24.Size = Vector3.new(10, 30, 10) * v18
			v24.CFrame = CFrame.new(p16)
			v24.Parent = workspace.Effects
			v_u_2:AddItem(v24, 0.3)
			v_u_3:Create(v24, TweenInfo.new(0.3), {
				["Size"] = nil,
				["Transparency"] = 1,
				["Position"] = nil,
				["Size"] = Vector3.new(36, 7, 36) * v18,
				["Position"] = v24.Position - Vector3.new(0, 3, 0)
			}):Play()
			local v26 = v_u_6.Choso.CounterSwing.Shock:Clone()
			v26.Size = Vector3.new(20, 10, 20) * v18
			v26.CFrame = CFrame.new(p16)
			v26.Parent = workspace.Effects
			v_u_2:AddItem(v26, 0.2)
			v_u_3:Create(v26, TweenInfo.new(0.2), {
				["Size"] = Vector3.new(0, 36, 0),
				["Transparency"] = 1,
				["Position"] = nil,
				["Position"] = v26.Position + Vector3.new(0, 10, 0)
			}):Play()
			v_u_10:DustBreak(p16 + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
			v_u_10:PlaySound(v_u_7.MeiMei.Crush, v19, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p16).Magnitude < 60 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
			end
		end,
		["DivebombWhoosh"] = function(p27)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v28 = p27.HumanoidRootPart
			if v28 then
				if p27.SetAssets:FindFirstChild("MeiMeiAxe") then
					v_u_10:PlaySound(v_u_7.MeiMei.Circling.AirSlash, v28, game.SoundService.Effect)
					local v_u_29 = v_u_6.MeiMei.Circling.MeiMeiWideSlash3:Clone()
					v_u_29.Weld.Part0 = v28
					v_u_29.Weld.C0 = CFrame.new(0, -1, 0) * CFrame.Angles(0, 0, 3.141592653589793)
					v_u_10:PlayParticles(v_u_29)
					v_u_29.Parent = workspace.Effects
					task.delay(0.25, function()
						-- upvalues: (copy) v_u_29
						v_u_29.Weld:Destroy()
						v_u_29.Anchored = true
					end)
					v_u_2:AddItem(v_u_29, 1.5)
					for v30 = 1, 2 do
						local v31 = v30 == 2 and 180 or 0
						local v32 = v_u_6.MeiMei.Circling.SwingMesh:Clone()
						v32.Transparency = 0.05
						v32.Mesh.Scale = Vector3.new(0.15, 1, 0.15)
						v32.Mesh.VertexColor = Vector3.new(1.5, 1.5, 2.25)
						v32.Weld.Part0 = v28
						v32.Weld.C0 = CFrame.new(0, -1, 0) * CFrame.Angles(3.141592653589793, 1.5707963267948966, 3.141592653589793) * CFrame.Angles(0, 1.0471975511965976, 0) * CFrame.Angles(0, math.rad(v31), 0)
						v_u_3:Create(v32.Weld, TweenInfo.new(0.25, Enum.EasingStyle.Linear), {
							["C0"] = v32.Weld.C0 * CFrame.Angles(0, 3.1066860685499065, 0)
						}):Play()
						v_u_3:Create(v32.Mesh, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
							["Scale"] = Vector3.new(0.5, 0.25, 0.5)
						}):Play()
						v_u_3:Create(v32.Mesh, TweenInfo.new(0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
							["VertexColor"] = Vector3.new(0.5, 0.5, 0.75)
						}):Play()
						v_u_3:Create(v32, TweenInfo.new(0.25, Enum.EasingStyle.Quint, Enum.EasingDirection.In), {
							["Transparency"] = 1
						}):Play()
						v32.Parent = workspace.Effects
						v_u_2:AddItem(v32, 0.25)
					end
					local v33 = v_u_6.MeiMei.Circling.WindMesh2:Clone()
					v33.Weld.Part0 = v28
					local v34 = v33.Weld
					local v35 = CFrame.new(0, -2, 0)
					local v36 = CFrame.Angles
					local v37 = math.random(-180, 180)
					v34.C0 = v35 * v36(0, math.rad(v37), 0)
					v33.Transparency = 0.95
					v33.Size = Vector3.new(10, 2.5, 10)
					v_u_3:Create(v33, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Size"] = Vector3.new(35, 15, 35),
						["Transparency"] = 1
					}):Play()
					v_u_3:Create(v33.Weld, TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
						["C0"] = v33.Weld.C0 * CFrame.new(0, -0.5, 0) * CFrame.Angles(0, -3.12413936106985, 0)
					}):Play()
					v33.Parent = workspace.Effects
					v_u_2:AddItem(v33, 0.15)
				end
			else
				return
			end
		end,
		["DivebombFall"] = function(p38, p39)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_2, (ref) v_u_3, (ref) v_u_5, (ref) v_u_13
			local v40 = p38:FindFirstChild("HumanoidRootPart")
			if v40 then
				local v_u_41 = {}
				local function v_u_45(p_u_42) -- name: Cleanup
					-- upvalues: (copy) v_u_45
					for v43 = #p_u_42, 1, -1 do
						local v44 = p_u_42[v43]
						if not v44 then
							continue
						end
						table.remove(p_u_42, v43)
						if typeof(v44) == "RBXScriptConnection" then
							v44:Disconnect()
						elseif type(v44) == "function" then
							pcall(v44)
						elseif v44:IsA("AnimationTrack") then
							v44:Stop()
						else
							v44:Destroy()
						end
					end
					task.defer(function()
						-- upvalues: (copy) p_u_42, (ref) v_u_45
						if #p_u_42 > 0 then
							v_u_45(p_u_42)
						end
					end)
				end
				p39.AncestryChanged:Connect(function()
					-- upvalues: (copy) v_u_45, (copy) v_u_41
					v_u_45(v_u_41)
				end)
				local v_u_46 = v_u_10:PlaySound(v_u_7.MeiMei.Fall, v40, game.SoundService.Effect)
				local function v47()
					-- upvalues: (copy) v_u_46, (ref) v_u_2, (ref) v_u_3
					if v_u_46 and v_u_46.Parent then
						v_u_2:AddItem(v_u_46, 0.5)
						v_u_3:Create(v_u_46, TweenInfo.new(0.5), {
							["Volume"] = 0
						}):Play()
					end
				end
				table.insert(v_u_41, v47)
				local v48 = v_u_5.Utils.MeiMei.FallStage1:Clone()
				table.insert(v_u_41, v48)
				v48.Weld.Part0 = v40
				v48.Weld.C0 = CFrame.new(0, -2, 0)
				for _, v49 in v48.Attachment:GetChildren() do
					v49.Enabled = true
				end
				v48.Parent = workspace.Effects
				v_u_2:AddItem(v48, 30)
				local v50 = v_u_5.Utils.MeiMei.AxeWindTrail:Clone()
				table.insert(v_u_41, v50)
				v50.Weld.Part0 = p38.SetAssets.MeiMeiAxe.Axe
				v50.Parent = workspace.Effects
				v_u_2:AddItem(v50, 30)
				v50.Transparency = 0.9
				v_u_3:Create(v50, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
					["Transparency"] = 1
				}):Play()
				repeat
					local v51 = v_u_13:NextNumber(0.85, 1.15)
					local v52 = 0.25 * v51
					local v53 = v_u_5.Utils.MeiMei.Circling.WindMesh1:Clone()
					table.insert(v_u_41, v53)
					v53.Decal.Transparency = 0.9
					v53.Mesh.Scale = Vector3.new(0.15, 0.25, 0.25) * v51
					local v54 = v40.CFrame * CFrame.Angles(0, 0, 1.5707963267948966) * CFrame.new(-2 * v51, 0, 0)
					local v55 = CFrame.Angles
					local v56 = math.random(-180, 180)
					v53.CFrame = v54 * v55(math.rad(v56), 0, 0)
					v53.Parent = workspace.Effects
					v_u_3:Create(v53, TweenInfo.new(v52, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
						["CFrame"] = v53.CFrame * CFrame.new(-15 * v51, 0, 0) * CFrame.Angles(-3.12413936106985, 0, 0)
					}):Play()
					v_u_3:Create(v53.Mesh, TweenInfo.new(v52, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["Scale"] = Vector3.new(0.5, 0.2, 0.2) * v51
					}):Play()
					v_u_3:Create(v53.Decal, TweenInfo.new(v52, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v53, v52)
					task.wait(0.175)
				until p39.Value ~= 1 or (v40.Parent == nil or (p38.Parent == nil or p39.Parent == nil))
				if v40.Parent ~= nil and (p38.Parent ~= nil and p39.Parent ~= nil) then
					for _, v57 in v48.Attachment:GetChildren() do
						v57.Enabled = false
					end
					v48.Weld:Destroy()
					v_u_2:AddItem(v48, 0.5)
					if p39.Value == 2 then
						local v58 = v_u_5.Utils.MeiMei.FallStage2:Clone()
						table.insert(v_u_41, v58)
						v58.Weld.Part0 = v40
						v58.Weld.C0 = CFrame.new(0, -2, 0)
						for _, v59 in v58.Attachment:GetChildren() do
							v59.Enabled = true
						end
						v58.Parent = workspace.Effects
						v50.Transparency = 0.8
						v_u_3:Create(v50, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
							["Transparency"] = 1
						}):Play()
						v50.Trail.Lifetime = 0.075
						v50.Trail.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.8), NumberSequenceKeypoint.new(1, 1) })
						local v60 = v_u_5.Utils.MeiMei.Circling.WindMesh1:Clone()
						table.insert(v_u_41, v60)
						v60.Decal.Transparency = 0.5
						v60.Mesh.Scale = Vector3.new(0.15, 0.15, 0.15)
						local v61 = v40.CFrame * CFrame.Angles(0, 0, 1.5707963267948966) * CFrame.new(-4, 0, 0)
						local v62 = CFrame.Angles
						local v63 = math.random(-180, 180)
						v60.CFrame = v61 * v62(math.rad(v63), 0, 0)
						v60.Parent = workspace.Effects
						v_u_3:Create(v60, TweenInfo.new(0.35, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
							["CFrame"] = v60.CFrame * CFrame.new(-10, 0, 0) * CFrame.Angles(-3.12413936106985, 0, 0)
						}):Play()
						v_u_3:Create(v60.Mesh, TweenInfo.new(0.35, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
							["Scale"] = Vector3.new(0.1, 0.75, 0.75)
						}):Play()
						v_u_3:Create(v60.Decal, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v60, 0.35)
						local v64 = v_u_5.Utils.MeiMei.Circling.WindMesh1:Clone()
						table.insert(v_u_41, v64)
						v64.Decal.Transparency = 0.5
						v64.Mesh.Scale = Vector3.new(1, 0.15, 0.15)
						local v65 = v40.CFrame * CFrame.Angles(0, 0, 1.5707963267948966) * CFrame.new(0, 0, 0)
						local v66 = CFrame.Angles
						local v67 = math.random(-180, 180)
						v64.CFrame = v65 * v66(math.rad(v67), 0, 0)
						v64.Parent = workspace.Effects
						v_u_3:Create(v64, TweenInfo.new(0.35, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
							["CFrame"] = v64.CFrame * CFrame.new(-10, 0, 0) * CFrame.Angles(-3.12413936106985, 0, 0)
						}):Play()
						v_u_3:Create(v64.Mesh, TweenInfo.new(0.35, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
							["Scale"] = Vector3.new(0.05, 0.75, 0.75)
						}):Play()
						v_u_3:Create(v64.Decal, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v64, 0.35)
						repeat
							local v68 = v_u_13:NextNumber(0.85, 1.15)
							local v69 = 0.25 * v68
							local v70 = v_u_5.Utils.MeiMei.Circling.WindMesh3:Clone()
							table.insert(v_u_41, v70)
							v70.Decal.Transparency = 0.9
							v70.Mesh.Scale = Vector3.new(0.15, 0.25, 0.25) * v68
							local v71 = v40.CFrame * CFrame.Angles(0, 0, 1.5707963267948966) * CFrame.new(-2 * v68, 0, 0)
							local v72 = CFrame.Angles
							local v73 = math.random(-180, 180)
							v70.CFrame = v71 * v72(math.rad(v73), 0, 0)
							v70.Parent = workspace.Effects
							v_u_3:Create(v70, TweenInfo.new(v69, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
								["CFrame"] = v70.CFrame * CFrame.new(-15 * v68, 0, 0) * CFrame.Angles(-3.12413936106985, 0, 0)
							}):Play()
							v_u_3:Create(v70.Mesh, TweenInfo.new(v69, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
								["Scale"] = Vector3.new(0.35, 0.3, 0.3) * v68
							}):Play()
							v_u_3:Create(v70.Decal, TweenInfo.new(v69, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
								["Transparency"] = 1
							}):Play()
							v_u_2:AddItem(v70, v69)
							local v74 = v_u_13:NextNumber(0.85, 1.15)
							local v75 = v_u_5.Utils.MeiMei.Circling.WindMesh1:Clone()
							table.insert(v_u_41, v75)
							v75.Decal.Transparency = 0.9
							v75.Mesh.Scale = Vector3.new(0.25, 0.25, 0.25) * v74
							local v76 = v40.CFrame * CFrame.Angles(0, 0, 1.5707963267948966) * CFrame.new(-5 * v74, 0, 0)
							local v77 = CFrame.Angles
							local v78 = math.random(-180, 180)
							v75.CFrame = v76 * v77(math.rad(v78), 0, 0)
							v75.Parent = workspace.Effects
							v_u_3:Create(v75, TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
								["CFrame"] = v75.CFrame * CFrame.new(2 * v74, 0, 0) * CFrame.Angles(-3.12413936106985, 0, 0)
							}):Play()
							v_u_3:Create(v75.Mesh, TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
								["Scale"] = Vector3.new(0.2, 0.4, 0.4) * v74
							}):Play()
							v_u_3:Create(v75.Decal, TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
								["Transparency"] = 1
							}):Play()
							v_u_2:AddItem(v75, 0.15)
							task.wait(0.1)
						until p39.Value ~= 2 or (v40.Parent == nil or (p38.Parent == nil or p39.Parent == nil))
						if v40.Parent == nil or (p38.Parent == nil or p39.Parent == nil) then
							return
						end
						for _, v79 in v58.Attachment:GetChildren() do
							v79.Enabled = false
						end
						v58.Weld:Destroy()
						v_u_2:AddItem(v58, 0.75)
						if p39.Value == 3 then
							local v80 = v_u_5.Utils.MeiMei.FallStage3:Clone()
							table.insert(v_u_41, v80)
							v80.Weld.Part0 = v40
							v80.Weld.C0 = CFrame.new(0, -2, 0)
							for _, v81 in v80.Attachment:GetChildren() do
								v81.Enabled = true
							end
							v80.Parent = workspace.Effects
							v50.Transparency = 0.25
							v_u_3:Create(v50, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
								["Transparency"] = 1
							}):Play()
							v50.Trail.Lifetime = 0.1
							v50.Trail.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.75), NumberSequenceKeypoint.new(1, 1) })
							local v82 = v_u_5.Utils.MeiMei.Circling.WindMesh3:Clone()
							table.insert(v_u_41, v82)
							v82.Decal.Transparency = 0.5
							v82.Mesh.Scale = Vector3.new(0.15, 0.25, 0.25)
							local v83 = v40.CFrame * CFrame.Angles(0, 0, 1.5707963267948966) * CFrame.new(-2, 0, 0)
							local v84 = CFrame.Angles
							local v85 = math.random(-180, 180)
							v82.CFrame = v83 * v84(math.rad(v85), 0, 0)
							v82.Parent = workspace.Effects
							v_u_3:Create(v82, TweenInfo.new(0.35, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
								["CFrame"] = v82.CFrame * CFrame.new(-15, 0, 0) * CFrame.Angles(-3.12413936106985, 0, 0)
							}):Play()
							v_u_3:Create(v82.Mesh, TweenInfo.new(0.35, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
								["Scale"] = Vector3.new(0.5, 0.35, 0.35)
							}):Play()
							v_u_3:Create(v82.Decal, TweenInfo.new(0.35, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
								["Transparency"] = 1
							}):Play()
							v_u_2:AddItem(v82, 0.35)
							local v86 = v_u_5.Utils.MeiMei.Circling.WindMesh1:Clone()
							table.insert(v_u_41, v86)
							v86.Decal.Transparency = 0.5
							v86.Mesh.Scale = Vector3.new(0.35, 0.35, 0.35)
							local v87 = v40.CFrame * CFrame.Angles(0, 0, 1.5707963267948966) * CFrame.new(-5, 0, 0)
							local v88 = CFrame.Angles
							local v89 = math.random(-180, 180)
							v86.CFrame = v87 * v88(math.rad(v89), 0, 0)
							v86.Parent = workspace.Effects
							v_u_3:Create(v86, TweenInfo.new(0.25, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
								["CFrame"] = v86.CFrame * CFrame.new(2, 0, 0) * CFrame.Angles(-3.12413936106985, 0, 0)
							}):Play()
							v_u_3:Create(v86.Mesh, TweenInfo.new(0.25, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
								["Scale"] = Vector3.new(0.15, 0.5, 0.5)
							}):Play()
							v_u_3:Create(v86.Decal, TweenInfo.new(0.25, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
								["Transparency"] = 1
							}):Play()
							v_u_2:AddItem(v86, 0.25)
							repeat
								local v90 = Random.new():NextNumber(0.85, 1.15)
								local v91 = 0.15 * v90
								local v92 = v_u_5.Utils.MeiMei.Shock:Clone()
								table.insert(v_u_41, v92)
								v92.Transparency = 0.95
								local v93 = 10 * v90
								v92.Size = vector.create(10, v93, 10)
								local v94 = v40.CFrame * CFrame.Angles(0, 0, 0) * CFrame.new(0, -5 * v90, 0)
								local v95 = CFrame.Angles
								local v96 = math.random(-180, 180)
								v92.CFrame = v94 * v95(0, math.rad(v96), 0)
								v92.Parent = workspace.Effects
								local v97 = v_u_3
								local v98 = TweenInfo.new(v91, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
								local v99 = {
									["CFrame"] = nil,
									["Size"] = nil,
									["Transparency"] = 1,
									["CFrame"] = v92.CFrame * CFrame.new(2 * v90, 0, 0) * CFrame.Angles(0, -3.12413936106985, 0)
								}
								local v100 = 20 * v90
								v99.Size = vector.create(30, v100, 30)
								v97:Create(v92, v98, v99):Play()
								v_u_2:AddItem(v92, v91)
								local v101 = 0.25 * v90
								local v102 = v_u_5.Utils.MeiMei.Circling.WindMesh3:Clone()
								table.insert(v_u_41, v102)
								v102.Decal.Transparency = 0.9
								v102.Mesh.Scale = Vector3.new(0.15, 0.25, 0.25) * v90
								local v103 = v40.CFrame * CFrame.Angles(0, 0, 1.5707963267948966) * CFrame.new(-2 * v90, 0, 0)
								local v104 = CFrame.Angles
								local v105 = math.random(-180, 180)
								v102.CFrame = v103 * v104(math.rad(v105), 0, 0)
								v102.Parent = workspace.Effects
								v_u_3:Create(v102, TweenInfo.new(v101, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
									["CFrame"] = v102.CFrame * CFrame.new(-15 * v90, 0, 0) * CFrame.Angles(-3.12413936106985, 0, 0)
								}):Play()
								v_u_3:Create(v102.Mesh, TweenInfo.new(v101, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
									["Scale"] = Vector3.new(0.5, 0.35, 0.35) * v90
								}):Play()
								v_u_3:Create(v102.Decal, TweenInfo.new(v101, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
									["Transparency"] = 1
								}):Play()
								v_u_2:AddItem(v102, v101)
								local v106 = Random.new():NextNumber(0.85, 1.15)
								local v107 = v_u_5.Utils.MeiMei.Circling.WindMesh1:Clone()
								table.insert(v_u_41, v102)
								v107.Decal.Transparency = 0.9
								v107.Mesh.Scale = Vector3.new(0.35, 0.35, 0.35) * v106
								local v108 = v40.CFrame * CFrame.Angles(0, 0, 1.5707963267948966) * CFrame.new(-5 * v106, 0, 0)
								local v109 = CFrame.Angles
								local v110 = math.random(-180, 180)
								v107.CFrame = v108 * v109(math.rad(v110), 0, 0)
								v107.Parent = workspace.Effects
								v_u_3:Create(v107, TweenInfo.new(0.35, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
									["CFrame"] = v107.CFrame * CFrame.new(6, 0, 0) * CFrame.Angles(-3.12413936106985, 0, 0)
								}):Play()
								v_u_3:Create(v107.Mesh, TweenInfo.new(0.35, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
									["Scale"] = Vector3.new(0.15, 0.6, 0.6) * v106
								}):Play()
								v_u_3:Create(v107.Decal, TweenInfo.new(0.35, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
									["Transparency"] = 1
								}):Play()
								v_u_2:AddItem(v107, 0.35)
								task.wait(0.05)
							until p39.Value ~= 3 or (v40.Parent == nil or (p38.Parent == nil or p39.Parent == nil))
							if v40.Parent == nil or (p38.Parent == nil or p39.Parent == nil) then
								return
							end
							for _, v111 in v80.Attachment:GetChildren() do
								v111.Enabled = false
							end
							v80.Weld:Destroy()
							v_u_2:AddItem(v80, 0.5)
						end
					end
					v50:Destroy()
				end
			else
				return
			end
		end,
		["Start"] = function(p112)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v113 = p112:FindFirstChild("HumanoidRootPart")
			if v113 then
				v_u_10:PlaySound(v_u_7.MeiMei.Circling.Start, v113, game.SoundService.Effect)
			end
		end,
		["Charge"] = function(p114, p115)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_12, (ref) v_u_6, (ref) v_u_11, (ref) v_u_2
			local v116 = p114:FindFirstChild("HumanoidRootPart")
			if v116 then
				local v117 = 0
				if p115 == 1 then
					v_u_10:PlaySound(v_u_7.MeiMei.Circling.Charge1, v116, game.SoundService.Effect)
					v_u_10:Flash(p114, Color3.new(1, 0.666667, 0), 0.45)
					v117 = 0.9
				elseif p115 == 2 then
					v_u_10:PlaySound(v_u_7.MeiMei.Circling.Charge2, v116, game.SoundService.Effect)
					v_u_10:Flash(p114, Color3.new(1, 0, 0), 0.45)
					v117 = 1.15
				end
				local v118 = workspace:Raycast((v116.CFrame * CFrame.new(0, 0, 1)).Position, Vector3.new(-0, -8, -0), v_u_12)
				if v118 then
					for _, v119 in pairs(v_u_6.Nanami.BluntCut.Charge:GetChildren()) do
						if not v119:IsA("Model") then
							continue
						end
						local v120 = v119:Clone()
						v120:ScaleTo(v117)
						local v121 = v_u_11.HandleMesh(v120, CFrame.new(v118.Position, v118.Position + v118.Normal) * CFrame.Angles(-1.5707963267948966, 0, 0))
						v120.Parent = workspace.Effects
						v_u_2:AddItem(v120, v121)
					end
				end
			end
		end,
		["Slash"] = function(p122)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v123 = p122.HumanoidRootPart
			if v123 then
				if p122.SetAssets:FindFirstChild("MeiMeiAxe") then
					v_u_10:PlaySound(v_u_7.MeiMei.Circling.Slash1, v123, game.SoundService.Effect)
					local v124 = v_u_6.MeiMei.Circling.MeiMeiWideSlash1:Clone()
					v124.Weld.Part0 = v123
					v124.Weld.C0 = CFrame.Angles(0, 0, 3.141592653589793)
					v_u_10:PlayParticles(v124)
					v124.Parent = workspace.Effects
					v_u_2:AddItem(v124, 1.5)
					local v125 = v_u_6.MeiMei.Circling.SwingMesh:Clone()
					v125.Transparency = 0.05
					v125.Mesh.Scale = Vector3.new(0.15, 1, 0.15)
					v125.Mesh.VertexColor = Vector3.new(1.5, 1.5, 2.25)
					v125.Weld.Part0 = v123
					v125.Weld.C0 = CFrame.Angles(3.141592653589793, 1.5707963267948966, 3.141592653589793) * CFrame.Angles(0, 1.0471975511965976, 0)
					v_u_3:Create(v125.Weld, TweenInfo.new(0.25, Enum.EasingStyle.Linear), {
						["C0"] = v125.Weld.C0 * CFrame.Angles(0, 3.1066860685499065, 0)
					}):Play()
					v_u_3:Create(v125.Mesh, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Scale"] = Vector3.new(0.5, 0.25, 0.5)
					}):Play()
					v_u_3:Create(v125.Mesh, TweenInfo.new(0.16666666666666666, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["VertexColor"] = Vector3.new(0.5, 0.5, 0.75)
					}):Play()
					v_u_3:Create(v125, TweenInfo.new(0.25, Enum.EasingStyle.Quint, Enum.EasingDirection.In), {
						["Transparency"] = 1
					}):Play()
					v125.Parent = workspace.Effects
					v_u_2:AddItem(v125, 0.25)
					local v126 = v_u_6.MeiMei.Circling.WindMesh2:Clone()
					v126.Weld.Part0 = v123
					local v127 = v126.Weld
					local v128 = CFrame.new(0, -2, 0)
					local v129 = CFrame.Angles
					local v130 = math.random(-180, 180)
					v127.C0 = v128 * v129(0, math.rad(v130), 0)
					v126.Transparency = 0.95
					v126.Size = Vector3.new(10, 2.5, 10)
					v_u_3:Create(v126, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Size"] = Vector3.new(35, 15, 35),
						["Transparency"] = 1
					}):Play()
					v_u_3:Create(v126.Weld, TweenInfo.new(0.35, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
						["C0"] = v126.Weld.C0 * CFrame.new(0, 0.5, 0) * CFrame.Angles(0, 3.12413936106985, 0)
					}):Play()
					v126.Parent = workspace.Effects
				end
			else
				return
			end
		end,
		["Slash2"] = function(p131, p132)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v133 = p131.HumanoidRootPart
			if v133 then
				if p132 == nil then
					v_u_10:PlaySound(v_u_7.MeiMei.Circling.Slash2, v133, game.SoundService.Effect)
				end
				if p131.SetAssets:FindFirstChild("MeiMeiAxe") then
					local v_u_134 = v_u_6.MeiMei.Circling.MeiMeiWideSlash2:Clone()
					v_u_134.Weld.Part0 = v133
					v_u_134.Weld.C0 = CFrame.Angles(0, 0, 2.792526803190927) * CFrame.Angles(0, 3.141592653589793, 0)
					local v135 = v_u_134.Weld
					v135.C1 = v135.C1 * CFrame.Angles(-0.17453292519943295, 0, 0)
					v_u_10:PlayParticles(v_u_134)
					v_u_134.Parent = workspace.Effects
					v_u_2:AddItem(v_u_134.Weld, 0.5)
					v_u_2:AddItem(v_u_134, 2)
					local v136 = v_u_6.MeiMei.Circling.SwingMesh:Clone()
					v136.Transparency = 0.75
					v136.Mesh.Scale = Vector3.new(0.25, 2.5, 0.25)
					v136.Mesh.VertexColor = Vector3.new(1, 1, 1.5)
					v136.Weld.Part0 = v133
					local v137 = v136.Weld
					v137.C1 = v137.C1 * CFrame.Angles(0.08726646259971647, 0, 0)
					v136.Weld.C0 = CFrame.Angles(3.141592653589793, 1.5707963267948966, 3.141592653589793) * CFrame.Angles(0.3490658503988659, 0, 0)
					v_u_3:Create(v136.Weld, TweenInfo.new(0.2, Enum.EasingStyle.Linear), {
						["C0"] = v136.Weld.C0 * CFrame.Angles(0, 3.1066860685499065, 0)
					}):Play()
					v_u_3:Create(v136.Mesh, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Scale"] = Vector3.new(0.5175, 0.575, 0.5175)
					}):Play()
					v_u_3:Create(v136, TweenInfo.new(0.2, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
						["Transparency"] = 1
					}):Play()
					v136.Parent = workspace.Effects
					v_u_2:AddItem(v136, 0.2)
					local v_u_138 = v_u_6.MeiMei.Circling.WindMesh2:Clone()
					v_u_138.Weld.Part0 = v133
					local v139 = v_u_138.Weld
					local v140 = CFrame.new(0, -1, 0)
					local v141 = CFrame.Angles
					local v142 = math.random(-180, 180)
					v139.C0 = v140 * v141(0, math.rad(v142), 0)
					v_u_138.Transparency = 0.985
					v_u_138.Size = Vector3.new(20, 7.5, 20)
					v_u_3:Create(v_u_138, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["Size"] = Vector3.new(45, 10, 45),
						["Transparency"] = 1
					}):Play()
					v_u_3:Create(v_u_138.Weld, TweenInfo.new(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
						["C0"] = v_u_138.Weld.C0 * CFrame.new(0, 0.5, 0) * CFrame.Angles(0, 3.12413936106985, 0)
					}):Play()
					v_u_138.Parent = workspace.Effects
					v_u_2:AddItem(v_u_138, 0.5)
					task.delay(0.25, function()
						-- upvalues: (copy) v_u_134, (copy) v_u_138
						v_u_134.Weld:Destroy()
						v_u_134.Anchored = true
						v_u_138.Weld:Destroy()
						v_u_138.Anchored = true
					end)
				end
			else
				return
			end
		end,
		["Slash3"] = function(p143, p144)
			-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_15, (ref) v_u_10, (ref) v_u_7
			local v145 = p144:FindFirstChild("HumanoidRootPart")
			if v145 then
				if v_u_4.Character == p143 or v_u_4.Character == p144 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
				v_u_15.Slash2(p143, true)
				v_u_10:PlaySound(v_u_7.MeiMei.Circling.FinisherWhoosh, v145, game.SoundService.Effect)
			end
		end,
		["Hit1"] = function(p146, p147)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v148 = p147:FindFirstChild("HumanoidRootPart")
			if v148 then
				v_u_10:Flash(p147, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.MeiMei.Circling.Hit1, v148, game.SoundService.Effect)
				if v_u_4.Character == p146 or v_u_4.Character == p147 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Hit2"] = function(p149, p150)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v151 = p150:FindFirstChild("HumanoidRootPart")
			if v151 then
				v_u_10:Flash(p150, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.MeiMei.Circling.Hit2, v151, game.SoundService.Effect)
				if v_u_4.Character == p149 or v_u_4.Character == p150 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["Hit3"] = function(p152, p153, p154)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v155 = p153:FindFirstChild("HumanoidRootPart")
			if v155 then
				local v156 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v156.Position = v155.Position
				v156.Parent = workspace.Effects
				v_u_2:AddItem(v156, 1)
				v156.Sparks.Color = ColorSequence.new(Color3.new(0.513725, 0.643137, 1))
				v156.Wind.Color = v156.Sparks.Color
				v156.Wind2.Color = v156.Sparks.Color
				v156.Sparks:Emit(30)
				v156.Wind2:Emit(7)
				v_u_10:Flash(p153, Color3.new(1, 1, 1))
				if p154 then
					v_u_10:PlaySound(v_u_7.MeiMei.Circling.FinisherHit, v155, game.SoundService.Effect)
					if v_u_4.Character == p152 or v_u_4.Character == p153 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.SnapOh)
					end
					local v157 = Instance.new("Attachment", p153.Torso)
					local v158 = v_u_6.Itadori.CrushingBlow.Floor.Wind2:Clone()
					v158.Color = ColorSequence.new(Color3.new(1, 1, 1))
					v158.LockedToPart = true
					v158.Parent = v157
					v158.EmissionDirection = Enum.NormalId.Left
					v158:Emit(8)
					v_u_2:AddItem(v157, 1.5)
				else
					v_u_10:PlaySound(v_u_7.MeiMei.Circling.Hit2, v155, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Finisher"] = function(p159)
			-- upvalues: (ref) v_u_10
			if p159:FindFirstChild("HumanoidRootPart") then
				v_u_10:Bleed(p159)
			end
		end,
		["Hit4"] = function(p160, p161)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v162 = p161:FindFirstChild("HumanoidRootPart")
			if v162 then
				v_u_10:Flash(p161, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.MeiMei.Circling.FinisherSlash, v162, game.SoundService.Effect)
				if v_u_4.Character == p160 or v_u_4.Character == p161 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end
	}
	v_u_9.Effects:Connect(function(p163, ...)
		-- upvalues: (ref) v_u_15
		local v164 = v_u_15[p163]
		if v164 then
			v164(...)
		end
	end)
end
function v14.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("CirclingService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v14