-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Reggie.Base.FlecheController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = require(v_u_5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "FlecheController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (ref) v_u_12, (copy) v_u_7, (copy) v_u_4, (copy) v_u_8, (copy) v_u_5, (copy) v_u_3, (copy) v_u_9, (ref) v_u_10
	local v_u_41 = {
		["Hit"] = function(p14, p15)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v16 = p14:FindFirstChild("HumanoidRootPart")
			if v16 then
				local v17 = p15:FindFirstChild("HumanoidRootPart")
				if v17 then
					local v18 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
					v18.CFrame = v16.CFrame * CFrame.new(0, 0, -9) * CFrame.Angles(1.5707963267948966, 0, 0)
					v18.Parent = workspace.Effects
					v_u_2:AddItem(v18, 1)
					v18.Sparks.Color = ColorSequence.new(Color3.fromRGB(67, 67, 67))
					v18.Wind.Color = v18.Sparks.Color
					v18.Wind2.Color = v18.Sparks.Color
					v18.Sparks.SpreadAngle = Vector2.new(45, -45)
					v18.Sparks:Emit(20)
					v18.Wind2:Emit(7)
					v_u_12:Flash(p15, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Reggie.Fleche.Hit, v17, game.SoundService.Effect)
					if v_u_4.Character == p14 or v_u_4.Character == p15 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
					end
				end
			else
				return
			end
		end,
		["Hit2"] = function(p19, p20)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			if p19:FindFirstChild("HumanoidRootPart") then
				local v21 = p20:FindFirstChild("HumanoidRootPart")
				if v21 then
					v_u_12:Flash(p20, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Reggie.Fleche.HitOpen, v21, game.SoundService.Effect)
					if v_u_4.Character == p20 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["Dash"] = function(p22)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_5, (ref) v_u_2, (ref) v_u_6, (ref) v_u_3
			local v_u_23 = p22:FindFirstChild("HumanoidRootPart")
			if v_u_23 then
				v_u_12:PlaySound(v_u_7.Reggie.Fleche.Dash, v_u_23, game.SoundService.Effect)
				local v24 = Instance.new("Model")
				local v25 = v_u_5.Utils.Itadori.RushWind:Clone()
				v25.CFrame = v_u_23.CFrame * CFrame.new(0, -1, 0)
				v25.Parent = v24
				v24.Parent = workspace.Effects
				v24:ScaleTo(0.6)
				v25.Ring:Emit(7)
				v25.Dash1.Dash:Emit(1)
				v25.Dash2.Dash:Emit(1)
				v_u_2:AddItem(v24, 2)
				local v26 = v_u_6.Itadori.Shock:Clone()
				v26.CFrame = v_u_23.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v26.Parent = workspace.Effects
				v_u_3:Create(v26, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(8, 0, 8),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v26, 0.2)
				task.delay(0.1, function()
					-- upvalues: (ref) v_u_6, (copy) v_u_23, (ref) v_u_3, (ref) v_u_2
					local v27 = v_u_6.Itadori.Shock:Clone()
					v27.CFrame = (v_u_23.CFrame - v_u_23.CFrame.Position + v_u_23.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
					v27.Parent = workspace.Effects
					v_u_3:Create(v27, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v27, 0.2)
				end)
			end
		end,
		["Pull"] = function(p28, p29)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_9
			if p28:FindFirstChild("HumanoidRootPart") then
				local v30 = p29:FindFirstChild("HumanoidRootPart")
				if v30 then
					v_u_12:Flash(p29, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Reggie.Fleche.PullOut, v30, game.SoundService.Effect)
					for _ = 1, 8 do
						v_u_9:Blood(p29.Torso.CFrame, math.random(5, 55), 25, 25)
					end
				end
			else
				return
			end
		end,
		["Drop"] = function(p31)
			-- upvalues: (ref) v_u_2
			local v32 = p31:Clone()
			v32.Weld:Destroy()
			for _, v33 in v32:GetDescendants() do
				if not v33:IsA("BasePart") then
					continue
				end
				v33.CollisionGroup = "NoPlayerCollision"
				v33.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
				if v33.Name == "Open" and v33.Transparency ~= 1 then
					v33.CanCollide = true
				else
					if v33.Name == "Open" then
						continue
					end
					v33.CanCollide = true
				end
			end
			v32:PivotTo(p31:GetPivot())
			v32.Parent = workspace.Effects
			v_u_2:AddItem(v32, 2)
		end,
		["Open"] = function(p34, p35)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v36 = p34:FindFirstChild("HumanoidRootPart")
			if v36 then
				p35.Open.Transparency = 0
				p35.Closed.Transparency = 1
				local v37 = v36.CFrame * CFrame.new(0, -1, 0)
				local v38 = v_u_6.Itadori.DivergentFist.BlackFlashLaunch:Clone()
				local v39 = Instance.new("Model")
				v38.Parent = v39
				v39:ScaleTo(0.5)
				v_u_2:AddItem(v39, 0.2)
				v38.CFrame = v37 * CFrame.new(0, 0, -6.5) * CFrame.Angles(0, 3.141592653589793, 0)
				v38.Parent = workspace.Effects
				v38.Wind:Emit(10)
				v38.PointLight:Destroy()
				v38.Wind.Lifetime = NumberRange.new(0.9, 1.5)
				v38.Back1.Back.Size = NumberSequence.new(0)
				v38.Back2.Back.Size = NumberSequence.new(0)
				v_u_2:AddItem(v38, 3)
				local v40 = v_u_6.Choso.CounterSwing.Shock:Clone()
				v40.Size = Vector3.new(3, 15, 3)
				v40.CFrame = v37 * CFrame.Angles(1.5707963267948966, 0, 0)
				v40.Parent = workspace.Effects
				v_u_2:AddItem(v40, 0.2)
				v_u_3:Create(v40, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(17.5, 0, 17.5),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v40.Position + v37.LookVector * 10
				}):Play()
				v_u_12:PlaySound(v_u_7.Reggie.Fleche.Unleash, v36, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_7.Reggie.Fleche.UnleashWhoosh, v36, game.SoundService.Effect)
				if v_u_4.Character == p34 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p42, ...)
		-- upvalues: (copy) v_u_41
		local v43 = v_u_41[p42]
		if v43 then
			v43(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("FlecheService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13