-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Hanami.Awake.FlowerBeamController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
require(v5.Modules.BloodyZee)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "FlowerBeamController"
})
local v_u_13 = Random.new()
local v_u_14 = workspace.CurrentCamera
Color3.fromRGB(128, 187, 219)
Color3.new(1, 1, 1)
local function v_u_33(p15, p16, p17) -- name: drawBeam
	local v18 = p17.Z - 45 - p17.X / 2
	local v19 = math.max(v18, 0)
	local v20 = p15.BlackStart.Size.X
	p15.BlackStart.CFrame = p16 * CFrame.new(0, 0, -22.5) * CFrame.Angles(-1.5707963267948966, 0, 0)
	local v21 = p15.BlackStart
	local v22 = p17.X
	local v23 = p17.Y
	v21.Size = Vector3.new(v22, 45, v23)
	p15.PinkStart.CFrame = p15.BlackStart.CFrame
	p15.PinkStart.Size = p15.BlackStart.Size * Vector3.new(0.6, 1, 0.6)
	p15.BlackMiddle.CFrame = p16 * CFrame.new(0, 0, -(v19 / 2 + 45)) * CFrame.Angles(-1.5707963267948966, 0, 0)
	local v24 = p15.BlackMiddle
	local v25 = p17.X
	local v26 = p17.Y
	v24.Size = Vector3.new(v25, v19, v26)
	p15.PinkMiddle.CFrame = p15.BlackMiddle.CFrame
	p15.PinkMiddle.Size = p15.BlackMiddle.Size * Vector3.new(0.6, 1, 0.6)
	p15.BlackEnd.CFrame = p16 * CFrame.new(0, 0, -(v19 + 45 + p17.X / 4)) * CFrame.Angles(1.5707963267948966, 0, 0)
	local v27 = p15.BlackEnd
	local v28 = p17.X
	local v29 = p17.X / 2
	local v30 = p17.X
	v27.Size = Vector3.new(v28, v29, v30)
	p15.PinkEnd.CFrame = p15.BlackEnd.CFrame
	p15.PinkEnd.Size = p15.BlackEnd.Size * Vector3.new(0.6, 1, 0.6)
	for _, v31 in p15:GetDescendants() do
		if not v31:IsA("Beam") then
			continue
		end
		local v32 = v20 / v31.CurveSize0
		v31.CurveSize0 = p17.X / v32
	end
end
local function v_u_38(p34) -- name: shootSpec
	-- upvalues: (copy) v_u_6, (copy) v_u_3
	local v35 = v_u_6.Yuta.LoveBeam.BlackSpec:Clone()
	v35.Color = Color3.new(1, 1, 1)
	v35.CFrame = p34.PinkStart.CFrame * CFrame.new(0, -10, 0)
	v35.Parent = p34
	local v36 = p34.BlackMiddle.Size.X
	local v37 = p34.BlackMiddle.Size.Y
	v_u_3:Create(v35, TweenInfo.new(0.3), {
		["Size"] = Vector3.new(v36, 20, v36),
		["CFrame"] = v35.CFrame * CFrame.new(0, v37 / 2, 0)
	}):Play()
	task.wait(0.2)
	v_u_3:Create(v35, TweenInfo.new(0.3), {
		["Size"] = Vector3.new(v36, 0, v36),
		["CFrame"] = p34.PinkStart.CFrame * CFrame.new(0, v37, 0)
	}):Play()
	task.wait(0.3)
	v35:Destroy()
end
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (ref) v_u_10, (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (copy) v_u_8, (copy) v_u_14, (copy) v_u_1, (copy) v_u_33, (copy) v_u_13, (copy) v_u_38, (ref) v_u_9
	local v_u_74 = {
		["Windup"] = function(p39)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_8
			if p39 then
				local v40 = p39:FindFirstChild("Left Arm")
				if v40 then
					local v41 = v_u_6.Hanami.Beam.Windup:Clone()
					v41.Parent = v40
					v_u_2:AddItem(v41, 0.8)
					v_u_10:PlaySound(v_u_7.Hanami.FlowerBeam.Windup, v40, game.SoundService.Effect)
					if v_u_4:DistanceFromCharacter(v40.Position) < 40 then
						local v42 = TweenInfo.new(1)
						v_u_3:Create(v41.PointLight, v42, {
							["Range"] = 12,
							["Brightness"] = 2
						}):Play()
						v_u_3:Create(game.Lighting, v42, {
							["ExposureCompensation"] = -2
						}):Play()
						local v_u_43 = v_u_8.CurrentShaker:ShakeSustain(v_u_8.Presets.LightHit)
						v41.AncestryChanged:Once(function()
							-- upvalues: (ref) v_u_3, (copy) v_u_43
							v_u_3:Create(game.Lighting, TweenInfo.new(0.1), {
								["ExposureCompensation"] = 0
							}):Play()
							v_u_43:StartFadeOut(0.2)
						end)
					end
					for _ = 1, 8 do
						local v44 = v41.Spark2
						v44.Rate = v44.Rate + 5
						local v45 = v41.Spark
						v45.Rate = v45.Rate + 5
						task.wait(0.05)
					end
				end
			else
				return
			end
		end,
		["StartBeam"] = function(p_u_46)
			-- upvalues: (ref) v_u_14, (ref) v_u_8, (ref) v_u_6, (ref) v_u_1, (ref) v_u_33, (ref) v_u_10, (ref) v_u_7, (ref) v_u_13, (ref) v_u_38, (ref) v_u_3
			local v_u_47 = p_u_46:GetAttribute("BeamStartCFrame")
			local v48 = v_u_14.CFrame
			local v49 = v_u_47.Position - v48.Position
			if v49.Unit:Dot(v48.LookVector) >= 0.7 and v49.Magnitude < 70 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.SnapOh)
			end
			for _, v50 in v_u_6.Misc.M.Awk.mokultMeh["3"]:GetChildren() do
				v50:PivotTo(v_u_47 * CFrame.Angles(1.5707963267948966, 0, 0))
				v_u_1.GetController("MokouController"):ArcTween(v50.Start, true)
			end
			for _, v51 in v_u_6.Ryu.Launch:GetChildren() do
				v51:PivotTo(v_u_47 * CFrame.Angles(1.5707963267948966, 0, 0))
				v_u_1.GetController("MokouController"):ArcTween(v51.Start, true)
			end
			local v_u_52 = v_u_6.Hanami.Beam.FlowerBeam:Clone()
			local v_u_53 = Instance.new("Vector3Value")
			v_u_53.Value = Vector3.new(30, 30, 180)
			v_u_33(v_u_52, v_u_47 * CFrame.new(0, 0, -5), (Vector3.new(30, 30, p_u_46:GetAttribute("BeamLength"))))
			v_u_52.Parent = workspace.Effects
			v_u_10:PlaySound(v_u_7.Hanami.FlowerBeam.Shoot, v_u_52.PinkStart, game.SoundService.Effect)
			local _ = v_u_47 * CFrame.new(0, 0, -3)
			local v_u_54 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_6, (ref) v_u_14, (ref) v_u_47, (ref) v_u_8, (ref) v_u_54, (ref) v_u_13, (copy) p_u_46, (ref) v_u_33, (copy) v_u_52, (copy) v_u_53
				local v55 = v_u_6.Yuta.LoveBeam.CameraFX:Clone()
				v55.TintColor = Color3.fromRGB(170, 255, 255)
				local v56
				if (v_u_14.CFrame.Position - v_u_47.Position).Magnitude < 180 then
					v56 = v_u_8.CurrentShaker:ShakeSustain(v_u_8.Presets.HeavyHit)
				else
					v56 = nil
				end
				local v57 = v_u_54 and Vector3.new(1, 1, 0) * v_u_13:NextNumber(1, 5) or Vector3.new(0, 0, 0)
				v_u_47 = p_u_46:GetAttribute("BeamStartCFrame")
				local v58 = p_u_46
				v_u_33(v_u_52, v_u_47, v_u_53.Value * Vector3.new(1, 1, 0) + v57 + Vector3.new(0, 0, v58:GetAttribute("BeamLength")))
				local v59, v60 = v_u_52:GetBoundingBox()
				local v61 = v60 / 2
				local v62 = v59:PointToObjectSpace(v_u_14.CFrame.Position)
				local v63
				if v62.Z > v61.Z or v62.Z < -v61.Z then
					v63 = nil
				else
					v63 = (v62 * Vector3.new(1, 1, 0)).Magnitude <= v61.X and true or nil
				end
				if v63 then
					v55.Parent = game.Lighting
				else
					v55.Parent = nil
				end
				task.wait()
				if v_u_52.Parent then
					continue
				end
				if v56 then
					v56:StartFadeOut(0.5)
				end
				v55:Destroy()
			end)
			local v_u_64 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_38, (copy) v_u_52, (ref) v_u_64
				repeat
					task.spawn(v_u_38, v_u_52)
					task.wait(0.3)
				until not (v_u_52.Parent and v_u_64)
			end)
			v_u_3:Create(v_u_53, TweenInfo.new(0.3), {
				["Value"] = Vector3.new(60, 60, 180)
			}):Play()
			task.wait(0.3)
			v_u_3:Create(v_u_53, TweenInfo.new(0.1), {
				["Value"] = Vector3.new(40, 40, 180)
			}):Play()
			task.wait(0.1)
			v_u_3:Create(v_u_53, TweenInfo.new(1), {
				["Value"] = Vector3.new(30, 30, 180)
			}):Play()
			local function v72() -- name: updateWidth
				-- upvalues: (copy) p_u_46, (ref) v_u_3, (copy) v_u_53
				local v65 = p_u_46:GetAttribute("Width")
				local v66 = v_u_3
				local v67 = v_u_53
				local v68 = TweenInfo.new(0.2)
				local v69 = {}
				local v70 = v65.X - 5
				local v71 = v65.Y - 5
				v69.Value = Vector3.new(v70, v71, 180)
				v66:Create(v67, v68, v69):Play()
			end
			v72()
			p_u_46:GetAttributeChangedSignal("Width"):Connect(v72)
			repeat
				task.wait()
			until not p_u_46.Parent
			v_u_64 = false
			v_u_3:Create(v_u_52.BlackStart.Glow.PointLight, TweenInfo.new(1), {
				["Brightness"] = 0
			}):Play()
			v_u_3:Create(v_u_53, TweenInfo.new(0.5), {
				["Value"] = Vector3.new(0, 0, 180)
			}):Play()
			for _, v73 in v_u_52:GetDescendants() do
				if v73:IsA("Beam") then
					v_u_3:Create(v73, TweenInfo.new(0.25), {
						["Width0"] = 0,
						["Width1"] = 0
					}):Play()
				else
					if not v73:IsA("ParticleEmitter") then
						continue
					end
					v73.Enabled = false
				end
			end
			task.wait(0.25)
			v_u_54 = false
			task.wait(0.25)
			v_u_52:Destroy()
		end
	}
	v_u_9.Effects:Connect(function(p75, ...)
		-- upvalues: (copy) v_u_74
		local v76 = v_u_74[p75]
		if v76 then
			v76(...)
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("FlowerBeamService")
	v_u_10 = v_u_1.GetController("FXController")
	v_u_11 = v_u_1.GetController("ToolController")
end
return v12