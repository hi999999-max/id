-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Todo.Awake.ClimaxJumpController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local v_u_7 = v6.Animations
local v_u_8 = v6.Utils
local v_u_9 = v6.Sounds
local v_u_10 = require(v6.Modules.CameraShaker)
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "ClimaxJumpController"
})
function v14.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_8, (copy) v_u_3, (ref) v_u_13, (copy) v_u_9, (copy) v_u_5, (copy) v_u_10, (copy) v_u_4, (copy) v_u_2, (copy) v_u_7, (ref) v_u_11
	local v_u_69 = {
		["Grab"] = function(p_u_15, p_u_16)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10, (ref) v_u_4, (ref) v_u_2, (ref) v_u_7
			local v_u_17 = p_u_16:FindFirstChild("HumanoidRootPart")
			if v_u_17 then
				local v18 = v_u_8.Mahito.CrushingRushdown.DrillImpact:Clone()
				v18.Position = v_u_17.Position
				v18.Parent = workspace.Effects
				v_u_3:AddItem(v18, 1)
				v18.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 1))
				v18.Wind.Color = v18.Sparks.Color
				v18.Wind2.Color = v18.Sparks.Color
				v18.Sparks:Emit(50)
				v18.Wind:Emit(7)
				v18.Wind2:Emit(7)
				v_u_13:Flash(p_u_16, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Hakari.EnergySurge.Hit1, v_u_17, game.SoundService.Effect)
				if v_u_5.Character == p_u_16 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
				end
				if v_u_5.Character == p_u_15 and p_u_15:GetAttribute("InUlt") then
					local v_u_19 = v_u_8.Todo.Jump.Flash:Clone()
					local v_u_20 = Instance.new("Camera", v_u_19.Main)
					v_u_19.Main.CurrentCamera = v_u_20
					v_u_19.Parent = v_u_5.PlayerGui
					v_u_4:Create(v_u_19.Fade, TweenInfo.new(0.2), {
						["BackgroundTransparency"] = 1
					}):Play()
					local v21 = CFrame.new(2000, 0, 0)
					local v_u_22 = v_u_8.DomainWarn.Panel.Viewport.Display:Clone()
					v_u_22["Left Arm"].FingersL:Destroy()
					v_u_22["Right Arm"].FingersR:Destroy()
					v_u_22.HumanoidRootPart.CFrame = v21
					v_u_22.Parent = v_u_19.Main
					local function v23()
						-- upvalues: (ref) v_u_13, (copy) p_u_15, (copy) v_u_22
						v_u_13:ApplyCopyOutfit(p_u_15, v_u_22)
					end
					pcall(v23)
					v_u_22.Humanoid:LoadAnimation(v_u_19.User):Play(0)
					local v24 = v_u_8.Todo.Awakening.Takada:Clone()
					v24.Parent = v_u_19.Main
					v24.HumanoidRootPart.CFrame = v_u_22.HumanoidRootPart.CFrame
					v24.Humanoid:LoadAnimation(v_u_19.Takada):Play(0)
					local v_u_25 = v_u_8.DomainWarn.Panel.Viewport.Display:Clone()
					v_u_25["Left Arm"].FingersL:Destroy()
					v_u_25["Right Arm"].FingersR:Destroy()
					v_u_25.HumanoidRootPart.CFrame = v_u_22.HumanoidRootPart.CFrame * CFrame.Angles(0, 3.141592653589793, 0) * CFrame.new(0, 0, 5)
					v_u_25.Parent = v_u_19.Main
					local function v26()
						-- upvalues: (ref) v_u_13, (copy) p_u_16, (copy) v_u_25
						v_u_13:ApplyCopyOutfit(p_u_16, v_u_25)
					end
					pcall(v26)
					v_u_25.Humanoid:LoadAnimation(v_u_19.Target):Play(0)
					local v_u_27 = workspace.CurrentCamera.CFrame
					local v_u_28 = 0
					local v_u_29 = nil
					local v_u_30 = v_u_8.Todo.Jump.CameraData
					v_u_29 = v_u_2.RenderStepped:Connect(function(p31)
						-- upvalues: (ref) v_u_28, (copy) v_u_30, (copy) v_u_22, (copy) v_u_20, (ref) v_u_29, (copy) v_u_27
						v_u_28 = v_u_28 + p31 * 60
						local v32 = v_u_30.Frames
						local v33 = v_u_28
						local v34 = math.ceil(v33)
						local v35 = v32:FindFirstChild((tonumber(v34)))
						local v36 = v_u_30.FOV
						local v37 = v_u_28
						local v38 = math.ceil(v37)
						local v39 = v36:FindFirstChild((tonumber(v38)))
						if v35 and (v39 and v_u_22.Parent) then
							v_u_20.CFrame = v_u_22.HumanoidRootPart.CFrame * v35.Value
							v_u_20.FieldOfView = v39.Value
							if v_u_28 < 79 then
								workspace.CurrentCamera.CFrame = v_u_20.CFrame
								workspace.CurrentCamera.FieldOfView = v_u_20.FieldOfView
								return
							end
						else
							v_u_29:Disconnect()
							workspace.CurrentCamera.FieldOfView = 70
							workspace.CurrentCamera.CFrame = v_u_27
						end
					end)
					v_u_19.Main.Ambient = Color3.new(0.211765, 0.0509804, 0.0862745)
					v_u_19.Main.LightColor = Color3.new(0.956863, 0.807843, 1)
					v_u_19.Main.LightDirection = Vector3.new(0, 1, -0.5)
					local v_u_40 = v_u_8.Todo.Jump.Stage:Clone()
					v_u_40:PivotTo(CFrame.new(2000, 0, 0))
					v_u_4:Create(v_u_40.BG, TweenInfo.new(1.3, Enum.EasingStyle.Linear), {
						["CFrame"] = v_u_40.BG.CFrame * CFrame.new(3.12413936106985, 0, 0)
					}):Play()
					local v41 = v_u_40.Bloom
					v_u_40.Parent = workspace.Effects
					v41.Parent = game.Lighting
					v_u_3:AddItem(v_u_40, 1.4)
					v_u_3:AddItem(v41, 1.4)
					task.delay(1.3, function()
						-- upvalues: (copy) v_u_19
						v_u_19.BG.Visible = true
						v_u_19.Main.Ambient = Color3.new(1, 1, 1)
						v_u_19.Main.LightColor = Color3.new(1, 1, 1)
						v_u_19.Main.LightDirection = Vector3.new(-1, -1, -1)
						task.wait(0.9)
						v_u_19.BG.Hearts.Position = UDim2.new(-0.5, 0, 0, 0)
						task.wait(0.7)
						v_u_19.BG.Hearts.Visible = false
					end)
					if _G.Settings.Flash ~= true then
						v_u_40.BG.Flashes.Enabled = false
						v_u_40.BG.Flashes2.Enabled = false
					end
					v_u_13:PlaySound(v_u_9.Hakari.EnergySurge.Hit1, workspace, game.SoundService.Effect)
					task.delay(0.4, function()
						-- upvalues: (copy) v_u_40, (copy) v_u_25, (ref) v_u_13, (ref) v_u_9, (copy) v_u_19, (ref) v_u_3, (ref) v_u_4, (ref) v_u_28
						local v42 = v_u_40.RootPart.Attachment
						v42.WorldPosition = v_u_25.Torso.Position
						v42.Wind2:Emit(10)
						v42.Hearts:Emit(20)
						v42.Ring:Emit(1)
						v_u_13:PlaySound(v_u_9.Hakari.EnergySurge.Hit1, workspace, game.SoundService.Effect)
						task.wait(0.3)
						v42.Wind2:Emit(10)
						v42.Hearts:Emit(20)
						v42.Ring:Emit(1)
						v_u_13:PlaySound(v_u_9.Hakari.EnergySurge.Hit2, workspace, game.SoundService.Effect)
						task.wait(0.2)
						v42.Wind2:Emit(10)
						v42.Hearts:Emit(20)
						v42.Ring:Emit(1)
						v_u_13:PlaySound(v_u_9.Hakari.EnergySurge.Hit1, workspace, game.SoundService.Effect)
						task.wait(0.4)
						local v43 = TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
						repeat
							v_u_13:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit" .. math.random(1, 4)), workspace, game.SoundService.Effect)
							local v44 = v_u_19.BG.Heart:Clone()
							v44.ImageColor3 = Color3.fromHSV(math.random(0, 100) / 100, 1, 1)
							v44.Parent = v_u_19.BG.Hearts
							v_u_3:AddItem(v44, 0.3)
							v44.Visible = true
							v_u_4:Create(v44, v43, {
								["Size"] = UDim2.new(5, 0, 5, 0)
							}):Play()
							task.wait(0.075)
						until v_u_28 > 171
						v_u_13:PlaySound(v_u_9.Hakari.EnergySurge.Hit2, workspace, game.SoundService.Effect)
					end)
					task.delay(1, function()
						-- upvalues: (ref) v_u_3, (copy) v_u_19, (ref) v_u_8, (copy) v_u_17, (copy) p_u_15, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_7
						v_u_3:AddItem(v_u_19, 2.2)
						local v45 = v_u_8.Todo.Jump.EndSpotlight:Clone()
						v45.CFrame = v_u_17.CFrame
						v45.Parent = p_u_15.HumanoidRootPart
						v_u_3:AddItem(v45, 3.5)
						task.wait(2)
						v_u_4:Create(v_u_19.Fade, TweenInfo.new(0.2), {
							["BackgroundTransparency"] = 0
						}):Play()
						task.wait(0.2)
						if _G.Settings.Flash == true then
							local v46 = v_u_8.Itadori.DivergentFist.BlackFlashCC:Clone()
							v46.TintColor = Color3.fromRGB(255, 170, 0)
							v46.Parent = game.Lighting
							task.wait(0.03)
							v46.Brightness = 200
							v46.Contrast = -1000
							task.wait(0.03)
							v46.TintColor = Color3.new(1, 1, 1)
							v46.Brightness = -200
							v46.Contrast = 1000
							task.wait(0.03)
							v46:Destroy()
						end
						game.Lighting.ExposureCompensation = -6
						v_u_4:Create(game.Lighting, TweenInfo.new(1), {
							["ExposureCompensation"] = 0
						}):Play()
						v_u_4:Create(v45.Attachment.SpotLight, TweenInfo.new(1), {
							["Brightness"] = 0
						}):Play()
						v45.CFrame = v_u_17.CFrame
						v45.Dust:Emit(40)
						v_u_13:PlaySound(v_u_9.Todo.Jump.Bell, p_u_15.HumanoidRootPart, game.SoundService.Effect)
						local v47 = workspace.Effects:FindFirstChild("FollowTakada")
						if v47 and v_u_5.Character == p_u_15 then
							v47:SetAttribute("A", CFrame.new(-6, 0, 0))
							v47.Humanoid:LoadAnimation(v_u_7.Todo.TakadaJoint.JumpEnd):Play(0)
							task.wait(1)
							v47:SetAttribute("A", nil)
						end
					end)
				end
			end
		end,
		["Hit"] = function(p48, p49)
			-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			if v_u_5 == p48 then
				return
			else
				local v50 = p49:FindFirstChild("HumanoidRootPart")
				if v50 then
					local v51 = v_u_8.Mahito.CrushingRushdown.DrillImpact:Clone()
					v51.Position = v50.Position
					v51.Parent = workspace.Effects
					v_u_3:AddItem(v51, 1)
					v51.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 1))
					v51.Wind.Color = v51.Sparks.Color
					v51.Wind2.Color = v51.Sparks.Color
					v51.Sparks:Emit(50)
					v51.Wind:Emit(7)
					v51.Wind2:Emit(7)
					v_u_13:Flash(p49, Color3.new(1, 1, 1))
					v_u_13:PlaySound(v_u_9.Hakari.EnergySurge.Hit1, v50, game.SoundService.Effect)
					if v_u_5 == p48 or v_u_5.Character == p49 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
					end
				end
			end
		end,
		["Hit2"] = function(p52, p53)
			-- upvalues: (ref) v_u_5, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			if v_u_5 == p52 then
				return
			else
				local v54 = p53:FindFirstChild("HumanoidRootPart")
				if v54 then
					v_u_13:Flash(p53, Color3.new(1, 1, 1))
					v_u_13:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit" .. math.random(1, 4)), v54, game.SoundService.Effect)
					if v_u_5 == p52 or v_u_5.Character == p53 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
					end
				end
			end
		end,
		["Hit3"] = function(p55, p56)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v57 = p56:FindFirstChild("HumanoidRootPart")
			if v57 then
				local v58 = v_u_8.Mahito.CrushingRushdown.DrillImpact:Clone()
				v58.Position = v57.Position
				v58.Parent = workspace.Effects
				v_u_3:AddItem(v58, 1)
				v58.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 0.498039))
				v58.Wind.Color = v58.Sparks.Color
				v58.Wind2.Color = v58.Sparks.Color
				v58.Sparks:Emit(50)
				v58.Wind:Emit(7)
				v58.Wind2:Emit(7)
				v_u_13:Flash(p56, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Hakari.EnergySurge.Hit1, v57, game.SoundService.Effect)
				if v_u_5 == p55 or v_u_5.Character == p56 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
				end
			end
		end,
		["Burst"] = function(p59)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10, (ref) v_u_7
			local v60 = p59:FindFirstChild("HumanoidRootPart")
			if v60 then
				v_u_13:Flash(p59, Color3.new(1, 1, 1), 1)
				v_u_13:PlaySound(v_u_9.Itadori.CursedStrikes.Startup, v60, game.SoundService.Effect)
				if v_u_5.Character == p59 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
					local v61 = workspace.Effects:FindFirstChild("FollowTakada")
					if v61 and v_u_5.Character == p59 then
						v61:SetAttribute("A", CFrame.new(4, 0, 0))
						v61.Humanoid:LoadAnimation(v_u_7.Todo.TakadaJoint.JumpStart):Play(0)
						task.wait(1)
						v61:SetAttribute("A", nil)
					end
				end
			end
		end,
		["Dash"] = function(p62)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3
			local v63 = p62:FindFirstChild("HumanoidRootPart")
			if v63 then
				v_u_13:PlaySound(v_u_9.Itadori.Rush.RushLaunch, v63, game.SoundService.Effect)
				local v64 = v_u_8.Itadori.DivergentFist.BlackFlashLaunch:Clone()
				v64.CFrame = v63.CFrame * CFrame.new(2, 1, -5)
				v64.Parent = workspace.Effects
				v64.Wind:Emit(20)
				v64.PointLight:Destroy()
				v64.Back1.Back:Emit(1)
				v64.Back2.Back:Emit(1)
				v_u_4:Create(v64.Back1, TweenInfo.new(2), {
					["CFrame"] = v64.Back1.CFrame - v64.Back1.CFrame.LookVector * 20
				}):Play()
				v_u_4:Create(v64.Back2, TweenInfo.new(2), {
					["CFrame"] = v64.Back2.CFrame - v64.Back2.CFrame.LookVector * 20
				}):Play()
				v_u_3:AddItem(v64, 3)
				for _ = 1, 10 do
					local v_u_65 = v_u_8.Mahito.BodyRepel["Wind" .. math.random(1, 5)]:Clone()
					local v66 = v63.CFrame
					local v67 = CFrame.Angles
					local v68 = math.random(0, 360)
					v_u_65.CFrame = v66 * v67(1.5707963267948966, math.rad(v68), 0)
					v_u_65.Transparency = 0.5
					v_u_65.Size = Vector3.new(6, 6, 6)
					v_u_4:Create(v_u_65, TweenInfo.new(0.3, Enum.EasingStyle.Quad), {
						["CFrame"] = nil,
						["Size"] = Vector3.new(7, 0, 7),
						["CFrame"] = v_u_65.CFrame + v63.CFrame.LookVector * 3
					}):Play()
					v_u_3:AddItem(v_u_65, 0.3)
					v_u_65.Parent = workspace.Effects
					v_u_4:Create(v_u_65, TweenInfo.new(0.15), {
						["Transparency"] = 0.5
					}):Play()
					task.delay(0.15, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_65
						v_u_4:Create(v_u_65, TweenInfo.new(0.15), {
							["Transparency"] = 1
						}):Play()
					end)
					task.wait(0.03)
				end
			end
		end
	}
	v_u_11.Effects:Connect(function(p70, ...)
		-- upvalues: (copy) v_u_69
		local v71 = v_u_69[p70]
		if v71 then
			v71(...)
		end
	end)
end
function v14.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13
	v_u_11 = v_u_1.GetService("ClimaxJumpService")
	v_u_12 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("FXController")
end
return v14