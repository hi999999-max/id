-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Choso.Awake.PlasmaWaveController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "PlasmaWaveController"
})
function quadraticBezier(p13, p14, p15, p16) -- name: quadraticBezier
	return (1 - p13) ^ 2 * p14 + 2 * (1 - p13) * p13 * p15 + p13 ^ 2 * p16
end
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (ref) v_u_11, (copy) v_u_8, (copy) v_u_2, (copy) v_u_5, (copy) v_u_9, (ref) v_u_10
	local v_u_67 = {
		["Startup"] = function(p17, p_u_18)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8, (ref) v_u_2
			local v19 = p17:FindFirstChild("HumanoidRootPart")
			if v19 then
				local v20 = v_u_7.Choso.Switch:Clone()
				v20.Parent = p17.Head
				v_u_4:Create(v20, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
					["Size"] = UDim2.new(15, 0, 15, 0)
				}):Play()
				local v21 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				v_u_4:Create(v20.Eye1, v21, {
					["Size"] = nil,
					["ImageTransparency"] = 1,
					["Size"] = UDim2.new(0.3, 0, 0, 0)
				}):Play()
				v_u_4:Create(v20.Eye2, v21, {
					["Size"] = nil,
					["ImageTransparency"] = 1,
					["Size"] = UDim2.new(0.6, 0, 0, 0)
				}):Play()
				v_u_4:Create(v20.Eye3, v21, {
					["Size"] = nil,
					["ImageTransparency"] = 1,
					["Size"] = UDim2.new(0.3, 0, 0, 0)
				}):Play()
				v_u_3:AddItem(v20, 0.5)
				v_u_11:PlaySound(v_u_8.Choso.PlasmaWave.Swarm, v19, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v19.Position).Magnitude <= 150 then
					local v_u_22 = {}
					for _ = 1, 15 do
						local v23 = v_u_7.Choso.Convergence.Blood1:Clone()
						v23.Trail.Lifetime = 1
						v23.Parent = p_u_18
						local v24 = {}
						local v25 = math.random(-130, 130) / 10
						local v26 = math.random(0, 120) / 10
						local v27 = math.random(-130, 130) / 10
						local v28 = Vector3.new(v25, v26, v27)
						local v29 = math.random(-130, 130) / 10
						local v30 = math.random(0, 120) / 10
						local v31 = math.random(-130, 130) / 10
						__set_list(v24, 1, {v28, (Vector3.new(v29, v30, v31))})
						v_u_22[v23] = v24
					end
					local v_u_32 = Instance.new("NumberValue", p_u_18)
					v_u_4:Create(v_u_32, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
						["Value"] = 0.2
					}):Play()
					task.delay(0.5, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_32, (copy) v_u_22
						v_u_4:Create(v_u_32, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
							["Value"] = 0.45
						}):Play()
						task.wait(0.5)
						v_u_4:Create(v_u_32, TweenInfo.new(0.9, Enum.EasingStyle.Cubic, Enum.EasingDirection.In), {
							["Value"] = 1
						}):Play()
						task.wait(0.1)
						for v33, _ in v_u_22 do
							v33.ParticleEmitter.Enabled = false
						end
						task.wait(0.3)
						for v34, _ in v_u_22 do
							v34.Trail.Lifetime = 0.2
						end
					end)
					local v_u_35 = nil
					v_u_35 = v_u_2.Stepped:Connect(function()
						-- upvalues: (copy) p_u_18, (ref) v_u_35, (copy) v_u_22, (copy) v_u_32
						if p_u_18.Parent then
							for v36, v37 in v_u_22 do
								local v38 = v_u_32.Value
								local v39 = v37[1]
								local v40 = v37[2]
								v36.Position = (1 - v38) ^ 3 * Vector3.new(0, 2, 0) + 3 * (1 - v38) ^ 2 * v38 * v39 + 3 * (1 - v38) * v38 ^ 2 * v40 + v38 ^ 3 * Vector3.new(0, 0, -2.5)
							end
						else
							v_u_35:Disconnect()
						end
					end)
				end
			else
				return
			end
		end,
		["Clap"] = function(p41)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v42 = p41:FindFirstChild("HumanoidRootPart")
			if v42 then
				v_u_11:PlaySound(v_u_8.Choso.PiercingBlood.Clap, v42, game.SoundService.Effect)
				if v_u_5.Character == p41 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Fire"] = function(p43, p_u_44)
			-- upvalues: (ref) v_u_7, (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_9, (ref) v_u_5
			local v45 = p43:FindFirstChild("HumanoidRootPart")
			if v45 then
				local v_u_46 = v_u_7.Choso.PlasmaWave:Clone()
				v_u_46.CFrame = p_u_44:GetAttribute("BeamStartCFrame") * CFrame.new(0, 0, -62)
				v_u_46.Weld.Part0 = v45
				v_u_46.Parent = workspace.Effects
				task.spawn(function()
					-- upvalues: (copy) p_u_44, (copy) v_u_46
					while p_u_44.Parent do
						v_u_46.CFrame = p_u_44:GetAttribute("BeamStartCFrame") * CFrame.new(0, 0, -62)
						task.wait(0.1)
					end
				end)
				local v47 = v_u_11:PlaySound(v_u_8.Choso.PlasmaWave.Fire, v_u_46, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_8.Choso.PiercingBlood.Fire, v45, game.SoundService.Effect)
				v_u_46.Back1.Back:Emit(1)
				v_u_46.Back2.Back:Emit(1)
				v_u_4:Create(v_u_46.Back1, TweenInfo.new(2), {
					["CFrame"] = v_u_46.Back1.CFrame - v_u_46.Back1.CFrame.LookVector * 20
				}):Play()
				v_u_4:Create(v_u_46.Back2, TweenInfo.new(2), {
					["CFrame"] = v_u_46.Back2.CFrame - v_u_46.Back2.CFrame.LookVector * 20
				}):Play()
				v_u_4:Create(v_u_46.Flash, TweenInfo.new(0.05), {
					["Size"] = Vector3.new(20, 20, 20)
				}):Play()
				v_u_4:Create(v_u_46.Flash.Weld, TweenInfo.new(0.05), {
					["C1"] = v_u_46.Flash.Weld.C1 + Vector3.new(0, 0, 10)
				}):Play()
				task.delay(0.05, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_46, (ref) v_u_3, (ref) v_u_9, (ref) v_u_7, (copy) p_u_44
					v_u_4:Create(v_u_46.Flash, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(0, 0, 50)
					}):Play()
					v_u_4:Create(v_u_46.Flash.Weld, TweenInfo.new(0.2), {
						["C1"] = v_u_46.Flash.Weld.C1 + Vector3.new(0, 0, 25)
					}):Play()
					v_u_3:AddItem(v_u_46.Flash, 0.2)
					if (workspace.CurrentCamera.CFrame.Position - v_u_46.Position).Magnitude < 180 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
						local v48 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.HeavyHit)
						task.spawn(function()
							-- upvalues: (ref) v_u_7
							if _G.Settings.Flash == true then
								local v49 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
								v49.TintColor = Color3.new(1, 1, 1)
								v49.Parent = game.Lighting
								task.wait(0.02)
								v49.Brightness = 200
								v49.Contrast = -1000
								task.wait(0.02)
								v49:Destroy()
							end
						end)
						repeat
							task.wait(0.1)
						until not p_u_44.Parent
						v48:StartFadeOut(0.5)
					end
				end)
				if v_u_5.Character == p43 then
					v_u_4:Create(workspace.CurrentCamera, TweenInfo.new(0.7, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["FieldOfView"] = 120
					}):Play()
				end
				v_u_46.End.Position = Vector3.new(0, 0, 60)
				v_u_4:Create(v_u_46.End, TweenInfo.new(0.2), {
					["Position"] = Vector3.new(0, 0, -60)
				}):Play()
				p_u_44:GetAttributeChangedSignal("BeamLength"):Connect(function()
					-- upvalues: (ref) v_u_4, (copy) v_u_46, (copy) p_u_44
					local v50 = v_u_4
					local v51 = v_u_46.End
					local v52 = TweenInfo.new(0.1)
					local v53 = {}
					local v54 = -p_u_44:GetAttribute("BeamLength") / 2
					v53.Position = Vector3.new(0, 0, v54)
					v50:Create(v51, v52, v53):Play()
				end)
				task.delay(0.2, function()
					-- upvalues: (copy) v_u_46
					v_u_46.Blood.Enabled = true
					v_u_46.Burst.Enabled = true
				end)
				repeat
					task.wait()
				until not p_u_44.Parent
				if v_u_5.Character == p43 then
					v_u_4:Create(workspace.CurrentCamera, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.InOut), {
						["FieldOfView"] = 70
					}):Play()
				end
				v_u_4:Create(v47, TweenInfo.new(0.5), {
					["Volume"] = 0
				}):Play()
				v_u_11:PlaySound(v_u_8.Choso.BloodRain.End, v_u_46, game.SoundService.Effect)
				v_u_46.Weld.Enabled = false
				v_u_46.Anchored = true
				for _, v55 in v_u_46:GetDescendants() do
					if v55:IsA("ParticleEmitter") then
						v55.Enabled = false
					else
						if not v55:IsA("Beam") then
							continue
						end
						v_u_4:Create(v55, TweenInfo.new(0.4), {
							["Width0"] = 0,
							["Width1"] = 0
						}):Play()
					end
				end
				task.wait(1.3)
				v_u_46:Destroy()
			end
		end,
		["FinalHit"] = function(p56, p57)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9
			local v58 = p57:FindFirstChild("HumanoidRootPart")
			if v58 then
				v_u_11:Flash(p57, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_8.Hakari.OverLuck.Hit2, v58, game.SoundService.Effect)
				local v59 = v_u_7.Hakari.RoughHit:Clone()
				v59.Glow.Color = ColorSequence.new(Color3.fromRGB(150, 0, 0))
				v59.Sparks.Color = ColorSequence.new(Color3.fromRGB(150, 0, 0))
				v59.Wind.Color = ColorSequence.new(Color3.fromRGB(150, 0, 0))
				v59.Wind2.Color = ColorSequence.new(Color3.fromRGB(150, 0, 0))
				v59.PointLight.Color = Color3.fromRGB(150, 0, 0)
				v59.Position = v58.Position
				v59.Parent = workspace.Effects
				v_u_3:AddItem(v59, 1)
				v_u_4:Create(v59.PointLight, TweenInfo.new(0.6), {
					["Brightness"] = 0
				}):Play()
				v59.Glow:Emit(1)
				v59.Sparks:Emit(50)
				v59.Wind:Emit(7)
				v59.Wind2:Emit(7)
				if v_u_5 == p56 or v_u_5.Character == p57 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["BeamClashing"] = function(p60, p61)
			-- upvalues: (ref) v_u_7, (ref) v_u_4
			local v_u_62 = v_u_7.Choso.PlasmaWaveClash:Clone()
			v_u_62.Parent = workspace.Effects
			local function v65(p63) -- name: toggleParticles
				-- upvalues: (copy) v_u_62
				for _, v64 in v_u_62.Attachment0:GetChildren() do
					if not v64:IsA("ParticleEmitter") then
						continue
					end
					v64.Enabled = p63
				end
			end
			v65(true)
			while p60.Parent and p61.Parent do
				v_u_62.CFrame = p60:GetAttribute("BeamStartCFrame") * CFrame.new(0, 0, -p60:GetAttribute("BeamLength")) * CFrame.Angles(0, 3.141592653589793, 0)
				task.wait()
			end
			v65(false)
			for _, v66 in v_u_62:GetChildren() do
				v_u_4:Create(v66, TweenInfo.new(0.2), {
					["Position"] = Vector3.new(0, 0, 0)
				}):Play()
			end
			task.wait(0.2)
			v_u_62:Destroy()
		end
	}
	v_u_10.Effects:Connect(function(p68, ...)
		-- upvalues: (copy) v_u_67
		local v69 = v_u_67[p68]
		if v69 then
			v69(...)
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("PlasmaWaveService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12