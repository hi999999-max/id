-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Character.JoinController.InventoryController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
game:GetService("TweenService")
local v_u_2 = game.Players.LocalPlayer
local v3 = game.ReplicatedStorage
local _ = v3.Animations
local _ = v3.Utils
local v_u_4 = v3.Sounds
local v5 = v_u_1.CreateController({
	["Name"] = "InventoryController"
})
local v_u_6 = Color3.fromRGB(85, 170, 255)
local v_u_7 = Color3.new(1, 1, 1)
local v_u_8 = {}
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
for v13, v14 in require(game.ReplicatedStorage.Modules.ListData).MoveList do
	v_u_8[v14[1][1]] = { v13, v14[1][2] }
end
function v5.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_2, (ref) v_u_9, (copy) v_u_4, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (copy) v_u_6, (copy) v_u_7, (copy) v_u_8
	local v_u_15 = v_u_2.PlayerGui:WaitForChild("Menus")
	local v_u_16 = v_u_15.Group.Inventory
	v_u_16:SetAttribute("Loaded", true)
	v_u_2:WaitForChild("leaderstats")
	local v_u_17 = nil
	for _, v_u_18 in v_u_16.Categories:GetChildren() do
		if not v_u_18:IsA("TextButton") then
			continue
		end
		v_u_18.MouseButton1Down:Connect(function()
			-- upvalues: (copy) v_u_16, (copy) v_u_18, (ref) v_u_9, (ref) v_u_4
			for _, v19 in v_u_16.Categories:GetChildren() do
				if not v19:IsA("TextButton") then
					continue
				end
				v19.Select.Visible = v19 == v_u_18
			end
			v_u_9:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
			for _, v20 in v_u_16.Items:GetChildren() do
				v20.Visible = v20.Name == v_u_18.Name
			end
		end)
	end
	local function v_u_25() -- name: updateEmoteListSize
		-- upvalues: (copy) v_u_16
		local v21 = v_u_16.Items.Emotes.List
		local v22 = v21.UIListLayout.Padding.Offset
		local v23 = -v22
		for _, v24 in v_u_16.Items.Emotes.List:GetChildren() do
			if not (v24:IsA("Frame") and v24.Visible) then
				continue
			end
			v23 = v23 + (v24.AbsoluteSize.Y + v22)
		end
		v21.CanvasSize = UDim2.fromOffset(0, v23)
	end
	local v_u_26 = v_u_16.Items.Emotes.TextBox
	v_u_26:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (copy) v_u_16, (copy) v_u_26, (copy) v_u_25
		v_u_16.Items.Emotes.List.CanvasPosition = Vector2.zero
		for _, v27 in v_u_16.Items.Emotes.List:GetChildren() do
			if not v27:IsA("Frame") then
				continue
			end
			v27.Visible = v27.Name:lower():find(v_u_26.Text:lower())
		end
		v_u_25()
	end)
	local v_u_28 = {
		[Enum.SortOrder.LayoutOrder] = Enum.SortOrder.Name,
		[Enum.SortOrder.Name] = Enum.SortOrder.LayoutOrder
	}
	local v_u_29 = {
		[Enum.SortOrder.Name] = "NEW",
		[Enum.SortOrder.LayoutOrder] = "A-Z"
	}
	local v_u_30 = v_u_16.Items.Emotes.List.UIListLayout
	v_u_26.SortAZ.MouseButton1Click:Connect(function()
		-- upvalues: (copy) v_u_30, (copy) v_u_28, (copy) v_u_26, (copy) v_u_29
		v_u_30.SortOrder = v_u_28[v_u_30.SortOrder]
		v_u_26.SortAZ.Text = v_u_29[v_u_30.SortOrder]
	end)
	local function v_u_34() -- name: updatePageDisplay
		-- upvalues: (copy) v_u_16, (ref) v_u_10, (ref) v_u_17, (ref) v_u_9, (ref) v_u_4
		v_u_16.Items.Emotes.Equipped.Pages.Page.Text = ("%*/%*"):format(v_u_10.Page, v_u_10.MaxPage + 1)
		local v31 = 8 * (v_u_10.Page - 1)
		v_u_17 = nil
		for v32 = 1, 8 do
			local v33 = v_u_10.EmoteCache[v32 + v31]
			if not v33 then
				continue
			end
			v_u_16.Items.Emotes.Equipped:FindFirstChild(v32).Text = v33[1]
		end
		v_u_9:PlaySound(v_u_4.Misc.UI.Switch, workspace, game.SoundService.Effect)
	end
	local function v_u_47(p35) -- name: updateInventory
		-- upvalues: (copy) v_u_16, (copy) v_u_15, (copy) v_u_26, (ref) v_u_9, (ref) v_u_4, (ref) v_u_17, (ref) v_u_10, (ref) v_u_11, (copy) v_u_25, (copy) v_u_34
		local v36 = v_u_16.Items.Emotes.List
		for _, v37 in v36:GetChildren() do
			if not v37:IsA("Frame") or table.find(p35, v37.Name) then
				continue
			end
			v37:Destroy()
		end
		for v38, v_u_39 in p35 do
			if v36:FindFirstChild(v_u_39) then
				continue
			end
			local v40 = v_u_15.Preset.Emote:Clone()
			v40.EmoteName.Text = v_u_39
			v40.Name = v_u_39
			v40.Visible = v_u_39:lower():find(v_u_26.Text:lower())
			v40.LayoutOrder = -v38
			v40.Parent = v36
			v40.EmoteName.MouseButton1Down:Connect(function()
				-- upvalues: (ref) v_u_9, (ref) v_u_4, (ref) v_u_17, (ref) v_u_10, (copy) v_u_39, (ref) v_u_11
				v_u_9:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
				if v_u_17 then
					local v41 = v_u_10.EmoteCache
					local v42 = v_u_17.Name
					local v43 = v41[tonumber(v42)]
					if v43[1] == v_u_39 then
						v_u_17.Text = v43[1]
						v_u_17 = nil
						return
					end
					local v44 = v_u_11.Equip
					local v45 = (v_u_10.Page - 1) * 8
					local v46 = v_u_17.Name
					v44:Fire(v45 + tonumber(v46), v_u_39)
					v_u_17 = nil
				end
			end)
		end
		v_u_25()
		v_u_34()
	end
	v_u_16.Items.Emotes.Equipped.Pages.Buttons.Next.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_10, (ref) v_u_12, (copy) v_u_34
		local v48 = v_u_10
		v48.Page = v48.Page + 1
		if v_u_10.Page > v_u_10.MaxPage then
			local v49 = v_u_10
			v49.Page = v49.Page - 1
			v_u_12.Purchase:Fire("ExtraEmotePage", "Robux")
		else
			v_u_34()
		end
	end)
	v_u_16.Items.Emotes.Equipped.Pages.Buttons.Back.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_10, (copy) v_u_34
		local v50 = v_u_10.Page
		local v51 = v_u_10
		local v52 = v_u_10.Page - 1
		v51.Page = math.max(v52, 1)
		if v_u_10.Page ~= v50 then
			v_u_34()
		end
	end)
	local function v_u_58(p53) -- name: updateTitles
		-- upvalues: (copy) v_u_16, (copy) v_u_15, (ref) v_u_2, (ref) v_u_6, (ref) v_u_7, (ref) v_u_9, (ref) v_u_4, (ref) v_u_11
		local v54 = v_u_16.Items.Titles.List
		for _, v55 in v54:GetChildren() do
			if not v55:IsA("Frame") or table.find(p53, v55.Name) then
				continue
			end
			v55:Destroy()
		end
		for _, v_u_56 in p53 do
			if v54:FindFirstChild(v_u_56) then
				v54:FindFirstChild(v_u_56).BackgroundColor3 = v_u_56 == v_u_2:GetAttribute("Title") and v_u_6 or v_u_7
			else
				local v57 = v_u_15.Preset.Emote:Clone()
				v57.EmoteName.Text = v_u_56
				v57.Name = v_u_56
				v57.Size = UDim2.new(1, 0, 0.05, 15)
				v57.BackgroundColor3 = v_u_56 == v_u_2:GetAttribute("Title") and v_u_6 or v_u_7
				v57.Parent = v54
				v57.EmoteName.MouseButton1Down:Connect(function()
					-- upvalues: (ref) v_u_9, (ref) v_u_4, (ref) v_u_11, (copy) v_u_56
					v_u_9:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
					v_u_11.ChangeInv:Fire(v_u_56)
				end)
			end
		end
	end
	local function v_u_64(p59) -- name: updateVictories
		-- upvalues: (copy) v_u_16, (copy) v_u_15, (ref) v_u_2, (ref) v_u_6, (ref) v_u_7, (ref) v_u_9, (ref) v_u_4, (ref) v_u_11
		local v60 = v_u_16.Items.MVP.List
		for _, v61 in v60:GetChildren() do
			if not v61:IsA("Frame") or table.find(p59, v61.Name) then
				continue
			end
			v61:Destroy()
		end
		for _, v_u_62 in p59 do
			if v60:FindFirstChild(v_u_62) then
				v60:FindFirstChild(v_u_62).BackgroundColor3 = v_u_62 == v_u_2:GetAttribute("MVP") and v_u_6 or v_u_7
			else
				local v63 = v_u_15.Preset.Emote:Clone()
				v63.EmoteName.Text = v_u_62
				v63.Name = v_u_62
				v63.Size = UDim2.new(1, 0, 0.05, 15)
				v63.BackgroundColor3 = v_u_62 == v_u_2:GetAttribute("MVP") and v_u_6 or v_u_7
				v63.Parent = v60
				v63.EmoteName.MouseButton1Down:Connect(function()
					-- upvalues: (ref) v_u_9, (ref) v_u_4, (ref) v_u_11, (copy) v_u_62
					v_u_9:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
					v_u_11.ChangeMVP:Fire(v_u_62)
				end)
			end
		end
	end
	local function v_u_85(p65) -- name: updateSkins
		-- upvalues: (copy) v_u_16, (ref) v_u_8, (ref) v_u_11, (ref) v_u_6, (ref) v_u_7
		local v66 = p65[1]
		local v67 = p65[2]
		local v68 = v_u_16.Items.Skins.List
		for _, v69 in v68:GetChildren() do
			if not v69:IsA("Frame") or v66[v69.Name] then
				continue
			end
			v69:Destroy()
		end
		for v_u_70, v71 in v66 do
			local v72 = v68:FindFirstChild(v_u_70)
			if not v72 then
				local v_u_73 = v_u_16.Items.Skins.Preset.Category:Clone()
				v_u_73.Name = v_u_70
				v_u_73.Dropdown.Title.Text = v_u_70
				v_u_73.Parent = v68
				local v_u_74 = v_u_73.Dropdown.Icon
				v_u_73.Dropdown.MouseButton1Click:Connect(function()
					-- upvalues: (copy) v_u_74, (ref) v_u_73
					v_u_74.Text = v_u_74.Text == "v" and ">" or "v"
					v_u_73.List.Visible = v_u_74.Text == "v"
				end)
				local v75 = v_u_8[v_u_70:upper()]
				if v75 then
					v_u_73.LayoutOrder = v75[1]
					v_u_73.Dropdown.BackgroundColor3 = v75[2]
				else
					v_u_73.LayoutOrder = 99
				end
				v_u_73.List.Default:Destroy()
				v72 = v_u_73
			end
			for v_u_76, v77 in v71 do
				local v78 = v72.List:FindFirstChild(v_u_76)
				if not v78 then
					local v_u_79 = v_u_16.Items.Skins.Preset.Category:Clone()
					v_u_79.Size = UDim2.new(0.93, 0, 0.08, 0)
					v_u_79.Name = v_u_76
					v_u_79.Dropdown.Title.Text = v_u_76
					v_u_79.Parent = v72.List
					v_u_79.List.Default.LayoutOrder = -1
					local v_u_80 = v_u_79.Dropdown.Icon
					v_u_79.Dropdown.MouseButton1Click:Connect(function()
						-- upvalues: (copy) v_u_80, (ref) v_u_79
						v_u_80.Text = v_u_80.Text == "v" and ">" or "v"
						v_u_79.List.Visible = v_u_80.Text == "v"
					end)
					v_u_79.List.Default.MouseButton1Click:Connect(function()
						-- upvalues: (ref) v_u_11, (copy) v_u_70, (copy) v_u_76
						v_u_11.ChangeSkin:Fire(v_u_70, v_u_76)
					end)
					v78 = v_u_79
				end
				local v81 = v78.List
				for v82, v_u_83 in v77 do
					local v84 = v81:FindFirstChild(v_u_83)
					if not v84 then
						v84 = v_u_16.Items.Skins.Preset.Skin:Clone()
						v84.Name = v_u_83
						v84.Text = v_u_83
						v84.LayoutOrder = v82
						v84.Parent = v81
						v84.MouseButton1Click:Connect(function()
							-- upvalues: (ref) v_u_11, (copy) v_u_70, (copy) v_u_76, (copy) v_u_83
							v_u_11.ChangeSkin:Fire(v_u_70, v_u_76, v_u_83)
						end)
					end
					v84.BackgroundColor3 = (v67[v_u_70] or {})[v_u_76] == v_u_83 and v_u_6 or v_u_7
				end
				v81.Default.BackgroundColor3 = (v67[v_u_70] or {})[v_u_76] and v_u_7 or v_u_6
			end
		end
	end
	local v86 = v_u_16.Items.Skins.Preview
	local v87 = v86.ViewportFrame
	local v88 = v86.Slider
	local v_u_89 = Instance.new("Camera", v87)
	v87.CurrentCamera = v_u_89
	local v_u_90 = v88.Bar.Handle
	local v91 = v_u_90.UIDragDetector
	local v_u_92 = v87.CurrentPreview
	local v_u_93 = 0.01231
	local v94 = v_u_93
	v_u_92:PivotTo(CFrame.new() * CFrame.Angles(0, math.rad(v94), 0))
	v91.DragContinue:Connect(function()
		-- upvalues: (ref) v_u_93, (copy) v_u_90, (copy) v_u_92
		v_u_93 = math.map(v_u_90.Position.X.Scale, 0, 1, -1, 1) * 180
		local v95 = v_u_93
		v_u_92:PivotTo(CFrame.new() * CFrame.Angles(0, math.rad(v95), 0))
	end)
	local v_u_96 = v87.NoPreview
	v_u_11.ChangeSkin:Connect(function(p97)
		-- upvalues: (copy) v_u_92, (copy) v_u_96, (ref) v_u_93, (copy) v_u_89
		v_u_92:ClearAllChildren()
		if p97 then
			v_u_96.Visible = false
			p97.Parent = v_u_92
			local v98 = v_u_92:FindFirstChildWhichIsA("BasePart", true)
			local v99 = Instance.new("Model", v_u_92)
			if v98.Parent == p97 then
				v98.Parent = v99
			else
				v98.Parent.Parent = v99
			end
			local v100 = v_u_93
			v99:PivotTo(CFrame.new() * CFrame.Angles(0, math.rad(v100), 0))
			local _, v101 = v99:GetBoundingBox()
			v_u_89.CFrame = CFrame.lookAt(CFrame.new(0, 0, -v101.Magnitude * 0.8).Position, v98.Position)
		else
			v_u_96.Visible = true
		end
	end)
	v_u_11.ChangeInv:Connect(function(p102, p103)
		-- upvalues: (copy) v_u_47, (copy) v_u_64, (copy) v_u_85, (copy) v_u_58
		if p103 == 1 then
			v_u_47(p102)
			return
		elseif p103 == 2 then
			v_u_64(p102)
			return
		elseif p103 == 3 then
			v_u_85(p102)
		else
			v_u_58(p102)
		end
	end)
	for _, v_u_104 in v_u_16.Items.Emotes.Equipped:GetChildren() do
		if v_u_104.Name == "Pages" then
			continue
		end
		v_u_104.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_9, (ref) v_u_4, (ref) v_u_17, (copy) v_u_104, (ref) v_u_10
			v_u_9:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
			if v_u_17 == nil then
				v_u_17 = v_u_104
				v_u_104.Text = "..."
				return
			end
			if v_u_17 == v_u_104 then
				v_u_17 = nil
				local v105 = v_u_104
				local v106 = v_u_10.EmoteCache
				local v107, v108
				if v_u_10.Page == 2 then
					local v109 = v_u_104.Name
					v107 = tonumber(v109) + 8
					if v107 then
						v105.Text = v106[v107]
					else
						v108 = v_u_104.Name
						v107 = tonumber(v108)
						v105.Text = v106[v107]
					end
				else
					v108 = v_u_104.Name
					v107 = tonumber(v108)
					v105.Text = v106[v107]
				end
			end
		end)
	end
end
function v5.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_9, (ref) v_u_10
	v_u_11 = v_u_1.GetService("EmoteService")
	v_u_12 = v_u_1.GetService("ShopService")
	v_u_9 = v_u_1.GetController("FXController")
	v_u_10 = v_u_1.GetController("EmoteController")
end
return v5