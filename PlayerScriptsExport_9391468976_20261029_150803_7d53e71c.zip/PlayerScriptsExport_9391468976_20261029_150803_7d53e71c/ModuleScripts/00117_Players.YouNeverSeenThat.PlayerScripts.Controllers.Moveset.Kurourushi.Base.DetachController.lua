-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Kurourushi.Base.DetachController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "DetachController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_10, (copy) v_u_7, (copy) v_u_6, (copy) v_u_3, (copy) v_u_4, (ref) v_u_12, (copy) v_u_2, (copy) v_u_8, (ref) v_u_9
	local v_u_81 = {
		["Start"] = function(p14, _)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_10:PlaySound(v_u_7.Kurourushi.Detach.Detach, v15, game.SoundService.Effect)
			end
		end,
		["Aerial"] = function(p16, p_u_17)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_4, (ref) v_u_12
			local v_u_18 = p16:FindFirstChild("HumanoidRootPart")
			if v_u_18 then
				local v19 = p16:FindFirstChild("Humanoid")
				if v19 then
					local v_u_20 = v_u_6.Kurourushi.Swarm:Clone()
					v_u_20.CFrame = v_u_18.CFrame * CFrame.new(0, -3.8, 0)
					v_u_20.Parent = workspace.Effects
					v_u_20:SetAttribute("Owner", p16.Name)
					task.spawn(function()
						-- upvalues: (copy) v_u_20, (copy) v_u_18, (copy) p_u_17, (ref) v_u_3
						local v21 = task.wait()
						v_u_20.CFrame = v_u_20.CFrame:Lerp(CFrame.lookAt((v_u_18.CFrame * CFrame.new(0, -5, 0)).Position, v_u_18.Position), 0.1 * v21 * 60)
						for _, v22 in v_u_20:GetChildren() do
							v22.Size = NumberSequence.new(v22.Size.Keypoints[1].Value + 0.085 * v21 * 60, v22.Size.Keypoints[2].Value)
						end
						if p_u_17.Parent ~= nil then
							break
						end
						for _, v23 in v_u_20:GetChildren() do
							v23.Enabled = false
						end
						v_u_3:AddItem(v_u_20, 2)
					end)
					if p16 == v_u_4.Character then
						local v24 = Instance.new("BodyGyro", v_u_18)
						v24.P = 10000
						v24.MaxTorque = Vector3.new(40000, 40000, 40000)
						p_u_17.Position = v_u_18.Position + Vector3.new(0, 6, 0)
						v19.PlatformStand = true
						repeat
							local v25 = v_u_12:GetMouseTarget()
							v24.CFrame = CFrame.new(v_u_18.Position, v25)
							task.wait()
						until not p_u_17.Parent
						v24:Destroy()
						v19.PlatformStand = false
					end
				else
					return
				end
			else
				return
			end
		end,
		["Detach"] = function(p26, p27)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_10, (ref) v_u_7
			local v28 = p26:FindFirstChild("HumanoidRootPart")
			if v28 then
				p27.ArmProjectile["Right Arm"].Color = p26["Right Arm"].Color
				p27.ArmProjectile:ScaleTo(p26:GetScale())
				if p26:FindFirstChild("Shirt") then
					p26.Shirt:Clone().Parent = p27.ArmProjectile
				end
				local v29 = p26["Right Arm"]
				local v30 = {}
				for _, v31 in v29:GetChildren() do
					if not v31:IsA("Decal") or v31.Transparency == 1 then
						continue
					end
					v31.Transparency = 1
					v30[v31] = v31.Transparency
				end
				for _, v32 in p26:GetChildren() do
					if not v32:IsA("Accessory") then
						continue
					end
					local v33 = v32:FindFirstChild("Handle", true)
					if not v33 then
						continue
					end
					for _, v34 in { "RightShoulderAttachment", "RightGripAttachment" } do
						if not v33:FindFirstChild(v34) or v33.Transparency == 1 then
							continue
						end
						v30[v33] = v33.Transparency
						v33.Transparency = 1
					end
				end
				if v29.Transparency ~= 1 then
					v30[v29] = v29.Transparency
					v29.Transparency = 1
				end
				local v35 = v_u_6.Kurourushi.RoachTorso:Clone()
				local v36 = Instance.new("Model")
				v35.Parent = v36
				v36:ScaleTo(p26:GetScale())
				v_u_3:AddItem(v36, 0.1)
				v35.Weld.Part0 = p26.Torso
				v35.Parent = workspace.Effects
				local v37 = v_u_6.Kurourushi.RoachJet:Clone()
				v37.Parent = workspace.Effects
				local v38 = v_u_6.Kurourushi.RoachJet:Clone()
				v38.Parent = workspace.Effects
				local v39 = {}
				local v40 = false
				task.wait()
				if p26.Parent and v28.Parent then
					local v41 = p26:GetScale()
					local v42 = p26.Torso.CFrame * CFrame.new(1 * v41, 0.5 * v41, 0).Position
					local v43 = p27.CFrame * CFrame.new(0, 1, 0).Position
					local v44 = (v43 - v42).Magnitude
					v37.CFrame = CFrame.lookAt(p26.Torso.CFrame * CFrame.new(1 * v41, 0.75 * v41, 0).Position, v43)
					if v38.Parent ~= nil then
						v38.CFrame = CFrame.lookAt(p27.CFrame * CFrame.new(0, 1, 0).Position, v42)
					end
					if p27:GetAttribute("Rebound") ~= nil then
						if not v40 then
							v_u_10:PlaySound(v_u_7.Kurourushi.Detach.Reattach, v28, game.SoundService.Effect)
							v40 = true
						end
						if v38 and v38.Parent ~= nil then
							v38:Destroy()
						end
						local v45 = v44 / 1.5
						local v46 = math.floor(v45)
						local v47 = math.max(1, v46)
						local v48 = math.min(35, v47)
						local _ = v44 / v48
						local v49
						if v48 <= 2 and v44 > 0 then
							local v50 = v44 / v44
							v49 = math.clamp(v50, 0, 1)
						else
							v49 = 1
						end
						for v51 = 1, v48 do
							local v52 = (v51 - 1) / v48
							local v53 = v51 / v48
							local v54 = v42:Lerp(v43, v52)
							local v55 = v42:Lerp(v43, v53)
							local v56 = v54:Lerp(v55, 0.5)
							local v57 = (v55 - v54).Magnitude
							if v39[v51] then
								v39[v51].Size = vector.create(0.25, 0.25, v57)
								v39[v51].CFrame = CFrame.lookAt(v56, v55)
								for _, v58 in v39[v51]:GetChildren() do
									if v58.Name == "Roaches" or v48 > 2 then
										continue
									end
									v58.Size = NumberSequence.new(v49)
								end
							else
								local v59 = v_u_6.Kurourushi.RoachSection:Clone()
								v59.Size = vector.create(0.25, 0.25, v57)
								v59.CFrame = CFrame.lookAt(v56, v55)
								v59.Parent = workspace.Effects
								v39[v51] = v59
								for _, v60 in v59:GetChildren() do
									if v60.Name == "Roaches" or v48 > 2 then
										continue
									end
									v60.Size = NumberSequence.new(v49)
								end
							end
						end
						for v61 = 1, #v39 do
							if not v39[v61] then
								continue
							end
							for _, v62 in v39[v61]:GetChildren() do
								if not v62:IsA("ParticleEmitter") or v62.Name ~= "RoachSwarm" then
									continue
								end
								if #v39 - 1 <= v61 and #v39 >= 5 then
									v62.Speed = NumberRange.new(0.1)
								else
									v62.Speed = NumberRange.new(5, 10)
								end
							end
						end
						for v63 = #v39, v48 + 1, -1 do
							if not v39[v63] then
								continue
							end
							v39[v63]:Destroy()
							v39[v63] = nil
						end
					end
					if p26.Parent ~= nil and (p27.Parent ~= nil and p27 ~= nil) then
						continue
					end
				else
					for _, v64 in v39 do
						if not v39[v64] then
							continue
						end
						v39[v64]:Destroy()
						v39[v64] = nil
					end
					v37:Destroy()
					v38:Destroy()
					v35:Destroy()
					for _, v65 in v39 do
						v65:Destroy()
					end
				end
				if p26.Parent ~= nil then
					for _, v66 in pairs(p26:GetDescendants()) do
						if not v66:IsA("BasePart") or v30[v66] == nil then
							continue
						end
						v66.Transparency = v30[v66]
					end
					v37:Destroy()
					v38:Destroy()
					v35:Destroy()
					for _, v67 in v39 do
						v67:Destroy()
					end
				end
			else
				return
			end
		end,
		["Interp"] = function(p_u_68, p_u_69)
			-- upvalues: (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			if p_u_68:FindFirstChild("HumanoidRootPart") then
				local v_u_70 = p_u_69.CFrame
				local v_u_71 = tick()
				local v_u_72 = p_u_69:GetPropertyChangedSignal("Position"):Connect(function()
					-- upvalues: (ref) v_u_70, (copy) p_u_69, (ref) v_u_71
					v_u_70 = p_u_69.CFrame
					v_u_71 = tick()
				end)
				local v_u_73 = nil
				v_u_73 = v_u_2.Stepped:Connect(function()
					-- upvalues: (copy) p_u_69, (ref) v_u_4, (copy) p_u_68, (ref) v_u_8, (ref) v_u_73, (copy) v_u_72, (ref) v_u_70, (ref) v_u_71
					if p_u_69.Parent and p_u_69:GetAttribute("Speed") then
						workspace:BulkMoveTo({ p_u_69 }, { v_u_70 - v_u_70.UpVector * (p_u_69:GetAttribute("Speed") * (tick() - v_u_71)) }, Enum.BulkMoveMode.FireCFrameChanged)
					else
						if not p_u_69:GetAttribute("Speed") and v_u_4.Character == p_u_68 then
							v_u_8.CurrentShaker:Shake(v_u_8.Presets.MediumHit)
						end
						v_u_73:Disconnect()
						v_u_72:Disconnect()
					end
				end)
			end
		end,
		["Impact"] = function(p74)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_10, (ref) v_u_7
			local v75 = Instance.new("Part")
			v75.Anchored = true
			v75.CanCollide = false
			v75.Size = Vector3.new(2, 2, 1)
			v75.CFrame = CFrame.new(p74)
			v75.Transparency = 1
			v75.Parent = workspace.Effects
			local v76 = v_u_6.Damage.SwordBlockHit:Clone()
			v76.Parent = v75
			v76:Emit(10)
			v_u_3:AddItem(v75, 2.4)
			v_u_10:PlaySound(v_u_7.Kurourushi.Detach.WallHit, v75, game.SoundService.Effect)
		end,
		["Hit"] = function(p77, p78)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_10, (ref) v_u_4, (ref) v_u_8, (ref) v_u_7
			if p77:FindFirstChild("HumanoidRootPart") then
				local v79 = p78:FindFirstChild("HumanoidRootPart")
				if v79 then
					local v80 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
					v80.Position = v79.Position
					v80.Parent = workspace.Effects
					v_u_3:AddItem(v80, 1)
					v80.Sparks.Color = ColorSequence.new(Color3.fromRGB(101, 35, 44))
					v80.Wind.Color = v80.Sparks.Color
					v80.Wind2.Color = v80.Sparks.Color
					v80.Sparks:Emit(30)
					v80.Wind2:Emit(7)
					v_u_10:Flash(p78, Color3.new(1, 1, 1))
					if p77 == v_u_4.Character or p78 == v_u_4.Character then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
					end
					v_u_10:PlaySound(v_u_7.Kurourushi.Detach.Hit, v79, game.SoundService.Effect)
				end
			else
				return
			end
		end
	}
	v_u_9.Effects:Connect(function(p82, ...)
		-- upvalues: (copy) v_u_81
		local v83 = v_u_81[p82]
		if v83 then
			v83(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12
	v_u_9 = v_u_1.GetService("DetachService")
	v_u_10 = v_u_1.GetController("FXController")
	v_u_11 = v_u_1.GetController("KurourushiController")
	v_u_12 = v_u_1.GetController("ToolController")
end
return v13