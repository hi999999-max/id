-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Reggie.Base.BluntTraumaController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
require(v_u_5.Modules.BloodyZee)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "BluntTraumaController"
})
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (copy) v_u_5, (ref) v_u_9
	local v_u_51 = {
		["Start"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_11:PlaySound(v_u_7.Reggie.BluntTrauma.Start, v14, game.SoundService.Effect)
			end
		end,
		["Slash"] = function(p15, p16)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v17 = p15:FindFirstChild("HumanoidRootPart")
			if v17 then
				local v18 = {
					{ 0.15, CFrame.new(0, -1, 0) * CFrame.Angles(-0.08726646259971647, 0.6108652381980153, 3.141592653589793) },
					{ 0.165, CFrame.new(0, 0, 0) * CFrame.Angles(0.2617993877991494, -1.5707963267948966, 0) },
					{ 0.165, CFrame.new(0, -1, 0) * CFrame.Angles(-0.08726646259971647, 0.6108652381980153, 3.141592653589793) },
					{ 0.165, CFrame.new(0, -1, 0) * CFrame.Angles(-0.08726646259971647, 0.6108652381980153, 3.490658503988659) },
					{ 0.125, CFrame.new(0, 0, 0) * CFrame.Angles(-1.5707963267948966, 0, -1.5707963267948966) }
				}
				v_u_11:PlaySound(v_u_7.Reggie.BluntTrauma["Whoosh" .. p16], v17, game.SoundService.Effect)
				if p16 == 5 then
					local v19 = v18[p16][1]
					local v20 = v_u_6.Ryu.Slash:Clone()
					v20.Weld.Part0 = v17
					v20.Weld.C0 = v18[p16][2]
					v20.Parent = workspace.Effects
					v_u_2:AddItem(v20, v19)
					v20.Part1.Mesh.Scale = Vector3.new(-10, 1, 10)
					v20.Part2.Mesh.Scale = Vector3.new(10.445, 3, 10.445)
					local v21 = TweenInfo.new(v19, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
					local v22 = TweenInfo.new(v19, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
					v_u_3:Create(v20.Weld, v21, {
						["C1"] = CFrame.Angles(0, 2.9670597283903604, 0)
					}):Play()
					for _, v23 in v20:GetDescendants() do
						if v23:IsA("Decal") then
							v23.Color3 = Color3.fromRGB(500, 500, 400)
							v_u_3:Create(v23, v22, {
								["Transparency"] = 1
							}):Play()
						else
							if not v23:IsA("SpecialMesh") then
								continue
							end
							v_u_3:Create(v23, v21, {
								["Scale"] = v23.Scale * 1.7
							}):Play()
						end
					end
				end
			else
				return
			end
		end,
		["Break"] = function(p24)
			-- upvalues: (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3
			local v25 = Instance.new("Part")
			v25.Anchored = true
			v25.Transparency = 1
			v25.CanCollide = false
			v25.CanQuery = false
			v25.CFrame = p24.CFrame
			v25.Parent = workspace.Effects
			v_u_2:AddItem(v25, 5)
			v_u_11:PlaySound(v_u_7.Reggie.BluntTrauma["Break" .. math.random(1, 2)], v25, game.SoundService.Effect)
			for _ = 1, 9 do
				local v_u_26 = v_u_6.Hiromi.GavelShard:Clone()
				local v27 = p24.CFrame
				local v28 = CFrame.new
				local v29 = (math.random() - 0.5) * p24.Size.X
				local v30 = (math.random() - 0.5) * p24.Size.Y
				local v31 = (math.random() - 0.5) * p24.Size.Z
				v_u_26.Position = (v27 * v28((Vector3.new(v29, v30, v31)))).Position
				v_u_26.Size = v_u_26.Size * (p24.Size.Magnitude / 3.5)
				v_u_26.Color = p24.Color
				local v32 = math.random(-50, 50)
				local v33 = math.random(-50, 50)
				local v34 = math.random
				v_u_26.Velocity = Vector3.new(v32, v33, v34(-50, 50))
				local v35 = math.random(-50, 50)
				local v36 = math.random(-50, 50)
				local v37 = math.random
				v_u_26.RotVelocity = Vector3.new(v35, v36, v37(-50, 50))
				v_u_26.Parent = workspace.Effects
				v_u_2:AddItem(v_u_26, 2)
				task.delay(1, function()
					-- upvalues: (ref) v_u_3, (copy) v_u_26
					v_u_3:Create(v_u_26, TweenInfo.new(1), {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
				end)
			end
		end,
		["Hit"] = function(p38, p39, p40, _)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			if p38:FindFirstChild("HumanoidRootPart") then
				local v41 = p39:FindFirstChild("HumanoidRootPart")
				if v41 then
					v_u_11:Flash(p39, Color3.new(1, 1, 1))
					v_u_11:PlaySound(v_u_7.Reggie.BluntTrauma["Hit" .. p40], v41, game.SoundService.Effect)
					if v_u_4.Character == p38 or v_u_4.Character == p39 then
						v_u_8.CurrentShaker:Shake(p40 == 5 and v_u_8.Presets.SnapOh or (p40 == 4 and v_u_8.Presets.Snap or v_u_8.Presets.HeavyHit))
					end
				end
			else
				return
			end
		end,
		["Align"] = function(p42, p43, p44)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4
			local v45 = p42:FindFirstChild("HumanoidRootPart")
			if v45 then
				local v46 = p43:FindFirstChild("HumanoidRootPart")
				if v46 then
					v_u_11:PlaySound(v_u_7.Reggie.BluntTrauma.Jump, v45, game.SoundService.Effect)
					if v_u_4.Character == p42 then
						repeat
							task.wait()
							p44.Position = v46.Position - v45.CFrame.LookVector * 4 + Vector3.new(0, 1.5, 0)
						until p42.Parent == nil or (p43.Parent == nil or (p43:GetAttribute("Ragdoll") == 0 or p44.Parent == nil))
					end
				end
			else
				return
			end
		end,
		["Dizzy"] = function(p47, p48, p49)
			-- upvalues: (ref) v_u_5
			if p47:FindFirstChild("HumanoidRootPart") then
				if p48:FindFirstChild("HumanoidRootPart") then
					local v_u_50 = v_u_5.Utils.Damage.Dizzy:Clone()
					v_u_50.Parent = workspace.Effects
					v_u_50.Weld.Part0 = p48.Head
					p49.Destroying:Once(function()
						-- upvalues: (copy) v_u_50
						v_u_50:Destroy()
					end)
				end
			else
				return
			end
		end
	}
	v_u_9.Effects:Connect(function(p52, ...)
		-- upvalues: (copy) v_u_51
		local v53 = v_u_51[p52]
		if v53 then
			v53(...)
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("BluntTraumaService")
	v_u_10 = v_u_1.GetController("HitboxController")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12