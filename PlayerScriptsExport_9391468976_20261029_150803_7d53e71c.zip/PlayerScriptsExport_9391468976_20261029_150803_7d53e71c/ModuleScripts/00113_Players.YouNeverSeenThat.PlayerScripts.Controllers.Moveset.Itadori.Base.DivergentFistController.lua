-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Itadori.Base.DivergentFistController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.LightningBeams)
local v_u_10 = Random.new()
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "DivergentFistController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (copy) v_u_10, (copy) v_u_9, (ref) v_u_11
	local v_u_83 = {
		["CurseBuild"] = function(p14)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_12:PlaySound(v_u_7.Itadori.DivergentFist.Crack, v15, game.SoundService.Effect)
				task.wait(0.142)
				v_u_12:Flash(p14, Color3.new(1, 1, 1), 0.275)
			end
		end,
		["DivergentSwing"] = function(p16, p17)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v_u_18 = p16:FindFirstChild("HumanoidRootPart")
			if v_u_18 then
				local v_u_19 = v_u_6.Itadori.DivergentFist.DivergentSwing:Clone()
				v_u_19.Weld.Part1 = v_u_18
				v_u_19.Parent = workspace.Effects
				v_u_2:AddItem(v_u_19, 1)
				v_u_12:PlaySound(v_u_7.Itadori.DivergentFist.Swing, v_u_18, game.SoundService.Effect)
				if p17 == true then
					v_u_19.BlackFlashSparks:Emit(20)
					v_u_19.BlackFlashWind:Emit(10)
					v_u_19.BlackFlashLight.Enabled = true
					v_u_3:Create(v_u_19.BlackFlashLight, TweenInfo.new(0.6), {
						["Brightness"] = 0
					}):Play()
					v_u_12:PlaySound(v_u_7.Itadori.DivergentFist.BlackFlash, v_u_18, game.SoundService.Effect)
					if v_u_4.Character == p16 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
						return
					end
				else
					v_u_19.Wind:Emit(7)
					v_u_19.Charge:Emit(1)
					v_u_19.Glow:Emit(1)
					task.delay(0.3, function()
						-- upvalues: (copy) v_u_19, (ref) v_u_3, (ref) v_u_12, (ref) v_u_7, (copy) v_u_18
						v_u_19.DivergentLight.Enabled = true
						v_u_3:Create(v_u_19.DivergentLight, TweenInfo.new(0.6), {
							["Brightness"] = 0
						}):Play()
						v_u_12:PlaySound(v_u_7.Itadori.DivergentFist.Divergent, v_u_18, game.SoundService.Effect)
						v_u_19.Flames:Emit(10)
						v_u_19.Sparks:Emit(20)
						v_u_19.Wind2:Emit(6)
					end)
					if v_u_4.Character == p16 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
						task.wait(0.3)
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
				end
			end
		end,
		["DivergentHit"] = function(p20)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v21 = p20:FindFirstChild("HumanoidRootPart")
			if v21 then
				v_u_12:Flash(p20, Color3.new(0.333333, 0.666667, 1))
				v_u_12:PlaySound(v_u_7.Itadori.DivergentFist.DivergentHit, v21, game.SoundService.Effect)
				if v_u_4.Character == p20 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["DivergentStun"] = function(p22, p23)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v24 = p22:FindFirstChild("HumanoidRootPart")
			if v24 then
				local v25 = p23:FindFirstChild("HumanoidRootPart")
				if v25 then
					local v26 = v_u_6.Itadori.DivergentFist.DivergentStun:Clone()
					v26.CFrame = CFrame.lookAt(v25.Position, v24.Position)
					v26.Parent = workspace.Effects
					v_u_2:AddItem(v26, 0.8)
					v_u_3:Create(v26, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(0, 0, 15)
					}):Play()
					v26.Attachment.Lightning:Emit(5)
					v26.Attachment.Sparks:Emit(30)
					v26.Attachment.Glow:Emit(1)
					v26.Attachment.Wind:Emit(15)
					v26.Attachment.Flames:Emit(15)
					v_u_3:Create(v26.PointLight, TweenInfo.new(0.8), {
						["Brightness"] = 0
					}):Play()
					v_u_12:Flash(p23, Color3.new(0.333333, 0.666667, 1), 1.3)
					v_u_12:PlaySound(v_u_7.Itadori.DivergentFist.DivergentHit, v25, game.SoundService.Effect)
					if v_u_4.Character == p23 or v_u_4.Character == p22 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["BlackFlashHit"] = function(p27, p28)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			if p27:FindFirstChild("HumanoidRootPart") then
				local v29 = p28:FindFirstChild("HumanoidRootPart")
				if v29 then
					for _, v30 in p28:GetChildren() do
						if not v30:IsA("BasePart") then
							continue
						end
						local v31 = v_u_6.Itadori.DivergentFist.FlashBurn:Clone()
						v31.Parent = v30
						v_u_2:AddItem(v31, 1)
					end
					local v_u_32 = v_u_6.Itadori.DivergentFist.BlackFlashHit:Clone()
					v_u_32.Position = v29.Position
					v_u_32.Parent = workspace.Effects
					v_u_2:AddItem(v_u_32, 1)
					v_u_12:Flash(p28, Color3.new(1, 0, 0))
					v_u_12:PlaySound(v_u_7.Itadori.DivergentFist.BlackFlashHit, v29, game.SoundService.Effect)
					v_u_32.Wind2:Emit(8)
					v_u_3:Create(v_u_32.PointLight, TweenInfo.new(1), {
						["Brightness"] = 0
					}):Play()
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_32
						v_u_32.Blast:Emit(8)
						v_u_32.Sparks:Emit(15)
						v_u_32.Lightning:Emit(6)
						v_u_32.Wind:Emit(7)
					end)
					if v_u_4.Character == p27 or v_u_4.Character == p28 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
						if _G.Settings.Flash ~= true then
							return
						end
						local v33 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
						v33.Parent = game.Lighting
						task.wait(0.04)
						v33.TintColor = Color3.new(1, 1, 1)
						task.wait(0.04)
						v33.Brightness = 200
						v33.Contrast = -1000
						task.wait(0.04)
						v33:Destroy()
					end
				end
			else
				return
			end
		end,
		["BlackFlashChain"] = function(p34, p35)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			if p34:FindFirstChild("HumanoidRootPart") then
				local v36 = p35:FindFirstChild("HumanoidRootPart")
				if v36 then
					local v_u_37 = v_u_6.Itadori.DivergentFist.BlackFlashHit:Clone()
					v_u_37.Position = v36.Position
					v_u_37.Parent = workspace.Effects
					v_u_2:AddItem(v_u_37, 1)
					v_u_12:Flash(p35, Color3.new(1, 0, 0))
					v_u_12:PlaySound(v_u_7.Itadori.PerfectHit, v36, game.SoundService.Effect)
					v_u_37.Wind2:Emit(8)
					v_u_3:Create(v_u_37.PointLight, TweenInfo.new(1), {
						["Brightness"] = 0
					}):Play()
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_37
						v_u_37.Blast:Emit(8)
						v_u_37.Sparks:Emit(15)
						v_u_37.Lightning:Emit(6)
						v_u_37.Wind:Emit(7)
					end)
					if v_u_4.Character == p34 or v_u_4.Character == p35 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["BlackFlashFinisher"] = function(p38, p39, p40)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v41 = p38:FindFirstChild("HumanoidRootPart")
			if v41 then
				local v42 = p39:FindFirstChild("HumanoidRootPart")
				if v42 then
					for _, v43 in p39:GetChildren() do
						if not v43:IsA("BasePart") then
							continue
						end
						local v44 = v_u_6.Itadori.DivergentFist.FlashBurn:Clone()
						v44.Parent = v43
						v_u_2:AddItem(v44, 1)
					end
					local v45 = v_u_6.Itadori.DivergentFist.BlackFlashLaunch:Clone()
					v45.CFrame = v41.CFrame * CFrame.new(2, 1, -5)
					v45.Parent = workspace.Effects
					v45.Wind:Emit(20)
					v45.Sparks:Emit(20)
					v45.Flare:Emit(20)
					v45.Lightning:Emit(25)
					v45.Back1.Back:Emit(1)
					v45.Back2.Back:Emit(1)
					v_u_3:Create(v45.Back1, TweenInfo.new(2), {
						["CFrame"] = v45.Back1.CFrame - v45.Back1.CFrame.LookVector * 20
					}):Play()
					v_u_3:Create(v45.Back2, TweenInfo.new(2), {
						["CFrame"] = v45.Back2.CFrame - v45.Back2.CFrame.LookVector * 20
					}):Play()
					v_u_3:Create(v45.PointLight, TweenInfo.new(1), {
						["Brightness"] = 0
					}):Play()
					v_u_2:AddItem(v45, 3)
					v_u_12:PlaySound(v_u_7.Itadori.DivergentFist.BlackFlashHit, v42, game.SoundService.Effect)
					if not p40 then
						v_u_12:PlaySound(v_u_7.Itadori.DivergentFist.Voice, v41, game.SoundService.Effect)
					end
					v_u_12:Bleed(p39)
					if v_u_4.Character == p38 or v_u_4.Character == p39 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
						if _G.Settings.Flash ~= true then
							return
						end
						local v46 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
						v46.Parent = game.Lighting
						task.wait(0.04)
						v46.TintColor = Color3.new(1, 1, 1)
						task.wait(0.04)
						v46.Brightness = 200
						v46.Contrast = -1000
						task.wait(0.04)
						v46:Destroy()
					end
				end
			else
				return
			end
		end,
		["Finisher"] = function(p47)
			-- upvalues: (ref) v_u_12
			if p47.HumanoidRootPart then
				v_u_12:Bleed(p47)
			end
		end,
		["MusicStart"] = function(p48)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v49 = p48:FindFirstChild("HumanoidRootPart")
			if v49 then
				v_u_12:PlaySound(v_u_7.Itadori.DivergentFist.Woosh, v49, game.SoundService.Music)
			end
		end,
		["Music"] = function(p50)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v51 = p50:FindFirstChild("HumanoidRootPart")
			if v51 then
				v_u_12:PlaySound(v_u_7.Itadori.DivergentFist.Wapam, v51, game.SoundService.Music)
			end
		end,
		["BlackFlashHitHard"] = function(p52, p53, p_u_54)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8, (ref) v_u_10, (ref) v_u_9
			local v_u_55 = p52:FindFirstChild("HumanoidRootPart")
			if v_u_55 then
				local v_u_56 = p53:FindFirstChild("HumanoidRootPart")
				if v_u_56 then
					local v_u_57 = v_u_6.Todo.BlackFlashHit:Clone()
					v_u_57.Position = v_u_56.Position
					v_u_57.Parent = workspace.Effects
					v_u_2:AddItem(v_u_57, 2)
					v_u_12:Flash(p53, Color3.new(1, 0, 0), 2)
					v_u_12:PlaySound(v_u_7.Itadori.DivergentFist.BlackFlashHit, v_u_56, game.SoundService.Effect)
					v_u_12:PlaySound(v_u_7.Mahito.BlackFlash, v_u_56, game.SoundService.Effect)
					v_u_12:PlaySound(v_u_7.Itadori.DivergentFist.Voice2, v_u_56, game.SoundService.Voice)
					task.delay(0.07, function()
						-- upvalues: (copy) v_u_57, (ref) v_u_3
						v_u_57.Wind2:Emit(10)
						v_u_57.Sparks:Emit(40)
						v_u_57.Sparks2:Emit(30)
						v_u_57.Lightning:Emit(10)
						v_u_3:Create(v_u_57, TweenInfo.new(0.1), {
							["Size"] = Vector3.new(18, 18, 18),
							["Transparency"] = 1
						}):Play()
					end)
					if v_u_4.Character == p52 or v_u_4.Character == p53 then
						task.spawn(function()
							-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_3
							v_u_8.CurrentShaker:ShakeSustain(v_u_8.Presets.Snap):StartFadeOut(1.8)
							if _G.Settings.Flash == true then
								local v58 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
								v58.Parent = game.Lighting
								task.wait(0.03)
								v58.Brightness = 200
								v58.Contrast = -1000
								task.wait(0.03)
								v58.TintColor = Color3.new(1, 1, 1)
								v58.Brightness = -200
								v58.Contrast = 1000
								task.wait(0.03)
								v58:Destroy()
							end
							game.Lighting.ExposureCompensation = 2
							v_u_3:Create(game.Lighting, TweenInfo.new(0.5), {
								["ExposureCompensation"] = 0
							}):Play()
						end)
						local v_u_59 = v_u_6.Itadori.DivergentFist.FinisherScene:Clone()
						v_u_59.Parent = workspace.Effects
						v_u_2:AddItem(v_u_59, 1.8)
						if _G.Settings.Flash ~= true then
							for _, v60 in v_u_59:GetDescendants() do
								if not v60:IsA("ParticleEmitter") then
									continue
								end
								v60.Rate = v60.Rate / 10
							end
						end
						task.delay(1.2, function()
							-- upvalues: (copy) v_u_59, (ref) v_u_3
							local v61 = TweenInfo.new(0.6, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
							for _, v62 in v_u_59:GetDescendants() do
								if not v62:IsA("ParticleEmitter") then
									continue
								end
								v_u_3:Create(v62, v61, {
									["TimeScale"] = 0.05
								}):Play()
							end
						end)
						local v_u_63 = Instance.new("Model", v_u_59)
						local v64 = Instance.new("Highlight", v_u_63)
						v64.DepthMode = Enum.HighlightDepthMode.Occluded
						v64.OutlineColor = Color3.new(1, 0, 0)
						v64.FillColor = Color3.new(0, 0, 0)
						v64.FillTransparency = 0
						local v_u_65 = tick()
						task.spawn(function()
							-- upvalues: (copy) v_u_59, (copy) v_u_55, (copy) v_u_65, (copy) p_u_54
							repeat
								v_u_59.CFrame = v_u_55.CFrame - v_u_55.Position + workspace.CurrentCamera.CFrame.Position
								local v66 = (tick() - v_u_65) / 1.8
								local v67 = math.clamp(v66, 0, 1)
								v_u_59.Smear.Color = ColorSequence.new(Color3.fromRGB(85, 170, 255):Lerp(Color3.fromRGB(255, 118, 5), v67), Color3.fromRGB(0, 0, 0):Lerp(Color3.fromRGB(200, 0, 0), v67))
								task.wait()
							until not (p_u_54:IsDescendantOf(workspace) and v_u_59.Parent)
							v_u_59:Destroy()
						end)
						task.spawn(function()
							-- upvalues: (copy) v_u_56, (ref) v_u_10, (ref) v_u_9, (copy) v_u_63, (copy) v_u_65, (ref) v_u_3, (ref) v_u_2
							local v68 = v_u_56.RootAttachment
							repeat
								local v69 = Instance.new("Attachment", v_u_56)
								v69.Position = v_u_10:NextUnitVector() * 30
								local v_u_70 = v_u_9.new(v68, v69, nil, v_u_63)
								v_u_70.Color = Color3.new(1, 0, 0)
								v_u_70.PulseSpeed = 300
								v_u_70.FadeLength = 0.35
								v_u_70.MaxRadius = 20
								v_u_70.MinRadius = 0
								v_u_70.AnimationSpeed = _G.Settings.Flash == true and 75 or 5
								v_u_70.MinThicknessMultiplier = 0.1
								v_u_70.MaxThicknessMultiplier = 3
								task.delay(0.1, function()
									-- upvalues: (copy) v_u_70
									v_u_70:Destroy()
								end)
								task.wait(0.02)
							until not v_u_63.Parent or (not v_u_56.Parent or tick() - v_u_65 > 1.2)
							if v_u_63.Parent and v_u_56.Parent then
								local v71 = Instance.new("PointLight", v_u_56)
								v71.Color = Color3.fromRGB(255, 170, 0)
								v71.Range = 30
								v_u_3:Create(v71, TweenInfo.new(0.6), {
									["Brightness"] = 20
								}):Play()
								v_u_2:AddItem(v71, 0.6)
								for _ = 1, 10 do
									local v72 = Instance.new("Attachment", v_u_56)
									v72.Position = v_u_10:NextUnitVector() * 30
									local v_u_73 = v_u_9.new(v68, v72, nil, v_u_63)
									v_u_73.Color = Color3.new(1, 0, 0)
									v_u_73.PulseSpeed = 5
									v_u_73.FadeLength = 1
									v_u_73.MaxRadius = 30
									v_u_73.MinRadius = 0
									v_u_73.AnimationSpeed = 5
									v_u_73.MinThicknessMultiplier = 0.1
									v_u_73.MaxThicknessMultiplier = 3
									task.wait()
									task.delay(1, function()
										-- upvalues: (copy) v_u_73
										v_u_73:Destroy()
									end)
								end
							end
						end)
					end
				end
			else
				return
			end
		end,
		["BlackFlashFinisherHard"] = function(p74, p75)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_9, (ref) v_u_4, (ref) v_u_8
			local v76 = p74:FindFirstChild("HumanoidRootPart")
			if v76 then
				local v77 = p75:FindFirstChild("HumanoidRootPart")
				if v77 then
					local v78 = v_u_6.Itadori.DivergentFist.BlackFlashLaunch:Clone()
					v78.CFrame = v76.CFrame * CFrame.new(2, 1, -5)
					v78.Parent = workspace.Effects
					v78.Wind:Emit(20)
					v78.Sparks:Emit(20)
					v78.Flare:Emit(20)
					v78.Lightning:Emit(25)
					v78.Back1.Back:Emit(1)
					v78.Back2.Back:Emit(1)
					v_u_3:Create(v78.Back1, TweenInfo.new(2), {
						["CFrame"] = v78.Back1.CFrame - v78.Back1.CFrame.LookVector * 20
					}):Play()
					v_u_3:Create(v78.Back2, TweenInfo.new(2), {
						["CFrame"] = v78.Back2.CFrame - v78.Back2.CFrame.LookVector * 20
					}):Play()
					v_u_3:Create(v78.PointLight, TweenInfo.new(1), {
						["Brightness"] = 0
					}):Play()
					v_u_2:AddItem(v78, 3)
					v_u_12:PlaySound(v_u_7.Itadori.DivergentFist.BlackFlashHit, v77, game.SoundService.Effect)
					v_u_12:Bleed(p75)
					local v79 = Instance.new("Model", workspace.Effects.Bolt)
					local v80 = Instance.new("Highlight", v79)
					v80.DepthMode = Enum.HighlightDepthMode.Occluded
					v80.OutlineColor = Color3.new(1, 0, 0)
					v80.FillColor = Color3.new(0, 0, 0)
					v80.FillTransparency = 0
					v_u_2:AddItem(v79, 1.2)
					local v_u_81 = v_u_9.new(v78.Core, v77.RootAttachment, nil, v79)
					v_u_81.Color = Color3.new(1, 0, 0)
					v_u_81.PulseSpeed = 1000
					v_u_81.FadeLength = 0.35
					v_u_81.MaxRadius = 20
					v_u_81.MinRadius = 0
					v_u_81.AnimationSpeed = 300
					v_u_81.MinThicknessMultiplier = 0.5
					v_u_81.MaxThicknessMultiplier = 10
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_81
						v_u_81.MaxThicknessMultiplier = 5
						task.wait(0.1)
						v_u_81.MaxThicknessMultiplier = 3
						task.wait(0.1)
						v_u_81.MaxThicknessMultiplier = 2
						task.wait(0.1)
						v_u_81.MaxThicknessMultiplier = 1
						task.wait(0.4)
						v_u_81:Destroy()
					end)
					if v_u_4.Character == p74 or v_u_4.Character == p75 then
						v_u_8.CurrentShaker:ShakeSustain(v_u_8.Presets.Snap):StartFadeOut(1.5)
						if _G.Settings.Flash == true then
							local v82 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
							v82.Parent = game.Lighting
							task.wait(0.04)
							v82.TintColor = Color3.new(1, 1, 1)
							task.wait(0.04)
							v82.Brightness = 200
							v82.Contrast = -1000
							task.wait(0.04)
							v82:Destroy()
						end
						game.Lighting.ExposureCompensation = 3
						v_u_3:Create(game.Lighting, TweenInfo.new(2, Enum.EasingStyle.Sine), {
							["ExposureCompensation"] = 0
						}):Play()
					end
				end
			else
				return
			end
		end
	}
	v_u_11.Effects:Connect(function(p84, ...)
		-- upvalues: (copy) v_u_83
		local v85 = v_u_83[p84]
		if v85 then
			v85(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12
	v_u_11 = v_u_1.GetService("DivergentFistService")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13