-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Reggie.ReggieController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "ReggieController"
})
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (copy) v_u_5, (ref) v_u_9
	local v_u_95 = {
		["Hit"] = function(p13, p14)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v15 = p13:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_11:Flash(p13, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Gojo.M1:FindFirstChild("Hit" .. p14), v15, game.SoundService.Effect)
			end
		end,
		["ChaseHit"] = function(p16, p17)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2
			local v18 = p16:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = p17:FindFirstChild("HumanoidRootPart")
				if v19 then
					v_u_11:Flash(p17, Color3.new(1, 1, 1))
					v_u_11:PlaySound(v_u_7.Gojo.M1:FindFirstChild("Hit3"), v19, game.SoundService.Effect)
					local v20 = v_u_6.ChaseHit:Clone()
					local v21 = CFrame.new
					local v22 = v19.Position
					local v23 = v18.Position.X
					local v24 = v19.Position.Y
					local v25 = v18.Position.Z
					v20.CFrame = v21(v22, (Vector3.new(v23, v24, v25))) * CFrame.Angles(0, 3.141592653589793, 0)
					v20.Parent = workspace.Effects
					v20.Ring:Emit(7)
					v20.Sparks:Emit(12)
					v_u_2:AddItem(v20, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p26)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7
			local v27 = p26.HumanoidRootPart
			if v27 then
				local v28 = v_u_6.Gojo.LapseBlue.Throw:Clone()
				v28.CFrame = v27.CFrame * CFrame.new(0, 1, -4)
				v28.Size = Vector3.new(0, 0, 2)
				v28.Parent = workspace.Effects
				v_u_3:Create(v28, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v28, 0.3)
				v_u_11:PlaySound(v_u_7.Misc.Chase, v27, game.SoundService.Effect)
				v_u_11:DustTrail(p26, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p29)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v30 = p29:FindFirstChild("HumanoidRootPart")
			if v30 then
				v_u_11:PlaySound(v_u_7.Misc.Swing.Fist, v30, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p31, p32, p33)
			-- upvalues: (ref) v_u_11
			if p33 == "Down" then
				v_u_11:ArmFlash(p31["Right Leg"], Color3.fromRGB(255, 255, 255), 0.4)
				return
			elseif p33 == "Up" then
				v_u_11:ArmFlash(p31["Right Arm"], Color3.fromRGB(255, 255, 255), 0.3)
				return
			elseif p32 == 1 then
				v_u_11:ArmFlash(p31["Left Arm"], Color3.fromRGB(255, 255, 255), 0.3)
				return
			elseif p32 == 2 then
				v_u_11:ArmFlash(p31["Right Arm"], Color3.fromRGB(255, 255, 255), 0.3)
				return
			elseif p32 == 3 then
				v_u_11:ArmFlash(p31["Left Leg"], Color3.fromRGB(255, 255, 255), 0.3)
			elseif p32 == 4 then
				v_u_11:ArmFlash(p31["Left Leg"], Color3.fromRGB(255, 255, 255), 0.4)
			end
		end,
		["Launch"] = function(p34, p35)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v36 = p34:FindFirstChild("HumanoidRootPart")
			if v36 then
				local v37 = v_u_6.Gojo.LapseBlue.Throw:Clone()
				v37.CFrame = CFrame.new(v36.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v37.Size = Vector3.new(0, 0, 5)
				v37.Parent = workspace.Effects
				v_u_3:Create(v37, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v37.Position + Vector3.new(0, p35, 0)
				}):Play()
				v_u_2:AddItem(v37, 0.3)
				if p35 < 0 then
					v_u_11:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Break, v36, game.SoundService.Effect)
					v_u_11:DustBreak(v36.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_4:DistanceFromCharacter(v36.Position) < 20 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
					end
				end
			end
		end,
		["MoveSwap"] = function(p38, p39, p40)
			-- upvalues: (ref) v_u_4, (ref) v_u_3
			if p38 == v_u_4.Character then
				local v41 = v_u_4.PlayerGui:WaitForChild("Main").Controls.Moveset
				local v42 = v41:FindFirstChild("ReggieSlot")
				if v42 and not p40 then
					v42.BackgroundColor3 = Color3.new(1, 1, 1)
					v_u_3:Create(v42, TweenInfo.new(1), {
						["BackgroundColor3"] = Color3.fromRGB(31, 31, 31)
					}):Play()
				end
				if p39 then
					for _, v43 in v41:GetChildren() do
						if not v43:IsA("Frame") or v43.ItemName.Text ~= p39.Name then
							continue
						end
						v43.BackgroundColor3 = Color3.new(1, 1, 1)
						v_u_3:Create(v43, TweenInfo.new(1), {
							["BackgroundColor3"] = Color3.fromRGB(31, 31, 31)
						}):Play()
					end
				end
			end
		end,
		["Discard"] = function(p44, p45)
			-- upvalues: (ref) v_u_4, (ref) v_u_6
			if v_u_4.Character == p44 then
				local v_u_46 = v_u_6.Reggie.Highlight:Clone()
				v_u_46.Parent = p44
				v_u_46.Adornee = p44
				p45.Destroying:Connect(function()
					-- upvalues: (copy) v_u_46
					v_u_46:Destroy()
				end)
			end
		end,
		["GoldSeal"] = function(p47, p48)
			-- upvalues: (ref) v_u_4, (ref) v_u_6
			if v_u_4.Character == p47 then
				local v_u_49 = v_u_6.Reggie.Highlight:Clone()
				v_u_49.FillColor = Color3.fromRGB(255, 217, 102)
				v_u_49.OutlineColor = Color3.fromRGB(255, 217, 102)
				v_u_49.Parent = p47
				v_u_49.Adornee = p47
				p48.Destroying:Connect(function()
					-- upvalues: (copy) v_u_49
					v_u_49:Destroy()
				end)
			end
		end,
		["DiscardWhoosh"] = function(p50)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v51 = p50:FindFirstChild("HumanoidRootPart")
			if v51 then
				v_u_11:PlaySound(v_u_7.Reggie.Discard, v51, game.SoundService.Effect)
			end
		end,
		["Burn"] = function(p52, p53, p54)
			-- upvalues: (ref) v_u_6, (ref) v_u_11, (ref) v_u_2, (ref) v_u_7
			local v55 = p52:FindFirstChild("HumanoidRootPart")
			if v55 then
				local v56 = v_u_6.Reggie.ReceiptBurn:Clone()
				v56.Parent = workspace.Effects
				v56.Anchored = true
				if p53 then
					p54 = p53.MainReceipt.CFrame or p54
				end
				v56.CFrame = p54
				v_u_11:PlayParticles(v56)
				v_u_2:AddItem(v56, 3)
				v_u_11:PlaySound(v_u_7.Reggie.CouponBurn, v55, game.SoundService.Effect)
			end
		end,
		["Spa"] = function(p57, _)
			-- upvalues: (ref) v_u_6, (ref) v_u_11, (ref) v_u_2
			local v58 = p57:FindFirstChild("HumanoidRootPart")
			if v58 then
				local v59 = v_u_6.Reggie.Spotlight:Clone()
				v59.Weld.Part0 = v58
				v59.Parent = workspace.Effects
				v_u_11:PlayParticles(v59)
				v_u_2:AddItem(v59, 3)
			end
		end,
		["Sweep"] = function(p60)
			-- upvalues: (ref) v_u_6, (ref) v_u_2
			local v61 = p60:FindFirstChild("HumanoidRootPart")
			if v61 then
				local v62 = v_u_6.Reggie.SweepStars:Clone()
				v62.CFrame = v61.CFrame * CFrame.new(0, 1.75, -0.9) * CFrame.Angles(0, -0.4363323129985824, 0.4363323129985824)
				v62.Parent = workspace.Effects
				for _, v63 in v62.Attachment:GetChildren() do
					v63:Emit(v63:GetAttribute("EmitCount"))
				end
				v_u_2:AddItem(v62, 1)
			end
		end,
		["Ultimate"] = function(p64)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v65 = p64:FindFirstChild("HumanoidRootPart")
			if v65 then
				v_u_11:PlaySound(v_u_7.Reggie.Ultimate, v65, game.SoundService.Effect)
			end
		end,
		["Chat"] = function(p66)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2
			if p66:FindFirstChild("HumanoidRootPart") then
				local v67 = v_u_6.Reggie.Dialogue:Clone()
				v67.Parent = p66.Torso
				local v68 = v67.Chat1.Position
				v67.Chat1.Position = v68 - UDim2.new(0, 0, 0.15, 0)
				v_u_3:Create(v67.Chat1, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v68
				}):Play()
				v_u_3:Create(v67.Chat1, TweenInfo.new(0.3), {
					["BackgroundTransparency"] = 0
				}):Play()
				v_u_3:Create(v67.Chat1.Sub, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				task.wait(0.5)
				local v69 = v67.Chat2.Position
				v67.Chat2.Position = v69 - UDim2.new(0, 0, 0.15, 0)
				v_u_3:Create(v67.Chat2, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v69
				}):Play()
				v_u_3:Create(v67.Chat2, TweenInfo.new(0.3), {
					["BackgroundTransparency"] = 0
				}):Play()
				v_u_3:Create(v67.Chat2.Sub, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				task.wait(1.5)
				v_u_2:AddItem(v67, 0.6)
				for _, v70 in v67:GetDescendants() do
					if v70:IsA("Frame") then
						v_u_3:Create(v70, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["Position"] = nil,
							["BackgroundTransparency"] = 1,
							["Position"] = v70.Position - UDim2.new(0, 0, 0.2, 0)
						}):Play()
					else
						if not v70:IsA("TextLabel") then
							continue
						end
						v_u_3:Create(v70, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["TextTransparency"] = 1
						}):Play()
					end
				end
			end
		end,
		["CouponStart"] = function(p71)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v72 = p71:FindFirstChild("HumanoidRootPart")
			if v72 then
				v_u_11:PlaySound(v_u_7.Reggie.CouponWhoosh, v72, game.SoundService.Effect)
			end
		end,
		["LitteringStart"] = function(p73)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v74 = p73:FindFirstChild("HumanoidRootPart")
			if v74 then
				v_u_11:PlaySound(v_u_7.Reggie.Littering.Start, v74, game.SoundService.Effect)
			end
		end,
		["LitteringLand"] = function(p75)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			v_u_11:PlaySound(v_u_7.Reggie.Littering.Land, p75, game.SoundService.Effect)
		end,
		["LitteringActivate"] = function(p76)
			-- upvalues: (ref) v_u_6, (ref) v_u_11, (ref) v_u_2, (ref) v_u_7
			for _, v77 in p76.CE_Infuse:GetChildren() do
				v77.Enabled = true
				v77:Emit(1)
			end
			local v78 = v_u_6.Reggie.ReceiptBurn:Clone()
			v78.Parent = workspace.Effects
			v78.Anchored = true
			v78.CFrame = p76.CFrame
			v_u_11:PlayParticles(v78)
			v_u_2:AddItem(v78, 3)
			v_u_11:PlaySound(v_u_7.Reggie.CouponBurn2, p76, game.SoundService.Effect)
		end,
		["Ball"] = function(p79, p80)
			-- upvalues: (ref) v_u_5, (ref) v_u_3, (ref) v_u_2, (ref) v_u_6, (ref) v_u_11, (ref) v_u_7
			local v_u_81 = v_u_5.Utils.Reggie.Ball:Clone()
			v_u_81.Size = v_u_81.Size * (math.random(135, 175) / 100 / (p79:GetAttribute("Delay") and 1.5 or 1))
			v_u_81.Color = Color3.fromRGB(math.random(100, 170), math.random(100, 170), math.random(100, 170))
			v_u_81.Position = p79.Position + p79.CFrame.UpVector * 2
			local v82 = p79.CFrame.UpVector * math.random(50, 110)
			local v83 = math.random(-5, 5)
			local v84 = math.random
			v_u_81.AssemblyLinearVelocity = v82 + Vector3.new(v83, 0, v84(-5, 5))
			local v85 = math.random(-20, 20)
			local v86 = math.random(-20, 20)
			local v87 = math.random
			v_u_81.AssemblyAngularVelocity = Vector3.new(v85, v86, v87(-20, 20))
			v_u_81.CanCollide = true
			v_u_81.Parent = workspace.Effects
			task.delay(2, function()
				-- upvalues: (ref) v_u_3, (copy) v_u_81, (ref) v_u_2
				v_u_3:Create(v_u_81, TweenInfo.new(0.5), {
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v_u_81, 0.5)
			end)
			local v88 = v_u_6.Gojo.LapseBlue.Throw:Clone()
			v88.CFrame = CFrame.new(v_u_81.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
			v88.Size = Vector3.new(0, 0, 5)
			v88.Parent = workspace.Effects
			v_u_3:Create(v88, TweenInfo.new(0.3), {
				["Size"] = Vector3.new(8, 8, 0),
				["Transparency"] = 1,
				["Position"] = nil,
				["Position"] = v88.Position + Vector3.new(0, 3, 0)
			}):Play()
			v_u_2:AddItem(v88, 0.3)
			v_u_11:PlaySound(v_u_7.Reggie.Littering.BallSpawn, v_u_81, game.SoundService.Effect).Volume = p80 and 0.16666666666666666 or 0.3333333333333333
		end,
		["BallHit"] = function(p89)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v90 = p89:FindFirstChild("HumanoidRootPart")
			if v90 then
				v_u_11:PlaySound(v_u_7.Reggie.Littering.BallHit, v90, game.SoundService.Effect)
			end
		end,
		["RainbowSealExplode"] = function(p91)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_8
			local v92 = p91:FindFirstChild("HumanoidRootPart")
			if v92 then
				local v93 = v92.Position
				local v94 = v_u_6.Reggie.BikeExplode:Clone()
				v94.Parent = workspace.Effects
				v94.Position = v93
				v_u_2:AddItem(v94, 6)
				v_u_11:PlayParticles(v94)
				v_u_11:PlaySound(v_u_7.Reggie.DroneStrike.Explode, v94, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v93).Magnitude < 35 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end
	}
	v_u_9.Effects:Connect(function(p96, ...)
		-- upvalues: (copy) v_u_95
		local v97 = v_u_95[p96]
		if v97 then
			v97(...)
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("ReggieService")
	v_u_10 = v_u_1.GetController("HitboxController")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12