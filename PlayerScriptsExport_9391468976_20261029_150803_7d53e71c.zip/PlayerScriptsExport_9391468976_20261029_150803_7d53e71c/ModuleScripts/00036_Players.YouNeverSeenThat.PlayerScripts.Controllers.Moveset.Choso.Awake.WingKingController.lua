-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Choso.Awake.WingKingController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "WingKingController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_6, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (copy) v_u_4, (copy) v_u_2, (copy) v_u_7, (ref) v_u_10
	local v_u_60 = {
		["Dash"] = function(p14, p15)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_6, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9, (ref) v_u_4, (ref) v_u_2
			local v16 = p14:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_12:PlaySound(v_u_8.Hakari.OverLuck.Dash, v16, game.SoundService.Effect)
				local v17 = v_u_6.Utils.Itadori.RushWind:Clone()
				v17.CFrame = v16.CFrame
				v17.Parent = workspace.Effects
				v17.Dust:Emit(7)
				v17.Ring:Emit(7)
				v17.Dash1.Dash:Emit(1)
				v17.Dash2.Dash:Emit(1)
				v_u_3:AddItem(v17, 2)
				v_u_12:ArmFlash(p14["Left Arm"], Color3.fromRGB(170, 0, 0), 0.3)
				if v_u_5.Character == p14 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					local v18 = Instance.new("NumberValue", p15)
					v18.Value = 30
					v_u_4:Create(v18, TweenInfo.new(3, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
						["Value"] = 0
					}):Play()
					repeat
						p15.Velocity = v16.CFrame.LookVector * v18.Value
						v_u_2.Stepped:Wait()
					until not (p15.Parent and v16.Parent)
				end
			end
		end,
		["Swing"] = function(p19, p20)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8
			local v_u_21 = p19:FindFirstChild("HumanoidRootPart")
			if v_u_21 then
				local function v24(p22) -- name: swingFX
					-- upvalues: (ref) v_u_7, (copy) v_u_21, (ref) v_u_3, (ref) v_u_4
					local v23 = v_u_7.Todo.Swing:Clone()
					v23.Weld.C0 = v23.Weld.C0 * CFrame.Angles(0, 0, 0.17453292519943295) * p22
					v23.Weld.Part0 = v_u_21
					v23.Parent = workspace.Effects
					v_u_3:AddItem(v23, 0.6)
					v23.Core.Wind:Emit(12)
					v_u_4:Create(v23.Weld, TweenInfo.new(0.4), {
						["C1"] = v23.Weld.C1 * CFrame.Angles(0, -3.141592653589793, 0)
					}):Play()
					v_u_4:Create(v23.Beam, TweenInfo.new(0.4), {
						["Width0"] = 0
					}):Play()
				end
				local function v26() -- name: jabFX
					-- upvalues: (ref) v_u_7, (copy) v_u_21, (ref) v_u_3, (ref) v_u_4
					local v25 = v_u_7.Charles.StabWind:Clone()
					v25:PivotTo(v_u_21.CFrame * CFrame.new(0, 0, -4))
					v25.Parent = workspace.Effects
					v_u_3:AddItem(v25, 0.3)
					v_u_4:Create(v25.Shock, TweenInfo.new(0.15), {
						["Size"] = Vector3.new(0, 25, 0),
						["Transparency"] = 1
					}):Play()
					v_u_4:Create(v25.Shock2, TweenInfo.new(0.1), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1,
						["Position"] = nil,
						["Position"] = v25.Shock2.Position + v_u_21.CFrame.LookVector * 3
					}):Play()
				end
				v_u_12:PlaySound(v_u_8.Misc.Swing.Fist3, v_u_21, game.SoundService.Effect)
				if p20 == 1 then
					v_u_12:ArmFlash(p19["Right Leg"], Color3.fromRGB(170, 0, 0), 0.4)
					v24(CFrame.Angles(0, 0, -2.9670597283903604))
					return
				elseif p20 == 2 then
					v26()
					return
				elseif p20 == 3 then
					v_u_12:ArmFlash(p19["Right Arm"], Color3.fromRGB(170, 0, 0), 0.5)
					v24(CFrame.Angles(0, 0, -4.1887902047863905))
					return
				elseif p20 == 4 then
					v_u_12:ArmFlash(p19["Left Arm"], Color3.fromRGB(170, 0, 0), 0.2)
					v24(CFrame.Angles(0, 0, -5.061454830783556))
					return
				elseif p20 == 5 then
					v_u_12:ArmFlash(p19["Right Arm"], Color3.fromRGB(170, 0, 0), 0.2)
					v26()
					return
				elseif p20 == 6 then
					v_u_12:ArmFlash(p19["Left Arm"], Color3.fromRGB(170, 0, 0), 0.4)
					v24(CFrame.Angles(0, 0, -4.537856055185257))
				elseif p20 == 7 then
					v_u_12:ArmFlash(p19["Left Leg"], Color3.fromRGB(170, 0, 0), 0.8)
					v24(CFrame.Angles(0, 0, -3.141592653589793))
				end
			else
				return
			end
		end,
		["Swing2"] = function(p27, _)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v28 = p27:FindFirstChild("HumanoidRootPart")
			if v28 then
				v_u_12:PlaySound(v_u_8.Misc.Swing.Fist3, v28, game.SoundService.Effect)
			end
		end,
		["Hit"] = function(p29, p30, _)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v31 = p30:FindFirstChild("HumanoidRootPart")
			if v31 then
				v_u_12:Flash(p30, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Hakari.OverLuck.Hit1, v31, game.SoundService.Effect)
				local v32 = v_u_7.Gojo.Twofold.Sparks:Clone()
				v32.Parent = v31.RootAttachment
				v32:Emit(20)
				v_u_3:AddItem(v32, 0.4)
				if v_u_5 == p29 or v_u_5.Character == p30 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["FinalHit"] = function(p33, p34)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9
			local v35 = p34:FindFirstChild("HumanoidRootPart")
			if v35 then
				v_u_12:Flash(p34, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Hakari.OverLuck.Hit2, v35, game.SoundService.Effect)
				local v36 = v_u_7.Hakari.RoughHit:Clone()
				v36.Glow.Color = ColorSequence.new(Color3.fromRGB(150, 0, 0))
				v36.Sparks.Color = ColorSequence.new(Color3.fromRGB(150, 0, 0))
				v36.Wind.Color = ColorSequence.new(Color3.fromRGB(150, 0, 0))
				v36.Wind2.Color = ColorSequence.new(Color3.fromRGB(150, 0, 0))
				v36.PointLight.Color = Color3.fromRGB(150, 0, 0)
				v36.Position = v35.Position
				v36.Parent = workspace.Effects
				v_u_3:AddItem(v36, 1)
				v_u_4:Create(v36.PointLight, TweenInfo.new(0.6), {
					["Brightness"] = 0
				}):Play()
				v36.Glow:Emit(1)
				v36.Sparks:Emit(50)
				v36.Wind:Emit(7)
				v36.Wind2:Emit(7)
				if v_u_5 == p33 or v_u_5.Character == p34 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Hit2"] = function(p37, p38)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v39 = p38:FindFirstChild("HumanoidRootPart")
			if v39 then
				v_u_12:Flash(p38, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Hakari.OverLuck.Hit2, v39, game.SoundService.Effect)
				if v_u_5 == p37 or v_u_5.Character == p38 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end,
		["Crush"] = function(p40)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9
			local v41 = v_u_7.Megumi.Mahoraga.Earthquake:Clone()
			v41.Position = p40
			v41.Parent = workspace.Effects
			v41.Air:Destroy()
			v_u_4:Create(v41.PointLight, TweenInfo.new(0.6), {
				["Brightness"] = 0
			}):Play()
			v_u_4:Create(v41.Floor.Ring2, TweenInfo.new(0.4), {
				["TimeScale"] = 0.5
			}):Play()
			v41.Floor.Ring2:Emit(10)
			v41.Floor.Wind2:Emit(15)
			v41.Floor.Dust:Emit(100)
			v_u_3:AddItem(v41, 3)
			local v42 = v_u_7.Megumi.Mahoraga.WorldSlash.mesh:Clone()
			v42.Position = p40
			v42.Decal.Transparency = 0
			v42.Mesh.Scale = Vector3.new(2, 50, 2)
			v42.Parent = v41
			v_u_4:Create(v42, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Size"] = Vector3.new(80, 40, 80),
				["CFrame"] = nil,
				["CFrame"] = v42.CFrame * CFrame.Angles(0, -3.12413936106985, 0)
			}):Play()
			v_u_4:Create(v42.Mesh, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Scale"] = Vector3.new(40, 10, 40)
			}):Play()
			v_u_4:Create(v42.Decal, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Transparency"] = 1
			}):Play()
			v_u_3:AddItem(v42, 1)
			v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v41, game.SoundService.Effect)
			v_u_12:PlaySound(v_u_8.Mahito.WideSPStrike.Crush, v41, game.SoundService.Effect)
			v_u_12:PlaySound(v_u_8.Mahito.WideSPStrike.Crush2, v41, game.SoundService.Effect)
			v_u_12:DustBreak(p40 + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 12, 35, 0.4, 1)
			if (workspace.CurrentCamera.CFrame.Position - p40).Magnitude < 180 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
			end
		end,
		["Interp"] = function(p_u_43, p_u_44)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_2, (ref) v_u_4
			local v_u_45 = p_u_43.CFrame
			local v_u_46 = tick()
			local v_u_47 = p_u_43:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_45, (copy) p_u_43, (ref) v_u_46
				v_u_45 = p_u_43.CFrame
				v_u_46 = tick()
			end)
			v_u_12:PlaySound(v_u_8.Mahito.CrushingRushdown.HairPull, p_u_43, game.SoundService.Effect)
			local v_u_48 = nil
			v_u_48 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_43, (ref) v_u_48, (copy) v_u_47, (copy) p_u_44, (ref) v_u_45, (ref) v_u_46
				if p_u_43.Position then
					workspace:BulkMoveTo({ p_u_43 }, { v_u_45 + v_u_45.LookVector * (200 * (tick() - v_u_46)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_48:Disconnect()
					v_u_47:Disconnect()
					p_u_44.Sparks.Enabled = false
				end
			end)
			local v49 = TweenInfo.new(1, Enum.EasingStyle.Elastic)
			p_u_43.End.Sparks.Parent = p_u_44
			p_u_43.Beam.CurveSize1 = 20
			v_u_4:Create(p_u_43.Beam, v49, {
				["CurveSize1"] = 0
			}):Play()
			v_u_4:Create(p_u_43.Beam, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Width0"] = 0.4,
				["Width1"] = 0.4
			}):Play()
		end,
		["Retract"] = function(p50, p51)
			-- upvalues: (ref) v_u_4, (ref) v_u_3
			local v52 = p51:Clone()
			v52.Parent = workspace.Effects
			v_u_4:Create(v52.Beam, TweenInfo.new(0.6), {
				["Width0"] = 3,
				["Width1"] = 0.4
			}):Play()
			v_u_3:AddItem(v52, 0.6)
			local v53 = tick()
			local _ = v52.CFrame
			repeat
				local _ = p50["Right Arm"].CFrame * CFrame.new(0, 0, 1) * CFrame.Angles(1.5707963267948966, 0, 0)
				v52.CFrame = v52.CFrame:Lerp(p50["Left Arm"].CFrame, (tick() - v53) / 0.6)
				task.wait()
			until tick() > v53 + 0.6 or not p50.Parent
		end,
		["GrabArm"] = function(p54, p55, p56)
			-- upvalues: (ref) v_u_4, (ref) v_u_3
			local v57 = p56:Clone()
			v57.Anchored = false
			v57.Parent = workspace.Effects
			v_u_4:Create(v57.Beam, TweenInfo.new(0.4), {
				["Width0"] = 1,
				["Width1"] = 0.3
			}):Play()
			v_u_4:Create(v57.Beam, TweenInfo.new(0.2), {
				["CurveSize0"] = 0,
				["CurveSize1"] = 0
			}):Play()
			v_u_3:AddItem(v57, 1.2)
			local v58 = Instance.new("Weld", v57)
			v58.Part1 = v57
			v58.Part0 = p55.Torso
			v58.C1 = CFrame.new(0, -1, 1) * CFrame.Angles(-0.17453292519943295, 0, 0)
			task.wait(0.8)
			v58.Enabled = false
			v57.Anchored = true
			v_u_4:Create(v57.Beam, TweenInfo.new(0.3), {
				["Width0"] = 0.6,
				["Width1"] = 0.6
			}):Play()
			local v59 = tick()
			local _ = v57.CFrame
			repeat
				local _ = p54["Right Arm"].CFrame * CFrame.new(0, 0, 1) * CFrame.Angles(1.5707963267948966, 0, 0)
				v57.CFrame = v57.CFrame:Lerp(p54["Left Arm"].CFrame, (tick() - v59) / 0.4)
				task.wait()
			until tick() > v59 + 0.4 or not p54.Parent
		end
	}
	v_u_10.Effects:Connect(function(p61, ...)
		-- upvalues: (copy) v_u_60
		local v62 = v_u_60[p61]
		if v62 then
			v62(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("WingKingService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13