-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Character.JoinController.SettingsController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
game:GetService("AvatarEditorService")
local v_u_5 = game:GetService("HttpService")
local v_u_6 = game.Players.LocalPlayer
local v_u_7 = game.ReplicatedStorage
local _ = v_u_7.Animations
local v_u_8 = v_u_7.Utils
local v_u_9 = v_u_7.Sounds
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
require(v_u_7.Modules.Icon)
require(v_u_7.Modules.BloodyZee)
_G.Settings = {}
_G.LocalSettings = {}
_G.SettingUpdate = {}
local v14 = v_u_1.CreateController({
	["Name"] = "SettingsController"
})
function v14.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_6, (ref) v_u_10, (ref) v_u_13, (copy) v_u_9, (copy) v_u_2, (copy) v_u_7, (ref) v_u_11, (copy) v_u_8, (copy) v_u_4, (copy) v_u_3, (copy) v_u_5
	local v_u_15 = v_u_6.PlayerGui:WaitForChild("Menus")
	local v_u_16 = v_u_15.Group.Settings
	v_u_16:SetAttribute("Loaded", true)
	v_u_6:WaitForChild("leaderstats")
	local v_u_17 = v_u_6:WaitForChild("Gamepasses")
	local v_u_18 = v_u_6:GetMouse()
	local function v27(p_u_19, p20) -- name: createSetting
		-- upvalues: (copy) v_u_15, (ref) v_u_10, (ref) v_u_13, (ref) v_u_9
		local v_u_21 = require(p_u_19)
		local v_u_22 = v_u_15.Preset.Option:Clone()
		v_u_22.Option.Text = p_u_19.Name
		v_u_22.Name = p_u_19.Name
		v_u_22.Description.Text = v_u_21.Desc
		v_u_22.Parent = p20
		v_u_22.LayoutOrder = v_u_21.SortOrder
		local v_u_23 = _G.Settings
		if v_u_21.Val == nil then
			v_u_23 = _G.LocalSettings
			if not v_u_23[p_u_19.Name] then
				v_u_23[p_u_19.Name] = false
			end
		end
		local v_u_24 = Instance.new("BindableEvent")
		_G.SettingUpdate[v_u_21.Val or p_u_19.Name] = v_u_24
		v_u_24.Event:Connect(function()
			-- upvalues: (ref) v_u_23, (copy) v_u_21, (copy) p_u_19, (copy) v_u_22
			local v25 = v_u_23[v_u_21.Val or p_u_19.Name]
			if v25 == true then
				v_u_22.Toggle.BackgroundColor3 = Color3.fromRGB(85, 255, 0)
				v_u_22.Toggle.Side.BackgroundColor3 = Color3.fromRGB(169, 255, 189)
				v_u_22.Toggle.Side.Position = UDim2.new(0, 0, 0, 0)
			elseif v25 == false then
				v_u_22.Toggle.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
				v_u_22.Toggle.Side.BackgroundColor3 = Color3.fromRGB(85, 0, 0)
				v_u_22.Toggle.Side.Position = UDim2.new(0.5, 0, 0, 0)
			end
			if v_u_21.Callback then
				v_u_21.Callback(v25)
			end
		end)
		v_u_22.Toggle.Side.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_23, (copy) v_u_21, (copy) p_u_19, (copy) v_u_24, (ref) v_u_10, (ref) v_u_13, (ref) v_u_9
			local v26 = v_u_23[v_u_21.Val or p_u_19.Name]
			if v_u_21.Val == nil then
				_G.LocalSettings[p_u_19.Name] = not v26
				v_u_24:Fire()
			else
				v_u_10.Setting:Fire(v_u_21.Val, not v26)
			end
			v_u_13:PlaySound(v_u_9.Misc.UI.Click, workspace, game.SoundService.Effect)
			v_u_13:PlaySound(v_u_9.Misc.UI.Switch, workspace, game.SoundService.Effect)
		end)
		if v_u_21.Val == nil then
			v_u_24:Fire()
		end
		return v_u_22
	end
	local function v36(p28, p29) -- name: createIdSetting
		-- upvalues: (copy) v_u_15, (ref) v_u_10, (ref) v_u_13, (ref) v_u_9, (copy) v_u_17
		local v_u_30 = require(p28)
		local v_u_31 = v_u_15.Preset.OptionString:Clone()
		v_u_31.Option.Text = p28.Name
		v_u_31.Name = p28.Name
		v_u_31.Description.Text = v_u_30.Desc
		v_u_31.Parent = p29
		v_u_31.LayoutOrder = v_u_30.SortOrder
		local v32 = Instance.new("BindableEvent")
		_G.SettingUpdate[v_u_30.Val] = v32
		v32.Event:Connect(function()
			-- upvalues: (copy) v_u_30, (copy) v_u_31
			local v33 = _G.Settings[v_u_30.Val]
			v_u_31.TextBox.Text = v33 or ""
		end)
		v_u_31.TextBox.FocusLost:Connect(function()
			-- upvalues: (copy) v_u_31, (ref) v_u_10, (copy) v_u_30, (ref) v_u_13, (ref) v_u_9
			local v34 = v_u_31.TextBox.Text
			if tonumber(v34) or v34 == "" then
				if tonumber(v34) then
					v34 = tonumber(v34)
				end
				v_u_10.Setting:Fire(v_u_30.Val, v34)
				v_u_13:PlaySound(v_u_9.Misc.UI.Click, workspace, game.SoundService.Effect)
			else
				v_u_31.TextBox.Text = "Invalid ID"
			end
		end)
		if v_u_30.Gamepass then
			v_u_31.Visible = v_u_17:GetAttribute(v_u_30.Gamepass)
			if v_u_31.Visible == false then
				local v_u_35 = nil
				v_u_35 = v_u_17:GetAttributeChangedSignal(v_u_30.Gamepass):Connect(function()
					-- upvalues: (ref) v_u_17, (copy) v_u_30, (ref) v_u_35, (copy) v_u_31
					if v_u_17:GetAttribute(v_u_30.Gamepass) == true then
						v_u_35:Disconnect()
						v_u_31.Visible = true
					end
				end)
			end
		end
	end
	local function v65(p37, p38) -- name: createVolSetting
		-- upvalues: (copy) v_u_15, (ref) v_u_10, (ref) v_u_13, (ref) v_u_9, (ref) v_u_2, (copy) v_u_18
		local v_u_39 = require(p37)
		local v_u_40 = v_u_15.Preset.OptionValue:Clone()
		v_u_40.Option.Text = p37.Name
		v_u_40.Name = p37.Name
		v_u_40.Description.Text = v_u_39.Desc
		v_u_40.TextBox.PlaceholderText = v_u_39.Max or 2
		v_u_40.Parent = p38
		v_u_40.LayoutOrder = v_u_39.SortOrder
		local v41 = Instance.new("BindableEvent")
		_G.SettingUpdate[v_u_39.Val] = v41
		v41.Event:Connect(function()
			-- upvalues: (copy) v_u_39, (copy) v_u_40
			local v42 = _G.Settings[v_u_39.Val] or 1
			v_u_40.TextBox.Text = v42
			if v_u_39.Callback then
				v_u_39.Callback(v42)
			end
			v_u_40.Bar.BarClip.Size = UDim2.new(v42 / v_u_39.Max, 0, 1, 0)
			v_u_40.Bar.BarClip.Bar.Size = UDim2.new(v42 > 0 and 1 / (v42 / v_u_39.Max) or 0, 0, 1, 0)
		end)
		v_u_40.TextBox.FocusLost:Connect(function()
			-- upvalues: (copy) v_u_40, (copy) v_u_39, (ref) v_u_10, (ref) v_u_13, (ref) v_u_9
			local v43 = v_u_40.TextBox.Text
			local v44 = tonumber(v43)
			local v45
			if v44 and not math.isnan(v44) then
				local v46 = v_u_39.Max
				v45 = math.clamp(v44, 0, v46) or 1
			else
				v45 = 1
			end
			v_u_10.Setting:Fire(v_u_39.Val, (tonumber(v45)))
			v_u_13:PlaySound(v_u_9.Misc.UI.Click, workspace, game.SoundService.Effect)
		end)
		v_u_40.Bar.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_2, (copy) v_u_40, (ref) v_u_18, (copy) v_u_39, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			local v_u_55 = v_u_2.Stepped:Connect(function()
				-- upvalues: (ref) v_u_40, (ref) v_u_18, (ref) v_u_39
				local v47 = v_u_40.Bar.AbsolutePosition
				local v48 = v_u_40.Bar.AbsoluteSize
				local v49 = v47.X
				local v50 = v47.X + v48.X
				local v51 = (v_u_18.X - v49) / (v50 - v49)
				local v52 = math.clamp(v51, 0, 1) * v_u_39.Max * 10
				local v53 = math.floor(v52) / 10
				v_u_40.TextBox.Text = v53
				local v54 = v_u_39.Max
				v_u_40.Bar.BarClip.Size = UDim2.new(v53 / v54, 0, 1, 0)
				v_u_40.Bar.BarClip.Bar.Size = UDim2.new(v53 > 0 and (1 / (v53 / v54) or 0) or 0, 0, 1, 0)
				if v_u_39.Callback then
					v_u_39.Callback(v53)
				end
			end)
			local v_u_56 = nil
			v_u_56 = v_u_40.Bar.InputEnded:Connect(function()
				-- upvalues: (ref) v_u_56, (ref) v_u_55, (ref) v_u_13, (ref) v_u_9, (ref) v_u_40, (ref) v_u_18, (ref) v_u_39, (ref) v_u_10
				v_u_56:Disconnect()
				v_u_55:Disconnect()
				v_u_13:PlaySound(v_u_9.Misc.UI.Click, workspace, game.SoundService.Effect)
				local v57 = v_u_40.Bar.AbsolutePosition
				local v58 = v_u_40.Bar.AbsoluteSize
				local v59 = v57.X
				local v60 = v57.X + v58.X
				local v61 = (v_u_18.X - v59) / (v60 - v59)
				local v62 = math.clamp(v61, 0, 1) * v_u_39.Max * 10
				local v63 = math.floor(v62) / 10
				v_u_40.TextBox.Text = v63
				local v64 = v_u_39.Max
				v_u_40.Bar.BarClip.Size = UDim2.new(v63 / v64, 0, 1, 0)
				v_u_40.Bar.BarClip.Bar.Size = UDim2.new(v63 > 0 and (1 / (v63 / v64) or 0) or 0, 0, 1, 0)
				v_u_10.Setting:Fire(v_u_39.Val, v63)
			end)
		end)
	end
	local function v71(p66, p67) -- name: createButtonSetting
		-- upvalues: (copy) v_u_15, (ref) v_u_13, (ref) v_u_9, (copy) v_u_17
		local v_u_68 = require(p66)
		local v_u_69 = v_u_15.Preset.OptionButton:Clone()
		v_u_69.Option.Text = p66.Name
		v_u_69.Name = p66.Name
		v_u_69.TextButton.Text = v_u_68.BtnText or p66.Name
		v_u_69.Description.Text = v_u_68.Desc
		v_u_69.Parent = p67
		v_u_69.LayoutOrder = v_u_68.SortOrder
		v_u_69.TextButton.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (copy) v_u_68
			v_u_13:PlaySound(v_u_9.Misc.UI.Click, workspace, game.SoundService.Effect)
			if v_u_68.Callback then
				v_u_68.Callback()
			end
		end)
		if v_u_68.Gamepass then
			v_u_69.Visible = v_u_17:GetAttribute(v_u_68.Gamepass)
			if v_u_69.Visible == false then
				local v_u_70 = nil
				v_u_70 = v_u_17:GetAttributeChangedSignal(v_u_68.Gamepass):Connect(function()
					-- upvalues: (ref) v_u_17, (copy) v_u_68, (ref) v_u_70, (copy) v_u_69
					if v_u_17:GetAttribute(v_u_68.Gamepass) == true then
						v_u_70:Disconnect()
						v_u_69.Visible = true
					end
				end)
			end
		end
	end
	for _, v_u_72 in v_u_16.Settings.Categories:GetChildren() do
		if not v_u_72:IsA("TextButton") then
			continue
		end
		v_u_72.MouseButton1Down:Connect(function()
			-- upvalues: (copy) v_u_16, (copy) v_u_72, (ref) v_u_13, (ref) v_u_9
			for _, v73 in v_u_16.Settings.Categories:GetChildren() do
				if not v73:IsA("TextButton") then
					continue
				end
				v73.Select.Visible = v73 == v_u_72
			end
			v_u_13:PlaySound(v_u_9.Misc.UI.Click, workspace, game.SoundService.Effect)
			for _, v74 in v_u_16.Settings.Items:GetChildren() do
				v74.Visible = v74.Name == v_u_72.Name
			end
		end)
	end
	for _, v75 in v_u_7.Modules.Settings:GetChildren() do
		local v76 = v_u_16.Settings.Items:FindFirstChild(v75.Name)
		for _, v77 in v75:GetChildren() do
			local v78 = require(v77)
			if v78.Btn == 1 then
				v27(v77, v76)
			elseif v78.Btn == 2 then
				v36(v77, v76)
			elseif v78.Btn == 3 then
				v65(v77, v76)
			else
				if v78.Btn ~= 4 then
					continue
				end
				v71(v77, v76)
			end
		end
	end
	v_u_7.Remotes.ForceFun.OnClientEvent:Connect(function(p79, _)
		_G.LocalSettings[p79] = true
		_G.SettingUpdate[p79]:Fire()
	end)
	local v_u_80 = false
	local v_u_81 = nil
	v_u_2.RenderStepped:Connect(function()
		-- upvalues: (ref) v_u_80, (ref) v_u_11, (ref) v_u_81, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3
		local v82 = workspace.CurrentCamera.CFrame.Y
		if v_u_80 == false then
			if v82 > 15000 then
				v_u_80 = true
				v_u_11.Give:Fire("Space Shenanigans")
				v_u_81 = v_u_8.Misc.Space:Clone()
				v_u_81.Position = workspace.CurrentCamera.CFrame.Position
				v_u_81.Parent = workspace.Effects
				v_u_4:Create(v_u_81, TweenInfo.new(1), {
					["Transparency"] = 0
				}):Play()
				v_u_4:Create(v_u_81.Earth, TweenInfo.new(1), {
					["Transparency"] = 0
				}):Play()
				v_u_4:Create(v_u_81.Earth.Atmo, TweenInfo.new(1), {
					["Transparency"] = 0
				}):Play()
			end
		elseif v_u_80 == true and v82 < 15000 then
			v_u_80 = false
			v_u_4:Create(v_u_81, TweenInfo.new(1), {
				["Transparency"] = 1
			}):Play()
			v_u_4:Create(v_u_81.Earth, TweenInfo.new(1), {
				["Transparency"] = 1
			}):Play()
			v_u_4:Create(v_u_81.Earth.Atmo, TweenInfo.new(1), {
				["Transparency"] = 1
			}):Play()
			v_u_3:AddItem(v_u_81, 1)
			v_u_81 = nil
		end
		if v_u_81 then
			local v83 = (v82 - 15000) / 20000
			v_u_81.Position = workspace.CurrentCamera.CFrame.Position
			local v84 = v_u_81.Earth
			local v85 = v_u_81.Position
			local v86 = v83 * 150
			local v87 = math.clamp(v86, 0, 150) + 250
			v84.Position = v85 - Vector3.new(0, v87, 0)
		end
	end)
	v_u_11.Give:Connect(function()
		-- upvalues: (ref) v_u_11
		if _G.LocalSettings.Gravity and _G.LocalSettings.Invert then
			v_u_11.Give:Fire("Betavision", true)
		end
	end)
	v_u_10.Setting:Connect(function(p88, ...)
		-- upvalues: (ref) v_u_5, (ref) v_u_7
		local v89 = nil
		local v90
		if p88 == "Batch" then
			local v91 = ({ ... })[1]
			local v92 = game:GetService("EncodingService"):DecompressBuffer(v91, Enum.CompressionAlgorithm.Zstd)
			v90 = v_u_5:JSONDecode(buffer.tostring(v92))
		else
			v90 = p88 == "Single" and {
				[({ ... })[1]] = ({ ... })[2]
			} or v89
		end
		for v93, v94 in v90 do
			_G.Settings[v93] = v94
			if not _G.SettingUpdate[v93] then
				continue
			end
			_G.SettingUpdate[v93]:Fire()
		end
		if v90.Keybinds then
			local v95 = {
				["K"] = "Keyboard",
				["G"] = "Gamepad"
			}
			for v96, v97 in v90.Keybinds do
				local v98 = v_u_7.Keybind:FindFirstChild(v96, true)
				if not v98 then
					continue
				end
				for v99, v100 in v97 do
					if not v98:FindFirstChild(v95[v99]) then
						continue
					end
					v98[v95[v99]].KeyCode = Enum.KeyCode[v100[1]]
					if not v100[2] then
						continue
					end
					v98[v95[v99]].PrimaryModifier = Enum.KeyCode[v100[2]]
				end
			end
		end
	end)
end
function v14.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13
	v_u_10 = v_u_1.GetService("JoinService")
	v_u_11 = v_u_1.GetService("AchievementService")
	v_u_12 = v_u_1.GetController("ToolController")
	v_u_13 = v_u_1.GetController("FXController")
end
return v14