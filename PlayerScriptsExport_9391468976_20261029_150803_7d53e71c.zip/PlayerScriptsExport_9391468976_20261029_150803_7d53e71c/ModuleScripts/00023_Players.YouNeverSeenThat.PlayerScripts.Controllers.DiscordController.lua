-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.DiscordController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local _ = game.ReplicatedStorage
require(script.DiscordClient)
local v2 = v1.CreateController({
	["Name"] = "DiscordController"
})
function v2.KnitStart(_) -- name: KnitStart end
function v2.KnitInit(_) -- name: KnitInit end
return v2