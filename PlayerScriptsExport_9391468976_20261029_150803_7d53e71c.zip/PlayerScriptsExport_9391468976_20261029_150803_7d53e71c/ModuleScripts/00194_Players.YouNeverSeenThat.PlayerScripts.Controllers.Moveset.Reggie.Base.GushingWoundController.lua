-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Reggie.Base.GushingWoundController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "GushingWoundController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_6, (copy) v_u_3, (ref) v_u_12, (copy) v_u_9, (copy) v_u_7, (copy) v_u_4, (copy) v_u_8, (copy) v_u_2, (ref) v_u_10
	local v_u_32 = {
		["Start"] = function(p14, p15, _)
			-- upvalues: (ref) v_u_6, (ref) v_u_3
			if p14:FindFirstChild("HumanoidRootPart") then
				for _, v16 in p15:GetChildren() do
					if v16.Name == "Root" or not v16:IsA("BasePart") then
						continue
					end
					local v_u_17 = v_u_6.Reggie.ReceiptBurn:Clone()
					v_u_17.Parent = workspace.Effects
					v_u_17.Weld.Part0 = v16
					v_u_3:AddItem(v_u_17, 5)
					v16.Destroying:Connect(function()
						-- upvalues: (copy) v_u_17
						v_u_17.Anchored = true
						for _, v18 in v_u_17.BurningPart:GetChildren() do
							v18.Enabled = false
						end
					end)
				end
			end
		end,
		["Hit"] = function(p19, p20, p21)
			-- upvalues: (ref) v_u_12, (ref) v_u_9, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v22 = p19:FindFirstChild("HumanoidRootPart")
			if v22 then
				local v23 = p20:FindFirstChild("HumanoidRootPart")
				if v23 then
					v_u_12:Flash(p20, Color3.new(1, 1, 1))
					for _ = 1, 5 do
						v_u_9:Blood(CFrame.lookAt(v23.Position, v22.Position), math.random(5, 20), 25, 25)
					end
					v_u_12:PlaySound(v_u_7.Reggie.KnifeHit, v23, game.SoundService.Effect).Volume = p21 and 0.3333333333333333 or 1
					if v_u_4.Character == p19 or v_u_4.Character == p20 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
					end
				end
			else
				return
			end
		end,
		["Interp"] = function(p_u_24, p25)
			-- upvalues: (ref) v_u_6, (ref) v_u_12, (ref) v_u_3, (ref) v_u_7, (ref) v_u_2
			local v26 = v_u_6.Reggie.ReceiptBurn:Clone()
			v26.Parent = workspace.Effects
			v26.Anchored = true
			v26.CFrame = p_u_24.CFrame * CFrame.new(-3, 0, 0)
			v_u_12:PlayParticles(v26)
			v_u_3:AddItem(v26, 3)
			local v27 = v_u_12:PlaySound(v_u_7.Reggie.CouponBurn, p_u_24, game.SoundService.Effect)
			v27:Stop()
			v27.PlayOnRemove = true
			v27.Volume = p25 and 0.3333333333333333 or 1
			v27:Destroy()
			v_u_12:PlaySound(v_u_7.Reggie.KnifeThrow, p_u_24, game.SoundService.Effect).Volume = p25 and 0.3333333333333333 or 1
			local v_u_28 = p_u_24.CFrame
			local v_u_29 = tick()
			local v_u_30 = p_u_24:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_28, (copy) p_u_24, (ref) v_u_29
				v_u_28 = p_u_24.CFrame
				v_u_29 = tick()
			end)
			local v_u_31 = nil
			v_u_31 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_24, (ref) v_u_31, (copy) v_u_30, (ref) v_u_28, (ref) v_u_29
				if p_u_24.Parent and p_u_24:GetAttribute("Speed") ~= nil then
					workspace:BulkMoveTo({ p_u_24 }, { v_u_28 + -v_u_28.RightVector * (p_u_24:GetAttribute("Speed") * (tick() - v_u_29)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_31:Disconnect()
					v_u_30:Disconnect()
				end
			end)
		end
	}
	v_u_10.Effects:Connect(function(p33, ...)
		-- upvalues: (copy) v_u_32
		local v34 = v_u_32[p33]
		if v34 then
			v34(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("GushingWoundService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13