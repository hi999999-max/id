-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.RankedController.NightParadeController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
game:GetService("TweenService")
local v2 = game.Players.LocalPlayer
local v3 = game.ReplicatedStorage
require(v3.Modules.Icon)
local _ = v3.Animations
local _ = v3.Utils
local _ = v3.Sounds
require(v3.Modules.CameraShaker)
require(v2.PlayerScripts.PlayerModule)
require(v3.Modules.MVP)
local v_u_4 = nil
local v_u_5 = nil
local v6 = v_u_1.CreateController({
	["Name"] = "NightParadeController"
})
function v6.Start(_) -- name: Start
	-- upvalues: (ref) v_u_4
	local v_u_7 = {
		["PickVows"] = function() end
	}
	v_u_4.Effects:Connect(function(p8, ...)
		-- upvalues: (copy) v_u_7
		local v9 = v_u_7[p8]
		if v9 then
			v9(...)
		end
	end)
end
function v6.KnitStart(_) -- name: KnitStart end
function v6.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_4, (copy) v_u_1, (ref) v_u_5
	v_u_4 = v_u_1.GetService("NightParadeService")
	v_u_5 = v_u_1.GetController("FXController")
end
return v6