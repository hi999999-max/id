-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Haruta.HarutaController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local v_u_7 = v_u_6.Animations
local v_u_8 = v_u_6.Utils
local v_u_9 = v_u_6.Sounds
local v_u_10 = require(v_u_6.Modules.CameraShaker)
local v_u_11 = require(v_u_6.Modules.BloodyZee)
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v15 = v_u_1.CreateController({
	["Name"] = "HarutaController"
})
function v15.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_14, (copy) v_u_9, (copy) v_u_8, (copy) v_u_3, (copy) v_u_5, (copy) v_u_10, (copy) v_u_4, (copy) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (ref) v_u_12
	local v_u_125 = {
		["Hit"] = function(p16, p17, p18, p19)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3
			local v20 = p16:FindFirstChild("HumanoidRootPart")
			if v20 then
				local v21 = p17:FindFirstChild("HumanoidRootPart")
				if v21 then
					v_u_14:Flash(p17, Color3.new(1, 1, 1))
					if p16.SetAssets:FindFirstChild("HarutaSword") then
						local v22 = p19 == "Up" and 1 or p18
						v_u_14:PlaySound(v_u_9.Haruta.M1:FindFirstChild("Hit" .. v22), v21, game.SoundService.Effect)
						if p19 ~= "Down" then
							local v23 = v_u_8.Yuta.SlashHit:Clone()
							v23.CFrame = CFrame.lookAlong(v21.Position, v20.CFrame.LookVector)
							local v24 = {
								[2] = CFrame.Angles(0, 0, 0.2617993877991494),
								[3] = CFrame.Angles(0, 0, 0.4363323129985824)
							}
							if v24[p18] then
								v23.CFrame = v23.CFrame * v24[p18]
							elseif p19 == "Up" then
								v23.CFrame = v23.CFrame * CFrame.Angles(0, 0, -1.3089969389957472)
							end
							v23.Parent = workspace.Effects
							v_u_3:AddItem(v23, 0.5)
							v23.Slash:Emit(5)
						end
					else
						v_u_14:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit" .. p18), v20, game.SoundService.Effect)
						return
					end
				else
					return
				end
			else
				return
			end
		end,
		["ChaseHit"] = function(p25, p26, p27)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3
			local v28 = p25:FindFirstChild("HumanoidRootPart")
			if v28 then
				local v29 = p26:FindFirstChild("HumanoidRootPart")
				if v29 then
					if p25.SetAssets:FindFirstChild("HarutaSword") and not p27 then
						v_u_14:Flash(p26, Color3.new(1, 1, 1))
						v_u_14:PlaySound(v_u_9.Haruta.M1:FindFirstChild("Hit" .. math.random(1, 3)), v29, game.SoundService.Effect)
					else
						v_u_14:Flash(p26, Color3.new(1, 1, 1))
						v_u_14:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit3"), v29, game.SoundService.Effect)
					end
					local v30 = v_u_8.ChaseHit:Clone()
					local v31 = CFrame.new
					local v32 = v29.Position
					local v33 = v28.Position.X
					local v34 = v29.Position.Y
					local v35 = v28.Position.Z
					v30.CFrame = v31(v32, (Vector3.new(v33, v34, v35))) * CFrame.Angles(0, 3.141592653589793, 0)
					v30.Parent = workspace.Effects
					v_u_3:AddItem(v30, 0.5)
					v30.Ring:Emit(7)
					v30.Sparks:Emit(12)
				end
			else
				return
			end
		end,
		["AerialHit"] = function(p36, p37)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10, (ref) v_u_8, (ref) v_u_3
			local v38 = p36:FindFirstChild("HumanoidRootPart")
			if v38 then
				local v39 = p37:FindFirstChild("HumanoidRootPart")
				if v39 then
					v_u_14:Flash(p37, Color3.new(1, 1, 1))
					v_u_14:PlaySound(v_u_9.Itadori.CraniumSmash.Hit2, v39, game.SoundService.Effect)
					if v_u_5.Character == p36 or v_u_5.Character == p37 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
					end
					local v40 = CFrame.new(v38.Position, v39.Position - Vector3.new(0, 4, 0))
					local v41 = v_u_8.Gojo.HardHit:Clone()
					v41.CFrame = v40 + v40.LookVector * 4
					v41.Parent = workspace.Effects
					v41.Dust:Emit(5)
					v41.Ring:Emit(5)
					v41.Sparks:Emit(10)
					v_u_3:AddItem(v41, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p42)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_14, (ref) v_u_9
			local v43 = p42.HumanoidRootPart
			if v43 then
				local v44 = v_u_8.Gojo.LapseBlue.Throw:Clone()
				v44.CFrame = v43.CFrame * CFrame.new(0, 1, -4)
				v44.Size = Vector3.new(0, 0, 2)
				v44.Parent = workspace.Effects
				v_u_4:Create(v44, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v44, 0.3)
				v_u_14:PlaySound(v_u_9.Misc.Chase, v43, game.SoundService.Effect)
				v_u_14:DustTrail(p42, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p45, p46, p47)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			local v48 = p45:FindFirstChild("HumanoidRootPart")
			if v48 then
				if p45.SetAssets:FindFirstChild("HarutaSword") then
					local v49 = (p47 == "Up" or p47 == "Down") and 1 or (p46 or 4)
					v_u_14:PlaySound(v_u_9.Haruta.M1:FindFirstChild("Swing" .. v49), v48, game.SoundService.Effect)
				else
					v_u_14:PlaySound(v_u_9.Misc.Swing.Fist, v48, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Swing2"] = function(p50, p51, p52)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_14
			local v53 = p50.SetAssets:FindFirstChild("HarutaSword")
			if v53 then
				local v54 = v_u_8.Haruta.CombatTrail:Clone()
				v54.Weld.Part0 = v53.Blade
				v54.Parent = workspace.Effects
				task.wait(p51 == 4 and 0.425 or 0.325)
				v54.Trail.Enabled = false
				v_u_4:Create(v54, TweenInfo.new(0.1), {
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v54, 0.2)
				return
			elseif p52 == "Down" then
				v_u_14:ArmFlash(p50["Right Leg"], Color3.fromRGB(167, 125, 203), 0.4)
				return
			elseif p51 == 1 or p51 == 4 then
				v_u_14:ArmFlash(p50["Right Arm"], Color3.fromRGB(167, 125, 203), 0.3)
			else
				v_u_14:ArmFlash(p50["Left Arm"], Color3.fromRGB(167, 125, 203), 0.3)
			end
		end,
		["Launch"] = function(p55, p56)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_14, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10, (ref) v_u_11
			local v57 = p55:FindFirstChild("HumanoidRootPart")
			if v57 then
				local v58 = v_u_8.Gojo.LapseBlue.Throw:Clone()
				v58.CFrame = CFrame.new(v57.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v58.Size = Vector3.new(0, 0, 5)
				v58.Parent = workspace.Effects
				v_u_4:Create(v58, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v58.Position + Vector3.new(0, p56, 0)
				}):Play()
				v_u_3:AddItem(v58, 0.3)
				if p56 < 0 then
					v_u_14:PlaySound(v_u_9.Megumi.Mahoraga.Throw.Break, v57, game.SoundService.Effect)
					v_u_14:DustBreak(v57.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v57.Position) < 20 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
					end
					v_u_14:PlaySound(v_u_9.Choso.BloodEdge.StabHit, v57, game.SoundService.Effect).PlaybackSpeed = math.random(90, 110) / 100
					for _ = 1, 8 do
						v_u_11:Blood(CFrame.lookAt(p55.Torso.Position, p55.Torso.Position + Vector3.new(0, 10, 0)), math.random(20, 40), math.random(20, 40), math.random(20, 40))
					end
				end
			end
		end,
		["Miracles"] = function(p_u_59)
			task.spawn(function()
				-- upvalues: (copy) p_u_59
				repeat
					task.wait()
				until _G.Settings ~= nil and (_G.Settings.UIS ~= nil and p_u_59:FindFirstChild("UIScale"))
				p_u_59.UIScale.Scale = _G.Settings.UIS
			end)
		end,
		["UpdateMiracles"] = function(p60, p61)
			for v62 = 1, 6 do
				p60:FindFirstChild("Mir" .. v62, true).Fill.Visible = v62 <= p61
			end
		end,
		["Stab"] = function(p63, p64)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_11
			if p63:FindFirstChild("HumanoidRootPart") then
				local v65 = p64:FindFirstChild("HumanoidRootPart")
				if v65 then
					v_u_14:PlaySound(v_u_9.Choso.BloodEdge.StabHit, v65, game.SoundService.Effect)
					for _ = 1, 20 do
						v_u_11:Blood(p64.Torso.CFrame, math.random(5, 80), 25, 25)
					end
				end
			else
				return
			end
		end,
		["Kick"] = function(_, p66)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			local v67 = p66:FindFirstChild("HumanoidRootPart")
			if v67 then
				v_u_14:Flash(p66, Color3.new(1, 1, 1))
				v_u_14:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit4"), v67, game.SoundService.Effect)
			end
		end,
		["DodgeAttempt"] = function(p68)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_5, (ref) v_u_8, (ref) v_u_3
			local v69 = p68:FindFirstChild("HumanoidRootPart")
			if v69 then
				v_u_14:Flash(p68, Color3.fromRGB(167, 125, 203), 0.2)
				v_u_14:PlaySound(v_u_9.Itadori.ManjiKick.Startup, v69, game.SoundService.Effect)
				if v_u_5.Character == p68 then
					local v70 = v_u_8.Itadori.CounterHit.Feint:Clone()
					for _, v71 in v70:GetChildren() do
						v71.Color = ColorSequence.new(Color3.fromRGB(167, 125, 203))
					end
					v70.Parent = v69
					v70.Ring:Emit(1)
					v70.Ring.Lifetime = NumberRange.new(0.2)
					v_u_3:AddItem(v70, 0.2)
				end
			end
		end,
		["MiracleGain"] = function(p72)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			local v73 = p72:FindFirstChild("HumanoidRootPart")
			if v73 then
				v_u_14:Flash(p72, Color3.fromRGB(209, 157, 255), 0.4)
				v_u_9.Haruta.Gain.PlaybackSpeed = math.random(90, 110) / 100
				v_u_14:PlaySound(v_u_9.Haruta.Gain, v73, game.SoundService.Effect)
			end
		end,
		["MiracleUse"] = function(p74)
			-- upvalues: (ref) v_u_14, (ref) v_u_5, (ref) v_u_9, (ref) v_u_10
			local v75 = p74:FindFirstChild("HumanoidRootPart")
			if v75 then
				v_u_14:Flash(p74, Color3.fromRGB(126, 91, 154), 0.4)
				if v_u_5.Character == p74 then
					v_u_9.Haruta.Lose.PlaybackSpeed = math.random(90, 110) / 100
					v_u_14:PlaySound(v_u_9.Haruta.Lose, v75, game.SoundService.Effect)
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
				end
			end
		end,
		["Dodge"] = function(p76)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_14, (ref) v_u_9, (ref) v_u_7
			local v77 = p76:FindFirstChild("HumanoidRootPart")
			if v77 then
				local v78 = v_u_8.Damage.HitGlow:Clone()
				if p76:GetScale() ~= 1 then
					v78:ScaleTo(p76:GetScale())
				end
				v78.Parent = workspace.Effects
				v_u_3:AddItem(v78, 0.5)
				for _, v79 in v78:GetChildren() do
					local v80 = p76:FindFirstChild(v79.Name)
					if v80 then
						v79.CFrame = v80.CFrame
					end
					v79.Color = Color3.fromRGB(167, 125, 203)
					v79.Anchored = true
					v79.Transparency = 0.1
					v_u_4:Create(v79, TweenInfo.new(0.5), {
						["Transparency"] = 1
					}):Play()
				end
				v_u_14:PlaySound(v_u_9.Itadori.ManjiKick.Dodge, v77, game.SoundService.Effect)
				local v81 = {
					"Dodge1",
					"Dodge2",
					"Dodge3",
					"Dodge4",
					"Dodge5"
				}
				for _, v82 in p76.Humanoid:GetPlayingAnimationTracks() do
					if not table.find(v81, v82.Name) then
						continue
					end
					v82:Stop(0.02)
				end
				p76.Humanoid:LoadAnimation(v_u_7.Hiromi.Dodge:GetChildren()[math.random(1, 5)]):Play(0.02)
			end
		end,
		["SwordCatch"] = function(p83)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_6, (ref) v_u_3, (ref) v_u_5, (ref) v_u_10
			local v84 = p83:FindFirstChild("HumanoidRootPart")
			if v84 then
				v_u_14:PlaySound(v_u_9.Haruta.Catch, v84, game.SoundService.Effect)
				v_u_14:ArmFlash(p83["Right Arm"], Color3.fromRGB(167, 125, 203))
				local v85 = v_u_6.Utils.Haruta.SwordGrab:Clone()
				v85.Parent = p83["Right Arm"]
				v85.Ring:Emit(5)
				v85.Star:Emit(1)
				v_u_3:AddItem(v85, 0.8)
				if v_u_5.Character == p83 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
				end
			end
		end,
		["Taunt"] = function(p86, p87)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			local v88 = p86:FindFirstChild("HumanoidRootPart")
			if v88 then
				local v_u_89 = v_u_14:PlaySound(v_u_9.Haruta.Taunt, v88, game.SoundService.Effect)
				p87.AncestryChanged:Connect(function()
					-- upvalues: (copy) v_u_89
					v_u_89:Destroy()
				end)
			end
		end,
		["HandMode"] = function(p_u_90, p_u_91)
			-- upvalues: (ref) v_u_2
			if p_u_91 and p_u_90 then
				local v_u_92 = Instance.new("Highlight")
				v_u_92.Enabled = false
				v_u_92.Adornee = p_u_91.Value
				v_u_92.OutlineColor = Color3.new(1, 1, 1)
				v_u_92.FillColor = Color3.fromRGB(167, 125, 203)
				v_u_92.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
				v_u_92.Parent = p_u_91.Value
				local v_u_97 = v_u_2.RenderStepped:Connect(function()
					-- upvalues: (copy) p_u_91, (copy) p_u_90, (copy) v_u_92
					local v93 = p_u_91.Value
					if v93 and (v93.PrimaryPart and (p_u_90 and p_u_90.PrimaryPart)) then
						local v94 = v93.PrimaryPart.Position
						local v95 = p_u_90.PrimaryPart.Position
						local v96 = workspace:Raycast(v94, v95 - v94, _G.MapParams)
						if v_u_92 then
							v_u_92.Enabled = v96
						end
					end
				end)
				p_u_91.AncestryChanged:Once(function()
					-- upvalues: (copy) v_u_97, (copy) v_u_92
					v_u_97:Disconnect()
					v_u_92:Destroy()
				end)
			end
		end,
		["JawbreakerStart"] = function(p_u_98, p99, p_u_100, p_u_101)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_10, (ref) v_u_6, (ref) v_u_2
			local v_u_102 = p_u_98:FindFirstChild("HumanoidRootPart")
			if v_u_102 then
				local v_u_103 = p_u_100:FindFirstChild("HumanoidRootPart")
				if v_u_103 then
					v_u_14:Flash(p_u_98, Color3.new(1, 1, 1))
					v_u_14:PlaySound(v_u_9.Hiromi.Execution.Curb, v_u_102, game.SoundService.Effect)
					v_u_14:PlaySound(v_u_9.Hiromi.Execution.Step, v_u_102, game.SoundService.Effect)
					local v104 = v_u_8.Locust.Slam:Clone()
					v104.Position = p_u_100.Head.Position
					v104.Parent = workspace.Effects
					for _, v105 in v104.Attachment:GetChildren() do
						v105:Emit(v105:GetAttribute("EmitCount"))
					end
					v_u_3:AddItem(v104, 0.5)
					local v_u_106 = v_u_8.Mechamaru.Dust:Clone()
					v_u_106.bigimpact:Destroy()
					v_u_106.Smoke2:Destroy()
					v_u_106.Position = v_u_103.Position - Vector3.new(0, 3, 0)
					v_u_106.Parent = workspace.Effects
					v_u_3:AddItem(v_u_106, 2.5)
					for _, v107 in v_u_106:GetChildren() do
						v107:Emit(v107:GetAttribute("EmitCount"))
						v_u_4:Create(v107, TweenInfo.new(0.3), {
							["TimeScale"] = 0.1
						}):Play()
					end
					task.delay(1.7, function()
						-- upvalues: (ref) v_u_14, (ref) v_u_9, (copy) v_u_102, (copy) v_u_106
						v_u_14:PlaySound(v_u_9.Hiromi.Execution.Curb, v_u_102, game.SoundService.Effect)
						for _, v108 in v_u_106:GetChildren() do
							v108:Emit(v108:GetAttribute("EmitCount"))
							v108.TimeScale = 1
						end
					end)
					if v_u_5.Character ~= p_u_100 then
						v_u_14:PlaySound(v_u_9.Haruta.Jawbreaker, v_u_103, game.SoundService.Effect)
					end
					if v_u_5.Character == p99 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
						task.wait(1.7)
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
					elseif v_u_5.Character == p_u_100 then
						local v_u_109 = workspace.CurrentCamera
						local v_u_110 = v_u_109.CFrame
						v_u_14:PlaySound(v_u_9.Haruta.Jawbreaker, workspace, game.SoundService.Effect)
						local v_u_111 = v_u_6.Utils.Haruta.JawbreakerUI:Clone()
						v_u_111.BG.CurrentCamera = workspace.CurrentCamera
						v_u_111.Skull.CurrentCamera = workspace.CurrentCamera
						v_u_111.Parent = v_u_5.PlayerGui
						local v_u_112 = v_u_6.Utils.Damage.Skeleton.Head:Clone()
						v_u_112.Anchored = true
						v_u_112.Mesh.Scale = Vector3.new(0.8, 0.8, 0.8)
						v_u_112.Parent = v_u_111.Skull
						v_u_14:WorldModelChar(p_u_100, v_u_111.BG)
						local v_u_113 = Instance.new("NumberValue", v_u_111)
						v_u_4:Create(v_u_113, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
							["Value"] = 1
						}):Play()
						v_u_3:AddItem(v_u_113, 0.5)
						v_u_4:Create(v_u_111.BG, TweenInfo.new(0.5), {
							["ImageTransparency"] = 0.1
						}):Play()
						v_u_4:Create(v_u_111.BG, TweenInfo.new(0.85), {
							["BackgroundTransparency"] = 0.65
						}):Play()
						v_u_4:Create(v_u_111.BG.Vignette, TweenInfo.new(0.85), {
							["ImageTransparency"] = 0
						}):Play()
						v_u_4:Create(v_u_111.Skull, TweenInfo.new(1), {
							["ImageTransparency"] = 0
						}):Play()
						task.delay(0.85, function()
							-- upvalues: (ref) v_u_4, (copy) v_u_111
							v_u_4:Create(v_u_111.BG, TweenInfo.new(0.85), {
								["BackgroundTransparency"] = 1
							}):Play()
							v_u_4:Create(v_u_111.BG.Vignette, TweenInfo.new(0.85), {
								["ImageTransparency"] = 1
							}):Play()
							task.wait(0.15)
							local v114 = TweenInfo.new(0.7, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
							v_u_4:Create(v_u_111.Skull, v114, {
								["ImageTransparency"] = 1
							}):Play()
							v_u_4:Create(v_u_111.BG, v114, {
								["ImageTransparency"] = 1
							}):Play()
						end)
						local v_u_115 = 0
						local v_u_116 = nil
						tick()
						local v_u_117 = v_u_8.Haruta.JawbreakerCutscene
						v_u_116 = v_u_2.RenderStepped:Connect(function(p118)
							-- upvalues: (ref) v_u_115, (copy) v_u_117, (copy) p_u_98, (copy) v_u_102, (copy) p_u_101, (copy) v_u_109, (copy) v_u_110, (copy) v_u_103, (copy) v_u_113, (ref) v_u_116, (ref) v_u_5, (ref) v_u_4, (ref) v_u_10, (copy) v_u_111, (ref) v_u_3, (copy) v_u_112, (copy) p_u_100
							v_u_115 = v_u_115 + p118 * 120
							local v119 = v_u_117.Frames
							local v120 = v_u_115
							local v121 = math.ceil(v120)
							local v122 = v119:FindFirstChild((tonumber(v121)))
							if v122 and (p_u_98 and (p_u_98.Parent and (v_u_102 and p_u_101.Parent))) then
								v_u_109.CFrame = v_u_110:Lerp(v_u_103.CFrame * v122.Value, v_u_113.Value)
								v_u_109.CameraType = Enum.CameraType.Scriptable
							else
								v_u_116:Disconnect()
								v_u_109.CameraType = Enum.CameraType.Custom
								v_u_109.FieldOfView = 70
								v_u_109.CameraSubject = (v_u_5.Character or v_u_5.CharacterAdded:Wait()):WaitForChild("Humanoid")
								game.Lighting.ExposureCompensation = -2
								v_u_4:Create(game.Lighting, TweenInfo.new(1), {
									["ExposureCompensation"] = 0
								}):Play()
								v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
								v_u_111:Destroy()
								local v123 = Instance.new("BlurEffect", game.Lighting)
								v_u_3:AddItem(v123, 8)
								v123.Size = 64
								v_u_4:Create(v123, TweenInfo.new(8, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
									["Size"] = 0
								}):Play()
								if _G.Settings.Flash == true then
									local v124 = Instance.new("ColorCorrectionEffect", game.Lighting)
									v_u_3:AddItem(v124, 9)
									v124.TintColor = Color3.new(1, 0, 0)
									v124.Contrast = 200
									task.wait(0.05)
									v124.Contrast = -200
									v124.TintColor = Color3.new(1, 1, 1)
									task.wait(0.05)
									v124.Contrast = 0
									v124.TintColor = Color3.new(1, 0.3, 0.3)
									v_u_4:Create(v124, TweenInfo.new(8, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
										["TintColor"] = Color3.fromRGB(255, 201, 201)
									}):Play()
									task.wait(8)
									v_u_4:Create(v124, TweenInfo.new(2.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
										["TintColor"] = Color3.fromRGB(255, 255, 255)
									}):Play()
								end
							end
							v_u_112.CFrame = p_u_100.Head.CFrame
						end)
					end
				else
					return
				end
			else
				return
			end
		end
	}
	v_u_12.Effects:Connect(function(p126, ...)
		-- upvalues: (copy) v_u_125
		local v127 = v_u_125[p126]
		if v127 then
			v127(...)
		end
	end)
end
function v15.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_12, (copy) v_u_1, (ref) v_u_13, (ref) v_u_14
	v_u_12 = v_u_1.GetService("HarutaService")
	v_u_13 = v_u_1.GetController("HitboxController")
	v_u_14 = v_u_1.GetController("FXController")
end
return v15