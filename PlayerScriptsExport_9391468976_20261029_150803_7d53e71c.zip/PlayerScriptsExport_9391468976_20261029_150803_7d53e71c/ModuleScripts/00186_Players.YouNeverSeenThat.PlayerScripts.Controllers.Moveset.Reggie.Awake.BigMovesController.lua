-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Reggie.Awake.BigMovesController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
game:GetService("TweenService")
local v_u_3 = game.Players.LocalPlayer
local v4 = game.ReplicatedStorage
local _ = v4.Animations
local v_u_5 = v4.Utils
local v_u_6 = v4.Sounds
local v_u_7 = require(v4.Modules.CameraShaker)
require(v4.Modules.BloodyZee)
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "BigMovesController"
})
function v11.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_10, (copy) v_u_6, (copy) v_u_5, (copy) v_u_2, (copy) v_u_3, (copy) v_u_7, (ref) v_u_8
	local v_u_23 = {
		["Hit"] = function(p12, p13)
			-- upvalues: (ref) v_u_10, (ref) v_u_6, (ref) v_u_5, (ref) v_u_2, (ref) v_u_3, (ref) v_u_7
			if p12:FindFirstChild("HumanoidRootPart") then
				local v14 = p13:FindFirstChild("HumanoidRootPart")
				if v14 then
					v_u_10:Flash(p13, Color3.new(1, 1, 1))
					v_u_10:PlaySound(v_u_6.Reggie.TruckHit, v14, game.SoundService.Effect)
					local v15 = v_u_5.Mahito.CrushingRushdown.DrillImpact:Clone()
					v15.Position = v14.Position
					v15.Parent = workspace.Effects
					v_u_2:AddItem(v15, 1)
					v15.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 1))
					v15.Wind.Color = v15.Sparks.Color
					v15.Wind2.Color = v15.Sparks.Color
					v15.Sparks:Emit(50)
					v15.Wind2:Emit(7)
					if v_u_3.Character == p12 or v_u_3.Character == p13 then
						v_u_7.CurrentShaker:Shake(v_u_7.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["Shake"] = function(p16)
			-- upvalues: (ref) v_u_10, (ref) v_u_6, (ref) v_u_5, (ref) v_u_7
			v_u_10:PlaySound(v_u_6.Reggie.TruckHorn, p16, game.SoundService.Effect)
			local v17 = v_u_5.Reggie.TruckWind:Clone()
			v17.Parent = p16.Parent.Truck.Main
			v17.Wind1.Parent = p16.Parent.Truck.Main
			v17.Wind2.Parent = p16.Parent.Truck.Main
			task.wait(0.1)
			if (p16:GetAttribute("Speed") or 0) < 40 and (p16.Parent and p16.Parent.Truck.Main.Wind1.Enabled) then
				p16.Parent.Truck.Main.Wind1.Enabled = false
				p16.Parent.Truck.Main.Wind2.Enabled = false
			end
			if (workspace.CurrentCamera.CFrame.Position - p16.Position).Magnitude < 60 and (p16:GetAttribute("Speed") or 0) > 40 then
				v_u_7.CurrentShaker:Shake(v_u_7.Presets.HeavyHit)
			end
			if p16.Parent then
				continue
			end
			if v17 and v17.Parent then
				v17:Destroy()
			end
		end,
		["Explode"] = function(p18, p19)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_10, (ref) v_u_6, (ref) v_u_3, (ref) v_u_7
			local v20 = v_u_5.Reggie.Explosion:Clone()
			local v21 = Instance.new("Model")
			v20.Parent = v21
			v21:ScaleTo(2.5)
			v_u_2:AddItem(v21, 0.2)
			v20.Parent = workspace.Effects
			v20.WorldCFrame = CFrame.new(p19)
			for _, v22 in v20:GetDescendants() do
				if not v22:IsA("ParticleEmitter") then
					continue
				end
				v22:Emit(v22:GetAttribute("EmitCount"))
			end
			v_u_2:AddItem(v20, 3)
			v_u_10:PlaySound(v_u_6.Reggie.SpeedCrash.Explode, v20, game.SoundService.Effect).PlaybackSpeed = math.random(90, 125) / 100
			if (workspace.CurrentCamera.CFrame.Position - p19).Magnitude < 60 or v_u_3.Character == p18 then
				v_u_7.CurrentShaker:Shake(v_u_7.Presets.Snap)
			end
		end
	}
	v_u_8.Effects:Connect(function(p24, ...)
		-- upvalues: (copy) v_u_23
		local v25 = v_u_23[p24]
		if v25 then
			v25(...)
		end
	end)
end
function v11.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_8, (copy) v_u_1, (ref) v_u_9, (ref) v_u_10
	v_u_8 = v_u_1.GetService("BigMovesService")
	v_u_9 = v_u_1.GetController("HitboxController")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11