-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Hanami.Awake.CursedBudsController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local v_u_6 = v_u_5.Animations
local v_u_7 = v_u_5.Utils
local v_u_8 = v_u_5.Sounds
require(v_u_5.Modules.CameraShaker)
require(v_u_5.Modules.BloodyZee)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "CursedBudsController"
})
local v_u_13 = { Color3.fromRGB(86, 66, 54), Color3.fromRGB(76, 60, 51), Color3.fromRGB(86, 60, 51) }
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_10, (copy) v_u_8, (copy) v_u_5, (copy) v_u_13, (copy) v_u_3, (copy) v_u_6, (copy) v_u_4, (ref) v_u_11, (copy) v_u_7, (copy) v_u_2, (ref) v_u_9
	local v_u_59 = {
		["Start"] = function(p14)
			-- upvalues: (ref) v_u_10, (ref) v_u_8
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_10:PlaySound(v_u_8.Hanami.CursedBuds.Start, v15, game.SoundService.Effect)
			end
		end,
		["Appear"] = function(p16, p_u_17, p18)
			-- upvalues: (ref) v_u_5, (ref) v_u_13, (ref) v_u_3, (ref) v_u_10, (ref) v_u_6, (ref) v_u_8, (ref) v_u_4, (ref) v_u_11
			if p16:FindFirstChild("HumanoidRootPart") then
				local v_u_19 = v_u_5.Utils.Hanami.ParticleDissipationHolder
				local v_u_20 = v_u_13[math.random(1, #v_u_13)]
				local v_u_21 = p_u_17:GetScale()
				local v_u_22 = p_u_17:GetPivot() * CFrame.new(0, -6.65 * v_u_21, 0)
				task.spawn(function()
					-- upvalues: (copy) v_u_21, (copy) v_u_22, (ref) v_u_5, (copy) p_u_17, (ref) v_u_3, (ref) v_u_10, (ref) v_u_6, (copy) v_u_19, (copy) v_u_20
					local v23 = math.random() * 3.141592653589793 * 2
					for v24 = 1, 4 do
						local v25 = v23 + (v24 - 1) / 4 * 3.141592653589793 * 2
						local v26 = (3 + math.random() * 2) * v_u_21
						local v27 = math.cos(v25) * v26
						local v28 = math.sin(v25) * v26
						local v29 = v_u_22 + Vector3.new(v27, 0, v28) + Vector3.new(0, 1, 0)
						local v30 = workspace:Raycast(v29.Position, Vector3.new(0, -15, 0), _G.MapParams)
						if not v30 then
							continue
						end
						local v_u_31 = v_u_5.Utils.Hanami.bud1:Clone()
						v_u_31.Parent = workspace.Effects
						task.delay(0.7, function()
							-- upvalues: (copy) v_u_31, (ref) p_u_17
							v_u_31.Parent = p_u_17
						end)
						v_u_31:PivotTo(CFrame.new(v30.Position) * CFrame.Angles(0, math.random(-360, 360), 0))
						v_u_31:ScaleTo(2.584 + v_u_21 / 2)
						v_u_3:AddItem(v_u_31, 10)
						v_u_10:DustBreak(v30.Position + Vector3.new(0, 1, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
						local v_u_32 = v_u_31.AnimationController:LoadAnimation(v_u_6.Hanami.CursedBudsTreeSmall)
						v_u_32:Play()
						v_u_32:GetMarkerReachedSignal("Loop"):Connect(function(p33)
							-- upvalues: (copy) v_u_32
							v_u_32.TimePosition = p33
						end)
						for _, v34 in v_u_31:GetDescendants() do
							if not v34:IsA("BasePart") or (v34.Transparency ~= 0 or v34.Color ~= Color3.fromRGB(84, 72, 47)) then
								continue
							end
							for _, v35 in v_u_19:GetChildren() do
								local v36 = v35:Clone()
								v36.Shape = Enum.ParticleEmitterShape.Box
								v36.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v34.Size.X, 0), NumberSequenceKeypoint.new(1, v34.Size.X, 0) })
								v36.Parent = v34
							end
							v34.Color = v_u_20
						end
					end
				end)
				v_u_10:DustBreak(v_u_22.Position + Vector3.new(0, 1, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
				v_u_10:PlaySound(v_u_8.Hanami.CursedBuds.Appear, p_u_17.HumanoidRootPart, game.SoundService.Effect)
				for _, v37 in p_u_17:GetDescendants() do
					if v37:GetAttribute("Smoke") then
						for _, v38 in v_u_19:GetChildren() do
							local v39 = v38:Clone()
							v39.Shape = Enum.ParticleEmitterShape.Box
							v39.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v37.Size.X, 0), NumberSequenceKeypoint.new(1, v37.Size.X, 0) })
							v39.Parent = v37
						end
					end
					if not v37:IsA("BasePart") or v37.Color ~= Color3.fromRGB(84, 72, 47) then
						continue
					end
					v37.Color = v_u_20
				end
				p_u_17:ScaleTo(0.25)
				p_u_17:PivotTo(p_u_17:GetPivot() * CFrame.new(0, -1.6625, 0))
				local v_u_40 = Instance.new("NumberValue")
				v_u_40.Value = 0.25
				v_u_40:GetPropertyChangedSignal("Value"):Connect(function()
					-- upvalues: (copy) p_u_17, (copy) v_u_40, (copy) v_u_22
					p_u_17:ScaleTo(v_u_40.Value)
					p_u_17:PivotTo(v_u_22 * CFrame.new(0, 6.65 * v_u_40.Value, 0))
				end)
				v_u_4:Create(v_u_40, TweenInfo.new(0.65), {
					["Value"] = v_u_21
				}):Play()
				local v_u_41 = Instance.new("NumberValue")
				v_u_41.Value = 0.923 * v_u_21
				v_u_41:GetPropertyChangedSignal("Value"):Connect(function()
					-- upvalues: (copy) p_u_17, (copy) v_u_41
					p_u_17.Model:ScaleTo(v_u_41.Value)
				end)
				task.delay(0.25, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_41, (copy) v_u_21, (copy) p_u_17
					v_u_4:Create(v_u_41, TweenInfo.new(1), {
						["Value"] = 1.25 * v_u_21
					}):Play()
					v_u_4:Create(p_u_17.stem4.Mouth.PartRoot, TweenInfo.new(0.5), {
						["C0"] = CFrame.new(0, 1.65 * v_u_21, 0)
					}):Play()
				end)
				while p18 and p18.Parent do
					task.wait(0.02)
					local v42 = v_u_11:GetTarget()
					local v43
					if v42 == nil then
						v43 = v_u_11:GetMouseTarget(300)
					else
						v43 = v42.PrimaryPart.Position
					end
					p18:FireServer(v43)
				end
				v_u_4:Create(v_u_41, TweenInfo.new(0.85), {
					["Value"] = 0.923 * v_u_21
				}):Play()
			end
		end,
		["Interp"] = function(p_u_44, p45)
			-- upvalues: (ref) v_u_10, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_2
			v_u_10:PlaySound(v_u_8.Hanami.BudShot.Throw, p45.HumanoidRootPart, game.SoundService.Effect).PlaybackSpeed = math.random(90, 110) / 100
			local v46 = v_u_7.Gojo.LapseBlue.Throw:Clone()
			v46.CFrame = p_u_44.CFrame * CFrame.new(0, 0, -1.5 * p45:GetScale())
			v46.Size = Vector3.new(0, 0, 1.25)
			v46.Parent = workspace.Effects
			v46.Transparency = 0.5
			v_u_4:Create(v46, TweenInfo.new(0.2), {
				["Size"] = Vector3.new(8.75, 8.75, 0),
				["Position"] = nil,
				["Transparency"] = 1,
				["Position"] = v46.Position - p_u_44.CFrame.LookVector * -2
			}):Play()
			v_u_3:AddItem(v46, 0.2)
			local v_u_47 = p_u_44.CFrame
			local v_u_48 = tick()
			local v_u_49 = p_u_44:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_47, (copy) p_u_44, (ref) v_u_48
				v_u_47 = p_u_44.CFrame
				v_u_48 = tick()
			end)
			local v_u_50 = nil
			v_u_50 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_44, (ref) v_u_50, (copy) v_u_49, (ref) v_u_47, (ref) v_u_48
				if p_u_44.Parent then
					workspace:BulkMoveTo({ p_u_44 }, { v_u_47 + v_u_47.LookVector * (200 * (tick() - v_u_48)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_50:Disconnect()
					v_u_49:Disconnect()
				end
			end)
		end,
		["Hit"] = function(p51)
			-- upvalues: (ref) v_u_10, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v52 = p51:FindFirstChild("HumanoidRootPart")
			if v52 then
				v_u_10:PlaySound(v_u_8.Hanami.BudShot[("Hit%*"):format((math.random(1, 2)))], v52, game.SoundService.Effect).PlaybackSpeed = math.random(90, 110) / 100
				v_u_10:Flash(p51, Color3.new(1, 1, 1))
				local v53 = v_u_7.Gojo.Twofold.Sparks:Clone()
				v53.Parent = v52.RootAttachment
				v53:Emit(20)
				v_u_3:AddItem(v53, 0.4)
			end
		end,
		["Hit2"] = function(p54)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_10, (ref) v_u_8
			local v55 = p54:FindFirstChild("HumanoidRootPart")
			if v55 then
				local v56 = v_u_7.Mahito.CrushingRushdown.DrillImpact:Clone()
				v56.Position = v55.Position
				v56.Parent = workspace.Effects
				v_u_3:AddItem(v56, 1)
				v56.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 0.498039))
				v56.Wind.Color = v56.Sparks.Color
				v56.Wind2.Color = v56.Sparks.Color
				v56.Sparks:Emit(30)
				v56.Wind2:Emit(7)
				v_u_10:Flash(p54, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_8.Hanami.DefenseResponse.Hit2, v55, game.SoundService.Effect)
			end
		end,
		["Disappear"] = function(_, p57)
			-- upvalues: (ref) v_u_10, (ref) v_u_8
			for _, v58 in p57:GetDescendants() do
				if not (v58:IsA("BasePart") or v58:IsA("Decal")) then
					continue
				end
				v58.Transparency = 1
			end
			v_u_10:PlayParticles(p57)
			v_u_10:PlaySound(v_u_8.Hanami.CursedBuds.Disappear, p57.HumanoidRootPart, game.SoundService.Effect)
		end
	}
	v_u_9.Effects:Connect(function(p60, ...)
		-- upvalues: (copy) v_u_59
		local v61 = v_u_59[p60]
		if v61 then
			v61(...)
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("CursedBudsService")
	v_u_10 = v_u_1.GetController("FXController")
	v_u_11 = v_u_1.GetController("ToolController")
end
return v12