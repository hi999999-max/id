-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Character.EmoteController.Effects
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("Debris")
local v_u_5 = game:GetService("RunService")
local v_u_6 = game:GetService("SoundService")
local v_u_7 = v_u_1.LocalPlayer
local v_u_8 = v_u_2:WaitForChild("Utils", (1 / 0))
local v9 = v_u_2:WaitForChild("Modules", (1 / 0))
local v_u_10 = v_u_8:WaitForChild("Misc", (1 / 0))
local v_u_11 = require(v9.CameraShaker)
local v_u_12 = require(v9.BloodyZee)
local v13 = require(v_u_2.Knit.Knit)
local v_u_14 = Random.new()
local v_u_15 = workspace.Effects
local v_u_16 = workspace.CurrentCamera
local function v_u_26(p17, p18, p19) -- name: SoundPlay
	-- upvalues: (copy) v_u_10, (copy) v_u_15, (copy) v_u_4
	local v20 = typeof(p18)
	local v21 = v_u_10.Sounds:FindFirstChild(p17)
	if not v21 then
		local v22 = print
		local v23 = "Failed to find sound for [%s]: %s"
		if v20 == "Instance" then
			v20 = p18.Name or v20
		end
		return v22(v23:format(v20, v21))
	end
	local v24 = v21:Clone()
	local v25
	if v20 == "Instance" then
		v25 = p18
	else
		if v20 == "Vector3" then
			p18 = CFrame.new(p18) or p18
		end
		v25 = Instance.new("Part")
		v25.Anchored = true
		v25.CanCollide = false
		v25.Transparency = 1
		v25.CanCollide = false
		v25.CanQuery = false
		v25.CanTouch = false
		v25.CFrame = p18
		v25.Parent = v_u_15.CamIgnore
		v_u_4:AddItem(v25, (p19 or v24.TimeLength / v24.PlaybackSpeed) + 2)
	end
	v24.Parent = v25
	v24:Play()
	if p19 then
		v_u_4:AddItem(v24, p19)
	end
end
local function v_u_32(p27) -- name: Emit
	local v28 = next
	local v29, v30 = p27:GetDescendants()
	for _, v31 in v28, v29, v30 do
		if not v31:IsA("ParticleEmitter") then
			continue
		end
		v31:Emit(v31:GetAttribute("EmitCount"))
	end
end
local function v_u_39(p33, p34) -- name: SetEnabled
	local v35 = next
	local v36, v37 = p33:GetDescendants()
	for _, v38 in v35, v36, v37 do
		if not v38:IsA("ParticleEmitter") then
			continue
		end
		v38.Enabled = p34
	end
end
local function v_u_43(p_u_40) -- name: Cleanup
	-- upvalues: (copy) v_u_43
	if p_u_40 then
		for v41 = #p_u_40, 1, -1 do
			local v42 = p_u_40[v41]
			if not v42 then
				continue
			end
			table.remove(p_u_40, v41)
			if typeof(v42) == "RBXScriptConnection" then
				v42:Disconnect()
			elseif type(v42) == "function" then
				pcall(v42)
			elseif v42:IsA("AnimationTrack") then
				v42:Stop()
			else
				v42:Destroy()
			end
		end
		task.defer(function()
			-- upvalues: (ref) p_u_40, (ref) v_u_43
			if #p_u_40 <= 0 then
				p_u_40 = nil
			else
				v_u_43(p_u_40)
			end
		end)
	end
end
local v_u_44 = v13.GetController("FXController")
local v_u_45 = RaycastParams.new()
v_u_45.FilterType = Enum.RaycastFilterType.Include
v_u_45.FilterDescendantsInstances = { workspace:WaitForChild("Map") }
local v_u_46 = nil
v_u_46 = {
	["UltraCoinUse"] = function(p47)
		-- upvalues: (copy) v_u_26
		local v48 = p47:FindFirstChild("HumanoidRootPart")
		if v48 then
			v_u_26("UltraCoin Use", v48)
		end
	end,
	["UltraCoinThrow"] = function(p49)
		-- upvalues: (copy) v_u_32, (copy) v_u_45, (copy) v_u_3, (copy) v_u_26, (copy) v_u_5
		v_u_32(p49)
		while p49.Parent and p49.Transparency == 0 do
			if workspace:Raycast(p49.Position + Vector3.new(0, 1, 0), Vector3.new(0, -3, 0), v_u_45) then
				local v50 = v_u_3:Create(p49.Light.PointLight, TweenInfo.new(0.25), {
					["Brightness"] = 0
				})
				v50:Play()
				v50:Destroy()
				v_u_26("UltraCoin Coin Land", p49)
				return
			end
			v_u_5.Heartbeat:Wait()
		end
	end,
	["CameraShake"] = function(p51, p52, p53)
		-- upvalues: (copy) v_u_16, (copy) v_u_11
		if p52 then
			if typeof(p52) == "CFrame" then
				p52 = p52.Position
			end
			if (p53 or 200) < (v_u_16.CFrame.Position - p52).Magnitude then
				return
			end
		end
		v_u_11.CurrentShaker:Shake(v_u_11.Presets[p51])
	end,
	["UltraCoinPiercerShoot"] = function(p54)
		-- upvalues: (copy) v_u_32, (copy) v_u_26, (copy) v_u_3
		if p54.Parent then
			v_u_32(p54)
			v_u_26("UltraCoin Shoot", p54.Handle.CFrame)
			local v55 = v_u_3:Create(p54.Handle.Light.PointLight, TweenInfo.new(0.25), {
				["Brightness"] = 0
			})
			v55:Play()
			v55:Destroy()
			p54.Handle.Light.PointLight.Enabled = true
		end
	end,
	["UltraCoinShoot"] = function(p56, _, p57, p58, p59)
		-- upvalues: (copy) v_u_15, (copy) v_u_4, (copy) v_u_3, (copy) v_u_26, (copy) v_u_10, (copy) v_u_39, (copy) v_u_12, (copy) v_u_32
		local v60 = p58 and (typeof(p58) == "Vector3" and p58 or p58.Position) or p56.Handle.ShootPoint.WorldCFrame.Position
		local v61 = (v60 - p57.Position).Magnitude
		local v62 = Instance.new("Part")
		v62.Parent = v_u_15
		v_u_4:AddItem(v62, 0.41)
		v62.Anchored = true
		v62.CanCollide = false
		v62.CollisionGroup = "NoCollision"
		v62.Material = Enum.Material.Neon
		v62.Size = vector.create(0.35, 0.35, v61)
		v62.CFrame = CFrame.lookAt(v60, p57.Position) * CFrame.new(0, 0, -v61 / 2)
		local v63 = v_u_3:Create(v62, TweenInfo.new(p58 and 0.6 or 0.28), {
			["Size"] = vector.create(0, 0, v61)
		})
		v63:Play()
		v63:Destroy()
		v_u_26("UltraCoin Coin Hit", p57.CFrame)
		if p58 then
			v62.Color = Color3.fromRGB(147, 130, 3)
			if typeof(p58) == "Vector3" or (not p58.Parent:FindFirstChild("Torso") or (not p58.Parent:FindFirstChild("Head") or p58.Parent.Torso:FindFirstChild("DecapitateBlood"))) then
				if typeof(p58) == "Vector3" and (p59 and p59:IsDescendantOf(workspace.Map)) then
					local v64 = v_u_10.SparksGround:Clone()
					v64.CFrame = CFrame.new(p58)
					v64.Parent = v_u_15
					v_u_4:AddItem(v64, 7)
					v_u_32(v64)
					v_u_26("UltraCoin Debris", p58)
					local v65 = v_u_3:Create(v64.Attachment.Light, TweenInfo.new(0.3), {
						["Brightness"] = 0
					})
					v65:Play()
					v65:Destroy()
					for _ = 1, math.random(4, 5) do
						local v_u_66 = Instance.new("Part")
						v_u_66.CFrame = CFrame.new(p58)
						v_u_66.Size = Vector3.new(0.01, 0.01, 0.01)
						v_u_66.CanCollide = false
						v_u_66.CanTouch = false
						v_u_66.CollisionGroup = "Effects"
						v_u_66.Color = p59.Color
						v_u_66.Material = p59.Material
						v_u_66.MaterialVariant = p59.MaterialVariant
						v_u_66.Parent = v_u_15
						v_u_4:AddItem(v_u_66, 4.5)
						local v67 = Instance.new("BodyVelocity")
						v67.MaxForce = Vector3.new(50000, 50000, 50000)
						v67.Velocity = Vector3.new(1, 0, 0) * math.random(-13, 13) + Vector3.new(0, 0, 1) * math.random(-13, 13) + Vector3.new(0, 1, 0) * math.random(6, 30)
						v67.Parent = v_u_66
						v_u_4:AddItem(v67, 0.15)
						local v68 = Instance.new("BodyAngularVelocity")
						v68.MaxTorque = Vector3.new(50000, 50000, 50000)
						local v69 = math.random(-10, 10)
						local v70 = math.random(-10, 10)
						local v71 = math.random
						v68.AngularVelocity = vector.create(v69, v70, v71(-10, 10))
						v68.Parent = v_u_66
						v_u_4:AddItem(v68, 0.2)
						task.delay(0.1, function()
							-- upvalues: (copy) v_u_66
							v_u_66.CanCollide = true
						end)
						local v72 = math.random(2, 6) / 10
						local v73 = math.random(2, 6) / 10
						local v74 = math.random(2, 6) / 10
						local v75 = {
							["Size"] = vector.create(v72, v73, v74)
						}
						local v76 = v_u_3:Create(v_u_66, TweenInfo.new(math.random(1, 5) / 10, Enum.EasingStyle.Back, Enum.EasingDirection.Out), v75)
						v76:Play()
						v76:Destroy()
						task.delay(math.random(25, 32) / 10, function()
							-- upvalues: (ref) v_u_3, (copy) v_u_66
							local v77 = v_u_3
							local v78 = v_u_66
							local v79 = TweenInfo.new(math.random(3, 11) / 10)
							local v80 = {
								["Position"] = nil,
								["Size"] = Vector3.new(0.01, 0.01, 0.01),
								["Color"] = nil
							}
							local v81 = v_u_66.Position
							local v82 = math.random(1, 15) / 10
							v80.Position = v81 + vector.create(0, v82, 0)
							v80.Color = Color3.new(0.07, 0.07, 0.07)
							local v83 = v77:Create(v78, v79, v80)
							v83:Play()
							v83:Destroy()
						end)
					end
				end
			else
				local v84 = p58.Parent
				local v85 = v84.Torso
				local v86 = {
					Enum.AccessoryType.Face,
					Enum.AccessoryType.Hat,
					Enum.AccessoryType.Hair,
					Enum.AccessoryType.Eyebrow,
					Enum.AccessoryType.Eyelash
				}
				p58.Transparency = 1
				for _, v87 in pairs(v84:GetChildren()) do
					if not (v87:IsA("Accessory") and table.find(v86, v87.AccessoryType)) then
						continue
					end
					local v88 = v87:FindFirstChild("Handle", true)
					if not v88 then
						continue
					end
					v88.Transparency = 1
				end
				if _G.Settings.Gore then
					local v89 = v_u_10.DecapitateBlood:Clone()
					v89.Parent = v85
					task.delay(5, v_u_39, v89, false)
					v_u_4:AddItem(v89, 7)
				end
				while v84.Parent and p58.Parent do
					v_u_12:Blood(v85.CFrame * CFrame.new(0, 0.3, 0), math.random(5, 30), 360, 360)
					task.wait(math.random(5, 15) / 100)
				end
			end
		end
	end,
	["UltraCoinHitDead"] = function(p90, p91, p92, p_u_93)
		-- upvalues: (ref) v_u_46, (copy) v_u_10, (copy) v_u_4, (copy) v_u_32, (copy) v_u_12, (copy) v_u_26
		task.spawn(v_u_46.UltraCoinShoot, p90, p91, p92, p_u_93.Head)
		if _G.Settings.Gore then
			local v94 = v_u_10.BloodBurst:Clone()
			v94.Parent = p_u_93.Head
			v_u_4:AddItem(v94, 5)
			v_u_32(v94)
		end
		local v_u_95 = p_u_93.Head.CFrame
		local v_u_96 = math.random(30, 32)
		local v_u_97 = 10
		local v_u_98 = 180
		local v_u_99 = 180
		local v_u_100 = 0.08
		task.spawn(function()
			-- upvalues: (copy) v_u_96, (copy) p_u_93, (ref) v_u_12, (copy) v_u_95, (copy) v_u_97, (copy) v_u_98, (copy) v_u_99, (copy) v_u_100
			for _ = 1, v_u_96 or 1 do
				if p_u_93 and not p_u_93.Parent then
					break
				end
				v_u_12:Blood(v_u_95, v_u_97, v_u_98, v_u_99)
				if not v_u_100 then
					continue
				end
				task.wait(v_u_100)
			end
		end)
		v_u_46.CameraShake("ViolenterBump", p_u_93.Head.Position, 60)
		v_u_26("UltraCoin Headshot", p_u_93.Head)
	end,
	["UltraCoinHitEnemy"] = function(p_u_101, p102, _)
		-- upvalues: (copy) v_u_26, (copy) v_u_12, (ref) v_u_46
		v_u_26("UltraCoin Hit", p102)
		local v_u_103 = CFrame.new(p102)
		local v_u_104 = math.random(10, 14)
		local v_u_105 = 15
		local v_u_106 = 180
		local v_u_107 = 180
		local v_u_108 = 0.08
		task.spawn(function()
			-- upvalues: (copy) v_u_104, (copy) p_u_101, (ref) v_u_12, (copy) v_u_103, (copy) v_u_105, (copy) v_u_106, (copy) v_u_107, (copy) v_u_108
			for _ = 1, v_u_104 or 1 do
				if p_u_101 and not p_u_101.Parent then
					break
				end
				v_u_12:Blood(v_u_103, v_u_105, v_u_106, v_u_107)
				if not v_u_108 then
					continue
				end
				task.wait(v_u_108)
			end
		end)
		v_u_46.CameraShake("SmallBump", p102, 60)
	end,
	["AfterImageJevil"] = function(p109, p110, p111)
		-- upvalues: (copy) v_u_14, (copy) v_u_3, (copy) v_u_15, (copy) v_u_4
		if p109:FindFirstChild("HumanoidRootPart") then
			local v112 = p109:Clone()
			v112.Humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
			local v113 = v112.HumanoidRootPart.CFrame * (p110 == "Left" and CFrame.new(5, 0, 0) or CFrame.new(-5, 0, 0))
			local v114 = v_u_14:NextInteger(-0.5, 0.5)
			local v115 = v_u_14:NextInteger(-0.5, 0.5)
			local v116 = v_u_14
			local v117 = vector.create(v114, v115, v116:NextInteger(-0.5, 0.5))
			local v118 = next
			local v119, v120 = v112:GetDescendants()
			for _, v121 in v118, v119, v120 do
				if v121:IsA("BasePart") then
					v121.CanCollide = false
					v121.CanQuery = false
					v121.Anchored = true
					v121.CollisionGroup = "Effects"
					if v121.Transparency >= 1 then
						continue
					end
					v121.Transparency = 0.5
					local v122 = v_u_3:Create(v121, TweenInfo.new(0.2 / p111, Enum.EasingStyle.Linear), {
						["Transparency"] = 1,
						["CFrame"] = nil,
						["CFrame"] = v113 * v112.HumanoidRootPart.CFrame:ToObjectSpace(v121.CFrame) + v117
					})
					v122:Play()
					v122:Destroy()
				elseif v121:IsA("Sound") or (v121:IsA("Highlight") or v121:IsA("LuaSourceContainer")) then
					v121:Destroy()
				else
					if not v121:IsA("Decal") or v121.Transparency >= 1 then
						continue
					end
					local v123 = v_u_3:Create(v121, TweenInfo.new(0.2 / p111, Enum.EasingStyle.Linear), {
						["Transparency"] = 1
					})
					v123:Play()
					v123:Destroy()
				end
			end
			v112.Parent = v_u_15
			v_u_4:AddItem(v112, 0.3 / p111)
		end
	end,
	["LoopingTheRoomsClone"] = function(p124, p125)
		-- upvalues: (copy) v_u_15, (copy) v_u_8, (copy) v_u_4
		if p125 then
			for _, v126 in v_u_15:GetChildren() do
				if v126.Name ~= p124.Name .. "_Looping" then
					continue
				end
				v126:Destroy()
			end
		else
			local v127 = v_u_8.Damage.HitGlow:Clone()
			if p124:GetScale() ~= 1 then
				v127:ScaleTo(p124:GetScale())
			end
			v127.Name = p124.Name .. "_Looping"
			v127.Parent = workspace.Effects
			v_u_4:AddItem(v127, 12.5)
			for _, v128 in v127:GetChildren() do
				local v129 = p124:FindFirstChild(v128.Name)
				if v129 then
					v128.CFrame = v129.CFrame
				end
				v128.Anchored = true
				v128.Color = Color3.fromRGB(255, 255, 255)
				v128.Transparency = 0.99
			end
		end
	end,
	["StaticClone"] = function(p130, p131, p132, p133, p134)
		-- upvalues: (copy) v_u_15, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8
		if p134 then
			for _, v135 in v_u_15:GetChildren() do
				if v135.Name ~= p130.Name .. "_StaticClone" then
					continue
				end
				v135:Destroy()
			end
			return
		elseif p133 then
			for _, v136 in v_u_15:GetChildren() do
				if v136.Name ~= p130.Name .. "_StaticClone" then
					continue
				end
				for _, v137 in v136:GetChildren() do
					v_u_3:Create(v137, TweenInfo.new(0.4), {
						["Transparency"] = 1
					}):Play()
				end
				v_u_4:AddItem(v136, 0.5)
			end
		else
			task.wait()
			local v138 = 1
			for _, v139 in v_u_15:GetChildren() do
				if v139.Name ~= p130.Name .. "_StaticClone" then
					continue
				end
				v138 = v138 + 1
				for _, v140 in v139:GetChildren() do
					v_u_3:Create(v140, TweenInfo.new(0.4, Enum.EasingStyle.Cubic), {
						["Position"] = v140.Position + p132.RightVector * 1.75
					}):Play()
				end
			end
			local v141 = v_u_8.Damage.HitGlow:Clone()
			if p130:GetScale() ~= 1 then
				v141:ScaleTo(p130:GetScale())
			end
			v141.Name = p130.Name .. "_StaticClone"
			v141.Parent = workspace.Effects
			v_u_4:AddItem(v141, 12.5)
			for _, v142 in v141:GetChildren() do
				local v143 = p130:FindFirstChild(v142.Name)
				if v143 then
					v142.CFrame = v143.CFrame
				end
				v142.Anchored = true
				v142.Color = p131
				v142.Transparency = 0.4
				v_u_3:Create(v142, TweenInfo.new(0.8, Enum.EasingStyle.Cubic), {
					["Transparency"] = 1
				}):Play()
				v_u_3:Create(v142, TweenInfo.new(0.4, Enum.EasingStyle.Cubic), {
					["Position"] = v142.Position + p132.RightVector * 1.75
				}):Play()
			end
		end
	end,
	["GanonSpin"] = function(p144, p_u_145)
		-- upvalues: (copy) v_u_8, (copy) v_u_3, (copy) v_u_4
		local v_u_146 = p144:FindFirstChild("HumanoidRootPart")
		if v_u_146 then
			local v_u_147 = v_u_8.Misc.Emotes.Ganon
			task.spawn(function()
				-- upvalues: (copy) p_u_145, (copy) v_u_147, (copy) v_u_146, (ref) v_u_3, (ref) v_u_4
				for _ = 1, 3 do
					if not p_u_145.Parent then
						break
					end
					local v148 = v_u_147.ShadedSpikeyMesh:Clone()
					local v149 = v148.Mesh
					v149.Scale = Vector3.new(0.1, 0.3, 0.1)
					v149.VertexColor = Vector3.new(1.2, 1.2, 1.2)
					v148.CFrame = v_u_146.CFrame * CFrame.fromEulerAnglesXYZ(0, math.random(-180, 180), 0) * CFrame.new(0, 1, 0)
					v148.Parent = workspace.Effects
					v_u_3:Create(v149, TweenInfo.new(0.25, Enum.EasingStyle.Linear), {
						["Scale"] = Vector3.new(0.3, 0.15, 0.3)
					}):Play()
					v_u_3:Create(v148, TweenInfo.new(0.25, Enum.EasingStyle.Linear), {
						["Position"] = v148.Position + Vector3.new(0, -3.5, 0),
						["Rotation"] = v148.Rotation + Vector3.new(0, 180, 0)
					}):Play()
					v_u_4:AddItem(v148, 0.25)
					task.wait(0.049999999999999996)
				end
			end)
			local v150 = v_u_147.GanonSmoke:Clone()
			v_u_4:AddItem(v150, 0.45)
			v150.CFrame = v_u_146.CFrame * CFrame.new(0, -2.5, 0)
			v150.Parent = workspace.Effects
			v150.Attachment.Smoke.Enabled = true
			task.wait(0.15)
			v150.Attachment.Smoke.Enabled = false
		end
	end,
	["GanonRoar"] = function(p151, _)
		-- upvalues: (copy) v_u_8, (copy) v_u_4, (copy) v_u_44, (copy) v_u_3
		local v152 = p151:FindFirstChild("HumanoidRootPart")
		if v152 then
			local v153 = v_u_8.Misc.Emotes.Ganon
			local v154 = v153.GanonImpact:Clone()
			v154.CFrame = v152.CFrame
			v154.Parent = workspace.Effects
			v154.Attachment.Impact:Emit(1)
			v_u_4:AddItem(v154, 0.25)
			local v155 = ColorSequence.new({
				ColorSequenceKeypoint.new(0, Color3.new(0.921569, 0.380392, 0.560784)),
				ColorSequenceKeypoint.new(0.2, Color3.new(1, 0.756863, 0.27451)),
				ColorSequenceKeypoint.new(0.425, Color3.new(1, 0.756863, 0.27451)),
				ColorSequenceKeypoint.new(0.5, Color3.new(0.352941, 1, 0.458824)),
				ColorSequenceKeypoint.new(0.65, Color3.new(0.352941, 1, 0.458824)),
				ColorSequenceKeypoint.new(0.7, Color3.new(0.921569, 0.380392, 0.560784)),
				ColorSequenceKeypoint.new(1, Color3.new(0.921569, 0.157735, 0.319826))
			})
			local v156 = v153.SpikeyMesh:Clone()
			local v157 = v156.Mesh
			v157.Scale = Vector3.new(0.1, 0.75, 0.1)
			v_u_44:ColorSeqLerpVec(v157, v155, 0.2, 3)
			v156.CFrame = v152.CFrame * CFrame.fromEulerAnglesXYZ(0, math.random(-180, 180), 0) * CFrame.new(0, 2, 0)
			v156.Parent = workspace.Effects
			v_u_3:Create(v157, TweenInfo.new(0.2, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
				["Scale"] = Vector3.new(0.35, 0.15, 0.35)
			}):Play()
			v_u_3:Create(v156, TweenInfo.new(0.2, Enum.EasingStyle.Linear), {
				["Position"] = v156.Position + Vector3.new(0, -5, 0),
				["Rotation"] = v156.Rotation + Vector3.new(0, 180, 0)
			}):Play()
			v_u_4:AddItem(v156, 0.2)
			local v158 = ColorSequence.new({
				ColorSequenceKeypoint.new(0, Color3.new(0.921569, 0.32549, 0.396078)),
				ColorSequenceKeypoint.new(0.4, Color3.new(0.921569, 0.152941, 0.317647)),
				ColorSequenceKeypoint.new(0.55, Color3.new(0.921569, 0.157735, 0.319826)),
				ColorSequenceKeypoint.new(1, Color3.new(1, 0.529412, 0.235294))
			})
			local v159 = v153.SpikeyMesh:Clone()
			local v160 = v159.Mesh
			v160.Scale = Vector3.new(0.15, 0.75, 0.15)
			v_u_44:ColorSeqLerpVec(v160, v158, 0.1, 3)
			v159.CFrame = v152.CFrame * CFrame.fromEulerAnglesXYZ(0, math.random(-180, 180), 0)
			v159.Parent = workspace.Effects
			v_u_3:Create(v160, TweenInfo.new(0.2, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
				["Scale"] = Vector3.new(0.5, 0.25, 0.5)
			}):Play()
			v_u_3:Create(v159, TweenInfo.new(0.2, Enum.EasingStyle.Linear), {
				["Position"] = v159.Position + Vector3.new(0, -2.5, 0),
				["Rotation"] = v159.Rotation + Vector3.new(0, -180, 0)
			}):Play()
			v_u_4:AddItem(v159, 0.2)
			local v161 = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.new(1, 0.462745, 0.25098)), ColorSequenceKeypoint.new(1, Color3.new(1, 0.827451, 0.392157)) })
			local v162 = v153.SpikeyMesh:Clone()
			local v163 = v162.Mesh
			v163.Scale = Vector3.new(0.075, 0.75, 0.075)
			v_u_44:ColorSeqLerpVec(v163, v161, 0.07500000000000001, 1.5)
			v162.CFrame = v152.CFrame * CFrame.fromEulerAnglesXYZ(0, math.random(-180, 180), 0)
			v162.Parent = workspace.Effects
			v_u_3:Create(v163, TweenInfo.new(0.125, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
				["Scale"] = Vector3.new(0.2, 0.75, 0.2)
			}):Play()
			v_u_3:Create(v162, TweenInfo.new(0.125, Enum.EasingStyle.Linear), {
				["Position"] = v162.Position + Vector3.new(0, 2, 0),
				["Rotation"] = v162.Rotation + Vector3.new(0, 90, 0)
			}):Play()
			v_u_4:AddItem(v162, 0.07500000000000001)
			local v164 = ColorSequence.new({
				ColorSequenceKeypoint.new(0, Color3.new(0.921569, 0.380392, 0.560784)),
				ColorSequenceKeypoint.new(0.15, Color3.new(0.921569, 0.380392, 0.560784)),
				ColorSequenceKeypoint.new(0.2, Color3.new(1, 0.756863, 0.27451)),
				ColorSequenceKeypoint.new(0.425, Color3.new(1, 0.756863, 0.27451)),
				ColorSequenceKeypoint.new(0.5, Color3.new(0.352941, 1, 0.458824)),
				ColorSequenceKeypoint.new(0.65, Color3.new(0.352941, 1, 0.458824)),
				ColorSequenceKeypoint.new(0.85, Color3.new(0.168627, 0.862745, 0.952941)),
				ColorSequenceKeypoint.new(1, Color3.new(0.168627, 0.862745, 0.952941))
			})
			local v165 = v153.ShadedSpikeyMesh:Clone()
			local v166 = v165.Mesh
			v166.Scale = Vector3.new(0.075, 1.5, 0.075)
			v_u_44:ColorSeqLerpVec(v166, v164, 0.1, 3)
			v165.CFrame = v152.CFrame * CFrame.fromEulerAnglesXYZ(0, math.random(-180, 180), 0) * CFrame.new(0, 0, 0)
			v165.Parent = workspace.Effects
			v_u_3:Create(v166, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Scale"] = Vector3.new(0.65, 0.5, 0.65)
			}):Play()
			v_u_3:Create(v165, TweenInfo.new(0.1, Enum.EasingStyle.Linear), {
				["Position"] = v165.Position + Vector3.new(0, -0, 0),
				["Rotation"] = v165.Rotation + Vector3.new(0, -270, 0)
			}):Play()
			v_u_4:AddItem(v165, 0.1)
			local v167 = v153.FrontFaceSpikeyMesh:Clone()
			local v168 = v167.Mesh
			v168.Scale = Vector3.new(0.1, 0.3, 0.1)
			v168.VertexColor = Vector3.new(1.2, 1.2, 1.2)
			v167.CFrame = v152.CFrame * CFrame.fromEulerAnglesXYZ(0, math.random(-180, 180), 0) * CFrame.new(0, -1.5, 0)
			v167.Parent = workspace.Effects
			v_u_3:Create(v168, TweenInfo.new(0.1, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
				["Scale"] = Vector3.new(0.55, 0.2, 0.55)
			}):Play()
			v_u_3:Create(v167, TweenInfo.new(0.1, Enum.EasingStyle.Linear), {
				["Position"] = v167.Position + Vector3.new(0, -0, 0),
				["Rotation"] = v167.Rotation + Vector3.new(0, -90, 0)
			}):Play()
			v_u_4:AddItem(v167, 0.1)
		end
	end,
	["MysteryEmote"] = function(p_u_169, p170, p_u_171, p_u_172, p_u_173)
		-- upvalues: (copy) v_u_8, (copy) v_u_43, (copy) v_u_3
		local v_u_174 = p_u_169:FindFirstChild("HumanoidRootPart")
		if v_u_174 then
			local v_u_175 = p_u_169:FindFirstChild("Left Leg")
			local v_u_176 = p_u_169:FindFirstChild("Right Leg")
			local v_u_177 = p_u_169:FindFirstChild("Torso")
			local v_u_178 = TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
			local v_u_179 = TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
			local v_u_180 = v_u_8.Misc.Emotes.Mystery
			local v_u_181 = {}
			p_u_171.AncestryChanged:Once(function()
				-- upvalues: (ref) v_u_43, (copy) v_u_181
				v_u_43(v_u_181)
			end)
			local function v_u_184(p182) -- name: emit
				for _, v183 in p182:QueryDescendants("ParticleEmitter") do
					v183:Emit(v183:GetAttribute("EmitCount"))
				end
			end
			local function v_u_188(p185, p186) -- name: enable
				for _, v_u_187 in p185:QueryDescendants("ParticleEmitter, Trail, Beam") do
					v_u_187.Enabled = true
					task.delay(p186, function()
						-- upvalues: (copy) v_u_187
						v_u_187.Enabled = false
					end)
				end
			end
			local v235 = {
				["Pulse1"] = function()
					-- upvalues: (copy) v_u_180, (copy) v_u_181, (copy) v_u_174, (copy) v_u_184, (copy) p_u_169, (copy) v_u_188
					local v189 = v_u_180.fxPulse1:Clone()
					local v190 = v_u_181
					table.insert(v190, v189)
					v189.Parent = v_u_174
					v_u_184(v189)
					task.delay(1.5, v189.Destroy, v189)
					local v191 = v_u_180.fxBallTrailArm:Clone()
					local v192 = v_u_181
					table.insert(v192, v191)
					v191.Parent = p_u_169:FindFirstChild("Left Arm")
					v_u_188(v191, 0.5)
					task.delay(1, v191.Destroy, v191)
				end,
				["Explode"] = function()
					-- upvalues: (copy) v_u_180, (copy) v_u_181, (copy) v_u_174, (copy) v_u_184
					local v193 = v_u_180.fxExplode:Clone()
					local v194 = v_u_181
					table.insert(v194, v193)
					v193.Parent = v_u_174
					v_u_184(v193)
					task.delay(1, v193.Destroy, v193)
				end,
				["ExplodeEnd"] = function()
					-- upvalues: (copy) v_u_180, (copy) v_u_181, (copy) v_u_174, (copy) v_u_184
					local v195 = v_u_180.fxStupidThing:Clone()
					local v196 = v_u_181
					table.insert(v196, v195)
					v195.Parent = v_u_174
					v_u_184(v195)
					task.delay(1, v195.Destroy, v195)
				end,
				["BallTrippleTrail"] = function()
					-- upvalues: (copy) v_u_180, (copy) v_u_181, (copy) p_u_173, (copy) v_u_188
					local v197 = v_u_180.fxTripTrail:Clone()
					local v198 = v_u_181
					table.insert(v198, v197)
					v197.Parent = p_u_173
					v_u_188(v197, 1)
					task.delay(2, v197.Destroy, v197)
				end,
				["BallTrail"] = function()
					-- upvalues: (copy) v_u_180, (copy) v_u_181, (copy) p_u_173, (copy) v_u_188, (copy) p_u_172
					local v199 = v_u_180.fxTrail:Clone()
					local v200 = v_u_181
					table.insert(v200, v199)
					v199.Parent = p_u_173
					v_u_188(v199, p_u_172)
					task.delay(p_u_172 + 0.5, v199.Destroy, v199)
				end,
				["Leg"] = function()
					-- upvalues: (copy) v_u_180, (copy) v_u_181, (copy) v_u_174, (copy) v_u_184
					local v201 = v_u_180.fxLeg:Clone()
					local v202 = v_u_181
					table.insert(v202, v201)
					v201.Parent = v_u_174
					v_u_184(v201)
					task.delay(1, v201.Destroy, v201)
				end,
				["Spin"] = function()
					-- upvalues: (copy) v_u_180, (copy) v_u_181, (copy) v_u_174, (copy) v_u_188, (copy) p_u_169, (copy) v_u_184
					local v203 = v_u_180.fxSpin:Clone()
					local v204 = v_u_181
					table.insert(v204, v203)
					v203.Parent = v_u_174
					v_u_188(v203, 0.3)
					task.delay(1, v203.Destroy, v203)
					local v205 = v_u_180.fxBallTrailArm:Clone()
					local v206 = v_u_181
					table.insert(v206, v205)
					v205.Parent = p_u_169:FindFirstChild("Left Arm")
					v_u_188(v205, 1)
					task.delay(1.5, v205.Destroy, v205)
					local v207 = v_u_180.fxBallTrailArm:Clone()
					local v208 = v_u_181
					table.insert(v208, v207)
					v207.Parent = p_u_169:FindFirstChild("Right Arm")
					v_u_188(v207, 1)
					task.delay(1.5, v207.Destroy, v207)
					task.wait(0.3)
					local v209 = v_u_180.fxPulse2:Clone()
					local v210 = v_u_181
					table.insert(v210, v209)
					v209.Parent = v_u_174
					v_u_184(v209)
					task.delay(1, v209.Destroy, v209)
				end,
				["Circle1"] = function()
					-- upvalues: (copy) p_u_171, (copy) v_u_180, (copy) v_u_181, (copy) v_u_177, (ref) v_u_3, (copy) v_u_178, (copy) v_u_179, (copy) v_u_175, (copy) v_u_176
					for _ = 1, 2 do
						if not p_u_171.Parent then
							break
						end
						local v_u_211 = v_u_180.Circle:Clone()
						local v212 = v_u_181
						table.insert(v212, v_u_211)
						v_u_211.Size = Vector3.new(3.5, 0.45, 3.5)
						v_u_211.Parent = workspace.Effects
						v_u_211.Transparency = 0
						local v_u_213 = v_u_211.Weld
						v_u_213.Part0 = v_u_177
						v_u_213.Part1 = v_u_211
						v_u_213.C0 = CFrame.new(0, 0.5, 0)
						local v214 = v_u_3:Create(v_u_213, v_u_178, {
							["C0"] = CFrame.new(0, -1.3, 0)
						})
						v214:Play()
						v214.Completed:Once(function()
							-- upvalues: (ref) v_u_3, (copy) v_u_213, (ref) v_u_178, (copy) v_u_211, (ref) v_u_179, (ref) v_u_175, (ref) v_u_176, (ref) v_u_180, (ref) v_u_181
							v_u_3:Create(v_u_213, v_u_178, {
								["C0"] = CFrame.new(0, 1, 0)
							}):Play()
							v_u_3:Create(v_u_211, v_u_179, {
								["Size"] = Vector3.new(4.2, 0, 4.2)
							}):Play()
							task.delay(0.22, v_u_211.Destroy, v_u_211)
							local v215 = {
								{
									["part"] = v_u_175
								},
								{
									["part"] = v_u_176
								}
							}
							for _, v216 in ipairs(v215) do
								local v_u_217 = v_u_180.Circle:Clone()
								local v218 = v_u_181
								table.insert(v218, v_u_217)
								v_u_217.Size = Vector3.new(1.5, 0.35, 1.5)
								v_u_217.Parent = workspace.Effects
								local v_u_219 = v_u_217.Weld
								v_u_219.Part0 = v216.part
								v_u_219.Part1 = v_u_217
								v_u_219.C0 = CFrame.new(0, 1.2, 0)
								local v220 = v_u_3:Create(v_u_219, v_u_178, {
									["C0"] = CFrame.new(0, -0.8, 0)
								})
								local v221 = v_u_3:Create(v_u_217, v_u_178, {
									["Size"] = Vector3.new(2.2, 0.1, 2.2),
									["Transparency"] = 0
								})
								v220:Play()
								v221:Play()
								v220.Completed:Once(function()
									-- upvalues: (ref) v_u_3, (copy) v_u_219, (ref) v_u_178, (copy) v_u_217, (ref) v_u_179
									v_u_3:Create(v_u_219, v_u_178, {
										["C0"] = CFrame.new(0, 1.2, 0)
									}):Play()
									local v222 = v_u_3:Create(v_u_217, v_u_179, {
										["Size"] = Vector3.new(3.1, 0, 3.1),
										["Transparency"] = 1
									})
									v222:Play()
									v222.Completed:Once(function()
										-- upvalues: (ref) v_u_217
										v_u_217:Destroy()
									end)
								end)
							end
						end)
						task.wait(0.35)
					end
				end,
				["Circle2"] = function()
					-- upvalues: (copy) v_u_180, (copy) v_u_181, (copy) v_u_176, (ref) v_u_3, (copy) v_u_178, (copy) v_u_179, (copy) v_u_177, (copy) v_u_175
					local v223 = v_u_180.Circle:Clone()
					local v224 = v_u_181
					table.insert(v224, v223)
					v223.Size = Vector3.new(2, 0.45, 2)
					v223.Parent = workspace.Effects
					v223.Transparency = 0
					local v225 = v223.Weld
					v225.Part0 = v_u_176
					v225.Part1 = v223
					v225.C0 = CFrame.new(0, -1.2, 0)
					local v226 = v_u_3:Create(v225, v_u_178, {
						["C0"] = CFrame.new(0, 1.2, 0)
					})
					v226:Play()
					v_u_3:Create(v223, v_u_179, {
						["Size"] = Vector3.new(2.5, 0, 2.5)
					}):Play()
					task.delay(0.15, v223.Destroy, v223)
					v226.Completed:Once(function()
						-- upvalues: (ref) v_u_180, (ref) v_u_181, (ref) v_u_177, (ref) v_u_3, (ref) v_u_178, (ref) v_u_179, (ref) v_u_175
						local v_u_227 = v_u_180.Circle:Clone()
						local v228 = v_u_181
						table.insert(v228, v_u_227)
						v_u_227.Size = Vector3.new(3.5, 0.45, 3.5)
						v_u_227.Parent = workspace.Effects
						v_u_227.Transparency = 0
						local v_u_229 = v_u_227.Weld
						v_u_229.Part0 = v_u_177
						v_u_229.Part1 = v_u_227
						v_u_229.C0 = CFrame.new(0, -1, 0)
						local v230 = v_u_3:Create(v_u_229, v_u_178, {
							["C0"] = CFrame.new(0, 1, 0)
						})
						v230:Play()
						v230.Completed:Once(function()
							-- upvalues: (ref) v_u_3, (copy) v_u_229, (ref) v_u_178, (copy) v_u_227, (ref) v_u_179, (ref) v_u_180, (ref) v_u_181, (ref) v_u_175
							local v231 = v_u_3:Create(v_u_229, v_u_178, {
								["C0"] = CFrame.new(0, -1, 0)
							})
							v_u_3:Create(v_u_227, v_u_179, {
								["Size"] = Vector3.new(2.7, 0, 2.7)
							}):Play()
							v231:Play()
							v231.Completed:Once(function()
								-- upvalues: (ref) v_u_227, (ref) v_u_180, (ref) v_u_181, (ref) v_u_175, (ref) v_u_3, (ref) v_u_179, (ref) v_u_178
								v_u_227:Destroy()
								local v232 = v_u_180.Circle:Clone()
								local v233 = v_u_181
								table.insert(v233, v232)
								v232.Size = Vector3.new(2.5, 0.45, 2.5)
								v232.Parent = workspace.Effects
								v232.Transparency = 0
								local v234 = v232.Weld
								v234.Part0 = v_u_175
								v234.Part1 = v232
								v234.C0 = CFrame.new(0, 1, 0)
								v_u_3:Create(v232, v_u_179, {
									["Size"] = Vector3.new(2, 0, 2),
									["Transparency"] = 1
								}):Play()
								v_u_3:Create(v234, v_u_178, {
									["C0"] = CFrame.new(0, -1, 0)
								}):Play()
								task.delay(1, v232.Destroy, v232)
							end)
						end)
					end)
				end
			}
			if v235[p170] then
				v235[p170]()
			end
		end
	end,
	["TeleportEffect"] = function(p_u_236)
		-- upvalues: (copy) v_u_8, (copy) v_u_15, (copy) v_u_4, (copy) v_u_44, (copy) v_u_2, (copy) v_u_6, (copy) v_u_11, (copy) v_u_7, (copy) v_u_3, (copy) v_u_16, (copy) v_u_5
		local v_u_237 = v_u_8.Gojo.Teleport:Clone()
		v_u_237.CFrame = p_u_236.HumanoidRootPart.CFrame
		v_u_237.Parent = v_u_15
		v_u_4:AddItem(v_u_237, 1.1)
		v_u_237.Center.Flash:Emit(1)
		v_u_44:PlaySound(v_u_2.Sounds.Gojo.Teleport2, p_u_236.HumanoidRootPart, v_u_6.Effect)
		task.delay(0.1, function()
			-- upvalues: (copy) v_u_237, (copy) p_u_236
			v_u_237.Floor.Dust:Emit(30)
			task.wait(0.05)
			v_u_237.CFrame = p_u_236.HumanoidRootPart.CFrame
			v_u_237.Lines:Emit(30)
			v_u_237.Floor.Dust:Emit(30)
		end)
		v_u_11.CurrentShaker:Shake(v_u_11.Presets.LightHit)
		v_u_44:PlaySound(v_u_2.Sounds.Gojo.Teleport, p_u_236.HumanoidRootPart, v_u_6.Effect)
		if v_u_7.Character and v_u_7.Character == p_u_236 then
			local v238 = v_u_8.Gojo.TeleportBreak:Clone()
			v238.Parent = v_u_15
			v_u_4:AddItem(v238, 0.8)
			local v239 = Instance.new("Highlight")
			v239.OutlineTransparency = 1
			v239.FillColor = Color3.new(1, 1, 1)
			v239.FillTransparency = 0.8
			v239.Parent = v238
			for _ = 1, 30 do
				local v240 = v_u_8.Gojo.Shard:Clone()
				v240.CFrame = v238.Part.CFrame * CFrame.new(math.random(-40, 40) / 10, math.random(-20, 20) / 10, 0)
				v240.CFrame = v240.CFrame * CFrame.Angles(math.random(0, 360), math.random(0, 360), math.random(0, 360))
				v240.Parent = v238.Shards
				local v241 = v_u_3:Create(v240, TweenInfo.new(math.random(4, 7) / 10), {
					["Size"] = Vector3.new(0, 0, 0)
				})
				v241:Play()
				v241:Destroy()
				local v242 = v238.Part.CFrame * CFrame.Angles(math.random(0, 30), math.random(-30, 30), 0)
				local v243 = math.random(-5, 5)
				local v244 = math.random(-5, 5)
				local v245 = math.random
				v240.RotVelocity = vector.create(v243, v244, v245(-5, 5))
				local v246 = Instance.new("BodyVelocity")
				v246.Archivable = false
				v246.Velocity = v242.LookVector * math.random(1, 80) / 10
				v246.Parent = v240
			end
			v238:SetPrimaryPartCFrame(v_u_16.CFrame * CFrame.new(0, 0, -2))
			for _, v247 in v238.Shards:GetChildren() do
				local v248 = v247.BodyVelocity
				v248.Velocity = v248.Velocity - Vector3.new(0, 0.25, 0)
			end
			v_u_5.RenderStepped:Wait()
			if v238.Parent then
				break
			end
		end
	end,
	["ChestBump"] = function(p249, p250, p251)
		-- upvalues: (copy) v_u_8, (copy) v_u_3, (copy) v_u_4, (copy) v_u_1, (copy) v_u_11
		local v252 = p249:FindFirstChild("HumanoidRootPart")
		if v252 then
			local v253 = math.random(80, 120) / 10
			local v254 = v_u_8.Gojo.LapseBlue.Throw:Clone()
			v254.Transparency = 0.7
			v254.CFrame = v252.CFrame * CFrame.new(0, 0, -1)
			v254.Size = Vector3.new(0, 0, 5)
			v254.Parent = workspace.Effects
			v_u_3:Create(v254, TweenInfo.new(0.1, Enum.EasingStyle.Quad), {
				["Size"] = nil,
				["Transparency"] = 1,
				["Size"] = Vector3.new(v253, v253, 0)
			}):Play()
			v_u_4:AddItem(v254, 0.1)
			if p250 and p251 then
				local v255 = math.random(170, 220) / 10
				local v256 = v_u_8.Gojo.LapseBlue.Throw:Clone()
				v256.Transparency = 0.7
				v256.CFrame = CFrame.new(p250, p250 + p251)
				v256.Size = Vector3.new(0, 0, 7)
				v256.Parent = workspace.Effects
				v_u_3:Create(v256, TweenInfo.new(0.25, Enum.EasingStyle.Quad), {
					["Size"] = nil,
					["Transparency"] = 1,
					["Size"] = Vector3.new(v255, v255, 0)
				}):Play()
				v_u_4:AddItem(v256, 0.25)
				if (workspace.CurrentCamera.CFrame.Position - p250).Magnitude < 50 or v_u_1.LocalPlayer.Character == p249 then
					v_u_11.CurrentShaker:Shake(v_u_11.Presets.Snap)
				end
			end
		end
	end,
	["BangWhoosh"] = function(p257)
		-- upvalues: (copy) v_u_8, (copy) v_u_3, (copy) v_u_4
		local v258 = p257:FindFirstChild("HumanoidRootPart")
		if v258 then
			local v259 = v_u_8.Itadori.DivergentFist.BlackFlashLaunch:Clone()
			v259.CFrame = v258.CFrame * CFrame.new(-0.5, 1, -5)
			v259.Parent = workspace.Effects
			v259.Wind:Emit(20)
			v259.PointLight:Destroy()
			v259.Back1.Back:Emit(1)
			v259.Back2.Back:Emit(1)
			v_u_3:Create(v259.Back1, TweenInfo.new(2), {
				["CFrame"] = v259.Back1.CFrame - v259.Back1.CFrame.LookVector * 20
			}):Play()
			v_u_3:Create(v259.Back2, TweenInfo.new(2), {
				["CFrame"] = v259.Back2.CFrame - v259.Back2.CFrame.LookVector * 20
			}):Play()
			v_u_4:AddItem(v259, 3)
			local v260 = v_u_8.Choso.CounterSwing.Shock:Clone()
			v260.Size = Vector3.new(6, 30, 6)
			v260.CFrame = v258.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
			v260.Parent = workspace.Effects
			v_u_4:AddItem(v260, 0.2)
			v_u_3:Create(v260, TweenInfo.new(0.2), {
				["Size"] = Vector3.new(25, 0, 25),
				["Transparency"] = 1,
				["Position"] = nil,
				["Position"] = v260.Position + v258.CFrame.LookVector * 10
			}):Play()
		end
	end,
	["Kaboom"] = function(p261)
		-- upvalues: (copy) v_u_44, (copy) v_u_2, (copy) v_u_6, (copy) v_u_11, (copy) v_u_12, (copy) v_u_8
		local v262 = p261:FindFirstChild("HumanoidRootPart")
		if v262 then
			v_u_44:PlaySound(v_u_2.Sounds.Impact.Players.MostExplodeSoundEverToGoWithMostGoreSoundEver, v262, v_u_6.Effect)
			v_u_44:PlaySound(v_u_2.Sounds.Impact.Players.MostGoreSoundEver, v262, v_u_6.Effect)
			if (workspace.CurrentCamera.CFrame.Position - v262.Position).Magnitude < 50 then
				v_u_11.CurrentShaker:Shake(v_u_11.Presets.SnapOh)
			end
			v_u_44:Bleed(p261)
			for _ = 1, 40 do
				v_u_12:Blood(p261.Torso.CFrame, 50, 360, 360)
			end
			if _G.Settings.Gore then
				local v263 = v_u_8.Heian.BloodSpread:Clone()
				v263.Parent = v262
				v263:Emit(80)
				game:GetService("Debris"):AddItem(v263, 2)
			end
			if _G.Settings.DesPHY then
				if (workspace.CurrentCamera.CFrame.Position - v262.Position).Magnitude > 150 then
					return
				end
				local v264 = {}
				for _, v265 in p261:GetChildren() do
					if not v265:IsA("BasePart") or (v265 == v262 or v265.Transparency == 1) then
						continue
					end
					local v266 = v265.Color
					table.insert(v264, v266)
				end
				Random.new()
				TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
				for _ = 1, 35 do
					local v267 = math.random(50, 200) / 100
					local v268 = v264[math.random(1, #v264)]
					local v_u_269 = v_u_8.Hiromi.GavelShard:Clone()
					v_u_269.CollisionGroup = "Effects"
					v_u_269.Position = v262.Position
					v_u_269.Size = Vector3.new(v267, 0.1, v267)
					local v270 = math.random(-90, 90)
					local v271 = math.random(-30, 90)
					local v272 = math.random
					v_u_269.Velocity = Vector3.new(v270, v271, v272(-90, 90))
					local v273 = math.random(-120, 120)
					local v274 = math.random(-120, 120)
					local v275 = math.random
					v_u_269.RotVelocity = Vector3.new(v273, v274, v275(-120, 120))
					v_u_269.Color = v268
					v_u_269.Parent = workspace.Effects
					game:GetService("Debris"):AddItem(v_u_269, 5)
					task.delay(4, function()
						-- upvalues: (copy) v_u_269
						game:GetService("TweenService"):Create(v_u_269, TweenInfo.new(1), {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
					end)
				end
			end
		end
	end,
	["WalkAroundIt"] = function(p276, p277)
		-- upvalues: (copy) v_u_3
		local v278 = Instance.new("Highlight")
		v278.Parent = p277
		v278.Adornee = p276
		v278.DepthMode = Enum.HighlightDepthMode.Occluded
		v278.FillTransparency = 1
		v278.FillColor = Color3.fromRGB(255, 255, 255)
		v278.OutlineTransparency = 1
		v278.OutlineColor = Color3.fromRGB(0, 0, 0)
		v_u_3:Create(v278, TweenInfo.new(0.15), {
			["FillTransparency"] = 0,
			["OutlineTransparency"] = 0.2
		}):Play()
		task.wait(0.15)
		v_u_3:Create(v278, TweenInfo.new(0.1), {
			["FillTransparency"] = 1,
			["OutlineTransparency"] = 1
		}):Play()
	end,
	["DiamondSlide"] = function(p279, p280)
		-- upvalues: (copy) v_u_44
		v_u_44:DustTrail(p279, 0.75, CFrame.Angles(0, -1.5707963267948966, 0))
		if p280 ~= nil then
			v_u_44:DustTrail(p280, 0.75, CFrame.Angles(0, -1.5707963267948966, 0))
		end
	end,
	["AuraMonster"] = function(p281, p282)
		-- upvalues: (copy) v_u_8, (copy) v_u_44
		local v283 = v_u_8.Misc.Emotes.AuraMonster.AuraMonsterUI:Clone()
		v283.SurfaceGui.Adornee = p282
		v283.SurfaceGui.ViewportFrame.CurrentCamera = v283.SurfaceGui.ViewportFrame:FindFirstChildOfClass("Camera")
		v_u_44:ApplyCopyOutfit(p281, v283.SurfaceGui.ViewportFrame.WorldModel)
		v283.Parent = game.Players.LocalPlayer.PlayerGui
		local v284 = nil
		for _, v285 in pairs(p281.Humanoid:GetPlayingAnimationTracks()) do
			if v285.Animation.AnimationId ~= "rbxassetid://89623084168746" then
				continue
			end
			v284 = v285
		end
		if v284 then
			local v286 = Instance.new("Animation")
			v286.AnimationId = "rbxassetid://74622996549158"
			local v287 = v283.SurfaceGui.ViewportFrame.WorldModel.Humanoid:LoadAnimation(v286)
			v287:Play()
			v287.TimePosition = v284.TimePosition
			v286:Destroy()
			task.wait()
			if v287.TimePosition ~= v284.TimePosition then
				v287.TimePosition = v284.TimePosition
			end
			if p282.Parent ~= nil and v284.IsPlaying ~= false then
				continue
			end
			v283:Destroy()
		else
			v283:Destroy()
		end
	end
}
return v_u_46