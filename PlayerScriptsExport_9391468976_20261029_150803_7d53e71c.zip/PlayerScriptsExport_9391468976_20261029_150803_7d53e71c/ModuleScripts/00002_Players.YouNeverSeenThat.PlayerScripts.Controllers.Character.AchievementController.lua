-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Character.AchievementController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local _ = v_u_5.Utils
local v_u_6 = v_u_5.Sounds
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = v_u_1.CreateController({
	["Name"] = "AchievementController"
})
local v_u_10 = require(v_u_5.Modules.Icon)
v_u_9.TotalAchievements = 0
function v_u_9.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_4, (ref) v_u_8, (copy) v_u_6, (copy) v_u_5, (copy) v_u_9, (ref) v_u_7, (copy) v_u_2, (copy) v_u_3, (copy) v_u_10
	local v_u_11 = v_u_4.PlayerGui:WaitForChild("Menus")
	local v_u_12 = v_u_11.Group.Achievements
	v_u_12:SetAttribute("Loaded", true)
	local function v_u_17(p13, p14) -- name: selecta
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (copy) v_u_12
		if not p14 then
			v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
			v_u_8:PlaySound(v_u_6.Misc.UI.Switch, workspace, game.SoundService.Effect)
		end
		for _, v15 in v_u_12.Items:GetChildren() do
			if not (v15:IsA("TextButton") or v15:IsA("Frame")) then
				continue
			end
			if v15 == p13 then
				v15.BackgroundTransparency = 0.5
			else
				v15.BackgroundTransparency = 1
			end
		end
		for _, v16 in v_u_12.Description:GetChildren() do
			if not (v16:IsA("ScrollingFrame") or v16:IsA("Frame")) then
				continue
			end
			if v16.Name == p13.Name then
				v16.Visible = true
			else
				v16.Visible = false
			end
		end
	end
	local v_u_18 = false
	v_u_12:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (copy) v_u_12, (ref) v_u_18, (ref) v_u_5, (ref) v_u_9, (copy) v_u_11, (copy) v_u_17
		if v_u_12.Visible then
			if v_u_18 ~= true then
				v_u_18 = true
				local v19, v20 = v_u_5.Remotes.Achievements:InvokeServer()
				local v21 = 0
				if v_u_9.TotalAchievements == 0 then
					for v22, v23 in v19 do
						if v23[1] == "Daily" or v23[1] == "Weekly" then
							local v_u_24 = v_u_11.Preset.QuestButton:Clone()
							v_u_24.Name = v23[1]
							v_u_24.LayoutOrder = v22
							v_u_24.ItemBox.Text = v23[1]
							v_u_24.Parent = v_u_12.Items
							v_u_24.ItemBox.MouseButton1Down:Connect(function()
								-- upvalues: (ref) v_u_17, (copy) v_u_24
								v_u_17(v_u_24)
							end)
						else
							local v_u_25 = v_u_11.Preset.ItemBox:Clone()
							v_u_25.Name = v23[1]
							v_u_25.LayoutOrder = v22
							v_u_25.Text = v23[1]
							v_u_25.Parent = v_u_12.Items
							v_u_25.MouseButton1Down:Connect(function()
								-- upvalues: (ref) v_u_17, (copy) v_u_25
								v_u_17(v_u_25)
							end)
							if #v23[2] <= 0 then
								v_u_25:Destroy()
							else
								local v26 = v_u_11.Preset.AchievementList:Clone()
								v26.Name = v23[1]
								v26.Parent = v_u_12.Description
								if v22 == 1 then
									v_u_17(v_u_25)
								end
								for _, v27 in v23[2] do
									local v28 = v_u_11.Preset.Achievement:Clone()
									v28.Name = v27[1]
									v28.Title.Text = v27[1]
									v28.Description.Text = v27[2]
									v28.Background.Image = "rbxassetid://" .. v27[3]
									v28.Progress.Bar.Size = UDim2.new((v20[v27[1]] or 0) / v27[4], 0, 1, 0)
									if v28.Progress.Bar.Size.X.Scale >= 1 then
										v28.Progress.Bar.BackgroundColor3 = Color3.new(0, 1, 0)
										v21 = v21 + 1
									end
									v28.Parent = v26
									local v29 = v_u_9
									v29.TotalAchievements = v29.TotalAchievements + 1
								end
							end
						end
					end
				else
					for _, v30 in v19 do
						for _, v31 in v30[2] do
							if not v20[v31[1]] or v20[v31[1]] < v31[4] then
								continue
							end
							v21 = v21 + 1
						end
					end
				end
				v_u_12.Progress.Bar.Size = UDim2.new(v21 / v_u_9.TotalAchievements, 0, 1, 0)
				local v32 = v_u_12.TextLabel
				local v33 = v21 / v_u_9.TotalAchievements * 100
				v32.Text = "Total Progress: " .. math.ceil(v33) .. "%"
				v_u_12.Loading.Visible = false
				v_u_17(v_u_12.Items.Daily, true)
				v_u_18 = false
			end
		else
			return
		end
	end)
	local v_u_34 = {}
	v_u_7.Update:Connect(function(p_u_35, p36, p37, p_u_38)
		-- upvalues: (copy) v_u_34, (copy) v_u_11, (ref) v_u_2, (ref) v_u_8, (ref) v_u_6, (ref) v_u_3, (copy) v_u_12
		if p37 <= p36 then
			task.spawn(function()
				-- upvalues: (ref) v_u_34, (copy) p_u_35, (copy) p_u_38, (ref) v_u_11, (ref) v_u_2, (ref) v_u_8, (ref) v_u_6, (ref) v_u_3
				local v39 = v_u_34
				local v40 = { p_u_35, p_u_38 }
				table.insert(v39, v40)
				if #v_u_34 == 1 then
					local v_u_41 = v_u_11.Preset.AchieveNotif:Clone()
					v_u_41.BG.Title.Text = v_u_34[1][1]
					v_u_41.BG.Background.Image = "rbxassetid://" .. v_u_34[1][2]
					v_u_41.Parent = v_u_11
					v_u_2:AddItem(v_u_41, 7)
					v_u_8:PlaySound(v_u_6.Misc.UI.Achievement, workspace, game.SoundService.Effect)
					v_u_3:Create(v_u_41.Flash, TweenInfo.new(2, Enum.EasingStyle.Exponential), {
						["Size"] = nil,
						["BackgroundTransparency"] = 1,
						["Size"] = UDim2.new(1, 64, 1, 64)
					}):Play()
					task.spawn(function()
						-- upvalues: (copy) v_u_41
						local v42 = v_u_41.Position
						v_u_41.Position = v42 + UDim2.new(0, 15, 0, -3)
						task.wait(0.02)
						v_u_41.Position = v42 + UDim2.new(0, -15, 0, 0)
						task.wait(0.02)
						v_u_41.Position = v42 + UDim2.new(0, 12, 0, 3)
						task.wait(0.02)
						v_u_41.Position = v42 + UDim2.new(0, -12, 0, 0)
						task.wait(0.03)
						v_u_41.Position = v42 + UDim2.new(0, 10, 0, -2)
						task.wait(0.03)
						v_u_41.Position = v42 + UDim2.new(0, -10, 0, 0)
						task.wait(0.03)
						v_u_41.Position = v42 + UDim2.new(0, 8, 0, 2)
						task.wait(0.04)
						v_u_41.Position = v42 + UDim2.new(0, -8, 0, 0)
						task.wait(0.04)
						v_u_41.Position = v42 + UDim2.new(0, 6, 0, -1)
						task.wait(0.04)
						v_u_41.Position = v42 + UDim2.new(0, -6, 0, 0)
						task.wait(0.05)
						v_u_41.Position = v42 + UDim2.new(0, 4, 0, 1)
						task.wait(0.05)
						v_u_41.Position = v42 + UDim2.new(0, -4, 0, 0)
						task.wait(0.05)
						v_u_41.Position = v42 + UDim2.new(0, 2, 0, 0)
						task.wait(0.05)
						v_u_41.Position = v42 + UDim2.new(0, -2, 0, 0)
						task.wait(0.05)
						v_u_41.Position = v42
					end)
					task.wait(6)
					if #v_u_34 == 1 then
						v_u_3:Create(v_u_41, TweenInfo.new(1), {
							["BackgroundTransparency"] = 1
						}):Play()
						v_u_3:Create(v_u_41.BG.Background, TweenInfo.new(1), {
							["ImageTransparency"] = 1
						}):Play()
						v_u_3:Create(v_u_41.BG.New, TweenInfo.new(1), {
							["TextTransparency"] = 1
						}):Play()
						v_u_3:Create(v_u_41.BG.Title, TweenInfo.new(1), {
							["TextTransparency"] = 1
						}):Play()
						task.wait(1)
						table.remove(v_u_34, 1)
					else
						v_u_41:Destroy()
						table.remove(v_u_34, 1)
					end
					if #v_u_34 > 0 then
						continue
					end
				end
			end)
		end
		local v43 = v_u_12.Description:FindFirstChild(p_u_35, true)
		if v43 then
			local _ = (p36 or 0) / p37
			v43.Progress.Bar.Size = UDim2.new((p36 or 0) / p37, 0, 1, 0)
			if v43.Progress.Bar.Size.X.Scale >= 1 then
				v43.Progress.Bar.BackgroundColor3 = Color3.new(0, 1, 0)
			end
		end
	end)
	local function v_u_59(p44, p45) -- name: formatTimeLeft
		if p45 <= 0 then
			return "Refreshing soon"
		end
		local v46
		if p44 == "Weekly" then
			local v47 = p45 / 86400
			local v48 = math.floor(v47)
			local v49 = p45 % 86400 / 3600
			local v50 = math.floor(v49)
			local v51 = p45 % 3600 / 60
			local v52 = math.floor(v51)
			local v53 = p45 % 60
			v46 = v48 .. "d " .. v50 .. "h " .. v52 .. "m " .. math.floor(v53) .. "s"
		else
			local v54 = p45 / 3600
			local v55 = math.floor(v54)
			local v56 = p45 % 3600 / 60
			local v57 = math.floor(v56)
			local v58 = p45 % 60
			v46 = v55 .. "h " .. v57 .. "m " .. math.floor(v58) .. "s"
		end
		return "Refreshes in: " .. v46
	end
	local function v_u_65(p60, p61, p62) -- name: UpdateFrame
		if p61.ID then
			p60.Background.Image = "rbxassetid://" .. p61.ID
		end
		if p61.Finished then
			p60.Complete.Visible = true
			p60.Purchase.Visible = false
			p60.Progress.Bar.Size = UDim2.new(1, 0, 1, 0)
			p60.Progress.Bar.BackgroundColor3 = Color3.new(0, 1, 0)
			local v63 = p61.Progress
			if type(v63) == "boolean" then
				p60.Left.Visible = false
			else
				p60.Left.Text = ("%d/%d"):format(p61.Progress, p61.Requirement)
			end
		else
			local v64 = p61.Progress
			if type(v64) == "boolean" then
				p60.Progress.Bar.Size = UDim2.new(p61.Progress and 1 or 0, 0, 1, 0)
				p60.Left.Visible = false
				if p61.Progress then
					p60.Purchase.Cash.Text = ("CLAIM %d$"):format(p62 == "Daily" and 15 or 100)
					p60.Purchase.Visible = true
					p60.Progress.Bar.BackgroundColor3 = Color3.new(0, 1, 0)
				else
					p60.Purchase.Visible = false
					p60.Progress.Bar.BackgroundColor3 = Color3.fromRGB(85, 170, 255)
				end
			else
				p60.Progress.Bar.Size = UDim2.new(p61.Progress / p61.Requirement, 0, 1, 0)
				p60.Left.Text = ("%d/%d"):format(p61.Progress, p61.Requirement)
				if p61.Progress >= p61.Requirement then
					p60.Purchase.Cash.Text = ("CLAIM %d$"):format(p62 == "Daily" and 15 or 100)
					p60.Purchase.Visible = true
					p60.Progress.Bar.BackgroundColor3 = Color3.new(0, 1, 0)
				else
					p60.Purchase.Visible = false
					p60.Progress.Bar.BackgroundColor3 = Color3.fromRGB(85, 170, 255)
				end
			end
		end
	end
	local v_u_66 = v_u_12.Description.Daily.Daily
	local v_u_67 = v_u_12.Description.Weekly.Weekly
	local v_u_68 = nil
	local function v_u_81(p_u_69, p70, p71, p72) -- name: UpdateQuests
		-- upvalues: (ref) v_u_68, (ref) v_u_10, (copy) v_u_11, (ref) v_u_8, (ref) v_u_6, (ref) v_u_7, (copy) v_u_65, (copy) v_u_59, (copy) v_u_66
		if p70 == "SET" then
			if not v_u_68 then
				v_u_68 = v_u_10.getIcon("Achievement")
			end
			local v73 = next
			local v74, v75 = p_u_69:GetChildren()
			for _, v76 in v73, v74, v75 do
				if not v76:IsA("Frame") then
					continue
				end
				v76:Destroy()
			end
			local v77 = 0
			for _, v_u_78 in next, p71 do
				if type(v_u_78) ~= "table" then
					continue
				end
				local v79 = v_u_11.Preset.Daily:Clone()
				v79.Name = v_u_78.Tag
				v79.Description.Text = v_u_78.Description
				v79.Purchase.Cash.MouseButton1Down:Connect(function()
					-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_7, (copy) p_u_69, (copy) v_u_78
					v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
					v_u_7[p_u_69.Name]:Fire(v_u_78.Name)
				end)
				if v_u_78.Finished then
					v77 = v77 + 1
				end
				v_u_65(v79, v_u_78, p_u_69.Name)
				v79.Parent = p_u_69
			end
			if v77 < 3 and v_u_68 then
				v_u_68:notify(v_u_68.deselected)
			end
			p_u_69.Parent.Timer.Text = v_u_59(p_u_69.Name, p71.ExpireDate - p72)
			return
		elseif p70 == "UPDATE" then
			local v80 = p_u_69:FindFirstChild(p71)
			if not v80 then
				return print(("Failed to find %s under %s frame"):format(p_u_69.Name, p71))
			end
			v_u_65(v80, p72, p_u_69.Name)
		elseif p70 == "TIMER" then
			v_u_66.Parent.Timer.Text = v_u_59(p_u_69.Name, p71 - p72)
		end
	end
	v_u_7.Daily:Connect(function(...)
		-- upvalues: (copy) v_u_81, (copy) v_u_66
		v_u_81(v_u_66, ...)
	end)
	v_u_7.Weekly:Connect(function(...)
		-- upvalues: (copy) v_u_81, (copy) v_u_67
		v_u_81(v_u_67, ...)
	end)
end
function v_u_9.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (ref) v_u_8
	v_u_7 = v_u_1.GetService("AchievementService")
	v_u_8 = v_u_1.GetController("FXController")
end
return v_u_9