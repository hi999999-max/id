-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Reggie.Base.HomerunController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "HomerunController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_2, (copy) v_u_5, (copy) v_u_9, (copy) v_u_4, (ref) v_u_10
	local v_u_42 = {
		["Start"] = function(p14)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_12:PlaySound(v_u_8.Reggie.Homerun.Start, v15, game.SoundService.Effect)
			end
		end,
		["Interp"] = function(p16, p_u_17)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_2, (ref) v_u_5, (ref) v_u_9
			local v18 = p16:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = v_u_7.Itadori.DivergentFist.BlackFlashLaunch:Clone()
				local v20 = Instance.new("Model")
				v19.Parent = v20
				v20:ScaleTo(0.85)
				v_u_3:AddItem(v20, 0.1)
				v19.CFrame = p_u_17.CFrame
				v19.Parent = workspace.Effects
				v19.Wind:Emit(2)
				v19.PointLight:Destroy()
				v19.Wind.Lifetime = NumberRange.new(0.25, 0.8)
				v19.Back1.Back.Size = NumberSequence.new(0)
				v19.Back2.Back.Size = NumberSequence.new(0)
				v_u_3:AddItem(v19, 3)
				v_u_12:PlaySound(v_u_8.Reggie.Homerun.BallLaunch2, v18, game.SoundService.Effect)
				local v_u_21 = p_u_17.CFrame
				local v_u_22 = tick()
				local v_u_23 = p_u_17:GetPropertyChangedSignal("Position"):Connect(function()
					-- upvalues: (ref) v_u_21, (copy) p_u_17, (ref) v_u_22
					v_u_21 = p_u_17.CFrame
					v_u_22 = tick()
				end)
				local v_u_25 = p_u_17:GetAttributeChangedSignal("Boosted"):Connect(function()
					-- upvalues: (ref) v_u_7, (copy) p_u_17, (ref) v_u_12, (ref) v_u_8
					local v24 = v_u_7.Reggie.Boost:Clone()
					v24.Parent = p_u_17
					v24.Wind2.Parent = p_u_17
					v_u_12:PlaySound(v_u_8.Reggie.Homerun.BallFire, p_u_17, game.SoundService.Effect)
					repeat
						v24.CFrame = v_u_7.Reggie.Boost.CFrame * CFrame.Angles(0, 0, math.random(0, 3.141592653589793))
						task.wait()
					until not v24.Parent
				end)
				local v_u_26 = nil
				v_u_26 = v_u_2.Stepped:Connect(function()
					-- upvalues: (copy) p_u_17, (ref) v_u_26, (copy) v_u_23, (copy) v_u_25, (ref) v_u_21, (ref) v_u_22
					if p_u_17.Parent == workspace.Bullets then
						if p_u_17.Parent then
							workspace:BulkMoveTo({ p_u_17 }, { v_u_21 + v_u_21.LookVector * (p_u_17:GetAttribute("Speed") * (tick() - v_u_22)) }, Enum.BulkMoveMode.FireCFrameChanged)
						else
							v_u_26:Disconnect()
							v_u_23:Disconnect()
							v_u_25:Disconnect()
						end
					else
						return
					end
				end)
				if v_u_5.Character == p16 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["HitBall"] = function(p27)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v28 = p27:FindFirstChild("HumanoidRootPart")
			if v28 then
				v_u_12:PlaySound(v_u_8.Reggie.Homerun.BallLaunch1, v28, game.SoundService.Effect)
				if v_u_5.Character == p27 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end,
		["Hit"] = function(p29, p30, p31)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v32 = p29:FindFirstChild("HumanoidRootPart")
			if v32 then
				local v33 = p30:FindFirstChild("HumanoidRootPart")
				if v33 then
					local v34 = v_u_7.Mahito.CrushingRushdown.DrillImpact:Clone()
					v34.Position = v33.Position
					v34.Parent = workspace.Effects
					v_u_3:AddItem(v34, 1)
					v34.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 1))
					v34.Wind.Color = v34.Sparks.Color
					v34.Wind2.Color = v34.Sparks.Color
					v34.Sparks:Emit(30)
					v34.Wind2:Emit(7)
					for _, v35 in v34:GetDescendants() do
						if not v35:IsA("ParticleEmitter") then
							continue
						end
						if p31 then
							v35.Color = ColorSequence.new(Color3.fromRGB(255, 100, 100))
						end
						v35.TimeScale = 0.05
						v_u_4:Create(v35, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
							["TimeScale"] = 1
						}):Play()
					end
					v_u_12:Flash(p29, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Hakari.EnergySurge.Hit1, v32, game.SoundService.Effect)
					if v_u_5.Character == p30 or v_u_5.Character == p29 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["Hit2"] = function(p36, p37)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v38 = p37:FindFirstChild("HumanoidRootPart")
			if v38 then
				v_u_12:Flash(p37, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Reggie.Homerun.BallHit, v38, game.SoundService.Effect)
				if v_u_5.Character == p37 or v_u_5.Character == p36 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.SnapOh)
				end
			end
		end,
		["CollidedBall"] = function(p39, p40)
			-- upvalues: (ref) v_u_3
			local v41 = p39:Clone()
			if v41:FindFirstChild("Boost") then
				v41.Boost:Destroy()
				v41.Wind2:Destroy()
			end
			v41.Parent = workspace.Effects
			v41.CollisionGroup = "NoPlayerCollision"
			v41.CanCollide = true
			v41.Anchored = false
			v41.AssemblyLinearVelocity = p40 and -p39.CFrame.LookVector * 40 + Vector3.new(0, 15, 0) or p39.CFrame.LookVector * 40
			v_u_3:AddItem(v41, 2)
		end
	}
	v_u_10.Effects:Connect(function(p43, ...)
		-- upvalues: (copy) v_u_42
		local v44 = v_u_42[p43]
		if v44 then
			v44(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("HomerunService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13