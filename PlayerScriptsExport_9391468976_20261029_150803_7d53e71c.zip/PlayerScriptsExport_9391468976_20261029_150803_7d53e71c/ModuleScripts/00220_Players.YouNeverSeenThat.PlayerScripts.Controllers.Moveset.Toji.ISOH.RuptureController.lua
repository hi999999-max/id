-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Toji.ISOH.RuptureController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = require(v_u_5.Modules.BloodyZee)
local v_u_10 = require(v_u_5.Modules.SraikoVFX)
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "RuptureController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_4, (copy) v_u_8, (copy) v_u_10, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (ref) v_u_11
	local v_u_85 = {
		["Hit"] = function(p14, p15)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v16 = p14:FindFirstChild("HumanoidRootPart")
			if v16 then
				local v17 = p15:FindFirstChild("HumanoidRootPart")
				if v17 then
					v_u_12:Flash(p15, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Choso.BloodEdge.StabHit, v17, game.SoundService.Effect).PlaybackSpeed = math.random(90, 110) / 100
					local v18 = v_u_6.Yuta.SlashHit:Clone()
					v18.CFrame = CFrame.lookAlong(v17.Position, v16.CFrame.LookVector)
					local v19 = v18.CFrame
					local v20 = CFrame.Angles
					local v21 = -90 + math.random(-4, 4)
					v18.CFrame = v19 * v20(0, 0, (math.rad(v21)))
					v18.Parent = workspace.Effects
					v18.Slash:Emit(5)
					v_u_2:AddItem(v18, 0.5)
					if v_u_4.Character == p14 or v_u_4.Character == p15 then
						local v22 = v_u_8.CameraShakeInstance.new(5, 8, 0.1, 0.7)
						v22.PositionInfluence = Vector3.new(0.25, 0.25, 0)
						v22.RotationInfluence = Vector3.new(0, 0, 0)
						v_u_8.CurrentShaker:Shake(v22)
					end
				end
			else
				return
			end
		end,
		["Dash"] = function(p23)
			-- upvalues: (ref) v_u_6, (ref) v_u_10, (ref) v_u_12, (ref) v_u_7, (ref) v_u_3, (ref) v_u_2
			local v24 = p23:FindFirstChild("HumanoidRootPart")
			if v24 then
				local v25 = v_u_6.Mechamaru.BoostOnVFX.BoostHit.Meshes.Mesh
				v_u_10.EmitMesh(v25, (v24.CFrame - v24.CFrame.LookVector * 4) * v25.Offset.Value)
				v_u_12:DustTrail(p23, 0.25, CFrame.Angles(0, -1.5707963267948966, 0))
				v_u_12:PlaySound(v_u_7.Toji.ISOH.Rupture.Dash, v24, game.SoundService.Effect)
				local v26 = p23.SetAssets:FindFirstChild("ISOH")
				if v26 then
					local v_u_27 = v_u_6.Toji.ISOHCombatTrail:Clone()
					v_u_27.Weld.Part0 = v26.Blade
					v_u_27.Parent = v26
					task.delay(0.5, function()
						-- upvalues: (copy) v_u_27, (ref) v_u_3, (ref) v_u_2
						if v_u_27.Parent ~= nil then
							v_u_27.Trail.Enabled = false
							v_u_3:Create(v_u_27, TweenInfo.new(0.1), {
								["Transparency"] = 1
							}):Play()
							v_u_2:AddItem(v_u_27, 0.2)
						end
					end)
				end
			end
		end,
		["Swing1"] = function(p28)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v29 = p28:FindFirstChild("HumanoidRootPart")
			if v29 then
				v_u_12:PlaySound(v_u_7.Toji.ISOH.Rupture.Whoosh1, v29, game.SoundService.Effect)
			end
		end,
		["Windup"] = function(p30)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_5
			local v31 = p30:FindFirstChild("HumanoidRootPart")
			if v31 then
				local v32 = p30.SetAssets:FindFirstChild("ISOH")
				if v32 then
					local v_u_33 = v_u_6.Toji.RuptureFlash:Clone()
					v_u_33.Parent = v32.Blade
					v_u_33.Enabled = true
					v_u_3:Create(v_u_33, TweenInfo.new(0.2, Enum.EasingStyle.Cubic, Enum.EasingDirection.In), {
						["TimeScale"] = 1
					}):Play()
					task.delay(0.3, function()
						-- upvalues: (copy) v_u_33, (ref) v_u_2
						v_u_33.Enabled = false
						v_u_2:AddItem(v_u_33, 0.1)
					end)
				end
				v_u_12:PlaySound(v_u_7.Toji.ISOH.Rupture.Whoosh2, v31, game.SoundService.Effect)
				local v34 = v_u_5.Utils.Itadori.EyeTrails:Clone()
				v34.Weld.Part0 = p30.Head
				v34.Trail1.Trail.Lifetime = 0.5
				v34.Trail2.Trail.Lifetime = 0.5
				v34.Parent = workspace.Effects
				task.wait(0.3)
				v34.Eye1.Glow.Enabled = false
				v34.Eye2.Glow.Enabled = false
				task.wait(0.1)
				v34.Trail1.Trail.Enabled = false
				v34.Trail2.Trail.Enabled = false
				v_u_2:AddItem(v34, 0.5)
			end
		end,
		["Swing2"] = function(p35, p36)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v37 = p35:FindFirstChild("HumanoidRootPart")
			if v37 then
				if not p36 then
					local v38 = v_u_6.Toji.RuptureSlash:Clone()
					v38.CFrame = v37.CFrame
					v38.Parent = workspace.Effects
					v_u_2:AddItem(v38, 0.4)
					for _, v39 in v38.Slash2:GetDescendants() do
						v39:Emit(v39:GetAttribute("Emit"))
					end
					v_u_3:Create(v38, TweenInfo.new(0.4), {
						["CFrame"] = v38.CFrame + v38.CFrame.LookVector * 5
					}):Play()
				end
			else
				return
			end
		end,
		["SkillCheck"] = function(p40, p41)
			-- upvalues: (ref) v_u_6, (ref) v_u_12, (ref) v_u_2
			if p40:FindFirstChild("HumanoidRootPart") then
				local v42 = p40.SetAssets:FindFirstChild("ISOH")
				if v42 then
					local v_u_43 = v_u_6.Toji.ISOHUseTwice:Clone()
					v_u_43.Parent = v42.Blade
					v_u_43.FluxFissureRef.Lifetime = NumberRange.new(0.5)
					v_u_12:PlayParticles(v_u_43)
					v_u_2:AddItem(v_u_43, 0.5)
					p41:GetAttributeChangedSignal("Start"):Connect(function()
						-- upvalues: (copy) v_u_43
						v_u_43:Destroy()
					end)
				end
			else
				return
			end
		end,
		["Feint"] = function(p44)
			-- upvalues: (ref) v_u_3, (ref) v_u_12
			local v45 = p44:FindFirstChild("HumanoidRootPart")
			if v45 then
				local v46 = v45:FindFirstChild("RootJoint")
				if v46 then
					local v47 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 1, -0)
					v46.C0 = v47 * CFrame.new(-2, 0, 0)
					v_u_3:Create(v46, TweenInfo.new(0.3, Enum.EasingStyle.Elastic), {
						["C0"] = v47
					}):Play()
				end
				v_u_12:DustTrail(p44, 0.2)
				for _, v_u_48 in p44:GetDescendants() do
					if not (v_u_48:IsA("BasePart") or v_u_48:IsA("Decal")) or v_u_48.Transparency == 1 then
						continue
					end
					v_u_48.LocalTransparencyModifier = 1
					task.delay(0.03, function()
						-- upvalues: (copy) v_u_48
						v_u_48.LocalTransparencyModifier = 0.7
						task.wait(0.03)
						v_u_48.LocalTransparencyModifier = 1
						task.wait(0.03)
						v_u_48.LocalTransparencyModifier = 0.2
						task.wait(0.03)
						v_u_48.LocalTransparencyModifier = 1
						task.wait(0.03)
						v_u_48.LocalTransparencyModifier = 0
					end)
				end
			end
		end,
		["Catch"] = function(p49)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v50 = p49:FindFirstChild("HumanoidRootPart")
			if v50 then
				v_u_12:PlaySound(v_u_7.Toji.ISOH.Rupture.Catch, v50, game.SoundService.Effect)
			end
		end,
		["EatISOH"] = function(p51)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v52 = p51:FindFirstChild("HumanoidRootPart")
			if v52 then
				v_u_12:PlaySound(v_u_7.Toji.Stance.ISOHUnequip, v52, game.SoundService.Effect).TimePosition = 0.05
			end
		end,
		["Throw"] = function(p53, p54, p55)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_5, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2
			local v56 = p53:FindFirstChild("HumanoidRootPart")
			if v56 then
				local v57 = p53.SetAssets:FindFirstChild("ISOH")
				if v57 and v57:FindFirstChild("ISOHCombatTrail") then
					v57.ISOHCombatTrail:Destroy()
				end
				local v58 = tick()
				v_u_12:PlaySound(v_u_7.Toji.ISOH.Rupture.Throw, v56, game.SoundService.Effect)
				local v59 = v_u_5.Utils.Toji.ISOH:Clone()
				v59.Parent = workspace.Effects
				v_u_12:PlaySound(v_u_7.Toji.ISOH.Rupture.ThrowLoop, v59.Blade, game.SoundService.Effect)
				local v_u_60 = v_u_6.Toji.ISOHCombatTrail:Clone()
				v_u_60.Weld.Part0 = v59.Blade
				v_u_60.Parent = workspace.Effects
				task.delay(p55 - 0.05, function()
					-- upvalues: (copy) v_u_60, (ref) v_u_3, (ref) v_u_2
					if v_u_60.Parent ~= nil then
						v_u_60.Trail.Enabled = false
						v_u_3:Create(v_u_60, TweenInfo.new(0.1), {
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v_u_60, 0.2)
					end
				end)
				local v61 = 3 * (p55 / 0.5)
				local v62 = v56.CFrame.Rotation
				local v63 = 0
				repeat
					local v64 = task.wait()
					local v65 = (tick() - v58) / p55
					local v66 = math.clamp(v65, 0, 1)
					v63 = v63 + 43.63323129985824 * v64
					local v67 = 1 - v66 * 2
					local v68 = 2.5 + v61 * (1 - math.abs(v67) ^ 2)
					local v69 = v56.Position + v56.CFrame.LookVector * 1 + Vector3.new(0, v68, 0)
					v59:PivotTo(CFrame.new(v69) * v62 * CFrame.Angles(v63, 0, 0))
				until not v56.Parent or (p55 < tick() - v58 or p54.Parent == nil)
				if v59 then
					v59:Destroy()
				end
			end
		end,
		["Stab"] = function(p70, p71, p_u_72)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_9
			if p70:FindFirstChild("HumanoidRootPart") then
				local v73 = p71:FindFirstChild("HumanoidRootPart")
				if v73 then
					v_u_12:Flash(p71, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Toji.ISOH.Rupture.Hit1, v73, game.SoundService.Effect)
					local v74 = p70.SetAssets:FindFirstChild("ISOH")
					local v_u_75 = v_u_6.Toji.ISOHCombatTrail:Clone()
					v_u_75.Weld.Part0 = v74.Blade
					v_u_75.Parent = workspace.Effects
					task.delay(0.5, function()
						-- upvalues: (copy) v_u_75, (ref) v_u_3, (ref) v_u_2
						if v_u_75.Parent ~= nil then
							v_u_75.Trail.Enabled = false
							v_u_3:Create(v_u_75, TweenInfo.new(0.1), {
								["Transparency"] = 1
							}):Play()
							v_u_2:AddItem(v_u_75, 0.2)
						end
					end)
					if _G.Settings.Gore == true then
						local v_u_76 = v_u_6.Naoya.BleedFreeze.Attachment:Clone()
						v_u_2:AddItem(v_u_76, 2)
						v_u_76.Blood.LockedToPart = true
						v_u_76.Parent = p71.Head
						v_u_76.CFrame = CFrame.new(0.155, -0.461, -0.312)
						v_u_76.Blood:Emit(20)
						task.delay(0.04, function()
							-- upvalues: (copy) v_u_76, (copy) p_u_72, (ref) v_u_9, (copy) v_u_75, (ref) v_u_3, (ref) v_u_2
							v_u_76.Blood.TimeScale = 0.005
							local v77 = tick()
							local v_u_78 = false
							p_u_72:GetAttributeChangedSignal("Start"):Connect(function()
								-- upvalues: (ref) v_u_78
								v_u_78 = true
							end)
							local v79 = v_u_78
							repeat
								task.wait()
							until tick() - v77 > 0.4 or v79
							v_u_76.Blood.LockedToPart = false
							v_u_76.Blood.TimeScale = 1
							v_u_76.Blood.Enabled = false
							for _ = 1, 20 do
								v_u_9:Blood(v_u_76.WorldCFrame, math.random(5, 80), 25, 25)
							end
							task.delay(0.1, function()
								-- upvalues: (ref) v_u_75, (ref) v_u_3, (ref) v_u_2
								v_u_75.Trail.Enabled = false
								v_u_3:Create(v_u_75, TweenInfo.new(0.1), {
									["Transparency"] = 1
								}):Play()
								v_u_2:AddItem(v_u_75, 0.2)
							end)
						end)
					end
				end
			else
				return
			end
		end,
		["Hit2"] = function(p80, p81)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v82 = p80:FindFirstChild("HumanoidRootPart")
			if v82 then
				local v83 = p81:FindFirstChild("HumanoidRootPart")
				if v83 then
					v_u_12:Flash(p81, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Toji.ISOH.Rupture.Hit2, v83, game.SoundService.Effect)
					local v84 = game.ReplicatedStorage.Utils.Yuta.ResoluteSlash.SlashHit.Attachment:Clone()
					v84.Parent = p81.Head
					v84.WorldCFrame = CFrame.lookAlong(v84.WorldPosition, CFrame.lookAt(v82.Position, v83.Position).LookVector) * CFrame.Angles(0, 0, 0.3490658503988659)
					v84.Slash.Color = ColorSequence.new(Color3.fromRGB(152, 0, 3))
					v84.Slash:Emit(2)
					v_u_2:AddItem(v84, 2)
					if v_u_4.Character == p80 or v_u_4.Character == p81 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
					end
				end
			else
				return
			end
		end
	}
	v_u_11.Effects:Connect(function(p86, ...)
		-- upvalues: (copy) v_u_85
		local v87 = v_u_85[p86]
		if v87 then
			v87(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12
	v_u_11 = v_u_1.GetService("RuptureService")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13