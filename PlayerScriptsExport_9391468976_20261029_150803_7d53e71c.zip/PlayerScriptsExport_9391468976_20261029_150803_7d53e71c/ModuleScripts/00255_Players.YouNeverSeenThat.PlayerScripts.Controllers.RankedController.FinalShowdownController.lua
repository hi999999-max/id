-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.RankedController.FinalShowdownController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
require(v5.Modules.Icon)
local _ = v5.Animations
local _ = v5.Utils
local v_u_6 = v5.Sounds
require(v5.Modules.CameraShaker)
require(v_u_4.PlayerScripts.PlayerModule)
require(v5.Modules.MVP)
local v_u_7 = nil
local v_u_8 = nil
local v9 = v_u_1.CreateController({
	["Name"] = "FinalShowdownController"
})
function v9.Start(_) -- name: Start
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_2, (ref) v_u_8, (copy) v_u_6, (ref) v_u_7
	task.spawn(function()
		-- upvalues: (ref) v_u_4, (ref) v_u_3, (ref) v_u_2, (ref) v_u_8, (ref) v_u_6
		local v_u_10 = v_u_4.PlayerGui:WaitForChild("Roulette")
		local v_u_11 = v_u_10.Gamemode_Items.Spectate
		v_u_10.Enabled = true
		workspace:GetAttributeChangedSignal("Timer"):Connect(function()
			-- upvalues: (copy) v_u_10, (ref) v_u_3
			if workspace:GetAttribute("Timer") == nil then
				v_u_10.Time.Visible = false
			else
				v_u_10.Time.Text = workspace:GetAttribute("Timer")
				v_u_10.Time.Size = UDim2.new(1, 0, 0.15, 0)
				v_u_10.Time.AnchorPoint = Vector2.new(0.5, 0.2)
				v_u_10.Time.Rotation = 5
				v_u_10.Time.Visible = true
				v_u_3:Create(v_u_10.Time, TweenInfo.new(1, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["AnchorPoint"] = nil,
					["Rotation"] = 0,
					["Size"] = UDim2.new(1, 0, 0.1, 0),
					["AnchorPoint"] = Vector2.new(0.5, 0)
				}):Play()
			end
		end)
		local v_u_12 = v_u_4.PlayerGui.Roulette.Gamemode_Items.Buttons
		v_u_12.AFK.Visible = false
		v_u_2.RenderStepped:Connect(function(p13)
			-- upvalues: (copy) v_u_10, (copy) v_u_11, (ref) v_u_4, (copy) v_u_12
			local v14 = v_u_10.Load.WaitSpin
			v14.Rotation = v14.Rotation + 30 * p13
			v_u_11.Static.Position = UDim2.new(math.random(-100, 0) / 100, 0, math.random(-100, 0) / 100, 0)
			local v15 = false
			if v_u_4.Team and v_u_4.Team.Name == "Lobby" then
				v_u_4.PlayerGui.Main.Enabled = false
				v_u_12.Visible = true
			else
				v_u_4.PlayerGui.Main.Enabled = true
				v_u_12.Visible = false
				v15 = true
			end
			if workspace.Effects:FindFirstChild("WaitAmbience") then
				if v15 == false then
					workspace.Effects.WaitAmbience.Volume = workspace.Effects.WaitAmbience.Vol.Value
					return
				end
				workspace.Effects.WaitAmbience.Volume = 0
			end
		end)
		local v_u_16 = 1
		v_u_4:GetAttributeChangedSignal("Spectate"):Connect(function()
			-- upvalues: (ref) v_u_16, (copy) v_u_11, (ref) v_u_4
			v_u_16 = 1
			v_u_11.Visible = v_u_4:GetAttribute("Spectate")
			if v_u_4:GetAttribute("Spectate") ~= true then
				local v17 = v_u_4.Character or v_u_4.CharacterAdded:Wait()
				workspace.CurrentCamera.CameraSubject = v17:WaitForChild("Humanoid", 1)
			end
		end)
		v_u_4:GetPropertyChangedSignal("Team"):Connect(function()
			-- upvalues: (ref) v_u_4
			v_u_4:SetAttribute("Spectate", nil)
		end)
		v_u_12.Spectate.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_4
			v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
			v_u_8:PlaySound(v_u_6.Misc.UI.SpectateStart, workspace, game.SoundService.Effect)
			v_u_4:SetAttribute("Spectate", v_u_4:GetAttribute("Spectate") == nil and true or nil)
		end)
		v_u_11.CycleLeft.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_4, (ref) v_u_16, (copy) v_u_11, (ref) v_u_3, (ref) v_u_8, (ref) v_u_6
			local v18 = {}
			for _, v19 in game.Players:GetPlayers() do
				if v19 == v_u_4 then
					table.insert(v18, v19)
				else
					if v19.Team.Name == "Lobby" then
						continue
					end
					table.insert(v18, v19)
				end
			end
			table.sort(v18, function(p20, _)
				-- upvalues: (ref) v_u_4
				return p20 == v_u_4
			end)
			v_u_16 = v_u_16 - 1
			if v_u_16 < 1 then
				v_u_16 = #v18
			end
			local v21
			if v18[v_u_16].Character then
				v21 = v18[v_u_16].Character:FindFirstChild("Head") or v_u_4.Character.Humanoid
			else
				v21 = nil
			end
			workspace.CurrentCamera.CameraSubject = v21
			v_u_11.Spectating.Spectating.Text = v18[v_u_16].Name
			v_u_11.Static.ImageTransparency = 0
			v_u_3:Create(v_u_11.Static, TweenInfo.new(1), {
				["ImageTransparency"] = 1
			}):Play()
			v_u_8:PlaySound(v_u_6.Misc.UI.SpectateStart, workspace, game.SoundService.Effect)
		end)
		v_u_11.CycleRight.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_4, (ref) v_u_16, (copy) v_u_11, (ref) v_u_3, (ref) v_u_8, (ref) v_u_6
			local v22 = {}
			for _, v23 in game.Players:GetPlayers() do
				if v23 == v_u_4 then
					table.insert(v22, v23)
				else
					if v23.Team.Name == "Lobby" then
						continue
					end
					table.insert(v22, v23)
				end
			end
			table.sort(v22, function(p24, _)
				-- upvalues: (ref) v_u_4
				return p24 == v_u_4
			end)
			v_u_16 = v_u_16 + 1
			if v_u_16 > #v22 then
				v_u_16 = 1
			end
			local v25
			if v22[v_u_16].Character then
				v25 = v22[v_u_16].Character:FindFirstChild("Head") or v_u_4.Character.Humanoid
			else
				v25 = nil
			end
			workspace.CurrentCamera.CameraSubject = v25
			v_u_11.Spectating.Spectating.Text = v22[v_u_16].Name
			v_u_11.Static.ImageTransparency = 0
			v_u_3:Create(v_u_11.Static, TweenInfo.new(1), {
				["ImageTransparency"] = 1
			}):Play()
			v_u_8:PlaySound(v_u_6.Misc.UI.SpectateStart, workspace, game.SoundService.Effect)
		end)
	end)
	local v_u_32 = {
		["PipeShoot"] = function()
			-- upvalues: (ref) v_u_6, (ref) v_u_8
			local v26 = workspace.Map.Core.Pipe.Core.PipePoint
			for _, v27 in v26.Wind:GetChildren() do
				v27:Emit(v27:GetAttribute("EmitCount"))
			end
			v_u_6.Misc.Pipe.PlaybackSpeed = math.random(14, 20) / 10
			v_u_8:PlaySound(v_u_6.Misc.Pipe, v26, game.SoundService.Effect)
		end,
		["Transition"] = function(p28)
			-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_6, (ref) v_u_3
			local v29 = v_u_4.PlayerGui:WaitForChild("Roulette"):WaitForChild("Load")
			v29.Gamemode.Text = p28
			v29.WaitTime.Size = UDim2.new(0, 0, 0, 10)
			v_u_8:PlaySound(v_u_6.Misc.UI.Load1, workspace, game.SoundService.Effect)
			local v30 = TweenInfo.new(0.5)
			v_u_3:Create(v29, v30, {
				["BackgroundTransparency"] = 0,
				["ImageTransparency"] = 0
			}):Play()
			v_u_3:Create(v29.WaitSpin, v30, {
				["ImageTransparency"] = 0
			}):Play()
			v_u_3:Create(v29.WaitTime, v30, {
				["BackgroundTransparency"] = 0
			}):Play()
			v_u_3:Create(v29.WaitTime, TweenInfo.new(1), {
				["Size"] = UDim2.new(1, 0, 0, 10)
			}):Play()
			v_u_3:Create(v29.Gamemode, v30, {
				["TextTransparency"] = 0
			}):Play()
			repeat
				task.wait()
			until not workspace:GetAttribute("Loading")
			local v31 = TweenInfo.new(1)
			v_u_8:PlaySound(v_u_6.Misc.UI.Load2, workspace, game.SoundService.Effect)
			v_u_3:Create(v29, v31, {
				["BackgroundTransparency"] = 1,
				["ImageTransparency"] = 1
			}):Play()
			v_u_3:Create(v29.WaitSpin, v31, {
				["ImageTransparency"] = 1
			}):Play()
			v_u_3:Create(v29.WaitTime, v31, {
				["BackgroundTransparency"] = 1
			}):Play()
			v_u_3:Create(v29.Gamemode, v31, {
				["TextTransparency"] = 1
			}):Play()
		end
	}
	v_u_7.Effects:Connect(function(p33, ...)
		-- upvalues: (copy) v_u_32
		local v34 = v_u_32[p33]
		if v34 then
			v34(...)
		end
	end)
end
function v9.KnitStart(_) -- name: KnitStart end
function v9.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (ref) v_u_8
	v_u_7 = v_u_1.GetService("FinalShowdownService")
	v_u_8 = v_u_1.GetController("FXController")
end
return v9