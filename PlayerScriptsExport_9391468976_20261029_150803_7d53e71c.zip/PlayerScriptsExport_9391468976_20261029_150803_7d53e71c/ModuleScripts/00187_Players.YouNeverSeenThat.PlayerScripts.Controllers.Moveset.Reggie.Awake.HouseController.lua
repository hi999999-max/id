-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Reggie.Awake.HouseController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
require(v_u_6.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "HouseController"
})
function v14.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_4, (ref) v_u_13, (copy) v_u_6, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2, (ref) v_u_10
	local v_u_55 = {
		["Start"] = function(p15, p16)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v17 = p15:FindFirstChild("HumanoidRootPart")
			if v17 then
				local v_u_18 = v_u_12:PlaySound(v_u_8.Reggie.House.Whoosh, v17, game.SoundService.Effect)
				p16.Destroying:Connect(function()
					-- upvalues: (copy) v_u_18
					v_u_18:Destroy()
				end)
			end
		end,
		["Voice"] = function(p19, p20)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v21 = p19:FindFirstChild("HumanoidRootPart")
			if v21 then
				local v_u_22 = v_u_12:PlaySound(v_u_8.Reggie.House.Voiceline, v21, game.SoundService.Voice)
				p20.Destroying:Connect(function()
					-- upvalues: (copy) v_u_22
					v_u_22:Destroy()
				end)
			end
		end,
		["Hitbox"] = function(p23, p24)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_13
			local v25 = v_u_7.Megumi.HitArea:Clone()
			v25.Size = Vector3.new(50, 0, 50)
			for _, v26 in v25:GetChildren() do
				local v27 = v26.Transparency
				v26.Transparency = 1
				v_u_4:Create(v26, TweenInfo.new(0.4), {
					["Transparency"] = v27
				}):Play()
			end
			v25.Parent = workspace.Effects
			local v28 = tick()
			local v29 = v_u_13:GetMouseTarget(200)
			local v30 = workspace:Raycast(v29 + Vector3.new(0, 1, 0), Vector3.new(0, -300, 0), _G.MapParams)
			if v30 then
				v29 = v30.Position
			end
			v25.Position = v29 + Vector3.new(0, 0.01, 0)
			if tick() - v28 > 0.1 then
				p24:FireServer(v29)
			end
			task.wait()
			if p23 and (p23.Parent and p23.Value ~= true) then
				continue
			end
			if p23.Value then
				p24:FireServer(v29)
			end
			v25:Destroy()
		end,
		["Smash"] = function(p31, p32)
			-- upvalues: (ref) v_u_6, (ref) v_u_12, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v33 = v_u_6.Utils.Reggie.GroundImpact:Clone()
			v33.Parent = workspace.Effects
			v33.Position = p32
			v_u_12:PlayParticles(v33)
			v_u_3:AddItem(v33, 2.5)
			if (workspace.CurrentCamera.CFrame.Position - p32).Magnitude < 100 or p31 == v_u_5.Character then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
			end
		end,
		["Interp"] = function(_, p_u_34, _)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_7, (ref) v_u_2, (ref) v_u_9
			local v35 = v_u_6.Utils.Reggie.Particles:Clone()
			v35.Parent = workspace.Effects
			v35.Anchored = false
			v35.Weld.Part0 = p_u_34
			v_u_3:AddItem(v35, 5)
			local v_u_36 = v_u_7.Reggie.HouseVisual:Clone()
			v_u_36.Parent = workspace.Effects
			v_u_3:AddItem(v_u_36, 15)
			local v_u_37 = nil
			v_u_37 = v_u_2.PreSimulation:Connect(function()
				-- upvalues: (copy) p_u_34, (ref) v_u_37, (copy) v_u_36
				if p_u_34 and p_u_34.Parent then
					v_u_36:PivotTo(p_u_34.Parent:GetPivot())
				else
					v_u_37:Disconnect()
					v_u_36:Destroy()
				end
			end)
			p_u_34:GetAttributeChangedSignal("Stop"):Connect(function()
				-- upvalues: (ref) v_u_37, (copy) v_u_36
				v_u_37:Disconnect()
				v_u_36:Destroy()
			end)
			while p_u_34 and p_u_34.Parent do
				local v38 = (workspace.CurrentCamera.CFrame.Position - p_u_34.Position).Magnitude
				if v38 > 160 and v38 < 200 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.MediumHit)
				elseif v38 < 160 and v38 > 100 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				elseif v38 < 100 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
				task.wait(0.3)
			end
			v35:Destroy()
		end,
		["Smash2"] = function(p39, p40)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_6, (ref) v_u_12, (ref) v_u_5, (ref) v_u_9
			local v41 = v_u_7.Megumi.Mahoraga.Earthquake:Clone()
			v41.Position = p40
			v41.Parent = workspace.Effects
			v41.Air:Destroy()
			v_u_4:Create(v41.PointLight, TweenInfo.new(0.6), {
				["Brightness"] = 0
			}):Play()
			v_u_4:Create(v41.Floor.Ring2, TweenInfo.new(0.4), {
				["TimeScale"] = 0.5
			}):Play()
			v41.Floor.Ring2:Emit(10)
			v41.Floor.Wind2:Emit(15)
			v41.Floor.Dust:Emit(100)
			v_u_3:AddItem(v41, 3)
			local v42 = v_u_7.Megumi.Mahoraga.WorldSlash.mesh:Clone()
			v42.Position = p40
			v42.Decal.Transparency = 0
			v42.Mesh.Scale = Vector3.new(2, 50, 2)
			v42.Parent = v41
			v_u_4:Create(v42, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Size"] = Vector3.new(80, 40, 80),
				["CFrame"] = nil,
				["CFrame"] = v42.CFrame * CFrame.Angles(0, -3.12413936106985, 0)
			}):Play()
			v_u_4:Create(v42.Mesh, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Scale"] = Vector3.new(60, 10, 60)
			}):Play()
			v_u_4:Create(v42.Decal, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Transparency"] = 1
			}):Play()
			v_u_3:AddItem(v42, 1)
			local v43 = v_u_6.Utils.Reggie.HouseExplosion:Clone()
			v43.Parent = workspace.Effects
			v43.Position = p40 + Vector3.new(0, 15, 0)
			v_u_12:PlayParticles(v43)
			v_u_3:AddItem(v43, 2.5)
			if (workspace.CurrentCamera.CFrame.Position - p40).Magnitude < 100 or p39 == v_u_5.Character then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeaviestHit)
			end
		end,
		["Hit"] = function(p44)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v45 = p44:FindFirstChild("HumanoidRootPart")
			if v45 then
				v_u_12:Flash(p44, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Megumi.Elephant.Hit, v45, game.SoundService.Effect)
			end
		end,
		["Finisher"] = function(p46)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v47 = p46.HumanoidRootPart
			if v47 then
				v_u_12:Bleed(p46)
				v_u_12:PlaySound(v_u_8.Megumi.Elephant.Explode, v47, game.SoundService.Effect)
				for _ = 1, 20 do
					local v48 = v_u_7.Damage.Chunk:Clone()
					v48.CFrame = v47.CFrame
					local v49 = math.random(-90, 90)
					local v50 = math.random(20, 50)
					local v51 = math.random
					v48.Velocity = Vector3.new(v49, v50, v51(-90, 90))
					local v52 = math.random(-200, 200)
					local v53 = math.random(-200, 200)
					local v54 = math.random
					v48.RotVelocity = Vector3.new(v52, v53, v54(-200, 200))
					v48.Parent = workspace.Effects
					v_u_3:AddItem(v48, 1)
					if _G.Settings.Gore ~= false then
						continue
					end
					v48.Color = Color3.fromRGB(255, 85, 255)
					v48.Trail.Color = ColorSequence.new(Color3.fromRGB(255, 85, 255))
					v48.Blood.Color = v48.Trail.Color
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p56, ...)
		-- upvalues: (copy) v_u_55
		local v57 = v_u_55[p56]
		if v57 then
			v57(...)
		end
	end)
end
function v14.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13
	v_u_10 = v_u_1.GetService("HouseService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
	v_u_13 = v_u_1.GetController("ToolController")
end
return v14