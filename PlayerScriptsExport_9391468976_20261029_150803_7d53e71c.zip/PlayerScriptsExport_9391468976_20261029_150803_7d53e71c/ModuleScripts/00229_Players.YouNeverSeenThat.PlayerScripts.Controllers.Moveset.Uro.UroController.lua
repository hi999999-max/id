-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Uro.UroController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local v_u_6 = v5.Animations
local v_u_7 = v5.Utils
local v_u_8 = v5.Sounds
local v_u_9 = require(v5.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "UroController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_2, (copy) v_u_4, (copy) v_u_9, (copy) v_u_3, (copy) v_u_1, (copy) v_u_6, (ref) v_u_10
	local v_u_190 = {
		["Hit"] = function(p14, p15)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v16 = p14:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_12:Flash(p14, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit" .. p15), v16, game.SoundService.Effect)
			end
		end,
		["ChaseHit"] = function(p17, p18)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_2
			local v19 = p17:FindFirstChild("HumanoidRootPart")
			if v19 then
				local v20 = p18:FindFirstChild("HumanoidRootPart")
				if v20 then
					v_u_12:Flash(p18, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit3"), v20, game.SoundService.Effect)
					local v21 = v_u_7.ChaseHit:Clone()
					local v22 = CFrame.new
					local v23 = v20.Position
					local v24 = v19.Position.X
					local v25 = v20.Position.Y
					local v26 = v19.Position.Z
					v21.CFrame = v22(v23, (Vector3.new(v24, v25, v26))) * CFrame.Angles(0, 3.141592653589793, 0)
					v21.Parent = workspace.Effects
					v21.Ring:Emit(7)
					v21.Sparks:Emit(12)
					v_u_2:AddItem(v21, 0.5)
				end
			else
				return
			end
		end,
		["AerialHit"] = function(p27, p28)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_4, (ref) v_u_9, (ref) v_u_7, (ref) v_u_2
			local v29 = p27:FindFirstChild("HumanoidRootPart")
			if v29 then
				local v30 = p28:FindFirstChild("HumanoidRootPart")
				if v30 then
					v_u_12:Flash(p28, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Itadori.CraniumSmash.Hit2, v30, game.SoundService.Effect)
					if v_u_4.Character == p27 or v_u_4.Character == p28 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					end
					local v31 = CFrame.new(v29.Position, v30.Position - Vector3.new(0, 4, 0))
					local v32 = v_u_7.Gojo.HardHit:Clone()
					v32.CFrame = v31 + v31.LookVector * 4
					v32.Parent = workspace.Effects
					v32.Dust:Emit(5)
					v32.Ring:Emit(5)
					v32.Sparks:Emit(10)
					v_u_2:AddItem(v32, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p33)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_12, (ref) v_u_8
			local v34 = p33.HumanoidRootPart
			if v34 then
				local v35 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v35.CFrame = v34.CFrame * CFrame.new(0, 1, -4)
				v35.Size = Vector3.new(0, 0, 2)
				v35.Parent = workspace.Effects
				v_u_3:Create(v35, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v35, 0.3)
				v_u_12:PlaySound(v_u_8.Misc.Chase, v34, game.SoundService.Effect)
				v_u_12:DustTrail(p33, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p36)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v37 = p36:FindFirstChild("HumanoidRootPart")
			if v37 then
				v_u_12:PlaySound(v_u_8.Misc.Swing.Fist, v37, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p38, p39, p40, p41)
			-- upvalues: (ref) v_u_3, (ref) v_u_12
			if p41 then
				if p40 == "Down" then
					v_u_12:ArmFlash(p38["Right Leg"], Color3.fromRGB(255, 133, 172), 0.4)
					return
				elseif p39 == 1 then
					v_u_12:ArmFlash(p38["Left Arm"], Color3.fromRGB(255, 133, 172), 0.3)
					return
				elseif p39 == 2 or p40 == "Up" then
					v_u_12:ArmFlash(p38["Right Arm"], Color3.fromRGB(255, 133, 172), 0.3)
					return
				elseif p39 == 3 then
					v_u_12:ArmFlash(p38["Left Leg"], Color3.fromRGB(255, 133, 172), 0.3)
				else
					v_u_12:ArmFlash(p38["Left Arm"], Color3.fromRGB(255, 133, 172), 0.3)
					v_u_12:ArmFlash(p38["Right Arm"], Color3.fromRGB(255, 133, 172), 0.3)
				end
			elseif p40 == "Down" then
				v_u_12:ArmFlash(p38["Right Leg"], Color3.fromRGB(255, 133, 172), 0.4)
				return
			elseif p39 == 1 or p39 == 3 then
				v_u_12:ArmFlash(p38["Left Arm"], Color3.fromRGB(255, 133, 172), 0.3)
			elseif p39 == 2 or (p39 == 4 or p40 == "Up") then
				v_u_12:ArmFlash(p38["Right Arm"], Color3.fromRGB(255, 133, 172), 0.3)
			end
		end,
		["Launch"] = function(p42, p43)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_12, (ref) v_u_8, (ref) v_u_4, (ref) v_u_9
			local v44 = p42:FindFirstChild("HumanoidRootPart")
			if v44 then
				local v45 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v45.CFrame = CFrame.new(v44.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v45.Size = Vector3.new(0, 0, 5)
				v45.Parent = workspace.Effects
				v_u_3:Create(v45, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v45.Position + Vector3.new(0, p43, 0)
				}):Play()
				v_u_2:AddItem(v45, 0.3)
				if p43 < 0 then
					v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v44, game.SoundService.Effect)
					v_u_12:DustBreak(v44.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_4:DistanceFromCharacter(v44.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			end
		end,
		["Chat"] = function(p_u_46)
			-- upvalues: (ref) v_u_7, (ref) v_u_12, (ref) v_u_8, (ref) v_u_3, (ref) v_u_2, (ref) v_u_9
			local v47 = p_u_46:FindFirstChild("HumanoidRootPart")
			if v47 then
				task.spawn(function()
					-- upvalues: (copy) p_u_46, (ref) v_u_7, (ref) v_u_12, (ref) v_u_8, (ref) v_u_3, (ref) v_u_2
					local v48 = p_u_46:FindFirstChild("Torso")
					if v48 then
						local v49 = v_u_7.Uro.Dialogue:Clone()
						v49.Parent = v48
						v_u_12:PlaySound(v_u_8.Uro.Ultimate.Voice, v48, game.SoundService.Effect)
						v_u_12:PlaySound(v_u_8.Uro.Ultimate.Ult, v48, game.SoundService.Effect)
						local v50 = UDim2.new(0.4, 0, 0.6, 0)
						v49.Chat1.Position = v50 - UDim2.new(0, 0, 0.15, 0)
						v49.Chat1.Sub.Text = "ARE YOU THAT AFRAID?"
						v_u_3:Create(v49.Chat1, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
							["Position"] = v50
						}):Play()
						v_u_3:Create(v49.Chat1, TweenInfo.new(0.3), {
							["BackgroundTransparency"] = 0
						}):Play()
						v_u_3:Create(v49.Chat1.Sub, TweenInfo.new(0.3), {
							["TextTransparency"] = 0
						}):Play()
						task.wait(1.5)
						v_u_2:AddItem(v49, 0.6)
						for _, v51 in v49:GetDescendants() do
							if v51:IsA("Frame") then
								v_u_3:Create(v51, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
									["Position"] = nil,
									["BackgroundTransparency"] = 1,
									["Position"] = v51.Position - UDim2.new(0, 0, 0.2, 0)
								}):Play()
							else
								if not v51:IsA("TextLabel") then
									continue
								end
								v_u_3:Create(v51, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
									["TextTransparency"] = 1
								}):Play()
							end
						end
					end
				end)
				local v52 = Instance.new("Model", workspace.Effects)
				local v53 = Instance.new("Highlight")
				v53.DepthMode = Enum.HighlightDepthMode.Occluded
				v53.FillColor = Color3.fromRGB(255, 255, 255)
				v53.FillTransparency = 1
				v53.OutlineTransparency = 1
				v53.Parent = v52
				v_u_2:AddItem(v52, 0.65)
				local v54 = v47.Position - v47.CFrame.LookVector * 12 - v47.CFrame.RightVector * 5
				local v55 = v_u_7.Uro.AirDistort2:Clone()
				v55.Transparency = 1
				v_u_3:Create(v55, TweenInfo.new(0.45), {
					["Transparency"] = 10
				}):Play()
				v55.Parent = v52
				local v56 = v47.Position - v47.CFrame.LookVector * 12 + v47.CFrame.RightVector * 5
				local v57 = v_u_7.Uro.AirDistort2:Clone()
				v57.Transparency = 1
				v_u_3:Create(v57, TweenInfo.new(0.45), {
					["Transparency"] = 10
				}):Play()
				v57.Parent = v52
				if (workspace.CurrentCamera.CFrame.Position - v47.Position).Magnitude < 100 then
					local v_u_58 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.LightHit)
					task.delay(0.65, function()
						-- upvalues: (copy) v_u_58
						v_u_58:StartFadeOut(0)
					end)
				end
				local v59 = v_u_7.Misc.C.M1.Hit1:Clone()
				v59.Parent = p_u_46["Left Arm"]
				v59.Position = Vector3.new(0, -1, 0)
				for _, v60 in v59:GetDescendants() do
					if not v60:IsA("ParticleEmitter") then
						continue
					end
					v60:Emit(v60:GetAttribute("EmitCount"))
					v60.LockedToPart = true
				end
				v_u_2:AddItem(v59, 0.5)
				local v61 = v_u_7.Misc.C.M1.Hit1:Clone()
				v61.Parent = p_u_46["Right Arm"]
				v61.Position = Vector3.new(0, -1, 0)
				for _, v62 in v61:GetDescendants() do
					if not v62:IsA("ParticleEmitter") then
						continue
					end
					v62:Emit(v62:GetAttribute("EmitCount"))
					v62.LockedToPart = true
				end
				v_u_2:AddItem(v61, 0.5)
				local v63 = tick()
				local v64 = 12
				local v65 = (p_u_46["Left Arm"].CFrame * CFrame.new(0, -1, 0)).Position
				local v66 = (p_u_46["Right Arm"].CFrame * CFrame.new(0, -1, 0)).Position
				local v67 = (v65 - v54).Magnitude
				local v68 = (v66 - v56).Magnitude
				local v69 = CFrame.lookAt(v54, v65)
				local v70 = CFrame.lookAt(v56, v66)
				v55.CFrame = v69 + v69.LookVector * (v67 / 2)
				v55.Size = Vector3.new(v64, v64, v67)
				v57.CFrame = v70 + v70.LookVector * (v68 / 2)
				v57.Size = Vector3.new(v64, v64, v68)
				local v71 = task.wait()
				if tick() > v63 + 0.2 then
					local v72 = v71 * 2.2
					v64 = math.lerp(v64, 3, v72)
				end
				if v52.Parent and p_u_46.Parent then
					continue
				end
				if (workspace.CurrentCamera.CFrame.Position - v47.Position).Magnitude < 100 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
				local v73 = v_u_7.Mechamaru.Dust:Clone()
				v73.bigimpact:Destroy()
				v73.Smoke2:Destroy()
				v73.Position = v47.Position - Vector3.new(0, 3, 0)
				v73.Parent = workspace.Effects
				v_u_2:AddItem(v73, 2.5)
				for _, v74 in v73:GetChildren() do
					v74:Emit(v74:GetAttribute("EmitCount"))
				end
				task.delay(0.5, function()
					-- upvalues: (copy) p_u_46, (ref) v_u_7, (ref) v_u_12, (ref) v_u_2
					if p_u_46:GetAttribute("InUlt") then
						local v75 = v_u_7.Uro.Rage:Clone()
						v75.Parent = p_u_46.Head
						v_u_12:Flash(p_u_46, Color3.fromRGB(255, 133, 172), 0.5)
						repeat
							v75.Smoke2.Enabled = p_u_46.Head.Transparency == 0
							task.wait()
						until not (p_u_46.Parent and p_u_46:GetAttribute("InUlt"))
						v75.Smoke2.Enabled = false
						v75.Smoke:Emit(20)
						v_u_2:AddItem(v75, 1)
						v_u_12:Flash(p_u_46, Color3.fromRGB(255, 133, 172), 1)
					end
				end)
				local v76 = v47.CFrame - v47.CFrame.LookVector * 6
				if _G.Settings.DesPHY then
					if (workspace.CurrentCamera.CFrame.Position - v76.Position).Magnitude > 200 then
						return
					end
					local v77 = Instance.new("Model", workspace.Effects)
					local v78 = Instance.new("Highlight")
					v78.DepthMode = Enum.HighlightDepthMode.Occluded
					v78.FillTransparency = 1
					v78.OutlineTransparency = 1
					v78.Parent = v77
					v_u_2:AddItem(v77, 1)
					Random.new()
					local v79 = TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
					for _ = 1, 20 do
						local v80 = v_u_7.Gojo.Shard:Clone()
						local v81 = CFrame.Angles
						local v82 = math.random(-60, 60)
						local v83 = math.rad(v82)
						local v84 = math.random(-60, 60)
						local v85 = (v76 * v81(v83, math.rad(v84), 0)).LookVector
						local v86 = math.random(10, 80) / 10
						local v87 = math.random(10, 80) / 10
						v80.Size = Vector3.new(0.2, v86, v87)
						v80.CFrame = v76 * CFrame.new(math.random(-10, 10), math.random(-5, 10), 0)
						v80.CFrame = v80.CFrame * CFrame.Angles(0, math.random(0, 3.141592653589793), 0)
						v80.CanCollide = true
						v80.CollisionGroup = "Effects"
						v80.Parent = v77
						v80.Transparency = 5
						v80.Material = Enum.Material.Glass
						local v88 = math.random(-50, 50)
						local v89 = math.random(-50, 50)
						local v90 = math.random
						v80.RotVelocity = Vector3.new(v88, v89, v90(-50, 50))
						v80.Velocity = v85 * math.random(30, 60) + v47.Velocity
						v_u_3:Create(v80, v79, {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
						v_u_2:AddItem(v80, 1)
					end
				end
			end
		end,
		["AirDistort"] = function(p91, p92, p_u_93, p94, p_u_95)
			-- upvalues: (ref) v_u_2, (ref) v_u_3, (ref) v_u_7
			if p91:FindFirstChild("HumanoidRootPart") then
				local v_u_96 = Instance.new("Model", workspace.Effects)
				local v97 = Instance.new("Highlight")
				v97.DepthMode = Enum.HighlightDepthMode.Occluded
				v97.FillColor = Color3.fromRGB(255, 255, 255)
				v97.OutlineColor = Color3.fromRGB(255, 170, 255)
				v97.FillTransparency = 0.9
				v97.OutlineTransparency = 0.8
				v97.Parent = v_u_96
				v_u_2:AddItem(v_u_96, p94 + p_u_95)
				local v98 = TweenInfo.new(p_u_95, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
				local v_u_99 = {}
				task.spawn(function()
					-- upvalues: (copy) v_u_99, (copy) p_u_95, (copy) p_u_93, (copy) v_u_96
					for v100, v101 in v_u_99 do
						if v100:IsDescendantOf(workspace.Effects) then
							local v102 = v101[1].Position
							local v103 = v101[2].Position
							local v104 = (v102 - v103).Magnitude
							local v105 = (tick() - v101[3]) / p_u_95
							local v106 = p_u_93 - v105 * p_u_93
							local v107 = v104 * 1.35 - v104
							local v108 = v104 + (v107 - v107 * v105)
							v100.Size = Vector3.new(v106, v106, v108)
							local v109 = CFrame.lookAt(v102, v103)
							v100.CFrame = v109 + v109.LookVector * (v104 / 2)
						else
							v_u_99[v100] = nil
						end
					end
					task.wait()
					if v_u_96.Parent then
						break
					end
				end)
				local v110 = p_u_95 / 0.5 * 5
				local v111 = tick()
				local v112 = p92.Position
				local v113 = {}
				local v114 = p92.Position - v112
				v112 = p92.Position
				local v115 = Instance.new("Folder", v_u_96)
				v_u_2:AddItem(v115, p_u_95)
				local v116 = Instance.new("Part")
				v116.Transparency = 1
				v116.Anchored = true
				v116.CanCollide = false
				v116.Name = "Attachment"
				v116.CFrame = p92.CFrame * CFrame.new(0, -2, 0)
				v116.Parent = v115
				v_u_3:Create(v116, v98, {
					["CFrame"] = v116.CFrame + v114 * v110
				}):Play()
				table.insert(v113, v115)
				if #v113 > 1 then
					local v117 = v113[#v113 - 1]
					local v118 = v_u_7.Uro.AirDistort2:Clone()
					v_u_3:Create(v118, v98, {
						["Transparency"] = 1
					}):Play()
					v118.Parent = v115
					v_u_99[v118] = { v117.Attachment, v116, tick() }
					local v119 = v117.Attachment.Position
					local v120 = v116.Position
					local v121 = (v119 - v120).Magnitude
					v118.Size = Vector3.new(p_u_93, p_u_93, v121)
					local v122 = CFrame.lookAt(v119, v120)
					v118.CFrame = v122 + v122.LookVector * (v121 / 2)
				end
				task.wait(0.02)
				if tick() <= v111 + p94 and p92:IsDescendantOf(workspace.Characters) then
					continue
				end
			end
		end,
		["Chat2"] = function(p123)
			-- upvalues: (ref) v_u_7, (ref) v_u_1, (ref) v_u_12, (ref) v_u_8, (ref) v_u_3, (ref) v_u_2
			local v124 = p123:FindFirstChild("HumanoidRootPart")
			if v124 then
				local v125 = p123:FindFirstChild("Torso")
				if v125 then
					local v126 = v124.CFrame * CFrame.Angles(0, 0, 3.141592653589793)
					v_u_7.Misc.M.Awk.mokultMeh["2"].Mesh2.Start.Decal.Color3 = Color3.fromRGB(25500, 170, 25500)
					v_u_7.Misc.M.Awk.mokultMeh["2"].Mesh2.End.Decal.Color3 = Color3.fromRGB(500, 300, 25500)
					for _, v127 in v_u_7.Misc.M.Awk.mokultMeh["2"]:GetChildren() do
						v127:PivotTo(v126)
						v_u_1.GetController("MokouController"):ArcTween(v127.Start, true)
					end
					local v128 = v_u_7.Uro.Dialogue:Clone()
					v128.Parent = v125
					v_u_12:PlaySound(v_u_8.Uro.Ultimate.Voice1, v125, game.SoundService.Effect)
					v_u_12:PlaySound(v_u_8.Uro.Ultimate.Fly, v125, game.SoundService.Effect)
					local v129 = v128.Chat1.Position
					v128.Chat1.Position = v129 - UDim2.new(0, 0, 0.15, 0)
					v_u_3:Create(v128.Chat1, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Position"] = v129
					}):Play()
					v_u_3:Create(v128.Chat1, TweenInfo.new(0.3), {
						["BackgroundTransparency"] = 0
					}):Play()
					v_u_3:Create(v128.Chat1.Sub, TweenInfo.new(0.3), {
						["TextTransparency"] = 0
					}):Play()
					task.wait(1.5)
					v_u_2:AddItem(v128, 0.6)
					for _, v130 in v128:GetDescendants() do
						if v130:IsA("Frame") then
							v_u_3:Create(v130, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
								["Position"] = nil,
								["BackgroundTransparency"] = 1,
								["Position"] = v130.Position - UDim2.new(0, 0, 0.2, 0)
							}):Play()
						else
							if not v130:IsA("TextLabel") then
								continue
							end
							v_u_3:Create(v130, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
								["TextTransparency"] = 1
							}):Play()
						end
					end
					task.wait(0.5)
					v_u_12:PlaySound(v_u_8.Uro.Ultimate.Voice2, v125, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Warning"] = function(p131, p132)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_9
			if p131:FindFirstChild("HumanoidRootPart") then
				local v133 = v_u_7.Megumi.Mahoraga.WorldSlash.mesh:Clone()
				v133.Position = p132
				v133.Decal.Transparency = 0.2
				v133.Mesh.Scale = Vector3.new(0.2, 50, 0.2)
				v133.Parent = workspace.Effects
				v_u_3:Create(v133, TweenInfo.new(3, Enum.EasingStyle.Exponential), {
					["Size"] = Vector3.new(80, 40, 80),
					["CFrame"] = nil,
					["CFrame"] = v133.CFrame * CFrame.Angles(0, -3.12413936106985, 0)
				}):Play()
				v_u_3:Create(v133.Mesh, TweenInfo.new(3, Enum.EasingStyle.Exponential), {
					["Scale"] = Vector3.new(25, 10, 25)
				}):Play()
				v_u_3:Create(v133.Decal, TweenInfo.new(3, Enum.EasingStyle.Exponential), {
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v133, 3)
				if (workspace.CurrentCamera.CFrame.Position - p132).Magnitude < 180 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end,
		["UhOh"] = function()
			-- upvalues: (ref) v_u_9, (ref) v_u_3, (ref) v_u_2
			v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
			if _G.Settings.Flash == true then
				local v134 = Instance.new("ColorCorrectionEffect", game.Lighting)
				v134.Contrast = -3
				v_u_3:Create(v134, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Contrast"] = 0
				}):Play()
				v_u_2:AddItem(v134, 1)
			end
			v_u_3:Create(workspace.CurrentCamera, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
				["FieldOfView"] = 50
			}):Play()
			task.delay(1, function()
				-- upvalues: (ref) v_u_3
				v_u_3:Create(workspace.CurrentCamera, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["FieldOfView"] = 70
				}):Play()
			end)
		end,
		["TIB"] = function(p135)
			-- upvalues: (ref) v_u_7, (ref) v_u_2, (ref) v_u_9, (ref) v_u_3
			local v136 = v_u_7.Uro.IceBreaker:Clone()
			v136:ScaleTo(8)
			v136.SmallShard.Anchored = true
			v136.SmallShard.CFrame = p135 - Vector3.new(0, 3.5, 0)
			v136.Parent = workspace.Effects
			v_u_2:AddItem(v136, 4)
			local v137 = Instance.new("Highlight", v136)
			v137.DepthMode = Enum.HighlightDepthMode.Occluded
			v137.FillColor = Color3.fromRGB(255, 255, 255)
			v137.OutlineColor = Color3.fromRGB(255, 170, 255)
			v137.FillTransparency = 0.9
			v137.OutlineTransparency = 0.8
			v137.DepthMode = Enum.HighlightDepthMode.Occluded
			if (workspace.CurrentCamera.CFrame.Position - p135.Position).Magnitude < 200 then
				local v_u_138 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.HeavyHit)
				task.delay(1.5, function()
					-- upvalues: (copy) v_u_138
					v_u_138:StartFadeOut(0.3)
				end)
			end
			local v139 = v136.SmallShard.Size * 1.1
			v136.SmallShard.Size = v136.SmallShard.Size * 0.3
			v_u_3:Create(v136.SmallShard, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
				["Size"] = v139
			}):Play()
			task.wait(0.5)
			v_u_3:Create(v136.BigShard, TweenInfo.new(0.9, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
				["Size"] = v136.BigShard.Size * 1.2
			}):Play()
			v136.SmallShard.Transparency = 7
			v136.BigShard.Material = Enum.Material.Glass
			v136.BigShard.Transparency = 5
			if (workspace.CurrentCamera.CFrame.Position - p135.Position).Magnitude < 60 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
			end
			task.wait(0.5)
			local v140 = v136.SmallShard.CFrame
			v136.SmallShard.Material = Enum.Material.Plastic
			v136.BigShard.Material = Enum.Material.Plastic
			if _G.Settings.DesPHY then
				if (workspace.CurrentCamera.CFrame.Position - v140.Position).Magnitude > 200 then
					return
				end
				Random.new()
				local v141 = TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
				for _ = 1, 25 do
					local v142 = v_u_7.Gojo.Shard:Clone()
					local v143 = CFrame.Angles
					local v144 = math.random(-60, 60)
					local v145 = math.rad(v144)
					local v146 = math.random(-60, 60)
					local v147 = (v140 * v143(v145, math.rad(v146), 0)).LookVector
					local v148 = math.random(10, 80) / 10
					local v149 = math.random(10, 80) / 10
					v142.Size = Vector3.new(0.2, v148, v149) * 8
					v142.CFrame = v140 * CFrame.new(math.random(-10, 10), math.random(-5, 10), 0)
					v142.CFrame = v142.CFrame * CFrame.Angles(0, math.random(0, 3.141592653589793), 0)
					v142.CanCollide = true
					v142.CollisionGroup = "Effects"
					v142.Parent = v136
					v142.Transparency = 5
					v142.Material = Enum.Material.Glass
					local v150 = math.random(-50, 50)
					local v151 = math.random(-50, 50)
					local v152 = math.random
					v142.RotVelocity = Vector3.new(v150, v151, v152(-50, 50))
					v142.Velocity = v147 * math.random(30, 60)
					v_u_3:Create(v142, v141, {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_2:AddItem(v142, 2)
				end
			end
		end,
		["TIBShock"] = function(p153, p154)
			-- upvalues: (ref) v_u_7, (ref) v_u_1, (ref) v_u_4, (ref) v_u_9
			for _, v155 in v_u_7.Misc.M.Awk.mokultMeh["3"]:GetChildren() do
				v155:PivotTo(CFrame.new(p154) + Vector3.new(0, 10, 0))
				v_u_1.GetController("MokouController"):ArcTween(v155.Start, true)
			end
			if (workspace.CurrentCamera.CFrame.Position - p154).Magnitude < 150 or v_u_4.Character == p153 then
				if v_u_4.Character == p153 or (workspace.CurrentCamera.CFrame.Position - p154).Magnitude < 60 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.SnapOh)
					if _G.Settings.Flash == true then
						task.spawn(function()
							-- upvalues: (ref) v_u_7
							local v156 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
							v156.TintColor = Color3.new(1, 1, 1)
							v156.Parent = game.Lighting
							task.wait(0.04)
							v156.Brightness = 200
							v156.Contrast = -1000
							task.wait(0.04)
							v156:Destroy()
						end)
						return
					end
				else
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end,
		["SkyGrab"] = function(p157)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_6
			local v158 = p157:FindFirstChild("HumanoidRootPart")
			if v158 then
				local v_u_159 = v_u_7.Uro.GlassPlane:Clone()
				for _, v160 in v_u_159:GetDescendants() do
					if not v160:IsA("BasePart") or v160.Name == "GlassMain" then
						continue
					end
					v160.Transparency = 1
					v_u_3:Create(v160, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {
						["Transparency"] = 5
					}):Play()
				end
				v_u_2:AddItem(v_u_159, 1.375)
				v_u_2:AddItem(v_u_159.Weld, 1.375)
				v_u_159.Parent = workspace.Effects
				v_u_159.Weld.Part0 = v158
				v_u_159.Weld.Part1 = v_u_159.GlassMain
				v_u_159.Weld.Parent = p157
				v_u_159.AnimationController.Animator:LoadAnimation(v_u_6.Uro.ThinIceBreaker2Sky):Play(0)
				local v161 = Instance.new("Highlight", v_u_159)
				v161.DepthMode = Enum.HighlightDepthMode.Occluded
				v161.FillTransparency = 1
				v161.OutlineTransparency = 1
				v161.OutlineColor = Color3.fromRGB(255, 170, 255)
				v161.DepthMode = Enum.HighlightDepthMode.Occluded
				v_u_3:Create(v161, TweenInfo.new(1.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {
					["OutlineTransparency"] = 0.8
				}):Play()
				local v_u_162 = Instance.new("NumberValue")
				v_u_162.Value = 1.5
				v_u_162:GetPropertyChangedSignal("Value"):Connect(function()
					-- upvalues: (copy) v_u_159, (copy) v_u_162
					v_u_159:ScaleTo(v_u_162.Value)
				end)
				task.wait(0.5)
				v_u_3:Create(v_u_162, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {
					["Value"] = 0.6
				}):Play()
			end
		end,
		["Flight"] = function(p163)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_4
			local v_u_164 = p163:FindFirstChild("HumanoidRootPart")
			if v_u_164 then
				v_u_12:PlaySound(v_u_8.Misc.Dash, v_u_164, game.SoundService.Effect)
				for v165 = 1, 5 do
					task.delay(v165 * 0.075, function()
						-- upvalues: (ref) v_u_7, (copy) v_u_164, (ref) v_u_3, (ref) v_u_2
						local v166 = v_u_7.Itadori.Shock:Clone()
						v166.CFrame = CFrame.lookAlong(v_u_164.Position, v_u_164.Velocity) * CFrame.Angles(1.5707963267948966, 0, 0)
						v166.Transparency = 0.3
						v166.Parent = workspace.Effects
						v_u_3:Create(v166, TweenInfo.new(0.15), {
							["Size"] = Vector3.new(20, 0, 20),
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v166, 0.15)
					end)
				end
				if v_u_4.Character == p163 then
					local v167 = workspace.CurrentCamera
					local v168 = v167.CFrame.LookVector:Dot(Vector3.new(0, 1, 0)) < -0.8 and 300 or 100
					v_u_164.Velocity = v167.CFrame.LookVector * v168
				end
			end
		end,
		["Dissapear"] = function(p_u_169, p170)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v171 = p_u_169:FindFirstChild("HumanoidRootPart")
			if v171 then
				v_u_12:PlaySound(v_u_8.Uro.Dissapear, v171, game.SoundService.Effect)
				local v_u_172 = {}
				for _, v173 in p_u_169:GetDescendants() do
					if not v173:IsA("BasePart") and (not v173:IsA("Decal") or v173.Transparency == 1) then
						continue
					end
					v_u_172[v173] = v173.Transparency
					v173.Transparency = 1
				end
				p170.Destroying:Connect(function()
					-- upvalues: (copy) p_u_169, (ref) v_u_172
					for _, v174 in p_u_169:GetDescendants() do
						if not v_u_172[v174] then
							continue
						end
						v174.Transparency = v_u_172[v174]
					end
					v_u_172 = nil
				end)
			end
		end,
		["Reappear"] = function(p175)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_3, (ref) v_u_7, (ref) v_u_2
			local v176 = p175:FindFirstChild("HumanoidRootPart")
			if v176 then
				v_u_12:PlaySound(v_u_8.Uro.Reapper, v176, game.SoundService.Effect)
				local v177 = v176:FindFirstChild("RootJoint")
				if v177 then
					local v178 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 1, -0)
					v177.C0 = v178 * CFrame.new(4, 0, 0)
					v_u_3:Create(v177, TweenInfo.new(0.5, Enum.EasingStyle.Elastic), {
						["C0"] = v178
					}):Play()
				end
				local v179 = v_u_7.Gojo.Teleport:Clone()
				v179.CFrame = v176.CFrame + Vector3.new(0, 2, 0)
				v179.Parent = workspace.Effects
				v_u_2:AddItem(v179, 1.1)
				v179.Floor.Dust:Emit(30)
				v179.Lines:Emit(30)
				local v180 = Instance.new("Model", workspace.Effects)
				local v181 = Instance.new("Highlight")
				v181.DepthMode = Enum.HighlightDepthMode.Occluded
				v181.FillColor = Color3.fromRGB(255, 255, 255)
				v181.FillTransparency = 1
				v181.OutlineTransparency = 1
				v181.Parent = v180
				v_u_2:AddItem(v180, 0.4)
				for _ = 1, 10 do
					local v182 = v_u_7.Uro.AirDistort2:Clone()
					v182.Size = Vector3.new(10, 10, 10)
					v182.CFrame = v176.CFrame * CFrame.new(math.random(-30, 30) / 10, math.random(-30, 30) / 10, math.random(-30, 30) / 10)
					local v183 = v_u_3
					local v184 = TweenInfo.new(math.random(25, 40) / 100)
					local v185 = {
						["Transparency"] = 1,
						["Size"] = nil,
						["Orientation"] = nil
					}
					local v186 = math.random(0, 20)
					v185.Size = Vector3.new(v186, 0, 0)
					local v187 = math.random(-180, 180)
					local v188 = math.random(-180, 180)
					local v189 = math.random
					v185.Orientation = Vector3.new(v187, v188, v189(-180, 180))
					v183:Create(v182, v184, v185):Play()
					v182.Parent = v180
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p191, ...)
		-- upvalues: (copy) v_u_190
		local v192 = v_u_190[p191]
		if v192 then
			v192(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("UroService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13