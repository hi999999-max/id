-- Original instance: Players.YouNeverSeenThat.PlayerScripts.PlayerModule.ControlModule.VRNavigation
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = game:GetService("VRService")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("RunService")
local v4 = game:GetService("Players")
local v_u_5 = game:GetService("PathfindingService")
local v_u_6 = game:GetService("ContextActionService")
local v_u_7 = game:GetService("StarterGui")
local v8 = script.Parent.Parent:WaitForChild("CommonUtils")
local v9 = require(v8:WaitForChild("FlagUtil"))
local v_u_10 = nil
local v_u_11 = v4.LocalPlayer
local v_u_12 = RaycastParams.new()
v_u_12.FilterType = Enum.RaycastFilterType.Exclude
local v_u_13 = v9.getUserFlag("UserRaycastUpdateAPI2")
local v_u_14 = Instance.new("BindableEvent")
v_u_14.Name = "MovementUpdate"
v_u_14.Parent = script
coroutine.wrap(function()
	-- upvalues: (ref) v_u_10
	local v15 = script.Parent:WaitForChild("PathDisplay")
	if v15 then
		v_u_10 = require(v15)
	end
end)()
local v_u_16 = require(script.Parent:WaitForChild("BaseCharacterController"))
local v_u_17 = setmetatable({}, v_u_16)
v_u_17.__index = v_u_17
function v_u_17.new(p18) -- name: new
	-- upvalues: (copy) v_u_16, (copy) v_u_17
	local v19 = v_u_16.new()
	local v20 = v_u_17
	local v21 = setmetatable(v19, v20)
	v21.CONTROL_ACTION_PRIORITY = p18
	v21.navigationRequestedConn = nil
	v21.heartbeatConn = nil
	v21.currentDestination = nil
	v21.currentPath = nil
	v21.currentPoints = nil
	v21.currentPointIdx = 0
	v21.expectedTimeToNextPoint = 0
	v21.timeReachedLastPoint = tick()
	v21.moving = false
	v21.isJumpBound = false
	v21.moveLatch = false
	v21.userCFrameEnabledConn = nil
	return v21
end
function v_u_17.SetLaserPointerMode(_, p_u_22) -- name: SetLaserPointerMode
	-- upvalues: (copy) v_u_7
	local function v23()
		-- upvalues: (ref) v_u_7, (copy) p_u_22
		v_u_7:SetCore("VRLaserPointerMode", p_u_22)
	end
	pcall(v23)
end
function v_u_17.GetLocalHumanoid(_) -- name: GetLocalHumanoid
	-- upvalues: (copy) v_u_11
	local v24 = v_u_11.Character
	if v24 then
		for _, v25 in pairs(v24:GetChildren()) do
			if not v25:IsA("Humanoid") then
				continue
			end
			return v25
		end
		return nil
	end
end
function v_u_17.HasBothHandControllers(_) -- name: HasBothHandControllers
	-- upvalues: (copy) v_u_1
	local v26 = v_u_1:GetUserCFrameEnabled(Enum.UserCFrame.RightHand)
	if v26 then
		v26 = v_u_1:GetUserCFrameEnabled(Enum.UserCFrame.LeftHand)
	end
	return v26
end
function v_u_17.HasAnyHandControllers(_) -- name: HasAnyHandControllers
	-- upvalues: (copy) v_u_1
	return v_u_1:GetUserCFrameEnabled(Enum.UserCFrame.RightHand) or v_u_1:GetUserCFrameEnabled(Enum.UserCFrame.LeftHand)
end
function v_u_17.IsMobileVR(_) -- name: IsMobileVR
	-- upvalues: (copy) v_u_2
	return v_u_2.TouchEnabled
end
function v_u_17.HasGamepad(_) -- name: HasGamepad
	-- upvalues: (copy) v_u_2
	return v_u_2.GamepadEnabled
end
function v_u_17.ShouldUseNavigationLaser(p27) -- name: ShouldUseNavigationLaser
	if p27:IsMobileVR() then
		return true
	elseif p27:HasBothHandControllers() then
		return false
	else
		return p27:HasAnyHandControllers() and true or not p27:HasGamepad()
	end
end
function v_u_17.StartFollowingPath(p28, p29) -- name: StartFollowingPath
	-- upvalues: (copy) v_u_14
	currentPath = p29
	currentPoints = currentPath:GetPointCoordinates()
	currentPointIdx = 1
	moving = true
	timeReachedLastPoint = tick()
	local v30 = p28:GetLocalHumanoid()
	if v30 and (v30.Torso and #currentPoints >= 1) then
		expectedTimeToNextPoint = (currentPoints[1] - v30.Torso.Position).magnitude / v30.WalkSpeed
	end
	v_u_14:Fire("targetPoint", p28.currentDestination)
end
function v_u_17.GoToPoint(p31, p32) -- name: GoToPoint
	-- upvalues: (copy) v_u_14
	currentPath = true
	currentPoints = { p32 }
	currentPointIdx = 1
	moving = true
	local v33 = p31:GetLocalHumanoid()
	local v34 = (v33.Torso.Position - p32).magnitude / v33.WalkSpeed
	timeReachedLastPoint = tick()
	expectedTimeToNextPoint = v34
	v_u_14:Fire("targetPoint", p32)
end
function v_u_17.StopFollowingPath(p35) -- name: StopFollowingPath
	currentPath = nil
	currentPoints = nil
	currentPointIdx = 0
	moving = false
	p35.moveVector = Vector3.new(0, 0, 0)
end
function v_u_17.TryComputePath(_, p36, p37) -- name: TryComputePath
	-- upvalues: (copy) v_u_5
	local v38 = nil
	local v39 = 0
	while not v38 and v39 < 5 do
		v38 = v_u_5:ComputeSmoothPathAsync(p36, p37, 200)
		v39 = v39 + 1
		if v38.Status == Enum.PathStatus.ClosestNoPath or v38.Status == Enum.PathStatus.ClosestOutOfRange then
			return nil
		end
		if v38 and v38.Status == Enum.PathStatus.FailStartNotEmpty then
			p36 = p36 + (p37 - p36).Unit
			v38 = nil
		end
		if not v38 or v38.Status ~= Enum.PathStatus.FailFinishNotEmpty then
			continue
		end
		p37 = p37 + Vector3.new(0, 1, 0)
		v38 = nil
	end
	return v38
end
function v_u_17.OnNavigationRequest(p40, p41, _) -- name: OnNavigationRequest
	-- upvalues: (ref) v_u_10
	local v42 = p41.Position
	local v43 = p40.currentDestination
	local v44 = v42.x
	local v45
	if v44 == v44 and v44 ~= (1 / 0) then
		v45 = v44 ~= (-1 / 0)
	else
		v45 = false
	end
	if v45 then
		local v46 = v42.y
		if v46 == v46 and v46 ~= (1 / 0) then
			v45 = v46 ~= (-1 / 0)
		else
			v45 = false
		end
		if v45 then
			local v47 = v42.z
			if v47 == v47 and v47 ~= (1 / 0) then
				v45 = v47 ~= (-1 / 0)
			else
				v45 = false
			end
		end
	end
	if v45 then
		p40.currentDestination = v42
		local v48 = p40:GetLocalHumanoid()
		if v48 and v48.Torso then
			local v49 = v48.Torso.Position
			if (p40.currentDestination - v49).magnitude < 12 then
				p40:GoToPoint(p40.currentDestination)
			elseif v43 and (p40.currentDestination - v43).magnitude <= 4 then
				if moving then
					p40.currentPoints[#currentPoints] = p40.currentDestination
					return
				end
				p40:GoToPoint(p40.currentDestination)
			else
				local v50 = p40:TryComputePath(v49, p40.currentDestination)
				if v50 then
					p40:StartFollowingPath(v50)
					if v_u_10 then
						v_u_10.setCurrentPoints(p40.currentPoints)
						v_u_10.renderPath()
						return
					end
				else
					p40:StopFollowingPath()
					if v_u_10 then
						v_u_10.clearRenderedPath()
						return
					end
				end
			end
		else
			return
		end
	else
		return
	end
end
function v_u_17.OnJumpAction(p51, _, p52, _) -- name: OnJumpAction
	if p52 == Enum.UserInputState.Begin then
		p51.isJumping = true
	end
	return Enum.ContextActionResult.Sink
end
function v_u_17.BindJumpAction(p_u_53, p54) -- name: BindJumpAction
	-- upvalues: (copy) v_u_6
	if p54 then
		if not p_u_53.isJumpBound then
			p_u_53.isJumpBound = true
			v_u_6:BindActionAtPriority("VRJumpAction", function()
				-- upvalues: (copy) p_u_53
				return p_u_53:OnJumpAction()
			end, false, p_u_53.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonA)
			return
		end
	elseif p_u_53.isJumpBound then
		p_u_53.isJumpBound = false
		v_u_6:UnbindAction("VRJumpAction")
	end
end
function v_u_17.ControlCharacterGamepad(p55, _, p56, p57) -- name: ControlCharacterGamepad
	-- upvalues: (ref) v_u_10, (copy) v_u_14
	if p57.KeyCode == Enum.KeyCode.Thumbstick1 then
		if p56 ~= Enum.UserInputState.Cancel then
			if p56 == Enum.UserInputState.End then
				p55.moveVector = Vector3.new(0, 0, 0)
				if p55:ShouldUseNavigationLaser() then
					p55:BindJumpAction(false)
					p55:SetLaserPointerMode("Navigation")
				end
				if p55.moveLatch then
					p55.moveLatch = false
					v_u_14:Fire("offtrack")
				end
			else
				p55:StopFollowingPath()
				if v_u_10 then
					v_u_10.clearRenderedPath()
				end
				if p55:ShouldUseNavigationLaser() then
					p55:BindJumpAction(true)
					p55:SetLaserPointerMode("Hidden")
				end
				if p57.Position.magnitude > 0.22 then
					local v58 = p57.Position.X
					local v59 = -p57.Position.Y
					p55.moveVector = Vector3.new(v58, 0, v59)
					if p55.moveVector.magnitude > 0 then
						local v60 = p55.moveVector.unit
						local v61 = p57.Position.magnitude
						p55.moveVector = v60 * math.min(1, v61)
					end
					p55.moveLatch = true
				end
			end
			return Enum.ContextActionResult.Sink
		end
		p55.moveVector = Vector3.new(0, 0, 0)
	end
end
function v_u_17.OnHeartbeat(p62, p63) -- name: OnHeartbeat
	-- upvalues: (ref) v_u_10, (copy) v_u_13, (copy) v_u_12, (copy) v_u_14
	local v64 = p62.moveVector
	local v65 = p62:GetLocalHumanoid()
	if v65 and v65.Torso then
		if p62.moving and p62.currentPoints then
			local v66 = v65.Torso.Position
			local v67 = (currentPoints[1] - v66) * Vector3.new(1, 0, 1)
			local v68 = v67.magnitude
			local v69 = v67 / v68
			if v68 < 1 then
				local v70 = currentPoints[1]
				local v71 = 0
				for v72, v73 in pairs(currentPoints) do
					if v72 == 1 then
						continue
					end
					v71 = v71 + (v73 - v70).magnitude / v65.WalkSpeed
					v70 = v73
				end
				table.remove(currentPoints, 1)
				currentPointIdx = currentPointIdx + 1
				if #currentPoints == 0 then
					p62:StopFollowingPath()
					if v_u_10 then
						v_u_10.clearRenderedPath()
					end
					return
				end
				if v_u_10 then
					v_u_10.setCurrentPoints(currentPoints)
					v_u_10.renderPath()
				end
				expectedTimeToNextPoint = (currentPoints[1] - v66).magnitude / v65.WalkSpeed
				timeReachedLastPoint = tick()
			else
				if v_u_13 then
					v_u_12.FilterDescendantsInstances = { game.Players.LocalPlayer.Character, workspace.CurrentCamera }
					local v74 = workspace:Raycast(v66 - Vector3.new(0, 1, 0), v69 * 3, v_u_12)
					if v74 then
						local v75 = workspace:Raycast(v74.Position + v69 * 0.5 + Vector3.new(0, 100, 0), Vector3.new(-0, -100, -0), v_u_12).Position.Y - v66.Y
						if v75 < 6 and v75 > -2 then
							v65.Jump = true
						end
					end
				else
					local v76 = { game.Players.LocalPlayer.Character, workspace.CurrentCamera }
					local v77 = Ray.new(v66 - Vector3.new(0, 1, 0), v69 * 3)
					local v78, v79, _ = workspace:FindPartOnRayWithIgnoreList(v77, v76)
					if v78 then
						local v80 = Ray.new(v79 + v69 * 0.5 + Vector3.new(0, 100, 0), Vector3.new(-0, -100, -0))
						local _, v81, _ = workspace:FindPartOnRayWithIgnoreList(v80, v76)
						local v82 = v81.Y - v66.Y
						if v82 < 6 and v82 > -2 then
							v65.Jump = true
						end
					end
				end
				if tick() - timeReachedLastPoint > expectedTimeToNextPoint + 2 then
					p62:StopFollowingPath()
					if v_u_10 then
						v_u_10.clearRenderedPath()
					end
					v_u_14:Fire("offtrack")
				end
				v64 = p62.moveVector:Lerp(v69, p63 * 10)
			end
		end
		local v83 = v64.x
		local v84
		if v83 == v83 and v83 ~= (1 / 0) then
			v84 = v83 ~= (-1 / 0)
		else
			v84 = false
		end
		if v84 then
			local v85 = v64.y
			if v85 == v85 and v85 ~= (1 / 0) then
				v84 = v85 ~= (-1 / 0)
			else
				v84 = false
			end
			if v84 then
				local v86 = v64.z
				if v86 == v86 and v86 ~= (1 / 0) then
					v84 = v86 ~= (-1 / 0)
				else
					v84 = false
				end
			end
		end
		if v84 then
			p62.moveVector = v64
		end
	end
end
function v_u_17.OnUserCFrameEnabled(p87) -- name: OnUserCFrameEnabled
	if p87:ShouldUseNavigationLaser() then
		p87:BindJumpAction(false)
		p87:SetLaserPointerMode("Navigation")
	else
		p87:BindJumpAction(true)
		p87:SetLaserPointerMode("Hidden")
	end
end
function v_u_17.Enable(p_u_88, p89) -- name: Enable
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_6
	p_u_88.moveVector = Vector3.new(0, 0, 0)
	p_u_88.isJumping = false
	if p89 then
		p_u_88.navigationRequestedConn = v_u_1.NavigationRequested:Connect(function(p90, p91)
			-- upvalues: (copy) p_u_88
			p_u_88:OnNavigationRequest(p90, p91)
		end)
		p_u_88.heartbeatConn = v_u_3.Heartbeat:Connect(function(p92)
			-- upvalues: (copy) p_u_88
			p_u_88:OnHeartbeat(p92)
		end)
		v_u_6:BindAction("MoveThumbstick", function(p93, p94, p95)
			-- upvalues: (copy) p_u_88
			return p_u_88:ControlCharacterGamepad(p93, p94, p95)
		end, false, p_u_88.CONTROL_ACTION_PRIORITY, Enum.KeyCode.Thumbstick1)
		v_u_6:BindActivate(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonR2)
		p_u_88.userCFrameEnabledConn = v_u_1.UserCFrameEnabled:Connect(function()
			-- upvalues: (copy) p_u_88
			p_u_88:OnUserCFrameEnabled()
		end)
		p_u_88:OnUserCFrameEnabled()
		v_u_1:SetTouchpadMode(Enum.VRTouchpad.Left, Enum.VRTouchpadMode.VirtualThumbstick)
		v_u_1:SetTouchpadMode(Enum.VRTouchpad.Right, Enum.VRTouchpadMode.ABXY)
		p_u_88.enabled = true
	else
		p_u_88:StopFollowingPath()
		v_u_6:UnbindAction("MoveThumbstick")
		v_u_6:UnbindActivate(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonR2)
		p_u_88:BindJumpAction(false)
		p_u_88:SetLaserPointerMode("Disabled")
		if p_u_88.navigationRequestedConn then
			p_u_88.navigationRequestedConn:Disconnect()
			p_u_88.navigationRequestedConn = nil
		end
		if p_u_88.heartbeatConn then
			p_u_88.heartbeatConn:Disconnect()
			p_u_88.heartbeatConn = nil
		end
		if p_u_88.userCFrameEnabledConn then
			p_u_88.userCFrameEnabledConn:Disconnect()
			p_u_88.userCFrameEnabledConn = nil
		end
		p_u_88.enabled = false
	end
end
return v_u_17