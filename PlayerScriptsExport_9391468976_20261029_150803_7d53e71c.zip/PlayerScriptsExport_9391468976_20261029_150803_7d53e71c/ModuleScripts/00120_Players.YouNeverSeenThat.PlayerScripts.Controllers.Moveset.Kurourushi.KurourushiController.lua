-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Kurourushi.KurourushiController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local v_u_7 = v6.Animations
local v_u_8 = v6.Utils
local v_u_9 = v6.Sounds
local v_u_10 = require(v6.Modules.CameraShaker)
local v_u_11 = require(v6.Modules.BloodyZee)
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = v_u_1.CreateController({
	["Name"] = "KurourushiController"
})
function v_u_16.PlayArms(_, p_u_17, p18, p19) -- name: PlayArms
	local v20 = p_u_17.SetAssets:FindFirstChild("HeianArms")
	if v20 then
		local v21 = v20:FindFirstChild("HeianArmsModel")
		if v21 then
			if p18 == nil then
				return v21
			end
			local v_u_22 = v21.Humanoid:LoadAnimation(p18)
			local v_u_23 = nil
			for _, v24 in p_u_17.Humanoid:GetPlayingAnimationTracks() do
				if v24.Animation.AnimationId ~= p19.AnimationId then
					continue
				end
				v_u_23 = v24
			end
			for _, v25 in v21.Humanoid:GetPlayingAnimationTracks() do
				v25:Stop(0)
			end
			v_u_22:Play(0)
			task.spawn(function()
				-- upvalues: (ref) v_u_23, (copy) v_u_22, (copy) p_u_17
				if v_u_23 then
					task.wait()
					if v_u_22.Speed ~= v_u_23.Speed then
						v_u_22:AdjustSpeed(v_u_23.Speed)
					end
					if v_u_22.TimePosition ~= v_u_23.TimePosition then
						v_u_22.TimePosition = v_u_23.TimePosition
					end
					if v_u_23.IsPlaying and (v_u_22.IsPlaying and p_u_17.Parent ~= nil) then
						continue
					end
					v_u_22:Stop(0.25)
				end
			end)
			return v_u_22, v21
		end
	end
end
function v_u_16.KnitStart(p_u_26) -- name: KnitStart
	-- upvalues: (ref) v_u_14, (copy) v_u_9, (copy) v_u_8, (copy) v_u_3, (copy) v_u_4, (copy) v_u_7, (copy) v_u_5, (copy) v_u_10, (copy) v_u_11, (copy) v_u_2, (copy) v_u_16, (ref) v_u_12, (ref) v_u_13, (ref) v_u_15
	local v_u_303 = {
		["Hit"] = function(p27, p28, p29, p30)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3
			local v31 = p27:FindFirstChild("HumanoidRootPart")
			if v31 then
				local v32 = p28:FindFirstChild("HumanoidRootPart")
				if v32 then
					v_u_14:Flash(p28, Color3.new(1, 1, 1))
					if (p29 == 1 or p29 == 3) and not p30 then
						v_u_14:PlaySound(v_u_9.Kurourushi.M1["Hit" .. math.random(1, 3)], v32, game.SoundService.Effect)
					else
						v_u_14:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit" .. p29), v32, game.SoundService.Effect)
					end
					local v33 = {
						[1] = CFrame.Angles(0, 0, -0.08726646259971647),
						[3] = CFrame.Angles(0, 0, -0.17453292519943295)
					}
					if v33[p29] and not p30 then
						local v34 = v_u_8.Yuta.SlashHit:Clone()
						v34.CFrame = CFrame.lookAlong(v32.Position + Vector3.new(0, 0.75, 0), v31.CFrame.LookVector)
						v34.CFrame = v34.CFrame * v33[p29]
						v34.Slash.Color = ColorSequence.new(Color3.fromRGB(101, 35, 44))
						v34.Slash.Squash = NumberSequence.new(-1, -10)
						v34.Slash.Size = NumberSequence.new(1.5, 0)
						v34.Parent = workspace.Effects
						v_u_3:AddItem(v34, 0.5)
						v34.Slash:Emit(5)
					end
				else
					return
				end
			else
				return
			end
		end,
		["ChaseHit"] = function(p35, p36)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3
			local v37 = p35:FindFirstChild("HumanoidRootPart")
			if v37 then
				local v38 = p36:FindFirstChild("HumanoidRootPart")
				if v38 then
					v_u_14:Flash(p36, Color3.new(1, 1, 1))
					v_u_14:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit3"), v38, game.SoundService.Effect)
					local v39 = v_u_8.ChaseHit:Clone()
					local v40 = CFrame.new
					local v41 = v38.Position
					local v42 = v37.Position.X
					local v43 = v38.Position.Y
					local v44 = v37.Position.Z
					v39.CFrame = v40(v41, (Vector3.new(v42, v43, v44))) * CFrame.Angles(0, 3.141592653589793, 0)
					v39.Parent = workspace.Effects
					v39.Ring:Emit(7)
					v39.Sparks:Emit(12)
					v_u_3:AddItem(v39, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p45)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_14, (ref) v_u_9, (copy) p_u_26, (ref) v_u_7
			local v46 = p45.HumanoidRootPart
			if v46 then
				local v47 = v_u_8.Gojo.LapseBlue.Throw:Clone()
				v47.CFrame = v46.CFrame * CFrame.new(0, 1, -4)
				v47.Size = Vector3.new(0, 0, 2)
				v47.Parent = workspace.Effects
				v_u_4:Create(v47, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v47, 0.3)
				v_u_14:PlaySound(v_u_9.Misc.Chase, v46, game.SoundService.Effect)
				v_u_14:DustTrail(p45, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
				p_u_26:PlayArms(p45, v_u_7.Kurourushi.ArmsMelee.Chase, v_u_7.Kurourushi.Melee.Chase)
			end
		end,
		["Swing"] = function(p48, p49, _, p50)
			-- upvalues: (ref) v_u_9, (ref) v_u_14
			local v51 = p48:FindFirstChild("HumanoidRootPart")
			if v51 then
				if p49 and (v_u_9.Kurourushi.M1:FindFirstChild("Swing" .. p49) and not p50) then
					v_u_14:PlaySound(v_u_9.Kurourushi.M1["Swing" .. p49], v51, game.SoundService.Effect)
				else
					v_u_14:PlaySound(v_u_9.Misc.Swing.Fist, v51, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Swing2"] = function(p52, p53, p54, p55)
			-- upvalues: (ref) v_u_14, (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_7, (copy) p_u_26
			local v_u_56 = p52.SetAssets:FindFirstChild("FesteringSword")
			if (p53 == 1 or p53 == 3) and v_u_56 then
				task.spawn(function()
					-- upvalues: (ref) v_u_8, (copy) v_u_56, (ref) v_u_3, (ref) v_u_4
					local v57 = v_u_8.Kurourushi.CombatTrail:Clone()
					local v58 = Instance.new("Model")
					v57.Parent = v58
					v58:ScaleTo(v_u_56:GetScale())
					v_u_3:AddItem(v58, 0.1)
					v57.Weld.Part0 = v_u_56.Union
					v57.Parent = workspace.Effects
					task.wait(0.37)
					v57.Trail.Enabled = false
					v_u_4:Create(v57, TweenInfo.new(0.1), {
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v57, 0.2)
				end)
			elseif p53 == 2 then
				local v59 = p52["Left Arm"]
				local v60 = Color3.fromRGB(101, 35, 44)
				if v59.Transparency ~= 1 then
					v_u_14:ArmFlash(v59, v60, 0.3)
				end
			elseif p53 == 4 and p54 == nil then
				local v61 = p52["Left Arm"]
				local v62 = Color3.fromRGB(101, 35, 44)
				if v61.Transparency ~= 1 then
					v_u_14:ArmFlash(v61, v62, 0.4)
				end
				local v63 = p52["Right Arm"]
				local v64 = Color3.fromRGB(101, 35, 44)
				if v63.Transparency ~= 1 then
					v_u_14:ArmFlash(v63, v64, 0.4)
				end
			end
			local v65 = nil
			local v66 = p55 and v_u_7.Kurourushi.ArmsDetach or v_u_7.Kurourushi.ArmsMelee
			local v67 = p55 and v_u_7.Kurourushi.MeleeDetach or v_u_7.Kurourushi.Melee
			if p54 and v66:FindFirstChild(p54) then
				local v68
				v68, v65 = p_u_26:PlayArms(p52, v66[p54], v67[p54])
			elseif v66:FindFirstChild("Melee" .. p53) then
				local v69
				v69, v65 = p_u_26:PlayArms(p52, v66["Melee" .. p53], v67["Melee" .. p53])
			end
			if v65 then
				if p54 == "Down" or (p54 == "Up" or p53 == 4) then
					local v70 = v65["Left Arm"]
					local v71 = Color3.fromRGB(101, 35, 44)
					if v70.Transparency ~= 1 then
						v_u_14:ArmFlash(v70, v71, 0.4)
					end
					local v72 = v65["Right Arm"]
					local v73 = Color3.fromRGB(101, 35, 44)
					if v72.Transparency ~= 1 then
						v_u_14:ArmFlash(v72, v73, 0.4)
					end
				end
				if (p53 == 1 or p53 == 3) and p55 then
					local v74 = v65["Right Arm"]
					local v75 = Color3.fromRGB(101, 35, 44)
					if v74.Transparency ~= 1 then
						v_u_14:ArmFlash(v74, v75, 0.3)
					end
				end
				if p53 == 2 then
					local v76 = v65["Left Arm"]
					local v77 = Color3.fromRGB(101, 35, 44)
					if v76.Transparency == 1 then
						return
					end
					v_u_14:ArmFlash(v76, v77, 0.3)
				end
			end
		end,
		["Launch"] = function(p78, p79)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_14, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v80 = p78:FindFirstChild("HumanoidRootPart")
			if v80 then
				local v81 = v_u_8.Gojo.LapseBlue.Throw:Clone()
				v81.CFrame = CFrame.new(v80.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v81.Size = Vector3.new(0, 0, 5)
				v81.Parent = workspace.Effects
				v_u_4:Create(v81, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v81.Position + Vector3.new(0, p79, 0)
				}):Play()
				v_u_3:AddItem(v81, 0.3)
				if p79 < 0 then
					v_u_14:PlaySound(v_u_9.Megumi.Mahoraga.Throw.Break, v80, game.SoundService.Effect)
					v_u_14:DustBreak(v80.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v80.Position) < 20 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
					end
				end
			end
		end,
		["InjuryTick"] = function(_, p82)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			local v83 = p82:FindFirstChild("HumanoidRootPart")
			if v83 then
				v_u_14:Flash(p82, Color3.fromRGB(141, 49, 63), 0.5)
				v_u_14:PlaySound(v_u_9.Kurourushi.Tick["Tick" .. math.random(1, 3)], v83, game.SoundService.Effect)
			end
		end,
		["Injury"] = function(p84, p_u_85, p86)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3
			local v_u_87 = p84:FindFirstChild("HumanoidRootPart")
			if v_u_87 then
				local v_u_88 = p_u_85:FindFirstChild("HumanoidRootPart")
				if v_u_88 then
					for _ = 1, p86 or 1 do
						v_u_14:PlaySound(v_u_9.Kurourushi["Egg" .. math.random(1, 4)], v_u_88, game.SoundService.Effect)
						task.spawn(function()
							-- upvalues: (copy) p_u_85, (copy) v_u_87, (copy) v_u_88, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3
							local v89 = p_u_85.Torso
							local v90 = (v_u_87.Position - v_u_88.Position).Unit
							local v91 = v_u_88.CFrame:VectorToObjectSpace(v90)
							local v92 = (math.random() - 0.5 + v91.X * 0.8 * 0.5) * v89.Size.X
							local v93 = -v89.Size.X / 2
							local v94 = v89.Size.X / 2
							math.clamp(v92, v93, v94)
							local v95 = (math.random() - 0.5 + v91.Y * 0.8 * 0.5) * v89.Size.Y
							local v96 = -v89.Size.Y / 2
							local v97 = v89.Size.Y / 2
							math.clamp(v95, v96, v97)
							local v98 = (math.random() - 0.5 + v91.Z * 0.8 * 0.5) * v89.Size.Z
							local v99 = -v89.Size.Z / 2
							local v100 = v89.Size.Z / 2
							math.clamp(v98, v99, v100)
							local v101 = CFrame.new(v92, v95, v98)
							for _ = 1, 5 do
								local v102 = v_u_8.Mahito.Morph:Clone()
								v102.Weld.Part0 = v89
								v102.Color = v89.Color
								v102.Weld.C0 = v101 * CFrame.new(math.random(-30, 30) / 100, math.random(-30, 30) / 100, 0)
								v102.Parent = workspace.Effects
								v102.Size = Vector3.new(1, 1, 1) * (math.random(7, 10) / 10)
								v_u_4:Create(v102, TweenInfo.new(math.random(20, 50) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
									["Size"] = Vector3.new(0, 0, 0)
								}):Play()
								v_u_3:AddItem(v102, 0.8)
								task.wait(0.035)
							end
						end)
						task.wait()
					end
				end
			else
				return
			end
		end,
		["InjuryHatch"] = function(p103, p104)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_5, (ref) v_u_10
			if p103:FindFirstChild("HumanoidRootPart") then
				local v105 = p104:FindFirstChild("HumanoidRootPart")
				if v105 then
					v_u_14:PlaySound(v_u_9.Kurourushi.Hatch, v105, game.SoundService.Effect)
					v_u_14:Flash(p104, Color3.fromRGB(118, 168, 92), 1)
					local v106 = { Color3.fromRGB(170, 170, 127), Color3.fromRGB(162, 170, 87), Color3.fromRGB(131, 131, 0) }
					local v107 = math.random(4, 7)
					local v_u_108 = p104.Torso
					task.spawn(function()
						-- upvalues: (copy) v_u_108, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3
						for _ = 1, 10 do
							local v109 = CFrame.new(math.random(-v_u_108.Size.X, v_u_108.Size.X) / 2, math.random(-v_u_108.Size.Y, v_u_108.Size.Y) / 2, math.random(-v_u_108.Size.Z, v_u_108.Size.Z) / 2)
							for _ = 1, 2 do
								local v110 = v_u_8.Mahito.Morph:Clone()
								v110.Weld.Part0 = v_u_108
								v110.Color = v_u_108.Color
								v110.Weld.C0 = v109 * CFrame.new(math.random(-30, 30) / 100, math.random(-30, 30) / 100, 0)
								v110.Parent = workspace.Effects
								v110.Size = Vector3.new(1, 1, 1) * (math.random(10, 15) / 10)
								v_u_4:Create(v110, TweenInfo.new(math.random(10, 40) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
									["Size"] = Vector3.new(0, 0, 0)
								}):Play()
								v_u_3:AddItem(v110, 0.8)
							end
							task.wait(0.05)
						end
					end)
					task.wait(0.8)
					if v_u_5.Character == p103 or v_u_5.Character == p104 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
					end
					v_u_14:PlaySound(v_u_9.Itadori.Dismantle.Explode, v105, game.SoundService.Effect)
					for _ = 1, 10 do
						local v_u_111 = v_u_8.Damage.Chunk:Clone()
						v_u_111.CFrame = v_u_108.CFrame
						v_u_111.Blood.Enabled = false
						local v112 = math.random(-60, 60)
						local v113 = math.random(-30, 60)
						local v114 = math.random
						v_u_111.Velocity = Vector3.new(v112, v113, v114(-60, 60))
						local v115 = math.random(-200, 200)
						local v116 = math.random(-200, 200)
						local v117 = math.random
						v_u_111.RotVelocity = Vector3.new(v115, v116, v117(-200, 200))
						v_u_111.Parent = workspace.Effects
						v_u_3:AddItem(v_u_111, 3)
						v_u_111.CollisionGroup = "Effects"
						task.delay(0.1, function()
							-- upvalues: (copy) v_u_111, (ref) v_u_4
							v_u_111.CanCollide = true
							task.wait(1.9)
							v_u_4:Create(v_u_111, TweenInfo.new(0.5), {
								["Size"] = Vector3.new(0, 0, 0)
							}):Play()
							v_u_111.Trail.Enabled = false
						end)
						if _G.Settings.Gore ~= false then
							continue
						end
						v_u_111.Color = Color3.fromRGB(255, 85, 255)
						v_u_111.Trail.Color = ColorSequence.new(Color3.fromRGB(255, 85, 255))
					end
					for _ = 1, v107 do
						local v_u_118 = v_u_8.Kurourushi.Bug:Clone()
						local v119 = v105.CFrame
						local v120 = CFrame.Angles
						local v121 = math.random(-360, 360)
						local v122 = math.rad(v121)
						local v123 = math.random(-360, 360)
						local v124 = math.rad(v123)
						local v125 = math.random(-360, 360)
						v_u_118:SetPrimaryPartCFrame(v119 * v120(v122, v124, (math.rad(v125))))
						local v126 = v_u_118["1"].CFrame.LookVector * math.random(30, 60)
						local v127 = math.random(30, 60)
						local v128 = v126 + Vector3.new(0, v127, 0)
						local v129 = v_u_118["1"]
						local v130 = math.random(-100, 100)
						local v131 = math.random(-100, 100)
						local v132 = math.random
						v129.RotVelocity = Vector3.new(v130, v131, v132(-100, 100))
						local v133 = v106[math.random(1, #v106)]
						for _, v134 in v_u_118:GetChildren() do
							v134.Color = v133
							v134.Velocity = v128
						end
						v_u_118.Parent = workspace.Effects
						v_u_3:AddItem(v_u_118, 3)
						task.delay(2, function()
							-- upvalues: (copy) v_u_118, (ref) v_u_4
							for _, v135 in v_u_118:GetDescendants() do
								if not (v135:IsA("BasePart") or v135:IsA("Decal")) then
									continue
								end
								v_u_4:Create(v135, TweenInfo.new(0.5), {
									["Transparency"] = 1
								}):Play()
							end
						end)
						for v136 = 2, 3 do
							local v137 = v_u_118[tostring(v136)]
							local v138 = v136 - 1
							local v139 = v_u_118[tostring(v138)]
							local v140 = Instance.new("Attachment", v137)
							local v141 = Instance.new("Attachment", v139)
							v140.Position = Vector3.new(0, 0, -0.525)
							v141.Position = Vector3.new(0, 0, 0.525)
							local v142 = Instance.new("BallSocketConstraint")
							v142.Attachment0 = v140
							v142.Attachment1 = v141
							v142.LimitsEnabled = true
							v142.Parent = v140
						end
					end
				end
			else
				return
			end
		end,
		["EatStart"] = function(p143)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (copy) p_u_26, (ref) v_u_7
			local v144 = p143:FindFirstChild("HumanoidRootPart")
			if v144 then
				v_u_14:PlaySound(v_u_9.Kurourushi.EatStart, v144, game.SoundService.Effect)
				local _, _ = p_u_26:PlayArms(p143, v_u_7.Kurourushi.EatArms, v_u_7.Kurourushi.Eat)
			end
		end,
		["RipArms"] = function(p145)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_11
			local v146 = p145:FindFirstChild("HumanoidRootPart")
			if v146 then
				v_u_14:PlaySound(v_u_9.Itadori.Dismantle.Explode, v146, game.SoundService.Effect)
				for _ = 1, 10 do
					v_u_11:Blood(p145["Right Arm"].CFrame, math.random(5, 80), 25, 25)
				end
				for _ = 1, 10 do
					v_u_11:Blood(p145["Left Arm"].CFrame, math.random(5, 80), 25, 25)
				end
			end
		end,
		["Eat"] = function(p147, p_u_148, p149)
			-- upvalues: (ref) v_u_4, (ref) v_u_11, (ref) v_u_14, (ref) v_u_9
			local v150 = p147:FindFirstChild("HumanoidRootPart")
			if v150 then
				if p_u_148:FindFirstChild("HumanoidRootPart") then
					local v_u_151 = p_u_148:FindFirstChild(p149)
					if v_u_151 then
						v_u_151.Transparency = 1
						(function(p152) -- name: removeAccessories
							-- upvalues: (copy) v_u_151, (copy) p_u_148
							local v153 = {
								["Head"] = {
									"HairAttachment",
									"HatAttachment",
									"FaceCenterAttachment",
									"FaceFrontAttachment"
								},
								["Torso"] = {
									"BodyBackAttachment",
									"BodyFrontAttachment",
									"NeckAttachment",
									"WaistFrontAttachment",
									"WaistCenterAttachment",
									"WaistBackAttachment",
									"LeftCollarAttachment",
									"RightCollarAttachment"
								},
								["Left Arm"] = { "LeftShoulderAttachment", "LeftGripAttachment" },
								["Right Arm"] = { "RightShoulderAttachment", "RightGripAttachment" }
							}
							for _, v154 in v_u_151:GetChildren() do
								if not v154:IsA("Decal") then
									continue
								end
								v154.Transparency = 1
							end
							for _, v155 in p_u_148:GetChildren() do
								if not v155:IsA("Accessory") then
									continue
								end
								local v156 = v155:FindFirstChild("Handle", true)
								if not v156 then
									continue
								end
								for _, v157 in v153[p152.Name] do
									if not v156:FindFirstChild(v157) then
										continue
									end
									v155:Destroy()
								end
							end
						end)(v_u_151)
						if v_u_151.Name == "Torso" then
							v_u_4:Create(p_u_148["Left Leg"], TweenInfo.new(0.5), {
								["Size"] = Vector3.new(0.7, 2, 0.7) * p_u_148:GetScale()
							}):Play()
							v_u_4:Create(p_u_148["Right Leg"], TweenInfo.new(0.5), {
								["Size"] = Vector3.new(0.7, 2, 0.7) * p_u_148:GetScale()
							}):Play()
							p_u_148.SetAssets:ClearAllChildren()
						end
						local v158 = v_u_151.Name == "Head" and v_u_151:FindFirstChildWhichIsA("Decal")
						if v158 then
							v158.Transparency = 1
						end
						for _, v159 in pairs(p_u_148.SetAssets:GetDescendants()) do
							if not (v159:IsA("Motor6D") or (v159:IsA("Weld") or v159:IsA("WeldConstraint"))) or v159.Part0 ~= v_u_151 then
								continue
							end
							v159.Parent:Destroy()
							v159:Destroy()
						end
						for _ = 1, 3 do
							v_u_11:Blood(p147.Head.CFrame, math.random(5, 80), 25, 25)
						end
						v_u_14:PlaySound(v_u_9.Mahito.Eat, v150, game.SoundService.Effect).TimePosition = 0.1
					end
				else
					return
				end
			else
				return
			end
		end,
		["EarthenTranceStart"] = function(p160)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (copy) p_u_26, (ref) v_u_7
			local v161 = p160:FindFirstChild("HumanoidRootPart")
			if v161 then
				v_u_14:PlaySound(v_u_9.Kurourushi.InsectTrance.Start, v161, game.SoundService.Effect)
				local _, _ = p_u_26:PlayArms(p160, v_u_7.Kurourushi.EarthenTranceArms, v_u_7.Kurourushi.EarthenTrance)
			end
		end,
		["Interp"] = function(p162, p_u_163, p_u_164)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_4, (ref) v_u_2
			if p162:FindFirstChild("HumanoidRootPart") then
				v_u_14:PlaySound(v_u_9.Kurourushi.InsectTrance.BugAppear, p_u_163, game.SoundService.Effect)
				v_u_14:PlaySound(v_u_9.Kurourushi.InsectTrance.FlyLoop, p_u_163, game.SoundService.Effect)
				for _, v165 in pairs(p_u_163.Parent:GetDescendants()) do
					if not v165:IsA("BasePart") or v165.Transparency == 1 then
						continue
					end
					v165.Transparency = 1
					v_u_4:Create(v165, TweenInfo.new(0.4), {
						["Transparency"] = 0
					}):Play()
				end
				local v_u_166 = p_u_163.CFrame
				local v_u_167 = p_u_163.CFrame
				local v_u_168 = tick()
				local v_u_169 = p_u_163:GetPropertyChangedSignal("Position"):Connect(function()
					-- upvalues: (ref) v_u_167, (copy) p_u_163, (ref) v_u_168
					v_u_167 = p_u_163.CFrame
					v_u_168 = tick()
				end)
				local v_u_170 = nil
				v_u_170 = v_u_2.RenderStepped:Connect(function(p171)
					-- upvalues: (copy) p_u_163, (copy) p_u_164, (ref) v_u_170, (copy) v_u_169, (ref) v_u_166, (ref) v_u_167
					if p_u_163.Parent and p_u_164.Parent then
						v_u_166 = v_u_166:Lerp(v_u_167, 0.3 * p171 * 60)
						local v172 = { p_u_163 }
						local v173 = { v_u_166 }
						workspace:BulkMoveTo(v172, v173, Enum.BulkMoveMode.FireCFrameChanged)
					else
						v_u_170:Disconnect()
						v_u_169:Disconnect()
					end
				end)
			end
		end,
		["InsectDisappear"] = function(_, p_u_174)
			-- upvalues: (ref) v_u_4, (ref) v_u_14, (ref) v_u_9, (ref) v_u_2
			for _, v175 in pairs(p_u_174.Parent:GetDescendants()) do
				if v175:IsA("BasePart") then
					v_u_4:Create(v175, TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
						["Transparency"] = 1
					}):Play()
				else
					if not v175:IsA("Sound") then
						continue
					end
					v_u_4:Create(v175, TweenInfo.new(0.4, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
						["Volume"] = 0
					}):Play()
				end
			end
			local v_u_176 = p_u_174.CFrame
			local v_u_177 = p_u_174.CFrame * CFrame.new(0, 10, 0)
			for _, v178 in pairs(p_u_174.Parent:GetDescendants()) do
				if not v178:IsA("BasePart") then
					continue
				end
				v_u_4:Create(v178, TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
					["Transparency"] = 1
				}):Play()
			end
			v_u_14:PlaySound(v_u_9.Kurourushi.InsectTrance.BugDisappear, p_u_174, game.SoundService.Effect)
			local v_u_179 = nil
			v_u_179 = v_u_2.RenderStepped:Connect(function()
				-- upvalues: (copy) p_u_174, (ref) v_u_179, (ref) v_u_176, (copy) v_u_177
				if p_u_174.Parent then
					v_u_176 = v_u_176:Lerp(v_u_177, 0.025)
					local v180 = { p_u_174 }
					local v181 = { v_u_176 }
					workspace:BulkMoveTo(v180, v181, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_179:Disconnect()
				end
			end)
		end,
		["InsectBurst"] = function(p182, p183)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3
			if p182:FindFirstChild("HumanoidRootPart") then
				v_u_14:PlaySound(v_u_9.Kurourushi.InsectTrance.BugExplode, p183, game.SoundService.Effect)
				local v184 = v_u_8.Kurourushi.InsectBurst:Clone()
				v184.CFrame = p183.CFrame
				v184.Parent = workspace.Effects
				v_u_14:PlayParticles(v184)
				v_u_3:AddItem(v184, 4)
			end
		end,
		["InsectHit"] = function(p185, p186)
			-- upvalues: (ref) v_u_14, (ref) v_u_5, (ref) v_u_10, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3, (ref) v_u_4
			if p185:FindFirstChild("HumanoidRootPart") then
				v_u_14:Flash(p186, Color3.new(0.392157, 1, 0.27451), 2)
				if v_u_5.Character == p186 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
					v_u_14:PlaySound(v_u_9.Kurourushi.InsectTrance.Screen, workspace, game.SoundService.Effect)
					if _G.Settings.Flash then
						local v_u_187 = v_u_8.Kurourushi.InsectBurst:Clone()
						v_u_187.CFrame = workspace.CurrentCamera.CFrame
						v_u_187.Parent = workspace.Effects
						for _, v188 in pairs(v_u_187:GetDescendants()) do
							if not v188:IsA("ParticleEmitter") then
								continue
							end
							v188.LockedToPart = true
							v188:Emit(v188:GetAttribute("EmitCount"))
							v188.TimeScale = 0.5
						end
						v_u_3:AddItem(v_u_187, 4)
						task.spawn(function()
							-- upvalues: (copy) v_u_187
							repeat
								task.wait()
								v_u_187.CFrame = workspace.CurrentCamera.CFrame * CFrame.new(0, 0, -1)
							until v_u_187.Parent == nil or v_u_187 == nil
						end)
					end
					task.wait(0.15)
					local v189 = Instance.new("BlurEffect", game.Lighting)
					v_u_3:AddItem(v189, 4)
					v189.Size = 64
					v_u_4:Create(v189, TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
						["Size"] = 0
					}):Play()
					if _G.Settings.Flash then
						local v190 = Instance.new("ColorCorrectionEffect", game.Lighting)
						v_u_3:AddItem(v190, 4)
						v190.Contrast = 0
						v190.TintColor = Color3.new(0.376471, 1, 0.278431)
						v_u_4:Create(v190, TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
							["TintColor"] = Color3.fromRGB(255, 255, 255)
						}):Play()
					end
				end
			end
		end,
		["Explode"] = function(p191)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_14, (ref) v_u_9, (ref) v_u_10
			local v192 = v_u_8.Kurourushi.RoachExplosion:Clone()
			local v193 = Instance.new("Model")
			v192.Parent = v193
			v193:ScaleTo(3)
			v_u_3:AddItem(v193, 0.1)
			v192.Parent = workspace.Effects
			v192.CFrame = CFrame.new(p191)
			v_u_14:PlayParticles(v192)
			v_u_3:AddItem(v192, 3)
			v_u_14:PlaySound(v_u_9.Kurourushi.Bugnado.Explosion, v192, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p191).Magnitude < 100 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
			end
		end,
		["KuroClone"] = function(p194)
			if p194 and p194.Parent then
				local v195 = game.ReplicatedStorage.Utils.MoveReveal:Clone()
				v195.MaxDistance = 75
				v195.Parent = p194.PrimaryPart
				v195.Moveset.Visible = false
				v195.Handle.Enabled = true
			end
		end,
		["Bugnado"] = function(p196, p_u_197, p_u_198)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3, (ref) v_u_2, (ref) v_u_10
			local v_u_199 = p196:FindFirstChild("HumanoidRootPart")
			if v_u_199 then
				local v_u_200 = tick()
				v_u_14:PlaySound(v_u_9.Kurourushi.Bugnado.Start, v_u_199, game.SoundService.Effect)
				local v_u_201 = tick()
				local v_u_202 = math.random(750, 1000)
				local v_u_203 = {}
				local v_u_204 = 0
				local v_u_205 = 20
				for v206 = 1, 4 do
					local v207 = v_u_8.Kurourushi.Swarm:Clone()
					v207.CFrame = v_u_199.CFrame
					v207.Parent = workspace.Effects
					v_u_203[v206] = v207
					v_u_3:AddItem(v207, 20)
				end
				local v_u_208 = p_u_197:Clone()
				v_u_208.Parent = workspace.Effects
				v_u_3:AddItem(v_u_208, 15)
				for _, v209 in ipairs(v_u_203) do
					for _, v210 in ipairs(v209:GetChildren()) do
						v210.Size = NumberSequence.new(0, v210.Size.Keypoints[2].Value)
					end
				end
				local v_u_211 = nil
				v_u_211 = v_u_2.PreRender:Connect(function(p212)
					-- upvalues: (copy) p_u_197, (ref) v_u_211, (copy) v_u_208, (ref) v_u_3, (copy) v_u_203, (copy) v_u_201, (ref) v_u_204, (copy) v_u_202, (ref) v_u_205, (copy) v_u_199, (copy) p_u_198, (ref) v_u_200, (ref) v_u_10, (ref) v_u_14, (ref) v_u_9
					if p_u_197.Parent == nil then
						v_u_211:Disconnect()
						if v_u_208:FindFirstChild("Wind") and v_u_208.Wind.Enabled then
							v_u_208.Wind.Enabled = false
							v_u_3:AddItem(v_u_208, 2)
						end
						for _, v_u_213 in v_u_203 do
							local v_u_214 = v_u_213.CFrame.LookVector
							local _ = v_u_213.Size
							local v_u_215 = 0
							task.spawn(function()
								-- upvalues: (ref) v_u_215, (copy) v_u_213, (copy) v_u_214
								local v216 = math.random(150, 225)
								local v217 = task.wait()
								local v218 = v_u_215 + v217 / 0.6
								v_u_215 = math.min(v218, 1)
								local _ = 1 - v_u_215 * v_u_215
								local v219 = v_u_213
								local v220 = v_u_213.CFrame * CFrame.new(v_u_214 * v217 * v216)
								local v221 = v_u_215 * 1 * v217 * 80
								v219.CFrame = v220 - Vector3.new(0, v221, 0)
								for _, v222 in v_u_213:GetChildren() do
									v222.Size = NumberSequence.new(v222.Size.Keypoints[1].Value - 0.06 * v217 * 80, v222.Size.Keypoints[2].Value)
								end
								if v_u_215 < 1 then
									break
								end
								task.delay(1, function()
									-- upvalues: (ref) v_u_213
									v_u_213:Destroy()
								end)
							end)
						end
					else
						local v223 = tick() - v_u_201
						local v224 = v223 - 1.75
						local v225 = math.max(v224, 0) / 1
						local v226 = math.min(v225, 1)
						local v227 = v226 ^ 2 * 8
						local v228 = v223 * 23
						local v229 = math.sin(v228) * v227
						local v230 = v223 * 17
						local v231 = math.sin(v230)
						local v232 = v227 * 3
						local v233 = v231 * math.rad(v232)
						local v234 = v_u_204
						local v235 = v_u_202 * p212
						local v236 = v234 + math.rad(v235)
						local v237 = v226 * v_u_202 * 0.5 * p212
						v_u_204 = v236 + math.rad(v237)
						v_u_205 = v_u_205 + 0.09 * p212 * 80
						local v238 = p_u_197.Position
						local v239 = p_u_197.Size.Y / 2
						local _ = v238 - Vector3.new(0, v239, 0)
						for v240, v241 in v_u_203 do
							local v242 = (v223 * 0.25 + (v240 - 1) / 4) % 1
							local v243 = v242 * 3.141592653589793 * 2 - 1.5707963267948966
							local v244 = (math.sin(v243) + 1) / 2 * v_u_205
							local v245 = v_u_204
							local v246 = 90 * (v240 - 1)
							local v247 = v245 + math.rad(v246) + v233 * (v240 % 2 == 0 and 1 or -1)
							local v248 = v242 * 3.141592653589793
							local v249 = math.sin(v248) * 6 + 0.5 + v229 * (v240 % 2 == 0 and 1 or -1)
							local v250 = math.cos(v247) * v249
							local v251 = -p_u_197.Size.Y / 2 + v244
							local v252 = math.sin(v247) * v249
							local v253 = Vector3.new(v250, v251, v252)
							local v254 = (v223 * 0.25 + p212 * 0.25 + (v240 - 1) / 4) % 1
							local v255 = v_u_202 * p212
							local v256 = v247 + math.rad(v255)
							local v257 = math.cos(v256)
							local v258 = v254 * 3.141592653589793
							local v259 = v257 * (math.sin(v258) * 6 + 0.5)
							local v260 = -p_u_197.Size.Y / 2 + v254 * v_u_205
							local v261 = math.sin(v247)
							local v262 = v254 * 3.141592653589793
							local v263 = v261 * (math.sin(v262) * 6 + 0.5)
							local v264 = Vector3.new(v259, v260, v263)
							local v265 = v223 / 0.4
							local v266 = math.min(v265, 1)
							local v267 = p_u_197.Position + v253
							v241.CFrame = CFrame.lookAt(v_u_199.Position:Lerp(v267, v266 * v266), p_u_197.Position + v264)
							if v266 >= 0.75 and ((workspace.CurrentCamera.CFrame.Position - p_u_198).Magnitude < 80 and v_u_200 - tick() > 0.2) then
								v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
								v_u_200 = tick()
							end
							v_u_208.CFrame = p_u_197.CFrame
							if v_u_208:FindFirstChild("Wind") then
								if v_u_208.Wind.Enabled == false and v266 >= 0.75 then
									v_u_208.Wind.Enabled = true
									local v_u_268 = v_u_14:PlaySound(v_u_9.Kurourushi.Bugnado.Tornado, p_u_197, game.SoundService.Effect)
									p_u_197.AncestryChanged:Once(function()
										-- upvalues: (copy) v_u_268
										v_u_268:Destroy()
									end)
								end
								v_u_208.Wind.Size = NumberSequence.new(v_u_208.Wind.Size.Keypoints[1].Value + 0.04 * p212 * 80, v_u_208.Wind.Size.Keypoints[2].Value)
								local v269 = v_u_208.Wind
								v269.Rate = v269.Rate + 0.1 * p212 * 60
								local v270 = v_u_208
								v270.Size = v270.Size + Vector3.new(0, 0.02, 0) * p212 * 80
							end
							for _, v271 in ipairs(v241:GetChildren()) do
								v271.Size = NumberSequence.new(v271.Size.Keypoints[1].Value + 0.04 * p212 * 80, v271.Size.Keypoints[2].Value)
							end
						end
					end
				end)
			end
		end,
		["EatSoda"] = function(p272)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v273 = p272:FindFirstChild("HumanoidRootPart")
			if v273 then
				v_u_14:Flash(p272, Color3.fromRGB(101, 35, 44), 1)
				v_u_14:PlaySound(v_u_9.Mahito.Eat, v273, game.SoundService.Effect)
				if v_u_5.Character == p272 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
				end
			end
		end,
		["Divide"] = function(p274, p275)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_2, (ref) v_u_8, (ref) v_u_3, (ref) v_u_14, (ref) v_u_9, (ref) v_u_10, (ref) v_u_5
			local v_u_276 = p274:FindFirstChild("HumanoidRootPart")
			if v_u_276 then
				local v_u_277 = p274:Clone()
				if v_u_277.SetAssets:FindFirstChild("HeianArms") then
					v_u_277.SetAssets.HeianArms:Destroy()
				end
				local v_u_278 = p274:Clone()
				if v_u_278.SetAssets:FindFirstChild("HeianArms") then
					v_u_278.SetAssets.HeianArms:Destroy()
				end
				v_u_277.Parent = p275
				v_u_278.Parent = p275
				for _, v279 in p275:GetDescendants() do
					if not v279:IsA("BasePart") then
						continue
					end
					if v279.Name == "HumanoidRootPart" or v279.Name == "Torso" then
						v279.CollisionGroup = "Effects"
					else
						v279.CollisionGroup = "NoCollision"
					end
					v279.Massless = true
				end
				v_u_277.HumanoidRootPart.Anchored = true
				v_u_278.HumanoidRootPart.Anchored = true
				local v280 = v_u_277.Humanoid:LoadAnimation(v_u_7.Kurourushi.Parthenogenesis)
				v280:Play(0)
				v280.TimePosition = 2.117
				local v281 = v_u_278.Humanoid:LoadAnimation(v_u_7.Kurourushi.Parthenogenesis)
				v281:Play(0)
				v281.TimePosition = 2.117
				local v282 = Instance.new("Highlight", v_u_277)
				v282.FillTransparency = 1
				v282.OutlineTransparency = 1
				v282.DepthMode = Enum.HighlightDepthMode.Occluded
				local v283 = v282:Clone()
				v283.Parent = v_u_278
				v_u_4:Create(v282, TweenInfo.new(2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["OutlineTransparency"] = 0
				}):Play()
				v_u_4:Create(v283, TweenInfo.new(2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["OutlineTransparency"] = 0
				}):Play()
				local v_u_284 = Instance.new("Weld", v_u_277)
				v_u_284.C0 = CFrame.new(0, 0, 0)
				v_u_284.Name = "FolderWeld"
				local v_u_285 = Instance.new("Weld", v_u_278)
				v_u_285.C0 = CFrame.new(0, 0, 0)
				v_u_285.Name = "FolderWeld"
				v_u_4:Create(v_u_284, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.InOut), {
					["C0"] = CFrame.new(-4, 0, 0)
				}):Play()
				v_u_4:Create(v_u_285, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.InOut), {
					["C0"] = CFrame.new(4, 0, 0)
				}):Play()
				local v_u_286 = nil
				v_u_286 = v_u_2.Stepped:Connect(function()
					-- upvalues: (copy) v_u_284, (copy) v_u_285, (ref) v_u_286, (copy) v_u_277, (copy) v_u_276, (copy) v_u_278
					if v_u_284.Parent and v_u_285.Parent then
						if v_u_284.Enabled == true then
							v_u_277.HumanoidRootPart.CFrame = v_u_276.CFrame * v_u_284.C0
						end
						if v_u_285.Enabled == true then
							v_u_278.HumanoidRootPart.CFrame = v_u_276.CFrame * v_u_285.C0
						end
					else
						v_u_286:Disconnect()
					end
				end)
				local v_u_287 = {}
				for _, v288 in p274:GetDescendants() do
					if not (v288:IsA("BasePart") or v288:IsA("Decal")) or v288.Transparency == 1 then
						continue
					end
					local v289 = v288.Transparency
					v288.Transparency = 1
					v_u_287[v288] = v289
				end
				task.delay(6, function()
					-- upvalues: (copy) v_u_287
					for v290, v291 in v_u_287 do
						if not v290.Parent then
							continue
						end
						v290.Transparency = v291
					end
				end)
				local v_u_292 = v_u_8.Kurourushi.Parthenogenesis.RoachUlt:Clone()
				v_u_292.Weld.Part0 = v_u_276
				v_u_292.Parent = workspace.Effects
				v_u_3:AddItem(v_u_292, 3)
				v_u_14:PlaySound(v_u_9.Kurourushi.Parthenogenesis.Explode, v_u_276, game.SoundService.Effect)
				v_u_4:Create(v_u_292, TweenInfo.new(2, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {
					["Size"] = Vector3.new(20, 10, 10)
				}):Play()
				task.delay(0.2, function()
					-- upvalues: (copy) v_u_292
					if v_u_292.Parent then
						v_u_292.In.Roaches.Enabled = false
						v_u_292.Roaches.Enabled = true
					end
				end)
				p275.AncestryChanged:Once(function()
					-- upvalues: (copy) v_u_287, (copy) v_u_277, (copy) v_u_278, (copy) v_u_284, (copy) v_u_285, (copy) v_u_292, (ref) v_u_3, (ref) v_u_14, (ref) v_u_9, (copy) v_u_276, (ref) v_u_10
					for v293, v294 in v_u_287 do
						if not v293.Parent then
							continue
						end
						v293.Transparency = v294
					end
					v_u_277:Destroy()
					v_u_278:Destroy()
					v_u_284:Destroy()
					v_u_285:Destroy()
					v_u_292.In.Roaches:Emit(20)
					v_u_292.In.Sparks:Emit(20)
					v_u_292.RoachFly:Emit(20)
					v_u_292.Roaches.Enabled = false
					v_u_3:AddItem(v_u_292, 1.2)
					v_u_14:PlaySound(v_u_9.Kurourushi.Parthenogenesis.Explode2, v_u_276, game.SoundService.Effect)
					if (workspace.CurrentCamera.CFrame.Position - v_u_292.Position).Magnitude < 100 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
					end
				end)
				if v_u_5.Character == p274 then
					local v_u_295 = v_u_10.CurrentShaker:ShakeSustain(v_u_10.Presets.LightHit)
					v_u_4:Create(workspace.CurrentCamera, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["FieldOfView"] = 50
					}):Play()
					task.delay(1.5, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_295
						v_u_4:Create(workspace.CurrentCamera, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.InOut), {
							["FieldOfView"] = 70
						}):Play()
						v_u_295:StartFadeOut(0.3)
					end)
				end
			end
		end,
		["CollectBugs"] = function(p296, p297)
			-- upvalues: (ref) v_u_16, (ref) v_u_7, (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3, (ref) v_u_4
			local v298 = p296:FindFirstChild("HumanoidRootPart")
			if v298 then
				v_u_16:PlayArms(p296, v_u_7.Kurourushi.ParthenogenesisArms, v_u_7.Kurourushi.Parthenogenesis)
				v_u_14:PlaySound(v_u_9.Kurourushi.Parthenogenesis.Startup, v298, game.SoundService.Effect)
				local v_u_299 = v_u_8.Kurourushi.Parthenogenesis.RoachUlt2:Clone()
				v_u_299.Weld.Part0 = v298
				v_u_299.Parent = workspace.Effects
				v_u_3:AddItem(v_u_299, 3)
				v_u_4:Create(v_u_299.RoachFly, TweenInfo.new(2), {
					["Rate"] = 200
				}):Play()
				v_u_4:Create(v_u_299.Attachment.Roaches, TweenInfo.new(2), {
					["Rate"] = 200,
					["TimeScale"] = 1
				}):Play()
				task.delay(3, function()
					-- upvalues: (copy) v_u_299
					if v_u_299 and v_u_299.Parent then
						if v_u_299:FindFirstChild("Attachment") then
							v_u_299.Attachment.Roaches.Enabled = false
						end
						if v_u_299:FindFirstChild("RoachFly") then
							v_u_299.RoachFly.Enabled = false
						end
					end
				end)
				p297.AncestryChanged:Once(function()
					-- upvalues: (copy) v_u_299
					if v_u_299:FindFirstChild("Attachment") then
						v_u_299.Attachment.Roaches.Enabled = false
					end
					if v_u_299:FindFirstChild("RoachFly") then
						v_u_299.RoachFly.Enabled = false
					end
				end)
			end
		end,
		["StartInvade"] = function(p300, p301, p302)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			if p300:FindFirstChild("HumanoidRootPart") then
				v_u_14:PlaySound(v_u_9.Kurourushi.StartInvade, p301, game.SoundService.Effect)
				v_u_14:PlaySound(v_u_9.Kurourushi.StartInvade, p302, game.SoundService.Effect)
			end
		end
	}
	v_u_12.Effects:Connect(function(p304, ...)
		-- upvalues: (copy) v_u_303
		local v305 = v_u_303[p304]
		if v305 then
			v305(...)
		end
	end)
	v_u_12.Hitbox:Connect(function(p306, p307, p308)
		-- upvalues: (ref) v_u_13, (ref) v_u_4
		local v309 = p307.HumanoidRootPart
		if v309 then
			local v310 = nil
			local v311 = v_u_13:SphereHitbox(p307, CFrame.new(0, 0, -4), 8)
			for _, v312 in v311 do
				local v313 = v312:FindFirstChild("Info")
				if not v313 then
					continue
				end
				local v314 = v313:FindFirstChild("Knockback")
				if v314 and v314.Value == false then
					continue
				end
				v310 = v311
			end
			if v310 then
				local v315 = p306:FindFirstChildWhichIsA("NumberValue")
				if v315 then
					v_u_4:Create(v315, TweenInfo.new(0.1), {
						["Value"] = 0
					}):Play()
				end
			else
				task.wait(0.05)
				if p306.Parent then
					break
				end
			end
			p308:FireServer(v310, v309.CFrame)
		end
	end)
	local v_u_316 = nil
	local v_u_317 = nil
	v_u_2.RenderStepped:Connect(function()
		-- upvalues: (ref) v_u_15, (ref) v_u_316, (ref) v_u_317
		local v318 = v_u_15:GetTarget()
		local v319
		if v318 then
			v319 = v318.PrimaryPart or nil
		else
			v319 = nil
		end
		if v318 ~= v_u_316 then
			if v_u_317 then
				v_u_317.Visible = false
				v_u_317 = nil
			end
			v_u_316 = nil
		end
		if v319 then
			local v320 = v319:FindFirstChild("MoveReveal")
			local v321 = v320 and v320:FindFirstChild("Moveset") or nil
			if v321 then
				v321.Visible = true
				v_u_316 = v318
				v_u_317 = v321
			end
		end
	end)
end
function v_u_16.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_12, (copy) v_u_1, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15
	v_u_12 = v_u_1.GetService("KurourushiService")
	v_u_13 = v_u_1.GetController("HitboxController")
	v_u_14 = v_u_1.GetController("FXController")
	v_u_15 = v_u_1.GetController("ToolController")
end
return v_u_16