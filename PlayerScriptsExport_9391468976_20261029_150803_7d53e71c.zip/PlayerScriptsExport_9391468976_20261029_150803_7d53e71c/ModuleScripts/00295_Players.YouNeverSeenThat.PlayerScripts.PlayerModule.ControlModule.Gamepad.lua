-- Original instance: Players.YouNeverSeenThat.PlayerScripts.PlayerModule.ControlModule.Gamepad
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = game:GetService("UserInputService")
local v_u_2 = game:GetService("ContextActionService")
local v3 = script.Parent.Parent:WaitForChild("CommonUtils")
local v_u_4 = require(v3:WaitForChild("FlagUtil")).getUserFlag("UserPlayerScriptsSupportTVRemoteKeycodes")
local v_u_5 = Enum.UserInputType.None
local v_u_6 = require(script.Parent:WaitForChild("BaseCharacterController"))
local v_u_7 = setmetatable({}, v_u_6)
v_u_7.__index = v_u_7
function v_u_7.new(p8) -- name: new
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_5
	local v9 = v_u_6.new()
	local v10 = v_u_7
	local v11 = setmetatable(v9, v10)
	v11.CONTROL_ACTION_PRIORITY = p8
	v11.forwardValue = 0
	v11.backwardValue = 0
	v11.leftValue = 0
	v11.rightValue = 0
	v11.thumbstickVector = Vector3.new(0, 0, 0)
	v11.activeGamepad = v_u_5
	v11.gamepadConnectedConn = nil
	v11.gamepadDisconnectedConn = nil
	return v11
end
function v_u_7.Enable(p12, p13) -- name: Enable
	-- upvalues: (copy) v_u_5
	if p13 == p12.enabled then
		return true
	end
	p12.forwardValue = 0
	p12.backwardValue = 0
	p12.leftValue = 0
	p12.rightValue = 0
	p12.thumbstickVector = Vector3.new(0, 0, 0)
	p12.moveVector = Vector3.new(0, 0, 0)
	p12.isJumping = false
	if p13 then
		p12.activeGamepad = p12:GetHighestPriorityGamepad()
		if p12.activeGamepad == v_u_5 then
			return false
		end
		p12:BindContextActions()
		p12:ConnectGamepadConnectionListeners()
	else
		p12:UnbindContextActions()
		p12:DisconnectGamepadConnectionListeners()
		p12.activeGamepad = v_u_5
	end
	p12.enabled = p13
	return true
end
function v_u_7.GetHighestPriorityGamepad(_) -- name: GetHighestPriorityGamepad
	-- upvalues: (copy) v_u_1, (copy) v_u_5
	local v14 = v_u_1:GetConnectedGamepads()
	local v15 = v_u_5
	for _, v16 in pairs(v14) do
		if v16.Value >= v15.Value then
			continue
		end
		v15 = v16
	end
	return v15
end
function v_u_7.UpdateMovement(p17) -- name: UpdateMovement
	local v18 = p17.thumbstickVector
	local v19 = p17.forwardValue + p17.backwardValue
	p17.moveVector = v18 + Vector3.new(0, 0, v19)
end
function v_u_7.BindContextActions(p_u_20) -- name: BindContextActions
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_2
	if p_u_20.activeGamepad == v_u_5 then
		return false
	end
	local function v22(_, p21, _)
		-- upvalues: (copy) p_u_20
		p_u_20.isJumping = p21 == Enum.UserInputState.Begin
		return Enum.ContextActionResult.Sink
	end
	local function v31(_, p23, p24)
		-- upvalues: (ref) v_u_4, (copy) p_u_20
		if p23 == Enum.UserInputState.Cancel then
			if v_u_4 then
				p_u_20.thumbstickVector = Vector3.new(0, 0, 0)
				p_u_20:UpdateMovement()
			else
				p_u_20.moveVector = Vector3.new(0, 0, 0)
			end
			return Enum.ContextActionResult.Sink
		end
		if p_u_20.activeGamepad ~= p24.UserInputType then
			return Enum.ContextActionResult.Pass
		end
		if p24.KeyCode == Enum.KeyCode.Thumbstick1 then
			if v_u_4 then
				if p24.Position.magnitude > 0.2 then
					local v25 = p_u_20
					local v26 = p24.Position.X
					local v27 = -p24.Position.Y
					v25.thumbstickVector = Vector3.new(v26, 0, v27)
				else
					p_u_20.thumbstickVector = Vector3.new(0, 0, 0)
				end
				p_u_20:UpdateMovement()
			elseif p24.Position.magnitude > 0.2 then
				local v28 = p_u_20
				local v29 = p24.Position.X
				local v30 = -p24.Position.Y
				v28.moveVector = Vector3.new(v29, 0, v30)
			else
				p_u_20.moveVector = Vector3.new(0, 0, 0)
			end
			return Enum.ContextActionResult.Sink
		end
	end
	local function v35(_, p32, p33)
		-- upvalues: (copy) p_u_20
		if p32 == Enum.UserInputState.Cancel then
			p_u_20.forwardValue = 0
			p_u_20.backwardValue = 0
			p_u_20:UpdateMovement()
			return Enum.ContextActionResult.Sink
		else
			local v34 = p33.Position.magnitude <= 0.2 and 0 or p33.Position.Z
			if p33.KeyCode == Enum.KeyCode.ButtonUp then
				p_u_20.forwardValue = -v34
			elseif p33.KeyCode == Enum.KeyCode.ButtonDown then
				p_u_20.backwardValue = v34
			end
			p_u_20:UpdateMovement()
			return Enum.ContextActionResult.Sink
		end
	end
	v_u_2:BindActivate(p_u_20.activeGamepad, Enum.KeyCode.ButtonR2)
	if v_u_4 then
		v_u_2:BindActionAtPriority("jumpAction", v22, false, p_u_20.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonA, Enum.KeyCode.ButtonCenter)
		v_u_2:BindActionAtPriority("moveDirectionalButton", v35, false, p_u_20.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonUp, Enum.KeyCode.ButtonDown)
	else
		v_u_2:BindActionAtPriority("jumpAction", v22, false, p_u_20.CONTROL_ACTION_PRIORITY, Enum.KeyCode.ButtonA)
	end
	v_u_2:BindActionAtPriority("moveThumbstick", v31, false, p_u_20.CONTROL_ACTION_PRIORITY, Enum.KeyCode.Thumbstick1)
	return true
end
function v_u_7.UnbindContextActions(p36) -- name: UnbindContextActions
	-- upvalues: (copy) v_u_5, (copy) v_u_2, (copy) v_u_4
	if p36.activeGamepad ~= v_u_5 then
		v_u_2:UnbindActivate(p36.activeGamepad, Enum.KeyCode.ButtonR2)
	end
	if v_u_4 then
		v_u_2:UnbindAction("moveDirectionalButton")
	end
	v_u_2:UnbindAction("moveThumbstick")
	v_u_2:UnbindAction("jumpAction")
end
function v_u_7.OnNewGamepadConnected(p37) -- name: OnNewGamepadConnected
	-- upvalues: (copy) v_u_5
	local v38 = p37:GetHighestPriorityGamepad()
	if v38 == p37.activeGamepad then
		return
	elseif v38 == v_u_5 then
		warn("Gamepad:OnNewGamepadConnected found no connected gamepads")
		p37:UnbindContextActions()
	else
		if p37.activeGamepad ~= v_u_5 then
			p37:UnbindContextActions()
		end
		p37.activeGamepad = v38
		p37:BindContextActions()
	end
end
function v_u_7.OnCurrentGamepadDisconnected(p39) -- name: OnCurrentGamepadDisconnected
	-- upvalues: (copy) v_u_5, (copy) v_u_2
	if p39.activeGamepad ~= v_u_5 then
		v_u_2:UnbindActivate(p39.activeGamepad, Enum.KeyCode.ButtonR2)
	end
	local v40 = p39:GetHighestPriorityGamepad()
	if p39.activeGamepad == v_u_5 or v40 ~= p39.activeGamepad then
		if v40 == v_u_5 then
			p39:UnbindContextActions()
			p39.activeGamepad = v_u_5
		else
			p39.activeGamepad = v40
			v_u_2:BindActivate(p39.activeGamepad, Enum.KeyCode.ButtonR2)
		end
	else
		warn("Gamepad:OnCurrentGamepadDisconnected found the supposedly disconnected gamepad in connectedGamepads.")
		p39:UnbindContextActions()
		p39.activeGamepad = v_u_5
		return
	end
end
function v_u_7.ConnectGamepadConnectionListeners(p_u_41) -- name: ConnectGamepadConnectionListeners
	-- upvalues: (copy) v_u_1
	p_u_41.gamepadConnectedConn = v_u_1.GamepadConnected:Connect(function(_)
		-- upvalues: (copy) p_u_41
		p_u_41:OnNewGamepadConnected()
	end)
	p_u_41.gamepadDisconnectedConn = v_u_1.GamepadDisconnected:Connect(function(p42)
		-- upvalues: (copy) p_u_41
		if p_u_41.activeGamepad == p42 then
			p_u_41:OnCurrentGamepadDisconnected()
		end
	end)
end
function v_u_7.DisconnectGamepadConnectionListeners(p43) -- name: DisconnectGamepadConnectionListeners
	if p43.gamepadConnectedConn then
		p43.gamepadConnectedConn:Disconnect()
		p43.gamepadConnectedConn = nil
	end
	if p43.gamepadDisconnectedConn then
		p43.gamepadDisconnectedConn:Disconnect()
		p43.gamepadDisconnectedConn = nil
	end
end
return v_u_7