-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Ryu.RyuController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
require(v6.Modules.StaticLightning)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "RyuController"
})
local v_u_14 = Random.new()
local v_u_15 = workspace.CurrentCamera
Color3.fromRGB(128, 187, 219)
local v_u_16 = Color3.new(1, 1, 1)
local function v_u_35(p17, p18, p19) -- name: drawBeam
	local v20 = p19.Z - 45 - p19.X / 2
	local v21 = math.max(v20, 0)
	local v22 = p17.BlackStart.Size.X
	p17.BlackStart.CFrame = p18 * CFrame.new(0, 0, -22.5) * CFrame.Angles(-1.5707963267948966, 0, 0)
	local v23 = p17.BlackStart
	local v24 = p19.X
	local v25 = p19.Y
	v23.Size = Vector3.new(v24, 45, v25)
	p17.PinkStart.CFrame = p17.BlackStart.CFrame
	p17.PinkStart.Size = p17.BlackStart.Size * Vector3.new(0.6, 1, 0.6)
	p17.BlackMiddle.CFrame = p18 * CFrame.new(0, 0, -(v21 / 2 + 45)) * CFrame.Angles(-1.5707963267948966, 0, 0)
	local v26 = p17.BlackMiddle
	local v27 = p19.X
	local v28 = p19.Y
	v26.Size = Vector3.new(v27, v21, v28)
	p17.PinkMiddle.CFrame = p17.BlackMiddle.CFrame
	p17.PinkMiddle.Size = p17.BlackMiddle.Size * Vector3.new(0.6, 1, 0.6)
	p17.BlackEnd.CFrame = p18 * CFrame.new(0, 0, -(v21 + 45 + p19.X / 4)) * CFrame.Angles(1.5707963267948966, 0, 0)
	local v29 = p17.BlackEnd
	local v30 = p19.X
	local v31 = p19.X / 2
	local v32 = p19.X
	v29.Size = Vector3.new(v30, v31, v32)
	p17.PinkEnd.CFrame = p17.BlackEnd.CFrame
	p17.PinkEnd.Size = p17.BlackEnd.Size * Vector3.new(0.6, 1, 0.6)
	for _, v33 in p17:GetDescendants() do
		if not v33:IsA("Beam") then
			continue
		end
		local v34 = v22 / v33.CurveSize0
		v33.CurveSize0 = p19.X / v34
	end
end
local function v_u_40(p36) -- name: shootSpec
	-- upvalues: (copy) v_u_7, (copy) v_u_4
	local v37 = v_u_7.Yuta.LoveBeam.BlackSpec:Clone()
	v37.Color = Color3.new(1, 1, 1)
	v37.CFrame = p36.PinkStart.CFrame * CFrame.new(0, -10, 0)
	v37.Parent = p36
	local v38 = p36.BlackMiddle.Size.X
	local v39 = p36.BlackMiddle.Size.Y
	v_u_4:Create(v37, TweenInfo.new(0.3), {
		["Size"] = Vector3.new(v38, 20, v38),
		["CFrame"] = v37.CFrame * CFrame.new(0, v39 / 2, 0)
	}):Play()
	task.wait(0.2)
	v_u_4:Create(v37, TweenInfo.new(0.3), {
		["Size"] = Vector3.new(v38, 0, v38),
		["CFrame"] = p36.PinkStart.CFrame * CFrame.new(0, v39, 0)
	}):Play()
	task.wait(0.3)
	v37:Destroy()
end
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_16, (copy) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2, (copy) v_u_15, (copy) v_u_1, (copy) v_u_35, (copy) v_u_14, (copy) v_u_40, (ref) v_u_10
	task.spawn(function()
		game.ContentProvider:PreloadAsync({ "rbxassetid://131698399665351", "rbxassetid://94473169004838" })
	end)
	local v_u_154 = {
		["Hit"] = function(p41, p42, p43)
			-- upvalues: (ref) v_u_12, (ref) v_u_16, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v44 = p41:FindFirstChild("HumanoidRootPart")
			if v44 then
				v_u_12:Flash(p41, v_u_16)
				v_u_12:PlaySound(v_u_8.Itadori.M1:FindFirstChild("Hit" .. (p42 or 1)), v44, game.SoundService.Effect)
				if p43 then
					local v45 = v_u_7.Itadori.CounterHit:Clone()
					v45.Position = v44.Position
					v45.Parent = workspace.Effects
					v45.Glow:Emit(1)
					v45.Sparks:Emit(20)
					v_u_3:AddItem(v45, 0.5)
				end
			end
		end,
		["ChaseHit"] = function(p46, p47)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v48 = p46:FindFirstChild("HumanoidRootPart")
			if v48 then
				local v49 = p47:FindFirstChild("HumanoidRootPart")
				if v49 then
					v_u_12:Flash(p47, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit3"), v49, game.SoundService.Effect)
					local v50 = v_u_7.ChaseHit:Clone()
					local v51 = CFrame.new
					local v52 = v49.Position
					local v53 = v48.Position.X
					local v54 = v49.Position.Y
					local v55 = v48.Position.Z
					v50.CFrame = v51(v52, (Vector3.new(v53, v54, v55))) * CFrame.Angles(0, 3.141592653589793, 0)
					v50.Parent = workspace.Effects
					v50.Ring:Emit(7)
					v50.Sparks:Emit(12)
					v_u_3:AddItem(v50, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p56)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8
			local v57 = p56.HumanoidRootPart
			if v57 then
				local v58 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v58.CFrame = v57.CFrame * CFrame.new(0, 1, -4)
				v58.Size = Vector3.new(0, 0, 2)
				v58.Parent = workspace.Effects
				v_u_4:Create(v58, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v58, 0.3)
				v_u_12:PlaySound(v_u_8.Misc.Chase, v57, game.SoundService.Effect)
				v_u_12:DustTrail(p56, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p59)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v60 = p59:FindFirstChild("HumanoidRootPart")
			if v60 then
				v_u_12:PlaySound(v_u_8.Misc.Swing.Fist, v60, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p61, p62, p63)
			-- upvalues: (ref) v_u_12
			if p63 == "Up" then
				v_u_12:ArmFlash(p61["Right Arm"], Color3.fromRGB(170, 255, 255))
				return
			elseif p63 == "Down" or p62 == 2 then
				v_u_12:ArmFlash(p61["Right Leg"], Color3.fromRGB(170, 255, 255), p63 == "Down" and 0.4 or false)
			elseif p62 == 1 or p62 == 3 then
				v_u_12:ArmFlash(p61["Left Arm"], Color3.fromRGB(170, 255, 255))
			end
		end,
		["Launch"] = function(p64, p65)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v66 = p64:FindFirstChild("HumanoidRootPart")
			if v66 then
				local v67 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v67.CFrame = CFrame.new(v66.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v67.Size = Vector3.new(0, 0, 5)
				v67.Parent = workspace.Effects
				v_u_4:Create(v67, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v67.Position + Vector3.new(0, p65, 0)
				}):Play()
				v_u_3:AddItem(v67, 0.3)
				if p65 < 0 then
					v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v66, game.SoundService.Effect)
					v_u_12:DustBreak(v66.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 15, 25, 0.7, 1.4)
					if v_u_5:DistanceFromCharacter(v66.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			end
		end,
		["Ring"] = function(p68, p69)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			local v70 = p68:FindFirstChild("HumanoidRootPart")
			if v70 then
				v_u_12:PlaySound(v_u_8.Ryu.GraniteBlast.Fire, v70, game.SoundService.Effect)
				local v_u_71 = v_u_7.Ryu.Ring:Clone()
				v_u_71.Weld.Part0 = v70
				v_u_71.Parent = workspace.Effects
				v_u_4:Create(v_u_71.Fade, TweenInfo.new(0.3, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
					["CFrame"] = v_u_71.Fade.CFrame * CFrame.Angles(0, 3.12413936106985, 0)
				}):Play()
				v_u_4:Create(v_u_71.Fade.Attachment, TweenInfo.new(0.3), {
					["Position"] = Vector3.new(0, 0, 4.5)
				}):Play()
				v_u_4:Create(v_u_71.Weld, TweenInfo.new(0.3, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
					["C1"] = CFrame.Angles(0, -3.12413936106985, 0)
				}):Play()
				task.delay(0.3, function()
					-- upvalues: (copy) v_u_71, (ref) v_u_4
					v_u_71.Fade.Attachment.Trail.Enabled = false
					v_u_4:Create(v_u_71, TweenInfo.new(0.1), {
						["Transparency"] = 0
					}):Play()
					for _, v72 in v_u_71.Attachment:GetDescendants() do
						if not (v72:IsA("Beam") or v72:IsA("ParticleEmitter")) then
							continue
						end
						v72.Enabled = true
					end
				end)
				repeat
					task.wait()
				until not p69:IsDescendantOf(workspace)
				v_u_3:AddItem(v_u_71, 1)
				v_u_71.Weld.Enabled = false
				v_u_71.Anchored = true
				for _, v73 in v_u_71.Attachment:GetDescendants() do
					if not (v73:IsA("Beam") or v73:IsA("ParticleEmitter")) then
						continue
					end
					v73.Enabled = false
				end
				v_u_71.Fade.Attachment.Trail.Enabled = true
				v_u_4:Create(v_u_71, TweenInfo.new(0.6, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
					["CFrame"] = v_u_71.CFrame * CFrame.Angles(0, 3.12413936106985, 0)
				}):Play()
				v_u_4:Create(v_u_71.Fade, TweenInfo.new(0.6, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
					["CFrame"] = v_u_71.Fade.CFrame * CFrame.Angles(0, 3.12413936106985, 0)
				}):Play()
				v_u_4:Create(v_u_71, TweenInfo.new(0.1), {
					["Transparency"] = 1
				}):Play()
			end
		end,
		["Overheat"] = function(p74, p75)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			if p74:FindFirstChild("HumanoidRootPart") then
				local v76 = v_u_7.Ryu.Buildup:Clone()
				v76.Parent = p74.Torso
				v_u_4:Create(v76.BG, TweenInfo.new(0.2), {
					["BackgroundTransparency"] = 0.5
				}):Play()
				v_u_4:Create(v76.Bar.Bar, TweenInfo.new(0.2), {
					["BackgroundTransparency"] = 0
				}):Play()
				local v77 = 0
				local v78 = p75.Value / 50
				v77 = math.lerp(v77, v78, 0.1)
				v76.Bar.Size = UDim2.new(1, 0, v77, 0)
				v76.Bar.Bar.Size = UDim2.new(1, 0, 1 / v77, 0)
				if v78 >= 1 then
					v76.Bar.Bar.UIGradient.Enabled = false
					v76.Bar.Bar.Overheat.Enabled = true
				end
				task.wait()
				if p74.Parent and p75.Parent then
					continue
				end
				v76.Bar.Bar.UIGradient.Enabled = true
				v76.Bar.Bar.Overheat.Enabled = false
				v_u_4:Create(v76.BG, TweenInfo.new(0.4), {
					["BackgroundTransparency"] = 1
				}):Play()
				v_u_4:Create(v76.Bar.Bar, TweenInfo.new(0.4), {
					["BackgroundTransparency"] = 1
				}):Play()
				v_u_3:AddItem(v76, 0.4)
				repeat
					v77 = math.lerp(v77, 0, 0.1)
					v76.Bar.Size = UDim2.new(1, 0, v77, 0)
					v76.Bar.Bar.Size = UDim2.new(1, 0, 1 / v77, 0)
					task.wait()
				until not v76.Parent
			end
		end,
		["Comb"] = function(p79, p80)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v81 = p79:FindFirstChild("HumanoidRootPart")
			if v81 then
				if p80 then
					v_u_12:PlaySound(v_u_8.Ryu.Recovery2.Comb, v81, game.SoundService.Effect)
					return
				elseif p79:GetAttribute("InUlt") then
					v_u_12:PlaySound(v_u_8.Ryu.Recovery3, v81, game.SoundService.Effect)
				else
					v_u_12:PlaySound(v_u_8.Ryu.Recovery.Comb, v81, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Comb2"] = function(p82, p83)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v84 = p82:FindFirstChild("HumanoidRootPart")
			if v84 then
				if p83 then
					v_u_12:PlaySound(v_u_8.Ryu.Recovery2.Hair, v84, game.SoundService.Effect)
				else
					v_u_12:PlaySound(v_u_8.Ryu.Recovery.Sweet, v84, game.SoundService.Voice)
				end
			else
				return
			end
		end,
		["FireBeam"] = function(p85)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8
			local v86 = p85:FindFirstChild("HumanoidRootPart")
			if v86 then
				local v87 = v_u_7.Ryu.GraniteBeam:Clone()
				v87.Parent = workspace.Effects
				v87.CFrame = v86.CFrame * CFrame.new(0, 2, -12)
				v87.Size = Vector3.new(12, 12, 24)
				v_u_4:Create(v87, TweenInfo.new(0.2, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(0, 0, 24)
				}):Play()
				v_u_3:AddItem(v87, 0.2)
				v_u_12:PlaySound(v_u_8.Ryu.GraniteBlast.Fire, v86, game.SoundService.Effect)
			end
		end,
		["UltimateCharge"] = function(p88, p89, p90)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_7
			local v91 = p88:FindFirstChild("HumanoidRootPart")
			if v91 then
				v_u_12:PlaySound(v_u_8.Ryu.UltimateStart, v91, game.SoundService.Effect)
				local v92 = v_u_12:PlaySound(v_u_8.Ryu.Ultimate, v91, game.SoundService.Music)
				v_u_3:AddItem(v92, 3.35)
				v92.TimePosition = (p89 and 140 or 9.9) - 3.35
				local v93 = v92.Volume
				v92.Volume = 0
				v_u_4:Create(v92, TweenInfo.new(2), {
					["Volume"] = v93
				}):Play()
				local v94 = v_u_7.Ryu.Dialogue:Clone()
				v94.Parent = p88.Torso
				local v95 = v94.Text1.Position
				v94.Text1.Position = v95 - UDim2.new(0, 0, 0.15, 0)
				v_u_4:Create(v94.Text1, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v95
				}):Play()
				v_u_4:Create(v94.Text1, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				v_u_4:Create(v94.Text1.UIStroke, TweenInfo.new(0.3), {
					["Transparency"] = 0
				}):Play()
				if p90 then
					v94.Text1.Text = "LET\'S LARP!"
				end
				task.wait(1.6)
				v_u_3:AddItem(v94, 0.6)
				for _, v96 in v94:GetDescendants() do
					if v96:IsA("Frame") then
						v_u_4:Create(v96, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["Position"] = nil,
							["BackgroundTransparency"] = 1,
							["Position"] = v96.Position - UDim2.new(0, 0, 0.2, 0)
						}):Play()
					else
						if not v96:IsA("TextLabel") then
							continue
						end
						v_u_4:Create(v96, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["TextTransparency"] = 1
						}):Play()
						if not v96:FindFirstChild("UIStroke") then
							continue
						end
						v_u_4:Create(v96:FindFirstChild("UIStroke"), TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["Transparency"] = 1
						}):Play()
					end
				end
			end
		end,
		["Ultimate"] = function(p_u_97, p98, p99)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_5, (ref) v_u_2, (ref) v_u_4, (ref) v_u_3
			if p_u_97:FindFirstChild("HumanoidRootPart") then
				local v_u_100 = p_u_97:FindFirstChild("Humanoid")
				if v_u_100 then
					local v_u_101 = v_u_12:PlaySound(v_u_8.Ryu.Ultimate, workspace, game.SoundService.Music)
					local v_u_102 = v_u_12:PlaySound(v_u_8.Ryu[p99 and "UltimateVocalsLarp" or "UltimateVocals"], workspace, game.SoundService.Music)
					v_u_101.TimePosition = p99 and 0 or (p98 and 140 or 9.9)
					local v_u_103 = p99 and 0.15 or 0
					local v_u_104 = v_u_7.Hakari.IdleDeath.AudioVis:Clone()
					v_u_104.Beat.ImageColor3 = Color3.fromRGB(170, 255, 255)
					v_u_104.Parent = v_u_5.PlayerGui
					local v_u_105 = nil
					v_u_105 = v_u_2.Stepped:Connect(function(_, p106)
						-- upvalues: (copy) v_u_101, (copy) v_u_102, (copy) p_u_97, (copy) v_u_100, (ref) v_u_105, (ref) v_u_4, (ref) v_u_3, (copy) v_u_104, (ref) v_u_103
						if v_u_101.Parent and (v_u_102.Parent and (p_u_97.Parent and (v_u_100.Parent and p_u_97:GetAttribute("InUlt")))) then
							local v107 = v_u_101.TimePosition + v_u_103
							local v108 = v_u_102.TimePosition
							local v109 = v108 - v107
							if v109 < 0 then
								v109 = -v109
							end
							if v109 > 0.1 then
								v_u_102.TimePosition = v107
							elseif v107 < v108 then
								v_u_102.PlaybackSpeed = 0.99
							elseif v108 < v107 then
								v_u_102.PlaybackSpeed = 1.01
							else
								v_u_102.PlaybackSpeed = 1
							end
							local v110 = 2 - v_u_102.PlaybackLoudness / 330
							local v111 = math.clamp(v110, 1, (1 / 0))
							v_u_104.Beat.Size = v_u_104.Beat.Size:Lerp(UDim2.new(v111, 0, v111, 0), 0.5)
							if v_u_100.Health < 50 then
								local v112 = v_u_102
								local v113 = v_u_102.Volume
								v112.Volume = math.lerp(v113, 1, p106)
							else
								local v114 = v_u_102
								local v115 = v_u_102.Volume
								v114.Volume = math.lerp(v115, 0, p106)
							end
						else
							v_u_105:Disconnect()
							v_u_4:Create(v_u_101, TweenInfo.new(3), {
								["Volume"] = 0
							}):Play()
							v_u_3:AddItem(v_u_101, 3)
							v_u_4:Create(v_u_102, TweenInfo.new(3), {
								["Volume"] = 0
							}):Play()
							v_u_3:AddItem(v_u_102, 3)
							v_u_4:Create(v_u_104.Beat, TweenInfo.new(0.25), {
								["ImageTransparency"] = 1
							}):Play()
							v_u_3:AddItem(v_u_104, 0.25)
							return
						end
					end)
				end
			else
				return
			end
		end,
		["EveryLastDrop"] = function(p116)
			-- upvalues: (ref) v_u_7, (ref) v_u_5, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_4
			local v117 = v_u_7.Ryu.Larp:Clone()
			v117.Parent = v_u_5.PlayerGui
			v_u_3:AddItem(v117, 2)
			if p116 then
				v117.Beat.Size = UDim2.new(1, 0, 1, 0)
				v117.Beat.SizeConstraint = Enum.SizeConstraint.RelativeXY
				v117.Beat.Image = "rbxassetid://94473169004838"
				v117.Lyrics.TextColor3 = Color3.new(0, 0, 0)
				v117.Lyrics.Text = "LET\'S LARP!!!!!!!!!!!!!!!!!!!"
			end
			v_u_12:PlaySound(v_u_8.Ryu.Jingle, workspace, game.SoundService.Effect)
			v_u_4:Create(v117.Beat, TweenInfo.new(0.3), {
				["ImageTransparency"] = 0
			}):Play()
			local v118 = TweenInfo.new(1.5, Enum.EasingStyle.Linear)
			task.wait(0.5)
			v117.Beat.BackgroundTransparency = 1
			v_u_4:Create(v117.Beat, v118, {
				["ImageTransparency"] = 1
			}):Play()
			v_u_4:Create(v117.Lyrics, v118, {
				["TextTransparency"] = 1
			}):Play()
			v_u_4:Create(v117.Beat.Frame1, v118, {
				["BackgroundTransparency"] = 1
			}):Play()
			v_u_4:Create(v117.Beat.Frame2, v118, {
				["BackgroundTransparency"] = 1
			}):Play()
		end,
		["StartBeam"] = function(p_u_119)
			-- upvalues: (ref) v_u_15, (ref) v_u_9, (ref) v_u_7, (ref) v_u_1, (ref) v_u_35, (ref) v_u_12, (ref) v_u_8, (ref) v_u_14, (ref) v_u_40, (ref) v_u_4
			local v_u_120 = p_u_119:GetAttribute("BeamStartCFrame")
			local v121 = v_u_15.CFrame
			local v122 = v_u_120.Position - v121.Position
			if v122.Unit:Dot(v121.LookVector) >= 0.7 and v122.Magnitude < 70 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.SnapOh)
			end
			for _, v123 in v_u_7.Misc.M.Awk.mokultMeh["3"]:GetChildren() do
				v123:PivotTo(v_u_120 * CFrame.Angles(1.5707963267948966, 0, 0))
				v_u_1.GetController("MokouController"):ArcTween(v123.Start, true)
			end
			for _, v124 in v_u_7.Ryu.Launch:GetChildren() do
				v124:PivotTo(v_u_120 * CFrame.Angles(1.5707963267948966, 0, 0))
				v_u_1.GetController("MokouController"):ArcTween(v124.Start, true)
			end
			local v_u_125 = v_u_7.Ryu.FinalBeam:Clone()
			local v_u_126 = Instance.new("Vector3Value")
			v_u_126.Value = Vector3.new(30, 30, 180)
			v_u_35(v_u_125, v_u_120 * CFrame.new(0, 0, -5), (Vector3.new(30, 30, p_u_119:GetAttribute("BeamLength"))))
			v_u_125.Parent = workspace.Effects
			v_u_12:PlaySound(v_u_8.Ryu.UltimateFire, v_u_125.PinkStart, game.SoundService.Effect)
			local _ = v_u_120 * CFrame.new(0, 0, -3)
			local v_u_127 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_7, (ref) v_u_15, (ref) v_u_120, (ref) v_u_9, (ref) v_u_127, (ref) v_u_14, (copy) p_u_119, (ref) v_u_35, (copy) v_u_125, (copy) v_u_126
				local v128 = v_u_7.Yuta.LoveBeam.CameraFX:Clone()
				v128.TintColor = Color3.fromRGB(170, 255, 255)
				local v129
				if (v_u_15.CFrame.Position - v_u_120.Position).Magnitude < 180 then
					v129 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.HeavyHit)
				else
					v129 = nil
				end
				local v130 = v_u_127 and Vector3.new(1, 1, 0) * v_u_14:NextNumber(1, 5) or Vector3.new(0, 0, 0)
				v_u_120 = p_u_119:GetAttribute("BeamStartCFrame")
				local v131 = p_u_119
				v_u_35(v_u_125, v_u_120, v_u_126.Value * Vector3.new(1, 1, 0) + v130 + Vector3.new(0, 0, v131:GetAttribute("BeamLength")))
				local v132, v133 = v_u_125:GetBoundingBox()
				local v134 = v133 / 2
				local v135 = v132:PointToObjectSpace(v_u_15.CFrame.Position)
				local v136
				if v135.Z > v134.Z or v135.Z < -v134.Z then
					v136 = nil
				else
					v136 = (v135 * Vector3.new(1, 1, 0)).Magnitude <= v134.X and true or nil
				end
				if v136 then
					v128.Parent = game.Lighting
				else
					v128.Parent = nil
				end
				task.wait()
				if v_u_125.Parent then
					continue
				end
				if v129 then
					v129:StartFadeOut(0.5)
				end
				v128:Destroy()
			end)
			local v_u_137 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_40, (copy) v_u_125, (ref) v_u_137
				repeat
					task.spawn(v_u_40, v_u_125)
					task.wait(0.3)
				until not (v_u_125.Parent and v_u_137)
			end)
			v_u_4:Create(v_u_126, TweenInfo.new(0.3), {
				["Value"] = Vector3.new(60, 60, 180)
			}):Play()
			task.wait(0.3)
			v_u_4:Create(v_u_126, TweenInfo.new(0.1), {
				["Value"] = Vector3.new(40, 40, 180)
			}):Play()
			task.wait(0.1)
			v_u_4:Create(v_u_126, TweenInfo.new(1), {
				["Value"] = Vector3.new(30, 30, 180)
			}):Play()
			local function v145() -- name: updateWidth
				-- upvalues: (copy) p_u_119, (ref) v_u_4, (copy) v_u_126
				local v138 = p_u_119:GetAttribute("Width")
				local v139 = v_u_4
				local v140 = v_u_126
				local v141 = TweenInfo.new(0.2)
				local v142 = {}
				local v143 = v138.X - 5
				local v144 = v138.Y - 5
				v142.Value = Vector3.new(v143, v144, 180)
				v139:Create(v140, v141, v142):Play()
			end
			v145()
			p_u_119:GetAttributeChangedSignal("Width"):Connect(v145)
			repeat
				task.wait()
			until not p_u_119.Parent
			v_u_137 = false
			v_u_4:Create(v_u_125.BlackStart.Glow.PointLight, TweenInfo.new(1), {
				["Brightness"] = 0
			}):Play()
			v_u_4:Create(v_u_126, TweenInfo.new(0.5), {
				["Value"] = Vector3.new(0, 0, 180)
			}):Play()
			for _, v146 in v_u_125:GetDescendants() do
				if v146:IsA("Beam") then
					v_u_4:Create(v146, TweenInfo.new(0.25), {
						["Width0"] = 0,
						["Width1"] = 0
					}):Play()
				else
					if not v146:IsA("ParticleEmitter") then
						continue
					end
					v146.Enabled = false
				end
			end
			task.wait(0.25)
			v_u_127 = false
			task.wait(0.25)
			v_u_125:Destroy()
		end,
		["YutaClashing"] = function(p_u_147, p_u_148)
			-- upvalues: (ref) v_u_7, (ref) v_u_14, (ref) v_u_4
			local v_u_149 = v_u_7.Ryu.Clashing:Clone()
			v_u_149.Parent = workspace.Effects
			local function v_u_152(p150) -- name: toggleParticles
				-- upvalues: (copy) v_u_149
				for _, v151 in v_u_149:GetChildren() do
					if not v151:IsA("ParticleEmitter") then
						continue
					end
					v151.Enabled = p150
				end
			end
			task.spawn(function()
				-- upvalues: (copy) p_u_147, (copy) p_u_148, (ref) v_u_14, (copy) v_u_149, (copy) v_u_152, (ref) v_u_4
				while p_u_147.Parent and p_u_148.Parent do
					local v153 = p_u_147:GetAttribute("BeamStartCFrame") * CFrame.new(0, 0, -p_u_147:GetAttribute("BeamLength")) * CFrame.Angles(0, 3.141592653589793, 0)
					v_u_149.Size = Vector3.new(10, 10, 10) + Vector3.new(1, 1, 1) * v_u_14:NextNumber(1, 5)
					v_u_149.CFrame = v153
					task.wait()
				end
				v_u_152(false)
				v_u_4:Create(v_u_149, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(0, 0, 0)
				}):Play()
				task.wait(1)
				v_u_149:Destroy()
			end)
			v_u_149.Attachment.Impact1:Emit(15)
			v_u_149.Attachment.Impact2:Emit(15)
			task.wait(0.1)
			if p_u_147.Parent then
				v_u_152(true)
			end
		end
	}
	v_u_10.Effects:Connect(function(p155, ...)
		-- upvalues: (copy) v_u_154
		local v156 = v_u_154[p155]
		if v156 then
			v156(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("RyuService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13