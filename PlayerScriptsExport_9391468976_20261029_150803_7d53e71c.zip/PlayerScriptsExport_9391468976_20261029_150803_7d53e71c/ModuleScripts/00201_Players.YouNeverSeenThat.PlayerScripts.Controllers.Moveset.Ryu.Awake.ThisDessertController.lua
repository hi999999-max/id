-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Ryu.Awake.ThisDessertController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v_u_10 = require(v_u_6.Modules.BloodyZee)
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "ThisDessertController"
})
local v_u_14 = {
	"rbxassetid://1179108573",
	"rbxassetid://71845731466516",
	"rbxassetid://87448031781486",
	"rbxassetid://1195495141",
	"rbxassetid://139763419390819",
	"rbxassetid://118771487275303",
	"rbxassetid://132000956098235",
	"rbxassetid://86387593022324",
	"rbxassetid://119931280790531",
	"rbxassetid://81714155332842",
	"rbxassetid://71211268740252",
	"rbxassetid://86546583614760",
	"rbxassetid://1195495141",
	"rbxassetid://104840081726175",
	"rbxassetid://93699203917632",
	"rbxassetid://117187548246869",
	"rbxassetid://134478530219943",
	"rbxassetid://87702215058937",
	"rbxassetid://84891765170592",
	"rbxassetid://1195495141"
}
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_14, (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_1, (copy) v_u_3, (copy) v_u_10, (copy) v_u_5, (copy) v_u_9, (copy) v_u_4, (copy) v_u_6, (copy) v_u_2, (ref) v_u_11
	task.spawn(function()
		-- upvalues: (ref) v_u_14
		local v15 = {}
		for _, v16 in pairs(v_u_14) do
			table.insert(v15, v16)
		end
		game.ContentProvider:PreloadAsync(v15)
	end)
	local v_u_83 = {
		["Startup"] = function(p17)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v18 = p17:FindFirstChild("HumanoidRootPart")
			if v18 then
				v_u_12:PlaySound(v_u_8.Ryu.Dessert.Startup, v18, game.SoundService.Effect)
			end
		end,
		["Dash"] = function(p19)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_1
			local v20 = p19:FindFirstChild("HumanoidRootPart")
			if v20 then
				v_u_12:PlaySound(v_u_8.Ryu.Dessert.Dash, v20, game.SoundService.Effect)
				for _, v21 in v_u_7.Ryu.Launch:GetChildren() do
					v21:PivotTo(v20.CFrame * CFrame.Angles(1.5707963267948966, 0, 0))
					v_u_1.GetController("MokouController"):ArcTween(v21.Start, true)
				end
				task.wait(0.2)
				for _, v22 in v_u_7.Ryu.Doosh:GetChildren() do
					v22:PivotTo(v20.CFrame * CFrame.Angles(1.5707963267948966, 0, 0))
					v_u_1.GetController("MokouController"):ArcTween(v22.Start, true)
				end
				task.wait(0.4)
				v_u_12:PlaySound(v_u_8.Ryu.Dessert.Slide, v20, game.SoundService.Effect)
				v_u_12:DustTrail(p19, 1)
			end
		end,
		["FirstHit"] = function(p23, p24, p25)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_10, (ref) v_u_5, (ref) v_u_9
			local v26 = p23:FindFirstChild("HumanoidRootPart")
			if v26 then
				if p24:FindFirstChild("HumanoidRootPart") then
					v_u_12:Flash(p24, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Ryu.Dessert.Hit, v26, game.SoundService.Effect)
					local v27 = v_u_7.Mahito.CrushingRushdown.DrillImpact:Clone()
					v27.Position = v26.Position
					v27.Parent = workspace.Effects
					v_u_3:AddItem(v27, 1)
					v27.Sparks.Color = ColorSequence.new(Color3.fromRGB(170, 255, 255))
					v27.Wind.Color = v27.Sparks.Color
					v27.Wind2.Color = v27.Sparks.Color
					v27.Sparks:Emit(30)
					v27.Wind2:Emit(7)
					if p25 then
						for _ = 1, 20 do
							v_u_10:Blood(p24.Head.CFrame, math.random(5, 60), 20, 20)
						end
					end
					if v_u_5.Character == p23 or v_u_5.Character == p24 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.SnapOh)
					end
				end
			else
				return
			end
		end,
		["Swing"] = function(p28)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v29 = p28:FindFirstChild("HumanoidRootPart")
			if v29 then
				local v30 = v_u_7.Ryu.Slash:Clone()
				v30.Weld.Part0 = v29
				v30.Weld.C0 = CFrame.Angles(0, 0, 0.7853981633974483)
				v30.Weld.C1 = CFrame.Angles(0, -1.5707963267948966, 0)
				v30.Parent = workspace.Effects
				v_u_3:AddItem(v30, 0.15)
				local v31 = TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
				local v32 = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				v_u_4:Create(v30.Weld, v31, {
					["C1"] = v30.Weld.C1 * CFrame.Angles(0, -1.7453292519943295, 0)
				}):Play()
				for _, v33 in v30:GetDescendants() do
					if v33:IsA("Decal") then
						v_u_4:Create(v33, v32, {
							["Transparency"] = 1
						}):Play()
					else
						if not v33:IsA("SpecialMesh") then
							continue
						end
						v_u_4:Create(v33, v31, {
							["Scale"] = v33.Scale * 1.2
						}):Play()
					end
				end
			end
		end,
		["StartHit"] = function(p34, p35)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_6, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v36 = p34:FindFirstChild("HumanoidRootPart")
			if v36 then
				if p35:FindFirstChild("HumanoidRootPart") then
					v_u_12:Flash(p35, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Ryu.Dessert.LongHit, v36, game.SoundService.Effect)
					for v37 = 1, 2 do
						local v38 = v37 == 1 and p34 and p34 or p35
						local v39 = v_u_6.Utils.Gojo.HandTrail:Clone()
						v39.Parent = workspace.Effects
						v39.Trail.Color = ColorSequence.new(v38["Left Arm"].Color)
						v39.Weld.Part0 = v38["Left Arm"]
						v_u_3:AddItem(v39, 4)
						local v40 = v_u_6.Utils.Gojo.HandTrail:Clone()
						v40.Parent = workspace.Effects
						v40.Trail.Color = ColorSequence.new(v38["Right Arm"].Color)
						v40.Weld.Part0 = v38["Right Arm"]
						local v41 = v40.Weld
						v41.C1 = v41.C1 * CFrame.Angles(0, 3.141592653589793, 0)
						v_u_3:AddItem(v40, 4)
					end
					if v_u_5.Character == p34 or v_u_5.Character == p35 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.SnapOh)
					end
				end
			else
				return
			end
		end,
		["Flash"] = function(p_u_42, p_u_43, p_u_44)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_10, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_2, (ref) v_u_14, (ref) v_u_4, (ref) v_u_9
			local v_u_45 = p_u_42:FindFirstChild("HumanoidRootPart")
			if v_u_45 then
				local v46 = p_u_43:FindFirstChild("HumanoidRootPart")
				if v46 then
					task.spawn(function()
						-- upvalues: (copy) p_u_44, (ref) v_u_7, (ref) v_u_3, (copy) p_u_43, (ref) v_u_10, (copy) p_u_42, (ref) v_u_12, (ref) v_u_8, (copy) v_u_45
						if p_u_44 == 1 and _G.Settings.Gore == true then
							local v_u_47 = v_u_7.Naoya.BleedFreeze.Attachment:Clone()
							v_u_47.Position = Vector3.new(0, -0.5, 0.5)
							v_u_47.Blood.Enabled = false
							v_u_47.Blood.LockedToPart = true
							v_u_3:AddItem(v_u_47, 1)
							v_u_47.Parent = p_u_43.Head
							v_u_47.Blood:Emit(7)
							task.delay(0.05, function()
								-- upvalues: (copy) v_u_47, (ref) v_u_10, (ref) p_u_43
								v_u_47.Blood.TimeScale = 0
								task.wait(0.37)
								v_u_47.Blood.TimeScale = 1
								for _ = 1, 8 do
									v_u_10:Blood(p_u_43.Head.CFrame, math.random(5, 80), 25, 25)
								end
							end)
						elseif p_u_44 == 2 then
							if _G.Settings.Gore == true then
								local v_u_48 = v_u_7.Naoya.BleedFreeze.Attachment:Clone()
								v_u_48.Position = Vector3.new(0, -0.5, 0.5)
								v_u_48.Blood.Enabled = false
								v_u_48.Blood.LockedToPart = true
								v_u_3:AddItem(v_u_48, 1)
								v_u_48.Parent = p_u_42.Head
								v_u_48.Blood:Emit(7)
								task.delay(0.05, function()
									-- upvalues: (copy) v_u_48, (ref) v_u_10, (ref) p_u_42
									v_u_48.Blood.TimeScale = 0
									task.wait(0.42)
									v_u_48.Blood.TimeScale = 1
									for _ = 1, 8 do
										v_u_10:Blood(p_u_42.Head.CFrame, math.random(5, 80), 25, 25)
									end
								end)
							end
							task.wait(0.45)
							v_u_12:PlaySound(v_u_8.Ryu.Dessert.Impact, v_u_45, game.SoundService.Effect)
						end
					end)
					if v_u_5.Character == p_u_42 or v_u_5.Character == p_u_43 then
						if p_u_44 == 1 then
							local v49 = v_u_7.Ryu.DOF:Clone()
							v49.Parent = game.Lighting
							v_u_3:AddItem(v49, 0.4)
							local v50 = v_u_7.Ryu.Lines:Clone()
							v50.Parent = v_u_5.PlayerGui
							v_u_3:AddItem(v50, 0.4)
							local v51 = CFrame.new(-0.542443275, 1.10020399, -3.05016518, -0.37603417, -0.910731256, -0.170783877, -0.892315924, 0.306238711, 0.331647605, -0.249741182, 0.27710408, -0.927816153)
							workspace.CurrentCamera.CameraType = Enum.CameraType.Scriptable
							workspace.CurrentCamera.FieldOfView = 30
							local v52 = tick() + 0.4
							repeat
								workspace.CurrentCamera.CFrame = p_u_43.Head.CFrame:ToWorldSpace(v51)
								v_u_2.RenderStepped:Wait()
							until v52 < tick() or not (v_u_45.Parent and v46.Parent)
							workspace.CurrentCamera.CameraType = Enum.CameraType.Custom
							workspace.CurrentCamera.FieldOfView = 70
							return
						end
						if p_u_44 == 2 then
							local v53 = v_u_7.Ryu.DOF:Clone()
							v53.Parent = game.Lighting
							v_u_3:AddItem(v53, 0.45)
							local v54 = v_u_7.Ryu.Lines:Clone()
							v54.Parent = v_u_5.PlayerGui
							v_u_3:AddItem(v54, 0.45)
							v54.Line1.Rotation = 7
							v54.Line2.Rotation = 7
							v54.Line1.Position = UDim2.new(0.1, 0, 0.5, 0)
							v54.Line2.Position = UDim2.new(1, 0, 0.5, 0)
							local v55 = CFrame.new(-0.610998154, 0.568918705, -3.20584297, -0.879151344, 0.442517459, -0.176836967, 0.413873523, 0.89296639, 0.176974386, 0.236223653, 0.0823992491, -0.968198776)
							workspace.CurrentCamera.CameraType = Enum.CameraType.Scriptable
							workspace.CurrentCamera.FieldOfView = 30
							local v56 = tick() + 0.45
							repeat
								workspace.CurrentCamera.CFrame = p_u_42.Head.CFrame:ToWorldSpace(v55)
								v_u_2.RenderStepped:Wait()
							until v56 < tick() or not (v_u_45.Parent and v46.Parent)
							if not (v_u_45.Parent and v46.Parent) then
								return
							end
							task.spawn(function()
								-- upvalues: (ref) v_u_7, (ref) v_u_12, (copy) p_u_42, (copy) p_u_43, (ref) v_u_5, (ref) v_u_3, (ref) v_u_14, (ref) v_u_4
								local v57 = v_u_7.Ryu.DessertImpact:Clone()
								v57.ViewportFrame.CurrentCamera = workspace.CurrentCamera
								v_u_12:WorldModelChar(p_u_42, v57.ViewportFrame)
								v_u_12:WorldModelChar(p_u_43, v57.ViewportFrame)
								v57.Parent = v_u_5.PlayerGui
								v_u_3:AddItem(v57, 2.4)
								for v58 = 1, #v_u_14 do
									local v59 = Instance.new("ImageLabel")
									v59.Name = tostring(v58)
									v59.Image = v_u_14[v58]
									v59.Size = UDim2.new(0, 1, 0, 1)
									v59.ZIndex = 3
									v59.BackgroundColor3 = Color3.new(0, 0, 0)
									v59.Parent = v57.Impact
								end
								if _G.Settings.Flash == true then
									local v60 = tick()
									for v61 = 1, #v_u_14 do
										v57.Impact[tostring(v61)].Size = UDim2.new(1, 0, 1, 0)
										if v61 ~= 1 then
											local v62 = v57.Impact
											local v63 = v61 - 1
											v62[tostring(v63)]:Destroy()
										end
										repeat
											task.wait()
										until tick() - v60 >= 0.05
										v60 = tick()
									end
								else
									v57.Impact["1"].Size = UDim2.new(1, 0, 1, 0)
									task.wait(#v_u_14 * 0.05)
								end
								v57.Impact:Destroy()
								v57.Fade.Visible = true
								v_u_4:Create(v57.Fade, TweenInfo.new(1), {
									["BackgroundTransparency"] = 1
								}):Play()
								v_u_4:Create(v57.Fade, TweenInfo.new(1.3), {
									["ImageTransparency"] = 1
								}):Play()
								v_u_4:Create(v57.BG.ImageLabel, TweenInfo.new(1.4, Enum.EasingStyle.Linear), {
									["Position"] = UDim2.new(0, 0, 0, 0)
								}):Play()
							end)
							local v64 = CFrame.new(-7.05208826, 0.152262688, -8.68662262, -0.746794939, -0.0204642545, -0.664739549, 1.86264515e-9, 0.99952662, -0.0307707973, 0.6650545, -0.0229794774, -0.746441305)
							local v65 = tick() + 2.4
							repeat
								workspace.CurrentCamera.CFrame = v_u_45.CFrame:ToWorldSpace(v64)
								v_u_2.RenderStepped:Wait()
							until v65 < tick() or not (v_u_45.Parent and v46.Parent)
							workspace.CurrentCamera.CameraType = Enum.CameraType.Custom
							workspace.CurrentCamera.FieldOfView = 70
							game.Lighting.ExposureCompensation = 2
							v_u_4:Create(game.Lighting, TweenInfo.new(1), {
								["ExposureCompensation"] = 0
							}):Play()
							v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
							v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.HeavyHit):StartFadeOut(2)
							if _G.Settings.Flash ~= true then
								return
							end
							local v66 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
							v66.Parent = game.Lighting
							task.wait(0.04)
							v66.TintColor = Color3.new(1, 1, 1)
							task.wait(0.04)
							v66.Brightness = 200
							v66.Contrast = -1000
							task.wait(0.04)
							v66:Destroy()
						end
					end
				end
			else
				return
			end
		end,
		["Hit1"] = function(p67)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_9
			local v68 = p67:FindFirstChild("HumanoidRootPart")
			if v68 then
				v_u_12:Flash(p67, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Ryu.Unsatisfied:FindFirstChild("Hit" .. math.random(1, 3)), v68, game.SoundService.Effect)
				v_u_10:Blood(p67.Head.CFrame, math.random(5, 80), 25, 25)
				local v69 = math.random(400, 600) / 10
				local v70 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v70.Transparency = 0.9
				v70.Position = p67.Head.Position
				local v71 = math.random(-180, 180)
				local v72 = math.random(-180, 180)
				local v73 = math.random
				v70.Orientation = Vector3.new(v71, v72, v73(-180, 180))
				v70.Size = Vector3.new(0, 0, 7)
				v70.Parent = workspace.Effects
				v_u_4:Create(v70, TweenInfo.new(0.1, Enum.EasingStyle.Quad), {
					["Size"] = nil,
					["Transparency"] = 1,
					["Size"] = Vector3.new(v69, v69, 0)
				}):Play()
				v_u_3:AddItem(v70, 0.1)
				if (workspace.CurrentCamera.CFrame.Position - v68.Position).Magnitude < 70 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Weave"] = function(p74)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v75 = p74:FindFirstChild("HumanoidRootPart")
			if v75 then
				v_u_12:PlaySound(v_u_8.Itadori.ManjiKick.Dodge, v75, game.SoundService.Effect)
				local v76 = v_u_7.Damage.HitGlow:Clone()
				if p74:GetScale() ~= 1 then
					v76:ScaleTo(p74:GetScale())
				end
				v76.Parent = workspace.Effects
				v_u_3:AddItem(v76, 0.4)
				for _, v77 in v76:GetChildren() do
					local v78 = p74:FindFirstChild(v77.Name)
					if v78 then
						v77.CFrame = v78.CFrame
					end
					v77.Color = Color3.new(0, 0, 0)
					v77.Anchored = true
					v77.Transparency = 0.1
					v_u_4:Create(v77, TweenInfo.new(0.4), {
						["Transparency"] = 1
					}):Play()
				end
			end
		end,
		["FinalHit"] = function(p79, p80)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			if p79:FindFirstChild("HumanoidRootPart") then
				local v81 = p80:FindFirstChild("HumanoidRootPart")
				if v81 then
					local v82 = v_u_7.Mahito.CrushingRushdown.DrillImpact:Clone()
					v82.Position = v81.Position
					v82.Parent = workspace.Effects
					v_u_3:AddItem(v82, 1)
					v82.Sparks.Color = ColorSequence.new(Color3.fromRGB(170, 255, 255))
					v82.Wind.Color = v82.Sparks.Color
					v82.Wind2.Color = v82.Sparks.Color
					v82.Sparks:Emit(50)
					v82.Wind:Emit(7)
					v82.Wind2:Emit(7)
					v_u_12:Flash(p80, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Hakari.EnergySurge.Hit1, v81, game.SoundService.Effect)
					if v_u_5.Character == p79 or v_u_5.Character == p80 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
					end
				end
			else
				return
			end
		end
	}
	v_u_11.Effects:Connect(function(p84, ...)
		-- upvalues: (copy) v_u_83
		local v85 = v_u_83[p84]
		if v85 then
			v85(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12
	v_u_11 = v_u_1.GetService("ThisDessertService")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13