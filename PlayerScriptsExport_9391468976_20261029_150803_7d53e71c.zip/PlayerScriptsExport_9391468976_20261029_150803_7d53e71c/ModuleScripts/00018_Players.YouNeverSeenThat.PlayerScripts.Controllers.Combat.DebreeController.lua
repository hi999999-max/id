-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Combat.DebreeController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = game:GetService("Debris")
game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("SoundService")
local v4 = game:GetService("ReplicatedStorage")
local v5 = workspace.Map
local v_u_6 = v4.Utils
local v_u_7 = v4.Sounds
local v8 = v4.Modules.Destruction
local v_u_9 = false
local v_u_10 = workspace.CurrentCamera
local v_u_11 = nil
local v_u_12 = nil
local _ = v_u_6.Damage.DebreeRef
local v_u_13 = CFrame.new(16777216, 16777216, 16777216)
local v_u_14 = require(v8.Grid)
local v_u_15 = require("@self/BufferRead")
local v_u_16 = require(v4.Knit.Knit)
local v_u_17 = require(v8.GetInterval)
local v18 = require(v8.ObjectCache)
local v_u_19 = table.create(2000)
local v_u_20 = table.create(2000)
local v_u_21 = {}
local v_u_22 = {}
local v_u_23 = v18.new(v_u_6.Damage.DebreeRef, v5.Data, 2000, v_u_13)
local v_u_24 = v_u_16.CreateController({
	["Name"] = "DebreeController"
})
local function v_u_25() -- name: sendLoadedEvent
	-- upvalues: (ref) v_u_9, (ref) v_u_12
	while not v_u_9 do
		v_u_12.Loaded:Fire()
		task.wait(1)
	end
end
local function v_u_30(p26, p27) -- name: pushVoxelInterp
	-- upvalues: (copy) v_u_14, (copy) v_u_10, (copy) v_u_17, (copy) v_u_22
	local v28 = v_u_17((v_u_14.getChunkDistanceSquared(p27.Position, v_u_10.CFrame.Position)))
	if v28 then
		local v29 = v_u_22[p26]
		if not v29 then
			v_u_22[p26] = {
				["Alpha"] = 0,
				["Rate"] = nil,
				["Goal"] = nil,
				["Start"] = nil,
				["Goal"] = p27,
				["Start"] = p26.CFrame
			}
			v29 = v_u_22[p26]
		end
		v29.Alpha = 0
		v29.Goal = p27
		v29.Start = p26.CFrame
		v29.Rate = 1 / v28
	end
end
local function v_u_41(p31) -- name: interpolateParts
	-- upvalues: (copy) v_u_22, (copy) v_u_19, (copy) v_u_20
	if _G.Settings.DesINT == true then
		for v32, v33 in v_u_22 do
			local v34 = v33.Rate
			if v34 and v33.Alpha < 1 then
				local v35 = v33.Alpha + p31 * v34
				local v36 = math.min(v35, 1)
				v33.Alpha = v36
				local v37 = v_u_19
				table.insert(v37, v32)
				local v38 = v_u_20
				local v39 = v33.Start
				local v40 = v33.Goal
				table.insert(v38, v39:Lerp(v40, v36))
			else
				v_u_22[v32] = nil
			end
		end
	end
end
function v_u_24.GetVoxel(_, p42) -- name: GetVoxel
	-- upvalues: (copy) v_u_21
	return v_u_21[p42]
end
function v_u_24.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_2, (copy) v_u_41, (copy) v_u_19, (copy) v_u_20, (ref) v_u_12, (ref) v_u_9, (copy) v_u_15, (copy) v_u_23, (copy) v_u_21, (copy) v_u_6, (copy) v_u_1, (copy) v_u_22, (copy) v_u_24, (copy) v_u_30, (ref) v_u_11, (copy) v_u_7, (copy) v_u_3, (copy) v_u_13, (copy) v_u_25
	v_u_2.RenderStepped:Connect(function(...)
		-- upvalues: (ref) v_u_41, (ref) v_u_19, (ref) v_u_20
		v_u_41(...)
		if #v_u_19 > 0 then
			workspace:BulkMoveTo(v_u_19, v_u_20, Enum.BulkMoveMode.FireCFrameChanged)
			table.clear(v_u_19)
			table.clear(v_u_20)
		end
	end)
	v_u_12.Loaded:Connect(function()
		-- upvalues: (ref) v_u_9
		v_u_9 = true
	end)
	v_u_12.Create:Connect(function(p43, p44, p45, p46, p47)
		-- upvalues: (ref) v_u_15, (ref) v_u_23, (ref) v_u_21, (ref) v_u_19, (ref) v_u_20, (ref) v_u_6, (ref) v_u_1
		local v_u_48 = {}
		local v_u_49
		if _G.Settings.DesVFX == true then
			v_u_49 = not p47
		else
			v_u_49 = false
		end
		v_u_15.Create(p43, p44, p45, p46, function(p50, p51, p52, p53, p54, p55)
			-- upvalues: (ref) v_u_23, (ref) v_u_21, (ref) v_u_19, (ref) v_u_20, (copy) v_u_49, (copy) v_u_48
			local v56 = v_u_23.Get()
			v56.Size = p52
			v56.Color = p53
			v56.Transparency = p54
			v56.Locked = p52.Magnitude <= 2.9
			v56.Material = p55
			v_u_21[p50] = v56
			local v57 = v_u_19
			table.insert(v57, v56)
			local v58 = v_u_20
			table.insert(v58, p51)
			if v_u_49 and not v56.Locked then
				local v59 = v_u_48
				table.insert(v59, v56)
			end
		end)
		if #v_u_19 > 0 then
			workspace:BulkMoveTo(v_u_19, v_u_20, Enum.BulkMoveMode.FireCFrameChanged)
			table.clear(v_u_19)
			table.clear(v_u_20)
		end
		if #v_u_48 > 0 then
			for _, v60 in v_u_48 do
				local v61 = v_u_6.Damage.Break:Clone()
				v61.Color = ColorSequence.new(v60.Color)
				v61.Parent = v60
				v61:Emit(1)
				v_u_1:AddItem(v61, 1.5)
			end
		end
	end)
	v_u_12.Physics:Connect(function(p62, p_u_63)
		-- upvalues: (ref) v_u_22, (ref) v_u_15, (ref) v_u_24, (ref) v_u_19, (ref) v_u_20, (ref) v_u_30
		local v_u_64 = _G.Settings.DesINT == true
		if not v_u_64 and next(v_u_22) then
			table.clear(v_u_22)
		end
		v_u_15.Physics(p62, function(p65, p66)
			-- upvalues: (ref) v_u_24, (copy) v_u_64, (copy) p_u_63, (ref) v_u_19, (ref) v_u_20, (ref) v_u_30
			local v67 = v_u_24:GetVoxel(p65)
			if v67 and v67.Parent then
				if v_u_64 and not p_u_63 then
					v_u_30(v67, p66)
				else
					local v68 = v_u_19
					table.insert(v68, v67)
					local v69 = v_u_20
					table.insert(v69, p66)
				end
			else
				return
			end
		end)
	end)
	v_u_12.Domain:Connect(function(p70)
		-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_3
		v_u_11:PlaySound(v_u_7.Misc.Domain.DomainHit, p70, v_u_3.Effect)
		local v71 = p70:FindFirstChild("DomainCollider")
		if v71 then
			v_u_11:PlaySound(v_u_7.Misc.Domain.DomainHit, v71, v_u_3.Effect)
		end
	end)
	v_u_12.Sound:Connect(function(p72)
		-- upvalues: (ref) v_u_15, (ref) v_u_24, (ref) v_u_11
		v_u_15.Sound(p72, function(p73)
			-- upvalues: (ref) v_u_24, (ref) v_u_11
			local v74 = v_u_24:GetVoxel(p73)
			if v74 and v74.Parent then
				v_u_11:DebreeSound(v74)
			end
		end)
	end)
	v_u_12.Destroy:Connect(function(p75)
		-- upvalues: (ref) v_u_15, (ref) v_u_24, (ref) v_u_23, (ref) v_u_22, (ref) v_u_21, (ref) v_u_19, (ref) v_u_20, (ref) v_u_13
		local v_u_76 = _G.Settings.DesVFX == true
		v_u_15.Destroy(p75, function(p77)
			-- upvalues: (ref) v_u_24, (copy) v_u_76, (ref) v_u_23, (ref) v_u_22, (ref) v_u_21, (ref) v_u_19, (ref) v_u_20, (ref) v_u_13
			local v78 = v_u_24:GetVoxel(p77)
			if v78 and v78.Parent then
				local v79
				if v_u_76 then
					v79 = v78:FindFirstChild("Break") or nil
				else
					v79 = nil
				end
				if v78.Locked then
					v78.Locked = false
				end
				if v79 then
					v79:Destroy()
				end
				v_u_23.Return(v78)
				v_u_22[v78] = nil
				v_u_21[p77] = nil
				local v80 = v_u_19
				table.insert(v80, v78)
				local v81 = v_u_20
				local v82 = v_u_13
				table.insert(v81, v82)
			end
		end)
	end)
	v_u_12.MoveAway:Connect(function(p83)
		-- upvalues: (ref) v_u_19, (ref) v_u_20, (ref) v_u_13
		for _, v84 in p83 do
			local v85 = v_u_19
			table.insert(v85, v84)
			local v86 = v_u_20
			local v87 = v_u_13
			table.insert(v86, v87)
		end
		if #v_u_19 > 0 then
			workspace:BulkMoveTo(v_u_19, v_u_20, Enum.BulkMoveMode.FireCFrameChanged)
			table.clear(v_u_19)
			table.clear(v_u_20)
		end
	end)
	v_u_12.MoveIn:Connect(function(p88, p89)
		-- upvalues: (ref) v_u_15, (ref) v_u_19, (ref) v_u_20
		local v90 = v_u_15.MoveIn(p89)
		for v91, v92 in p88 do
			local v93 = v_u_19
			table.insert(v93, v92)
			local v94 = v_u_20
			local v95 = v90[v91]
			table.insert(v94, v95)
		end
	end)
	v_u_25()
end
function v_u_24.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_12, (copy) v_u_16, (ref) v_u_11
	v_u_12 = v_u_16.GetService("DebreeService")
	v_u_11 = v_u_16.GetController("FXController")
end
return v_u_24