-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Combat.HandicapController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v2 = game:GetService("Players")
game:GetService("UserInputService")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Debris")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game:GetService("CollectionService")
local v_u_7 = v2.LocalPlayer
local v_u_8 = game.ReplicatedStorage
local v_u_9 = v_u_8.Animations
local v_u_10 = v_u_8.Utils
local v_u_11 = v_u_8.Sounds
local v_u_12 = require(v_u_8.Modules.DamageCounter)
local v_u_13 = require(v_u_8.Modules.CameraShaker)
local v_u_14 = require(v_u_8.Modules.BloodyZee)
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = nil
local v_u_18 = nil
local v_u_19 = nil
local v20 = v_u_1.CreateController({
	["Name"] = "HandicapController"
})
local v_u_21 = RaycastParams.new()
v_u_21.FilterType = Enum.RaycastFilterType.Include
v_u_21.FilterDescendantsInstances = { workspace.Map }
function v20.GetCharacterHeight(_, p22) -- name: GetCharacterHeight
	if not p22 then
		return 0
	end
	local v23 = p22:FindFirstChild("HumanoidRootPart")
	local v24 = p22:FindFirstChild("Humanoid")
	local v25 = p22:FindFirstChild("Left Leg")
	local v26 = p22:FindFirstChild("Right Leg")
	if not (v23 and (v24 and (v25 and v26))) then
		return 0
	end
	local v27 = v23.Size.Y / 2
	local v28 = v25.Size.Y
	local v29 = v26.Size.Y
	if v29 < v28 then
		v29 = v28 or v29
	end
	return v24.HipHeight + v27 + v29
end
function v20.Swing(_, _, p_u_30, p31, p_u_32, p_u_33) -- name: Swing
	-- upvalues: (copy) v_u_7, (copy) v_u_5, (copy) v_u_21, (copy) v_u_3
	local v34 = v_u_7.Character
	if v34 then
		local v_u_35 = v34:FindFirstChild("HumanoidRootPart")
		if v_u_35 then
			local v_u_36
			if p31 then
				v_u_36 = Instance.new("NumberValue", p_u_30)
				v_u_36.Value = p_u_32.Magnitude
				v_u_5:Create(v_u_36, TweenInfo.new(p31, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
					["Value"] = 0
				}):Play()
			else
				v_u_36 = nil
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_35, (copy) p_u_32, (copy) p_u_33, (ref) v_u_21, (ref) v_u_36, (copy) p_u_30, (ref) v_u_3
				local v37 = v_u_35.CFrame:VectorToWorldSpace(p_u_32)
				if p_u_33 and workspace:Blockcast(v_u_35.CFrame, Vector3.new(2, 2, 1), v37.Unit * 1.5, v_u_21) then
					local v38 = v37.Y
					v37 = Vector3.new(0, v38, 0)
				end
				if v_u_36 then
					p_u_30.Velocity = v37.Unit * v_u_36.Value
				else
					p_u_30.Velocity = v37
				end
				v_u_3.Stepped:Wait()
				if p_u_30.Parent and v_u_35.Parent then
					continue
				end
			end)
		end
	else
		return
	end
end
function v20.MovementForce(_, p39, p40, p41, p42) -- name: MovementForce
	-- upvalues: (copy) v_u_5, (copy) v_u_4
	local v43 = Instance.new("BodyVelocity", p39.Torso)
	v43.MaxForce = Vector3.new(40000, 40000, 40000)
	v43.P = 40000
	v43.Name = "MovementForce"
	v43.Velocity = p40
	v_u_5:Create(v43, TweenInfo.new(0.3), {
		["Velocity"] = p41
	}):Play()
	v_u_4:AddItem(v43, p42)
end
function v20.ClearForce(_, p44, p45) -- name: ClearForce
	for _, v46 in p44:GetChildren() do
		if not v46:IsA("BodyVelocity") or p45 and v46 == p45 or v46.Name ~= "SwingForce" and v46.Name ~= "MovementForce" then
			continue
		end
		v46:Destroy()
	end
end
function v20.KnitStart(p_u_47) -- name: KnitStart
	-- upvalues: (ref) v_u_15, (copy) v_u_3, (copy) v_u_4, (copy) v_u_21, (copy) v_u_11, (ref) v_u_18, (copy) v_u_7, (copy) v_u_13, (copy) v_u_10, (copy) v_u_1, (copy) v_u_9, (copy) v_u_5, (copy) v_u_14, (copy) v_u_12, (copy) v_u_8, (copy) v_u_6, (ref) v_u_19, (ref) v_u_17, (ref) v_u_16
	local v_u_48 = {}
	v_u_15.Effects:Connect(function(p_u_49, p50, p_u_51, p_u_52, p53)
		-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_21, (ref) v_u_11, (ref) v_u_18, (ref) v_u_7, (ref) v_u_13, (ref) v_u_10, (copy) p_u_47, (ref) v_u_1, (ref) v_u_9, (ref) v_u_5, (ref) v_u_14, (copy) v_u_48, (ref) v_u_12
		if p50 == "Collide" then
			local v_u_54 = false
			local v_u_55 = false
			local v_u_56 = nil
			local v_u_57 = tick()
			local v_u_58 = Vector3.new(1000000000, 1000000000, 1000000000)
			local v_u_59 = nil
			v_u_59 = v_u_3.Stepped:Connect(function(_, p60)
				-- upvalues: (copy) p_u_49, (copy) p_u_51, (ref) v_u_59, (ref) v_u_56, (ref) v_u_4, (ref) v_u_21, (ref) v_u_54, (ref) v_u_11, (ref) v_u_18, (ref) v_u_55, (ref) v_u_58, (ref) v_u_7, (ref) v_u_13, (ref) v_u_57, (ref) v_u_10
				if p_u_49 and (p_u_49.Parent and (p_u_51.Parent and p_u_51:GetAttribute("Ragdoll") > 0)) then
					local v61 = p_u_49.Velocity.Magnitude
					local v62 = workspace:Raycast(p_u_49.Position, Vector3.new(0, -3, 0), v_u_21)
					if v62 and v_u_54 == false then
						v_u_54 = true
						local v63 = v_u_11.Impact.Players["RagdollFall" .. math.random(1, 3)]
						local v64 = p_u_49.Velocity.Magnitude / 50
						v63.Volume = math.clamp(v64, 0, 3)
						v_u_18:PlaySound(v63, p_u_49, game.SoundService.Effect)
					elseif not v62 and v_u_54 == true then
						v_u_54 = false
					end
					local v65 = p_u_49.Velocity * p60 * 3
					local v66 = workspace:Raycast(p_u_49.Position, v65, v_u_21)
					if v66 and v61 > 100 then
						if v_u_55 == false then
							v_u_55 = true
							if (v66.Position - v_u_58).Magnitude > 5 then
								v_u_58 = v66.Position
								v_u_18:PlaySound(v_u_11.Hakari.OverLuck.Hit1, p_u_49, game.SoundService.Effect)
								v_u_18:PlaySound(v_u_11.Itadori.Rush.RushLaunch, p_u_49, game.SoundService.Effect)
								v_u_18:DustBreak(v66.Position - v65.Unit, -v65, 4, 1, 0.4, 1)
								if v_u_7:DistanceFromCharacter(p_u_49.Position) < 100 then
									v_u_13.CurrentShaker:Shake(v_u_13.Presets.Snap)
								end
							end
						end
					else
						v_u_55 = false
					end
					if _G.Settings.DesPHY and (tick() - v_u_57 > 0.05 and v61 > 50) then
						v_u_57 = tick()
						v_u_18:DustBreak(p_u_49.Position, Vector3.new(0, 1, 0), 3, 2, 0.4, 1, 4)
					end
					if v61 >= 100 then
						if v_u_56 == nil then
							v_u_56 = v_u_10.Damage.RagdollWind:Clone()
							v_u_56.Parent = workspace.Effects
						end
						v_u_56.Wind1.Enabled = true
						v_u_56.Wind2.Enabled = true
						v_u_56.Trail.Enabled = v61 > 150
						if p_u_49.Parent then
							v_u_56.CFrame = CFrame.new(p_u_49.Position, p_u_49.Position - p_u_49.Velocity)
							return
						end
					elseif v_u_56 then
						v_u_56.Wind1.Enabled = false
						v_u_56.Wind2.Enabled = false
						v_u_56.Trail.Enabled = false
					end
				else
					v_u_59:Disconnect()
					if v_u_56 ~= nil then
						v_u_56.Wind1.Enabled = false
						v_u_56.Wind2.Enabled = false
						v_u_56.Trail.Enabled = false
						v_u_4:AddItem(v_u_56, 0.2)
					end
				end
			end)
			return
		end
		if p50 == "Swing" then
			p_u_47:Swing(p_u_49.Parent, p_u_49, p_u_51, p_u_52, p53)
			return
		end
		if p50 == "Death" then
			if _G.Settings.VolKS == false then
				return
			else
				local v67 = p_u_51:FindFirstChild("HumanoidRootPart")
				if v67 then
					local v68 = v_u_11.Impact.Players.Death:Clone()
					v68.SoundGroup = game.SoundService.Effect
					v68.SoundId = "rbxassetid://" .. p_u_49
					v68.Volume = 1
					v68.Parent = v67
					v68:Play()
					v_u_4:AddItem(v68, 4)
				end
			end
		end
		if p50 == "Spawn" then
			local v_u_69 = p_u_51:FindFirstChild("HumanoidRootPart")
			if not v_u_69 then
				return
			end
			local v_u_70 = v_u_1.GetController(p_u_52 .. "Controller")
			if v_u_70 and (v_u_70.SpawnFunc and v_u_70.SpawnAnim) then
				local v_u_71 = {}
				local v_u_72 = v_u_69.Position
				v_u_9.Misc.SpawnAnim.AnimationId = "rbxassetid://" .. v_u_70.SpawnAnim
				local v_u_73 = p_u_51.Humanoid:LoadAnimation(v_u_9.Misc.SpawnAnim)
				local v75 = v_u_73:GetMarkerReachedSignal("Function"):Connect(function(p74)
					-- upvalues: (copy) v_u_70, (copy) p_u_51, (copy) v_u_71
					if v_u_70.SpawnFunc[p74] then
						v_u_70.SpawnFunc[p74](p_u_51, v_u_71)
					end
				end)
				table.insert(v_u_71, v75)
				local v76 = p_u_51.Info.ChildAdded:Connect(function()
					-- upvalues: (copy) v_u_73
					v_u_73:Stop()
				end)
				table.insert(v_u_71, v76)
				local v77 = p_u_51.Humanoid.HealthChanged:Connect(function()
					-- upvalues: (copy) v_u_73
					v_u_73:Stop()
				end)
				table.insert(v_u_71, v77)
				local v78 = v_u_3.Stepped:Connect(function()
					-- upvalues: (copy) v_u_72, (copy) v_u_69, (copy) v_u_73
					if ((v_u_72 - v_u_69.Position) * Vector3.new(1, 0, 1)).Magnitude > 1 then
						v_u_73:Stop()
					end
				end)
				table.insert(v_u_71, v78)
				local v79 = p_u_51.AncestryChanged:Connect(function()
					-- upvalues: (copy) v_u_73
					v_u_73:Stop()
				end)
				table.insert(v_u_71, v79)
				local v_u_80 = nil
				v_u_80 = v_u_73.Stopped:Connect(function()
					-- upvalues: (ref) v_u_80, (copy) v_u_71
					v_u_80:Disconnect()
					for v81 = #v_u_71, 1, -1 do
						local v82 = v_u_71[v81]
						if not v82 then
							continue
						end
						table.remove(v_u_71, v81)
						if typeof(v82) == "RBXScriptConnection" then
							v82:Disconnect()
						elseif v82:IsA("AnimationTrack") then
							v82:Stop()
						else
							v82:Destroy()
						end
					end
				end)
				v_u_73:Play(0)
				return
			end
			return
		elseif p50 == "Poison" then
			local v83 = p_u_51:FindFirstChild("HumanoidRootPart")
			if not v83 then
				return
			end
			local v84 = v_u_10.Megumi.Poison:Clone()
			v84.Parent = v83
			v_u_5:Create(v84, TweenInfo.new(10), {
				["Rate"] = 0
			}):Play()
			v_u_4:AddItem(v84, p_u_49 + 1)
			for v85 = 1, p_u_49 do
				if not p_u_51.Parent or p_u_51:GetAttribute("Dead") then
					return
				end
				v_u_18:Flash(p_u_51, Color3.fromRGB(85, 0, 127), 2)
				v_u_18:PlaySound(v_u_11.Megumi.Serpent["Poison" .. v85 % 3 + 1], v83, game.SoundService.Effect)
				task.wait(1)
			end
		else
			if p50 == "Bleed" then
				local v86 = p_u_51:FindFirstChild("HumanoidRootPart")
				if v86 then
					if p_u_49 ~= 0 then
						for _ = 1, p_u_49 do
							v_u_18:PlaySound(v_u_11.Misc.Bleed, v86, game.SoundService.Effect)
							if _G.Settings.Gore == false then
								v_u_18:Flash(p_u_51, Color3.fromRGB(255, 85, 255), 1)
							else
								v_u_18:Flash(p_u_51, Color3.fromRGB(85, 0, 0), 1)
								for _ = 1, 2 do
									v_u_14:Blood(p_u_51.Torso.CFrame, math.random(15, 30), 180, 180)
								end
								for _, v87 in v_u_10.Damage.Explode:GetDescendants() do
									if not v87:IsA("Attachment") then
										continue
									end
									local v88 = v87:Clone()
									v88.Parent = p_u_51:FindFirstChild(v87.Parent.Name)
									v88.Blood.Enabled = false
									v88.Blood:Emit(8)
									v_u_4:AddItem(v88, 1)
								end
							end
						end
					end
				else
					return
				end
			end
			if p50 == "SBleed" then
				local v89 = p_u_51:FindFirstChild("HumanoidRootPart")
				if v89 then
					v_u_18:PlaySound(v_u_11.Misc.SBleed, v89, game.SoundService.Effect)
					if _G.Settings.Gore == false then
						v_u_18:Flash(p_u_51, Color3.fromRGB(255, 85, 255), 0.5)
					else
						v_u_18:Flash(p_u_51, Color3.fromRGB(85, 0, 0), 0.5)
						v_u_14:Blood(p_u_51.Torso.CFrame, math.random(15, 30), 180, 180)
					end
				else
					return
				end
			end
			if p50 == "WakeupEvade" then
				local v90 = p_u_51.HumanoidRootPart
				if v90 then
					if not p_u_51:GetAttribute("Dead") then
						local v91 = v_u_10.Itadori.CounterHit:Clone()
						v91.Position = v90.Position
						v91.Parent = workspace.Effects
						v91.Glow.Color = ColorSequence.new(Color3.fromRGB(0, 150, 200))
						v91.Sparks.Color = ColorSequence.new(Color3.fromRGB(0, 150, 200))
						v91.Glow:Emit(1)
						v91.Sparks:Emit(20)
						v_u_4:AddItem(v91, 0.5)
					end
				else
					return
				end
			end
			if p50 == "IFrames" then
				if p_u_51.HumanoidRootPart then
					v_u_18:Flash(p_u_51, Color3.fromRGB(255, 255, 255), p_u_49)
				end
			end
			if p50 == "Grab" then
				local v_u_92
				if p_u_49 then
					v_u_92 = p_u_49.Parent or nil
				else
					v_u_92 = nil
				end
				local v_u_93
				if p_u_51 then
					v_u_93 = p_u_51.Parent or nil
				else
					v_u_93 = nil
				end
				local v_u_94
				if p_u_49 then
					v_u_94 = p_u_49.CFrame * p_u_52.C1 or nil
				else
					v_u_94 = nil
				end
				local v_u_95 = nil
				local v_u_96 = nil
				if not p53 and (v_u_92 and v_u_93) then
					local v97 = v_u_93:FindFirstChild("HumanoidRootPart")
					local v98 = v_u_92:FindFirstChild("HumanoidRootPart")
					if v98 and v97 then
						local v99 = Instance.new("Part")
						v99.Name = "GrabCollisionPart"
						v99.Size = v97.Size
						v99.CanCollide = true
						v99.CanTouch = false
						v99.Massless = true
						v99.Transparency = 1
						v99.Parent = v_u_92
						v_u_96 = Instance.new("Weld")
						v_u_96.Part0 = v98
						v_u_96.part1 = v99
						v_u_96.C0 = v98.CFrame:ToObjectSpace(v97.CFrame)
						v_u_96.Parent = v99
					end
				end
				local v106 = v_u_3.Heartbeat:Connect(function()
					-- upvalues: (copy) p_u_52, (copy) p_u_49, (copy) p_u_51, (ref) v_u_95, (ref) v_u_94, (ref) v_u_93, (copy) v_u_92, (ref) v_u_96
					local v100 = p_u_52
					if v100 then
						v100 = v100.Parent ~= nil
					end
					if v100 then
						local v101 = p_u_49
						if v101 then
							v101 = v101.Parent ~= nil
						end
						if v101 then
							local v102 = p_u_51
							if v102 then
								v102 = v102.Parent ~= nil
							end
							if v102 then
								v_u_94 = p_u_49 and p_u_49.CFrame * p_u_52.C1 or nil
								v_u_93 = p_u_51 and p_u_51.Parent or nil
								if v_u_94 and v_u_93 then
									for _, v103 in v_u_93:GetChildren() do
										if not (v103:IsA("BasePart") and (v103:GetAttribute("D_CC") and v103.CanCollide)) then
											continue
										end
										v103.CanCollide = false
									end
									p_u_51.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
									p_u_51.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
									v_u_93:PivotTo(v_u_94)
									local v104 = v_u_93:FindFirstChild("HumanoidRootPart")
									local v105 = v_u_92:FindFirstChild("HumanoidRootPart")
									if v_u_96 and (v104 and v105) then
										v_u_96.C0 = v105.CFrame:ToObjectSpace(v104.CFrame)
									end
								end
							end
						end
					end
					v_u_95:Disconnect()
				end)
				v_u_48[v_u_92] = v106
				v_u_48[v_u_93] = v106
				return
			end
			if p50 == "GrabEnd" then
				if p_u_49 and v_u_48[p_u_49.Parent] then
					v_u_48[p_u_49.Parent]:Disconnect()
					v_u_48[p_u_49.Parent] = nil
				end
				if p_u_51 and v_u_48[p_u_51.Parent] then
					v_u_48[p_u_51.Parent]:Disconnect()
					v_u_48[p_u_51.Parent] = nil
				end
				local v107 = p_u_49 and (p_u_49.Parent and p_u_49.Parent:FindFirstChild("GrabCollisionPart"))
				if v107 then
					v107:Destroy()
				end
				if p_u_51 and p_u_51.Parent then
					for _, v108 in p_u_51.Parent:GetChildren() do
						if not v108:IsA("BasePart") or (not v108:GetAttribute("D_CC") or v108.CanCollide) then
							continue
						end
						v108.CanCollide = true
					end
					p_u_51.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
					p_u_51.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
					return
				end
			elseif p50 == "DamageCounter" then
				v_u_12(p_u_49)
			end
		end
	end)
	local function v126(p109, p110) -- name: customSFX
		-- upvalues: (ref) v_u_11, (ref) v_u_5, (ref) v_u_3
		local v111 = p109:FindFirstChild("HumanoidRootPart") or p109:IsA("BasePart") and p109
		if v111 then
			local v112 = p110.ID
			local v_u_113 = p110.VOLUME or 1
			local v114 = p110.SPEED or 1
			local v115 = p110.START or 0
			local v116 = p110.END or 500
			local v117 = p110["FADE IN"]
			local v_u_118 = p110["FADE OUT"]
			local v119 = workspace:GetAttribute("CC1")
			if v119 then
				v_u_113 = math.clamp(v_u_113, 0, 2)
				p110.GLOBAL = false
			end
			if p110.CANCEL == true then
				if p110.GLOBAL == true then
					v111 = workspace or v111
				end
				for _, v120 in pairs(v111:GetChildren()) do
					if not v120:IsA("Sound") or v120.SoundId ~= "rbxassetid://" .. v112 then
						continue
					end
					v120:Destroy()
				end
			else
				local v_u_121 = v_u_11.Impact.Players.Death:Clone()
				v_u_121.SoundGroup = game.SoundService.Effect
				v_u_121.SoundId = "rbxassetid://" .. v112
				v_u_121.Volume = v_u_113
				v_u_121.PlaybackSpeed = v114
				v_u_121.PlaybackRegionsEnabled = true
				v_u_121.PlaybackRegion = NumberRange.new(v115, v116)
				v_u_121.TimePosition = v115
				if p110.GLOBAL == true then
					v111 = workspace or v111
				end
				v_u_121.Parent = v111
				v_u_121:Play()
				if v117 and v117 > 0 then
					v_u_121.Volume = 0
					v_u_5:Create(v_u_121, TweenInfo.new(v117), {
						["Volume"] = v_u_113
					}):Play()
				end
				local function v_u_123() -- name: fadeoutFunc
					-- upvalues: (copy) v_u_118, (copy) v_u_121, (ref) v_u_5
					if v_u_118 and v_u_118 > 0 then
						local v122 = v_u_121.TimeLength - v_u_121.TimePosition - v_u_118
						if v122 > 0 then
							task.wait(v122)
						end
						if v_u_121.Parent then
							v_u_5:Create(v_u_121, TweenInfo.new(v_u_118), {
								["Volume"] = 0
							}):Play()
						end
					end
				end
				v_u_121.Loaded:Once(function()
					-- upvalues: (copy) v_u_121, (copy) v_u_123
					if v_u_121.IsLoaded then
						if v_u_121.TimeLength > 30 then
							v_u_121.SoundGroup = game.SoundService.Music
						end
						v_u_123()
					else
						v_u_121:Destroy()
					end
				end)
				local v_u_124 = nil
				v_u_121.Ended:Once(function()
					-- upvalues: (copy) v_u_121, (ref) v_u_124
					v_u_121:Destroy()
					if v_u_124 then
						v_u_124:Disconnect()
					end
				end)
				if v119 then
					v_u_124 = v_u_3.RenderStepped:Connect(function()
						-- upvalues: (copy) v_u_121, (ref) v_u_124, (ref) v_u_113
						if v_u_121.Parent then
							if v_u_121.PlaybackLoudness > 750 then
								v_u_121.Volume = 0.2
							end
							if v_u_121.TimeLength > 30 and v_u_113 > 1 then
								local v125 = v_u_113
								v_u_121.Volume = math.clamp(v125, 0, 1)
							end
						else
							v_u_124:Disconnect()
						end
					end)
				end
			end
		else
			return
		end
	end
	local v_u_127 = {
		["Screen Color"] = true,
		["Overlay"] = true,
		["Field of View"] = true,
		["Camera"] = true,
		["Shake Light"] = true,
		["Shake Medium"] = true,
		["Shake Heavy"] = true
	}
	local v_u_128 = require(v_u_8.Modules.SkillDefault).LineItems
	local v_u_129 = #v_u_128.VISUAL + 1
	local function v138(p130, p131) -- name: customFX
		-- upvalues: (copy) v_u_128, (ref) v_u_7, (copy) v_u_127, (copy) v_u_129, (ref) v_u_8
		local v132 = {}
		for v133, v134 in v_u_128.VISUAL do
			if p131[v133] == "\226\156\191" or not p131[v133] then
				v132[v134[1]] = v134[3]
			else
				v132[v134[1]] = p131[v133]
			end
		end
		if workspace:GetAttribute("CreatorClash") then
			local v135 = p130:GetAttribute("InMatch")
			local v136 = v_u_7.Character
			if v136 then
				v136 = v_u_7.Character:GetAttribute("InMatch")
			end
			if v_u_127[v132.EFFECT] then
				if not v135 then
					return
				end
				if v135 and v136 ~= v135 then
					return
				end
			end
		end
		if p131[v_u_129] then
			v132.RELATIVE = p131[v_u_129]
		end
		local v137 = require(v_u_8.Modules.BuilderFX)
		if v137[v132.EFFECT] then
			v137[v132.EFFECT](p130, v132)
		end
	end
	local function v240(p139, p140) -- name: customParticle
		-- upvalues: (ref) v_u_6
		if p140.CANCEL and p140["CANCEL TAG"] then
			for _, v141 in game.CollectionService:GetTagged("CustomParticles") do
				if v141:GetAttribute("Owner") ~= p139.Name or v141:GetAttribute("Tag") ~= p140["CANCEL TAG"] then
					continue
				end
				v141:Destroy()
			end
		else
			local function v149(p142) -- name: getNumberSequence
				local v143 = {}
				for _, v144 in string.split(p142, ",") do
					local v145 = tonumber(v144)
					if not v145 then
						continue
					end
					v143[#v143 + 1] = v145
				end
				if #v143 == 0 then
					return NumberSequence.new(0)
				end
				if #v143 == 1 then
					return NumberSequence.new(v143[1])
				end
				local v146 = {}
				for v147, v148 in v143 do
					v146[v147] = NumberSequenceKeypoint.new((v147 - 1) / (#v143 - 1), v148)
				end
				return NumberSequence.new(v146)
			end
			local function v163(p150) -- name: getColorSequence
				local v151 = {}
				for _, v152 in string.split(p150, " ") do
					local v153 = string.split(v152, ",")
					local v154 = v153[1]
					local v155 = tonumber(v154)
					local v156 = v153[2]
					local v157 = tonumber(v156)
					local v158 = v153[3]
					local v159 = tonumber(v158)
					if not (v155 and (v157 and v159)) then
						continue
					end
					v151[#v151 + 1] = Color3.fromRGB(math.clamp(v155, 0, 255), math.clamp(v157, 0, 255), (math.clamp(v159, 0, 255)))
				end
				if #v151 == 0 then
					return ColorSequence.new(Color3.new(1, 1, 1))
				end
				if #v151 == 1 then
					return ColorSequence.new(v151[1])
				end
				local v160 = {}
				for v161, v162 in v151 do
					v160[v161] = ColorSequenceKeypoint.new((v161 - 1) / (#v151 - 1), v162)
				end
				return ColorSequence.new(v160)
			end
			local _ = p139.HumanoidRootPart
			local v164 = p140["BODY PART"]
			if v164 then
				v164 = p139:FindFirstChild(p140["BODY PART"], true)
			end
			local v165 = string.split
			local v166 = p140.POSITION
			local v167 = unpack
			local v168 = Vector3.new(v167(v165(v166)))
			local v169 = string.split
			local v170 = p140["PART SIZE"]
			local v171 = unpack
			local v172 = Vector3.new(v171(v169(v170)))
			local v_u_173
			if v172 == Vector3.new(0, 0, 0) then
				v_u_173 = Instance.new("Attachment")
				v_u_173.Name = "CustomParticlePart"
				local v174 = -v168.X
				local v175 = v168.Y
				local v176 = -v168.Z
				v_u_173.Position = Vector3.new(v174, v175, v176)
				v_u_173.Parent = v164
			else
				v_u_173 = Instance.new("Part")
				v_u_173.Transparency = 1
				v_u_173.CanCollide = false
				v_u_173.CanQuery = false
				v_u_173.Massless = true
				v_u_173.Anchored = false
				v_u_173.Size = v172
				v_u_173.Name = "CustomParticlePart"
				v_u_173.Parent = workspace.Effects
				local v177 = Instance.new("Motor6D")
				v177.Parent = v_u_173
				v177.Part0 = v164
				v177.Part1 = v_u_173
				local v178 = CFrame.new
				local v179 = -v168.X
				local v180 = v168.Y
				local v181 = -v168.Z
				v177.C0 = v178((Vector3.new(v179, v180, v181)))
			end
			local v182 = string.split
			local v183 = p140["SPREAD ANGLE"]
			local v184 = unpack
			local v185 = Vector3.new(v184(v182(v183)))
			local v_u_186 = Instance.new("ParticleEmitter")
			if p140.TEXTURE and p140.TEXTURE ~= 0 then
				v_u_186.Texture = "rbxassetid://" .. p140.TEXTURE
			end
			v_u_186.Rate = p140.RATE
			v_u_186.Color = v163(p140.COLOR)
			v_u_186.Transparency = v149(p140.TRANSPARENCY)
			v_u_186.Squash = v149(p140.SQUASH)
			local v187 = p140["EMIT COUNT"]
			local v_u_188 = p140.DURATION
			if workspace:GetAttribute("CC1") then
				local v189 = p140.LIFETIME
				local v190 = string.split(v189, ",")
				local v191 = v190[1]
				local v192 = tonumber(v191) or 0
				local v193 = v190[2]
				local v194 = tonumber(v193) or v192
				if v194 >= v192 then
					local v195 = v192
					v192 = v194
					v194 = v195
				end
				local v196 = NumberRange.new(v194, v192)
				local v197 = NumberRange.new
				local v198 = v196.Min
				local v199 = math.clamp(v198, (-1 / 0), 10)
				local v200 = v196.Max
				v_u_186.Lifetime = v197(v199, (math.clamp(v200, (-1 / 0), 10)))
				v_u_186.Size = v149(p140.SIZE)
				v187 = math.clamp(v187, (-1 / 0), 100)
				v_u_188 = math.clamp(v_u_188, (-1 / 0), 10)
			else
				local v201 = p140.LIFETIME
				local v202 = string.split(v201, ",")
				local v203 = v202[1]
				local v204 = tonumber(v203) or 0
				local v205 = v202[2]
				local v206 = tonumber(v205) or v204
				if v206 >= v204 then
					local v207 = v204
					v204 = v206
					v206 = v207
				end
				v_u_186.Lifetime = NumberRange.new(v206, v204)
				v_u_186.Size = v149(p140.SIZE)
			end
			local v208 = p140.SPEED
			local v209 = string.split(v208, ",")
			local v210 = v209[1]
			local v211 = tonumber(v210) or 0
			local v212 = v209[2]
			local v213 = tonumber(v212) or v211
			if v213 >= v211 then
				local v214 = v211
				v211 = v213
				v213 = v214
			end
			v_u_186.Speed = NumberRange.new(v213, v211)
			local v215 = p140.ROTATION
			local v216 = string.split(v215, ",")
			local v217 = v216[1]
			local v218 = tonumber(v217) or 0
			local v219 = v216[2]
			local v220 = tonumber(v219) or v218
			if v220 >= v218 then
				local v221 = v218
				v218 = v220
				v220 = v221
			end
			v_u_186.Rotation = NumberRange.new(v220, v218)
			local v222 = p140["ROT SPEED"]
			local v223 = string.split(v222, ",")
			local v224 = v223[1]
			local v225 = tonumber(v224) or 0
			local v226 = v223[2]
			local v227 = tonumber(v226) or v225
			if v227 >= v225 then
				local v228 = v225
				v225 = v227
				v227 = v228
			end
			v_u_186.RotSpeed = NumberRange.new(v227, v225)
			v_u_186.SpreadAngle = Vector2.new(v185.X, v185.Y)
			local v229 = string.split
			local v230 = p140.ACCELERATION
			local v231 = unpack
			v_u_186.Acceleration = Vector3.new(v231(v229(v230)))
			v_u_186.Drag = p140.DRAG
			v_u_186.LightEmission = p140["LIGHT EMISSION"]
			v_u_186.LightInfluence = p140["LIGHT INFLUENCE"]
			v_u_186.ZOffset = p140.ZOFFSET
			v_u_186.LockedToPart = p140["LOCK TO PART"]
			v_u_186.Orientation = Enum.ParticleOrientation[p140["ORIENTATION TYPE"]] or Enum.ParticleOrientation.FacingCamera
			v_u_186.EmissionDirection = Enum.NormalId[p140["EMISSION DIRECTION"]] or Enum.NormalId.Front
			v_u_186.Shape = Enum.ParticleEmitterShape[p140.SHAPE] or Enum.ParticleEmitterShape.Box
			v_u_186.ShapeInOut = Enum.ParticleEmitterShapeInOut[p140["SHAPE INOUT"]] or Enum.ParticleEmitterShapeInOut.Outward
			v_u_186.ShapePartial = p140["SHAPE PARTIAL"]
			v_u_186.Enabled = false
			local v232 = v149(p140["FLIPBOOK SIZE"])
			if v232 and (v232.Keypoints[1].Value > 0 and v232.Keypoints[2].Value > 0) then
				v_u_186.FlipbookLayout = Enum.ParticleFlipbookLayout.Custom
				v_u_186.FlipbookSizeX = v232.Keypoints[1].Value
				v_u_186.FlipbookSizeY = v232.Keypoints[2].Value
			end
			v_u_186.FlipbookMode = p140["FLIPBOOK MODE"]
			local v233 = p140["FLIPBOOK FRAMERATE"]
			local v234 = string.split(v233, ",")
			local v235 = v234[1]
			local v236 = tonumber(v235) or 0
			local v237 = v234[2]
			local v238 = tonumber(v237) or v236
			if v238 >= v236 then
				local v239 = v236
				v236 = v238
				v238 = v239
			end
			v_u_186.FlipbookFramerate = NumberRange.new(v238, v236)
			v_u_6:AddTag(v_u_186, "CustomParticle")
			v_u_186.Parent = v_u_173
			if p140["CANCEL TAG"] then
				v_u_173:SetAttribute("ID", p140.UID)
				v_u_173:SetAttribute("Owner", p139.Name)
				v_u_173:SetAttribute("Tag", p140["CANCEL TAG"])
				v_u_173:AddTag("CustomParticles")
			end
			if v187 > 0 then
				v_u_186:Emit(v187)
			end
			if v_u_188 > 0 then
				v_u_186.Enabled = true
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_188, (copy) v_u_186, (ref) v_u_173
				if v_u_188 > 0 then
					task.wait(v_u_188)
					if v_u_186.Parent then
						v_u_186.Enabled = false
					end
				end
				task.wait(v_u_186.Lifetime.Max + 1)
				if v_u_173 and v_u_173.Parent then
					v_u_173:Destroy()
				end
			end)
		end
	end
	local function v257(p241, p242, p243, p244) -- name: lookAt
		-- upvalues: (ref) v_u_19
		local v245 = p241:FindFirstChild("HumanoidRootPart")
		if v245 then
			local v246 = p241:FindFirstChild("Humanoid")
			if v246 then
				local v247
				if p243 then
					v247 = p243:FindFirstChild("HumanoidRootPart")
				else
					v247 = p243
				end
				local v248 = Instance.new("AlignOrientation")
				v248.Name = "CustomRotation"
				v248.Attachment0 = v245:FindFirstChild("RootAttachment") or Instance.new("Attachment")
				v248.Attachment0.Name = "RootAttachment"
				v248.Attachment0.Parent = v245
				v248.MaxTorque = 5000000 * p241:GetScale()
				local v249 = p242.SMOOTHNESS
				v248.Responsiveness = math.clamp(v249, 10, 200)
				v248.MaxAngularVelocity = 5000000 * p241:GetScale()
				v248.PrimaryAxisOnly = false
				v248.ReactionTorqueEnabled = false
				v248.Mode = Enum.OrientationAlignmentMode.OneAttachment
				v248.AlignType = Enum.AlignType.AllAxes
				v248.Parent = v245
				local v250 = p243 == p241
				v248:SetAttribute("UseMouse", v250)
				task.wait()
				local v251 = v_u_19:GetMouseTarget(1000)
				local v252 = CFrame.lookAt(v245.Position, v251).LookVector
				if v250 or not v247 then
					if p242["CAMERA DIRECTION"] then
						v252 = CFrame.lookAt(v245.Position, workspace.CurrentCamera.CFrame.Position + workspace.CurrentCamera.CFrame.LookVector * 100).LookVector
					end
				else
					v252 = CFrame.lookAt(v245.Position, v247.Position).LookVector
				end
				if p242["HORIZONTAL ONLY"] then
					local v253 = v252.X
					local v254 = v252.Z
					v252 = Vector3.new(v253, 0, v254)
				end
				if p242.GROUNDED == true then
					local v255
					if v246.FloorMaterial == Enum.Material.Air then
						v255 = 0
					else
						local v256 = v252.Y
						v255 = math.abs(v256) * -1.25
					end
					v246.HipHeight = v255
				end
				v248.CFrame = CFrame.lookAt(v245.Position, v245.Position + v252)
				if p244 and p244.Parent then
					continue
				end
				v246.HipHeight = 0
				if v248 then
					v248:Destroy()
				end
			end
		else
			return
		end
	end
	v_u_17.SFX:Connect(v126)
	v_u_17.SFX2:Connect(v126)
	v_u_17.FX:Connect(v138)
	v_u_17.FX2:Connect(v138)
	v_u_17.LOOK:Connect(v257)
	v_u_17.PARTICLE:Connect(v240)
	v_u_17.PARTICLE2:Connect(v240)
	v_u_16.Effects:Connect(function(p258, p259)
		-- upvalues: (ref) v_u_18, (ref) v_u_11, (ref) v_u_10, (ref) v_u_4
		local v260 = p258:FindFirstChild("HumanoidRootPart")
		if v260 then
			if p259 then
				v_u_18:PlaySound(v_u_11.Impact.Players.Perfect, v260, game.SoundService.Effect)
			else
				if p258:GetAttribute("Sword") or p258:GetAttribute("Moveset") == "Mechamaru" then
					local v261 = v_u_11.Misc.SwordBlock["Block" .. math.random(1, 3)]
					v261.Pitch = math.random(90, 110) / 100
					v_u_18:PlaySound(v261, v260, game.SoundService.Effect)
					local v262 = v_u_10.Damage.SwordBlockHit:Clone()
					v262.Parent = v260
					v262:Emit(10)
					v_u_4:AddItem(v262, 0.3)
				end
				local v263 = v_u_11.Misc.Block["Block" .. math.random(1, 3)]
				v263.Pitch = math.random(90, 110) / 100
				v_u_18:PlaySound(v263, v260, game.SoundService.Effect)
				local v264 = v_u_10.Damage.BlockHit:Clone()
				v264.Parent = v260
				v264:Emit(1)
				v_u_4:AddItem(v264, 0.3)
			end
		else
			return
		end
	end)
	local v_u_265 = {}
	for v266 = 1, #v_u_8.Animations.Misc.Hits.Normal:GetChildren() do
		local v267 = "Hit" .. v266
		table.insert(v_u_265, v267)
	end
	local v_u_268 = v_u_8.Animations.Misc.Hits.Normal:GetChildren()
	v_u_15.Hit:Connect(function(p269)
		-- upvalues: (copy) v_u_265, (copy) v_u_268
		local v270 = v_u_265
		local v271 = v_u_268
		local v272 = p269:FindFirstChild("Humanoid")
		if v272 then
			local v273 = math.random(1, #v271)
			if v272:GetAttribute("LHit") == v273 then
				repeat
					v273 = math.random(1, #v271)
				until v272:GetAttribute("LHit") ~= v273
			end
			v272:SetAttribute("LHit", v273)
			for _, v274 in v272:GetPlayingAnimationTracks() do
				if not table.find(v270, v274.Name) then
					continue
				end
				v274:Stop(0.04)
			end
			local v_u_275 = v272:LoadAnimation(v271[v273])
			v_u_275:Play(0.04, nil, 0.75)
			v272.PlatformStanding:Once(function()
				-- upvalues: (copy) v_u_275
				v_u_275:Stop(0)
				v_u_275:Destroy()
			end)
		end
	end)
end
function v20.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_15, (copy) v_u_1, (ref) v_u_16, (ref) v_u_18, (ref) v_u_17, (ref) v_u_19
	v_u_15 = v_u_1.GetService("HandicapService")
	v_u_16 = v_u_1.GetService("BlockService")
	v_u_18 = v_u_1.GetController("FXController")
	v_u_17 = v_u_1.GetService("CustomService")
	v_u_19 = v_u_1.GetController("ToolController")
end
return v20