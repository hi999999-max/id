-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Todo.Base.SwiftKickController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = workspace.CurrentCamera
local v_u_7 = game.ReplicatedStorage
local _ = v_u_7.Animations
local v_u_8 = v_u_7.Utils
local v_u_9 = v_u_7.Sounds
local v_u_10 = require(v_u_7.Modules.CameraShaker)
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v15 = v_u_1.CreateController({
	["Name"] = "SwiftKickController"
})
local function v_u_23(p16, p17, p18) -- name: writeFloat16
	local v19 = p17 * 8
	if p18 == 0 then
		buffer.writebits(p16, v19, 16, 0)
		return
	elseif p18 >= 65520 then
		buffer.writebits(p16, v19, 16, 31744)
		return
	elseif p18 <= -65520 then
		buffer.writebits(p16, v19, 16, 64512)
		return
	elseif p18 == p18 then
		local v20
		if p18 < 0 then
			p18 = -p18
			v20 = 1
		else
			v20 = 0
		end
		local v21, v22 = math.frexp(p18)
		buffer.writebits(p16, v19 + 0, 10, v21 * 2048 - 1023.5)
		buffer.writebits(p16, v19 + 10, 5, v22 + 14)
		buffer.writebits(p16, v19 + 15, 1, v20)
	else
		buffer.writebits(p16, v19, 16, 31745)
	end
end
function v15.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_14, (copy) v_u_9, (copy) v_u_8, (copy) v_u_3, (copy) v_u_4, (copy) v_u_7, (copy) v_u_5, (copy) v_u_10, (copy) v_u_2, (copy) v_u_6, (copy) v_u_23, (ref) v_u_13, (ref) v_u_11
	local v_u_59 = {
		["Start"] = function(p24)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			local v25 = p24:FindFirstChild("HumanoidRootPart")
			if v25 then
				v_u_14:PlaySound(v_u_9.Hakari.FeverBreak.Dash, v25, game.SoundService.Effect)
			end
		end,
		["Swing"] = function(p26)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_14, (ref) v_u_9
			local v27 = p26:FindFirstChild("HumanoidRootPart")
			if v27 then
				local v28 = v_u_8.Todo.Swing:Clone()
				v28.Weld.Part0 = v27
				v28.Parent = workspace.Effects
				v_u_3:AddItem(v28, 0.6)
				v28.Core.Wind:Emit(12)
				v_u_4:Create(v28.Weld, TweenInfo.new(0.4), {
					["C1"] = v28.Weld.C1 * CFrame.Angles(0, -3.141592653589793, 0)
				}):Play()
				v_u_4:Create(v28.Beam, TweenInfo.new(0.4), {
					["Width0"] = 0
				}):Play()
				v_u_14:PlaySound(v_u_9.Hakari.Counter.Startup, v27, game.SoundService.Effect)
				v_u_14:PlaySound(v_u_9.Choso.PiercingBlood.Startup, v27, game.SoundService.Effect)
			end
		end,
		["Dash"] = function(p29, p30, p31)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_7, (ref) v_u_3, (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_10, (ref) v_u_2
			local v_u_32 = p29:FindFirstChild("HumanoidRootPart")
			if v_u_32 then
				v_u_14:PlaySound(v_u_9.Itadori.Rush.Rush, v_u_32, game.SoundService.Effect)
				local v33 = v_u_7.Utils.Itadori.RushWind:Clone()
				v33.CFrame = v_u_32.CFrame
				v33.Parent = workspace.Effects
				v33.Dust:Emit(7)
				v33.Ring:Emit(7)
				v33.Dash1.Dash:Emit(1)
				v33.Dash2.Dash:Emit(1)
				v_u_3:AddItem(v33, 2)
				local v34 = v_u_8.Itadori.Shock:Clone()
				v34.CFrame = v_u_32.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v34.Parent = workspace.Effects
				v_u_4:Create(v34, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(8, 0, 8),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v34, 0.2)
				task.delay(0.1, function()
					-- upvalues: (ref) v_u_8, (copy) v_u_32, (ref) v_u_4, (ref) v_u_3
					local v35 = v_u_8.Itadori.Shock:Clone()
					v35.CFrame = v_u_32.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
					v35.Parent = workspace.Effects
					v_u_4:Create(v35, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v35, 0.2)
				end)
				if v_u_5.Character == p29 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
					local v36 = Instance.new("NumberValue", p30)
					v36.Value = p31 and 165 or 150
					v_u_4:Create(v36, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["Value"] = 35
					}):Play()
					repeat
						p30.Velocity = v_u_32.CFrame.LookVector * v36.Value
						v_u_2.Stepped:Wait()
					until not (p30.Parent and v_u_32.Parent)
				end
			end
		end,
		["Hit"] = function(p37, p38)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_14, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v39 = p38:FindFirstChild("HumanoidRootPart")
			if v39 then
				local v40 = v_u_8.Gojo.Twofold.Sparks:Clone()
				v40.Parent = v39.RootAttachment
				v40:Emit(20)
				v_u_3:AddItem(v40, 0.4)
				v_u_14:Flash(p38, Color3.new(1, 1, 1))
				v_u_14:PlaySound(v_u_9.Itadori.CraniumSmash.Hit2, v39, game.SoundService.Effect)
				if v_u_5 == p37 or v_u_5.Character == p38 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
				end
			end
		end,
		["Grab"] = function(p41)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			local v42 = p41:FindFirstChild("HumanoidRootPart")
			if v42 then
				v_u_14:Flash(p41, Color3.new(1, 1, 1))
				v_u_14:PlaySound(v_u_9.Gojo.LapseBlue.Grab, v42, game.SoundService.Effect)
				task.wait(0.2)
				v_u_14:PlaySound(v_u_9.Mahito.CrushingRushdown.Leap, v42, game.SoundService.Effect)
			end
		end,
		["UpdateCamera"] = function(p_u_43)
			-- upvalues: (ref) v_u_2, (ref) v_u_6, (ref) v_u_23
			local v_u_46 = v_u_2.Heartbeat:Connect(function()
				-- upvalues: (copy) p_u_43, (ref) v_u_6, (ref) v_u_23
				if p_u_43 and p_u_43.Parent then
					local v44 = v_u_6.CFrame.LookVector
					local v45 = buffer.create(6)
					v_u_23(v45, 0, v44.X)
					v_u_23(v45, 2, v44.Y)
					v_u_23(v45, 4, v44.Z)
					p_u_43:FireServer(v45)
				end
			end)
			p_u_43.AncestryChanged:Once(function()
				-- upvalues: (copy) v_u_46
				v_u_46:Disconnect()
			end)
		end,
		["Aim"] = function(p47, p48)
			-- upvalues: (ref) v_u_13
			local v49 = p47:FindFirstChild("HumanoidRootPart")
			if v49 then
				local v50 = p47:FindFirstChild("Humanoid")
				if v50 then
					local v51 = Instance.new("BodyGyro", v49)
					v51.P = 10000
					v51.MaxTorque = Vector3.new(40000, 40000, 40000)
					p48.Position = v49.Position + Vector3.new(0, 2, 0)
					v50.PlatformStand = true
					repeat
						v_u_13:GetMouseTarget(nil, true)
						v51.CFrame = CFrame.new(v49.Position, v49.Position + workspace.CurrentCamera.CFrame.LookVector)
						task.wait()
					until not p48.Parent
					v51:Destroy()
					v50.PlatformStand = false
				end
			else
				return
			end
		end,
		["Throw"] = function(p52, p53)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_14, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v54 = p52:FindFirstChild("HumanoidRootPart")
			if v54 then
				local v_u_55 = p53:FindFirstChild("HumanoidRootPart")
				if v_u_55 then
					local v56 = v_u_8.Choso.CounterSwing:Clone()
					v56:PivotTo(v54.CFrame * CFrame.new(2, 1, -4))
					v56.Parent = workspace.Effects
					v_u_3:AddItem(v56, 0.3)
					v_u_4:Create(v56.Shock, TweenInfo.new(0.15), {
						["Size"] = Vector3.new(0, 25, 0),
						["Transparency"] = 1
					}):Play()
					v_u_4:Create(v56.Shock2, TweenInfo.new(0.1), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1,
						["Position"] = nil,
						["Position"] = v56.Shock2.Position + v54.CFrame.LookVector * 3
					}):Play()
					v_u_4:Create(v56.Shockwave, TweenInfo.new(0.3), {
						["Size"] = Vector3.new(0, 30, 0),
						["Transparency"] = 1,
						["CFrame"] = nil,
						["CFrame"] = v56.Shockwave.CFrame * CFrame.Angles(0, 3.12413936106985, 0)
					}):Play()
					v_u_14:PlaySound(v_u_9.Mahito.Stockpile.Swing2, v54, game.SoundService.Effect)
					for v57 = 1, 4 do
						task.delay(v57 * 0.1, function()
							-- upvalues: (ref) v_u_8, (copy) v_u_55, (ref) v_u_4, (ref) v_u_3
							local v58 = v_u_8.Itadori.Shock:Clone()
							v58.CFrame = CFrame.lookAlong(v_u_55.Position, v_u_55.Velocity) * CFrame.Angles(1.5707963267948966, 0, 0)
							v58.Parent = workspace.Effects
							v_u_4:Create(v58, TweenInfo.new(0.15), {
								["Size"] = Vector3.new(10, 0, 10),
								["Transparency"] = 1
							}):Play()
							v_u_3:AddItem(v58, 0.15)
						end)
					end
					if v_u_5.Character == p52 or v_u_5.Character == p53 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
					end
				end
			else
				return
			end
		end
	}
	v_u_11.Effects:Connect(function(p60, ...)
		-- upvalues: (copy) v_u_59
		local v61 = v_u_59[p60]
		if v61 then
			v61(...)
		end
	end)
end
function v15.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14
	v_u_11 = v_u_1.GetService("SwiftKickService")
	v_u_12 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("ToolController")
	v_u_14 = v_u_1.GetController("FXController")
end
return v15