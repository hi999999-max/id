-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Kurourushi.Base.RoachSwarmController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "RoachSwarmController"
})
local function v_u_23(p14, p15, p16, p17, p18) -- name: cubicBezier
	local v19 = p14 + (p15 - p14) * p18
	local v20 = p15 + (p16 - p15) * p18
	local v21 = p16 + (p17 - p16) * p18
	local v22 = v19 + (v20 - v19) * p18
	return v22 + (v20 + (v21 - v20) * p18 - v22) * p18
end
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_11, (copy) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2, (copy) v_u_4, (copy) v_u_23, (ref) v_u_10
	local v_u_130 = {
		["Hit"] = function(p24, p25)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			if p24:FindFirstChild("HumanoidRootPart") then
				local v26 = p25:FindFirstChild("HumanoidRootPart")
				if v26 then
					v_u_11:PlaySound(v_u_8.Kurourushi.RoachSwarm.Hit, v26, game.SoundService.Effect)
					local v27 = v_u_7.Kurourushi.RoachExplosion:Clone()
					local v28 = Instance.new("Model")
					v27.Parent = v28
					v28:ScaleTo(0.4)
					v_u_3:AddItem(v28, 0.1)
					v27.Parent = workspace.Effects
					v27.CFrame = CFrame.new(v26.Position)
					v_u_11:PlayParticles(v27)
					v_u_3:AddItem(v27, 3)
					v_u_11:Flash(p25, Color3.new(1, 1, 1))
					if p24 == v_u_5.Character or p25 == v_u_5.Character then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.MediumHit)
					end
				end
			else
				return
			end
		end,
		["Swarm1"] = function(p29, p30, p31, p_u_32)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_2
			local v_u_33 = p29:FindFirstChild("HumanoidRootPart")
			if v_u_33 then
				local v34 = p30 * CFrame.new(0, 0, 2)
				local v35 = v34 * CFrame.new(-10, 0, 15)
				local v36 = v34 * CFrame.new(0, 0, -35)
				local _ = v34.Position
				local v_u_37 = v35.Position
				local v_u_38 = v36.Position
				if p31 == nil then
					v_u_11:PlaySound(v_u_8.Kurourushi.RoachSwarm.Swarm1, v_u_33, game.SoundService.Effect)
				else
					local v39 = v34 * CFrame.new(0, -8, 0)
					local v40 = v34 * CFrame.new(0, -5, -40)
					local _ = v34.Position
					v_u_37 = v39.Position
					v_u_38 = v40.Position
					v_u_11:PlaySound(v_u_8.Kurourushi.RoachSwarm.Swarm2, v_u_33, game.SoundService.Effect)
				end
				local v_u_41 = v_u_7.Kurourushi.Swarm:Clone()
				v_u_41.CFrame = v34
				v_u_41.Parent = workspace.Effects
				v_u_41:SetAttribute("Owner", p29.Name)
				local v_u_42 = os.clock()
				local v_u_43 = nil
				local v_u_44 = true
				local v_u_45 = 0
				v_u_43 = v_u_2.PreRender:Connect(function()
					-- upvalues: (copy) v_u_41, (ref) v_u_43, (ref) v_u_44, (copy) p_u_32, (copy) v_u_42, (ref) v_u_45, (copy) v_u_33, (ref) v_u_37, (ref) v_u_38
					if v_u_41:GetAttribute("Owner") == nil then
						v_u_43:Disconnect()
					else
						if v_u_44 == true and (p_u_32.Parent and p_u_32:GetAttribute("KeepVFX")) then
							v_u_44 = false
						end
						local v46 = (os.clock() - v_u_42) / 0.5
						local v47 = math.min(v46, 1)
						if tick() - v_u_45 > 0.005 then
							v_u_45 = tick()
							for _, v48 in pairs(v_u_41:GetChildren()) do
								v48.Size = NumberSequence.new(v48.Size.Keypoints[1].Value + v47 / 8, v48.Size.Keypoints[2].Value)
							end
						end
						local v49 = v_u_33.CFrame * CFrame.new(0, 0, 2).Position
						local v50 = v_u_37
						local v51 = v_u_38
						local v52 = v49 + (v50 - v49) * v47
						local v53 = v52 + (v50 + (v51 - v50) * v47 - v52) * v47
						local v54 = v_u_41
						local v55 = CFrame.lookAt
						local v56 = v_u_33.CFrame * CFrame.new(0, 0, 2).Position
						local v57 = v_u_37
						local v58 = v_u_38
						local v59 = v47 + 0.01
						local v60 = v56 + (v57 - v56) * v59
						v54.CFrame = v55(v53, v60 + (v57 + (v58 - v57) * v59 - v60) * v59)
						if v47 >= 1 or p_u_32.Parent == nil and v_u_44 then
							v_u_43:Disconnect()
							for _, v61 in v_u_41:GetChildren() do
								v61.Enabled = false
							end
							task.wait(0.5)
							v_u_41:Destroy()
						end
					end
				end)
			end
		end,
		["Swarm2"] = function(p62, p63, p_u_64)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_2, (ref) v_u_4, (ref) v_u_23
			local v65 = p62:FindFirstChild("HumanoidRootPart")
			if v65 then
				v_u_11:PlaySound(v_u_8.Kurourushi.RoachSwarm.SwarmFollowupWhoosh, v65, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_8.Kurourushi.RoachSwarm.SwarmFollowup, v65, game.SoundService.Effect)
				for v66 = 1, 2 do
					local v67 = v66 == 2 and 1 or -1
					local v68 = p63 * CFrame.new(v67 * 1, 0, 2.5)
					local v_u_69 = v68.Position
					local v70 = p63 * CFrame.new(v67 * 20, 1.5, 0)
					local v71 = p63 * CFrame.new(v67 * 20, 3.5, -10)
					local v72 = p63 * CFrame.new(0, 5, -20)
					local v73 = nil
					local v_u_74 = false
					for _, v75 in pairs(workspace.Effects:GetChildren()) do
						if v75.Name ~= "Swarm" or v75:GetAttribute("Owner") ~= p62.Name then
							continue
						end
						v73 = v75
						v73:SetAttribute("Owner", nil)
						v68 = v73.CFrame
						v70 = v68 * CFrame.new(v67 * 10, 1.5, 0)
						v71 = v68 * CFrame.new(v67 * 10, 3.5, -10)
						v_u_69 = v68.Position
						v_u_74 = true
					end
					local v_u_76 = v73 or v_u_7.Kurourushi.Swarm:Clone()
					local v_u_77 = v70.Position
					local v_u_78 = v71.Position
					local v_u_79 = v72.Position
					v_u_76.CFrame = v68
					v_u_76.Parent = workspace.Effects
					local v_u_80 = 0.5 - (v66 == 2 and 0.2 or 0)
					local v_u_81 = os.clock()
					local v_u_82 = nil
					local v_u_83 = 0
					v_u_82 = v_u_2.PreRender:Connect(function()
						-- upvalues: (copy) v_u_81, (copy) v_u_80, (ref) v_u_4, (ref) v_u_83, (ref) v_u_76, (ref) v_u_74, (ref) v_u_23, (ref) v_u_69, (copy) v_u_77, (copy) v_u_78, (copy) v_u_79, (copy) p_u_64, (ref) v_u_82
						local v84 = (os.clock() - v_u_81) / v_u_80
						local v85 = v_u_4:GetValue(math.min(v84, 1), Enum.EasingStyle.Cubic, Enum.EasingDirection.Out)
						if tick() - v_u_83 > 0.005 then
							v_u_83 = tick()
							for _, v86 in pairs(v_u_76:GetChildren()) do
								v86.Size = NumberSequence.new(v86.Size.Keypoints[1].Value + v85 / 4, v86.Size.Keypoints[2].Value)
							end
						end
						local v87, v88
						if v_u_74 then
							v87 = v_u_23(v_u_69, v_u_77, v_u_78, v_u_79, v85)
							v88 = v_u_23(v_u_69, v_u_77, v_u_78, v_u_79, v85 + 0.001)
						else
							local v89 = v_u_69
							local v90 = v_u_78
							local v91 = v_u_79
							local v92 = v89 + (v90 - v89) * v85
							v87 = v92 + (v90 + (v91 - v90) * v85 - v92) * v85
							local v93 = v_u_69
							local v94 = v_u_78
							local v95 = v_u_79
							local v96 = v85 + 0.001
							local v97 = v93 + (v94 - v93) * v96
							v88 = v97 + (v94 + (v95 - v94) * v96 - v97) * v96
						end
						v_u_76.CFrame = CFrame.lookAt(v87, v88)
						if v85 >= 1 or p_u_64.Parent == nil then
							v_u_82:Disconnect()
							for _, v98 in v_u_76:GetChildren() do
								v98.Enabled = false
							end
							task.wait(v_u_80 + 0.4)
							v_u_76:Destroy()
						end
					end)
					task.wait(0.2)
				end
			end
		end,
		["Finisher"] = function(_, p_u_99)
			-- upvalues: (ref) v_u_7, (ref) v_u_2, (ref) v_u_11, (ref) v_u_8
			local v_u_100 = p_u_99:FindFirstChild("HumanoidRootPart")
			if v_u_100 then
				local v_u_101 = nil or v_u_7.Kurourushi.Swarm:Clone()
				v_u_101.CFrame = v_u_100.CFrame
				v_u_101.Parent = workspace.Effects
				local v_u_102 = tick()
				local v_u_103 = nil
				local v_u_104 = 0
				local v_u_105 = tick()
				v_u_103 = v_u_2.PreRender:Connect(function(p106)
					-- upvalues: (copy) v_u_102, (ref) v_u_104, (copy) v_u_100, (ref) v_u_101, (copy) p_u_99, (ref) v_u_103, (ref) v_u_105, (ref) v_u_7, (ref) v_u_11, (ref) v_u_8
					local v107 = (tick() - v_u_102) / 1.75
					local v108 = math.min(v107, 1)
					v_u_104 = v_u_104 + 50 * p106
					local v109 = v_u_100.Position
					local v110 = v_u_104
					local v111 = math.cos(v110) * 3
					local v112 = v_u_104
					local v113 = math.sin(v112) * 3
					local v114 = v_u_104 * 0.7
					local v115 = math.sin(v114) * 3
					local v116 = v109 + Vector3.new(v111, v115, v113)
					local v117 = v_u_104 + 50 * p106
					local v118 = math.cos(v117) * 3
					local v119 = math.sin(v117) * 3
					local v120 = v117 * 0.7
					local v121 = math.sin(v120) * 3
					local v122 = v109 + Vector3.new(v118, v121, v119)
					v_u_101.CFrame = CFrame.lookAt(v116, v122)
					if v108 >= 1 or p_u_99.Parent == nil then
						v_u_103:Disconnect()
						for _, v123 in v_u_101:GetChildren() do
							v123.Enabled = false
						end
						task.wait(1.75)
						v_u_101:Destroy()
					end
					if tick() - v_u_105 > 0.25 then
						v_u_105 = tick()
						local v124 = nil
						for _, v125 in p_u_99:GetChildren() do
							if not v_u_7.Damage.Skeleton:FindFirstChild(v125.Name) or v125.Transparency ~= 0 then
								continue
							end
							v124 = v125
						end
						if not v124 then
							return
						end
						v124.Transparency = 1
						local v126 = v_u_7.Damage.Skeleton:FindFirstChild(v124.Name):Clone()
						local v127 = Instance.new("Weld", v126)
						v127.Part0 = v124
						v127.Part1 = v126
						v126.Parent = v124
						v_u_11:PlaySound(v_u_8.Megumi.Rabbit.Eat, v_u_100, game.SoundService.Effect)
					end
				end)
				v_u_11:Bleed(p_u_99)
			end
		end,
		["Explosion"] = function(p128)
			-- upvalues: (ref) v_u_7, (ref) v_u_11, (ref) v_u_3, (ref) v_u_8, (ref) v_u_9
			local v129 = v_u_7.Kurourushi.RoachExplosion:Clone()
			v129.Parent = workspace.Effects
			v129.CFrame = CFrame.new(p128)
			v_u_11:PlayParticles(v129)
			v_u_3:AddItem(v129, 3)
			v_u_11:PlaySound(v_u_8.Kurourushi.RoachSwarm.Explosion, v129, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p128).Magnitude < 65 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
			end
		end
	}
	v_u_10.Effects:Connect(function(p131, ...)
		-- upvalues: (copy) v_u_130
		local v132 = v_u_130[p131]
		if v132 then
			v132(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("RoachSwarmService")
	v_u_11 = v_u_1.GetController("FXController")
	v_u_12 = v_u_1.GetController("KurourushiController")
end
return v13