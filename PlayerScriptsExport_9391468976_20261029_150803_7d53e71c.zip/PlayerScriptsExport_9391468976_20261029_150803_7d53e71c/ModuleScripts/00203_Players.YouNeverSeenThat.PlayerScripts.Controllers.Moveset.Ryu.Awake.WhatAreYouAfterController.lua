-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Ryu.Awake.WhatAreYouAfterController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "WhatAreYouAfterController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (ref) v_u_12, (copy) v_u_6, (copy) v_u_3, (copy) v_u_2, (copy) v_u_1, (copy) v_u_8, (copy) v_u_9, (copy) v_u_4, (ref) v_u_10
	local v_u_39 = {
		["Startup"] = function(p14)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_11:PlaySound(v_u_7.Hakari.FeverBreak.CrushSwing, v15, game.SoundService.Effect)
			end
		end,
		["Aerial"] = function(p16, p17)
			-- upvalues: (ref) v_u_12
			local v18 = p16:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = p16:FindFirstChild("Humanoid")
				if v19 then
					local v20 = Instance.new("BodyGyro", v18)
					v20.P = 10000
					v20.MaxTorque = Vector3.new(40000, 40000, 40000)
					p17.Position = v18.Position + Vector3.new(0, 18, 0)
					v19.PlatformStand = true
					repeat
						local v21 = v_u_12:GetMouseTarget()
						v20.CFrame = p17:GetAttribute("Aim") or CFrame.new(v18.Position, v21)
						task.wait()
					until not p17.Parent
					v20:Destroy()
					v19.PlatformStand = false
				end
			else
				return
			end
		end,
		["Crush"] = function(p22)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_1, (ref) v_u_11, (ref) v_u_7, (ref) v_u_8
			local v23 = v_u_6.Megumi.Mahoraga.Earthquake:Clone()
			v23.Position = p22
			v23.Parent = workspace.Effects
			v23.Air:Destroy()
			v23.PointLight:Destroy()
			v_u_3:Create(v23.Floor.Ring2, TweenInfo.new(0.4), {
				["TimeScale"] = 0.5
			}):Play()
			v23.Floor.Ring2:Emit(10)
			v23.Floor.Wind2:Emit(15)
			v23.Floor.Dust:Emit(100)
			v_u_2:AddItem(v23, 3)
			local v24 = CFrame.new(p22)
			for _, v25 in v_u_6.Misc.M.Awk.mokultMeh["3"]:GetChildren() do
				v25:PivotTo(v24)
				v_u_1.GetController("MokouController"):ArcTween(v25.Start, true)
			end
			v_u_11:PlaySound(v_u_7.Mechamaru.AbsoluteDestruction.Slam, v23, game.SoundService.Effect)
			v_u_11:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Break, v23, game.SoundService.Effect)
			v_u_11:DustBreak(p22 + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 12, 35, 0.4, 1)
			if (workspace.CurrentCamera.CFrame.Position - p22).Magnitude < 180 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
			end
		end,
		["Dash"] = function(p26)
			-- upvalues: (ref) v_u_6, (ref) v_u_1, (ref) v_u_11, (ref) v_u_7, (ref) v_u_3, (ref) v_u_2
			local v_u_27 = p26:FindFirstChild("HumanoidRootPart")
			if v_u_27 then
				for _, v28 in v_u_6.Ryu.Launch:GetChildren() do
					v28:PivotTo(v_u_27.CFrame * CFrame.Angles(1.5707963267948966, 0, 0))
					v_u_1.GetController("MokouController"):ArcTween(v28.Start, true)
				end
				v_u_11:PlaySound(v_u_7.Hakari.OverLuck.Dash, v_u_27, game.SoundService.Effect)
				for v29 = 1, 5 do
					task.delay(v29 * 0.06, function()
						-- upvalues: (ref) v_u_6, (copy) v_u_27, (ref) v_u_3, (ref) v_u_2
						local v30 = v_u_6.Itadori.Shock:Clone()
						v30.CFrame = CFrame.lookAlong(v_u_27.Position, v_u_27.Velocity) * CFrame.Angles(1.5707963267948966, 0, 0)
						v30.Transparency = 0.3
						v30.Parent = workspace.Effects
						v_u_3:Create(v30, TweenInfo.new(0.15), {
							["Size"] = Vector3.new(20, 0, 20),
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v30, 0.15)
					end)
				end
			end
		end,
		["Hit"] = function(p31, p32)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_4, (ref) v_u_8
			local v33 = p31:FindFirstChild("HumanoidRootPart")
			if v33 then
				local v_u_34 = p32:FindFirstChild("HumanoidRootPart")
				if v_u_34 then
					v_u_11:Flash(p31, Color3.new(1, 1, 1))
					v_u_11:Flash(p32, Color3.new(1, 1, 1))
					v_u_11:PlaySound(v_u_7.Nanami.Interrogate.Hit, v_u_34, game.SoundService.Effect)
					v_u_11:PlaySound(v_u_7.Naoya.Decisive.FirstHit, v_u_34, game.SoundService.Effect)
					task.delay(0.2, function()
						-- upvalues: (ref) v_u_11, (ref) v_u_7, (copy) v_u_34
						v_u_11:PlaySound(v_u_7.Nanami.Dismember, v_u_34, game.SoundService.Effect)
					end)
					for _ = 1, 8 do
						v_u_9:Blood(p31.Head.CFrame, math.random(5, 80), 25, 25)
					end
					for _ = 1, 8 do
						v_u_9:Blood(p32.Head.CFrame, math.random(5, 80), 25, 25)
					end
					if v_u_4.Character == p31 or v_u_4.Character == p32 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.SnapOh)
						v_u_8.CurrentShaker:ShakeSustain(v_u_8.Presets.HeavyHit):StartFadeOut(1)
					elseif (workspace.CurrentCamera.CFrame.Position - v33.Position).Magnitude < 100 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
					end
				else
					return
				end
			else
				return
			end
		end,
		["Hit2"] = function(p35, p36)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_8
			local v37 = p35:FindFirstChild("HumanoidRootPart")
			if v37 then
				local v38 = p36:FindFirstChild("HumanoidRootPart")
				if v38 then
					v_u_11:Flash(p36, Color3.new(1, 1, 1))
					v_u_11:PlaySound(v_u_7.Ryu.Dessert.Hit, v38, game.SoundService.Effect)
					if (workspace.CurrentCamera.CFrame.Position - v37.Position).Magnitude < 180 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
					end
				end
			else
				return
			end
		end
	}
	v_u_10.Effects:Connect(function(p40, ...)
		-- upvalues: (copy) v_u_39
		local v41 = v_u_39[p40]
		if v41 then
			v41(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("WhatAreYouAfterService")
	v_u_11 = v_u_1.GetController("FXController")
	v_u_12 = v_u_1.GetController("ToolController")
end
return v13