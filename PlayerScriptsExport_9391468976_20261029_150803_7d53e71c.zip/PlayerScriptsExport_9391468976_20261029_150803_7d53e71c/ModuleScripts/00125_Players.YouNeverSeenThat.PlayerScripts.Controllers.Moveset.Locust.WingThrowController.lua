-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Locust.WingThrowController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "WingThrowController"
})
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_4, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_8, (ref) v_u_9
	local v_u_32 = {
		["Dash"] = function(p13, p14)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4
			local v15 = p13.HumanoidRootPart
			if v15 then
				local v16 = p13:FindFirstChild("Humanoid")
				if v16 then
					v_u_11:PlaySound(v_u_7.Locust.Flight, v15, game.SoundService.Effect)
					if v_u_4.Character == p13 then
						local v17 = Instance.new("BodyGyro", v15)
						v17.P = 10000
						v17.MaxTorque = Vector3.new(40000, 40000, 40000)
						p14.Position = v15.Position + Vector3.new(0, 12, 0)
						local v18 = tick()
						v16.PlatformStand = true
						local v19 = workspace.CurrentCamera.CFrame
						if tick() - v18 < 0.7 then
							local v20 = workspace:Raycast(v15.Position, v19.LookVector * 10, _G.MapParams)
							if v20 then
								p14.Position = v20.Position - v19.LookVector * 4
							else
								p14.Position = v15.Position + v19.LookVector * 25
							end
						end
						v17.CFrame = v19
						task.wait()
						if p14.Parent then
							continue
						end
						v16.PlatformStand = false
						v17:Destroy()
					end
				end
			else
				return
			end
		end,
		["Throw"] = function(p21)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v22 = p21.HumanoidRootPart
			if v22 then
				local v23 = v_u_6.Itadori.DivergentFist.BlackFlashLaunch:Clone()
				v23.CFrame = v22.CFrame * CFrame.new(2, 1, -5)
				v23.Parent = workspace.Effects
				v23.PointLight:Destroy()
				v23.Wind:Emit(20)
				v_u_2:AddItem(v23, 3)
				local v24 = v_u_6.Choso.CounterSwing.Shock:Clone()
				v24.Size = Vector3.new(6, 30, 6)
				v24.CFrame = v22.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v24.Parent = workspace.Effects
				v_u_2:AddItem(v24, 0.2)
				v_u_3:Create(v24, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(25, 0, 25),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v24.Position + v22.CFrame.LookVector * 10
				}):Play()
				v_u_11:PlaySound(v_u_7.Todo.BruteForce.Swing, v22, game.SoundService.Effect)
				if v_u_4.Character == p21 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Grab"] = function(p25, p26)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_8
			if p25:FindFirstChild("HumanoidRootPart") then
				local v27 = p26:FindFirstChild("HumanoidRootPart")
				if v27 then
					v_u_11:Flash(p26, Color3.new(1, 1, 1))
					v_u_11:PlaySound(v_u_7.Gojo.LapseBlue.Grab, v27, game.SoundService.Effect)
					if (workspace.CurrentCamera.CFrame.Position - v27.Position).Magnitude < 200 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["ThrowHit"] = function(p28)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_4, (ref) v_u_8
			local v_u_29 = p28:FindFirstChild("HumanoidRootPart")
			if v_u_29 then
				for v30 = 1, 10 do
					task.delay(v30 * 0.075, function()
						-- upvalues: (ref) v_u_6, (copy) v_u_29, (ref) v_u_3, (ref) v_u_2
						local v31 = v_u_6.Itadori.Shock:Clone()
						v31.CFrame = CFrame.lookAlong(v_u_29.Position, v_u_29.Velocity) * CFrame.Angles(1.5707963267948966, 0, 0)
						v31.Parent = workspace.Effects
						v_u_3:Create(v31, TweenInfo.new(0.15), {
							["Size"] = Vector3.new(10, 0, 10),
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v31, 0.15)
					end)
				end
				v_u_11:Flash(p28, Color3.new(1, 1, 1))
				if v_u_4.Character == p28 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end
	}
	v_u_9.Effects:Connect(function(p33, ...)
		-- upvalues: (copy) v_u_32
		local v34 = v_u_32[p33]
		if v34 then
			v34(...)
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("WingThrowService")
	v_u_10 = v_u_1.GetController("ToolController")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12