-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.RankedController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
game:GetService("TweenService")
local v_u_2 = game.Players.LocalPlayer
local v3 = game.ReplicatedStorage
require(v3.Modules.Icon)
local _ = v3.Animations
local _ = v3.Utils
local v_u_4 = v3.Sounds
require(v3.Modules.CameraShaker)
require(v3.Modules.MVP)
local v_u_5 = require(game.ReplicatedStorage.Modules.CountryCodes)
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "RankedController"
})
function getFlagEmoji(p13) -- name: getFlagEmoji
	local v14 = {
		["a"] = "\240\159\135\166",
		["b"] = "\240\159\135\167",
		["c"] = "\240\159\135\168",
		["d"] = "\240\159\135\169",
		["e"] = "\240\159\135\170",
		["f"] = "\240\159\135\171",
		["g"] = "\240\159\135\172",
		["h"] = "\240\159\135\173",
		["i"] = "\240\159\135\174",
		["j"] = "\240\159\135\175",
		["k"] = "\240\159\135\176",
		["l"] = "\240\159\135\177",
		["m"] = "\240\159\135\178",
		["n"] = "\240\159\135\179",
		["o"] = "\240\159\135\180",
		["p"] = "\240\159\135\181",
		["q"] = "\240\159\135\182",
		["r"] = "\240\159\135\183",
		["s"] = "\240\159\135\184",
		["t"] = "\240\159\135\185",
		["u"] = "\240\159\135\186",
		["v"] = "\240\159\135\187",
		["w"] = "\240\159\135\188",
		["x"] = "\240\159\135\189",
		["y"] = "\240\159\135\190",
		["z"] = "\240\159\135\191"
	}
	local v15 = string.lower(p13)
	local v16 = string.sub(v15, 1, 1)
	local v17 = string.sub(v15, 2, 2)
	return v14[v16] .. v14[v17]
end
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_2, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (copy) v_u_4, (ref) v_u_6, (copy) v_u_5
	local v_u_18 = v_u_2.PlayerGui:WaitForChild("Menus").Group
	local v_u_19 = v_u_18.Ranked
	v_u_19:SetAttribute("Loaded", true)
	task.spawn(function()
		-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10
		repeat
			task.wait()
		until workspace:GetAttribute("Init") == true
		if workspace:GetAttribute("Match") == nil then
			if workspace:GetAttribute("Roulette") == nil then
				if workspace:GetAttribute("FinalShowdown") == nil then
					if workspace:GetAttribute("NightParade") ~= nil then
						v_u_10:Start()
					end
				else
					v_u_9:Start()
				end
			else
				v_u_8:Start()
				return
			end
		else
			v_u_7:Start()
			return
		end
	end)
	local function v_u_22() -- name: teleport
		-- upvalues: (copy) v_u_19
		for _, v20 in v_u_19:GetChildren() do
			if v20.Name == "Loading" then
				v20.Visible = true
			else
				if not v20:IsA("GuiObject") then
					continue
				end
				v20.Visible = false
			end
		end
		task.spawn(function()
			-- upvalues: (ref) v_u_19
			repeat
				local v21 = v_u_19.Loading.Icon
				v21.Rotation = v21.Rotation + 1
				task.wait()
			until v_u_19.Loading.Visible == false
		end)
	end
	local v_u_23 = false
	v_u_19.VC.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_4, (ref) v_u_23, (copy) v_u_19
		v_u_11:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_23 = not v_u_23
		if v_u_23 then
			v_u_19.VC.Loading.Visible = true
			v_u_19.VC.Image = "rbxassetid://219092693"
		else
			v_u_19.VC.Loading.Visible = false
			v_u_19.VC.Image = "rbxassetid://219092690"
		end
	end)
	v_u_19.Modes.Ranked.Button.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_4, (copy) v_u_22, (ref) v_u_6
		v_u_11:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_22()
		v_u_6.Teleport:Fire(1)
	end)
	v_u_19.Modes.Servers.Button.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_4, (copy) v_u_19
		v_u_11:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		for _, v24 in v_u_19:GetChildren() do
			if not v24:IsA("GuiObject") then
				continue
			end
			v24.Visible = false
		end
		v_u_19.Servers.Visible = true
		v_u_19.Return.Visible = true
		v_u_19.Load.Visible = true
		v_u_19.Create.Visible = true
		v_u_19.VC.Visible = false
	end)
	v_u_19.Return.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_4, (copy) v_u_19
		v_u_11:PlaySound(v_u_4.Misc.UI.Switch, workspace, game.SoundService.Effect)
		for _, v25 in v_u_19:GetChildren() do
			if not v25:IsA("GuiObject") then
				continue
			end
			v25.Visible = false
		end
		v_u_19.Modes.Visible = true
		v_u_19.JoinFriend.Visible = true
		v_u_19.VC.Visible = false
	end)
	v_u_19.Create.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_4, (copy) v_u_19
		v_u_11:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		for _, v26 in v_u_19:GetChildren() do
			if not v26:IsA("GuiObject") then
				continue
			end
			v26.Visible = false
		end
		v_u_19.Create2.Visible = true
		v_u_19.Return.Visible = true
	end)
	v_u_19.JoinFriend.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_4, (copy) v_u_19, (ref) v_u_2, (copy) v_u_18, (copy) v_u_22, (ref) v_u_6
		v_u_11:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		for _, v27 in v_u_19:GetChildren() do
			if not v27:IsA("GuiObject") then
				continue
			end
			v27.Visible = false
		end
		v_u_19.Return.Visible = true
		v_u_19.Friends.Visible = true
		local v28 = v_u_2:GetFriendsOnline(200)
		for _, v29 in v_u_19.Friends:GetChildren() do
			if not v29:IsA("Frame") then
				continue
			end
			v29:Destroy()
		end
		for _, v_u_30 in v28 do
			if v_u_30.LocationType ~= 4 or v_u_30.PlaceId ~= game.PlaceId then
				continue
			end
			local v_u_31 = v_u_18.Parent.Preset.FriendServer:Clone()
			v_u_31.Title.Text = v_u_30.DisplayName
			v_u_31.Count.Visible = false
			v_u_31.Desc.Text = "@" .. v_u_30.UserName
			task.spawn(function()
				-- upvalues: (copy) v_u_30, (copy) v_u_31
				local v32 = game.Players:GetUserThumbnailAsync(v_u_30.VisitorId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size48x48)
				v_u_31.FriendIcon.Image = v32
			end)
			v_u_31.Parent = v_u_19.Friends
			v_u_31.Button.MouseButton1Down:Connect(function()
				-- upvalues: (ref) v_u_11, (ref) v_u_4, (ref) v_u_22, (ref) v_u_6, (copy) v_u_30
				v_u_11:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
				v_u_22()
				v_u_6.Teleport:Fire(6, v_u_30.VisitorId)
			end)
		end
	end)
	local v_u_33 = 5
	v_u_19.Modes.Public.Button.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_4, (copy) v_u_22, (ref) v_u_6
		v_u_11:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_22()
		v_u_6.Teleport:Fire(2)
	end)
	v_u_19.Modes.Roulette.Button.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_4, (copy) v_u_19, (ref) v_u_6, (ref) v_u_33
		v_u_11:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		for _, v34 in v_u_19:GetChildren() do
			if not v34:IsA("GuiObject") then
				continue
			end
			v34.Visible = false
		end
		for _, v35 in v_u_19.GamemodeServers:GetChildren() do
			if not v35:IsA("Frame") or v35.Name ~= "RouServer" then
				continue
			end
			v35:Destroy()
		end
		v_u_19.GamemodeServers.Visible = true
		v_u_19.Return.Visible = true
		v_u_6.Filter:Fire(2)
		v_u_33 = 5
	end)
	v_u_19.Modes.Creator.Button.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_4, (copy) v_u_19, (ref) v_u_6, (ref) v_u_33
		v_u_11:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		for _, v36 in v_u_19:GetChildren() do
			if not v36:IsA("GuiObject") then
				continue
			end
			v36.Visible = false
		end
		for _, v37 in v_u_19.GamemodeServers:GetChildren() do
			if not v37:IsA("Frame") or v37.Name ~= "RouServer" then
				continue
			end
			v37:Destroy()
		end
		v_u_19.GamemodeServers.Visible = true
		v_u_19.Return.Visible = true
		v_u_19.VC.Visible = true
		v_u_6.Filter:Fire(3)
		v_u_33 = 7
	end)
	v_u_19.Modes.NightParade.Button.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_4, (copy) v_u_19, (ref) v_u_6, (ref) v_u_33
		v_u_11:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		for _, v38 in v_u_19:GetChildren() do
			if not v38:IsA("GuiObject") then
				continue
			end
			v38.Visible = false
		end
		for _, v39 in v_u_19.GamemodeServers:GetChildren() do
			if not v39:IsA("Frame") or v39.Name ~= "RouServer" then
				continue
			end
			v39:Destroy()
		end
		v_u_19.GamemodeServers.Visible = true
		v_u_19.Return.Visible = true
		v_u_6.Filter:Fire(4)
		v_u_33 = 8
	end)
	v_u_19.Modes.FinalShowdown.Button.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_4, (copy) v_u_19, (ref) v_u_6, (ref) v_u_33
		v_u_11:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		for _, v40 in v_u_19:GetChildren() do
			if not v40:IsA("GuiObject") then
				continue
			end
			v40.Visible = false
		end
		for _, v41 in v_u_19.GamemodeServers:GetChildren() do
			if not v41:IsA("Frame") or v41.Name ~= "RouServer" then
				continue
			end
			v41:Destroy()
		end
		v_u_19.GamemodeServers.Visible = true
		v_u_19.Return.Visible = true
		v_u_6.Filter:Fire(5)
		v_u_33 = 9
	end)
	v_u_19.GamemodeServers.QuickJoin.Button.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_4, (copy) v_u_22, (ref) v_u_6, (ref) v_u_33, (ref) v_u_23
		v_u_11:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_22()
		v_u_6.Teleport:Fire(v_u_33, true, v_u_23)
	end)
	v_u_19.GamemodeServers.QuickJoinGlobal.Button.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_4, (copy) v_u_22, (ref) v_u_6, (ref) v_u_33, (ref) v_u_23
		v_u_11:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_22()
		v_u_6.Teleport:Fire(v_u_33, nil, v_u_23)
	end)
	local v_u_42 = v_u_19.Create2.TextBox
	v_u_42.FocusLost:Connect(function(p43)
		-- upvalues: (copy) v_u_42, (ref) v_u_6
		if p43 then
			local v44 = v_u_42.Text
			v_u_42.Text = "Filtering..."
			v_u_42.TextEditable = false
			v_u_6.Filter:Fire(v44)
		end
	end)
	v_u_19.Create2.Create.MouseButton1Down:Connect(function()
		-- upvalues: (copy) v_u_42, (ref) v_u_11, (ref) v_u_4, (copy) v_u_22, (ref) v_u_6
		if v_u_42.TextEditable ~= false then
			v_u_11:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
			v_u_22()
			v_u_6.Teleport:Fire(3, v_u_42.Text)
		end
	end)
	local v_u_45 = false
	local v_u_46 = false
	v_u_19.Load.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_45, (ref) v_u_11, (ref) v_u_4, (ref) v_u_6, (ref) v_u_46, (copy) v_u_19
		if v_u_45 ~= true then
			v_u_45 = true
			v_u_11:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
			v_u_6.Filter:Fire(1, v_u_46)
			for _, v47 in v_u_19.Servers:GetChildren() do
				if not v47:IsA("Frame") then
					continue
				end
				v47:Destroy()
			end
			v_u_19.Load.Loading.Visible = true
			repeat
				task.wait()
			until v_u_45 == false
			v_u_19.Load.Loading.Visible = false
		end
	end)
	v_u_19.Load.Sort.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_46, (copy) v_u_19
		v_u_46 = not v_u_46
		v_u_19.Load.Sort.Rotation = v_u_46 and 180 or 0
	end)
	v_u_19.Create2.Rejoin.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_4, (copy) v_u_22, (ref) v_u_6, (ref) v_u_2
		v_u_11:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_22()
		v_u_6.Teleport:Fire(4, v_u_2.UserId)
	end)
	v_u_6.Teleport:Connect(function()
		-- upvalues: (copy) v_u_19
		for _, v48 in v_u_19:GetChildren() do
			if not v48:IsA("GuiObject") then
				continue
			end
			v48.Visible = false
		end
		v_u_19.Modes.Visible = true
		v_u_19.JoinFriend.Visible = true
	end)
	local v_u_49 = nil
	local function v_u_59(p50) -- name: loadList
		-- upvalues: (copy) v_u_19, (ref) v_u_5, (ref) v_u_49, (copy) v_u_18, (ref) v_u_46, (ref) v_u_11, (ref) v_u_4, (copy) v_u_22, (ref) v_u_6
		local v51 = string.lower(v_u_19.Create.Searchbox.Text)
		local v52 = nil
		local v53
		if string.sub(v51, 3, 3) == " " then
			v53 = string.upper((string.sub(v51, 1, 2)))
			v51 = string.sub(v51, 4)
			if v_u_5.ContinentCode[v53] then
				v52 = v_u_5.ContinentCode[v53]
				v53 = nil
			end
		else
			v53 = nil
		end
		local v54 = tick()
		v_u_49 = v54
		for v55, v_u_56 in p50 do
			if v_u_49 ~= v54 then
				break
			end
			local v57 = v_u_56.value[6] or 1
			local v58 = v_u_18.Parent.Preset.PrivateServer:Clone()
			v58.Name = v_u_56.key
			v58.Desc.Text = getFlagEmoji(v_u_56.value[4]) .. " " .. v_u_56.value[1]
			v58.Title.Text = v_u_56.value[2]
			v58.Count.Text = v57 .. "/25"
			v58:SetAttribute("CC", v_u_56.value[4])
			v58.LayoutOrder = v_u_46 == true and v57 and v57 or -v57
			v58.Button.Image = "rbxassetid://" .. (v_u_56.value[5] or 0)
			v58.Parent = v_u_19.Servers
			if v53 and v_u_56.value[4] ~= v53 or (v52 and v_u_5.CountryCodes[v_u_56.value[4]] ~= v52 or not string.match(string.lower(v_u_56.value[2]), v51)) then
				v58.Visible = false
			else
				v58.Visible = true
			end
			v58.Button.MouseButton1Down:Connect(function()
				-- upvalues: (ref) v_u_11, (ref) v_u_4, (ref) v_u_22, (ref) v_u_6, (copy) v_u_56
				v_u_11:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
				v_u_22()
				v_u_6.Teleport:Fire(4, v_u_56.key)
			end)
			if v55 % 15 ~= 0 then
				continue
			end
			task.wait()
		end
	end
	local function v_u_66(p60, p_u_61) -- name: loadListGamemode
		-- upvalues: (copy) v_u_19, (copy) v_u_18, (ref) v_u_11, (ref) v_u_4, (copy) v_u_22, (ref) v_u_6, (ref) v_u_23
		for _, v62 in v_u_19.GamemodeServers:GetChildren() do
			if not v62:IsA("Frame") or (v62.Name == "QuickJoin" or v62.Name == "QuickJoinGlobal") then
				continue
			end
			v62:Destroy()
		end
		for v_u_63, v64 in p60 do
			local v65 = v_u_18.Parent.Preset.RouServer:Clone()
			v65.Name = v_u_63
			v65.Count.Text = v64
			v65.Title.Text = getFlagEmoji(v_u_63) .. " " .. v_u_63
			v65.Parent = v_u_19.GamemodeServers
			v65.Button.MouseButton1Down:Connect(function()
				-- upvalues: (ref) v_u_11, (ref) v_u_4, (ref) v_u_22, (ref) v_u_6, (copy) p_u_61, (copy) v_u_63, (ref) v_u_23
				v_u_11:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
				v_u_22()
				v_u_6.Teleport:Fire(p_u_61, v_u_63, v_u_23)
			end)
		end
	end
	v_u_19.Create.Searchbox:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (copy) v_u_19, (ref) v_u_5
		local v67 = string.lower(v_u_19.Create.Searchbox.Text)
		local v68 = nil
		local v69
		if string.sub(v67, 3, 3) == " " then
			v69 = string.upper((string.sub(v67, 1, 2)))
			v67 = string.sub(v67, 4)
			if v_u_5.ContinentCode[v69] then
				v68 = v_u_5.ContinentCode[v69]
				v69 = nil
			end
		else
			v69 = nil
		end
		for _, v70 in v_u_19.Servers:GetChildren() do
			if not v70:IsA("Frame") then
				continue
			end
			local v71 = v70:GetAttribute("CC")
			if v69 and v71 ~= v69 or (v68 and v_u_5.CountryCodes[v71] ~= v68 or not string.match(string.lower(v70.Title.Text), v67)) then
				v70.Visible = false
			else
				v70.Visible = true
			end
		end
	end)
	v_u_19:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (copy) v_u_19
		if v_u_19.Visible ~= true then
			for _, v72 in v_u_19.Servers:GetChildren() do
				if not v72:IsA("Frame") then
					continue
				end
				v72:Destroy()
			end
		end
	end)
	v_u_6.Filter:Connect(function(p_u_73, p74)
		-- upvalues: (copy) v_u_42, (copy) v_u_66, (copy) v_u_59, (ref) v_u_45
		if typeof(p_u_73) == "string" then
			v_u_42.Text = p_u_73
			v_u_42.TextEditable = true
			return
		elseif p74 == "ROULETTE" then
			local function v75()
				-- upvalues: (ref) v_u_66, (copy) p_u_73
				v_u_66(p_u_73, 5)
			end
			pcall(v75)
			return
		elseif p74 == "CREATOR" then
			local function v76()
				-- upvalues: (ref) v_u_66, (copy) p_u_73
				v_u_66(p_u_73, 7)
			end
			pcall(v76)
			return
		elseif p74 == "NIGHT" then
			local function v77()
				-- upvalues: (ref) v_u_66, (copy) p_u_73
				v_u_66(p_u_73, 8)
			end
			pcall(v77)
			return
		elseif p74 == "FINAL" then
			local function v78()
				-- upvalues: (ref) v_u_66, (copy) p_u_73
				v_u_66(p_u_73, 9)
			end
			pcall(v78)
		else
			local function v79()
				-- upvalues: (ref) v_u_59, (copy) p_u_73
				v_u_59(p_u_73)
			end
			local v80, v81 = pcall(v79)
			if not v80 then
				warn(v81)
			end
			v_u_45 = false
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_6, (copy) v_u_1, (ref) v_u_11, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_7
	v_u_6 = v_u_1.GetService("RankedService")
	v_u_11 = v_u_1.GetController("FXController")
	v_u_8 = v_u_1.GetController("RouletteController")
	v_u_9 = v_u_1.GetController("FinalShowdownController")
	v_u_10 = v_u_1.GetController("NightParadeController")
	v_u_7 = v_u_1.GetController("DuelController")
end
return v12