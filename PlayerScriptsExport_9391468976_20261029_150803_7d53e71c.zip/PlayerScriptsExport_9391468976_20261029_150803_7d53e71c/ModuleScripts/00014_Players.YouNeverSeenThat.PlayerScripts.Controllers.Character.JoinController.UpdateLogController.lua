-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Character.JoinController.UpdateLogController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
game:GetService("TweenService")
local v_u_2 = game.Players.LocalPlayer
local v3 = game.ReplicatedStorage
local _ = v3.Animations
local _ = v3.Utils
local _ = v3.Sounds
local v_u_4 = nil
local v5 = v_u_1.CreateController({
	["Name"] = "UpdateLogController"
})
v5.Ver = "1.85"
local v_u_6 = "V" .. v5.Ver .. " \n THE HALLOWEEN UPDATE"
v5.Updates = {
	{
		"HALLOWEEN",
		{ "We travelled to a different city!", "Gather candies by getting kills or completing various events and go through the portal to exchange them for exclusive emotes, skins and a broom item!" }
	},
	{
		"HIRED KILLER",
		{
			"ADDED 1 NEW SPECIAL (Hidden Inventory)",
			"ADDED 1 NEW MOVE (Flourish)",
			"ADDED 1 NEW VARIANT (The Wrath)",
			"ADDED 1 NEW VARIANT (The Greed)",
			"ADDED 1 NEW VARIANT (The Pride)",
			"ADDED 1 NEW MOVE (Debilitate)",
			"ADDED 1 NEW MOVE (Transcend)",
			"ADDED 1 NEW VARIANT (Ascend)",
			"ADDED 1 NEW MOVE (Rupture)",
			"ADDED 1 NEW VARIANT (Paradise)",
			"ADDED 1 NEW VARIANT (Reincarnation)",
			"ADDED 1 NEW MOVE (Lasso)",
			"ADDED 1 NEW MOVE (Whiplash)",
			"ADDED 1 NEW VARIANT (Twirling Strike)"
		}
	},
	{
		"REGISTER",
		{
			"REGISTER HAS BEEN RELEASED TO THE PUBLIC!",
			"ADDED 1 NEW AWAKENING MOVE (Road Rage)",
			"ADDED 1 NEW AWAKENING MOVE (132-Square-Foot Two-Story House)",
			{
				"GENERAL",
				{ "Big Moves somewhat reworked", "Littering and Gushing Wound now properly stick to objects and throwables" }
			}
		}
	},
	{
		"SKY ASSASSIN",
		{
			{
				"GENERAL",
				{ "Reduced the hitlag of R+3", "Added a height requirement to the aerial evasive", "You can no longer lock onto the user when invisible" }
			},
			{
				"TURBULENCE",
				{ "Increased the hitbox size of Aerial Turbulence" }
			},
			{
				"SKY DISTORTION",
				{ "Sky Distortion Temper now knocks the enemy away when close to you" }
			}
		}
	},
	{
		"PUPPET MASTER",
		{
			"Removed that god awful multi npc body system for Absolute (I HATE IT I HATE IT THERES SO MANY BUGS)",
			{
				"AWAKENING",
				{ "Melee attacks now consume your awakening", "Adjusted the cost of skills during your awakening" }
			}
		}
	},
	{
		"DISASTER PLANTS",
		{
			"Chain knockback spikes damage reduced by 1 (7 -> 6)",
			{
				"SURGING THORNS",
				{ "Surging Thorns damage reduced by 4 (5-5-5 -> 3-3-5)", "Surging Thorns special variant normal damage reduced by 3 (9 -> 6)", "Surging Thorns special variant block break / interrupt damage boost reduced by 1 (3 -> 2)" }
			}
		}
	},
	{
		"SHOP",
		{
			"ADDED SKINS",
			"ADDED 2 NEW ITEMS (C4, RPG)",
			"ADDED 1 NEW VICTORY FLASH (Final Dessert)",
			"ADDED 12 NEW EMOTES (Cory, California Girls, I\'m all ears, Ex Provocation2, Join us for a bite, Wildside, In My Mind, Malo Mart, Richard, Jumper, Hollow Bench, Victory Lap)",
			{
				"GENERAL",
				{
					"Removed 2x option for buying emotes",
					"Gravestone now displays the last kill",
					"Transfigured Flesh wall is now breakable",
					"Added sound effects for Pistol Trick emote"
				}
			}
		}
	},
	{
		"KOGANE",
		{
			"ADDED 7 NEW SHENANIGANS (Liquidation, Transfer, Sunrise, Nightmare, Steed, Void Strider, Overproduction)",
			"ADDED A NEW PLAYLIST BUTTON TO KOGANE",
			"Kogane can now respond to basic chat messages from players",
			{
				"QOL",
				{ "Added icons to Kogane buttons", "Added timer for the pet daily reward" }
			}
		}
	},
	{
		"DOMAIN",
		{
			"Roach Swarm domain barrier damage reduced by 60%",
			"Slicing Exorcism domain barrier damage reduced by 70%",
			"Defense Response domain barrier damage reduced by 25%",
			"Perfection club fists domain barrier damage reduced by 65%",
			"Disaster Plants uppercuts and downslam domain barrier damage reduced by 50%",
			{
				"CLASHING",
				{ "Slightly reduced the cooldown of dashing during a domain clash", "You can no longer be hit by non-melee attacks during a domain clash", "You can now use domain expansions during your awakening if you are within the range of an opening domain expansion" }
			}
		}
	},
	{
		"PERFORMANCE",
		{ "Brought back the new destruction system", "Improved anchoring of moving parts from destruction", "Improved destruction replication (should fix most lag spikes, but server size is also bigger so be aware of that)" }
	},
	{
		"DUELS",
		{ "Ranked now removes the grass", "Ranked no longer has destruction", "Ranked will temporarily default to the flat map until the new maps are fixed" }
	},
	{
		"COMBAT",
		{ "Hitting a player now triggers combat tag", "Hitting dead players no longer gives awakening", "You no longer automatically respawn (A setting is available under [Controls] to revert the change)" }
	},
	{
		"SKILL BUILDER & BUILD MODE",
		{
			"ADDED 1 NEW BLOCK (Water)",
			"ADDED 3 NEW VISUAL EFFECTS (HighlightCore, HighlightFocus, HighlightOutline)",
			{
				"ANIMATIONS",
				{
					"Added missing animations for Vessel",
					"Added missing animations for Switcher",
					"Added missing animations for Salaryman",
					"Added missing animations for Perfection",
					"Added missing animations for Monkey Kid",
					"Added missing animations for Black Death",
					"Added missing animations for Sky Assassin",
					"Added missing animations for Head of the Hei"
				}
			},
			{
				"GENERAL",
				{ "Added horses to the Vehicle Block", "Fixed Particle Node being uncancellable in other branches" }
			}
		}
	},
	{
		"PRIVATE SERVER+",
		{
			"ADDED 2 NEW SERVER SETTINGS (Respawn Debris, Debris Respawn Time)",
			{
				"QOL",
				{ "Reorganized layout of server settings" }
			}
		}
	},
	{
		"GENERAL",
		{
			"ADDED 1 NEW GENERAL SETTING (Damage Counter)",
			{
				"QOL",
				{
					"Added captions to all topbar buttons",
					"Added a visible glow to items that are on the ground",
					"Improved ragdoll controls when dead or using the Ragdoll emote",
					"Water now has a different visual effects when landed on at high speeds"
				}
			},
			{
				"ACHIEVEMENTS",
				{ "Changed the obtainment method for one achievement" }
			}
		}
	},
	{
		"BUG FIXES",
		{
			"Fixed Jeep emote not consistently working",
			"Fixed being able to glide with skateboard emote",
			"Fixed Cursory Impact giving double Projection Meter",
			"Fixed ragdolls triggering a lot of debris effects at once",
			"Fixed TNT flinging the target if grabbed by another player",
			"Fixed Sky Assassin\'s moveset being unavailable in skill builder",
			"Fixed \"I love the taste of iron!\" achievement not being obtainable",
			"Fixed 0.2 Infinite Void sometimes permanently locking all of your skills",
			"Fixed outside forces killing players not giving kill rewards to other players",
			"Fixed stationary parts from destruction still being interpolated on the client",
			"Fixed being able to hit people with Sky Assassin\'s 2nd melee attack if the enemy isn\'t ragdolled",
			"Fixed skill builder\'s linked hitboxes being able to slip through other hitboxes if they\'re large enough",
			"Fixed extra emote pages having issues loading after 32 (do not ask me why some players bought that many)",
			"Fixed Murmurate\'s variant knockback being in world space instead of relative to the height (basically more consistent)"
		}
	}
}
function v5.KnitStart(p7) -- name: KnitStart
	-- upvalues: (copy) v_u_2, (copy) v_u_6
	local v8 = v_u_2.PlayerGui:WaitForChild("Menus").Group.Logs
	local v9 = v8.ScrollingFrame.UpdateTitle
	local v_u_10 = v8.ScrollingFrame.UpdateInfo.UpdateText
	if v_u_6 then
		v9.Text = v_u_6
	end
	local v11 = "\n "
	local v_u_12 = ""
	local v_u_13 = 1
	local v_u_14 = false
	local function v_u_26(p15, p16) -- name: listLog
		-- upvalues: (ref) v_u_13, (ref) v_u_10, (ref) v_u_14, (ref) v_u_12, (copy) v_u_26
		local v17 = p16 or 1
		for v18, v19 in p15 do
			if v_u_13 ~= v17 then
				local v20 = v_u_10.Parent:Clone()
				v20.LayoutOrder = v20.LayoutOrder + 1
				v20.Spacing.Size = UDim2.fromScale(v17 * 0.05, 0)
				v20.Parent = v_u_10.Parent.Parent
				v_u_10 = v20.UpdateText
				v_u_10.Text = ""
				v_u_13 = v17
				v_u_14 = true
			end
			local _, v21 = next(p15, v18)
			if type(v19) == "table" then
				local v22 = v_u_10
				v22.Text = v22.Text .. ("%*- <b>%* :</b>"):format(v_u_14 and "" or "\n", v19[1])
				v_u_12 = v_u_12 .. ("\n\n%*- **%*:**"):format((" "):rep((v17 - 1) * 3), v19[1])
				v_u_26(v19[2], v17 + 1)
				if not v21 then
					continue
				end
				local v23 = v_u_10
				v23.Text = v23.Text .. "\n"
			else
				local v24 = v_u_10
				v24.Text = v24.Text .. ("%*\226\128\162 %*"):format(v_u_14 and "" or "\n", v19)
				v_u_12 = v_u_12 .. ("\n%*- %*"):format((" "):rep((v17 - 1) * 3), v19)
				v_u_14 = false
				if not v21 or type(v21) ~= "table" then
					continue
				end
				local v25 = v_u_10
				v25.Text = v25.Text .. "\n"
			end
		end
	end
	local v27 = v_u_12
	for _, v28 in p7.Updates do
		local v29 = v_u_10.Parent:Clone()
		v29.LayoutOrder = v29.LayoutOrder + 1
		v29.Spacing.Size = UDim2.fromScale(0, 0)
		v29.Parent = v_u_10.Parent.Parent
		local v30 = v29.UpdateText
		v30.Text = ""
		v_u_13 = 0
		v_u_14 = true
		v30.Text = v30.Text .. v11 .. "<b>[ " .. v28[1] .. " ]</b>"
		v_u_12 = v27 .. ("\n\n**[ %* ]**"):format(v28[1])
		v_u_26(v28[2])
		v27 = v_u_12
		v_u_10 = v30
		v11 = "\n \n "
	end
	print(v27)
	v8:SetAttribute("Loaded", true)
end
function v5.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_4, (copy) v_u_1
	v_u_4 = v_u_1.GetController("FXController")
end
return v5