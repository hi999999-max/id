-- Original instance: Players.YouNeverSeenThat.PlayerScripts.PlayerModule.CommonUtils.CharacterUtil
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = game:GetService("Players")
local v2 = script.Parent
local v_u_22 = {
	["_connectionUtil"] = require(v2:WaitForChild("ConnectionUtil")).new(),
	["_boundEvents"] = {},
	["getLocalPlayer"] = function() -- name: getLocalPlayer
		-- upvalues: (copy) v_u_1
		return v_u_1.LocalPlayer
	end,
	["onLocalPlayer"] = function(p3) -- name: onLocalPlayer
		-- upvalues: (copy) v_u_22, (copy) v_u_1
		local v4 = v_u_22.getLocalPlayer()
		if v4 then
			p3(v4)
		end
		v_u_22._connectionUtil:trackConnection("LOCAL_PLAYER", v_u_1:GetPropertyChangedSignal("LocalPlayer"):Connect(function()
			-- upvalues: (ref) v_u_22
			local v5 = v_u_22.getLocalPlayer()
			assert(v5)
			v_u_22._getOrCreateBoundEvent("LOCAL_PLAYER"):Fire(v5)
		end))
		return v_u_22._getOrCreateBoundEvent("LOCAL_PLAYER").Event:Connect(p3)
	end,
	["getCharacter"] = function() -- name: getCharacter
		-- upvalues: (copy) v_u_22
		local v6 = v_u_22.getLocalPlayer()
		if v6 then
			return v6.Character
		else
			return nil
		end
	end,
	["onCharacter"] = function(p_u_7) -- name: onCharacter
		-- upvalues: (copy) v_u_22
		v_u_22._connectionUtil:trackConnection("ON_LOCAL_PLAYER", v_u_22.onLocalPlayer(function(p8)
			-- upvalues: (ref) v_u_22, (copy) p_u_7
			local v9 = v_u_22.getCharacter()
			if v9 then
				p_u_7(v9)
			end
			v_u_22._connectionUtil:trackConnection("CHARACTER_ADDED", p8.CharacterAdded:Connect(function(p10)
				-- upvalues: (ref) v_u_22
				assert(p10)
				v_u_22._getOrCreateBoundEvent("CHARACTER_ADDED"):Fire(p10)
			end))
		end))
		return v_u_22._getOrCreateBoundEvent("CHARACTER_ADDED").Event:Connect(p_u_7)
	end,
	["getChild"] = function(p11, p12) -- name: getChild
		-- upvalues: (copy) v_u_22
		local v13 = v_u_22.getCharacter()
		if v13 then
			local v14 = v13:FindFirstChild(p11)
			if v14 and v14:IsA(p12) then
				return v14
			else
				return nil
			end
		else
			return nil
		end
	end,
	["onChild"] = function(p_u_15, p_u_16, p_u_17) -- name: onChild
		-- upvalues: (copy) v_u_22
		v_u_22._connectionUtil:trackConnection("ON_CHARACTER", v_u_22.onCharacter(function(p18)
			-- upvalues: (ref) v_u_22, (copy) p_u_15, (copy) p_u_16, (copy) p_u_17
			local v19 = v_u_22.getChild(p_u_15, p_u_16)
			if v19 then
				p_u_17(v19)
			end
			v_u_22._connectionUtil:trackConnection("CHARACTER_CHILD_ADDED", p18.ChildAdded:Connect(function(p20)
				-- upvalues: (ref) p_u_15, (ref) p_u_16, (ref) v_u_22
				if p20.Name == p_u_15 and p20:IsA(p_u_16) then
					v_u_22._getOrCreateBoundEvent("CHARACTER_CHILD_ADDED" .. p_u_15 .. p_u_16):Fire(p20)
				end
			end))
		end))
		return v_u_22._getOrCreateBoundEvent("CHARACTER_CHILD_ADDED" .. p_u_15 .. p_u_16).Event:Connect(p_u_17)
	end,
	["_getOrCreateBoundEvent"] = function(p21) -- name: _getOrCreateBoundEvent
		-- upvalues: (copy) v_u_22
		if not v_u_22._boundEvents[p21] then
			v_u_22._boundEvents[p21] = Instance.new("BindableEvent")
		end
		return v_u_22._boundEvents[p21]
	end
}
return v_u_22