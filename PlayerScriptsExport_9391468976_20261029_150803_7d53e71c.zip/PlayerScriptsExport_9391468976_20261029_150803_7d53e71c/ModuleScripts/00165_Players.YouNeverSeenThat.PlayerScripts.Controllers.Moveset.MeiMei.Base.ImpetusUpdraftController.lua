-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.MeiMei.Base.ImpetusUpdraftController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "ImpetusUpdraftController"
})
function v11.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (ref) v_u_10, (copy) v_u_7, (copy) v_u_5, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (ref) v_u_9
	local v_u_65 = {
		["Hit"] = function(p12, p13, p14)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7
			local v15 = p12:FindFirstChild("HumanoidRootPart")
			if v15 then
				local v16 = p13:FindFirstChild("HumanoidRootPart")
				if v16 then
					local v17 = v_u_6.MeiMei.SlashHit:Clone()
					local v18 = Instance.new("Model")
					v17.Parent = v18
					v18:ScaleTo(1.25)
					v_u_2:AddItem(v18, 0.1)
					v17.Parent = workspace.Effects
					v17.CFrame = CFrame.lookAlong(v16.Position, v15.CFrame.LookVector) * CFrame.Angles(0, 0, 0.6108652381980153)
					for _, v19 in v17:GetDescendants() do
						if not v19:IsA("ParticleEmitter") or v19.Lifetime ~= 0.15 then
							continue
						end
						v19.Lifetime = 0.25
					end
					v_u_2:AddItem(v17, 0.5)
					v_u_10:PlayParticles(v17)
					if p14 then
						v_u_10:Bleed(p13)
					end
					v_u_10:Flash(p13, Color3.new(1, 1, 1))
					v_u_10:PlaySound(v_u_7.MeiMei.UpdraftHit, v15, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Slash"] = function(p20)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_5, (ref) v_u_2, (ref) v_u_3
			local v21 = p20:FindFirstChild("HumanoidRootPart")
			if v21 then
				v_u_10:PlaySound(v_u_7.MeiMei.UpdraftSlash, v21, game.SoundService.Effect)
				local v22 = workspace:Raycast(v21.Position, Vector3.new(0, -6, 0), _G.MapParams)
				if v22 then
					local v23 = v_u_5.Utils.MeiMei.Launch:Clone()
					v23.Position = v22.Position
					v_u_10:PlayParticles(v23)
					v23.Parent = workspace.Effects
					v_u_2:AddItem(v23, 0.5)
				end
				local v24 = v_u_5.Utils.MeiMei.MeiMeiSlash:Clone()
				v24.Weld.Part0 = v21
				v24.Weld.C0 = CFrame.Angles(0.3490658503988659, 0.17453292519943295, 0.13962634015954636)
				v_u_10:PlayParticles(v24)
				v24.Parent = workspace.Effects
				v_u_2:AddItem(v24, 1)
				local v25 = v_u_5.Utils.MeiMei.Circling.SwingMesh:Clone()
				v25.Transparency = 0.05
				v25.Mesh.Scale = Vector3.new(0.15, 1, 0.15)
				v25.Mesh.VertexColor = Vector3.new(1.5, 1.5, 2.25)
				v25.Weld.Part0 = v21
				v25.Weld.C0 = CFrame.Angles(0.4363323129985824, -0.3490658503988659, -3.001966313430247) * CFrame.Angles(0, 1.0471975511965976, 0)
				v_u_3:Create(v25.Weld, TweenInfo.new(0.15, Enum.EasingStyle.Linear), {
					["C0"] = v25.Weld.C0 * CFrame.Angles(0, 3.1066860685499065, 0)
				}):Play()
				v_u_3:Create(v25.Mesh, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Scale"] = Vector3.new(0.5, 0.25, 0.5)
				}):Play()
				v_u_3:Create(v25.Mesh, TweenInfo.new(0.09999999999999999, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
					["VertexColor"] = Vector3.new(0.5, 0.5, 0.75)
				}):Play()
				v_u_3:Create(v25, TweenInfo.new(0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.In), {
					["Transparency"] = 1
				}):Play()
				v25.Parent = workspace.Effects
				v_u_2:AddItem(v25, 0.15)
				local v26 = v_u_5.Utils.MeiMei.Circling.WindMesh1:Clone()
				v26.Decal.Transparency = 0.75
				v26.Mesh.Scale = Vector3.new(0.5, 0.5, 0.5)
				local v27 = v21.CFrame * CFrame.Angles(0.3490658503988659, -1.5707963267948966, 0) * CFrame.new(-2, 0, 0)
				local v28 = CFrame.Angles
				local v29 = math.random(-180, 180)
				v26.CFrame = v27 * v28(math.rad(v29), 0, 0)
				v26.Parent = workspace.Effects
				v_u_3:Create(v26, TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
					["CFrame"] = v26.CFrame * CFrame.new(10, 0, 0) * CFrame.Angles(90, 0, 0)
				}):Play()
				v_u_3:Create(v26.Mesh, TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
					["Scale"] = Vector3.new(0.75, 0.05, 0.05)
				}):Play()
				v_u_3:Create(v26.Decal, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v26, 0.15)
				task.wait(0.3)
				v24.Weld:Destroy()
				v24.Anchored = true
			end
		end,
		["Slash2"] = function(p30, p31)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_5, (ref) v_u_2, (ref) v_u_3
			local v32 = p30:FindFirstChild("HumanoidRootPart")
			if v32 then
				v_u_10:PlaySound(v_u_7.MeiMei.UpdraftSlash, v32, game.SoundService.Effect).PlaybackSpeed = math.random(80, 120) / 100
				local v33 = { CFrame.Angles(-0.8726646259971648, 0, 1.5707963267948966), CFrame.Angles(-0.8726646259971648, 0.3490658503988659, 1.3962634015954636), CFrame.Angles(-0.8726646259971648, -0.2617993877991494, 1.7453292519943295) }
				local v34 = v_u_5.Utils.MeiMei.MeiMeiSlash:Clone()
				v34.Weld.Part0 = v32
				v34.Weld.C0 = v33[p31]
				v34.Parent = workspace.Effects
				for _, v35 in v34:GetDescendants() do
					if not v35:IsA("ParticleEmitter") then
						continue
					end
					v35:Emit(v35:GetAttribute("EmitCount"))
				end
				v_u_2:AddItem(v34, 1)
				local v36 = v_u_5.Utils.MeiMei.Circling.SwingMesh:Clone()
				v36.Transparency = 0.05
				v36.Mesh.Scale = Vector3.new(0.15, 1, 0.15)
				v36.Mesh.VertexColor = Vector3.new(1.5, 1.5, 2.25)
				v36.Weld.Part0 = v32
				v36.Weld.C0 = v33[p31]
				v_u_3:Create(v36.Weld, TweenInfo.new(0.15, Enum.EasingStyle.Linear), {
					["C0"] = v36.Weld.C0 * CFrame.Angles(0, 3.1066860685499065, 0)
				}):Play()
				v_u_3:Create(v36.Mesh, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Scale"] = Vector3.new(0.5, 0.25, 0.5)
				}):Play()
				v_u_3:Create(v36.Mesh, TweenInfo.new(0.09999999999999999, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
					["VertexColor"] = Vector3.new(0.5, 0.5, 0.75)
				}):Play()
				v_u_3:Create(v36, TweenInfo.new(0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.In), {
					["Transparency"] = 1
				}):Play()
				v36.Parent = workspace.Effects
				v_u_2:AddItem(v36, 0.15)
				task.wait(0.15)
				v34.Weld:Destroy()
				v34.Anchored = true
			end
		end,
		["Hit2"] = function(p37, p38, p39)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v40 = p37:FindFirstChild("HumanoidRootPart")
			if v40 then
				local v41 = p38:FindFirstChild("HumanoidRootPart")
				if v41 then
					local v42 = { CFrame.Angles(0, 0, 1.5707963267948966), CFrame.Angles(0, 0.3490658503988659, 1.3962634015954636), CFrame.Angles(0, -0.2617993877991494, 1.7453292519943295) }
					local v43 = v_u_6.MeiMei.SlashHit:Clone()
					local v44 = Instance.new("Model")
					v43.Parent = v44
					v44:ScaleTo(1.25)
					v_u_2:AddItem(v44, 0.1)
					v43.Parent = workspace.Effects
					v43.CFrame = CFrame.lookAlong(v41.Position, v40.CFrame.LookVector) * v42[p39]
					for _, v45 in v43:GetDescendants() do
						if not v45:IsA("ParticleEmitter") or v45.Lifetime ~= 0.15 then
							continue
						end
						v45.Lifetime = 0.25
					end
					v_u_2:AddItem(v43, 0.5)
					v_u_10:PlayParticles(v43)
					v_u_10:Flash(p38, Color3.new(1, 1, 1))
					v_u_10:PlaySound(v_u_7.MeiMei.UpdraftHit, v40, game.SoundService.Effect).PlaybackSpeed = math.random(80, 120) / 100
					if p37 == v_u_4.Character or p38 == v_u_4.Character then
						v_u_8.CurrentShaker:Shake(p39 == 3 and v_u_8.Presets.HeavyHit or v_u_8.Presets.MediumHit)
					end
				end
			else
				return
			end
		end,
		["Slash3"] = function(p46, p47)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_3
			local v48 = p46:FindFirstChild("HumanoidRootPart")
			if v48 then
				local v49 = {
					CFrame.Angles(1.5707963267948966, -1.0471975511965976, 1.1344640137963142),
					CFrame.Angles(0.6108652381980153, 3.141592653589793, 0.4363323129985824),
					CFrame.Angles(1.5707963267948966, -1.0471975511965976, 1.1344640137963142),
					CFrame.Angles(0.6108652381980153, 3.141592653589793, 0.4363323129985824),
					CFrame.Angles(0.6108652381980153, 3.141592653589793, 0)
				}
				local v50 = v_u_5.Utils.MeiMei.MeiMeiSlash:Clone()
				v50.Weld.Part0 = v48
				v50.Weld.C0 = v49[p47]
				v50.Parent = workspace.Effects
				for _, v51 in v50:GetDescendants() do
					if not v51:IsA("ParticleEmitter") then
						continue
					end
					if p47 == 2 or (p47 == 4 or p47 == 5) then
						local v52 = NumberRange.new
						local v53 = v51.RotSpeed.Max
						v51.RotSpeed = v52((math.abs(v53)))
					end
					v51:Emit(v51:GetAttribute("EmitCount"))
				end
				v_u_2:AddItem(v50, 1)
				local v54 = v_u_5.Utils.MeiMei.Circling.SwingMesh:Clone()
				v54.Transparency = 0.05
				v54.Mesh.Scale = Vector3.new(0.15, 1, 0.15)
				v54.Mesh.VertexColor = Vector3.new(1.5, 1.5, 2.25)
				v54.Weld.Part0 = v48
				v54.Weld.C0 = v49[p47]
				v_u_3:Create(v54.Weld, TweenInfo.new(0.15, Enum.EasingStyle.Linear), {
					["C0"] = v54.Weld.C0 * CFrame.Angles(0, 3.1066860685499065, 0)
				}):Play()
				v_u_3:Create(v54.Mesh, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Scale"] = Vector3.new(0.5, 0.25, 0.5)
				}):Play()
				v_u_3:Create(v54.Mesh, TweenInfo.new(0.09999999999999999, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
					["VertexColor"] = Vector3.new(0.5, 0.5, 0.75)
				}):Play()
				v_u_3:Create(v54, TweenInfo.new(0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.In), {
					["Transparency"] = 1
				}):Play()
				v54.Parent = workspace.Effects
				v_u_2:AddItem(v54, 0.15)
				task.wait(0.15)
				if v50:FindFirstChild("Weld") then
					v50.Weld:Destroy()
				end
				v50.Anchored = true
			end
		end,
		["Hit3"] = function(p55, p56, p57)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v58 = p55:FindFirstChild("HumanoidRootPart")
			if v58 then
				local v59 = p56:FindFirstChild("HumanoidRootPart")
				if v59 then
					local v60 = {
						CFrame.Angles(1.5707963267948966, -1.0471975511965976, 1.1344640137963142),
						CFrame.Angles(0.6108652381980153, 3.141592653589793, 0.4363323129985824),
						CFrame.Angles(1.5707963267948966, -1.0471975511965976, 1.1344640137963142),
						CFrame.Angles(0.6108652381980153, 3.141592653589793, 0.4363323129985824),
						CFrame.Angles(0.6108652381980153, 3.141592653589793, 0)
					}
					local v61 = v_u_6.MeiMei.SlashHit:Clone()
					local v62 = Instance.new("Model")
					v61.Parent = v62
					v62:ScaleTo(1.25)
					v_u_2:AddItem(v62, 0.1)
					v61.Parent = workspace.Effects
					v61.CFrame = CFrame.lookAlong(v59.Position, v58.CFrame.LookVector) * v60[p57]
					for _, v63 in v61:GetDescendants() do
						if not v63:IsA("ParticleEmitter") or v63.Lifetime ~= 0.15 then
							continue
						end
						v63.Lifetime = 0.25
					end
					v_u_2:AddItem(v61, 0.5)
					v_u_10:PlayParticles(v61)
					v_u_10:Flash(p56, Color3.new(1, 1, 1))
					v_u_10:PlaySound(v_u_7.MeiMei.UpdraftHit, v58, game.SoundService.Effect).PlaybackSpeed = math.random(80, 120) / 100
					if p55 == v_u_4.Character or p56 == v_u_4.Character then
						v_u_8.CurrentShaker:Shake(p57 == 3 and v_u_8.Presets.HeavyHit or v_u_8.Presets.MediumHit)
					end
				end
			else
				return
			end
		end,
		["Finisher"] = function(p64)
			-- upvalues: (ref) v_u_10
			if not p64:GetAttribute("MeiBleeding") then
				p64:SetAttribute("MeiBleeding", true)
				v_u_10:Bleed(p64)
			end
		end
	}
	v_u_9.Effects:Connect(function(p66, ...)
		-- upvalues: (copy) v_u_65
		local v67 = v_u_65[p66]
		if v67 then
			v67(...)
		end
	end)
end
function v11.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("ImpetusUpdraftService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11