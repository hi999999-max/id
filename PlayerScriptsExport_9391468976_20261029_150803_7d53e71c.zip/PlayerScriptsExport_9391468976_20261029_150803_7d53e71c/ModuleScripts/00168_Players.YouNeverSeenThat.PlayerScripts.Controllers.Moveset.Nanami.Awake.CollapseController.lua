-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Nanami.Awake.CollapseController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
local v_u_10 = require(v6.Modules.SraikoVFX)
require(v6.Modules.LightningBeams)
local v_u_11 = RaycastParams.new()
v_u_11.FilterType = Enum.RaycastFilterType.Include
v_u_11.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
Random.new()
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = nil
local v17 = v_u_1.CreateController({
	["Name"] = "CollapseController"
})
function v17.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_13, (copy) v_u_7, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (copy) v_u_8, (copy) v_u_11, (copy) v_u_10, (copy) v_u_4, (copy) v_u_2, (ref) v_u_14, (ref) v_u_12
	local v_u_92 = {
		["Hit"] = function(p18, p19)
			-- upvalues: (ref) v_u_13, (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v20 = p19.HumanoidRootPart
			if v20 then
				v_u_13:Flash(p19, Color3.new(0.333333, 0.666667, 1), 0.2)
				local v21 = v_u_7.Nanami.Collapse.Slam.Emit.Strike.Hit:Clone()
				local v22 = Instance.new("Model")
				v21.Parent = v22
				v22:ScaleTo(0.75)
				v_u_3:AddItem(v22, 0.1)
				v21.Parent = v20
				for _, v_u_23 in pairs(v21:GetDescendants()) do
					if not v_u_23:IsA("ParticleEmitter") then
						continue
					end
					v_u_23:Emit(v_u_23:GetAttribute("EmitCount"))
					task.delay(0.05, function()
						-- upvalues: (copy) v_u_23
						v_u_23.TimeScale = 0.1
					end)
					task.delay(0.221, function()
						-- upvalues: (copy) v_u_23
						v_u_23.TimeScale = 1
					end)
				end
				if p18 == v_u_5.Character or p19 == v_u_5.Character then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end,
		["Hit2"] = function(p24, p25)
			-- upvalues: (ref) v_u_13, (ref) v_u_5, (ref) v_u_9
			if p25.HumanoidRootPart then
				v_u_13:Flash(p25, Color3.new(0.333333, 0.666667, 1), 0.2)
				if p24 == v_u_5.Character or p25 == v_u_5.Character then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end,
		["Jump"] = function(p26, p27)
			-- upvalues: (ref) v_u_13, (ref) v_u_8, (ref) v_u_11, (ref) v_u_7, (ref) v_u_10, (ref) v_u_3
			local v28 = p26.HumanoidRootPart
			if v28 then
				if not p27 then
					v_u_13:PlaySound(v_u_8.Nanami.Collapse.Jump, v28, game.SoundService.Effect)
					local v29 = workspace:Raycast(v28.Position, Vector3.new(0, -10, 0), v_u_11)
					if v29 then
						for _, v30 in pairs(v_u_7.Nanami.Collapse.Jump.Meshes:GetChildren()) do
							local v31 = v30:Clone()
							local v32 = v_u_10.HandleMesh(v31, CFrame.new(v29.Position) * (p26.HumanoidRootPart.CFrame - p26.HumanoidRootPart.CFrame.Position) * CFrame.Angles(0.5235987755982988, 0, 0))
							v31.Parent = workspace.Effects
							v_u_3:AddItem(v31, v32)
						end
						v_u_10.Emit(v_u_7.Nanami.Collapse.Jump.Jump, CFrame.new(v29.Position, v29.Position + v29.Normal) * CFrame.Angles(-1.5707963267948966, 0, 0))
					end
				end
			else
				return
			end
		end,
		["ArmEmit"] = function(p33)
			-- upvalues: (ref) v_u_7, (ref) v_u_10, (ref) v_u_3, (ref) v_u_4, (ref) v_u_13, (ref) v_u_8
			local v34 = p33.HumanoidRootPart
			if v34 then
				for _, v35 in pairs(v_u_7.Nanami.Collapse.ChargeEmit.Meshes:GetChildren()) do
					local v36 = v35:Clone()
					local v37 = v_u_10.HandleMesh(v36, v34.CFrame)
					v36.Parent = workspace.Effects
					v_u_3:AddItem(v36, v37)
				end
				local v38 = v_u_7.Nanami.Collapse.ChargeEmit.Emit.Strike:Clone()
				v38.CFrame = v34.CFrame
				v38.Parent = workspace.Effects
				v_u_3:AddItem(v38, 3)
				for _, v_u_39 in pairs(v38:GetDescendants()) do
					if v_u_39:IsA("ParticleEmitter") then
						v_u_39:Emit(v_u_39:GetAttribute("EmitCount"))
					end
					if not v_u_39:IsA("Beam") then
						continue
					end
					v_u_39.Enabled = true
					v_u_4:Create(v_u_39, TweenInfo.new(0.3), {
						["Width0"] = 0,
						["Width1"] = 0
					}):Play()
					task.delay(0.4, function()
						-- upvalues: (copy) v_u_39
						v_u_39.Enabled = false
						v_u_39.Width0 = 25
						v_u_39.Width1 = 25
					end)
				end
				v_u_13:PlaySound(v_u_8.Nanami.Collapse.Charge, v34, game.SoundService.Effect)
			end
		end,
		["Leap"] = function(p40, p41, p42, _, _)
			-- upvalues: (ref) v_u_5, (ref) v_u_2
			local v43 = p40.HumanoidRootPart
			if v43 then
				local v44 = p40:FindFirstChild("Humanoid")
				if v44 then
					if v_u_5.Character == p40 then
						local v45 = v43.AssemblyLinearVelocity
						local _ = v45.Magnitude
						local v46 = v43.Position + v45 / 10
						local v47 = Instance.new("BodyGyro", v43)
						v47.P = 0
						v47.MaxTorque = Vector3.new(0, 0, 0)
						p41.Position = v46
						local v48 = tick()
						v44.PlatformStand = true
						local v49 = false
						local v50 = v_u_2.Heartbeat:Wait()
						local v51 = v45.Unit
						local v52 = v47.MaxTorque.X
						local v53 = v52 + (40000 - v52) * 25 * v50
						v47.MaxTorque = Vector3.new(v53, v53, v53)
						v47.P = v47.P + (10000 - v47.P) * 25 * v50
						local v54 = v51:Lerp(workspace.CurrentCamera.CFrame.LookVector, 25 * v50).Unit
						local v55 = v45:Lerp(v54 * v45.Magnitude, 25 * v50)
						local v56 = -workspace.Gravity
						v45 = v55 + Vector3.new(0, v56, 0) * v50
						v46 = v46 + v45 * v50
						local v57 = workspace:Raycast(v43.Position, v45.Unit * 10, _G.MapParams)
						if v57 then
							v46 = v57.Position - v45.Unit * 5
							if not v49 and tick() - v48 > 0.3 then
								p42:FireServer(v57.Position, v57.Normal, v43.Position)
								v49 = true
							end
						end
						p41.Position = v46
						v47.CFrame = CFrame.lookAt(v43.Position, v43.Position + v54)
						task.wait()
						if p41.Parent then
							continue
						end
						v47:Destroy()
						repeat
							task.wait()
						until not v43:FindFirstChild("CollapseBG")
						v44.PlatformStand = false
					end
				end
			else
				return
			end
		end,
		["Collapse"] = function(p58, p59, p60)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10
			local v61 = p58.HumanoidRootPart
			if v61 then
				local v62 = v_u_7.Gojo.LapseBlue.LapseBlue.Grab:Clone()
				v62.Weld:Destroy()
				v62.Anchored = true
				v62.Position = p59
				v62.Size = Vector3.new(50, 50, 50)
				v62.Parent = workspace.Effects
				local v63 = Instance.new("Highlight", v62)
				v63.FillTransparency = 1
				v63.OutlineTransparency = 1
				v_u_4:Create(v62, TweenInfo.new(0.226, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
					["Size"] = Vector3.new(0, 0, 0),
					["Transparency"] = 50
				}):Play()
				v_u_3:AddItem(v62, 0.5)
				local v64 = v_u_7.Nanami.Collapse.OrbEmit.Strike:Clone()
				v64.CFrame = CFrame.new(p59, p59 + p60) * CFrame.new(0, 0, -2)
				v64.Parent = workspace.Effects
				v_u_3:AddItem(v64, 6)
				v64.Beams.WorldCFrame = CFrame.lookAt(p59, (v61.CFrame * CFrame.new(0, -4.5, 0)).Position) * CFrame.new(0, 0, -1) * CFrame.Angles(0, 3.141592653589793, 0)
				v64.Beams2.WorldCFrame = CFrame.lookAt(p59, (v61.CFrame * CFrame.new(0, -4.5, 0)).Position) * CFrame.new(0, 0, -1) * CFrame.Angles(0, 3.141592653589793, 0)
				for _, v65 in pairs(v64:GetDescendants()) do
					if not v65:IsA("ParticleEmitter") then
						continue
					end
					v65.Enabled = true
				end
				for _, v66 in pairs(v64.Beams:GetDescendants()) do
					if not v66:IsA("Beam") then
						continue
					end
					v66.Enabled = true
				end
				v_u_13:PlaySound(v_u_8.Nanami.Collapse.Impact, v64, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - p59).Magnitude < 100 then
					v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(0.226)
				end
				task.wait(0.226)
				if (workspace.CurrentCamera.CFrame.Position - p59).Magnitude < 100 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
				for _, v67 in pairs(v64:GetDescendants()) do
					if v67:IsA("ParticleEmitter") then
						v67.Enabled = false
					end
					if not v67:IsA("Beam") then
						continue
					end
					v67.Enabled = false
				end
				for _, v68 in pairs(v_u_7.Nanami.Collapse.Slam.Meshes:GetChildren()) do
					local v69 = v68:Clone()
					local v70 = v_u_10.HandleMesh(v69, CFrame.new(p59, p59 + p60) * CFrame.new(0, 0, 7))
					v69.Parent = workspace.Effects
					v_u_3:AddItem(v69, v70)
				end
				v_u_10.Emit(v_u_7.Nanami.Collapse.Slam.Emit.Strike, CFrame.new(p59, p59 + p60))
				for _, v_u_71 in pairs(v64.Beams2:GetDescendants()) do
					if not v_u_71:IsA("Beam") then
						continue
					end
					v_u_71.Enabled = true
					v_u_4:Create(v_u_71, TweenInfo.new(0.2), {
						["Width0"] = 0,
						["Width1"] = 0
					}):Play()
					task.delay(0.30000000000000004, function()
						-- upvalues: (copy) v_u_71
						v_u_71.Enabled = false
						v_u_71.Width0 = 45
						v_u_71.Width1 = 45
					end)
				end
			end
		end,
		["CollapseDebree"] = function(p72, p73, p74)
			-- upvalues: (ref) v_u_2, (ref) v_u_13, (ref) v_u_8, (ref) v_u_14, (ref) v_u_7, (ref) v_u_3
			local v_u_75 = p72.HumanoidRootPart
			if v_u_75 then
				v_u_2.Heartbeat:Wait()
				local v_u_76 = {}
				p74.AncestryChanged:Once(function()
					-- upvalues: (ref) v_u_13, (ref) v_u_8, (copy) v_u_75, (copy) v_u_76
					v_u_13:PlaySound(v_u_8.Nanami.Collapse.Activate, v_u_75, game.SoundService.Effect)
					task.wait(0.5)
					for _, v77 in pairs(v_u_76) do
						v77:Destroy()
					end
				end)
				for v78 = 1, buffer.len(p73) / 3 do
					local v79 = (v78 - 1) * 3
					local v80 = v_u_14:GetVoxel((buffer.readbits(p73, v79 * 8, 24)))
					if not (v80 and v80.Parent) then
						continue
					end
					for _, v81 in pairs(v_u_7.Nanami.Collapse.Rock:GetChildren()) do
						local v82 = v81:Clone()
						table.insert(v_u_76, v82)
						v82.Parent = v80
						v_u_3:AddItem(v82, 10)
					end
				end
			end
		end,
		["Break"] = function(p83)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_13, (ref) v_u_8, (ref) v_u_9
			local v84 = v_u_7.Nanami.Collapse.Break:Clone()
			v84.CFrame = CFrame.new(p83)
			v84.Parent = workspace.Effects
			v_u_3:AddItem(v84, 3)
			v_u_13:PlaySound(v_u_8.Nanami.Collapse.DebreeDrop, v84, game.SoundService.Effect).PlaybackSpeed = math.random(90, 110) / 100
			for _, v85 in pairs(v84:GetDescendants()) do
				if not v85:IsA("ParticleEmitter") then
					continue
				end
				v85:Emit(v85:GetAttribute("EmitCount"))
			end
			if (workspace.CurrentCamera.CFrame.Position - p83).Magnitude < 65 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
			end
		end,
		["Launch"] = function(p86, p87)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v88 = p86:FindFirstChild("HumanoidRootPart")
			if v88 then
				local v89 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v89.CFrame = CFrame.new(v88.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v89.Size = Vector3.new(0, 0, 5)
				v89.Parent = workspace.Effects
				v_u_4:Create(v89, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v89.Position + Vector3.new(0, p87, 0)
				}):Play()
				v_u_3:AddItem(v89, 0.3)
				if p87 < 0 then
					v_u_13:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v88, game.SoundService.Effect)
					v_u_13:DustBreak(v88.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v88.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			end
		end,
		["Finisher"] = function(p90)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_13
			if p90.HumanoidRootPart then
				if _G.Settings.Gore then
					local v91 = v_u_7.Heian.BloodSpread:Clone()
					v91.Parent = p90.Head
					v91:Emit(20)
					v_u_3:AddItem(v91, 2)
				end
				v_u_13:Bleed(p90)
			end
		end
	}
	v_u_12.Effects:Connect(function(p93, ...)
		-- upvalues: (copy) v_u_92
		local v94 = v_u_92[p93]
		if v94 then
			v94(...)
		end
	end)
end
function v17.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_12, (copy) v_u_1, (ref) v_u_15, (ref) v_u_13, (ref) v_u_14, (ref) v_u_16
	v_u_12 = v_u_1.GetService("CollapseService")
	v_u_15 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("FXController")
	v_u_14 = v_u_1.GetController("DebreeController")
	v_u_16 = v_u_1.GetController("HandicapController")
end
return v17