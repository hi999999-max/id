-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Hiromi.Base.JudgeReachController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
game:GetService("TweenService")
local v_u_3 = game.Players.LocalPlayer
local v4 = game.ReplicatedStorage
local _ = v4.Animations
local v_u_5 = v4.Utils
local v_u_6 = v4.Sounds
local v_u_7 = require(v4.Modules.CameraShaker)
require(v4.Modules.BloodyZee)
require(v4.Modules.LightningBeams)
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "JudgeReachController"
})
function v11.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_9, (copy) v_u_6, (copy) v_u_5, (copy) v_u_2, (copy) v_u_3, (copy) v_u_7
	local v_u_19 = {
		["Startup"] = function(p12)
			-- upvalues: (ref) v_u_9, (ref) v_u_6
			local v13 = p12:FindFirstChild("HumanoidRootPart")
			if v13 then
				v_u_9:PlaySound(v_u_6.Hakari.EnergySurge.Swing, v13, game.SoundService.Effect)
			end
		end,
		["ExtendWind"] = function(p14)
			if not p14:FindFirstChild("HumanoidRootPart") then
			end
		end,
		["Hit"] = function(p15, p16)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_9, (ref) v_u_6, (ref) v_u_3, (ref) v_u_7
			local v17 = p16:FindFirstChild("HumanoidRootPart")
			if v17 then
				local v18 = v_u_5.Mahito.CrushingRushdown.DrillImpact:Clone()
				v18.Position = v17.Position
				v18.Parent = workspace.Effects
				v_u_2:AddItem(v18, 1)
				v18.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 0.498039))
				v18.Wind.Color = v18.Sparks.Color
				v18.Wind2.Color = v18.Sparks.Color
				v18.Sparks:Emit(50)
				v18.Wind:Emit(7)
				v18.Wind2:Emit(7)
				v_u_9:Flash(p16, Color3.new(1, 1, 1))
				v_u_9:PlaySound(v_u_6.Hakari.EnergySurge.Hit1, v17, game.SoundService.Effect)
				if v_u_3 == p15 or v_u_3.Character == p16 then
					v_u_7.CurrentShaker:Shake(v_u_7.Presets.Snap)
				end
			end
		end
	}
	JudgeReachService.Effects:Connect(function(p20, ...)
		-- upvalues: (copy) v_u_19
		local v21 = v_u_19[p20]
		if v21 then
			v21(...)
		end
	end)
end
function v11.KnitInit(_) -- name: KnitInit
	-- upvalues: (copy) v_u_1, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10
	JudgeReachService = v_u_1.GetService("JudgeReachService")
	v_u_8 = v_u_1.GetController("HitboxController")
	v_u_9 = v_u_1.GetController("FXController")
	v_u_10 = v_u_1.GetController("JoinController")
end
return v11