-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Yuta.Awake.CopyController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("UserInputService")
game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
game:GetService("GuiService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = v_u_5:GetMouse()
local v_u_7 = game.ReplicatedStorage
local _ = v_u_7.Animations
local v_u_8 = v_u_7.Utils
local v_u_9 = v_u_7.Sounds
local v_u_10 = require(v_u_7.Modules.CameraShaker)
require(v_u_7.Modules.BloodyZee)
local _ = require(v_u_7.Modules.ListData).MoveList
local v_u_11 = require(v_u_7.Modules.KeybindIcons)
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = v_u_1.CreateController({
	["Name"] = "CopyController"
})
v_u_15.SelectRemote = nil
function v_u_15.SelectWheel(_, p16) -- name: SelectWheel
	-- upvalues: (copy) v_u_15, (copy) v_u_5
	if v_u_15.SelectRemote then
		local v17 = v_u_5.PlayerGui:FindFirstChild("CopyWheel")
		if v17 then
			local v18 = v17.Wheel:FindFirstChild(p16)
			if v18 and v18.Visible then
				v_u_15.SelectRemote:FireServer(v18:GetAttribute("Name"))
			end
		end
	else
		return
	end
end
function v_u_15.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_13, (copy) v_u_9, (copy) v_u_8, (copy) v_u_3, (copy) v_u_10, (copy) v_u_7, (copy) v_u_15, (copy) v_u_5, (ref) v_u_14, (copy) v_u_11, (copy) v_u_4, (copy) v_u_2, (copy) v_u_6
	local v_u_19 = {
		["Shrine"] = Color3.fromRGB(255, 155, 155),
		["Doors"] = Color3.fromRGB(170, 255, 127),
		["Limitless"] = Color3.fromRGB(170, 255, 255),
		["10 Shadows"] = Color3.fromRGB(120, 120, 120),
		["Adaptation"] = Color3.fromRGB(255, 255, 255),
		["Transfiguration"] = Color3.fromRGB(255, 170, 255),
		["Blood"] = Color3.fromRGB(170, 75, 75),
		["Boogie Woogie"] = Color3.fromRGB(170, 255, 255),
		["Black Mucus"] = Color3.fromRGB(170, 255, 127),
		["Execution"] = Color3.fromRGB(115, 99, 77),
		["Mass"] = Color3.fromRGB(170, 170, 255),
		["Dismantle"] = Color3.fromRGB(255, 85, 0),
		["Clairvoyance"] = Color3.fromRGB(255, 235, 235),
		["Puppets"] = Color3.fromRGB(225, 10, 75),
		["Projection"] = Color3.fromRGB(128, 126, 255),
		["Ratio"] = Color3.fromRGB(94, 191, 255),
		["Kamehameha"] = Color3.fromRGB(255, 21, 52),
		["Hand Sword"] = Color3.fromRGB(167, 125, 203),
		["Bird Control"] = Color3.fromRGB(35, 40, 80),
		["Plants"] = Color3.fromRGB(172, 203, 163),
		["Granite Blast"] = Color3.fromRGB(170, 255, 255),
		["Roaches"] = Color3.fromRGB(101, 35, 44)
	}
	local v_u_20 = Color3.new(0, 0, 0)
	local v_u_87 = {
		["Start"] = function(p21, _)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v22 = p21:FindFirstChild("HumanoidRootPart")
			if v22 then
				v_u_13:PlaySound(v_u_9.Yuta.CursedSpeechStart, v22, game.SoundService.Effect)
			end
		end,
		["MouthSpeech"] = function(p23)
			-- upvalues: (ref) v_u_8, (ref) v_u_3
			local v24 = v_u_8.Yuta.RikaHandTrail.CSVfx:Clone()
			v24.Parent = p23.Head
			v24.CursedSpeech:Emit(1)
			v24.L.Ring:Emit(2)
			v24.R.Ring:Emit(2)
			v24.M.Ring:Emit(2)
			v_u_3:AddItem(v24, 4)
		end,
		["MouthGlitch"] = function(p25)
			local v26 = p25.Head:FindFirstChild("CSVfx")
			if v26 then
				v26.M.Glitch:Emit(10)
			end
		end,
		["DontMove"] = function(p27)
			-- upvalues: (ref) v_u_10, (ref) v_u_8, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9
			if (workspace.CurrentCamera.CFrame.Position - p27.Head.Position).Magnitude < 100 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
			end
			local v28 = v_u_8.Misc.Items.Voice:Clone()
			local v29 = Instance.new("Model")
			v_u_3:AddItem(v29, 0.2)
			v28.Parent = v29
			v29:ScaleTo(1.8)
			v28.Anchored = false
			local v30 = Instance.new("Motor6D")
			v30.Parent = v28
			v30.Part0 = p27.Head
			v30.Part1 = v28
			v28.Parent = workspace.Effects
			v_u_3:AddItem(v28, 4)
			for _, v31 in v28:GetChildren() do
				if not v31:IsA("ParticleEmitter") or v31.Name == "WindCircle" then
					continue
				end
				v31.LockedToPart = true
				v31:Emit(v31:GetAttribute("EmitCount"))
			end
			v_u_13:PlaySound(v_u_9.Misc.Items.Voice, p27.HumanoidRootPart, game.SoundService.Effect)
			v_u_13:PlaySound(v_u_9.Yuta.VoiceDontMove, p27.HumanoidRootPart, game.SoundService.Voice)
		end,
		["PromptWheel"] = function(p_u_32, p_u_33)
			-- upvalues: (ref) v_u_7, (ref) v_u_15, (ref) v_u_5, (ref) v_u_14, (ref) v_u_11, (copy) v_u_19, (copy) v_u_20, (ref) v_u_13, (ref) v_u_9, (ref) v_u_4, (ref) v_u_2, (ref) v_u_6
			local v_u_34 = v_u_7.Utils.Yuta.CopyWheel:Clone()
			v_u_15.SelectRemote = p_u_33
			local v_u_35 = v_u_34.Wheel
			v_u_35.Size = UDim2.new(0.1, 150, 0.1, 150)
			local v_u_36 = 0
			local v_u_37 = v_u_5.Character.Moveset:FindFirstChild("Copy", true)
			local v_u_38 = {}
			local v39 = p_u_32[5]
			if v39 then
				v_u_38[1] = v39
			end
			local v40 = p_u_32[6]
			if v40 then
				v_u_38[2] = v40
			end
			local v41 = p_u_32[7]
			if v41 then
				v_u_38[3] = v41
			end
			local v42 = p_u_32[8]
			if v42 then
				v_u_38[4] = v42
			end
			if #v_u_38 == 0 then
				v_u_35.Switch.Visible = false
			end
			local v_u_43 = nil
			local v_u_44 = nil
			local v_u_45 = 1
			local function v_u_56(p46) -- name: loadButtons
				-- upvalues: (ref) v_u_43, (ref) v_u_44, (ref) v_u_36, (ref) v_u_45, (copy) v_u_35, (ref) v_u_7, (ref) v_u_14, (ref) v_u_11, (copy) v_u_37, (ref) v_u_19, (ref) v_u_20, (ref) v_u_13, (ref) v_u_9, (copy) p_u_33
				v_u_43 = p46
				v_u_44 = nil
				v_u_36 = 0
				v_u_45 = 1
				for _, v47 in v_u_35:GetChildren() do
					if not v47:IsA("TextButton") then
						continue
					end
					v47.SelectionStroke.Enabled = false
					local v48 = v_u_7.Keybind.Combat:FindFirstChild("Skill " .. v47.Name)
					local v49 = v_u_14.LastInput or "Keyboard"
					local v50 = v48:FindFirstChild((v49 == "Xbox" or v49 == "Playstation") and "Gamepad" or v49)
					v47.Key.Text = v50 and ("[ %* ]"):format((v_u_11:GetTextForKeyCode(v50))) or ""
					local v51 = v47.Name
					local v52 = tonumber(v51)
					local v_u_53 = p46[v52]
					if v_u_53 then
						v47.Visible = true
						if v_u_36 < v52 then
							v_u_36 = v52
						end
						v47:SetAttribute("Name", v_u_53[1])
						local v54 = v_u_53[2]
						local v55 = v_u_53[3]
						if v_u_37:GetAttribute("Tip") == v_u_53[1] then
							v54 = v_u_37.Value
							v55 = v_u_37:GetAttribute("LastUse")
						end
						v47:SetAttribute("Cooldown", v54)
						v47:SetAttribute("LastUsed", v55)
						v47.Text = v_u_53[1]
						v47.BackgroundColor3 = v_u_19[v_u_53[1]] or v_u_20
						v47.MouseEnter:Connect(function()
							-- upvalues: (ref) v_u_13, (ref) v_u_9
							v_u_13:PlaySound(v_u_9.Misc.UI.Hover, workspace, game.SoundService.Effect)
						end)
						v47.MouseButton1Click:Connect(function()
							-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) p_u_33, (copy) v_u_53
							v_u_13:PlaySound(v_u_9.Misc.UI.Click, workspace, game.SoundService.Effect)
							p_u_33:FireServer(v_u_53[1])
						end)
					else
						v47.Visible = false
					end
				end
			end
			v_u_56(p_u_32)
			local function v58() -- name: swapPage
				-- upvalues: (ref) v_u_43, (copy) p_u_32, (copy) v_u_38, (copy) v_u_56
				local v57 = v_u_43 == p_u_32 and v_u_38 or p_u_32
				if #v57 ~= 0 then
					v_u_56(v57)
				end
			end
			v_u_35.Switch.MouseButton1Click:Connect(v58)
			p_u_33.OnClientEvent:Connect(function(p59)
				-- upvalues: (ref) v_u_43, (copy) p_u_32, (copy) v_u_38, (copy) v_u_56
				if p59 == "Swap" then
					local v60 = v_u_43 == p_u_32 and v_u_38 or p_u_32
					if #v60 ~= 0 then
						v_u_56(v60)
					end
				end
			end)
			v_u_34.Parent = v_u_5.PlayerGui
			v_u_34.Enabled = true
			v_u_13:PlaySound(v_u_9.Misc.UI.Switch, workspace, game.SoundService.Effect)
			v_u_4:Create(v_u_35, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
				["Size"] = UDim2.new(0.2, 150, 0.2, 150)
			}):Play()
			p_u_33.AncestryChanged:Once(function()
				-- upvalues: (copy) v_u_34
				v_u_34:Destroy()
			end)
			local v_u_61 = workspace.CurrentCamera.ViewportSize / 2
			local v62 = workspace.CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(function()
				-- upvalues: (ref) v_u_61
				v_u_61 = workspace.CurrentCamera.ViewportSize / 2
			end)
			local v63 = game:GetService("GuiService"):GetGuiInset()
			local v64 = v_u_35.Switch.AbsoluteSize.Magnitude
			local v65 = v_u_61
			local v66 = v_u_44
			local v67 = v_u_45
			local v68 = false
			local v69 = nil
			while true do
				while true do
					if not v_u_34.Parent then
						v_u_15.SelectRemote = nil
						v62:Disconnect()
						return
					end
					v_u_45 = v67 + task.wait()
					if v_u_45 >= 1 then
						v_u_45 = 0
						v67 = v_u_45
						for _, v70 in v_u_35:GetChildren() do
							if not (v70:IsA("TextButton") and v70.Visible) then
								continue
							end
							local v71 = workspace:GetServerTimeNow()
							local v72 = v70:GetAttribute("LastUsed")
							local v73 = v70:GetAttribute("Cooldown")
							local v74 = v70:GetAttribute("Name")
							local v75 = v71 - v72
							if v75 < v73 then
								local v76 = v73 - v75
								v70.Text = ("%* [%*]"):format(v74, (math.floor(v76)))
							else
								v70.Text = ("%*"):format(v74)
							end
						end
					else
						v67 = v_u_45
					end
					if not v68 and (v66 and (v_u_2:IsMouseButtonPressed(Enum.UserInputType.MouseButton1) or v_u_2:IsGamepadButtonDown(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonA))) then
						break
					end
					local v77 = nil
					if v_u_2.TouchEnabled then
						::l31::
						if not v77 or v77.Magnitude < 0.5 then
							continue
						end
						local v78 = -v77.Y
						local v79 = v77.X
						local v80 = math.atan2(v78, v79)
						local v81 = ((math.deg(v80) + 90) % 360 + 45) / 90
						local v82 = math.floor(v81) % 4 + 1
						local v83 = v_u_35:FindFirstChild((math.clamp(v82, 1, v_u_36)))
						if not (v83 and v83.Visible) then
							continue
						end
						if v66 then
							if v66 == v83 then
								continue
							end
							v66.SelectionStroke.Enabled = false
						end
						v69 = true
						v_u_44 = v83
						v83.SelectionStroke.Enabled = true
						v66 = v_u_44
					else
						if v_u_2.GamepadEnabled then
							for _, v84 in v_u_2:GetGamepadState(Enum.UserInputType.Gamepad1) do
								if v84.KeyCode ~= Enum.KeyCode.Thumbstick2 then
									continue
								end
								v77 = v84.Position
							end
							goto l31
						end
						local v85 = v65 - (Vector2.new(v_u_6.X, v_u_6.Y) + v63)
						if v85.Magnitude >= v64 then
							local v86 = v85.Unit
							v77 = Vector2.new(-v86.X, v86.Y)
							v68 = false
							goto l31
						end
						v68 = true
					end
				end
				if v69 then
					v_u_13:PlaySound(v_u_9.Misc.UI.Click, workspace, game.SoundService.Effect)
					v69 = false
				end
				p_u_33:FireServer(v66:GetAttribute("Name"))
			end
		end
	}
	CopyService.Effects:Connect(function(p88, ...)
		-- upvalues: (copy) v_u_87
		local v89 = v_u_87[p88]
		if v89 then
			v89(...)
		end
	end)
end
function v_u_15.KnitInit(_) -- name: KnitInit
	-- upvalues: (copy) v_u_1, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14
	CopyService = v_u_1.GetService("CopyService")
	v_u_12 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("FXController")
	v_u_14 = v_u_1.GetController("ToolController")
end
return v_u_15