-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Uro.TurbulanceController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = require(v_u_5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "TurbulanceController"
})
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_2, (copy) v_u_6, (copy) v_u_3, (copy) v_u_5, (copy) v_u_8, (copy) v_u_9, (copy) v_u_4, (ref) v_u_10
	local v_u_71 = {
		["Startup"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_2, (ref) v_u_6, (ref) v_u_3
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_11:PlaySound(v_u_7.Uro.Turbulence.Start, v14, game.SoundService.Effect)
				task.wait(0.2)
				if p13.Info:FindFirstChild("InSkill") then
					local v15 = Instance.new("Model", workspace.Effects)
					local v16 = Instance.new("Highlight")
					v16.DepthMode = Enum.HighlightDepthMode.Occluded
					v16.FillColor = Color3.fromRGB(255, 255, 255)
					v16.FillTransparency = 1
					v16.OutlineTransparency = 1
					v16.Parent = v15
					v_u_2:AddItem(v15, 0.6)
					local v17 = v14.Position - Vector3.new(0, 4, 0) + v14.CFrame.LookVector * 4 - v14.CFrame.RightVector * 2
					local v18 = v_u_6.Uro.AirDistort2:Clone()
					v18.Transparency = 1
					v_u_3:Create(v18, TweenInfo.new(0.3), {
						["Transparency"] = 10
					}):Play()
					v18.Parent = v15
					local v19 = v14.Position - Vector3.new(0, 4, 0) + v14.CFrame.LookVector * 4 + v14.CFrame.RightVector * 2
					local v20 = v_u_6.Uro.AirDistort2:Clone()
					v20.Transparency = 1
					v_u_3:Create(v20, TweenInfo.new(0.3), {
						["Transparency"] = 10
					}):Play()
					v20.Parent = v15
					local v21 = tick()
					local v22 = 12
					local v23 = (p13["Left Arm"].CFrame * CFrame.new(0, -1, 0)).Position
					local v24 = (p13["Right Arm"].CFrame * CFrame.new(0, -1, 0)).Position
					local v25 = (v23 - v17).Magnitude
					local v26 = (v24 - v19).Magnitude
					local v27 = CFrame.lookAt(v17, v23)
					local v28 = CFrame.lookAt(v19, v24)
					v18.CFrame = v27 + v27.LookVector * (v25 / 2)
					v18.Size = Vector3.new(v22, v22, v25)
					v20.CFrame = v28 + v28.LookVector * (v26 / 2)
					v20.Size = Vector3.new(v22, v22, v26)
					local v29 = task.wait()
					if tick() > v21 + 0.2 then
						local v30 = v29 * 10
						v22 = math.lerp(v22, 4, v30)
					end
					if v15.Parent and p13.Parent then
						continue
					end
				end
			else
				return
			end
		end,
		["Startup2"] = function(p31)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v32 = p31:FindFirstChild("HumanoidRootPart")
			if v32 then
				v_u_11:PlaySound(v_u_7.Uro.Turbulence.Kick, v32, game.SoundService.Effect)
				v_u_11:ArmFlash(p31["Left Leg"], Color3.fromRGB(255, 133, 172), 0.7)
			end
		end,
		["Wave"] = function(p33)
			if not p33:FindFirstChild("HumanoidRootPart") then
			end
		end,
		["Kick"] = function(p34, p35)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_11, (ref) v_u_7, (ref) v_u_5
			local v36 = p34:FindFirstChild("HumanoidRootPart")
			if v36 then
				local v37 = v36.CFrame * CFrame.Angles(math.rad(p35 and 0 or 40), 0, 0) * CFrame.new(0, -1, -5)
				local v38 = v_u_6.Choso.CounterSwing:Clone()
				v38.Shockwave:Destroy()
				v38.Shock2.Size = Vector3.new(0, 20, 0)
				v38:PivotTo(v37)
				v38.Parent = workspace.Effects
				v_u_2:AddItem(v38, 0.5)
				v_u_3:Create(v38.Shock, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(0, 30, 0),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v38.Shock2.Position + v37.LookVector * 14
				}):Play()
				v_u_3:Create(v38.Shock2, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(10, 0, 10),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v38.Shock2.Position + v37.LookVector * 25
				}):Play()
				if not p35 then
					v_u_11:PlaySound(v_u_7.Uro.Turbulence.Flip, v36, game.SoundService.Effect)
				end
				local v39 = v_u_5.Utils.Gojo.HandTrail:Clone()
				v39.Parent = workspace.Effects
				v39.Trail.FaceCamera = true
				v39.Trail.Lifetime = 0.3
				v39.Weld.Part0 = p34["Left Leg"]
				task.wait(0.4)
				local v40 = v_u_5.Utils.Gojo.HandTrail:Clone()
				v40.Parent = workspace.Effects
				v40.Trail.FaceCamera = true
				v40.Trail.Lifetime = 0.3
				v40.Weld.Part0 = p34["Right Leg"]
				task.wait(0.3)
				v39.Trail.Enabled = false
				v40.Trail.Enabled = false
				v_u_2:AddItem(v39, 0.3)
				v_u_2:AddItem(v40, 0.3)
			end
		end,
		["Crush"] = function(p41)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2
			local v42 = workspace.Effects:FindFirstChild("UroTurbulence")
			if not v42 then
				local v_u_43 = Instance.new("Model", workspace.Effects)
				v_u_43.Name = "UroTurbulence"
				task.spawn(function()
					-- upvalues: (ref) v_u_43
					repeat
						task.wait(1)
					until #v_u_43:GetChildren() <= 0
					v_u_43:Destroy()
				end)
				local v44 = Instance.new("Highlight")
				v44.FillTransparency = 1
				v44.OutlineTransparency = 1
				v44.Parent = v_u_43
				v42 = v_u_43
			end
			local v45 = v_u_6.Uro.AirDistort2:Clone()
			v45.Size = Vector3.new(12, 0, 12)
			v45.Position = p41
			v45.Parent = v42
			v_u_3:Create(v45, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Size"] = Vector3.new(12, 20, 12)
			}):Play()
			task.wait(0.3)
			v_u_3:Create(v45, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
				["Size"] = Vector3.new(12, 0, 12)
			}):Play()
			v_u_2:AddItem(v45, 0.3)
		end,
		["Crush2"] = function(p46, p47, p48)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_8, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v49 = p46:FindFirstChild("HumanoidRootPart")
			if v49 then
				v_u_11:PlaySound(v_u_7.Uro.Turbulence.Burst, v49, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v49.Position).Magnitude < 60 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
				local v50 = v49.Position
				local v51 = (v50 - p47).Magnitude
				local v52 = CFrame.lookAt(v50, p47)
				local v53 = v_u_6.Naoya.Fall:Clone()
				v53:PivotTo(v52 * CFrame.Angles(1.5707963267948966, 0, 0) - Vector3.new(0, 4, 0))
				v53.Parent = workspace.Effects
				v_u_2:AddItem(v53, 0.8)
				v53.Mesh.Start.Transparency = 0.3
				v53.Mesh2.Start.Transparency = 0.7
				v53.Mesh3.Start.Transparency = 0.6
				v_u_3:Create(v53.Mesh.Start, TweenInfo.new(0.3, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = nil,
					["Size"] = v53.Mesh.End.Size,
					["CFrame"] = v53.Mesh.End.CFrame + Vector3.new(0, 4, 0)
				}):Play()
				v_u_3:Create(v53.Mesh2.Start, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = nil,
					["Size"] = v53.Mesh2.End.Size,
					["CFrame"] = v53.Mesh2.End.CFrame + Vector3.new(0, 8, 0)
				}):Play()
				v_u_3:Create(v53.Mesh3.Start, TweenInfo.new(0.8, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = nil,
					["Size"] = v53.Mesh3.End.Size,
					["CFrame"] = v53.Mesh3.End.CFrame + Vector3.new(0, 12, 0)
				}):Play()
				v53.Mesh.End:Destroy()
				v53.Mesh2.End:Destroy()
				v53.Mesh3.End:Destroy()
				local v54 = Instance.new("Model", workspace.Effects)
				local v55 = Instance.new("Highlight")
				v55.FillTransparency = 1
				v55.OutlineTransparency = 1
				v55.Parent = v54
				v_u_2:AddItem(v54, p48 and 0.5 or 0.2)
				local v56 = v_u_6.Uro.AirDistort2:Clone()
				v56.Position = p47
				v56.Parent = v54
				if p48 then
					v56.Size = Vector3.new(0, 0, v51)
					v56.CFrame = v52 + v52.LookVector * 3
					v_u_3:Create(v56, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
						["Size"] = Vector3.new(24, 24, v51),
						["Position"] = v56.Position + v52.LookVector * (v51 / 2)
					}):Play()
					task.wait(0.2)
					v_u_3:Create(v56, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Size"] = Vector3.new(0, 0, v51)
					}):Play()
				else
					v56.Size = Vector3.new(12, 12, v51)
					v56.CFrame = v52 + v52.LookVector * (v51 / 2)
					task.wait(0.075)
					v_u_3:Create(v56, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Size"] = Vector3.new(24, 24, 0),
						["Position"] = nil,
						["Position"] = v56.Position + v52.LookVector * (v51 / 2)
					}):Play()
				end
			else
				return
			end
		end,
		["Hit"] = function(p57)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_8
			local v58 = p57:FindFirstChild("HumanoidRootPart")
			if v58 then
				v_u_11:Flash(p57, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Ryu.Unsatisfied.FinalHit1, v58, game.SoundService.Effect)
				local v59 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v59.Position = v58.Position
				v59.Parent = workspace.Effects
				v_u_2:AddItem(v59, 1)
				v59.Sparks.Color = ColorSequence.new(Color3.fromRGB(255, 165, 165))
				v59.Wind.Color = v59.Sparks.Color
				v59.Wind2.Color = v59.Sparks.Color
				v59.Sparks:Emit(30)
				v59.Wind2:Emit(7)
				if (workspace.CurrentCamera.CFrame.Position - v58.Position).Magnitude < 60 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Finisher"] = function(_, p60)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v61 = p60:FindFirstChild("HumanoidRootPart")
			if v61 then
				if p60.Parent then
					v_u_11:PlaySound(v_u_7.Itadori.Dismantle.Explode, v61, game.SoundService.Effect)
					v_u_11:PlaySound(v_u_7.Megumi.Elephant.Explode, v61, game.SoundService.Effect)
					for _, v62 in p60:GetDescendants() do
						if not (v62:IsA("BasePart") or v62:IsA("Decal")) then
							continue
						end
						v62.Transparency = 1
					end
					for _ = 1, 50 do
						v_u_9:Blood(v61.CFrame, 200, 360, 360)
					end
					if _G.Settings.Gore then
						local v63 = v_u_6.Heian.BloodSpread:Clone()
						v63.Parent = p60.Head
						v63:Emit(20)
						v_u_2:AddItem(v63, 2)
					end
					for _ = 1, 20 do
						local v_u_64 = v_u_6.Damage.Chunk:Clone()
						v_u_64.CFrame = v61.CFrame
						v_u_64.CollisionGroup = "Effects"
						local v65 = math.random(-90, 90)
						local v66 = math.random(20, 50)
						local v67 = math.random
						v_u_64.Velocity = Vector3.new(v65, v66, v67(-90, 90))
						local v68 = math.random(-200, 200)
						local v69 = math.random(-200, 200)
						local v70 = math.random
						v_u_64.RotVelocity = Vector3.new(v68, v69, v70(-200, 200))
						v_u_64.Parent = workspace.Effects
						v_u_2:AddItem(v_u_64, 3)
						task.delay(0.1, function()
							-- upvalues: (copy) v_u_64, (ref) v_u_3
							v_u_64.CanCollide = true
							task.wait(1.9)
							v_u_3:Create(v_u_64, TweenInfo.new(1), {
								["Size"] = Vector3.new(0, 0, 0)
							}):Play()
							v_u_64.Blood.Enabled = false
							v_u_64.Trail.Enabled = false
						end)
						if _G.Settings.Gore ~= false then
							continue
						end
						v_u_64.Color = Color3.fromRGB(255, 85, 255)
						v_u_64.Trail.Color = ColorSequence.new(Color3.fromRGB(255, 85, 255))
						v_u_64.Blood.Color = v_u_64.Trail.Color
					end
					if v_u_4:DistanceFromCharacter(v61.Position) < 40 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
					end
				end
			else
				return
			end
		end
	}
	v_u_10.Effects:Connect(function(p72, ...)
		-- upvalues: (copy) v_u_71
		local v73 = v_u_71[p72]
		if v73 then
			v73(...)
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("TurbulanceService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12