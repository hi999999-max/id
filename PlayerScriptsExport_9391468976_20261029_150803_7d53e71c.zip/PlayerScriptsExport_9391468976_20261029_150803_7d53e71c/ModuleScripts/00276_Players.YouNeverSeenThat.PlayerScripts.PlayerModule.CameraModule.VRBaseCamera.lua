-- Original instance: Players.YouNeverSeenThat.PlayerScripts.PlayerModule.CameraModule.VRBaseCamera
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = game:GetService("VRService")
local _ = game:GetService("Players").LocalPlayer
local v_u_2 = game:GetService("Lighting")
local v_u_3 = game:GetService("RunService")
local v_u_4 = UserSettings():GetService("UserGameSettings")
local v_u_5 = require(script.Parent:WaitForChild("CameraInput"))
local v_u_6 = require(script.Parent:WaitForChild("ZoomController"))
local v7 = script.Parent.Parent:WaitForChild("CommonUtils")
require(v7:WaitForChild("FlagUtil"))
local v_u_8 = require(script.Parent:WaitForChild("BaseCamera"))
local v_u_9 = setmetatable({}, v_u_8)
v_u_9.__index = v_u_9
function v_u_9.new() -- name: new
	-- upvalues: (copy) v_u_8, (copy) v_u_9
	local v10 = v_u_8.new()
	local v11 = v_u_9
	local v12 = setmetatable(v10, v11)
	v12.gamepadZoomLevels = { 0, 7 }
	v12.headScale = 1
	v12:SetCameraToSubjectDistance(7)
	v12.VRFadeResetTimer = 0
	v12.VREdgeBlurTimer = 0
	v12.gamepadResetConnection = nil
	v12.needsReset = true
	v12.recentered = false
	v12:Reset()
	return v12
end
function v_u_9.Reset(p13) -- name: Reset
	p13.stepRotateTimeout = 0
end
function v_u_9.GetModuleName(_) -- name: GetModuleName
	return "VRBaseCamera"
end
function v_u_9.GamepadZoomPress(p14) -- name: GamepadZoomPress
	-- upvalues: (copy) v_u_8
	v_u_8.GamepadZoomPress(p14)
	p14:GamepadReset()
	p14:ResetZoom()
end
function v_u_9.GamepadReset(p15) -- name: GamepadReset
	p15.stepRotateTimeout = 0
	p15.needsReset = true
end
function v_u_9.ResetZoom(p16) -- name: ResetZoom
	-- upvalues: (copy) v_u_6
	v_u_6.SetZoomParameters(p16.currentSubjectDistance, 0)
	v_u_6.ReleaseSpring()
end
function v_u_9.OnEnabledChanged(p_u_17) -- name: OnEnabledChanged
	-- upvalues: (copy) v_u_8, (copy) v_u_5, (copy) v_u_1, (copy) v_u_2
	v_u_8.OnEnabledChanged(p_u_17)
	if p_u_17.enabled then
		p_u_17.gamepadResetConnection = v_u_5.gamepadReset:Connect(function()
			-- upvalues: (copy) p_u_17
			p_u_17:GamepadReset()
		end)
		p_u_17.thirdPersonOptionChanged = v_u_1:GetPropertyChangedSignal("ThirdPersonFollowCamEnabled"):Connect(function()
			-- upvalues: (copy) p_u_17
			p_u_17:Reset()
		end)
		p_u_17.vrRecentered = v_u_1.UserCFrameChanged:Connect(function(p18, _)
			-- upvalues: (copy) p_u_17
			if p18 == Enum.UserCFrame.Floor then
				p_u_17.recentered = true
			end
		end)
	else
		if p_u_17.inFirstPerson then
			p_u_17:GamepadZoomPress()
		end
		if p_u_17.thirdPersonOptionChanged then
			p_u_17.thirdPersonOptionChanged:Disconnect()
			p_u_17.thirdPersonOptionChanged = nil
		end
		if p_u_17.vrRecentered then
			p_u_17.vrRecentered:Disconnect()
			p_u_17.vrRecentered = nil
		end
		if p_u_17.cameraHeadScaleChangedConn then
			p_u_17.cameraHeadScaleChangedConn:Disconnect()
			p_u_17.cameraHeadScaleChangedConn = nil
		end
		if p_u_17.gamepadResetConnection then
			p_u_17.gamepadResetConnection:Disconnect()
			p_u_17.gamepadResetConnection = nil
		end
		local v19 = v_u_2:FindFirstChild("VRFade")
		if v19 then
			v19.Brightness = 0
		end
	end
end
function v_u_9.OnCurrentCameraChanged(p_u_20) -- name: OnCurrentCameraChanged
	-- upvalues: (copy) v_u_8
	v_u_8.OnCurrentCameraChanged(p_u_20)
	if p_u_20.cameraHeadScaleChangedConn then
		p_u_20.cameraHeadScaleChangedConn:Disconnect()
		p_u_20.cameraHeadScaleChangedConn = nil
	end
	local v21 = workspace.CurrentCamera
	if v21 then
		p_u_20.cameraHeadScaleChangedConn = v21:GetPropertyChangedSignal("HeadScale"):Connect(function()
			-- upvalues: (copy) p_u_20
			p_u_20:OnHeadScaleChanged()
		end)
		p_u_20:OnHeadScaleChanged()
	end
end
function v_u_9.OnHeadScaleChanged(p22) -- name: OnHeadScaleChanged
	local v23 = workspace.CurrentCamera.HeadScale
	for v24, v25 in p22.gamepadZoomLevels do
		p22.gamepadZoomLevels[v24] = v25 * v23 / p22.headScale
	end
	p22:SetCameraToSubjectDistance(p22:GetCameraToSubjectDistance() * v23 / p22.headScale)
	p22.headScale = v23
end
function v_u_9.GetVRFocus(p26, p27, p28) -- name: GetVRFocus
	local v29 = p26.lastCameraFocus or p27
	local v30 = p26.cameraTranslationConstraints.x
	local v31 = p26.cameraTranslationConstraints.y + p28
	local v32 = math.min(1, v31)
	local v33 = p26.cameraTranslationConstraints.z
	p26.cameraTranslationConstraints = Vector3.new(v30, v32, v33)
	local v34 = p26:GetCameraHeight()
	local v35 = Vector3.new(0, v34, 0)
	local v36 = CFrame.new
	local v37 = p27.x
	local v38 = v29.y
	local v39 = p27.z
	return v36(Vector3.new(v37, v38, v39):Lerp(p27 + v35, p26.cameraTranslationConstraints.y))
end
function v_u_9.StartFadeFromBlack(p40) -- name: StartFadeFromBlack
	-- upvalues: (copy) v_u_4, (copy) v_u_2
	if v_u_4.VignetteEnabled ~= false then
		local v41 = v_u_2:FindFirstChild("VRFade")
		if not v41 then
			v41 = Instance.new("ColorCorrectionEffect")
			v41.Name = "VRFade"
			v41.Parent = v_u_2
		end
		v41.Brightness = -1
		p40.VRFadeResetTimer = 0.1
	end
end
function v_u_9.UpdateFadeFromBlack(p42, p43) -- name: UpdateFadeFromBlack
	-- upvalues: (copy) v_u_2
	local v44 = v_u_2:FindFirstChild("VRFade")
	if p42.VRFadeResetTimer > 0 then
		local v45 = p42.VRFadeResetTimer - p43
		p42.VRFadeResetTimer = math.max(v45, 0)
		local v46 = v_u_2:FindFirstChild("VRFade")
		if v46 and v46.Brightness < 0 then
			local v47 = v46.Brightness + p43 * 10
			v46.Brightness = math.min(v47, 0)
			return
		end
	elseif v44 then
		v44.Brightness = 0
	end
end
function v_u_9.StartVREdgeBlur(p48, p49, p50) -- name: StartVREdgeBlur
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_1
	if p50 or v_u_4.VignetteEnabled ~= false then
		local v51 = workspace.CurrentCamera:FindFirstChild("VRBlurPart")
		if not v51 then
			local v_u_52 = Instance.new("Part")
			v_u_52.Name = "VRBlurPart"
			v_u_52.Parent = workspace.CurrentCamera
			v_u_52.CanTouch = false
			v_u_52.CanCollide = false
			v_u_52.CanQuery = false
			v_u_52.Anchored = true
			v_u_52.Size = Vector3.new(0.44, 0.47, 1)
			v_u_52.Transparency = 1
			v_u_52.CastShadow = false
			v_u_3.RenderStepped:Connect(function(_)
				-- upvalues: (ref) v_u_1, (ref) v_u_52
				local v53 = v_u_1:GetUserCFrame(Enum.UserCFrame.Head)
				local v54 = workspace.CurrentCamera.CFrame * (CFrame.new(v53.p * workspace.CurrentCamera.HeadScale) * (v53 - v53.p))
				v_u_52.CFrame = v54 * CFrame.Angles(0, 3.141592653589793, 0) + v54.LookVector * (1.05 * workspace.CurrentCamera.HeadScale)
				v_u_52.Size = Vector3.new(0.44, 0.47, 1) * workspace.CurrentCamera.HeadScale
			end)
			v51 = v_u_52
		end
		local v55 = p49.PlayerGui:FindFirstChild("VRBlurScreen")
		local v56
		if v55 then
			v56 = v55:FindFirstChild("VRBlur")
		else
			v56 = nil
		end
		if not v56 then
			local v57 = v55 or (Instance.new("SurfaceGui") or Instance.new("ScreenGui"))
			v57.Name = "VRBlurScreen"
			v57.Parent = p49.PlayerGui
			v57.Adornee = v51
			v56 = Instance.new("ImageLabel")
			v56.Name = "VRBlur"
			v56.Parent = v57
			v56.Image = "rbxasset://textures/ui/VR/edgeBlur.png"
			v56.AnchorPoint = Vector2.new(0.5, 0.5)
			v56.Position = UDim2.new(0.5, 0, 0.5, 0)
			local v58 = workspace.CurrentCamera.ViewportSize.X * 2.3 / 512
			local v59 = workspace.CurrentCamera.ViewportSize.Y * 2.3 / 512
			v56.Size = UDim2.fromScale(v58, v59)
			v56.BackgroundTransparency = 1
			v56.Active = true
			v56.ScaleType = Enum.ScaleType.Stretch
		end
		v56.Visible = true
		v56.ImageTransparency = 0
		p48.VREdgeBlurTimer = 0.14
	end
end
function v_u_9.UpdateEdgeBlur(p60, p61, p62) -- name: UpdateEdgeBlur
	local v63 = p61.PlayerGui:FindFirstChild("VRBlurScreen")
	local v64
	if v63 then
		v64 = v63:FindFirstChild("VRBlur")
	else
		v64 = nil
	end
	if v64 then
		if p60.VREdgeBlurTimer > 0 then
			p60.VREdgeBlurTimer = p60.VREdgeBlurTimer - p62
			local v65 = p61.PlayerGui:FindFirstChild("VRBlurScreen")
			local v66 = v65 and v65:FindFirstChild("VRBlur")
			if v66 then
				local v67 = p60.VREdgeBlurTimer
				v66.ImageTransparency = 1 - math.clamp(v67, 0.01, 0.14) * 7.142857142857142
				return
			end
		else
			v64.Visible = false
		end
	end
end
function v_u_9.GetCameraHeight(p68) -- name: GetCameraHeight
	return p68.inFirstPerson and 0 or 0.25881904510252074 * p68.currentSubjectDistance
end
function v_u_9.GetSubjectCFrame(p69) -- name: GetSubjectCFrame
	-- upvalues: (copy) v_u_8
	local v70 = v_u_8.GetSubjectCFrame(p69)
	local v71 = workspace.CurrentCamera
	if v71 then
		v71 = v71.CameraSubject
	end
	if not v71 then
		return v70
	end
	if v71:IsA("Humanoid") and (v71:GetState() == Enum.HumanoidStateType.Dead and v71 == p69.lastSubject) then
		v70 = p69.lastSubjectCFrame
	end
	if v70 then
		p69.lastSubjectCFrame = v70
	end
	return v70
end
function v_u_9.GetSubjectPosition(p72) -- name: GetSubjectPosition
	-- upvalues: (copy) v_u_8
	local v73 = v_u_8.GetSubjectPosition(p72)
	local v74 = game.Workspace.CurrentCamera
	if v74 then
		v74 = v74.CameraSubject
	end
	if not v74 then
		return nil
	end
	if v74:IsA("Humanoid") then
		if v74:GetState() == Enum.HumanoidStateType.Dead and v74 == p72.lastSubject then
			v73 = p72.lastSubjectPosition
		end
	elseif v74:IsA("VehicleSeat") then
		v73 = v74.CFrame.p + v74.CFrame:vectorToWorldSpace(Vector3.new(0, 4, 0))
	end
	p72.lastSubjectPosition = v73
	return v73
end
function v_u_9.getRotation(p75, p76) -- name: getRotation
	-- upvalues: (copy) v_u_5, (copy) v_u_4
	local v77 = v_u_5.getRotation(p76)
	local v78 = 0
	if v_u_4.VRSmoothRotationEnabled then
		return v77.X
	end
	local v79 = v77.X
	if math.abs(v79) > 0.03 then
		if p75.stepRotateTimeout > 0 then
			p75.stepRotateTimeout = p75.stepRotateTimeout - p76
		end
		if p75.stepRotateTimeout <= 0 then
			local v80 = (v77.X < 0 and -1 or 1) * 0.5235987755982988
			p75:StartFadeFromBlack()
			p75.stepRotateTimeout = 0.25
			return v80
		end
	else
		local v81 = v77.X
		if math.abs(v81) < 0.02 then
			p75.stepRotateTimeout = 0
		end
	end
	return v78
end
function v_u_9.HandleSubjectDistance(p82, p83) -- name: HandleSubjectDistance
	if p83 and (p83.IsInFirstPerson and p83:IsInFirstPerson()) then
		p82:SetCameraToSubjectDistance(0)
	end
end
return v_u_9