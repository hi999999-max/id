-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Hiromi.Base.JusticeServedController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "JusticeServedController"
})
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_6, (copy) v_u_3, (ref) v_u_11, (copy) v_u_7, (copy) v_u_2, (copy) v_u_4, (copy) v_u_8, (copy) v_u_9, (ref) v_u_10
	local v_u_86 = {
		["Expand"] = function(p13, p14, p15, p16)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_11, (ref) v_u_7, (ref) v_u_2
			local v17 = p13:FindFirstChild("HumanoidRootPart")
			if v17 then
				local v_u_18 = v_u_6.Hiromi.GavelExpand:Clone()
				v_u_18.Weld.Part0 = p14
				v_u_18.Parent = p14.Extensions
				if not p16 then
					local v_u_19 = v_u_6.Hiromi.CombatTrail:Clone()
					v_u_19.Weld.Part0 = v_u_18.Core
					v_u_19.Weld.C1 = CFrame.new(0, 0, 0)
					v_u_19.Parent = v_u_18
					v_u_19.Transparency = 1
					v_u_19.Trail.Enabled = false
					task.delay(0.2, function()
						-- upvalues: (ref) v_u_3, (copy) v_u_19
						v_u_3:Create(v_u_19, TweenInfo.new(0.2), {
							["Transparency"] = 0.5
						}):Play()
						v_u_19.Trail.Enabled = true
						task.wait(0.4)
						v_u_19.Trail.Enabled = false
						v_u_3:Create(v_u_19, TweenInfo.new(0.3), {
							["Transparency"] = 1
						}):Play()
					end)
				end
				for v20 = 1, 20 do
					task.delay(v20 * 0.0375, function()
						-- upvalues: (copy) v_u_18
						local v21 = v_u_18
						local v22 = v_u_18:GetScale()
						v21:ScaleTo((math.lerp(v22, 4.75, 0.2)))
					end)
				end
				task.wait(0.3)
				v_u_11:PlaySound(v_u_7.Hiromi.HeavySwing, v17, game.SoundService.Effect)
				local v23 = tick()
				if tick() > v23 + 0.05 and p16 then
					local v24 = v_u_6.Itadori.Shock:Clone()
					v24.CFrame = p14.CFrame
					v24.Transparency = 0.3
					v24.Parent = workspace.Effects
					v_u_3:Create(v24, TweenInfo.new(0.15), {
						["Size"] = Vector3.new(20, 0, 20),
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v24, 0.15)
					v23 = tick()
				end
				task.wait()
				if p15 and p15.Parent then
					continue
				end
				for v25 = 1, 20 do
					task.delay(v25 * 0.015, function()
						-- upvalues: (copy) v_u_18
						local v26 = v_u_18
						local v27 = v_u_18:GetScale()
						v26:ScaleTo((math.lerp(v27, 0.5, 0.15)))
					end)
				end
				v_u_2:AddItem(v_u_18, 0.3)
			end
		end,
		["Crush"] = function(p28, p29, p30)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v31 = v_u_6.Hiromi.Shockwave:Clone()
			v31.Position = p29
			v31.Parent = workspace.Effects
			local v32 = v31.CFrame
			local v33 = CFrame.Angles
			local v34 = math.random(-179, 179)
			v31.CFrame = v32 * v33(0, math.rad(v34), 0)
			v_u_3:Create(v31.mesh.Mesh, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
				["Scale"] = Vector3.new(15, 0, 15)
			}):Play()
			v_u_3:Create(v31.mesh.Decal, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
				["Transparency"] = 1
			}):Play()
			v31.Floor.Glow:Emit(1)
			v31.Floor.Ring:Emit(10)
			v_u_2:AddItem(v31, 1.5)
			local v35 = v_u_6.Choso.CounterSwing.Shock:Clone()
			v35.Size = Vector3.new(10, 30, 10)
			v35.CFrame = CFrame.new(p29)
			v35.Parent = workspace.Effects
			v_u_2:AddItem(v35, 0.3)
			v_u_3:Create(v35, TweenInfo.new(0.3), {
				["Size"] = Vector3.new(36, 7, 36),
				["Transparency"] = 1,
				["Position"] = nil,
				["Position"] = v35.Position - Vector3.new(0, 3, 0)
			}):Play()
			local v36 = v_u_6.Choso.CounterSwing.Shock:Clone()
			v36.Size = Vector3.new(20, 10, 20)
			v36.CFrame = CFrame.new(p29)
			v36.Parent = workspace.Effects
			v_u_2:AddItem(v36, 0.2)
			v_u_3:Create(v36, TweenInfo.new(0.2), {
				["Size"] = Vector3.new(0, 36, 0),
				["Transparency"] = 1,
				["Position"] = nil,
				["Position"] = v36.Position + Vector3.new(0, 10, 0)
			}):Play()
			v_u_11:DustBreak(p29 + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
			v_u_11:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Break, v31, game.SoundService.Effect)
			v_u_11:PlaySound(v_u_7.Hakari.Impact, v31, game.SoundService.Effect)
			if p30 and v_u_4 == p28 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
			end
		end,
		["Hit2"] = function(p37, p38)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v39 = p38:FindFirstChild("HumanoidRootPart")
			if v39 then
				v_u_11:Flash(p38, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Megumi.Elephant.Hit, v39, game.SoundService.Effect)
				if v_u_4 == p37 or v_u_4.Character == p38 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["FinalHit"] = function(p40, p41)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v42 = p41:FindFirstChild("HumanoidRootPart")
			if v42 then
				v_u_11:Flash(p41, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Megumi.Elephant.Hit, v42, game.SoundService.Effect)
				if v_u_4 == p40 or v_u_4.Character == p41 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Jump"] = function(p43, p44, p45)
			-- upvalues: (ref) v_u_4, (ref) v_u_3
			local v46 = p44.Parent.Parent:FindFirstChild("HumanoidRootPart")
			if v46 then
				local v47 = p45 * 5
				if v_u_4.Character == v46.Parent then
					local v48 = v47 - Vector3.new(0, 1.5, 0)
					v_u_3:Create(p44, TweenInfo.new(0.5), {
						["P"] = 50000
					}):Play()
					repeat
						p44.Position = p43.Position - v48
						v46.CFrame = CFrame.lookAlong(v46.Position, v48)
						task.wait()
					until not (p44.Parent and p43)
				else
					repeat
						local v49 = CFrame.lookAlong(p43.Position, v47) - v47
						v46.CFrame = v46.CFrame:Lerp(v49, 0.075)
						task.wait()
					until not (p44.Parent and p43)
				end
			end
		end,
		["Finisher"] = function(p50, p51)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v52 = p51:FindFirstChild("HumanoidRootPart")
			if v52 then
				if p51.Parent then
					local v53
					if p51.Torso.Transparency == 0 and p51.Head.Transparency == 1 then
						v53 = not p51:GetAttribute("Woah")
					else
						v53 = false
					end
					v_u_11:PlaySound(v_u_7.Itadori.Dismantle.Explode, v52, game.SoundService.Effect)
					v_u_11:PlaySound(v_u_7.Megumi.Elephant.Explode, v52, game.SoundService.Effect)
					for _, v54 in p51:GetDescendants() do
						if not (v54:IsA("BasePart") or v54:IsA("Decal")) then
							continue
						end
						v54.Transparency = 1
					end
					for _ = 1, 50 do
						v_u_9:Blood(v52.CFrame, 200, 360, 360)
					end
					if _G.Settings.Gore then
						local v55 = v_u_6.Heian.BloodSpread:Clone()
						v55.Parent = p51.Head
						v55:Emit(20)
						v_u_2:AddItem(v55, 2)
					end
					for _ = 1, 20 do
						local v_u_56 = v_u_6.Damage.Chunk:Clone()
						v_u_56.CFrame = v52.CFrame
						v_u_56.CollisionGroup = "Effects"
						local v57 = math.random(-90, 90)
						local v58 = math.random(20, 50)
						local v59 = math.random
						v_u_56.Velocity = Vector3.new(v57, v58, v59(-90, 90))
						local v60 = math.random(-200, 200)
						local v61 = math.random(-200, 200)
						local v62 = math.random
						v_u_56.RotVelocity = Vector3.new(v60, v61, v62(-200, 200))
						v_u_56.Parent = workspace.Effects
						v_u_2:AddItem(v_u_56, 3)
						task.delay(0.1, function()
							-- upvalues: (copy) v_u_56, (ref) v_u_3
							v_u_56.CanCollide = true
							task.wait(1.9)
							v_u_3:Create(v_u_56, TweenInfo.new(1), {
								["Size"] = Vector3.new(0, 0, 0)
							}):Play()
							v_u_56.Blood.Enabled = false
							v_u_56.Trail.Enabled = false
						end)
						if _G.Settings.Gore ~= false then
							continue
						end
						v_u_56.Color = Color3.fromRGB(255, 85, 255)
						v_u_56.Trail.Color = ColorSequence.new(Color3.fromRGB(255, 85, 255))
						v_u_56.Blood.Color = v_u_56.Trail.Color
					end
					if v_u_4:DistanceFromCharacter(v52.Position) < 40 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
					end
					p51:SetAttribute("Woah", true)
					if v53 and (v_u_4.Character == p51 or v_u_4 == p50) then
						v_u_11:PlaySound(v_u_7.Todo.Boom, workspace, game.SoundService.Effect)
						local v63 = v_u_6.Todo.Woah:Clone()
						v63.ImageLabel.Image = "rbxassetid://16726446989"
						v63.Parent = v_u_4.PlayerGui
						v_u_2:AddItem(v63, 1)
						v_u_3:Create(v63.ImageLabel, TweenInfo.new(1), {
							["ImageTransparency"] = 1
						}):Play()
					end
				end
			else
				return
			end
		end,
		["BangEmoteFinisher"] = function(p64, p65)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v66 = p64:FindFirstChild("HumanoidRootPart")
			if v66 then
				v_u_11:PlaySound(v_u_7.Itadori.Dismantle.Explode, v66, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Megumi.Elephant.Explode, v66, game.SoundService.Effect)
				local v67 = { "Torso", "Left Arm", "Right Arm" }
				for _, v68 in pairs(p64:GetDescendants()) do
					if table.find(v67, v68.Name) then
						v68.Transparency = 1
					end
					if not v68:IsA("Accessory") then
						continue
					end
					local v69 = v68:FindFirstChild("Handle")
					if v69 then
						v69 = v69:FindFirstChildOfClass("Attachment")
					end
					if not v69 then
						continue
					end
					for _, v70 in pairs({
						"Neck",
						"Back",
						"Front",
						"Shoulder",
						"Waist"
					}) do
						if not string.find(v69.Name, v70) then
							continue
						end
						v70:Destroy()
					end
				end
				for _ = 1, 50 do
					v_u_9:Blood(CFrame.lookAt(v66.Position, v66.Position + p65), 200, 40, 40)
				end
				if _G.Settings.Gore then
					local v71 = v_u_6.Heian.BloodSpread:Clone()
					v71.Parent = p64.Head
					v71:Emit(20)
					v_u_2:AddItem(v71, 2)
				end
				for _ = 1, 20 do
					local v_u_72 = v_u_6.Damage.Chunk:Clone()
					v_u_72.CFrame = v66.CFrame
					v_u_72.CollisionGroup = "Effects"
					local v73 = p65 * 10
					local v74 = math.random(-5, 5)
					local v75 = math.random(5, 15)
					local v76 = math.random
					v_u_72.Velocity = v73 + Vector3.new(v74, v75, v76(-5, 5))
					local v77 = math.random(-200, 200)
					local v78 = math.random(-200, 200)
					local v79 = math.random
					v_u_72.RotVelocity = Vector3.new(v77, v78, v79(-200, 200))
					v_u_72.Parent = workspace.Effects
					v_u_2:AddItem(v_u_72, 3)
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_72, (ref) v_u_3
						v_u_72.CanCollide = true
						task.wait(1.9)
						v_u_3:Create(v_u_72, TweenInfo.new(1), {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
						v_u_72.Blood.Enabled = false
						v_u_72.Trail.Enabled = false
					end)
					if _G.Settings.Gore ~= false then
						continue
					end
					v_u_72.Color = Color3.fromRGB(255, 85, 255)
					v_u_72.Trail.Color = ColorSequence.new(Color3.fromRGB(255, 85, 255))
					v_u_72.Blood.Color = v_u_72.Trail.Color
				end
				if v_u_4:DistanceFromCharacter(v66.Position) < 40 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["Hyah"] = function(p80)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v81 = p80:FindFirstChild("HumanoidRootPart")
			if v81 then
				v_u_11:PlaySound(v_u_7.MeiMei.UpdraftSlash, v81, game.SoundService.Effect)
				local v82 = v_u_6.Ryu.Slash:Clone()
				v82:ScaleTo(1.7)
				v82.Weld.Part0 = v81
				v82.Weld.C0 = CFrame.Angles(0, 0, 0.6108652381980153)
				v82.Weld.C1 = CFrame.Angles(0, -1.5707963267948966, 0)
				v82.Parent = workspace.Effects
				v_u_2:AddItem(v82, 0.15)
				local v83 = TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
				local v84 = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				v_u_3:Create(v82.Weld, v83, {
					["C1"] = v82.Weld.C1 * CFrame.Angles(0, -1.7453292519943295, 0)
				}):Play()
				for _, v85 in v82:GetDescendants() do
					if v85:IsA("Decal") then
						v85.Color3 = Color3.fromRGB(455, 255, 127)
						v_u_3:Create(v85, v84, {
							["Transparency"] = 1
						}):Play()
					else
						if not v85:IsA("SpecialMesh") then
							continue
						end
						v_u_3:Create(v85, v83, {
							["Scale"] = v85.Scale * 1.2
						}):Play()
					end
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p87, ...)
		-- upvalues: (copy) v_u_86
		local v88 = v_u_86[p87]
		if v88 then
			v88(...)
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("JusticeServedService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12