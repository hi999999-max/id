-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Reggie.Base.GarageSaleController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "GarageSaleController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_2, (copy) v_u_4, (copy) v_u_5, (copy) v_u_9, (ref) v_u_10
	local v_u_47 = {
		["Start"] = function(p14)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_12:PlaySound(v_u_8.Reggie.GarageSaleFire, v15, game.SoundService.Effect)
			end
		end,
		["Interp"] = function(p16, p_u_17)
			-- upvalues: (ref) v_u_7, (ref) v_u_12, (ref) v_u_3, (ref) v_u_8, (ref) v_u_2
			local v18 = p16:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = v_u_7.Reggie.ReceiptBurn:Clone()
				v19.Parent = workspace.Effects
				v19.Anchored = true
				v19.CFrame = p16:FindFirstChild("ReceiptStack") and p16.ReceiptStack.CFrame or p_u_17.CFrame
				v_u_12:PlayParticles(v19)
				v_u_3:AddItem(v19, 3)
				local v20 = v18.CFrame * CFrame.new(0, 1, 0)
				if p_u_17.Name == "Fridge" then
					local v21 = v_u_7.Itadori.DivergentFist.BlackFlashLaunch:Clone()
					local v22 = Instance.new("Model")
					v21.Parent = v22
					v22:ScaleTo(0.8)
					v_u_3:AddItem(v22, 0.2)
					v21.CFrame = v20 * CFrame.new(0, 0, -6)
					v21.Parent = workspace.Effects
					v21.Wind.Lifetime = NumberRange.new(0.4, 1)
					v21.Wind:Emit(20)
					v21.PointLight:Destroy()
					v_u_12:PlaySound(v_u_8.Reggie.CouponBurn, v18, game.SoundService.Effect)
				end
				local v23 = v_u_7.Itadori.DivergentFist.BlackFlashLaunch:Clone()
				local v24 = Instance.new("Model")
				v23.Parent = v24
				v24:ScaleTo(0.3)
				v_u_3:AddItem(v24, 0.2)
				v23.CFrame = v20 * CFrame.new(0, 0, -math.random(4, 16))
				v23.Parent = workspace.Effects
				v23.Wind:Emit(2)
				v23.PointLight:Destroy()
				v23.Wind.Lifetime = NumberRange.new(0.25, 0.8)
				v23.Back1.Back.Size = NumberSequence.new(0)
				v23.Back2.Back.Size = NumberSequence.new(0)
				v_u_3:AddItem(v23, 3)
				local v_u_25 = p_u_17.CFrame
				local v_u_26 = tick()
				local v_u_27 = p_u_17:GetPropertyChangedSignal("Position"):Connect(function()
					-- upvalues: (ref) v_u_25, (copy) p_u_17, (ref) v_u_26
					v_u_25 = p_u_17.CFrame
					v_u_26 = tick()
				end)
				local v_u_28 = nil
				v_u_28 = v_u_2.Stepped:Connect(function()
					-- upvalues: (copy) p_u_17, (ref) v_u_28, (copy) v_u_27, (ref) v_u_25, (ref) v_u_26
					if p_u_17.Parent and p_u_17:GetAttribute("Speed") ~= nil then
						workspace:BulkMoveTo({ p_u_17 }, { v_u_25 + v_u_25.LookVector * (p_u_17:GetAttribute("Speed") * (tick() - v_u_26)) }, Enum.BulkMoveMode.FireCFrameChanged)
					else
						v_u_28:Disconnect()
						v_u_27:Disconnect()
					end
				end)
			end
		end,
		["Break"] = function(p29)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8, (ref) v_u_12
			for _ = 1, 3 do
				local v_u_30 = v_u_7.Hiromi.GavelShard:Clone()
				local v31 = p29.CFrame
				local v32 = CFrame.new
				local v33 = (math.random() - 0.5) * p29.Size.X
				local v34 = (math.random() - 0.5) * p29.Size.Y
				local v35 = (math.random() - 0.5) * p29.Size.Z
				v_u_30.Position = (v31 * v32((Vector3.new(v33, v34, v35)))).Position
				v_u_30.Size = v_u_30.Size * (p29.Size.Magnitude / 5)
				v_u_30.Color = p29.Color
				local v36 = math.random(-50, 50)
				local v37 = math.random(-50, 50)
				local v38 = math.random
				v_u_30.Velocity = Vector3.new(v36, v37, v38(-50, 50))
				local v39 = math.random(-50, 50)
				local v40 = math.random(-50, 50)
				local v41 = math.random
				v_u_30.RotVelocity = Vector3.new(v39, v40, v41(-50, 50))
				v_u_30.Parent = workspace.Effects
				v_u_3:AddItem(v_u_30, 2)
				task.delay(1, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_30
					v_u_4:Create(v_u_30, TweenInfo.new(1), {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
				end)
			end
			local v42 = v_u_8.Reggie.GarageSale:GetChildren()[math.random(1, #v_u_8.Reggie.GarageSale:GetChildren())]
			if p29.Name == "Fridge" then
				v42 = v_u_8.Reggie["Metal" .. math.random(1, 2)]
			end
			local v43 = v_u_12:PlaySound(v42, p29, game.SoundService.Effect)
			v43:Stop()
			v43.PlayOnRemove = true
			v43:Destroy()
		end,
		["Hit"] = function(p44, p45, p46, _)
			-- upvalues: (ref) v_u_12, (ref) v_u_5, (ref) v_u_9
			if p44:FindFirstChild("HumanoidRootPart") then
				if p45:FindFirstChild("HumanoidRootPart") then
					v_u_12:Flash(p45, Color3.new(1, 1, 1))
					if v_u_5.Character == p44 or v_u_5.Character == p45 then
						v_u_9.CurrentShaker:Shake(p46 and v_u_9.Presets.HeavyHit or v_u_9.Presets.LightHit)
					end
				end
			else
				return
			end
		end
	}
	v_u_10.Effects:Connect(function(p48, ...)
		-- upvalues: (copy) v_u_47
		local v49 = v_u_47[p48]
		if v49 then
			v49(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("GarageSaleService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13