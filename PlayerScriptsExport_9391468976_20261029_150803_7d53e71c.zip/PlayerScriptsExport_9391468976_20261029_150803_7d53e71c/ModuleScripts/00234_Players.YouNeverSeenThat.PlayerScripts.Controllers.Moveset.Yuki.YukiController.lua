-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Yuki.YukiController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "YukiController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2, (ref) v_u_10
	local v_u_114 = {
		["Hit"] = function(p14, p15)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v16 = p14:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_12:Flash(p14, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit" .. p15), v16, game.SoundService.Effect)
			end
		end,
		["ChaseHit"] = function(p17, p18)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v19 = p17:FindFirstChild("HumanoidRootPart")
			if v19 then
				local v20 = p18:FindFirstChild("HumanoidRootPart")
				if v20 then
					v_u_12:Flash(p18, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit3"), v20, game.SoundService.Effect)
					local v21 = v_u_7.ChaseHit:Clone()
					local v22 = CFrame.new
					local v23 = v20.Position
					local v24 = v19.Position.X
					local v25 = v20.Position.Y
					local v26 = v19.Position.Z
					v21.CFrame = v22(v23, (Vector3.new(v24, v25, v26))) * CFrame.Angles(0, 3.141592653589793, 0)
					v21.Parent = workspace.Effects
					v21.Ring:Emit(7)
					v21.Sparks:Emit(12)
					v_u_3:AddItem(v21, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p27)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8
			local v28 = p27.HumanoidRootPart
			if v28 then
				local v29 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v29.CFrame = v28.CFrame * CFrame.new(0, 1, -4)
				v29.Size = Vector3.new(0, 0, 2)
				v29.Parent = workspace.Effects
				v_u_4:Create(v29, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v29, 0.3)
				v_u_12:PlaySound(v_u_8.Misc.Chase, v28, game.SoundService.Effect)
				v_u_12:DustTrail(p27, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p30)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v31 = p30:FindFirstChild("HumanoidRootPart")
			if v31 then
				v_u_12:PlaySound(v_u_8.Misc.Swing.Fist, v31, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p32, p33, p34)
			-- upvalues: (ref) v_u_12
			if p34 == "Down" or p33 == 4 and not p34 then
				v_u_12:ArmFlash(p32["Right Leg"], Color3.fromRGB(255, 85, 255), 0.4)
				return
			elseif p34 == "Up" and p33 == 4 or p33 == 1 then
				v_u_12:ArmFlash(p32["Left Arm"], Color3.fromRGB(255, 85, 255), 0.3)
				return
			elseif p33 == 2 then
				v_u_12:ArmFlash(p32["Right Arm"], Color3.fromRGB(255, 85, 255), 0.3)
				return
			elseif p33 == 3 then
				v_u_12:ArmFlash(p32["Left Leg"], Color3.fromRGB(255, 85, 255), 0.3)
			else
				v_u_12:ArmFlash(p32["Left Arm"], Color3.fromRGB(255, 85, 255), 0.3)
			end
		end,
		["Launch"] = function(p35, p36)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v37 = p35:FindFirstChild("HumanoidRootPart")
			if v37 then
				local v38 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v38.CFrame = CFrame.new(v37.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v38.Size = Vector3.new(0, 0, 5)
				v38.Parent = workspace.Effects
				v_u_4:Create(v38, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v38.Position + Vector3.new(0, p36, 0)
				}):Play()
				v_u_3:AddItem(v38, 0.3)
				if p36 < 0 then
					v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v37, game.SoundService.Effect)
					v_u_12:DustBreak(v37.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v37.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			end
		end,
		["BlackHole"] = function(p_u_39)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9, (ref) v_u_4, (ref) v_u_2, (ref) v_u_5
			if p_u_39 then
				local v_u_40 = p_u_39.Position
				local v_u_41 = v_u_7.Yuki.BlackHole2:Clone()
				v_u_41.Position = v_u_40
				v_u_41.DustCollect.Position = v_u_40
				v_u_41.Parent = workspace.Effects
				v_u_3:AddItem(v_u_41, 7)
				local v42 = Instance.new("Highlight", v_u_41)
				v42.FillColor = Color3.new(0, 0, 0)
				v42.FillTransparency = 0
				v42.OutlineTransparency = 1
				v42.DepthMode = Enum.HighlightDepthMode.Occluded
				v_u_12:PlaySound(v_u_8.Yuki.Hole.Hole, v_u_41, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v_u_40).Magnitude < 150 then
					v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(2)
				end
				local v_u_43 = nil
				local v_u_44 = false
				local v_u_45 = TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
				task.delay(3.8, function()
					-- upvalues: (ref) v_u_43, (ref) v_u_44, (ref) v_u_4, (copy) v_u_45
					v_u_43:Disconnect()
					if v_u_44 == true then
						v_u_44 = false
						v_u_4:Create(workspace.CurrentCamera, v_u_45, {
							["FieldOfView"] = 70
						}):Play()
					end
				end)
				v_u_43 = v_u_2.Stepped:Connect(function(_, p46)
					-- upvalues: (copy) p_u_39, (ref) v_u_40, (copy) v_u_41, (ref) v_u_5, (ref) v_u_44, (ref) v_u_4, (copy) v_u_45, (ref) v_u_9
					if p_u_39 and p_u_39.Parent then
						v_u_40 = p_u_39.Position
						v_u_41.Position = v_u_40
						v_u_41.DustCollect.Position = v_u_40
					end
					local v47 = v_u_5.Character
					if v47 then
						local v48 = v47:FindFirstChild("HumanoidRootPart")
						if v48 then
							local v49 = (v48.Position - v_u_40).Magnitude
							if v49 > 100 then
								if v_u_44 == true then
									v_u_44 = false
									v_u_4:Create(workspace.CurrentCamera, v_u_45, {
										["FieldOfView"] = 70
									}):Play()
								end
							else
								if v_u_44 == false then
									v_u_44 = true
									v_u_4:Create(workspace.CurrentCamera, v_u_45, {
										["FieldOfView"] = 120
									}):Play()
								end
								local v50 = v49 / 100
								local v51 = 1 - math.clamp(v50, 0, 1)
								local v52 = CFrame.lookAt(v48.Position, v_u_40)
								if v47.Humanoid.FloorMaterial == Enum.Material.Air then
									v48.AssemblyLinearVelocity = v48.AssemblyLinearVelocity + v52.LookVector * (v51 * 300 * p46)
								else
									v48.AssemblyLinearVelocity = v48.AssemblyLinearVelocity + v52.LookVector * (v51 * 2000 * p46)
								end
								v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightLoop)
							end
						else
							return
						end
					else
						return
					end
				end)
				v_u_4:Create(v_u_41, TweenInfo.new(2.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(20, 20, 20)
				}):Play()
				task.wait(2.5)
				v_u_4:Create(v_u_41, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
					["Size"] = Vector3.new(0, 0, 0)
				}):Play()
				task.wait(1.3)
				for _, v53 in v_u_41.DustCollect:GetChildren() do
					v53.Enabled = false
				end
				task.wait(0.1)
				for _, v54 in v_u_41.Absorb:GetChildren() do
					v54.Enabled = false
				end
				task.wait(0.1)
				v_u_41.Clear.Dust:Emit(100)
				v_u_41.Clear.Ring:Emit(20)
				if (workspace.CurrentCamera.CFrame.Position - v_u_40).Magnitude < 150 then
					v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(1.5)
					game.Lighting.ExposureCompensation = 2
					v_u_4:Create(game.Lighting, TweenInfo.new(1), {
						["ExposureCompensation"] = 0
					}):Play()
				end
			end
		end,
		["Absorbed"] = function(p55)
			-- upvalues: (ref) v_u_4
			if p55:FindFirstChild("HumanoidRootPart") then
				local v56 = TweenInfo.new(0.5)
				for _, v57 in p55:GetDescendants() do
					if not (v57:IsA("BasePart") or v57:IsA("Decal")) then
						continue
					end
					v_u_4:Create(v57, v56, {
						["Transparency"] = 1
					}):Play()
				end
			end
		end,
		["OhNo"] = function(p58)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v_u_59 = p58:FindFirstChild("HumanoidRootPart")
			if v_u_59 then
				v_u_12:PlaySound(v_u_8.Yuki.Scream, v_u_59, game.SoundService.Voice)
				v_u_12:PlaySound(v_u_8.Itadori.Rush.Rush, v_u_59, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_8.Hakari.EnergySurge.Teleport, v_u_59, game.SoundService.Effect)
				for v60 = 1, 10 do
					task.delay(v60 * 0.075, function()
						-- upvalues: (ref) v_u_7, (copy) v_u_59, (ref) v_u_4, (ref) v_u_3
						local v61 = v_u_7.Itadori.Shock:Clone()
						v61.CFrame = CFrame.lookAlong(v_u_59.Position, v_u_59.Velocity) * CFrame.Angles(1.5707963267948966, 0, 0)
						v61.Transparency = 0.3
						v61.Parent = workspace.Effects
						v_u_4:Create(v61, TweenInfo.new(0.15), {
							["Size"] = Vector3.new(20, 0, 20),
							["Transparency"] = 1
						}):Play()
						v_u_3:AddItem(v61, 0.15)
					end)
				end
				if v_u_5.Character == p58 then
					task.spawn(function()
						-- upvalues: (copy) v_u_59
						local v62 = workspace.CurrentCamera
						local v63 = tick() + 0.5
						repeat
							v_u_59.Velocity = v62.CFrame.LookVector * 100
							task.wait()
						until v63 < tick()
					end)
				end
				if (workspace.CurrentCamera.CFrame.Position - v_u_59.Position).Magnitude < 150 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end,
		["OhNo2"] = function(p64, p65, p66)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_9, (ref) v_u_5, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			local v67 = p64:FindFirstChild("HumanoidRootPart")
			if v67 then
				local v68 = p65:FindFirstChild("HumanoidRootPart")
				if v68 then
					v_u_12:Flash(p65, Color3.new(1, 1, 1), 2)
					v_u_12:PlaySound(v_u_8.Gojo.LapseBlue.Grab, v68, game.SoundService.Effect).Volume = 5
					v_u_12:PlaySound(v_u_8.Yuki.Grab, v68, game.SoundService.Effect)
					if (workspace.CurrentCamera.CFrame.Position - v68.Position).Magnitude < 200 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
					end
					local v69 = v_u_5.Character == p64 and true or v_u_5.Character == p65
					local v70 = v_u_12:PlaySound(v_u_8.Yuki.GrabOST, v67, game.SoundService.Music)
					local v71
					if v69 then
						v71 = v_u_7.Hakari.IdleDeath.AudioVis:Clone()
						v71.Beat.ImageColor3 = Color3.new(0, 0, 0)
						v71.Beat.ImageTransparency = 1
						v71.Parent = v_u_5.PlayerGui
					else
						v71 = nil
					end
					local v72
					if v_u_5.Character == p65 then
						v72 = v_u_7.Yuki.Buildup:Clone()
						v72.Parent = p64.Torso
						v_u_4:Create(v72.BG, TweenInfo.new(0.2), {
							["BackgroundTransparency"] = 0.5
						}):Play()
						v_u_4:Create(v72.Bar.Bar, TweenInfo.new(0.2), {
							["BackgroundTransparency"] = 0
						}):Play()
					else
						v72 = nil
					end
					local v73 = (p64:GetAttribute("Charge") or 0) / 100
					if v71 then
						v71.Beat.ImageTransparency = 1 - v73
						v71.Beat.Size = UDim2.new(2, 0, 2, 0):Lerp(UDim2.new(1, 0, 1, 0), v73)
					end
					if v72 then
						v72.Bar.Size = UDim2.new(1, 0, v73, 0)
						v72.Bar.Bar.Size = UDim2.new(1, 0, 1 / v73, 0)
					end
					if v69 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightLoop)
					end
					task.wait()
					if p64.Parent and (p65.Parent and p66:IsDescendantOf(workspace.Characters)) then
						continue
					end
					if (p64:GetAttribute("Charge") or 0) >= 100 then
						v_u_3:AddItem(v70, 6)
						v_u_4:Create(v70, TweenInfo.new(6, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
							["Volume"] = 0
						}):Play()
					else
						v_u_3:AddItem(v70, 1)
						v_u_4:Create(v70, TweenInfo.new(1), {
							["Volume"] = 0
						}):Play()
					end
					if v71 then
						v_u_4:Create(v71.Beat, TweenInfo.new(0.5), {
							["ImageTransparency"] = 1
						}):Play()
						v_u_3:AddItem(v71, 0.5)
					end
					if v72 then
						v_u_4:Create(v72.BG, TweenInfo.new(0.4), {
							["BackgroundTransparency"] = 1
						}):Play()
						v_u_4:Create(v72.Bar.Bar, TweenInfo.new(0.4), {
							["BackgroundTransparency"] = 1
						}):Play()
						v_u_3:AddItem(v72, 0.4)
					end
				end
			else
				return
			end
		end,
		["Buildup"] = function(p_u_74, p75)
			-- upvalues: (ref) v_u_5, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8
			local v76 = p_u_74:FindFirstChild("HumanoidRootPart")
			if v76 then
				if v_u_5.Character == p_u_74 then
					task.spawn(function()
						-- upvalues: (ref) v_u_7, (copy) p_u_74, (ref) v_u_4, (ref) v_u_3
						local v77 = v_u_7.Yuki.Buildup:Clone()
						v77.Parent = p_u_74.Torso
						v_u_4:Create(v77.BG, TweenInfo.new(0.2), {
							["BackgroundTransparency"] = 0.5
						}):Play()
						v_u_4:Create(v77.Bar.Bar, TweenInfo.new(0.2), {
							["BackgroundTransparency"] = 0
						}):Play()
						repeat
							local v78 = (p_u_74:GetAttribute("Charge") or 0) / 100
							v77.Bar.Size = UDim2.new(1, 0, v78, 0)
							v77.Bar.Bar.Size = UDim2.new(1, 0, 1 / v78, 0)
							task.wait()
						until not (p_u_74.Parent and p_u_74:GetAttribute("Charging"))
						v_u_4:Create(v77.BG, TweenInfo.new(0.4), {
							["BackgroundTransparency"] = 1
						}):Play()
						v_u_4:Create(v77.Bar.Bar, TweenInfo.new(0.4), {
							["BackgroundTransparency"] = 1
						}):Play()
						v_u_3:AddItem(v77, 0.4)
					end)
				end
				local v79
				if p75 then
					v79 = v_u_7.Yuki.Warp2:Clone()
					v79.Weld.Part0 = v76
					v79.Parent = workspace.Effects
					v_u_4:Create(v79.Start.PointLight, TweenInfo.new(0.5), {
						["Brightness"] = 15
					}):Play()
					local v80 = Instance.new("Highlight", v79)
					v80.FillColor = Color3.fromRGB(103, 88, 135)
					v80.FillTransparency = 1
					v80.OutlineTransparency = 1
					v80.DepthMode = Enum.HighlightDepthMode.Occluded
					v_u_4:Create(v79, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
						["Size"] = Vector3.new(9, 9, 9)
					}):Play()
				else
					v79 = nil
				end
				local v81 = v_u_7.Damage.HitGlow:Clone()
				if p_u_74:GetScale() ~= 1 then
					v81:ScaleTo(p_u_74:GetScale())
				end
				v81.Parent = workspace.Effects
				v_u_3:AddItem(v81, 0.5)
				local v82 = TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
				for _, v83 in v81:GetChildren() do
					local v84 = p_u_74:FindFirstChild(v83.Name)
					if v84 then
						local v85 = Instance.new("Weld", v83)
						v85.Part0 = v83
						v85.Part1 = v84
					end
					v83.Size = v83.Size * 2
					v83.Transparency = 0
					v83.Color = Color3.fromRGB(170, 85, 255)
					v_u_4:Create(v83, v82, {
						["Transparency"] = 1,
						["Size"] = nil,
						["Size"] = v83.Size / 2
					}):Play()
				end
				v_u_12:PlaySound(v_u_8.Yuki.Charge.Start, v76, game.SoundService.Effect)
				if v79 then
					local v86 = (p_u_74:GetAttribute("Charge") or 0) / 100
					local v87 = (workspace.CurrentCamera.CFrame.Position - v79.Position).Magnitude
					v79.Highlight.DepthMode = v87 > 150 and Enum.HighlightDepthMode.Occluded or Enum.HighlightDepthMode.AlwaysOnTop
					v79.Transparency = 1 + 3 * v86
					local v88 = v79.Weld
					local v89 = CFrame.Angles
					local v90 = math.random(0, 360)
					local v91 = math.rad(v90)
					local v92 = math.random(0, 360)
					local v93 = math.rad(v92)
					local v94 = math.random(0, 360)
					v88.C1 = v89(v91, v93, (math.rad(v94)))
					if v86 > 0.66 then
						local v95 = (v86 - 0.66) / 0.3
						local v96 = math.clamp(v95, 0, 1)
						v79.Highlight.FillColor = Color3.fromRGB(103, 88, 135):Lerp(Color3.new(0, 0, 0), v96)
						for _, v97 in v79.Past:GetChildren() do
							v97.Enabled = true
							v97.TimeScale = v86
						end
					elseif v86 > 0.33 then
						local v98 = (v86 - 0.33) / 0.66
						local v99 = math.clamp(v98, 0, 1)
						v79.Start.Spark.Enabled = true
						v79.Past.Absorb.Enabled = true
						v79.Past.Absorb.TimeScale = math.lerp(0, 1, v99)
						v79.Highlight.FillTransparency = math.lerp(1, -5, v99)
					end
				end
				task.wait()
				if p_u_74.Parent and p_u_74:GetAttribute("Charging") then
					continue
				end
				if (p_u_74:GetAttribute("Charge") or 0) >= 100 then
					v_u_12:PlaySound(v_u_8.Yuki.Charge.Finish, v76, game.SoundService.Effect)
				else
					v_u_12:PlaySound(v_u_8.Yuki.Charge.End, v76, game.SoundService.Effect)
				end
				if v79 then
					v_u_3:AddItem(v79, 1.5)
					for _, v100 in v79.Start:GetChildren() do
						if v100:IsA("PointLight") then
							continue
						end
						v100.Enabled = false
					end
					for _, v101 in v79.Past:GetChildren() do
						v101.Enabled = false
					end
					v_u_4:Create(v79.Start.PointLight, TweenInfo.new(0.5), {
						["Brightness"] = 0
					}):Play()
					v_u_4:Create(v79, TweenInfo.new(0.2), {
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v79:FindFirstChildWhichIsA("Highlight"), 0.2)
				end
			end
		end,
		["MeterVis"] = function(p102, p_u_103)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8, (ref) v_u_3
			local v_u_104 = p102:FindFirstChild("HumanoidRootPart")
			if v_u_104 then
				local v105 = v_u_7.Yuki.Meter:Clone()
				v105.Parent = p102.Torso
				local v106 = {}
				for v107 = 1, p_u_103:GetAttribute("Max") do
					local v108 = v_u_7.Yuki.MeterBar:Clone()
					v108.Name = v107
					v108.Parent = v105
					v_u_4:Create(v108, TweenInfo.new(0.2), {
						["BackgroundTransparency"] = 0.5
					}):Play()
					v106[v107] = v108
				end
				local v109 = v_u_7.Yuki.Buildup:Clone()
				v109.Parent = p102.Torso
				v_u_4:Create(v109.BG, TweenInfo.new(0.2), {
					["BackgroundTransparency"] = 0.5
				}):Play()
				v_u_4:Create(v109.Bar.Bar, TweenInfo.new(0.2), {
					["BackgroundTransparency"] = 0
				}):Play()
				v109.Cost.Visible = true
				v109.Cost.Size = UDim2.new(1, 0, p_u_103:GetAttribute("Cost") / 100, 0)
				v_u_4:Create(v109.Cost, TweenInfo.new(0.2), {
					["BackgroundTransparency"] = 0.5
				}):Play()
				p_u_103:GetPropertyChangedSignal("Value"):Connect(function()
					-- upvalues: (copy) p_u_103, (ref) v_u_12, (ref) v_u_8, (copy) v_u_104
					if p_u_103.Value == p_u_103:GetAttribute("Max") then
						v_u_12:PlaySound(v_u_8.Yuki.Charge.ChargeFail, v_u_104, game.SoundService.Effect)
					else
						v_u_12:PlaySound(v_u_8.Yuki.Charge.Charge, v_u_104, game.SoundService.Effect)
					end
				end)
				for v110, v111 in v106 do
					if v110 <= p_u_103.Value then
						v111.Bar.Visible = true
					else
						v111.Bar.Visible = false
					end
				end
				local v112 = (p102:GetAttribute("Charge") or 0) / 100
				v109.Bar.Size = UDim2.new(1, 0, v112, 0)
				v109.Bar.Bar.Size = UDim2.new(1, 0, 1 / v112, 0)
				task.wait()
				if p102.Parent and p_u_103.Parent then
					break
				end
				for _, v113 in v106 do
					v_u_4:Create(v113, TweenInfo.new(0.2), {
						["BackgroundTransparency"] = 1
					}):Play()
					v_u_4:Create(v113.Bar, TweenInfo.new(0.2), {
						["BackgroundTransparency"] = 1
					}):Play()
				end
				v_u_3:AddItem(v105, 0.2)
				v_u_4:Create(v109.BG, TweenInfo.new(0.4), {
					["BackgroundTransparency"] = 1
				}):Play()
				v_u_4:Create(v109.Bar.Bar, TweenInfo.new(0.4), {
					["BackgroundTransparency"] = 1
				}):Play()
				v_u_4:Create(v109.Cost, TweenInfo.new(0.4), {
					["BackgroundTransparency"] = 1
				}):Play()
				v_u_3:AddItem(v109, 0.4)
			end
		end
	}
	v_u_10.Effects:Connect(function(p115, ...)
		-- upvalues: (copy) v_u_114
		local v116 = v_u_114[p115]
		if v116 then
			v116(...)
		end
	end)
	local v_u_117 = Random.new()
	v_u_10.Debree:Connect(function(p118, p_u_119)
		-- upvalues: (copy) v_u_117, (ref) v_u_3, (ref) v_u_12, (ref) v_u_4
		if (workspace.CurrentCamera.CFrame.Position - p_u_119).Magnitude > 200 then
			return
		elseif _G.Settings.DesPHY then
			for _, v120 in p118 do
				local v_u_121 = Instance.new("Part")
				v_u_121.Massless = true
				v_u_121.CollisionGroup = "Effects"
				v_u_121.Position = v120[1]
				v_u_121.Orientation = v120[2]
				v_u_121.Color = v120[3]
				v_u_121.Material = v120[4]
				v_u_121.Size = v120[5]
				v_u_121.Velocity = v_u_117:NextUnitVector() * v_u_117:NextInteger(60, 100)
				local v122 = math.random(-40, 40)
				local v123 = math.random(-40, 40)
				local v124 = math.random
				v_u_121.RotVelocity = Vector3.new(v122, v123, v124(-40, 40))
				v_u_121.Parent = workspace.Effects.CamIgnore
				v_u_3:AddItem(v_u_121, 0.8)
				if math.random(1, 10) == 1 then
					v_u_12:DebreeSound(v_u_121)
				end
				task.delay(0.2, function()
					-- upvalues: (copy) v_u_121, (ref) v_u_4, (copy) p_u_119
					local v125 = Instance.new("Attachment", v_u_121)
					v125.Name = "BlueGrab"
					local v126 = Instance.new("AlignPosition", v125)
					v126.Responsiveness = 0
					v_u_4:Create(v126, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
						["Responsiveness"] = 100
					}):Play()
					v126.Attachment0 = v125
					v126.Mode = Enum.PositionAlignmentMode.OneAttachment
					v126.Position = p_u_119
				end)
			end
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("YukiService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13