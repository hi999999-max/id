-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Uro.SkyDistortionController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "SkyDistortionController"
})
function v11.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_10, (copy) v_u_7, (copy) v_u_6, (copy) v_u_4, (copy) v_u_3, (copy) v_u_2, (copy) v_u_8, (ref) v_u_9
	local v_u_49 = {
		["Startup"] = function(p12)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v13 = p12:FindFirstChild("HumanoidRootPart")
			if v13 then
				v_u_10:PlaySound(v_u_7.Uro.SkyDistortion.Swing, v13, game.SoundService.Effect)
			end
		end,
		["Interp"] = function(p_u_14)
			-- upvalues: (ref) v_u_6, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_2, (ref) v_u_8
			local v_u_15 = p_u_14.CFrame
			local v_u_16 = tick()
			local v_u_17 = p_u_14:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_15, (copy) p_u_14, (ref) v_u_16
				v_u_15 = p_u_14.CFrame
				v_u_16 = tick()
			end)
			local v_u_18 = Instance.new("Model", workspace.Effects)
			local v19 = Instance.new("Highlight")
			v19.FillTransparency = 1
			v19.OutlineTransparency = 1
			v19.Parent = v_u_18
			local v_u_20 = p_u_14.Position + p_u_14.CFrame.LookVector * 4 - p_u_14.CFrame.RightVector * 5 - Vector3.new(0, 2, 0)
			local v_u_21 = v_u_6.Uro.AirDistort2:Clone()
			v_u_21.Parent = v_u_18
			v_u_10:PlaySound(v_u_7.Uro.SkyDistortion.Throw, v_u_21, game.SoundService.Effect)
			local v_u_22 = TweenInfo.new(0.5, Enum.EasingStyle.Back, Enum.EasingDirection.In)
			task.spawn(function()
				-- upvalues: (ref) v_u_6, (copy) p_u_14, (copy) v_u_18, (ref) v_u_4, (ref) v_u_3, (copy) v_u_21, (copy) v_u_22, (copy) v_u_20
				repeat
					local v23 = v_u_6.Uro.Ring:Clone()
					v23.CFrame = p_u_14.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
					v23.Parent = v_u_18
					v23.Attachment.Wind:Emit(2)
					v_u_4:Create(v23, TweenInfo.new(0.5), {
						["Size"] = nil,
						["Transparency"] = 1,
						["Size"] = v23.Size * 2
					}):Play()
					v_u_3:AddItem(v23, 0.5)
					task.wait(0.075)
				until not p_u_14.Parent
				v_u_3:AddItem(v_u_18, 0.5)
				v_u_4:Create(v_u_21, v_u_22, {
					["Size"] = Vector3.new(15, 15, 0),
					["Position"] = nil,
					["Position"] = v_u_20
				}):Play()
			end)
			local v_u_24 = 10
			local v_u_25 = nil
			v_u_25 = v_u_2.Stepped:Connect(function(_, p26)
				-- upvalues: (copy) p_u_14, (ref) v_u_25, (copy) v_u_17, (ref) v_u_15, (ref) v_u_16, (copy) v_u_20, (ref) v_u_24, (copy) v_u_21
				if p_u_14.Parent then
					workspace:BulkMoveTo({ p_u_14 }, { v_u_15 + v_u_15.LookVector * (180 * (tick() - v_u_16)) }, Enum.BulkMoveMode.FireCFrameChanged)
					local v27 = (v_u_20 - p_u_14.Position).Magnitude
					local v28 = CFrame.lookAt(v_u_20, p_u_14.Position)
					local v29 = v_u_24
					local v30 = 2 * p26
					v_u_24 = math.lerp(v29, 2, v30)
					v_u_21.CFrame = v28 + v28.LookVector * (v27 / 2)
					local v31 = v_u_24
					local v32 = v_u_24
					v_u_21.Size = Vector3.new(v31, v32, v27)
				else
					v_u_25:Disconnect()
					v_u_17:Disconnect()
				end
			end)
			p_u_14.Destroying:Connect(function()
				-- upvalues: (copy) p_u_14, (ref) v_u_8, (ref) v_u_10, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (copy) v_u_22
				if (workspace.CurrentCamera.CFrame.Position - p_u_14.Position).Magnitude < 40 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
				v_u_10:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Break, p_u_14, game.SoundService.Effect)
				local v33 = TweenInfo.new(2, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				for _, v34 in p_u_14.Rocks:GetChildren() do
					v34.BlueGrab:Destroy()
					v34.Parent = workspace.Effects
					v_u_3:AddItem(v34, 2)
					v_u_4:Create(v34, v_u_22, {
						["Position"] = v34:GetAttribute("P1"),
						["Orientation"] = v34:GetAttribute("V2")
					}):Play()
					v_u_4:Create(v34, v33, {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
				end
			end)
		end,
		["Crunch"] = function(p35, p36, p37)
			-- upvalues: (ref) v_u_8, (ref) v_u_4
			if p35:FindFirstChild("HumanoidRootPart") then
				local v38 = (workspace.CurrentCamera.CFrame.Position - p36.Position).Magnitude
				if v38 < 40 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
				if v38 <= 75 and (p36.Parent and p36:FindFirstChild("Rocks")) then
					for _, v39 in p37 do
						local v40 = Instance.new("Part")
						v40.CollisionGroup = "Effects"
						v40.Massless = true
						v40.Position = v39[1]
						v40.Orientation = v39[2]
						v40.Color = v39[3]
						v40.Material = v39[4]
						v40.Size = v39[5]
						v40.Transparency = v39[6]
						v40.Parent = p36.Rocks
						v40:SetAttribute("P1", v39[1])
						v40:SetAttribute("P2", v39[2])
						local v41 = Instance.new("Attachment", v40)
						v41.Name = "BlueGrab"
						local v42 = Instance.new("AlignPosition", v41)
						v42.Responsiveness = 30
						v_u_4:Create(v42, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
							["Responsiveness"] = 200
						}):Play()
						v42.Attachment0 = v41
						v42.Attachment1 = p36.Attachment
						local v43 = math.random(-100, 100)
						local v44 = math.random(-100, 100)
						local v45 = math.random
						v40.RotVelocity = Vector3.new(v43, v44, v45(-100, 100))
					end
				end
			else
				return
			end
		end,
		["Hit"] = function(p46)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_8
			local v47 = p46:FindFirstChild("HumanoidRootPart")
			if v47 then
				v_u_10:Flash(p46, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.Ryu.SecondHelping.Hit, v47, game.SoundService.Effect)
				local v48 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v48.Position = v47.Position
				v48.Parent = workspace.Effects
				v_u_3:AddItem(v48, 1)
				v48.Sparks.Color = ColorSequence.new(Color3.fromRGB(255, 165, 165))
				v48.Wind.Color = v48.Sparks.Color
				v48.Wind2.Color = v48.Sparks.Color
				v48.Sparks:Emit(30)
				v48.Wind2:Emit(7)
				if (workspace.CurrentCamera.CFrame.Position - v47.Position).Magnitude < 60 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end
	}
	v_u_9.Effects:Connect(function(p50, ...)
		-- upvalues: (copy) v_u_49
		local v51 = v_u_49[p50]
		if v51 then
			v51(...)
		end
	end)
end
function v11.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("SkyDistortionService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11