-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Yuta.Rika.RikaLaunchController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v3 = game.ReplicatedStorage
local _ = v3.Animations
local v_u_4 = v3.Utils
local v_u_5 = v3.Sounds
require(v3.Modules.CameraShaker)
require(v3.Modules.BloodyZee)
local v_u_6 = nil
local v_u_7 = nil
local v8 = v_u_1.CreateController({
	["Name"] = "RikaLaunchController"
})
function v8.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_7, (copy) v_u_5, (copy) v_u_4, (copy) v_u_2
	local v_u_15 = {
		["Feint"] = function(p9, p10)
			-- upvalues: (ref) v_u_7, (ref) v_u_5, (ref) v_u_4, (ref) v_u_2
			local v_u_11 = p9:FindFirstChild("HumanoidRootPart")
			if v_u_11 then
				if p10 then
					v_u_7:PlaySound(v_u_5.Yuta.EnergyRipple.Feint.Feint, v_u_11, game.SoundService.Effect)
					task.delay(0.2, function()
						-- upvalues: (ref) v_u_7, (ref) v_u_5, (copy) v_u_11
						v_u_7:PlaySound(v_u_5.Yuta.EnergyRipple.Feint.Swing, v_u_11, game.SoundService.Effect)
					end)
				end
				local v12 = v_u_4.Itadori.CounterHit.Feint:Clone()
				for _, v13 in v12:GetChildren() do
					v13.Color = ColorSequence.new(Color3.fromRGB(255, 170, 255))
				end
				v12.Parent = v_u_11
				v12.Sparks:Emit(10)
				v12.Star:Emit(1)
				v12.Ring:Emit(1)
				v_u_2:AddItem(v12, 0.5)
			end
		end,
		["StartSound"] = function(p14)
			-- upvalues: (ref) v_u_7, (ref) v_u_5
			v_u_7:PlaySound(v_u_5.Yuta.Rika.Launch, p14, game.SoundService.Effect)
		end
	}
	RikaLaunchService.Effects:Connect(function(p16, ...)
		-- upvalues: (copy) v_u_15
		local v17 = v_u_15[p16]
		if v17 then
			v17(...)
		end
	end)
end
function v8.KnitInit(_) -- name: KnitInit
	-- upvalues: (copy) v_u_1, (ref) v_u_6, (ref) v_u_7
	RikaLaunchService = v_u_1.GetService("RikaLaunchService")
	v_u_6 = v_u_1.GetController("HitboxController")
	v_u_7 = v_u_1.GetController("FXController")
end
return v8