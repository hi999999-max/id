-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Character.EmoteController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("MarketplaceService")
local v_u_2 = game:GetService("UserInputService")
game:GetService("CollectionService")
game:GetService("RunService")
game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local v_u_6 = require(v_u_5.Modules.Icon)
local _ = v_u_5.Animations
local _ = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = v_u_1.CreateController({
	["Name"] = "EmoteController"
})
v_u_10.EmoteCache = {}
v_u_10.Page = 1
v_u_10.MaxPage = 1
v_u_10.WheelPage = 1
function v_u_10.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_10, (copy) v_u_5, (copy) v_u_3, (copy) v_u_2, (ref) v_u_8, (ref) v_u_9, (copy) v_u_7
	local v_u_11 = v_u_4.PlayerGui:WaitForChild("Emotes")
	local v_u_12 = v_u_11.Emote
	local v_u_13 = v_u_12.EmoteMenu
	local v_u_14 = v_u_4.PlayerGui:WaitForChild("Menus").Group.Inventory
	local v_u_15 = v_u_4:WaitForChild("Gamepasses")
	task.wait()
	local v_u_16 = v_u_6.new()
	v_u_16:setImage("rbxassetid://11713358131")
	v_u_16:bindEvent("selected", function(_)
		-- upvalues: (copy) v_u_12
		v_u_12.Visible = true
	end)
	v_u_16:bindEvent("deselected", function(_)
		-- upvalues: (copy) v_u_12
		v_u_12.Visible = false
	end)
	v_u_16:setCaption("Emotes")
	v_u_10.IconButton = v_u_16
	v_u_5.Keybind.Combat.Emote.Pressed:Connect(function()
		-- upvalues: (ref) v_u_4, (copy) v_u_12, (copy) v_u_16
		if v_u_4.Character and _G.UsingPiano == 2 then
			return
		elseif v_u_4:GetAttribute("Adjusting_Keybinds") then
			return
		elseif v_u_12.Visible == false then
			v_u_16:select()
		elseif v_u_12.Visible == true then
			v_u_16:deselect()
		end
	end)
	v_u_12:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (copy) v_u_12, (copy) v_u_13, (ref) v_u_3
		if v_u_12.Visible ~= false then
			v_u_12.Size = UDim2.new(0.1, 150, 0.1, 150)
			v_u_13.TextBox.Text = ""
			v_u_3:Create(v_u_12, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
				["Size"] = UDim2.new(0.2, 150, 0.2, 150)
			}):Play()
			for _, v17 in v_u_13.Page:GetDescendants() do
				if not v17:IsA("Humanoid") then
					continue
				end
				for _, v18 in v17:GetPlayingAnimationTracks() do
					v18.TimePosition = 0
				end
			end
		end
	end)
	local v19 = Instance.new("Camera")
	v19.Parent = v_u_13
	v19.CFrame = v_u_11.Preset.Rig.HumanoidRootPart.CFrame * CFrame.new(0, 0, -30) * CFrame.Angles(0, 3.141592653589793, 0)
	v19.FieldOfView = 17
	v_u_4:WaitForChild("leaderstats")
	v_u_2.JumpRequest:Connect(function(_, _)
		-- upvalues: (ref) v_u_4, (ref) v_u_8
		local v20 = v_u_4.Character
		if v20 then
			if not v20.Info:FindFirstChild("EmoteCanJump") then
				if v20.Info:FindFirstChild("Emote") then
					v_u_8.EmoteEnd:Fire()
				end
			end
		else
			return
		end
	end)
	local v_u_21 = v_u_13.Pages.Page
	local function v_u_33() -- name: updateEmoteWheelPage
		-- upvalues: (copy) v_u_21, (ref) v_u_10, (copy) v_u_13, (copy) v_u_11
		v_u_21.Text = ("%*/%*"):format(v_u_10.WheelPage, v_u_10.MaxPage)
		local v22 = (v_u_10.WheelPage - 1) * 8
		for v23 = 1, 8 do
			local v24 = v_u_13.Page:FindFirstChild(v23)
			if v24:FindFirstChild("Rig") then
				v24.Rig:Destroy()
			end
			local v25 = v_u_10.EmoteCache[v22 + v23]
			if not v25 then
				continue
			end
			local v26 = v25[1]
			local v27 = v25[2]
			local v28 = v25[3]
			v24.EmoteName.Text = v26
			v24.EmoteName.Tip.Visible = v28 ~= nil
			if v28 then
				v24.EmoteName.Tip.Text = v28
			end
			local v29 = v_u_11.Preset.Rig:Clone()
			v29.Parent = v24
			if not v27 then
				continue
			end
			local v30 = Instance.new("Animation", v29)
			v30.AnimationId = v27
			if v27 == "0" then
				continue
			end
			local v_u_31 = v29.Humanoid:LoadAnimation(v30)
			v_u_31.Looped = true
			v_u_31:Play()
			v_u_31:GetMarkerReachedSignal("Loop"):Connect(function(p32)
				-- upvalues: (copy) v_u_31
				v_u_31.TimePosition = p32
			end)
		end
	end
	local function v_u_44(p34, p35, p36, p37) -- name: equipEmote
		-- upvalues: (ref) v_u_10, (copy) v_u_13, (copy) v_u_21, (copy) v_u_14, (copy) v_u_33
		local v38 = p35 or "None"
		v_u_10.EmoteCache[p34] = { v38, p36, p37 }
		v_u_10.MaxPage = #v_u_10.EmoteCache / 8
		if v_u_10.MaxPage >= 2 then
			v_u_13.TextBox.Visible = true
		end
		v_u_21.Text = ("%*/%*"):format(v_u_10.WheelPage, v_u_10.MaxPage)
		v_u_14.Items.Emotes.Equipped.Pages.Page.Text = ("%*/%*"):format(v_u_10.Page, v_u_10.MaxPage + 1)
		local v39 = v_u_10.MaxPage == 1
		v_u_21.Visible = not v39
		v_u_13.Pages.Visible = not v39
		v_u_13.Switch.Visible = not v39
		local v40 = (v_u_10.Page - 1) * 8
		if p34 <= v40 + 8 and v40 < p34 then
			local v41 = v_u_14.Items.Emotes.Equipped
			local v42 = p34 - v40
			v41[tostring(v42)].Text = v38
		end
		local v43 = (v_u_10.WheelPage - 1) * 8
		if p34 <= v43 + 8 and v43 < p34 then
			v_u_33()
		end
	end
	v_u_8.Equip:Connect(function(p45, p46, p47, p48)
		-- upvalues: (copy) v_u_44
		if p45 == "Bulk" then
			for v49, v50 in game:GetService("HttpService"):JSONDecode(buffer.tostring(game.EncodingService:DecompressBuffer(p46, Enum.CompressionAlgorithm.Zstd))) do
				local v51, v52, v53
				if v50 == 0 then
					v51 = nil
					v52 = nil
					v53 = nil
				else
					v51, v52, v53 = unpack(v50)
				end
				v_u_44(v49, v51, v52, v53)
			end
		else
			v_u_44(p45, p46, p47, p48)
		end
	end)
	v_u_13.Pages.Next.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_10, (copy) v_u_33, (ref) v_u_9, (ref) v_u_7
		local v54 = v_u_10.WheelPage
		local v55 = v54 + 1
		local v56 = v_u_10.MaxPage
		local v57 = math.min(v55, v56)
		if v57 ~= v54 then
			v_u_10.WheelPage = v57
			v_u_33()
		end
		v_u_9:PlaySound(v_u_7.Misc.UI.Switch, workspace, game.SoundService.Effect)
	end)
	v_u_13.Switch.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_10, (copy) v_u_33, (ref) v_u_9, (ref) v_u_7
		local v58 = v_u_10.WheelPage
		local v59 = v58 + 1
		local v60 = v_u_10.MaxPage
		local v61 = math.min(v59, v60)
		v_u_10.WheelPage = v61 == v58 and 1 or v61
		v_u_33()
		v_u_9:PlaySound(v_u_7.Misc.UI.Switch, workspace, game.SoundService.Effect)
	end)
	v_u_13.Pages.Back.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_10, (copy) v_u_33, (ref) v_u_9, (ref) v_u_7
		local v62 = v_u_10.WheelPage
		local v63 = v62 - 1
		local v64 = math.max(v63, 1)
		if v64 ~= v62 then
			v_u_10.WheelPage = v64
			v_u_33()
		end
		v_u_9:PlaySound(v_u_7.Misc.UI.Switch, workspace, game.SoundService.Effect)
	end)
	for _, v_u_65 in v_u_13.Page:GetChildren() do
		if not v_u_65:IsA("ViewportFrame") then
			continue
		end
		v_u_65.CurrentCamera = v19
		v_u_65.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_9, (ref) v_u_7, (ref) v_u_3, (copy) v_u_65
			v_u_9:PlaySound(v_u_7.Misc.UI.Hover, workspace, game.SoundService.Effect)
			v_u_3:Create(v_u_65, TweenInfo.new(0.25), {
				["Size"] = UDim2.new(0.35, 10, 0.5, 10)
			}):Play()
		end)
		v_u_65.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_3, (copy) v_u_65
			v_u_3:Create(v_u_65, TweenInfo.new(0.25), {
				["Size"] = UDim2.new(0.35, 0, 0.5, 0)
			}):Play()
		end)
		v_u_65.Clickable.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_9, (ref) v_u_7, (copy) v_u_16, (ref) v_u_8, (ref) v_u_10, (copy) v_u_65
			v_u_9:PlaySound(v_u_7.Misc.UI.Click, workspace, game.SoundService.Effect)
			v_u_16:deselect()
			local v66 = v_u_8.Emote
			local v67 = (v_u_10.WheelPage - 1) * 8
			local v68 = v_u_65.Name
			v66:Fire(v67 + tonumber(v68))
		end)
	end
	local function v70() -- name: updateGamepass
		-- upvalues: (copy) v_u_15, (copy) v_u_13, (copy) v_u_14
		if v_u_15:GetAttribute("742180133") then
			for v69 = 5, 8 do
				v_u_13:FindFirstChild(v69, true).Visible = true
				v_u_14.Items.Emotes.Equipped:FindFirstChild(v69).Visible = true
			end
		end
	end
	v70()
	v_u_15:GetAttributeChangedSignal("742180133"):Connect(v70)
	local v_u_71 = require(script:WaitForChild("Effects"))
	v_u_8.Effects:Connect(function(p_u_72, ...)
		-- upvalues: (copy) v_u_71
		local v_u_73 = { ... }
		local function v75()
			-- upvalues: (ref) v_u_71, (copy) p_u_72, (copy) v_u_73
			local v74 = v_u_73
			v_u_71[p_u_72](unpack(v74))
		end
		xpcall(v75, function(p76)
			-- upvalues: (copy) p_u_72
			print(("err with EmoteController [%s]: %s"):format(p_u_72, p76))
		end)
	end)
	v_u_13.TextBox:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (copy) v_u_13, (copy) v_u_15, (copy) v_u_14, (ref) v_u_9, (ref) v_u_7, (copy) v_u_16, (ref) v_u_8
		if v_u_13.TextBox.Text == "" then
			if v_u_15:GetAttribute("1151174294") then
				v_u_13.TextBox.Visible = true
				v_u_13.Switch.Visible = true
			end
			v_u_13.Page.Visible = true
			v_u_13.Search.Visible = false
			v_u_13.Pages.Visible = true
		else
			v_u_13.Page.Visible = false
			v_u_13.Pages.Visible = false
			v_u_13.Switch.Visible = false
			v_u_13.Search.Visible = true
			for _, v77 in v_u_13.Search:GetChildren() do
				if not v77:IsA("Frame") then
					continue
				end
				v77:Destroy()
			end
			for _, v78 in v_u_14.Items.Emotes.List:GetChildren() do
				if not (v78:IsA("Frame") and v78.Name:lower():find(v_u_13.TextBox.Text:lower())) then
					continue
				end
				local v_u_79 = v78:Clone()
				v_u_79.Parent = v_u_13.Search
				v_u_79.Visible = true
				v_u_79.MouseEnter:Connect(function()
					-- upvalues: (ref) v_u_9, (ref) v_u_7
					v_u_9:PlaySound(v_u_7.Misc.UI.Hover, workspace, game.SoundService.Effect)
				end)
				v_u_79.EmoteName.MouseButton1Down:Connect(function()
					-- upvalues: (ref) v_u_9, (ref) v_u_7, (ref) v_u_16, (ref) v_u_8, (copy) v_u_79
					v_u_9:PlaySound(v_u_7.Misc.UI.Click, workspace, game.SoundService.Effect)
					v_u_16:deselect()
					v_u_8.Emote:Fire(v_u_79.Name)
				end)
			end
		end
	end)
end
function v_u_10.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_8, (copy) v_u_1, (ref) v_u_9
	v_u_8 = v_u_1.GetService("EmoteService")
	v_u_9 = v_u_1.GetController("FXController")
end
return v_u_10