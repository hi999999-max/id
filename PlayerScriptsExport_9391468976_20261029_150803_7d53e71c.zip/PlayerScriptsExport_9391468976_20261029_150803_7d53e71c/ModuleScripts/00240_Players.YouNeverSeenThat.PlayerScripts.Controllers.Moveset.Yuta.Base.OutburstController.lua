-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Yuta.Base.OutburstController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
local v_u_10 = require(v6.Modules.SraikoVFX)
local v_u_11 = RaycastParams.new()
v_u_11.FilterType = Enum.RaycastFilterType.Include
v_u_11.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v16 = v_u_1.CreateController({
	["Name"] = "OutburstController"
})
function v16.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_7, (copy) v_u_3, (ref) v_u_14, (copy) v_u_8, (copy) v_u_5, (copy) v_u_9, (copy) v_u_4, (ref) v_u_15, (copy) v_u_2, (copy) v_u_11, (copy) v_u_10, (ref) v_u_12
	local v_u_93 = {
		["BodyBurst"] = function(p17)
			-- upvalues: (ref) v_u_7, (ref) v_u_3
			local v18 = p17:FindFirstChild("Torso")
			if v18 then
				local v_u_19 = v_u_7.Yuta.Outburst.Aura:Clone()
				v_u_19.Parent = v18
				v_u_3:AddItem(v_u_19, 0.6)
				task.delay(0.3, function()
					-- upvalues: (copy) v_u_19
					v_u_19.Aura.Enabled = false
				end)
			end
		end,
		["Hit"] = function(p20, p21)
			-- upvalues: (ref) v_u_14, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v22 = p20:FindFirstChild("HumanoidRootPart")
			if v22 then
				local v23 = p21:FindFirstChild("HumanoidRootPart")
				if v23 then
					v_u_14:PlaySound(v_u_8.Haruta.AmbushHit, v23, game.SoundService.Effect)
					v_u_14:Flash(p21, Color3.fromRGB(255, 170, 255))
					local v24 = v_u_7.Yuta.SlashHit:Clone()
					v24.Slash.Color = ColorSequence.new(Color3.fromRGB(255, 85, 255))
					v24.CFrame = CFrame.lookAlong(v23.Position, v22.CFrame.LookVector)
					v24.Parent = workspace.Effects
					v_u_3:AddItem(v24, 0.5)
					v24.Slash:Emit(5)
					if p20 == v_u_5.Character or p21 == v_u_5.Character then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.MediumHit)
					end
				end
			else
				return
			end
		end,
		["SwordBurst"] = function(p25)
			-- upvalues: (ref) v_u_7, (ref) v_u_14, (ref) v_u_3
			if p25:FindFirstChild("HumanoidRootPart") then
				local v26 = p25.SetAssets:FindFirstChild("YutaSword")
				if v26 then
					local v27 = v_u_7.Yuta.Outburst.SwordBurst:Clone()
					v27.Parent = v26.Sword
					v_u_14:PlayParticles(v27)
					v_u_3:AddItem(v27, 0.35)
				end
			else
				return
			end
		end,
		["ProjectileExplode"] = function(p28)
			-- upvalues: (ref) v_u_7, (ref) v_u_14, (ref) v_u_3, (ref) v_u_4
			local v29 = v_u_7.Yuta.Outburst.YutaAOE:Clone()
			v29.Parent = workspace.Effects
			v29.Position = p28
			v_u_14:PlayParticles(v29)
			v_u_3:AddItem(v29, 1)
			v_u_4:Create(v29.PointLight, TweenInfo.new(1), {
				["Range"] = 0
			}):Play()
		end,
		["Aerial"] = function(p30, p31)
			-- upvalues: (ref) v_u_14, (ref) v_u_8, (ref) v_u_15
			local v32 = p30:FindFirstChild("HumanoidRootPart")
			if v32 then
				local v33 = p30:FindFirstChild("Humanoid")
				if v33 then
					p31.Position = v32.Position
					v_u_14:PlaySound(v_u_8.Itadori.CursedStrikes.Spin, v32, game.SoundService.Effect)
					local v34 = Instance.new("BodyGyro", v32)
					v34.P = 10000
					v34.MaxTorque = Vector3.new(40000, 40000, 40000)
					v33.PlatformStand = true
					repeat
						local v35 = v_u_15:GetMouseTarget()
						v34.CFrame = CFrame.new(v32.Position, v35)
						task.wait()
					until not p31.Parent
					v34:Destroy()
					v33.PlatformStand = false
				end
			else
				return
			end
		end,
		["Interp"] = function(p_u_36)
			-- upvalues: (ref) v_u_4, (ref) v_u_2
			local v_u_37 = p_u_36.CFrame
			local v_u_38 = tick()
			local v_u_39 = p_u_36:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_37, (copy) p_u_36, (ref) v_u_38
				v_u_37 = p_u_36.CFrame
				v_u_38 = tick()
			end)
			local v_u_40 = v_u_38
			local v_u_41 = v_u_37
			for _, v_u_42 in p_u_36:GetChildren() do
				v_u_42.Squash = NumberSequence.new(0)
				v_u_42.Size = NumberSequence.new(3)
				if v_u_42.Name == "CursedEnergy3" or v_u_42.Name == "CursedEnergy4" then
					task.spawn(function()
						-- upvalues: (ref) v_u_4, (copy) v_u_42
						for v43 = 1, 30 do
							local v44 = v_u_4:GetValue(v43 / 30, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
							v_u_42.Size = NumberSequence.new(3 + -1.5 * v44)
							v_u_42.Squash = NumberSequence.new(-3 * v44)
							task.wait(0.025)
						end
					end)
				else
					task.spawn(function()
						-- upvalues: (ref) v_u_4, (copy) v_u_42
						for v45 = 1, 30 do
							local v46 = v_u_4:GetValue(v45 / 30, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
							v_u_42.Size = NumberSequence.new(3 + -1.5 * v46)
							v_u_42.Squash = NumberSequence.new(3 * v46)
							task.wait(0.025)
						end
					end)
				end
			end
			p_u_36.Size = Vector3.new(0, 0, 0)
			v_u_4:Create(p_u_36, TweenInfo.new(0.5), {
				["Size"] = Vector3.new(15, 0.25, 0.25)
			}):Play()
			local v_u_47 = nil
			v_u_47 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_36, (ref) v_u_47, (copy) v_u_39, (ref) v_u_41, (ref) v_u_40
				if p_u_36.Parent == workspace.Bullets then
					if p_u_36.Parent then
						workspace:BulkMoveTo({ p_u_36 }, { v_u_41 + v_u_41.LookVector * (p_u_36:GetAttribute("Speed") * (tick() - v_u_40)) }, Enum.BulkMoveMode.FireCFrameChanged)
					else
						v_u_47:Disconnect()
						v_u_39:Disconnect()
					end
				else
					return
				end
			end)
		end,
		["StartCharge"] = function(p_u_48, p_u_49)
			-- upvalues: (ref) v_u_14, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (ref) v_u_11, (ref) v_u_10, (ref) v_u_3
			local v_u_50 = p_u_48:FindFirstChild("HumanoidRootPart")
			if v_u_50 then
				v_u_14:PlaySound(v_u_8.Yuta.Outburst.Start, p_u_48.HumanoidRootPart, game.SoundService.Effect)
				local v_u_51 = v_u_7.Yuta.Outburst.ChargeMeter:Clone()
				v_u_51.Parent = v_u_50
				local v52 = p_u_48.SetAssets:FindFirstChild("YutaSword")
				if v52 then
					local v_u_53 = v_u_7.Yuta.Outburst.SwordCEFlash:Clone()
					v_u_53.Parent = v52.Sword
					local v_u_54 = v_u_51:FindFirstChild("Bars")
					v_u_4:Create(v_u_54, TweenInfo.new(0), {
						["GroupTransparency"] = 0
					}):Play()
					local v_u_55 = nil
					local v_u_56 = 0.35
					p_u_49:GetAttributeChangedSignal("Started"):Once(function()
						-- upvalues: (ref) v_u_55, (copy) p_u_49, (copy) v_u_54, (ref) v_u_14, (copy) p_u_48, (ref) v_u_8, (copy) v_u_50, (ref) v_u_4, (ref) v_u_56, (ref) v_u_11, (ref) v_u_7, (ref) v_u_10, (ref) v_u_3
						v_u_55 = true
						local v57 = 0
						for _ = 1, 3 do
							task.wait(0.2)
							if not p_u_49.Parent then
								break
							end
							v57 = v57 + 1
							local v58 = v_u_54:FindFirstChild(v57)
							v_u_14:Flash(p_u_48, Color3.new(1, 1, 1):Lerp(Color3.fromRGB(255, 85, 255), v57 / 3), 0.2)
							local v59 = v_u_14:PlaySound(v_u_8.Yuta.ResoluteSlash, v_u_50, game.SoundService.Effect)
							v59.Volume = 0.5
							v59.PlaybackSpeed = 2.2 - v57 / 3
							v58.BackgroundColor3 = Color3.new(1, 1, 1)
							v58.BackgroundTransparency = 0
							v_u_4:Create(v58, TweenInfo.new(0.2), {
								["BackgroundColor3"] = Color3.fromRGB(255, 85, 255)
							}):Play()
							v_u_56 = v_u_56 + 0.35
							local v60 = workspace:Raycast(v_u_50.Position, Vector3.new(-0, -7.5, -0), v_u_11)
							if not v60 then
								continue
							end
							for _, v61 in pairs(v_u_7.Nanami.BluntCut.Charge:GetChildren()) do
								if not v61:IsA("Model") then
									continue
								end
								local v62 = v61:Clone()
								v62:ScaleTo(v_u_56)
								if v62.Name == "NewSlash" then
									v62:SetAttribute("StartTransparency", 0.5)
								end
								local v63 = v_u_10.HandleMesh(v62, CFrame.new(v60.Position, v60.Position + v60.Normal) * CFrame.Angles(-1.5707963267948966, 0, 0))
								v62.Parent = workspace.Effects
								v_u_3:AddItem(v62, v63)
							end
						end
					end)
					p_u_49.AncestryChanged:Once(function()
						-- upvalues: (ref) v_u_4, (copy) v_u_54, (ref) v_u_3, (copy) v_u_51, (copy) v_u_53, (ref) v_u_55
						v_u_4:Create(v_u_54, TweenInfo.new(1), {
							["GroupTransparency"] = 1
						}):Play()
						v_u_3:AddItem(v_u_51, 1)
						v_u_3:AddItem(v_u_53, 0.2)
						if v_u_55 then
							v_u_53.CursedEnergy1:Emit(2)
						end
					end)
				end
			else
				return
			end
		end,
		["Slash"] = function(p64, p65)
			-- upvalues: (ref) v_u_14, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v66 = p64:FindFirstChild("HumanoidRootPart")
			if v66 then
				v_u_14:PlaySound(v_u_8.Yuta.Outburst.Swing, v66, game.SoundService.Effect)
				local v67 = v_u_7.Yuta.ResoluteSlash.RingSwing.Attachment:Clone()
				v67.Ring.RotSpeed = NumberRange.new(-800, -200)
				v67.Parent = v66
				v67.Ring:Emit(8)
				v_u_3:AddItem(v67, 0.6)
				local v68 = v_u_7.Ryu.Slash:Clone()
				v68:ScaleTo(1.7)
				v68.Weld.Part0 = v66
				v68.Weld.C0 = CFrame.Angles(0, -0.4363323129985824, 3.141592653589793)
				local v69 = v68.Part1.Mesh
				local v70 = -16 - p65
				local v71 = 16 + p65
				v69.Scale = Vector3.new(v70, 2, v71)
				local v72 = v68.Part2.Mesh
				local v73 = 16.445 + p65
				local v74 = 16.445 + p65
				v72.Scale = Vector3.new(v73, 2, v74)
				v68.Weld.C1 = CFrame.Angles(0, -1.5707963267948966, 0)
				v68.Parent = workspace.Effects
				v_u_3:AddItem(v68, 0.125)
				local v75 = TweenInfo.new(0.125, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
				local v76 = TweenInfo.new(0.125, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				v_u_4:Create(v68.Weld, v75, {
					["C1"] = v68.Weld.C1 * CFrame.Angles(0, -1.7453292519943295, 0)
				}):Play()
				for _, v77 in v68:GetDescendants() do
					if v77:IsA("Decal") then
						v77.Color3 = Color3.fromRGB(440, 223, 355)
						v_u_4:Create(v77, v76, {
							["Transparency"] = 1
						}):Play()
					else
						if not v77:IsA("SpecialMesh") then
							continue
						end
						v_u_4:Create(v77, v75, {
							["Scale"] = v77.Scale * 1.2
						}):Play()
					end
				end
			end
		end,
		["GroundExplode"] = function(p78, p79, _)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_14, (ref) v_u_8, (ref) v_u_9
			local v80 = v_u_7.Yuta.Outburst.OutburstExplode:Clone()
			v80:ScaleTo((p79 / v80.Hitbox.Size).Z)
			v80.Hitbox.CFrame = p78
			local v81 = v80.Hitbox.Attachment.PointLight
			local v82 = v81.Range
			v81.Range = 0
			v80.Parent = workspace.Effects
			v_u_4:Create(v81, TweenInfo.new(0.2), {
				["Range"] = v82
			}):Play()
			for _, v_u_83 in v80:GetDescendants() do
				if not v_u_83:IsA("ParticleEmitter") or v_u_83:GetAttribute("EmitDelay") == 0.5 then
					continue
				end
				if v_u_83:GetAttribute("EmitDelay") then
					task.delay(v_u_83:GetAttribute("EmitDelay"), function()
						-- upvalues: (copy) v_u_83
						v_u_83:Emit(v_u_83:GetAttribute("EmitCount"))
					end)
				else
					v_u_83:Emit(v_u_83:GetAttribute("EmitCount"))
				end
			end
			v_u_3:AddItem(v80, 3)
			v_u_14:PlaySound(v_u_8.Yuta.Outburst.Charge, v80.Hitbox, game.SoundService.Effect)
			task.wait(0.5)
			v_u_4:Create(v81, TweenInfo.new(0.1), {
				["Range"] = 0
			}):Play()
			v_u_14:PlaySound(v_u_8.Yuta.Outburst.Explosion, v80.Hitbox, game.SoundService.Effect)
			for _, v84 in v80:GetDescendants() do
				if not v84:IsA("ParticleEmitter") or v84:GetAttribute("EmitDelay") ~= 0.5 then
					continue
				end
				v84:Emit(v84:GetAttribute("EmitCount"))
			end
			local v85 = v_u_7.Gojo.ReversalRed.RedExplode:Clone()
			v85.Position = p78.Position
			v85.Parent = workspace.Effects
			v_u_3:AddItem(v85, 2)
			v85.Light.Color = v81.Color
			v85.Burst.Color = ColorSequence.new(Color3.fromRGB(255, 150, 255))
			v85.Sparks.Color = ColorSequence.new(Color3.fromRGB(255, 150, 255))
			v85.Burst:Emit(1)
			v85.Sparks:Emit(15)
			v85.Wind:Emit(6)
			v85.Dust:Emit(6)
			v_u_4:Create(v85.Light, TweenInfo.new(0.5), {
				["Brightness"] = 0
			}):Play()
			if (workspace.CurrentCamera.CFrame.Position - p78.Position).Magnitude < 60 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
			end
		end,
		["ExplosionHit"] = function(p86)
			-- upvalues: (ref) v_u_14, (ref) v_u_8
			local v87 = p86:FindFirstChild("HumanoidRootPart")
			if v87 then
				v_u_14:Flash(p86, Color3.fromRGB(255, 85, 255))
				v_u_14:PlaySound(v_u_8.Yuta.Outburst.ExplosionHit, v87, game.SoundService.Effect)
			end
		end,
		["Clash"] = function(p88, p89)
			-- upvalues: (ref) v_u_14, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_9
			local v90 = p88:FindFirstChild("HumanoidRootPart")
			if v90 then
				if p89 then
					v_u_14:Flash(p89, Color3.new(1, 1, 0.498039), 0.6)
				end
				v_u_14:Flash(p88, Color3.new(1, 1, 0.498039), 0.6)
				v_u_14:PlaySound(v_u_8.Misc.Items.Clash, v90, game.SoundService.Effect)
				local v91 = v_u_7.Misc.Items.Clash.Attachment:Clone()
				v91.Parent = v90
				v_u_3:AddItem(v91, 0.9)
				for _, v92 in v91:GetChildren() do
					if v92:IsA("PointLight") then
						v_u_4:Create(v92, TweenInfo.new(v92:GetAttribute("Duration")), {
							["Brightness"] = 0
						}):Play()
					else
						v92:Emit(v92:GetAttribute("EmitCount"))
					end
				end
				if (workspace.CurrentCamera.CFrame.Position - v90.Position).Magnitude < 150 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end
	}
	v_u_12.Effects:Connect(function(p94, ...)
		-- upvalues: (ref) v_u_93
		local v95 = v_u_93[p94]
		if v95 then
			v95(...)
		end
	end)
end
function v16.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_12, (copy) v_u_1, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15
	v_u_12 = v_u_1.GetService("OutburstService")
	v_u_13 = v_u_1.GetController("HitboxController")
	v_u_14 = v_u_1.GetController("FXController")
	v_u_15 = v_u_1.GetController("ToolController")
end
return v16