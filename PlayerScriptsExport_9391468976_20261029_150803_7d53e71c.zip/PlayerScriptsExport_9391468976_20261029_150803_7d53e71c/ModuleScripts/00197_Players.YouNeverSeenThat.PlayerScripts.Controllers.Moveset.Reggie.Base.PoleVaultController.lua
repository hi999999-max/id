-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Reggie.Base.PoleVaultController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
require(v5.Modules.BloodyZee)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "PoleVaultController"
})
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_4, (copy) v_u_8, (copy) v_u_2, (copy) v_u_6, (copy) v_u_3, (ref) v_u_9
	local v_u_34 = {
		["Hit"] = function(p13, p14)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			if p13:FindFirstChild("HumanoidRootPart") then
				local v15 = p14:FindFirstChild("HumanoidRootPart")
				if v15 then
					v_u_11:Flash(p14, Color3.new(1, 1, 1))
					v_u_11:PlaySound(v_u_7.Nanami.CrossCut.Hit1, v15, game.SoundService.Effect)
					if v_u_4.Character == p14 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
					end
				end
			else
				return
			end
		end,
		["Drop"] = function(p16)
			-- upvalues: (ref) v_u_2
			local v17 = p16:Clone()
			v17.Weld:Destroy()
			v17.CollisionGroup = "NoPlayerCollision"
			v17.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
			v17.CanCollide = true
			v17:PivotTo(p16:GetPivot())
			v17.Parent = workspace.Effects
			v_u_2:AddItem(v17, 2)
		end,
		["Slam"] = function(p18)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v19 = p18:FindFirstChild("HumanoidRootPart")
			if v19 then
				local v20 = v19.CFrame * CFrame.new(-0.2, -3, -3.6)
				local v21 = workspace:Raycast(v20.Position + Vector3.new(0, 3, 0), Vector3.new(0, -10, 0), _G.MapParams)
				if v21 then
					local v22 = v21.Position
					local v23 = v_u_6.Hiromi.Shockwave:Clone()
					local v24 = Instance.new("Model")
					v23.Parent = v24
					v24:ScaleTo(0.5)
					v_u_2:AddItem(v24, 0.2)
					v23.CFrame = CFrame.new(v22)
					v23.Parent = workspace.Effects
					local v25 = v23.CFrame
					local v26 = CFrame.Angles
					local v27 = math.random(-179, 179)
					v23.CFrame = v25 * v26(0, math.rad(v27), 0)
					v_u_3:Create(v23.mesh.Mesh, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
						["Scale"] = Vector3.new(5, 0, 5)
					}):Play()
					v_u_3:Create(v23.mesh.Decal, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
						["Transparency"] = 1
					}):Play()
					v23.Floor.Glow:Emit(1)
					v23.Floor.Ring:Emit(5)
					v_u_2:AddItem(v23, 1.5)
					local v28 = v_u_6.Choso.CounterSwing.Shock:Clone()
					v28.Size = Vector3.new(5, 15, 5)
					v28.CFrame = CFrame.new(v22)
					v28.Parent = workspace.Effects
					v_u_2:AddItem(v28, 0.3)
					v_u_3:Create(v28, TweenInfo.new(0.3), {
						["Size"] = Vector3.new(20, 5, 20),
						["Transparency"] = 1,
						["Position"] = nil,
						["Position"] = v28.Position - Vector3.new(0, 3, 0)
					}):Play()
					v_u_11:PlaySound(v_u_7.Haruta.BackstabFinisher.Slam, v23, game.SoundService.Effect)
					if v_u_4.Character == p18 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
					end
				end
			else
				return
			end
		end,
		["Launch"] = function(p29)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_11, (ref) v_u_7
			local v30 = p29:FindFirstChild("HumanoidRootPart")
			if v30 then
				local v31 = (v30.CFrame * CFrame.new(-0.2, -3, -3.6)).Position
				local v32 = workspace:Raycast(v31 + Vector3.new(0, 3, 0), Vector3.new(0, -10, 0), _G.MapParams)
				if v32 then
					v31 = v32.Position
				end
				local v33 = v_u_6.Choso.CounterSwing.Shock:Clone()
				v33.Size = Vector3.new(20, 10, 20)
				v33.CFrame = CFrame.new(v31) * v30.CFrame.Rotation * CFrame.Angles(-0.6108652381980153, 0, 0)
				v33.Parent = workspace.Effects
				v_u_2:AddItem(v33, 0.2)
				v_u_3:Create(v33, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(0, 36, 0),
					["Transparency"] = 1,
					["CFrame"] = nil,
					["CFrame"] = v33.CFrame * CFrame.new(0, 10, 0)
				}):Play()
				v_u_11:PlaySound(v_u_7.Reggie.BluntTrauma.Whoosh5, v30, game.SoundService.Effect)
			end
		end
	}
	v_u_9.Effects:Connect(function(p35, ...)
		-- upvalues: (copy) v_u_34
		local v36 = v_u_34[p35]
		if v36 then
			v36(...)
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("PoleVaultService")
	v_u_10 = v_u_1.GetController("HitboxController")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12