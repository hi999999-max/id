-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Ryu.Base.AppetizerController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
require(v5.Modules.CameraShaker)
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "AppetizerController"
})
function v11.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_9, (copy) v_u_7, (copy) v_u_6, (copy) v_u_4, (copy) v_u_3, (copy) v_u_2, (ref) v_u_8
	local v_u_26 = {
		["Startup"] = function(p12, _)
			if not p12:FindFirstChild("HumanoidRootPart") then
			end
		end,
		["Fire"] = function(p13, _)
			-- upvalues: (ref) v_u_9, (ref) v_u_7
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_9:PlaySound(v_u_7.Ryu.GraniteBlast.Fire, v14, game.SoundService.Effect)
			end
		end,
		["Fire2"] = function(p15, p16)
			-- upvalues: (ref) v_u_6, (ref) v_u_9, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			local v17 = p15:FindFirstChild("HumanoidRootPart")
			if v17 then
				local v18 = v_u_6.Ryu.GraniteBeam:Clone()
				v18.Size = Vector3.new(12, 12, 60)
				v18.Anchored = false
				v18.Massless = true
				v18.Parent = workspace.Effects
				if p16 then
					v_u_9:PlaySound(v_u_7.Ryu.GraniteBlast.FireHard, v17, game.SoundService.Effect)
					v18.Color = Color3.new(1, 1, 1)
					v18.Size = Vector3.new(6, 6, 60)
				else
					v_u_9:PlaySound(v_u_7.Ryu.GraniteBlast.Fire, v17, game.SoundService.Effect)
				end
				local v19 = Instance.new("Weld", v18)
				v19.Part0 = p15.Head
				v19.Part1 = v18
				v19.C1 = CFrame.new(0, -1, 31)
				v_u_4:Create(v18, TweenInfo.new(0.7, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(0, 0, 60)
				}):Play()
				v_u_3:AddItem(v18, 1)
				task.wait(0.35)
				v19:Destroy()
				v18.Anchored = true
			end
		end,
		["Interp"] = function(p_u_20)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_4, (ref) v_u_2
			local v_u_21 = p_u_20.CFrame
			local v_u_22 = tick()
			local v_u_23 = p_u_20:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_21, (copy) p_u_20, (ref) v_u_22
				v_u_21 = p_u_20.CFrame
				v_u_22 = tick()
			end)
			local v24 = v_u_6.Todo.Clap:Clone()
			v24.Color = Color3.fromRGB(128, 187, 219)
			v24.Transparency = 0
			v24.CFrame = p_u_20.CFrame * CFrame.new(0, 0, -1)
			v24.Size = Vector3.new(3, 3, 3)
			v24.Parent = workspace.Effects
			v_u_3:AddItem(v24, 0.4)
			v_u_4:Create(v24, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Size"] = Vector3.new(0, 0, 0)
			}):Play()
			local v_u_25 = nil
			v_u_25 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_20, (ref) v_u_25, (copy) v_u_23, (ref) v_u_21, (ref) v_u_22
				if p_u_20.Parent then
					workspace:BulkMoveTo({ p_u_20 }, { v_u_21 + v_u_21.LookVector * (180 * (tick() - v_u_22)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_25:Disconnect()
					v_u_23:Disconnect()
				end
			end)
		end
	}
	v_u_8.Effects:Connect(function(p27, ...)
		-- upvalues: (copy) v_u_26
		local v28 = v_u_26[p27]
		if v28 then
			v28(...)
		end
	end)
end
function v11.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_8, (copy) v_u_1, (ref) v_u_9, (ref) v_u_10
	v_u_8 = v_u_1.GetService("AppetizerService")
	v_u_9 = v_u_1.GetController("FXController")
	v_u_10 = v_u_1.GetController("ToolController")
end
return v11