-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Character.JoinController.TutorialController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local _ = v5.Utils
local v_u_6 = v5.Sounds
local v_u_7 = nil
local v8 = v_u_1.CreateController({
	["Name"] = "TutorialController"
})
local v_u_9 = require(v5.Modules.Info_Tutorial)
function v8.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_4, (ref) v_u_7, (copy) v_u_6, (copy) v_u_9, (copy) v_u_2, (copy) v_u_3
	local v_u_10 = v_u_4.PlayerGui:WaitForChild("Menus")
	local v_u_11 = v_u_10.Group.Tutorial_Info
	v_u_11:SetAttribute("Loaded", true)
	local function v_u_18(p12, p13) -- name: selecta
		-- upvalues: (ref) v_u_7, (ref) v_u_6, (copy) v_u_11, (ref) v_u_9
		v_u_7:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7:PlaySound(v_u_6.Misc.UI.Switch, workspace, game.SoundService.Effect)
		for _, v14 in v_u_11.Items:GetChildren() do
			if not v14:IsA("TextButton") then
				continue
			end
			if v14 == p13 then
				v14.BackgroundTransparency = 0.5
			else
				v14.BackgroundTransparency = 1
			end
		end
		local v15 = v_u_11.Description
		local v16 = v_u_9[p12]
		v15.CanvasPosition = Vector2.new(0, 0)
		v15.Title.Text = v16[2]
		v15.Video.Video = "rbxassetid://" .. v16[3]
		v15.Description.Text = ""
		for _, v17 in v16[4] do
			v15.Description.Text = v15.Description.Text .. v17 .. "\n\n"
		end
	end
	v_u_11.Return.MouseButton1Down:Connect(function()
		-- upvalues: (copy) v_u_11
		v_u_11.Visible = false
	end)
	v_u_11:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (copy) v_u_11, (ref) v_u_9, (copy) v_u_10, (copy) v_u_18, (ref) v_u_2
		if v_u_11.Visible == true then
			for v_u_19, v20 in v_u_9 do
				local v_u_21 = v_u_10.Preset.ItemBox:Clone()
				v_u_21.Name = v20[1]
				v_u_21.LayoutOrder = v_u_19
				v_u_21.Text = v20[1]
				v_u_21.Parent = v_u_11.Items
				if v_u_19 == 1 then
					v_u_18(v_u_19, v_u_21)
				end
				v_u_21.MouseButton1Down:Connect(function()
					-- upvalues: (ref) v_u_18, (copy) v_u_19, (copy) v_u_21
					v_u_18(v_u_19, v_u_21)
				end)
			end
			local v_u_22 = nil
			v_u_22 = v_u_2.RenderStepped:Connect(function()
				-- upvalues: (ref) v_u_11, (ref) v_u_22
				if v_u_11.Visible == false then
					v_u_22:Disconnect()
				else
					v_u_11.Description.Video.Playing = false
					v_u_11.Description.Video.Playing = true
				end
			end)
		else
			for _, v23 in v_u_11.Items:GetChildren() do
				if not v23:IsA("TextButton") then
					continue
				end
				v23:Destroy()
			end
			v_u_11.Description.Video.Video = ""
		end
	end)
	v_u_11.Description.Video:GetPropertyChangedSignal("IsLoaded"):Connect(function()
		-- upvalues: (copy) v_u_11, (ref) v_u_3
		if v_u_11.Description.Video.IsLoaded then
			v_u_3:Create(v_u_11.Description.Video.Fade, TweenInfo.new(0.4), {
				["BackgroundTransparency"] = 1
			}):Play()
		else
			v_u_3:Create(v_u_11.Description.Video.Fade, TweenInfo.new(0), {
				["BackgroundTransparency"] = 0
			}):Play()
		end
	end)
end
function v8.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_7, (copy) v_u_1
	v_u_7 = v_u_1.GetController("FXController")
end
return v8