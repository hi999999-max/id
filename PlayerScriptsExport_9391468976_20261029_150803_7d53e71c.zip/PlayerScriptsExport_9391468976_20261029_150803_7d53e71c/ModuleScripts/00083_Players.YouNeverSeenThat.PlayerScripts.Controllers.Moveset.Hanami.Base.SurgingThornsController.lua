-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Hanami.Base.SurgingThornsController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
require(v5.Modules.CameraShaker)
require(v5.Modules.BloodyZee)
local v_u_8 = nil
local v_u_9 = nil
local v10 = v_u_1.CreateController({
	["Name"] = "SurgingThornsController"
})
local v_u_11 = { Color3.fromRGB(86, 66, 54), Color3.fromRGB(76, 60, 51), Color3.fromRGB(86, 60, 51) }
function v10.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_6, (copy) v_u_4, (ref) v_u_9, (copy) v_u_7, (copy) v_u_11, (copy) v_u_3, (copy) v_u_2, (ref) v_u_8
	local v_u_73 = {
		["Spikes"] = function(p12)
			-- upvalues: (ref) v_u_6, (ref) v_u_4
			local function v16(p13) -- name: spike
				-- upvalues: (ref) v_u_6, (ref) v_u_4
				local v14 = workspace:Raycast(p13.Position, -p13.UpVector * 12, _G.MapParams)
				if v14 then
					local v15 = v_u_6.Hanami.CurvedRoot:Clone()
					v15.CFrame = p13
					v15.Position = v14.Position - p13.UpVector * 6
					v15.Parent = workspace.Effects
					v_u_4:Create(v15, TweenInfo.new(0.15), {
						["Position"] = v14.Position + p13.UpVector * 3
					}):Play()
					task.wait(0.5)
					v15:Destroy()
				end
			end
			for v17 = 1, 10 do
				local v18 = CFrame.Angles
				local v19 = v17 * 36
				local v20 = p12 * v18(0, math.rad(v19), 0) * CFrame.new(0, 0, -8 + math.random(-1, 1))
				local v21 = CFrame.Angles
				local v22 = -30 + math.random(-8, 8)
				local v23 = v20 * v21(math.rad(v22), 0, 0)
				task.spawn(v16, v23)
			end
		end,
		["WoodenBall"] = function(p_u_24, p_u_25)
			-- upvalues: (ref) v_u_9, (ref) v_u_7, (ref) v_u_11, (ref) v_u_6, (ref) v_u_3, (ref) v_u_4, (ref) v_u_2
			local v_u_26 = p_u_24:FindFirstChild("HumanoidRootPart")
			if v_u_26 then
				v_u_9:PlaySound(v_u_7.Hanami.AOESpikes.WoodBallsAppear, v_u_26, game.SoundService.Effect)
				local function v66(p_u_27, p28) -- name: CreateWoodenBall
					-- upvalues: (ref) v_u_11, (copy) v_u_26, (ref) v_u_6, (ref) v_u_3, (ref) v_u_4, (ref) v_u_2, (copy) p_u_25, (copy) p_u_24, (ref) v_u_9, (ref) v_u_7
					local v29 = v_u_11[math.random(1, #v_u_11)]
					local v30 = v_u_26.CFrame * p_u_27
					local v31 = workspace:Raycast(v30.Position, Vector3.new(0, -4, 0), _G.MapParams) or {
						["Position"] = v30.Position + Vector3.new(0, -2, 0)
					}
					local _ = v30.Position + Vector3.new(0, 2, 0)
					local v_u_32 = v_u_6.Hanami.WoodBall:Clone()
					v_u_32.Position = v31.Position + Vector3.new(0, -2, 0)
					v_u_32.Size = v_u_32.Size * 1.5
					v_u_32.Transparency = 1
					v_u_32.Color = v29
					v_u_32.Parent = workspace.Effects
					v_u_3:AddItem(v_u_32, 5)
					v_u_4:Create(v_u_32, TweenInfo.new(0.1), {
						["Transparency"] = 0
					}):Play()
					local v_u_33 = Instance.new("NumberValue", v_u_32)
					v_u_33.Value = -2
					v_u_4:Create(v_u_33, TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["Value"] = 2
					}):Play()
					local v_u_34 = false
					local v_u_35 = nil
					local v_u_36 = Random.new()
					local v_u_37 = nil
					v_u_37 = v_u_2.RenderStepped:Connect(function(p38)
						-- upvalues: (ref) p_u_25, (copy) v_u_32, (ref) p_u_24, (ref) v_u_37, (ref) v_u_35, (ref) v_u_26, (copy) p_u_27, (copy) v_u_33, (ref) v_u_34, (copy) v_u_36
						if not p_u_25:IsDescendantOf(workspace.Characters) then
							v_u_32:Destroy()
						end
						if p_u_24.Parent and v_u_32.Parent then
							if v_u_35 then
								if v_u_34 then
									v_u_32.CFrame = v_u_35 * CFrame.new(v_u_36:NextNumber(-0.2, 0.2), v_u_36:NextNumber(-0.2, 0.2), v_u_36:NextNumber(-0.2, 0.2))
								end
							else
								local v39 = v_u_32
								local v40 = v_u_32.CFrame
								local v41 = v_u_26.CFrame * p_u_27
								local v42 = v_u_33.Value
								v39.CFrame = v40:Lerp(v41 + vector.create(0, v42, 0), p38 * 20)
							end
						else
							v_u_37:Disconnect()
							return
						end
					end)
					if not p_u_25:GetAttribute(("Phase%d"):format(p28)) then
						repeat
							task.wait()
						until not p_u_25.Parent or p_u_25:GetAttribute(("Phase%d"):format(p28))
						if not p_u_25.Parent then
							return
						end
					end
					v_u_35 = v_u_32.CFrame
					local v43 = (p_u_25:GetAttribute(("Phase%d"):format(p28)) or v_u_26.CFrame).LookVector
					local v44 = Random.new()
					local v45 = v_u_32.Position
					local v46 = v_u_32.Position + v43 * 20
					v_u_9:PlaySound(v_u_7.Hanami.AOESpikes[("Spear%*"):format(p28)], v_u_32, game.SoundService.Effect)
					local v47 = v_u_32.Position
					local v_u_48 = {}
					for v49 = 1, 6 do
						local v50 = v49 / 6
						local v51 = v50 * -0.65 + 0.8
						local v52
						if v49 > 1 and v49 < 6 then
							local v53 = v44:NextNumber(-0.3, 0.3)
							local v54 = v44:NextNumber(-0.3, 0.3)
							v52 = vector.create(v53, v54, v44:NextNumber(-0.2, 0.2))
						else
							v52 = Vector3.new(0, 0, 0)
						end
						local v55 = v45 + (v46 - v45) * v50 + v52
						if v49 == 6 then
							v55 = v46
						end
						local v56 = (v55 - v47).Magnitude
						local v57 = Instance.new("Part")
						v57.Transparency = 1
						v57.Name = ("Segment"):format(v49)
						v57.CanCollide = false
						v57.Anchored = false
						v57.Material = Enum.Material.Wood
						v57.Color = v29
						v57.Size = vector.create(v51, v51, v56)
						v57.CFrame = CFrame.lookAt((v47 + v55) / 2, v47)
						local v58 = Instance.new("Weld")
						v58.C0 = v57.CFrame:ToObjectSpace(v_u_32.CFrame)
						v58.Part0 = v57
						v58.Part1 = v_u_32
						v58.Parent = v57
						v57.Parent = workspace.Effects
						table.insert(v_u_48, v57)
						v47 = v55
					end
					local v_u_59 = false
					local function v64() -- name: Cleanup
						-- upvalues: (ref) v_u_59, (ref) v_u_6, (copy) v_u_32, (ref) v_u_9, (ref) v_u_7, (copy) v_u_48, (ref) v_u_3, (ref) v_u_4, (copy) v_u_33
						if not v_u_59 then
							v_u_59 = true
							local v60 = v_u_6.Hanami.ParticleDissipationHolder:Clone()
							v60.Parent = v_u_32
							v_u_9:PlayParticles(v_u_32)
							v_u_9:PlaySound(v_u_7.Hanami.RootDisappear, v_u_32, game.SoundService.Effect)
							for _, v61 in v_u_48 do
								v61.Anchored = true
								for _, v62 in v60:GetChildren() do
									local v63 = v62:Clone()
									v63.Shape = Enum.ParticleEmitterShape.Box
									v63.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v61.Size.Magnitude / 2, 0), NumberSequenceKeypoint.new(1, v61.Size.Magnitude * 1.25, 0) })
									v63.Parent = v61
								end
								v_u_3:AddItem(v61, 1)
								v_u_9:PlayParticles(v61)
								v_u_4:Create(v61, TweenInfo.new(0.2), {
									["Transparency"] = 1
								}):Play()
							end
							v_u_4:Create(v_u_32, TweenInfo.new(0.2), {
								["Transparency"] = 1
							}):Play()
							v_u_3:AddItem(v_u_32, 1)
							v_u_33:Destroy()
						end
					end
					p_u_25.Destroying:Once(v64)
					p_u_24.Destroying:Once(v64)
					v_u_34 = true
					for _, v65 in v_u_48 do
						v65.Transparency = 0
						task.wait(0.024999999999999998)
					end
					v_u_34 = false
				end
				task.spawn(v66, CFrame.new(3, 0, -0.5), 1)
				task.spawn(v66, CFrame.new(-3, 0, -0.5), 2)
			end
		end,
		["SpikesWindup"] = function(p67)
			-- upvalues: (ref) v_u_9, (ref) v_u_7
			local v68 = p67:FindFirstChild("HumanoidRootPart")
			if v68 then
				v_u_9:PlaySound(v_u_7.Hanami.AOESpikes.SpikesWindup, v68, game.SoundService.Effect)
			end
		end,
		["Hit"] = function(p69, p70)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_9, (ref) v_u_7
			local v71 = p69:FindFirstChild("HumanoidRootPart")
			if v71 then
				local v72 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v72.Position = v71.Position
				v72.Parent = workspace.Effects
				v_u_3:AddItem(v72, 1)
				v72.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 0.498039))
				v72.Wind.Color = v72.Sparks.Color
				v72.Wind2.Color = v72.Sparks.Color
				v72.Sparks:Emit(30)
				v72.Wind2:Emit(7)
				v_u_9:Flash(p69, Color3.new(1, 1, 1))
				v_u_9:PlaySound(v_u_7.Hanami.DefenseResponse[("Hit%*"):format(p70)], v71, game.SoundService.Effect)
			end
		end
	}
	v_u_8.Effects:Connect(function(p74, ...)
		-- upvalues: (copy) v_u_73
		local v75 = v_u_73[p74]
		if v75 then
			v75(...)
		end
	end)
end
function v10.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_8, (copy) v_u_1, (ref) v_u_9
	v_u_8 = v_u_1.GetService("SurgingThornsService")
	v_u_9 = v_u_1.GetController("FXController")
end
return v10