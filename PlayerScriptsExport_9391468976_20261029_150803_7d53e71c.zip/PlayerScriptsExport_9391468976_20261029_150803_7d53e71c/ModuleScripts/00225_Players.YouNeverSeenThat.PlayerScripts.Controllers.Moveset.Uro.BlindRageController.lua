-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Uro.BlindRageController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = require(v_u_5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "BlindRageController"
})
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_6, (copy) v_u_3, (copy) v_u_2, (ref) v_u_11, (copy) v_u_7, (copy) v_u_4, (copy) v_u_5, (copy) v_u_8, (copy) v_u_9, (ref) v_u_10
	local v_u_56 = {
		["Fly"] = function(p13, p_u_14)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4
			local v_u_15 = p13.HumanoidRootPart
			if v_u_15 then
				local v16 = p13:FindFirstChild("Humanoid")
				if v16 then
					task.spawn(function()
						-- upvalues: (ref) v_u_6, (copy) v_u_15, (ref) v_u_3, (ref) v_u_2, (copy) p_u_14
						local v17 = Instance.new("Model", workspace.Effects)
						local v18 = Instance.new("Highlight")
						v18.FillTransparency = 1
						v18.OutlineTransparency = 1
						v18.Parent = v17
						repeat
							task.wait(0.1)
							local v19 = v_u_6.Uro.Ring:Clone()
							v19.CFrame = v_u_15.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
							v19.Parent = v17
							v19.Attachment.Wind:Emit(2)
							v_u_3:Create(v19, TweenInfo.new(0.5), {
								["Size"] = nil,
								["Transparency"] = 1,
								["Size"] = v19.Size * 2
							}):Play()
							v_u_2:AddItem(v19, 0.5)
						until not p_u_14:IsDescendantOf(workspace.Characters)
						v_u_2:AddItem(v17, 0.5)
					end)
					v_u_11:PlaySound(v_u_7.Uro.BlindRage.Fly, v_u_15, game.SoundService.Effect)
					v_u_11:PlaySound(v_u_7.Ryu.NotInvited.Dash, v_u_15, game.SoundService.Effect)
					if v_u_4.Character == p13 then
						local v20 = Instance.new("BodyGyro", v_u_15)
						v20.P = 10000
						v20.MaxTorque = Vector3.new(40000, 40000, 40000)
						p_u_14.Position = v_u_15.Position + Vector3.new(0, 12, 0)
						v16.PlatformStand = true
						repeat
							local v21 = workspace.CurrentCamera.CFrame
							p_u_14.Position = v_u_15.Position + v21.LookVector * 40
							v20.CFrame = v21
							task.wait()
						until not p_u_14.Parent
						v16.PlatformStand = false
						v20:Destroy()
					end
				end
			else
				return
			end
		end,
		["Swing"] = function(p22, p23)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v24 = p22.HumanoidRootPart
			if v24 then
				if p23 == 1 then
					v_u_11:PlaySound(v_u_7.Uro.BlindRage.Swing1, v24, game.SoundService.Effect)
				else
					v_u_11:PlaySound(v_u_7.Uro.BlindRage.Swing2, v24, game.SoundService.Effect)
					v_u_11:PlaySound(v_u_7.Uro.BlindRage.Swing3, v24, game.SoundService.Effect)
					task.wait(0.2)
					v_u_11:ArmFlash(p22["Right Arm"], Color3.fromRGB(255, 133, 172), 0.6)
					v_u_11:ArmFlash(p22["Left Arm"], Color3.fromRGB(255, 133, 172), 0.6)
				end
			else
				return
			end
		end,
		["Startup"] = function(p25)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v26 = p25.HumanoidRootPart
			if v26 then
				v_u_11:PlaySound(v_u_7.Uro.BlindRage.Swing3, v26, game.SoundService.Effect)
				v_u_11:ArmFlash(p25["Right Arm"], Color3.fromRGB(255, 133, 172), 0.6)
				v_u_11:ArmFlash(p25["Left Arm"], Color3.fromRGB(255, 133, 172), 0.6)
			end
		end,
		["RAGE"] = function(p27)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v28 = p27.HumanoidRootPart
			if v28 then
				v_u_11:PlaySound(v_u_7.Uro.BlindRage.DIE, v28, game.SoundService.Voice)
			end
		end,
		["Dash"] = function(p29)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_6, (ref) v_u_3
			local v_u_30 = p29.HumanoidRootPart
			if v_u_30 then
				local v31 = Instance.new("Model")
				local v32 = v_u_5.Utils.Itadori.RushWind:Clone()
				v32.CFrame = v_u_30.CFrame * CFrame.new(0, -1, 0)
				v32.Parent = v31
				v31.Parent = workspace.Effects
				v31:ScaleTo(0.6)
				v32.Ring:Emit(7)
				v32.Dash1.Dash:Emit(1)
				v32.Dash2.Dash:Emit(1)
				v_u_2:AddItem(v31, 2)
				local v33 = v_u_6.Itadori.Shock:Clone()
				v33.CFrame = v_u_30.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v33.Parent = workspace.Effects
				v_u_3:Create(v33, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(8, 0, 8),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v33, 0.2)
				task.delay(0.05, function()
					-- upvalues: (ref) v_u_6, (copy) v_u_30, (ref) v_u_3, (ref) v_u_2
					local v34 = v_u_6.Itadori.Shock:Clone()
					v34.CFrame = (v_u_30.CFrame - v_u_30.CFrame.Position + v_u_30.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
					v34.Parent = workspace.Effects
					v_u_3:Create(v34, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v34, 0.2)
				end)
			end
		end,
		["Throw"] = function(p35)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v36 = p35.HumanoidRootPart
			if v36 then
				local v37 = v_u_6.Itadori.DivergentFist.BlackFlashLaunch:Clone()
				v37.CFrame = v36.CFrame * CFrame.new(2, 1, -5)
				v37.Parent = workspace.Effects
				v37.PointLight:Destroy()
				v37.Wind:Emit(20)
				v_u_2:AddItem(v37, 3)
				local v38 = v_u_6.Choso.CounterSwing.Shock:Clone()
				v38.Size = Vector3.new(6, 30, 6)
				v38.CFrame = v36.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v38.Parent = workspace.Effects
				v_u_2:AddItem(v38, 0.2)
				v_u_3:Create(v38, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(25, 0, 25),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v38.Position + v36.CFrame.LookVector * 10
				}):Play()
				v_u_11:PlaySound(v_u_7.Uro.BlindRage.Throw, v36, game.SoundService.Effect)
				if v_u_4.Character == p35 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Grab"] = function(p39, p40)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_8
			if p39:FindFirstChild("HumanoidRootPart") then
				local v41 = p40:FindFirstChild("HumanoidRootPart")
				if v41 then
					v_u_11:Flash(p40, Color3.new(1, 1, 1))
					v_u_11:PlaySound(v_u_7.Gojo.LapseBlue.Grab, v41, game.SoundService.Effect)
					if (workspace.CurrentCamera.CFrame.Position - v41.Position).Magnitude < 200 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["Hit"] = function(p42)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_8
			local v43 = p42:FindFirstChild("HumanoidRootPart")
			if v43 then
				v_u_11:Flash(p42, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Ryu.SecondHelping.Hit, v43, game.SoundService.Effect)
				local v44 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v44.Position = v43.Position
				v44.Parent = workspace.Effects
				v_u_2:AddItem(v44, 1)
				v44.Sparks.Color = ColorSequence.new(Color3.fromRGB(255, 165, 165))
				v44.Wind.Color = v44.Sparks.Color
				v44.Wind2.Color = v44.Sparks.Color
				v44.Sparks:Emit(30)
				v44.Wind2:Emit(7)
				if (workspace.CurrentCamera.CFrame.Position - v43.Position).Magnitude < 60 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Destroy"] = function(p45)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_8
			local v46 = p45:FindFirstChild("HumanoidRootPart")
			if v46 then
				v_u_11:PlaySound(v_u_7.Megumi.Elephant.Explode, v46, game.SoundService.Effect)
				v_u_11:Bleed(p45)
				for _ = 1, 50 do
					v_u_9:Blood(v46.CFrame, 200, 360, 360)
				end
				if _G.Settings.Gore then
					local v47 = v_u_6.Heian.BloodSpread:Clone()
					v47.Parent = v46
					v47:Emit(80)
					v_u_2:AddItem(v47, 2)
				end
				for _ = 1, 20 do
					local v_u_48 = v_u_6.Damage.Chunk:Clone()
					v_u_48.CFrame = v46.CFrame
					v_u_48.CollisionGroup = "Effects"
					local v49 = math.random(-90, 90)
					local v50 = math.random(20, 50)
					local v51 = math.random
					v_u_48.Velocity = Vector3.new(v49, v50, v51(-90, 90))
					local v52 = math.random(-200, 200)
					local v53 = math.random(-200, 200)
					local v54 = math.random
					v_u_48.RotVelocity = Vector3.new(v52, v53, v54(-200, 200))
					v_u_48.Parent = workspace.Effects
					v_u_2:AddItem(v_u_48, 3)
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_48, (ref) v_u_3
						v_u_48.CanCollide = true
						task.wait(1.9)
						v_u_3:Create(v_u_48, TweenInfo.new(1), {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
						v_u_48.Blood.Enabled = false
						v_u_48.Trail.Enabled = false
					end)
					if _G.Settings.Gore ~= false then
						continue
					end
					v_u_48.Color = Color3.fromRGB(255, 85, 255)
					v_u_48.Trail.Color = ColorSequence.new(Color3.fromRGB(255, 85, 255))
					v_u_48.Blood.Color = v_u_48.Trail.Color
				end
				if (workspace.CurrentCamera.CFrame.Position - v46.Position).Magnitude < 60 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.SnapOh)
					if _G.Settings.Flash ~= true then
						return
					end
					local v55 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
					v55.Parent = game.Lighting
					task.wait(0.05)
					v55.TintColor = Color3.new(1, 1, 1)
					v55.Brightness = 200
					v55.Contrast = -1000
					task.wait(0.05)
					v55:Destroy()
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p57, ...)
		-- upvalues: (copy) v_u_56
		local v58 = v_u_56[p57]
		if v58 then
			v58(...)
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("BlindRageService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12