-- Original instance: Players.YouNeverSeenThat.PlayerScripts.PlayerModule.CameraModule.VRVehicleCamera
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = { 0, 30 }
local v_u_2 = require(script.Parent:WaitForChild("VRBaseCamera"))
local v_u_3 = require(script.Parent:WaitForChild("CameraUtils"))
local v_u_4 = require(script.Parent:WaitForChild("CameraInput"))
local v5 = game:GetService("Players")
local v_u_6 = game:GetService("RunService")
local v_u_7 = game:GetService("VRService")
local v_u_8 = game:GetService("Lighting")
local v_u_9 = v5.LocalPlayer
local v_u_10 = v_u_3.mapClamp
local v_u_11 = require(script.Parent:WaitForChild("VehicleCamera"):FindFirstChild("VehicleCameraConfig"))
local v_u_12 = RaycastParams.new()
v_u_12.FilterType = Enum.RaycastFilterType.Exclude
v_u_12.IgnoreWater = true
local function v_u_31(p13, p14, p15, p16) -- name: vrOccludeDisplace
	-- upvalues: (copy) v_u_9, (copy) v_u_12
	local v17 = p14.X
	local v18 = p14.Z
	local v19 = math.atan2(v17, v18)
	local v20 = CFrame.new(p13.Position + p14 * p15) * CFrame.Angles(0, v19, 0)
	local v21 = workspace.CurrentCamera
	if not v21 then
		return v20
	end
	local v22 = p13.Position
	local v23 = (v20.Position - v22) * Vector3.new(1, 0, 1)
	local v24 = v23.Magnitude
	if v24 < 0.5 then
		return v20
	end
	local v25 = { v21 }
	if p16 then
		table.insert(v25, p16)
	end
	local v26 = v_u_9
	if v26 then
		v26 = v_u_9.Character
	end
	if v26 then
		table.insert(v25, v26)
	end
	v_u_12.FilterDescendantsInstances = v25
	local v27 = v23.Unit
	local v28 = workspace:Raycast(v22, v23, v_u_12)
	if v28 and v28.Normal:Dot(v27) < 0 then
		local v29 = (v28.Position - v22).Magnitude - 0.5
		if v29 < v24 then
			local v30 = math.max(v29, 0.5)
			return CFrame.new(p13.Position + v27 * v30) * v20.Rotation
		end
	end
	return v20
end
local v_u_32 = OverlapParams.new()
v_u_32.FilterType = Enum.RaycastFilterType.Exclude
local function v_u_59(p33, p34, p35, p36) -- name: findObstructions
	-- upvalues: (copy) v_u_7, (copy) v_u_9, (copy) v_u_12, (copy) v_u_32
	local v37 = workspace.CurrentCamera
	if not v37 then
		return 0, {}
	end
	local v38 = p34.Position
	local v39 = v_u_7:GetUserCFrame(Enum.UserCFrame.Head)
	local v40 = v37.HeadScale
	local v41 = p33 * (CFrame.new(v39.Position * v40) * v39.Rotation)
	local v42 = v41.Position - v38
	local v43 = v42.Magnitude
	if v43 < 0.5 then
		return 0, {}
	end
	local v44 = { v37 }
	if p36 then
		table.insert(v44, p36)
	end
	local v45 = v_u_9
	if v45 then
		v45 = v_u_9.Character
	end
	if v45 then
		table.insert(v44, v45)
	end
	v_u_12.FilterDescendantsInstances = v44
	local v46 = workspace:Raycast(v38, v42, v_u_12)
	if v46 then
		local v47 = (v46.Position - v38).Magnitude
		if v47 < v43 then
			local v48 = v41.LookVector
			local v49 = (1 - -v42.Unit:Dot(v48)) / 0.1339745962155613
			local v50 = math.clamp(v49, 0, 1)
			local v51 = 1 - v47 / p35
			local v52 = math.max(v50, v51, 0.15)
			local v53 = v46.Position
			local v54 = v41.Position
			local v55 = (v53 + v54) / 2
			local v56 = (v54 - v53).Magnitude
			local v57 = Vector3.new(2, 2, v56)
			local v58 = CFrame.lookAt(v55, v54)
			v_u_32.FilterDescendantsInstances = v44
			return v52, workspace:GetPartBoundsInBox(v58, v57, v_u_32)
		end
	end
	return 0, {}
end
local v_u_60 = 0.016666666666666666
local v_u_61 = setmetatable({}, v_u_2)
v_u_61.__index = v_u_61
function v_u_61.new() -- name: new
	-- upvalues: (copy) v_u_2, (copy) v_u_61, (copy) v_u_6, (ref) v_u_60
	local v62 = v_u_2.new()
	local v63 = v_u_61
	local v64 = setmetatable(v62, v63)
	v64.skipOcclusion = true
	v64:Reset()
	if v64.thirdPersonOptionChanged then
		v64.thirdPersonOptionChanged:Disconnect()
		v64.thirdPersonOptionChanged = nil
	end
	v_u_6.Stepped:Connect(function(_, p65)
		-- upvalues: (ref) v_u_60
		v_u_60 = p65
	end)
	return v64
end
function v_u_61.Reset(p66) -- name: Reset
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v67 = workspace.CurrentCamera
	local v68
	if v67 then
		v68 = v67.CameraSubject
	else
		v68 = v67
	end
	assert(v67, "VRVehicleCamera initialization error")
	assert(v68)
	assert(v68:IsA("VehicleSeat"))
	p66.lastOrbitalDir = nil
	p66.wasInFirstPerson = nil
	local v69 = v68:GetConnectedParts(true)
	table.insert(v69, v68)
	local v70, v71 = v_u_3.getLooseBoundingSphere(v69)
	p66.vehicleModel = v68:FindFirstAncestorOfClass("Model") or v68.Parent
	p66.assemblyRadius = math.max(v71, 5)
	p66.assemblyOffset = v68.CFrame:Inverse() * v70
	p66.gamepadZoomLevels = {}
	for _, v72 in v_u_1 do
		local v73 = p66.gamepadZoomLevels
		local v74 = v72 * p66.headScale * p66.assemblyRadius / 10
		table.insert(v73, v74)
	end
	p66.lastCameraFocus = nil
	if not p66:IsInFirstPerson() then
		p66:SetCameraToSubjectDistance(p66.gamepadZoomLevels[#p66.gamepadZoomLevels])
	end
	p66.needsReset = false
end
function v_u_61._getThirdPersonLocalOffset(p75) -- name: _getThirdPersonLocalOffset
	-- upvalues: (copy) v_u_11
	local v76 = p75.assemblyOffset
	local v77 = p75.assemblyRadius * v_u_11.verticalCenterOffset
	return v76 + Vector3.new(0, v77, 0)
end
function v_u_61._getFirstPersonLocalOffset(p78, p79) -- name: _getFirstPersonLocalOffset
	-- upvalues: (copy) v_u_9
	local v80 = v_u_9.Character
	if v80 and v80.Parent then
		local v81 = v80:FindFirstChild("Head")
		if v81 and v81:IsA("BasePart") then
			return p79:Inverse() * v81.Position
		end
	end
	return p78:_getThirdPersonLocalOffset()
end
function v_u_61._vrOccludeVignette(p82, p83, p84, p85) -- name: _vrOccludeVignette
	-- upvalues: (copy) v_u_59, (copy) v_u_8, (copy) v_u_9
	local v86 = p84.X
	local v87 = p84.Z
	local v88 = math.atan2(v86, v87)
	local v89 = CFrame.new(p83.Position + p84 * p85) * CFrame.Angles(0, v88, 0)
	local v90, v91 = v_u_59(v89, p83, p85, p82.vehicleModel)
	local v92 = v_u_8:FindFirstChild("VRFade")
	if not v92 then
		v92 = Instance.new("ColorCorrectionEffect")
		v92.Name = "VRFade"
		v92.Parent = v_u_8
	end
	v92.Brightness = -v90
	if p82.lastOccludedParts then
		for _, v93 in p82.lastOccludedParts do
			v93.LocalTransparencyModifier = 0
		end
	end
	if #v91 > 0 then
		for _, v94 in v91 do
			v94.LocalTransparencyModifier = 1
		end
		p82:StartVREdgeBlur(v_u_9, true)
	end
	p82.lastOccludedParts = v91
	return v89
end
function v_u_61.Update(p95) -- name: Update
	-- upvalues: (ref) v_u_60, (copy) v_u_9
	local v96 = v_u_60
	v_u_60 = 0
	p95:UpdateFadeFromBlack(v96)
	p95:UpdateEdgeBlur(v_u_9, v96)
	local v97, v98 = p95:_updateStepRotation(v96)
	return v97, v98
end
function v_u_61._updateStepRotation(p99, p100) -- name: _updateStepRotation
	-- upvalues: (copy) v_u_10, (copy) v_u_4, (copy) v_u_11, (copy) v_u_31
	local v101 = p99:GetSubjectCFrame()
	local v102 = p99:GetCameraToSubjectDistance()
	local v103 = v_u_10(v102, 0.5, p99.assemblyRadius, 1, 0)
	local v104 = v101 * p99:_getThirdPersonLocalOffset():Lerp(p99:_getFirstPersonLocalOffset(v101), v103)
	local v105 = CFrame.new
	local v106 = p99:GetCameraHeight()
	local v107 = v105(v104 + Vector3.new(0, v106, 0))
	if p99.needsReset or p99.recentered then
		p99.lastOrbitalDir = nil
		p99.needsReset = false
		p99.recentered = false
	end
	local v108 = p99.lastOrbitalDir
	if not v108 then
		v108 = (v101.LookVector * Vector3.new(-1, 0, -1)).Unit
		p99:StartFadeFromBlack()
	end
	local v109 = (p99:GetSubjectVelocity() * Vector3.new(1, 0, 1)).Magnitude > 2
	if v109 then
		v_u_4.getRotation(p100)
	else
		local v110 = p99:getRotation(p100)
		if math.abs(v110) > 0 then
			v108 = (CFrame.Angles(0, -v110, 0) * CFrame.new(v108)).Position.Unit
			p99.lastRotateTime = os.clock()
		end
	end
	local v111
	if p99:IsInFirstPerson() then
		if not p99.wasInFirstPerson or v109 then
			v108 = (v101.LookVector * Vector3.new(-1, 0, -1)).Unit
			p99.wasInFirstPerson = true
		end
		local v112 = -v101.LookVector.X
		local v113 = -v101.LookVector.Z
		local v114 = math.atan2(v112, v113)
		if p99.lastVehicleYaw then
			local v115 = (v114 - p99.lastVehicleYaw + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
			if math.abs(v115) > 0.001 then
				v108 = (CFrame.Angles(0, v115, 0) * CFrame.new(v108)).Position.Unit
			end
		end
		p99.lastVehicleYaw = v114
		local v116 = v108.X
		local v117 = v108.Z
		local v118 = math.atan2(v116, v117)
		v111 = CFrame.new(v107.Position + v108 * v102) * CFrame.Angles(0, v118, 0)
	else
		p99.wasInFirstPerson = false
		p99.lastVehicleYaw = nil
		local v119 = p99.lastRotateTime
		if v119 then
			v119 = os.clock() - p99.lastRotateTime < v_u_11.autocorrectDelay
		end
		if v109 and not v119 then
			local v120 = (v101.LookVector * Vector3.new(-1, 0, -1)).Unit
			local v121 = v108:Dot(v120)
			local v122 = math.clamp(v121, -1, 1)
			local v123 = math.acos(v122)
			local v124 = p99:GetSubjectRotVelocity()
			local v125 = v101.YVector:Dot(v124)
			local v126 = math.abs(v125)
			local v127 = 0.01 + v123 / 3.141592653589793 * 0.05 + v126 * 0.02
			v108 = v108:Lerp(v120, (math.min(v127, 0.15)))
		end
		v111 = v_u_31(v107, v108, v102, p99.vehicleModel)
	end
	p99.lastOrbitalDir = v108
	return v111, v111 * CFrame.new(0, 0, -v102)
end
return v_u_61