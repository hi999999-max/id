-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Gojo.Awake.HollowPurpleController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "HollowPurpleController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (ref) v_u_11, (copy) v_u_8, (copy) v_u_4, (copy) v_u_7, (copy) v_u_5, (copy) v_u_9, (copy) v_u_3, (copy) v_u_2, (ref) v_u_10
	local v_u_54 = {
		["Aerial"] = function(p14, p15)
			-- upvalues: (ref) v_u_12
			local v16 = p14:FindFirstChild("HumanoidRootPart")
			if v16 then
				local v17 = p14:FindFirstChild("Humanoid")
				if v17 then
					local v18 = Instance.new("BodyGyro", v16)
					v18.P = 10000
					v18.MaxTorque = Vector3.new(40000, 40000, 40000)
					p15.Position = v16.Position + Vector3.new(0, 6, 0)
					v17.PlatformStand = true
					repeat
						local v19 = v_u_12:GetMouseTarget()
						v18.CFrame = CFrame.new(v16.Position, v19)
						task.wait()
					until not p15.Parent
					v18:Destroy()
					v17.PlatformStand = false
				end
			else
				return
			end
		end,
		["Purple"] = function(p20, p21)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_7, (ref) v_u_5, (ref) v_u_9, (ref) v_u_3
			local v22 = p20:FindFirstChild("HumanoidRootPart")
			if v22 then
				if not workspace:FindFirstChild("Music") then
					v_u_4:Create(v_u_11:PlaySound(v_u_8.Gojo.HollowPurple.Music, v22, game.SoundService.Music), TweenInfo.new(0.5), {
						["Volume"] = 1.25
					}):Play()
				end
				local v23 = v_u_7.Gojo.HollowPurple.Blue:Clone()
				v23.Weld.Part0 = v22
				v23.Parent = p21
				local v24 = v_u_7.Gojo.HollowPurple.Red:Clone()
				v24.Weld.Part0 = v22
				v24.Parent = p21
				v_u_4:Create(v23, TweenInfo.new(0.25), {
					["Transparency"] = 0
				}):Play()
				v_u_4:Create(v23.PointLight, TweenInfo.new(0.25), {
					["Brightness"] = 20
				}):Play()
				v_u_4:Create(v24, TweenInfo.new(0.25), {
					["Transparency"] = 0
				}):Play()
				v_u_4:Create(v24.PointLight, TweenInfo.new(0.25), {
					["Brightness"] = 20
				}):Play()
				v23.Mid.Charge:Emit(2)
				v24.Mid.Charge:Emit(2)
				v_u_11:PlaySound(v_u_8.Gojo.HollowPurple.Merge, v22, game.SoundService.Effect)
				task.wait(0.25)
				if v_u_5.Character == p20 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
				end
				for _, v25 in p21:GetDescendants() do
					if v25.Name == "Sparks" then
						v25:Emit(20)
					elseif v25.Name == "Stars" then
						v25:Emit(7)
					elseif v25.Name == "Beam2" or v25.Name == "Smoke" then
						v25.Enabled = true
					else
						if not v25:IsA("Decal") then
							continue
						end
						v25.Transparency = 0.1
					end
				end
				v23.Material = Enum.Material.Granite
				v24.Material = Enum.Material.Granite
				v_u_4:Create(v23.Weld, TweenInfo.new(1, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
					["C1"] = CFrame.new(0, 0, 9)
				}):Play()
				v_u_4:Create(v24.Weld, TweenInfo.new(1, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
					["C1"] = CFrame.new(0, 0, -9) * CFrame.Angles(0, 3.141592653589793, 0)
				}):Play()
				task.wait(1)
				v23:Destroy()
				v24:Destroy()
				local v_u_26 = v_u_7.Gojo.HollowPurple.Purple:Clone()
				v_u_26.Weld.Part0 = v22
				v_u_26.Parent = p21
				v_u_4:Create(v_u_26, TweenInfo.new(1, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(15, 15, 15)
				}):Play()
				v_u_4:Create(v_u_26.Weld, TweenInfo.new(1, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out), {
					["C1"] = CFrame.new(0, -3, 13)
				}):Play()
				v_u_4:Create(v_u_26.PointLight, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Brightness"] = 10
				}):Play()
				task.spawn(function()
					-- upvalues: (copy) v_u_26, (ref) v_u_4, (ref) v_u_3
					local v27 = Instance.new("Highlight", v_u_26.Warp)
					v27.FillTransparency = 1
					v27.OutlineTransparency = 1
					v_u_4:Create(v_u_26.Warp, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["Size"] = Vector3.new(40, 40, 40),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v_u_26.Warp, 0.5)
				end)
				if v_u_5.Character == p20 then
					local v28 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.LightHit)
					repeat
						task.wait()
					until not p21.Parent
					v28:StartFadeOut(1)
				end
			end
		end,
		["Launch"] = function(p29)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v30 = p29:FindFirstChild("HumanoidRootPart")
			if v30 then
				local v31 = v_u_7.Gojo.HollowPurple.PurpleSnap.Center:Clone()
				v31.Parent = p29["Right Arm"]
				v31.Ring:Emit(1)
				v31.Star:Emit(1)
				v31.Wave:Emit(1)
				v31.Snap1:Emit(20)
				v_u_3:AddItem(v31, 1)
				v_u_11:PlaySound(v_u_8.Gojo.HollowPurple.Snap, v30, game.SoundService.Effect)
				if v_u_5.Character == p29 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Interp"] = function(p_u_32, _)
			-- upvalues: (ref) v_u_2
			local v_u_33 = p_u_32.CFrame
			local v_u_34 = tick()
			local v_u_35 = p_u_32:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_33, (copy) p_u_32, (ref) v_u_34
				v_u_33 = p_u_32.CFrame
				v_u_34 = tick()
			end)
			local v_u_36 = nil
			v_u_36 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_32, (ref) v_u_36, (copy) v_u_35, (ref) v_u_33, (ref) v_u_34
				if p_u_32.Parent then
					workspace:BulkMoveTo({ p_u_32 }, { v_u_33 + v_u_33.LookVector * (200 * (tick() - v_u_34)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_36:Disconnect()
					v_u_35:Disconnect()
				end
			end)
		end,
		["Hit"] = function(p37)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v38 = p37:FindFirstChild("HumanoidRootPart")
			if v38 then
				v_u_11:Flash(p37, Color3.fromRGB(255, 85, 255), 2)
				v_u_11:PlaySound(v_u_8.Gojo.HollowPurple.Hit, v38, game.SoundService.Effect)
			end
		end,
		["Finisher"] = function(p39)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7
			local v40 = p39:FindFirstChild("HumanoidRootPart")
			if v40 then
				v_u_11:PlaySound(v_u_8.Gojo.HollowPurple.Hit, v40, game.SoundService.Effect)
				for _, v41 in p39:GetDescendants() do
					if not (v41:IsA("BasePart") or v41:IsA("Decal")) then
						continue
					end
					v41.Transparency = 1
				end
				p39["Left Leg"].Transparency = 0
				local v42 = v_u_7.Damage.LegBurn:Clone()
				v42.Weld.Part1 = p39["Left Leg"]
				local v43 = v42.Weld
				v43.C1 = v43.C1 * CFrame.new(0, 1, 0)
				v42.Parent = p39
				p39["Right Leg"].Transparency = 0
				local v44 = v_u_7.Damage.LegBurn:Clone()
				v44.Weld.Part1 = p39["Right Leg"]
				local v45 = v44.Weld
				v45.C1 = v45.C1 * CFrame.new(0, 1, 0)
				v44.Parent = p39
			end
		end,
		["PurpleStandalone"] = function(p46)
			-- upvalues: (ref) v_u_3, (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_7
			local v47 = Instance.new("Part")
			v47.Anchored = true
			v47.CFrame = p46
			v47.Transparency = 1
			v47.CanCollide = false
			v47.Parent = workspace.Effects
			v_u_3:AddItem(v47, 10)
			if not workspace:FindFirstChild("Music") then
				v_u_4:Create(v_u_11:PlaySound(v_u_8.Gojo.HollowPurple.Music, v47, game.SoundService.Music), TweenInfo.new(0.5), {
					["Volume"] = 1.25
				}):Play()
			end
			local v48 = v_u_7.Gojo.HollowPurple.Blue:Clone()
			v48.Weld.Part0 = v47
			v48.Parent = v47
			local v49 = v_u_7.Gojo.HollowPurple.Red:Clone()
			v49.Weld.Part0 = v47
			v49.Parent = v47
			v_u_4:Create(v48, TweenInfo.new(0.25), {
				["Transparency"] = 0
			}):Play()
			v_u_4:Create(v48.PointLight, TweenInfo.new(0.25), {
				["Brightness"] = 20
			}):Play()
			v_u_4:Create(v49, TweenInfo.new(0.25), {
				["Transparency"] = 0
			}):Play()
			v_u_4:Create(v49.PointLight, TweenInfo.new(0.25), {
				["Brightness"] = 20
			}):Play()
			v48.Mid.Charge:Emit(2)
			v49.Mid.Charge:Emit(2)
			v_u_11:PlaySound(v_u_8.Gojo.HollowPurple.Merge, v47, game.SoundService.Effect)
			task.wait(0.25)
			for _, v50 in v47:GetDescendants() do
				if v50.Name == "Sparks" then
					v50:Emit(20)
				elseif v50.Name == "Stars" then
					v50:Emit(7)
				elseif v50.Name == "Beam2" or v50.Name == "Smoke" then
					v50.Enabled = true
				else
					if not v50:IsA("Decal") then
						continue
					end
					v50.Transparency = 0.1
				end
			end
			v48.Material = Enum.Material.Granite
			v49.Material = Enum.Material.Granite
			v_u_4:Create(v48.Weld, TweenInfo.new(1, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
				["C1"] = CFrame.new(0, 0, 9)
			}):Play()
			v_u_4:Create(v49.Weld, TweenInfo.new(1, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
				["C1"] = CFrame.new(0, 0, -9) * CFrame.Angles(0, 3.141592653589793, 0)
			}):Play()
			task.wait(1)
			v48:Destroy()
			v49:Destroy()
			local v_u_51 = v_u_7.Gojo.HollowPurple.Purple:Clone()
			v_u_51.Weld.Part0 = v47
			v_u_51.Parent = v47
			v_u_4:Create(v_u_51, TweenInfo.new(1, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out), {
				["Size"] = Vector3.new(15, 15, 15)
			}):Play()
			v_u_4:Create(v_u_51.Weld, TweenInfo.new(1, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out), {
				["C1"] = CFrame.new(0, -3, 13)
			}):Play()
			v_u_4:Create(v_u_51.PointLight, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
				["Brightness"] = 10
			}):Play()
			v_u_51.Color = Color3.fromRGB(255, 85, 0)
			v_u_51.Center.Core.Color = ColorSequence.new(Color3.fromRGB(255, 255, 255), Color3.fromRGB(255, 0, 0))
			v_u_51.Lightning.Color = ColorSequence.new(Color3.fromRGB(255, 85, 0))
			v_u_51.Lightning2.Color = ColorSequence.new(Color3.fromRGB(255, 30, 0))
			v_u_51.PointLight.Color = Color3.fromRGB(255, 85, 0)
			task.spawn(function()
				-- upvalues: (copy) v_u_51, (ref) v_u_4, (ref) v_u_3
				local v52 = Instance.new("Highlight", v_u_51.Warp)
				v52.FillTransparency = 1
				v52.OutlineTransparency = 1
				v_u_4:Create(v_u_51.Warp, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(40, 40, 40),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v_u_51.Warp, 0.5)
			end)
			task.wait(1.5)
			v_u_11:PlaySound(v_u_8.Gojo.HollowPurple.Snap, v47, game.SoundService.Effect)
			for _, v53 in v47:GetChildren() do
				if not v53:IsA("BasePart") then
					continue
				end
				v53:Destroy()
			end
		end
	}
	v_u_10.Effects:Connect(function(p55, ...)
		-- upvalues: (copy) v_u_54
		local v56 = v_u_54[p55]
		if v56 then
			v56(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("HollowPurpleService")
	v_u_11 = v_u_1.GetController("FXController")
	v_u_12 = v_u_1.GetController("ToolController")
end
return v13