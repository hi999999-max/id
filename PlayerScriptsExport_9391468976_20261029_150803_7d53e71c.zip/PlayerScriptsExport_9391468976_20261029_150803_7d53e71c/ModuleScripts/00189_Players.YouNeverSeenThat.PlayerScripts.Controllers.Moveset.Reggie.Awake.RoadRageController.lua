-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Reggie.Awake.RoadRageController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "RoadRageController"
})
function v14.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (copy) v_u_4, (ref) v_u_13, (copy) v_u_2, (ref) v_u_10
	local v_u_66 = {
		["Hit"] = function(p15, p16)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			if p15:FindFirstChild("HumanoidRootPart") then
				local v17 = p16:FindFirstChild("HumanoidRootPart")
				if v17 then
					v_u_12:Flash(p16, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Reggie.RoadRage["Hit" .. math.random(1, 3)], v17, game.SoundService.Effect)
					local v18 = v_u_7.Mahito.CrushingRushdown.DrillImpact:Clone()
					v18.Position = v17.Position
					v18.Parent = workspace.Effects
					v_u_3:AddItem(v18, 1)
					v18.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 1))
					v18.Wind.Color = v18.Sparks.Color
					v18.Wind2.Color = v18.Sparks.Color
					v18.Sparks:Emit(50)
					v18.Wind2:Emit(7)
					if v_u_5.Character == p15 or v_u_5.Character == p16 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["Hitbox"] = function(p19)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_13
			local v20 = v_u_7.Megumi.HitArea:Clone()
			v20.Size = Vector3.new(15, 0, 15)
			for _, v21 in v20:GetChildren() do
				local v22 = v21.Transparency
				v21.Transparency = 1
				v_u_4:Create(v21, TweenInfo.new(0.4), {
					["Transparency"] = v22
				}):Play()
			end
			v20.Parent = workspace.Effects
			v_u_4:Create(v20, TweenInfo.new(9), {
				["Size"] = Vector3.new(0, 0, 0)
			}):Play()
			local v23 = v_u_13:GetMouseTarget(200)
			local v24 = workspace:Raycast(v23 + Vector3.new(0, 1, 0), Vector3.new(0, -300, 0), _G.MapParams)
			if v24 then
				v23 = v24.Position
			end
			v20.Position = v23 + Vector3.new(0, 0.01, 0)
			p19:FireServer(v23)
			task.wait(0.025)
			if p19 and p19.Parent then
				continue
			end
			v20:Destroy()
		end,
		["CarInterp"] = function(p_u_25)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_9
			local v_u_26 = 0
			for _, v27 in p_u_25.Car:GetChildren() do
				if not v27:GetAttribute("Color") then
					continue
				end
				v27.BrickColor = BrickColor.new(p_u_25:GetAttribute("C"))
			end
			local v_u_28 = CFrame.new(3.158, -0.853, 11.508) * CFrame.Angles(0, 3.141592653589793, 0)
			local v_u_29 = CFrame.new(-3.158, -0.853, 11.508) * CFrame.Angles(0, 3.141592653589793, 0)
			local v_u_30 = p_u_25.Root
			v_u_12:PlaySound(v_u_8.Reggie.RoadRage.CarStart, v_u_30, game.SoundService.Effect)
			task.delay(0.4, function()
				-- upvalues: (ref) v_u_12, (ref) v_u_8, (copy) v_u_30
				v_u_12:PlaySound(v_u_8.Reggie.RoadRage.CarLoop, v_u_30, game.SoundService.Effect)
			end)
			local v_u_31 = v_u_7.Misc.SmokeTrail:Clone()
			v_u_31.Parent = p_u_25
			v_u_31.CFrame = v_u_30.CFrame * v_u_28
			v_u_3:AddItem(v_u_31, 20)
			local v_u_32 = v_u_7.Misc.SmokeTrail:Clone()
			v_u_32.Parent = p_u_25
			v_u_32.CFrame = v_u_30.CFrame * v_u_29
			v_u_3:AddItem(v_u_32, 20)
			if v_u_28 then
				v_u_31.Dash.Smoke.Enabled = true
				local v33 = workspace:Raycast((v_u_30.CFrame * v_u_28).Position, Vector3.new(0, -3, 0), _G.MapParams)
				if v33 then
					v_u_31.Position = v33.Position
					v_u_31.Dash.Smoke:Emit(15)
				end
			end
			if v_u_29 then
				v_u_32.Dash.Smoke.Enabled = true
				local v34 = workspace:Raycast((v_u_30.CFrame * v_u_29).Position, Vector3.new(0, -3, 0), _G.MapParams)
				if v34 then
					v_u_32.Position = v34.Position
					v_u_32.Dash.Smoke:Emit(15)
				end
			end
			local v_u_35 = p_u_25.Root.CFrame
			local v_u_36 = p_u_25.Root.CFrame
			local v_u_37 = p_u_25.Root.CFrame
			local v_u_38 = tick()
			local v_u_39 = 0.05
			local v_u_45 = p_u_25.Root:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (copy) p_u_25, (ref) v_u_35, (ref) v_u_39, (ref) v_u_38, (ref) v_u_36, (ref) v_u_37
				if p_u_25.Root.CFrame ~= v_u_35 then
					local v40 = v_u_39
					local v41 = tick() - v_u_38
					v_u_39 = v40 + (math.clamp(v41, 0.016666666666666666, 0.2) - v_u_39) * 0.2
					local v42 = v_u_35
					local v43 = p_u_25.Root.CFrame
					local v44 = tick()
					v_u_36 = v42
					v_u_37 = v43
					v_u_38 = v44
				end
			end)
			local v_u_46 = nil
			local v_u_47 = nil
			local v_u_48 = nil
			v_u_48 = v_u_2.RenderStepped:Connect(function()
				-- upvalues: (copy) p_u_25, (ref) v_u_48, (copy) v_u_45, (copy) v_u_31, (ref) v_u_35, (ref) v_u_36, (ref) v_u_37, (ref) v_u_38, (ref) v_u_39, (ref) v_u_26, (ref) v_u_9, (copy) v_u_30, (copy) v_u_28, (copy) v_u_29, (ref) v_u_46, (copy) v_u_32, (ref) v_u_47
				if p_u_25 and p_u_25.Parent then
					if v_u_31 and v_u_31.Parent then
						local v49 = v_u_36
						local v50 = v_u_37
						local v51 = (tick() - v_u_38) / (v_u_39 * 1.25)
						v_u_35 = v49:Lerp(v50, (math.min(v51, 1)))
						workspace:BulkMoveTo({ p_u_25.Root }, { v_u_35 }, Enum.BulkMoveMode.FireCFrameChanged)
						if (workspace.CurrentCamera.CFrame.Position - p_u_25.Root.Position).Magnitude < 90 and tick() - v_u_26 > 0.25 then
							v_u_26 = tick()
							v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
						end
						local v52 = workspace:Raycast((v_u_30.CFrame * v_u_28).Position, Vector3.new(0, -3, 0), _G.MapParams)
						local v53 = workspace:Raycast((v_u_30.CFrame * v_u_29).Position, Vector3.new(0, -3, 0), _G.MapParams)
						if v52 then
							if v_u_28 then
								v_u_31.Dash.Smoke.Enabled = true
							end
							v_u_31.Position = v52.Position
							v_u_31.Velocity = v_u_30.Velocity
							if v_u_46 then
								if v_u_46.Color.Keypoints[1].Value ~= v52.Instance.Color then
									v_u_46.Enabled = false
									v_u_46 = v_u_46:Clone()
									v_u_46.Color = ColorSequence.new(v52.Instance.Color)
									v_u_46.Enabled = true
									v_u_46.Parent = v_u_31
								end
							else
								v_u_46 = v_u_31.Smoke
								v_u_46.Color = ColorSequence.new(v52.Instance.Color)
								v_u_46.Enabled = true
							end
						else
							v_u_31.Dash.Smoke.Enabled = false
							if v_u_46 then
								v_u_46.Enabled = false
							end
						end
						if v53 and v52 then
							if v_u_29 then
								v_u_32.Dash.Smoke.Enabled = true
							end
							v_u_32.Position = v53.Position
							v_u_32.Velocity = v_u_30.Velocity
							if not v_u_47 then
								v_u_47 = v_u_31.Smoke
								v_u_47.Color = ColorSequence.new(v52.Instance.Color)
								v_u_47.Enabled = true
								return
							end
							if v_u_47.Color.Keypoints[1].Value ~= v52.Instance.Color then
								v_u_47.Enabled = false
								v_u_47 = v_u_47:Clone()
								v_u_47.Color = ColorSequence.new(v52.Instance.Color)
								v_u_47.Enabled = true
								v_u_47.Parent = v_u_31
								return
							end
						else
							v_u_32.Dash.Smoke.Enabled = false
							if v_u_47 then
								v_u_47.Enabled = false
							end
						end
					else
						v_u_48:Disconnect()
						v_u_45:Disconnect()
					end
				else
					v_u_48:Disconnect()
					v_u_45:Disconnect()
					return
				end
			end)
		end,
		["Crush2"] = function(p54)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9
			local v55 = v_u_7.Megumi.Mahoraga.Earthquake:Clone()
			v55.Position = p54
			v55.Parent = workspace.Effects
			v55.Air:Destroy()
			v_u_4:Create(v55.PointLight, TweenInfo.new(0.6), {
				["Brightness"] = 0
			}):Play()
			v_u_4:Create(v55.Floor.Ring2, TweenInfo.new(0.4), {
				["TimeScale"] = 0.5
			}):Play()
			v55.Floor.Ring2:Emit(10)
			v55.Floor.Wind2:Emit(15)
			v55.Floor.Dust:Emit(100)
			v_u_3:AddItem(v55, 3)
			local v56 = v_u_7.Reggie.Explosion:Clone()
			local v57 = Instance.new("Model")
			v56.Parent = v57
			v57:ScaleTo(2.5)
			v_u_3:AddItem(v57, 0.2)
			v56.Parent = workspace.Effects
			v56.WorldCFrame = CFrame.new(p54) * CFrame.new(0, 3.5, 0)
			for _, v58 in v56:GetDescendants() do
				if not v58:IsA("ParticleEmitter") then
					continue
				end
				v58:Emit(v58:GetAttribute("EmitCount"))
			end
			v_u_3:AddItem(v56, 3)
			v_u_12:PlaySound(v_u_8.Reggie.SpeedCrash.Explode, v55, game.SoundService.Effect).PlaybackSpeed = 1.25
			v_u_12:PlaySound(v_u_8.Itadori.CrushingBlow.GroundImpact, v55, game.SoundService.Effect)
			v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Earthquake.Success, v55, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p54).Magnitude < 125 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
			end
		end,
		["Finisher"] = function(p59)
			-- upvalues: (ref) v_u_12
			if p59:FindFirstChild("HumanoidRootPart") then
				v_u_12:Bleed(p59)
				local v60 = {
					"Torso",
					"Left Arm",
					"Right Arm",
					"Left Leg",
					"Right Leg",
					"Head"
				}
				for _, v61 in pairs(p59:GetChildren()) do
					if not table.find(v60, v61.Name) then
						continue
					end
					if v61.Name == "Head" then
						local v62 = v61.Mesh
						v62.Scale = v62.Scale * Vector3.new(1, 1, 0.05)
					else
						v61.Size = v61.Size * Vector3.new(1, 1, 0.05)
					end
				end
				for _, v63 in p59:GetChildren() do
					if not v63:IsA("Accessory") then
						continue
					end
					local v64 = v63:FindFirstChild("Handle")
					if not v64 then
						continue
					end
					local v65 = v64:FindFirstChildOfClass("SpecialMesh")
					if v65 then
						v65.Scale = v65.Scale * Vector3.new(1, 1, 0.05)
					else
						v64.Size = v64.Size * Vector3.new(1, 1, 0.05)
					end
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p67, ...)
		-- upvalues: (copy) v_u_66
		local v68 = v_u_66[p67]
		if v68 then
			v68(...)
		end
	end)
end
function v14.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13
	v_u_10 = v_u_1.GetService("RoadRageService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
	v_u_13 = v_u_1.GetController("ToolController")
end
return v14