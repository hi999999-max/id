-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Ryu.Awake.HadNoIdeaController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "HadNoIdeaController"
})
function v11.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_10, (copy) v_u_7, (copy) v_u_6, (copy) v_u_3, (copy) v_u_2, (copy) v_u_8, (copy) v_u_4, (ref) v_u_9
	local v_u_37 = {
		["Startup"] = function(p12)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v13 = p12:FindFirstChild("HumanoidRootPart")
			if v13 then
				v_u_10:PlaySound(v_u_7.Ryu.HadNoIdea.Startup, v13, game.SoundService.Effect)
			end
		end,
		["Swing"] = function(p14)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_10:PlaySound(v_u_7.Ryu.Unsatisfied.Weave, v15, game.SoundService.Effect)
			end
		end,
		["Ow"] = function(p16)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_8
			local v17 = p16:FindFirstChild("HumanoidRootPart")
			if v17 then
				v_u_10:Flash(p16, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.Ryu.Dessert.Hit, v17, game.SoundService.Effect)
				for _ = 1, 2 do
					local v18 = math.random(300, 500) / 10
					local v19 = v_u_6.Gojo.LapseBlue.Throw:Clone()
					v19.Transparency = 0.7
					v19.Position = p16.Head.Position
					local v20 = math.random(-180, 180)
					local v21 = math.random(-180, 180)
					local v22 = math.random
					v19.Orientation = Vector3.new(v20, v21, v22(-180, 180))
					v19.Size = Vector3.new(0, 0, 7)
					v19.Parent = workspace.Effects
					v_u_3:Create(v19, TweenInfo.new(0.15, Enum.EasingStyle.Quad), {
						["Size"] = nil,
						["Transparency"] = 1,
						["Size"] = Vector3.new(v18, v18, 0)
					}):Play()
					v_u_2:AddItem(v19, 0.15)
					task.wait(0.025)
				end
				if (workspace.CurrentCamera.CFrame.Position - v17.Position).Magnitude < 60 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["StartHit"] = function(p23, p24, p25)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v26 = p23:FindFirstChild("HumanoidRootPart")
			if v26 then
				local v27 = p24:FindFirstChild("HumanoidRootPart")
				if v27 then
					local v28 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
					v28.Position = v27.Position
					v28.Parent = workspace.Effects
					v_u_2:AddItem(v28, 1)
					v28.Sparks.Color = ColorSequence.new(Color3.fromRGB(170, 255, 255))
					v28.Wind.Color = v28.Sparks.Color
					v28.Wind2.Color = v28.Sparks.Color
					v28.Sparks:Emit(50)
					v28.Wind:Emit(7)
					v28.Wind2:Emit(7)
					v_u_10:Flash(p24, Color3.new(1, 1, 1))
					local v_u_29 = v_u_10:PlaySound(v_u_7.Ryu.HadNoIdea.Hit, v26, game.SoundService.Effect)
					p25.AncestryChanged:Once(function()
						-- upvalues: (copy) v_u_29, (ref) v_u_3
						if v_u_29.TimePosition < 1.3 then
							v_u_3:Create(v_u_29, TweenInfo.new(0.3), {
								["Volume"] = 0
							}):Play()
						end
					end)
					if v_u_4.Character == p23 or v_u_4.Character == p24 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.SnapOh)
					end
				end
			else
				return
			end
		end,
		["Hit"] = function(p30, p31)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			if p30:FindFirstChild("HumanoidRootPart") then
				local v32 = p31:FindFirstChild("HumanoidRootPart")
				if v32 then
					v_u_10:Flash(p31, Color3.new(1, 1, 1))
					v_u_10:PlaySound(v_u_7.Naoya.Decisive.SecondHit, v32, game.SoundService.Effect)
					if v_u_4.Character == p30 or v_u_4.Character == p31 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
					end
				end
			else
				return
			end
		end,
		["FinalHit"] = function(p33, p34)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			if p33:FindFirstChild("HumanoidRootPart") then
				local v35 = p34:FindFirstChild("HumanoidRootPart")
				if v35 then
					local v36 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
					v36.Position = v35.Position
					v36.Parent = workspace.Effects
					v_u_2:AddItem(v36, 1)
					v36.Sparks.Color = ColorSequence.new(Color3.fromRGB(170, 255, 255))
					v36.Wind.Color = v36.Sparks.Color
					v36.Wind2.Color = v36.Sparks.Color
					v36.Sparks:Emit(50)
					v36.Wind:Emit(7)
					v36.Wind2:Emit(7)
					v_u_10:Flash(p34, Color3.new(1, 1, 1))
					v_u_10:PlaySound(v_u_7.Hakari.EnergySurge.Hit1, v35, game.SoundService.Effect)
					if v_u_4.Character == p33 or v_u_4.Character == p34 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
					end
				end
			else
				return
			end
		end
	}
	v_u_9.Effects:Connect(function(p38, ...)
		-- upvalues: (copy) v_u_37
		local v39 = v_u_37[p38]
		if v39 then
			v39(...)
		end
	end)
end
function v11.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("HadNoIdeaService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11