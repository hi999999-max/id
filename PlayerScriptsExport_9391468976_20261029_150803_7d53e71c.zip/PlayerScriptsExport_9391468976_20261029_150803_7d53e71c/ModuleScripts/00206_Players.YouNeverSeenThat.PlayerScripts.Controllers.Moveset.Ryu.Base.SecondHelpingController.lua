-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Ryu.Base.SecondHelpingController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v4 = game.ReplicatedStorage
local _ = v4.Animations
local v_u_5 = v4.Utils
local v_u_6 = v4.Sounds
local v_u_7 = require(v4.Modules.CameraShaker)
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "SecondHelpingController"
})
function v11.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_9, (copy) v_u_6, (copy) v_u_5, (copy) v_u_1, (copy) v_u_2, (copy) v_u_3, (copy) v_u_7, (ref) v_u_8
	local v_u_38 = {
		["Startup"] = function(p12, p13)
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_5, (ref) v_u_1
			local v14 = p12:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_9:PlaySound(v_u_6.Ryu.SecondHelping.Startup, v14, game.SoundService.Effect)
				local v15 = CFrame.lookAt(v14.Position, p13)
				for _, v16 in v_u_5.Ryu.Doosh:GetChildren() do
					v16:PivotTo(v15 * CFrame.Angles(1.5707963267948966, 0, 0))
					v_u_1.GetController("MokouController"):ArcTween(v16.Start, true)
				end
			end
		end,
		["Swing"] = function(p17)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_3
			local v18 = p17:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = v_u_5.Ryu.Slash:Clone()
				v19.Weld.Part0 = v18
				v19.Weld.C0 = CFrame.Angles(0, 0, -1.3962634015954636)
				v19.Parent = workspace.Effects
				v_u_2:AddItem(v19, 0.2)
				local v20 = TweenInfo.new(0.2, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
				local v21 = TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				v_u_3:Create(v19.Weld, v20, {
					["C1"] = CFrame.Angles(0, 2.9670597283903604, 0)
				}):Play()
				for _, v22 in v19:GetDescendants() do
					if v22:IsA("Decal") then
						v_u_3:Create(v22, v21, {
							["Transparency"] = 1
						}):Play()
					else
						if not v22:IsA("SpecialMesh") then
							continue
						end
						v_u_3:Create(v22, v20, {
							["Scale"] = v22.Scale * 1.7
						}):Play()
					end
				end
			end
		end,
		["Crush"] = function(p23)
			-- upvalues: (ref) v_u_5, (ref) v_u_3, (ref) v_u_2, (ref) v_u_9, (ref) v_u_6
			local v24 = v_u_5.Hiromi.Shockwave:Clone()
			v24.Position = p23
			v24.Parent = workspace.Effects
			local v25 = v24.CFrame
			local v26 = CFrame.Angles
			local v27 = math.random(-179, 179)
			v24.CFrame = v25 * v26(0, math.rad(v27), 0)
			v_u_3:Create(v24.mesh.Mesh, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
				["Scale"] = Vector3.new(15, 0, 15)
			}):Play()
			v_u_3:Create(v24.mesh.Decal, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
				["Transparency"] = 1
			}):Play()
			v24.Floor.Glow:Emit(1)
			v24.Floor.Ring:Emit(10)
			v_u_2:AddItem(v24, 1.5)
			local v28 = v_u_5.Choso.CounterSwing.Shock:Clone()
			v28.Size = Vector3.new(10, 30, 10)
			v28.CFrame = CFrame.new(p23)
			v28.Parent = workspace.Effects
			v_u_2:AddItem(v28, 0.3)
			v_u_3:Create(v28, TweenInfo.new(0.3), {
				["Size"] = Vector3.new(36, 7, 36),
				["Transparency"] = 1,
				["Position"] = nil,
				["Position"] = v28.Position - Vector3.new(0, 3, 0)
			}):Play()
			local v29 = v_u_5.Choso.CounterSwing.Shock:Clone()
			v29.Size = Vector3.new(20, 10, 20)
			v29.CFrame = CFrame.new(p23)
			v29.Parent = workspace.Effects
			v_u_2:AddItem(v29, 0.2)
			v_u_3:Create(v29, TweenInfo.new(0.2), {
				["Size"] = Vector3.new(0, 36, 0),
				["Transparency"] = 1,
				["Position"] = nil,
				["Position"] = v29.Position + Vector3.new(0, 10, 0)
			}):Play()
			v_u_9:DustBreak(p23 + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
			v_u_9:PlaySound(v_u_6.Megumi.Mahoraga.Throw.Break, v24, game.SoundService.Effect)
			v_u_9:PlaySound(v_u_6.Hakari.Impact, v24, game.SoundService.Effect)
		end,
		["Hit"] = function(p30)
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_5, (ref) v_u_2, (ref) v_u_7
			local v31 = p30:FindFirstChild("HumanoidRootPart")
			if v31 then
				v_u_9:Flash(p30, Color3.new(1, 1, 1))
				v_u_9:PlaySound(v_u_6.Ryu.SecondHelping.Hit, v31, game.SoundService.Effect)
				local v32 = v_u_5.Mahito.CrushingRushdown.DrillImpact:Clone()
				v32.Position = v31.Position
				v32.Parent = workspace.Effects
				v_u_2:AddItem(v32, 1)
				v32.Sparks.Color = ColorSequence.new(Color3.fromRGB(170, 255, 255))
				v32.Wind.Color = v32.Sparks.Color
				v32.Wind2.Color = v32.Sparks.Color
				v32.Sparks:Emit(30)
				v32.Wind2:Emit(7)
				if (workspace.CurrentCamera.CFrame.Position - v31.Position).Magnitude < 60 then
					v_u_7.CurrentShaker:Shake(v_u_7.Presets.HeavyHit)
				end
			end
		end,
		["HitPact"] = function(p33, p34)
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_5, (ref) v_u_3, (ref) v_u_2, (ref) v_u_7
			local v35 = p33:FindFirstChild("HumanoidRootPart")
			if v35 then
				local v_u_36 = p34:FindFirstChild("HumanoidRootPart")
				if v_u_36 then
					v_u_9:Flash(p33, Color3.new(1, 1, 1))
					v_u_9:PlaySound(v_u_6.Ryu.SecondHelping.AirHit, v_u_36, game.SoundService.Effect)
					local v_u_37 = v_u_5.Gojo.LapseBlue.Throw:Clone()
					v_u_37.CFrame = (v35.CFrame - v35.Position + v_u_36.Position) * CFrame.Angles(1.9198621771937625, 0, 0)
					v_u_37.Size = Vector3.new(0, 0, 7)
					v_u_37.Parent = workspace.Effects
					v_u_3:Create(v_u_37, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Size"] = Vector3.new(12, 12, 1)
					}):Play()
					v_u_2:AddItem(v_u_37, 0.9)
					task.delay(0.5, function()
						-- upvalues: (ref) v_u_3, (copy) v_u_37, (ref) v_u_9, (ref) v_u_6, (copy) v_u_36
						v_u_3:Create(v_u_37, TweenInfo.new(0.4, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
							["Size"] = Vector3.new(25, 25, 0),
							["Transparency"] = 1
						}):Play()
						task.wait(0.2)
						v_u_9:PlaySound(v_u_6.Ryu.SecondHelping.AirHit2, v_u_36, game.SoundService.Effect)
					end)
					if (workspace.CurrentCamera.CFrame.Position - v35.Position).Magnitude < 60 then
						v_u_7.CurrentShaker:Shake(v_u_7.Presets.Snap)
					end
				end
			else
				return
			end
		end
	}
	v_u_8.Effects:Connect(function(p39, ...)
		-- upvalues: (copy) v_u_38
		local v40 = v_u_38[p39]
		if v40 then
			v40(...)
		end
	end)
end
function v11.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_8, (copy) v_u_1, (ref) v_u_9, (ref) v_u_10
	v_u_8 = v_u_1.GetService("SecondHelpingService")
	v_u_9 = v_u_1.GetController("FXController")
	v_u_10 = v_u_1.GetController("ToolController")
end
return v11