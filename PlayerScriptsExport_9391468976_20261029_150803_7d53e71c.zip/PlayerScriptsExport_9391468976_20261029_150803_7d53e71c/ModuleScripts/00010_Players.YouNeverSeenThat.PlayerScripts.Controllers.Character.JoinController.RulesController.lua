-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Character.JoinController.RulesController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
game:GetService("TweenService")
local v_u_2 = game.Players.LocalPlayer
local v3 = game.ReplicatedStorage
local _ = v3.Animations
local _ = v3.Utils
local _ = v3.Sounds
local v_u_4 = nil
local v_u_5 = nil
local v6 = v_u_1.CreateController({
	["Name"] = "RulesController"
})
v6.Rules = require(v3.Modules.Rules)
function v6.KnitStart(p_u_7) -- name: KnitStart
	-- upvalues: (copy) v_u_2, (ref) v_u_4
	local v8 = v_u_2.PlayerGui:WaitForChild("Menus")
	local v_u_9 = v8.Group.Rules
	v_u_9:SetAttribute("Loaded", true)
	local v10 = v_u_9.ScrollingFrame.Rule
	for v11, v12 in p_u_7.Rules.RuleList do
		local v13 = v10:Clone()
		v13.Text = ("- %*"):format(v12)
		v13.LayoutOrder = v11
		v13.Parent = v_u_9.ScrollingFrame
		v13.Text = v13.Text .. "\n"
	end
	for v14, v15 in p_u_7.Rules.Agreements do
		local v_u_16 = v8.Preset.RuleAgree:Clone()
		v_u_16.Rule.Text = v15
		v_u_16.LayoutOrder = #p_u_7.Rules.RuleList + v14
		v_u_16.Parent = v_u_9.ScrollingFrame
		v_u_16.TextButton.MouseButton1Click:Connect(function()
			-- upvalues: (copy) v_u_16
			if v_u_16.TextButton.Text == "" then
				v_u_16.TextButton.Text = "\226\156\148\239\184\143"
			else
				v_u_16.TextButton.Text = ""
			end
		end)
	end
	local v_u_17 = v_u_2:GetAttribute("LastRulesAccepted")
	if not v_u_17 then
		v_u_2:GetAttributeChangedSignal("LastRulesAccepted"):Wait()
		v_u_17 = v_u_2:GetAttribute("LastRulesAccepted")
	end
	if v_u_17 ~= p_u_7.Rules.Version then
		v_u_9.Accept.Visible = true
		v_u_2:GetAttributeChangedSignal("LastRulesAccepted"):Once(function()
			-- upvalues: (ref) v_u_17, (ref) v_u_2, (copy) p_u_7, (copy) v_u_9
			v_u_17 = v_u_2:GetAttribute("LastRulesAccepted")
			if v_u_17 == p_u_7.Rules.Version then
				for _, v18 in v_u_9.ScrollingFrame:GetChildren() do
					if v18.Name ~= "RuleAgree" then
						continue
					end
					v18.Visible = false
				end
				v_u_9.Accept.Visible = false
			end
		end)
	end
	v_u_9.Accept.MouseButton1Click:Connect(function()
		-- upvalues: (copy) v_u_9, (ref) v_u_4
		if v_u_9.Accept.Text == "..." then
			return
		else
			local v19 = true
			for _, v20 in v_u_9.ScrollingFrame:GetChildren() do
				if v20.Name ~= "RuleAgree" or v20.TextButton.Text == "\226\156\148\239\184\143" then
					continue
				end
				v19 = false
			end
			if v19 ~= false then
				for _, v21 in v_u_9.ScrollingFrame:GetChildren() do
					if v21.Name ~= "RuleAgree" then
						continue
					end
					v21.Visible = false
				end
				v_u_9.Accept.Text = "..."
				v_u_4.AcceptRules:Fire()
			end
		end
	end)
end
function v6.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_5, (copy) v_u_1, (ref) v_u_4
	v_u_5 = v_u_1.GetController("FXController")
	v_u_4 = v_u_1.GetService("JoinService")
end
return v6