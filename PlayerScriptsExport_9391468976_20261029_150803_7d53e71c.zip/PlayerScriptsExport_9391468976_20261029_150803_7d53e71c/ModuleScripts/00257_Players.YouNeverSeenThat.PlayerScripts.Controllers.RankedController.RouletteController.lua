-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.RankedController.RouletteController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
require(v6.Modules.Icon)
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
local v_u_10 = require(v_u_5.PlayerScripts.PlayerModule)
local v_u_11 = require(v6.Modules.MVP)
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v15 = v_u_1.CreateController({
	["Name"] = "RouletteController"
})
function v15.Start(_) -- name: Start
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_2, (ref) v_u_14, (copy) v_u_8, (ref) v_u_12, (copy) v_u_11, (ref) v_u_13, (copy) v_u_3, (copy) v_u_10, (copy) v_u_7, (copy) v_u_9
	task.spawn(function()
		-- upvalues: (ref) v_u_5, (ref) v_u_4, (ref) v_u_2, (ref) v_u_14, (ref) v_u_8, (ref) v_u_12
		local v_u_16 = v_u_5.PlayerGui:WaitForChild("Roulette")
		v_u_16.Enabled = true
		workspace:GetAttributeChangedSignal("Timer"):Connect(function()
			-- upvalues: (copy) v_u_16, (ref) v_u_4
			if workspace:GetAttribute("Timer") == nil then
				v_u_16.Time.Visible = false
			else
				v_u_16.Time.Text = workspace:GetAttribute("Timer")
				v_u_16.Time.Size = UDim2.new(1, 0, 0.15, 0)
				v_u_16.Time.AnchorPoint = Vector2.new(0.5, 0.2)
				v_u_16.Time.Rotation = 5
				v_u_16.Time.Visible = true
				v_u_4:Create(v_u_16.Time, TweenInfo.new(1, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["AnchorPoint"] = nil,
					["Rotation"] = 0,
					["Size"] = UDim2.new(1, 0, 0.1, 0),
					["AnchorPoint"] = Vector2.new(0.5, 0)
				}):Play()
			end
		end)
		local v_u_17 = v_u_5.PlayerGui.Roulette.Gamemode_Items.Buttons
		v_u_2.RenderStepped:Connect(function(p18)
			-- upvalues: (copy) v_u_16, (ref) v_u_5, (copy) v_u_17
			local v19 = v_u_16.Load.WaitSpin
			v19.Rotation = v19.Rotation + 30 * p18
			local v20
			if v_u_5.Team and (v_u_5.Team.Name == "Lobby" and not (v_u_5.Character and v_u_5.Character:GetAttribute("Dead"))) then
				v_u_5.PlayerGui.Main.Enabled = false
				if _G.MVP_PLAYING == true then
					v_u_17.Visible = false
				else
					v_u_17.Visible = true
				end
				v20 = _G.Crow and true or false
			else
				v_u_5.PlayerGui.Main.Enabled = true
				v_u_17.Visible = false
				v20 = true
			end
			if workspace.Effects:FindFirstChild("WaitAmbience") then
				if v20 == false then
					workspace.Effects.WaitAmbience.Volume = workspace.Effects.WaitAmbience.Vol.Value
					workspace.Effects.Music.Volume = 0
					return
				end
				workspace.Effects.WaitAmbience.Volume = 0
				workspace.Effects.Music.Volume = workspace.Effects.Music.Vol.Value
			end
		end)
		v_u_17.Spectate.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_14, (ref) v_u_8, (ref) v_u_12
			v_u_14:PlaySound(v_u_8.Misc.UI.Click, workspace, game.SoundService.Effect)
			v_u_14:PlaySound(v_u_8.Misc.UI.Switch, workspace, game.SoundService.Effect)
			v_u_12.Spectate:Fire()
		end)
		local v_u_21 = false
		v_u_17.AFK.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_14, (ref) v_u_8, (ref) v_u_21, (copy) v_u_17, (ref) v_u_12
			v_u_14:PlaySound(v_u_8.Misc.UI.Click, workspace, game.SoundService.Effect)
			v_u_14:PlaySound(v_u_8.Misc.UI.Switch, workspace, game.SoundService.Effect)
			v_u_21 = not v_u_21
			v_u_17.AFK.BackgroundColor3 = v_u_21 == true and Color3.fromRGB(255, 152, 152) or Color3.fromRGB(170, 255, 127)
			v_u_17.AFK.Text = v_u_21 == true and "AFK" or "PLAYING"
			v_u_12.Spectate:Fire(v_u_21)
		end)
	end)
	local v_u_144 = {
		["Transition"] = function(p22)
			-- upvalues: (ref) v_u_5, (ref) v_u_14, (ref) v_u_8, (ref) v_u_4
			local v23 = v_u_5.PlayerGui:WaitForChild("Roulette"):WaitForChild("Load")
			v23.Gamemode.Text = p22
			v23.WaitTime.Size = UDim2.new(0, 0, 0, 10)
			v_u_14:PlaySound(v_u_8.Misc.UI.Load1, workspace, game.SoundService.Effect)
			local v24 = TweenInfo.new(0.5)
			v_u_4:Create(v23, v24, {
				["BackgroundTransparency"] = 0,
				["ImageTransparency"] = 0
			}):Play()
			v_u_4:Create(v23.WaitSpin, v24, {
				["ImageTransparency"] = 0
			}):Play()
			v_u_4:Create(v23.WaitTime, v24, {
				["BackgroundTransparency"] = 0
			}):Play()
			v_u_4:Create(v23.WaitTime, TweenInfo.new(1), {
				["Size"] = UDim2.new(1, 0, 0, 10)
			}):Play()
			v_u_4:Create(v23.Gamemode, v24, {
				["TextTransparency"] = 0
			}):Play()
			repeat
				task.wait()
			until not workspace:GetAttribute("Loading")
			local v25 = TweenInfo.new(1)
			v_u_14:PlaySound(v_u_8.Misc.UI.Load2, workspace, game.SoundService.Effect)
			v_u_4:Create(v23, v25, {
				["BackgroundTransparency"] = 1,
				["ImageTransparency"] = 1
			}):Play()
			v_u_4:Create(v23.WaitSpin, v25, {
				["ImageTransparency"] = 1
			}):Play()
			v_u_4:Create(v23.WaitTime, v25, {
				["BackgroundTransparency"] = 1
			}):Play()
			v_u_4:Create(v23.Gamemode, v25, {
				["TextTransparency"] = 1
			}):Play()
		end,
		["Result"] = function(p26)
			-- upvalues: (ref) v_u_5, (ref) v_u_14, (ref) v_u_8, (ref) v_u_11, (ref) v_u_4, (ref) v_u_13
			local v_u_27 = v_u_5.PlayerGui:WaitForChild("Roulette")
			v_u_14:PlaySound(v_u_8.Misc.UI.DuelEnd, workspace, game.SoundService.Music)
			local v28 = 0
			local v29 = {}
			local v30 = nil
			local v_u_31 = nil
			for v32, v33 in p26 do
				local v34 = game.Players:FindFirstChild(v33[3])
				if v34 then
					if v34 == v_u_5 then
						v_u_31 = v33[2]
					end
					if v28 <= v33[1] then
						v28 = v33[1]
						v30 = v34
					end
					local v35 = { v34.UserId, v34.DisplayName or v34.Name, v33[1] }
					table.insert(v29, v35)
				else
					p26[v32] = nil
				end
			end
			table.sort(v29, function(p36, p37)
				return p36[3] > p37[3]
			end)
			local v38 = nil
			if v30 then
				v38 = v_u_11:MVP_Play(v30, v30:GetAttribute("MVP") or "King of Curses")
			else
				task.wait(8.5)
			end
			local v_u_39 = v_u_27.Preset.Winner:Clone()
			v_u_39.Parent = v_u_27.Result
			v_u_4:Create(v_u_39, TweenInfo.new(1), {
				["BackgroundTransparency"] = 0
			}):Play()
			v_u_4:Create(v_u_39.Total, TweenInfo.new(1), {
				["BackgroundTransparency"] = 0
			}):Play()
			v_u_4:Create(v_u_39.Title, TweenInfo.new(1), {
				["TextTransparency"] = 0
			}):Play()
			v_u_4:Create(v_u_39.Total.Title, TweenInfo.new(1), {
				["TextTransparency"] = 0
			}):Play()
			task.wait(1)
			v_u_39.Flash.BackgroundTransparency = 0
			v_u_4:Create(v_u_39.Flash, TweenInfo.new(0.5), {
				["BackgroundTransparency"] = 1
			}):Play()
			v_u_39.Single.Visible = true
			for v40, v_u_41 in v29 do
				local v_u_42 = v_u_27.Preset.PlaceLead:Clone()
				v_u_42.Title.Text = "#" .. v40 .. " " .. v_u_41[2]
				v_u_42.Score.Text = v_u_41[3]
				v_u_42.LayoutOrder = v40
				v_u_42.Parent = v_u_39.Single
				if v40 <= 3 then
					v_u_42.BackgroundTransparency = 0
					if v40 == 1 then
						v_u_42.First.Enabled = true
					elseif v40 == 2 then
						v_u_42.Second.Enabled = true
					else
						v_u_42.Third.Enabled = true
					end
				end
				task.spawn(function()
					-- upvalues: (copy) v_u_41, (copy) v_u_42
					local v43 = game.Players:GetUserThumbnailAsync(v_u_41[1], Enum.ThumbnailType.AvatarBust, Enum.ThumbnailSize.Size150x150)
					v_u_42.UserIcon.Image = v43
				end)
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_31, (copy) v_u_27, (copy) v_u_39, (ref) v_u_14, (ref) v_u_8, (ref) v_u_13
				if v_u_31 then
					local v44 = 0
					for v45, v46 in v_u_31 do
						if math.ceil(v46) <= 0 then
							continue
						end
						task.wait(0.6)
						v44 = v44 + math.ceil(v46)
						local v47 = v_u_27.Preset.Rewards:Clone()
						v47.Text = v45 .. " (" .. math.ceil(v46) .. "$)"
						v47.Parent = v_u_39.Rewards
						v_u_39.Total.Total.Text = math.clamp(v44, 0, 50) .. "$"
						v_u_14:PlaySound(v_u_8.Misc.UI.Coin, workspace, game.SoundService.Effect)
					end
					v_u_39.Total.Total.Text = math.clamp(v44, 0, 50) .. "$"
					if v44 <= 0 then
						local v48 = v_u_27.Preset.Rewards:Clone()
						v48.Text = "NOTHING??????? (0$)"
						v48.Parent = v_u_39.Rewards
						v_u_14:PlaySound(v_u_8.Misc.UI.CoinZero, workspace, game.SoundService.Music)
						v_u_14:PlaySound(v_u_8.Misc.UI.CoinZero2, workspace, game.SoundService.Effect)
						v_u_13.Give:Fire("Poor Performance")
					else
						v_u_14:PlaySound(v_u_8.Misc.UI.CoinTotal, workspace, game.SoundService.Music)
						task.wait(0.5)
						v_u_14:PlaySound(v_u_8.Misc.UI.CoinTotal2, workspace, game.SoundService.Effect)
					end
				else
					return
				end
			end)
			task.wait(5.5)
			task.wait(0.5)
			v_u_39:Destroy()
			if v38 then
				v_u_11:MVP_End(v38, true)
			end
		end,
		["ResultTeam"] = function(p49, p50, p51, p52)
			-- upvalues: (ref) v_u_5, (ref) v_u_14, (ref) v_u_8, (ref) v_u_11, (ref) v_u_4, (ref) v_u_13
			local v_u_53 = v_u_5.PlayerGui:WaitForChild("Roulette")
			v_u_14:PlaySound(v_u_8.Misc.UI.DuelEnd, workspace, game.SoundService.Music)
			local v54 = 0
			local v55 = {}
			local v56 = 0
			local v57 = {}
			local v58 = nil
			local v_u_59 = nil
			local v60 = nil
			for v61, v62 in p49 do
				local v63 = game.Players:FindFirstChild(v62[3])
				if v63 then
					if v63 == v_u_5 then
						v_u_59 = v62[2]
					end
					if v63.Team == p50 then
						if v54 <= v62[1] then
							v54 = v62[1]
							v58 = v63
						end
						local v64 = { v63.UserId, v63.DisplayName or v63.Name, v62[1] }
						table.insert(v55, v64)
					else
						if v56 <= v62[1] then
							v56 = v62[1]
							v60 = v63
						end
						local v65 = { v63.UserId, v63.DisplayName or v63.Name, v62[1] }
						table.insert(v57, v65)
					end
				else
					p49[v61] = nil
				end
			end
			table.sort(v55, function(p66, p67)
				return p66[3] > p67[3]
			end)
			table.sort(v57, function(p68, p69)
				return p68[3] > p69[3]
			end)
			if p52 == p50 then
				v60 = nil
			else
				v58 = nil
			end
			local v70 = nil
			if v58 or v60 then
				v70 = v_u_11:MVP_Play(v58 or v60, (v58 or v60):GetAttribute("MVP") or "King of Curses")
			else
				task.wait(8.5)
			end
			local v_u_71 = v_u_53.Preset.Winner:Clone()
			v_u_71.Parent = v_u_53.Result
			v_u_4:Create(v_u_71, TweenInfo.new(1), {
				["BackgroundTransparency"] = 0
			}):Play()
			v_u_4:Create(v_u_71.Total, TweenInfo.new(1), {
				["BackgroundTransparency"] = 0
			}):Play()
			v_u_4:Create(v_u_71.Title, TweenInfo.new(1), {
				["TextTransparency"] = 0
			}):Play()
			v_u_4:Create(v_u_71.Total.Title, TweenInfo.new(1), {
				["TextTransparency"] = 0
			}):Play()
			task.wait(1)
			v_u_71.Flash.BackgroundTransparency = 0
			v_u_4:Create(v_u_71.Flash, TweenInfo.new(0.5), {
				["BackgroundTransparency"] = 1
			}):Play()
			v_u_71.Team.Visible = true
			v_u_71.Team.Win.UIStroke.Color = p50.TeamColor.Color
			v_u_71.Team.Lose.UIStroke.Color = p51.TeamColor.Color
			for v72, v_u_73 in v55 do
				local v_u_74 = v_u_53.Preset.PlaceLead:Clone()
				v_u_74.Title.Text = "#" .. v72 .. " " .. v_u_73[2]
				v_u_74.Score.Text = v_u_73[3]
				v_u_74.LayoutOrder = v72
				v_u_74.Size = UDim2.new(1, -10, 0.2, 0)
				v_u_74.Parent = v_u_71.Team.Win
				task.spawn(function()
					-- upvalues: (copy) v_u_73, (copy) v_u_74
					local v75 = game.Players:GetUserThumbnailAsync(v_u_73[1], Enum.ThumbnailType.AvatarBust, Enum.ThumbnailSize.Size150x150)
					v_u_74.UserIcon.Image = v75
				end)
			end
			for v76, v_u_77 in v57 do
				local v_u_78 = v_u_53.Preset.PlaceLead:Clone()
				v_u_78.Title.Text = "#" .. v76 .. " " .. v_u_77[2]
				v_u_78.Score.Text = v_u_77[3]
				v_u_78.LayoutOrder = v76
				v_u_78.Size = UDim2.new(1, -10, 0.2, 0)
				v_u_78.Parent = v_u_71.Team.Lose
				task.spawn(function()
					-- upvalues: (copy) v_u_77, (copy) v_u_78
					local v79 = game.Players:GetUserThumbnailAsync(v_u_77[1], Enum.ThumbnailType.AvatarBust, Enum.ThumbnailSize.Size150x150)
					v_u_78.UserIcon.Image = v79
				end)
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_59, (copy) v_u_53, (copy) v_u_71, (ref) v_u_14, (ref) v_u_8, (ref) v_u_13
				if v_u_59 then
					local v80 = 0
					for v81, v82 in v_u_59 do
						if math.ceil(v82) <= 0 then
							continue
						end
						task.wait(0.6)
						v80 = v80 + math.ceil(v82)
						local v83 = v_u_53.Preset.Rewards:Clone()
						v83.Text = v81 .. " (" .. math.ceil(v82) .. "$)"
						v83.Parent = v_u_71.Rewards
						v_u_71.Total.Total.Text = math.clamp(v80, 0, 50) .. "$"
						v_u_14:PlaySound(v_u_8.Misc.UI.Coin, workspace, game.SoundService.Effect)
					end
					v_u_71.Total.Total.Text = math.clamp(v80, 0, 50) .. "$"
					if v80 <= 0 then
						local v84 = v_u_53.Preset.Rewards:Clone()
						v84.Text = "NOTHING??????? (0$)"
						v84.Parent = v_u_71.Rewards
						v_u_14:PlaySound(v_u_8.Misc.UI.CoinZero, workspace, game.SoundService.Music)
						v_u_14:PlaySound(v_u_8.Misc.UI.CoinZero2, workspace, game.SoundService.Effect)
						v_u_13.Give:Fire("Poor Performance")
					else
						v_u_14:PlaySound(v_u_8.Misc.UI.CoinTotal, workspace, game.SoundService.Music)
						task.wait(0.5)
						v_u_14:PlaySound(v_u_8.Misc.UI.CoinTotal2, workspace, game.SoundService.Effect)
					end
				else
					return
				end
			end)
			task.wait(5.5)
			task.wait(0.5)
			v_u_71:Destroy()
			if v70 then
				v_u_11:MVP_End(v70, true)
			end
		end,
		["Announce"] = function(p85, p86)
			-- upvalues: (ref) v_u_5, (ref) v_u_14, (ref) v_u_8, (ref) v_u_4
			local v87 = v_u_5.PlayerGui:WaitForChild("Roulette").Gamemode
			v_u_14:PlaySound(v_u_8.Misc.UI.Gamemode, workspace, game.SoundService.Effect)
			v87.Text = p85 .. "\n<font size=\"30\">" .. p86 .. "</font>"
			v87.Gamemode.Text = v87.Text
			v_u_4:Create(v87, TweenInfo.new(1), {
				["TextTransparency"] = 0
			}):Play()
			v_u_4:Create(v87.Gamemode, TweenInfo.new(1), {
				["TextTransparency"] = 0
			}):Play()
			task.wait(5)
			v_u_4:Create(v87, TweenInfo.new(5), {
				["TextTransparency"] = 1
			}):Play()
			v_u_4:Create(v87.Gamemode, TweenInfo.new(5), {
				["TextTransparency"] = 1
			}):Play()
		end,
		["Credits"] = function(p88, p89)
			-- upvalues: (ref) v_u_5, (ref) v_u_4, (ref) v_u_3
			local v90 = v_u_5.PlayerGui:WaitForChild("Roulette")
			local v91 = v90.Preset.MapCredits:Clone()
			v91.Text = p88
			v91.Creators.Text = "By " .. p89
			v91.Parent = v90
			v_u_4:Create(v91, TweenInfo.new(2.5, Enum.EasingStyle.Exponential), {
				["Position"] = nil,
				["TextTransparency"] = 0,
				["TextStrokeTransparency"] = 0,
				["Position"] = UDim2.new(0, 20, 0, 100)
			}):Play()
			v_u_4:Create(v91.Creators, TweenInfo.new(2.5, Enum.EasingStyle.Exponential), {
				["TextTransparency"] = 0,
				["TextStrokeTransparency"] = 0
			}):Play()
			task.wait(2.5)
			local v92 = TweenInfo.new(1.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			v_u_4:Create(v91, v92, {
				["TextTransparency"] = 1,
				["TextStrokeTransparency"] = 1
			}):Play()
			v_u_4:Create(v91.Creators, v92, {
				["TextTransparency"] = 1,
				["TextStrokeTransparency"] = 1
			}):Play()
			v_u_3:AddItem(v91, 1.5)
		end,
		["Crow"] = function(p93)
			-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_14, (ref) v_u_8, (ref) v_u_2, (ref) v_u_10, (ref) v_u_5
			local v94 = p93:WaitForChild("CrowUpd", 0.5)
			if v94 then
				_G.Crow = v94
				local v95 = game.ReplicatedStorage.Utils.Todo.Clap:Clone()
				v95.Position = p93.HumanoidRootPart.Position
				v95.Parent = workspace.Effects
				v_u_3:AddItem(v95, 1.5)
				v95.Attachment.Sparks:Emit(20)
				v_u_4:Create(v95, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(0, 0, 0),
					["Transparency"] = 1
				}):Play()
				v_u_14:PlaySound(v_u_8.Todo.Clap, v95, game.SoundService.Effect)
				local v96 = p93.HumanoidRootPart.CFrame
				local v97 = p93.HumanoidRootPart.CFrame
				workspace.CurrentCamera.CameraSubject = p93.Head
				local v98 = 1
				local v99 = v_u_2.Heartbeat:Wait()
				if p93.Parent then
					local v100 = workspace.CurrentCamera.CFrame
					local v101 = v_u_10:GetControls():GetMoveVector()
					local v102 = v100.RightVector * v101.X + -v100.LookVector * v101.Z
					local v103 = v100.LookVector
					if not _G.Shift then
						if v101 == Vector3.new(0, 0, 0) then
							v103 = v96.LookVector
							v98 = 1
						else
							v98 = v98 + 0.4 * v99
							v103 = v102
						end
					end
					v97 = CFrame.lookAlong(v97.Position + v102 * v99 * 20 * v98, v103)
					local v104 = 10 * v99
					v96 = v96:Lerp(v97, (math.clamp(v104, 0, 1)))
					v94:FireServer(v96)
					p93.HumanoidRootPart.CFrame = v96
					if p93.Parent then
						continue
					end
				end
				_G.Crow = nil
				local v105 = v_u_5.Character or v_u_5.CharacterAdded:Wait()
				workspace.CurrentCamera.CameraSubject = v105:WaitForChild("Humanoid", 1)
			end
		end,
		["ClapSpawn"] = function(p106)
			-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_14, (ref) v_u_8
			local v107 = game.ReplicatedStorage.Utils.Todo.Clap:Clone()
			v107.Position = p106
			v107.Parent = workspace.Effects
			v_u_3:AddItem(v107, 1.5)
			v107.Attachment.Sparks:Emit(20)
			v_u_4:Create(v107, TweenInfo.new(0.3), {
				["Size"] = Vector3.new(0, 0, 0),
				["Transparency"] = 1
			}):Play()
			v_u_14:PlaySound(v_u_8.Todo.Clap, v107, game.SoundService.Effect)
		end,
		["CrowExplode"] = function(p108)
			-- upvalues: (ref) v_u_3, (ref) v_u_14, (ref) v_u_8
			local v109 = game.ReplicatedStorage.Utils.Damage.CrowExplode:Clone()
			v109.Position = p108
			v_u_3:AddItem(v109, 1.5)
			v109.Parent = workspace.Effects
			v109.Sparks:Emit(20)
			v109.Feathers:Emit(12)
			v109.FeathersVariant:Emit(12)
			v109.ParticleEmitter:Emit(15)
			v_u_14:PlaySound(v_u_8.Misc.Crow, v109, game.SoundService.Effect)
			v_u_14:PlaySound(v_u_8.Mahito.Soulfire.Hit, v109, game.SoundService.Effect)
		end,
		["CrowMad"] = function(p110)
			-- upvalues: (ref) v_u_14, (ref) v_u_8, (ref) v_u_7, (ref) v_u_9, (ref) v_u_3, (ref) v_u_4
			local v111 = p110.HumanoidRootPart.Position
			v_u_14:PlaySound(v_u_8.Misc.CrowMad, p110.Torso, game.SoundService.Effect)
			local v112 = v_u_7.Damage.Flames:Clone()
			v112.Parent = p110.Torso
			v112:Emit(30)
			task.wait(1)
			v_u_14:PlaySound(v_u_8.Misc.CrowMad2, p110.Torso, game.SoundService.Effect)
			v_u_14:PlaySound(v_u_8.Naoya.TopSpeed.SonicBoom, p110.Torso, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - v111).Magnitude < 100 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
			end
			task.wait(0.1)
			if p110:FindFirstChild("HumanoidRootPart") then
				local v113 = v_u_7.Choso.CounterSwing.Shock:Clone()
				v113.Size = Vector3.new(6, 30, 6)
				v113.CFrame = p110.HumanoidRootPart.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v113.Parent = workspace.Effects
				v_u_3:AddItem(v113, 0.2)
				v_u_4:Create(v113, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(25, 0, 25),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v113.Position + p110.HumanoidRootPart.CFrame.LookVector * 10
				}):Play()
			end
		end,
		["CaptureRealm"] = function(p114, p115)
			-- upvalues: (ref) v_u_3, (ref) v_u_7, (ref) v_u_4, (ref) v_u_9, (ref) v_u_14, (ref) v_u_8
			local v_u_116 = p115:FindFirstChild("HumanoidRootPart")
			if v_u_116 then
				if p114 then
					local v117 = Instance.new("Folder", workspace.Effects)
					v_u_3:AddItem(v117, 2)
					local v118 = Instance.new("Attachment", p115.Torso)
					v_u_3:AddItem(v118, 2)
					local v119 = Random.new()
					for _ = 1, 10 do
						local v_u_120 = v_u_7.Misc.Items.Prison.PrisonCap:Clone()
						v_u_120.Beam.Attachment1 = v118
						v_u_120.CFrame = p114
						v_u_120.Parent = v117
						v_u_120.Beam.CurveSize0 = math.random(-10, 10)
						v_u_120.Beam.CurveSize1 = math.random(-10, 10)
						v_u_4:Create(v_u_120.Beam, TweenInfo.new(0.6, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out), {
							["CurveSize0"] = 0,
							["CurveSize1"] = 0
						}):Play()
						local v121 = CFrame.lookAlong(p114.Position, v119:NextUnitVector())
						v_u_4:Create(v_u_120, TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
							["CFrame"] = p114 + v121.LookVector * math.random(10, 20)
						}):Play()
						task.delay(0.3, function()
							-- upvalues: (copy) v_u_120, (ref) v_u_4, (copy) v_u_116
							local v122 = v_u_120.CFrame
							v_u_4:Create(v_u_120.Close, TweenInfo.new(0.45, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
								["Value"] = 1
							}):Play()
							repeat
								v_u_120.CFrame = v122:Lerp(v_u_116.CFrame, v_u_120.Close.Value)
								task.wait()
							until not (v_u_120.Parent and v_u_116.Parent)
							v_u_120:Destroy()
						end)
					end
					task.wait(0.75)
					if v_u_116.Parent and p115.Parent then
						local v123 = v_u_7.Misc.Items.Prison.PrisonSeal:Clone()
						v123.Weld.Part0 = v_u_116
						v123.Parent = v117
						for _, v124 in p115:GetDescendants() do
							if not (v124:IsA("BasePart") or v124:IsA("Decal")) then
								continue
							end
							v124.Transparency = 1
						end
						local v125 = v_u_7.Megumi.Mahoraga.WorldSlash.mesh:Clone()
						v125.Position = v123.Position - Vector3.new(0, 2, 0)
						v125.Decal.Transparency = 0
						v125.Mesh.Scale = Vector3.new(2, -5, 2)
						v125.Decal.Transparency = 0.4
						v125.Parent = workspace.Effects
						v_u_4:Create(v125, TweenInfo.new(2, Enum.EasingStyle.Exponential), {
							["CFrame"] = v125.CFrame * CFrame.Angles(0, -3.12413936106985, 0)
						}):Play()
						v_u_4:Create(v125.Mesh, TweenInfo.new(2, Enum.EasingStyle.Exponential), {
							["Scale"] = Vector3.new(15, 25, 15)
						}):Play()
						v_u_4:Create(v125.Decal, TweenInfo.new(2, Enum.EasingStyle.Exponential), {
							["Transparency"] = 1
						}):Play()
						v_u_3:AddItem(v125, 2)
						for _ = 1, 4 do
							local v126 = math.random(300, 500) / 10
							local v127 = v_u_7.Gojo.LapseBlue.Throw:Clone()
							v127.Transparency = 0.7
							v127.Position = p115.Head.Position
							local v128 = math.random(-180, 180)
							local v129 = math.random(-180, 180)
							local v130 = math.random
							v127.Orientation = Vector3.new(v128, v129, v130(-180, 180))
							v127.Size = Vector3.new(0, 0, 7)
							v127.Parent = workspace.Effects
							v_u_4:Create(v127, TweenInfo.new(0.7, Enum.EasingStyle.Exponential), {
								["Size"] = nil,
								["Transparency"] = 1,
								["Size"] = Vector3.new(v126, v126, 0)
							}):Play()
							v_u_3:AddItem(v127, 0.7)
							task.wait(0.025)
						end
						if (workspace.CurrentCamera.CFrame.Position - v123.Position).Magnitude < 120 then
							v_u_9.CurrentShaker:Shake(v_u_9.Presets.SnapOh)
						end
						task.wait(1)
						local v131 = game.ReplicatedStorage.Utils.Todo.Clap:Clone()
						v131.Position = v123.Position
						v131.Parent = workspace.Effects
						v_u_3:AddItem(v131, 1.5)
						v131.Attachment.Sparks:Emit(20)
						v_u_4:Create(v131, TweenInfo.new(0.3), {
							["Size"] = Vector3.new(0, 0, 0),
							["Transparency"] = 1
						}):Play()
						v_u_14:PlaySound(v_u_8.Todo.Clap, v131, game.SoundService.Effect)
						v123.Transparency = 1
					end
				else
					return
				end
			else
				return
			end
		end,
		["Kit"] = function(p_u_132, p_u_133)
			-- upvalues: (ref) v_u_7, (ref) v_u_5, (ref) v_u_14, (ref) v_u_8, (ref) v_u_4
			local v_u_134 = v_u_7.Misc.RouletteKit:Clone()
			v_u_134.Parent = v_u_5.PlayerGui
			p_u_132.AncestryChanged:Once(function()
				-- upvalues: (copy) v_u_134
				v_u_134:Destroy()
			end)
			local v135 = 0
			for v_u_136 = 1, 3 do
				local v_u_137 = v_u_134.Vows["Vow" .. v_u_136]
				task.delay(v135, function()
					-- upvalues: (ref) v_u_14, (ref) v_u_8, (copy) v_u_137, (ref) v_u_4, (copy) p_u_133, (copy) v_u_136, (copy) v_u_134, (copy) p_u_132
					v_u_14:PlaySound(v_u_8.Misc.UI.CardFlip, workspace, game.SoundService.Effect)
					local v138 = v_u_137
					v138.Position = v138.Position - UDim2.new(0, 0, 1, 0)
					v_u_4:Create(v_u_137, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["Position"] = v_u_137.Position + UDim2.new(0, 0, 1, 0)
					}):Play()
					v_u_137.AnchorPoint = Vector2.new(0.5, 0.5)
					v_u_137.Size = UDim2.new(0, 200, 0, 250)
					v_u_137.Title.Text = p_u_133[v_u_136].Title
					for v139, v140 in p_u_133[v_u_136].Moveset do
						local v141 = v_u_134.Preset.Info:Clone()
						v141.Text = v140
						v141.Parent = v_u_137.Info
						v141.LayoutOrder = v139
					end
					if p_u_133[v_u_136].Health then
						local v142 = v_u_134.Preset.SubInfo:Clone()
						v142.Text = ("Max health : %*"):format(p_u_133[v_u_136].Health)
						v142.Parent = v_u_137.Info
						v142.LayoutOrder = 100
					end
					if p_u_133[v_u_136].Author then
						local v143 = v_u_134.Preset.SubInfo:Clone()
						v143.Text = ("Author : %*"):format(p_u_133[v_u_136].Author)
						v143.Parent = v_u_137.Info
						v143.LayoutOrder = 101
					end
					if p_u_133[v_u_136].Rarity == 2 then
						v_u_137.Basic.Enabled = false
						v_u_137.Rare.Enabled = true
					elseif p_u_133[v_u_136].Rarity == 3 then
						v_u_137.Basic.Enabled = false
						v_u_137.Legendary.Enabled = true
					end
					v_u_137.Visible = true
					v_u_137.TextButton.MouseEnter:Connect(function()
						-- upvalues: (ref) v_u_14, (ref) v_u_8, (ref) v_u_4, (ref) v_u_137
						v_u_14:PlaySound(v_u_8.Misc.UI.Hover, workspace, game.SoundService.Effect)
						v_u_4:Create(v_u_137, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
							["Size"] = UDim2.new(0, 205, 0, 255),
							["AnchorPoint"] = Vector2.new(0.5, 0.525)
						}):Play()
					end)
					v_u_137.TextButton.MouseLeave:Connect(function()
						-- upvalues: (ref) v_u_4, (ref) v_u_137
						v_u_4:Create(v_u_137, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
							["Size"] = UDim2.new(0, 200, 0, 250),
							["AnchorPoint"] = Vector2.new(0.5, 0.5)
						}):Play()
					end)
					v_u_137.TextButton.MouseButton1Down:Connect(function()
						-- upvalues: (ref) p_u_132, (ref) p_u_133, (ref) v_u_136, (ref) v_u_14, (ref) v_u_8
						p_u_132:FireServer(p_u_133[v_u_136].Index)
						v_u_14:PlaySound(v_u_8.Misc.UI.Click, workspace, game.SoundService.Effect)
						v_u_14:PlaySound(v_u_8.Misc.UI.Switch, workspace, game.SoundService.Effect)
					end)
				end)
				v135 = v135 + 0.1
			end
		end
	}
	v_u_12.Effects:Connect(function(p145, ...)
		-- upvalues: (copy) v_u_144
		local v146 = v_u_144[p145]
		if v146 then
			v146(...)
		end
	end)
end
function v15.KnitStart(_) -- name: KnitStart
	local v_u_147 = game:GetService("TextChatService")
	v_u_147.MessageReceived:Connect(function(p148)
		-- upvalues: (copy) v_u_147
		if workspace:GetAttribute("Roulette") then
			local v149 = p148.Text
			local v150 = p148.TextSource
			if v150 then
				local v151 = workspace.Effects.Crows:FindFirstChild(v150.Name)
				if v151 then
					v_u_147:DisplayBubble(v151.Head, v149)
				end
			else
				return
			end
		else
			return
		end
	end)
end
function v15.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_12, (copy) v_u_1, (ref) v_u_13, (ref) v_u_14
	v_u_12 = v_u_1.GetService("RouletteService")
	v_u_13 = v_u_1.GetService("AchievementService")
	v_u_14 = v_u_1.GetController("FXController")
end
return v15