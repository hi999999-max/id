-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Toji.ISOH.TranscendController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
require(v_u_6.Modules.StaticLightning)
require(v_u_6.Modules.LightningBeams)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "TranscendController"
})
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (ref) v_u_11, (copy) v_u_8, (copy) v_u_2, (copy) v_u_6, (copy) v_u_5, (copy) v_u_9, (ref) v_u_10
	local v_u_36 = {
		["Startup"] = function(p13)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				local v15 = p13.SetAssets:FindFirstChild("ISOH")
				if v15 then
					local v_u_16 = v_u_7.Toji.ISOHCombatTrail:Clone()
					v_u_16.Weld.Part0 = v15.Blade
					v_u_16.Parent = v15
					task.delay(0.6, function()
						-- upvalues: (copy) v_u_16, (ref) v_u_4, (ref) v_u_3
						if v_u_16.Parent ~= nil then
							v_u_16.Trail.Enabled = false
							v_u_4:Create(v_u_16, TweenInfo.new(0.1), {
								["Transparency"] = 1
							}):Play()
							v_u_3:AddItem(v_u_16, 0.2)
						end
					end)
				end
				v_u_11:PlaySound(v_u_8.Toji.ISOH.Transcend.Start, v14, game.SoundService.Effect)
				v_u_11:DustTrail(p13, 0.1, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Dash"] = function(p17, p18, p19, p20)
			-- upvalues: (ref) v_u_2, (ref) v_u_11, (ref) v_u_6, (ref) v_u_3, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v_u_21 = p17.HumanoidRootPart
			if v_u_21 then
				v_u_2.Stepped:Wait()
				local v_u_22 = CFrame.new(p18, v_u_21.Position)
				local _ = (p18 - v_u_21.Position).Magnitude
				v_u_11:DustBreak(p18 + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
				local v23 = p17.SetAssets:FindFirstChild("ISOH")
				if p20 and (p20:GetAttribute("Ascend") and (v23 and v23:FindFirstChild("ISOHCombatTrail"))) then
					v23.ISOHCombatTrail:Destroy()
				end
				if not p19 then
					local v24 = Instance.new("Model")
					local v25 = v_u_6.Utils.Itadori.RushWind:Clone()
					v25.CFrame = v_u_21.CFrame * CFrame.new(0, -1, 0)
					v25.Parent = v24
					v24.Parent = workspace.Effects
					v24:ScaleTo(0.6)
					v25.Ring:Emit(7)
					v25.Dash1.Dash:Emit(1)
					v25.Dash2.Dash:Emit(1)
					v_u_3:AddItem(v24, 2)
				end
				local v26 = v_u_7.Itadori.Shock:Clone()
				v26.CFrame = v_u_22 * CFrame.Angles(1.5707963267948966, 0, 0)
				v26.Parent = workspace.Effects
				v_u_4:Create(v26, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(10, 0, 10),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v26, 0.3)
				task.delay(0.075, function()
					-- upvalues: (ref) v_u_7, (copy) v_u_22, (ref) v_u_4, (ref) v_u_3, (copy) v_u_21
					local v27 = v_u_7.Itadori.Shock:Clone()
					v27.CFrame = v_u_22 * CFrame.Angles(1.5707963267948966, 0, 0) + v_u_22.LookVector * 3
					v27.Parent = workspace.Effects
					v_u_4:Create(v27, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v27, 0.2)
					task.wait(0.075)
					local v28 = v_u_7.Itadori.Shock:Clone()
					v28.CFrame = v_u_21.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
					v28.Parent = workspace.Effects
					v_u_4:Create(v28, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v28, 0.2)
				end)
				v_u_11:PlaySound(v_u_8.Toji.ISOH.Transcend.Dash, v_u_21, game.SoundService.Effect)
				v_u_11:DustTrail(p17, 0.4)
				for _, v_u_29 in p17:GetDescendants() do
					if not (v_u_29:IsA("BasePart") or v_u_29:IsA("Decal")) or v_u_29.Transparency == 1 then
						continue
					end
					v_u_29.LocalTransparencyModifier = 1
					task.delay(0.03, function()
						-- upvalues: (copy) v_u_29
						v_u_29.LocalTransparencyModifier = 0.7
						task.wait(0.03)
						v_u_29.LocalTransparencyModifier = 1
						task.wait(0.03)
						v_u_29.LocalTransparencyModifier = 0.2
						task.wait(0.03)
						v_u_29.LocalTransparencyModifier = 1
						task.wait(0.03)
						v_u_29.LocalTransparencyModifier = 0
						task.wait(0.04)
						v_u_29.LocalTransparencyModifier = 1
						task.wait(0.04)
						v_u_29.LocalTransparencyModifier = 0
					end)
				end
			end
		end,
		["Hit"] = function(p30, p31, p32, p33)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v34 = p30:FindFirstChild("HumanoidRootPart")
			if v34 then
				if p32 then
					local v35 = v_u_7.Yuta.SlashHit:Clone()
					v35.CFrame = CFrame.lookAlong(p32.Position, v34.CFrame.LookVector)
					v35.CFrame = v35.CFrame * CFrame.Angles(0, 0, -0.2617993877991494)
					v35.Parent = workspace.Effects
					v35.Slash:Emit(5)
					v_u_3:AddItem(v35, 2)
					if p33 then
						v_u_11:PlaySound(v_u_8.Misc.Items.Clash, v35, game.SoundService.Effect)
					else
						v_u_11:Flash(p31, Color3.new(1, 1, 1))
						v_u_11:PlaySound(v_u_8.Haruta.AnkleCutterHit, p32, game.SoundService.Effect)
						if v_u_5.Character == p30 or v_u_5.Character == p31 then
							v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
						end
					end
				else
					return
				end
			else
				return
			end
		end
	}
	v_u_10.Effects:Connect(function(p37, ...)
		-- upvalues: (copy) v_u_36
		local v38 = v_u_36[p37]
		if v38 then
			v38(...)
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("TranscendService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12