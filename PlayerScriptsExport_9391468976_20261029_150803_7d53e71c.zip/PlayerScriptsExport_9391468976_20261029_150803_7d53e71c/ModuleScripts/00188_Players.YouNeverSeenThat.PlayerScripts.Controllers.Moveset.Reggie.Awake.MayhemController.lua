-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Reggie.Awake.MayhemController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
require(v5.Modules.BloodyZee)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "MayhemController"
})
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (copy) v_u_2, (ref) v_u_9
	local v_u_33 = {
		["Start"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_11:PlaySound(v_u_7.Reggie.MayhemStart, v14, game.SoundService.Effect)
			end
		end,
		["Explosion"] = function(p15, p16)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v17 = v_u_6.Reggie.Explosion:Clone()
			v17.Parent = workspace.Effects
			v17.WorldCFrame = CFrame.new(p16)
			for _, v18 in v17:GetDescendants() do
				if not v18:IsA("ParticleEmitter") then
					continue
				end
				v18:Emit(v18:GetAttribute("EmitCount"))
			end
			v_u_3:AddItem(v17, 3)
			v_u_11:PlaySound(v_u_7.Reggie.DroneStrike.Explode, v17, game.SoundService.Effect).PlaybackSpeed = math.random(90, 110) / 100
			if (workspace.CurrentCamera.CFrame.Position - p16).Magnitude < 45 or v_u_4.Character == p15 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
			end
		end,
		["Interp"] = function(p_u_19, p20)
			-- upvalues: (ref) v_u_6, (ref) v_u_2
			if p20 then
				v_u_6.Reggie.ReceiptGlow:Clone().Parent = p_u_19
			end
			local v_u_21 = p_u_19.CFrame
			local v_u_22 = tick()
			local v_u_23 = p_u_19:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_21, (copy) p_u_19, (ref) v_u_22
				v_u_21 = p_u_19.CFrame
				v_u_22 = tick()
			end)
			local v_u_24 = nil
			v_u_24 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_19, (ref) v_u_24, (copy) v_u_23, (ref) v_u_21, (ref) v_u_22
				if p_u_19.Parent == workspace.Bullets then
					if p_u_19.Parent then
						workspace:BulkMoveTo({ p_u_19 }, { v_u_21 + v_u_21.LookVector * (p_u_19:GetAttribute("Speed") * (tick() - v_u_22)) }, Enum.BulkMoveMode.FireCFrameChanged)
					else
						v_u_24:Disconnect()
						v_u_23:Disconnect()
					end
				else
					v_u_24:Disconnect()
					v_u_23:Disconnect()
					return
				end
			end)
		end,
		["Land"] = function(p25, p26)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3
			v_u_11:PlaySound(v_u_7.Reggie.Littering.Land, p25, game.SoundService.Effect)
			for _, v27 in p25.CE_Infuse:GetChildren() do
				v27.Enabled = true
				v27:Emit(1)
			end
			if not p26 then
				local v28 = v_u_6.Reggie.ReceiptBurn:Clone()
				v28.Parent = workspace.Effects
				v28.Anchored = true
				v28.CFrame = p25.CFrame
				v_u_11:PlayParticles(v28)
				v_u_3:AddItem(v28, 3)
				v_u_11:PlaySound(v_u_7.Reggie.CouponBurn2, p25, game.SoundService.Effect)
			end
		end,
		["Heal"] = function(p29)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_11, (ref) v_u_7
			local v30 = p29:FindFirstChild("HumanoidRootPart")
			if v30 then
				local v31 = v_u_6.Reggie.SpotlightQuick:Clone()
				v31.CFrame = v30.CFrame
				v31.Weld.Part0 = v30
				v31.Parent = workspace.Effects
				for _, v32 in v31:GetDescendants() do
					if not v32:IsA("ParticleEmitter") then
						continue
					end
					v32:Emit(v32:GetAttribute("EmitCount"))
				end
				v_u_3:AddItem(v31, 1)
				v_u_11:PlaySound(v_u_7.Reggie.Heal, v30, game.SoundService.Effect)
			end
		end
	}
	v_u_9.Effects:Connect(function(p34, ...)
		-- upvalues: (copy) v_u_33
		local v35 = v_u_33[p34]
		if v35 then
			v35(...)
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("MayhemService")
	v_u_10 = v_u_1.GetController("HitboxController")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12