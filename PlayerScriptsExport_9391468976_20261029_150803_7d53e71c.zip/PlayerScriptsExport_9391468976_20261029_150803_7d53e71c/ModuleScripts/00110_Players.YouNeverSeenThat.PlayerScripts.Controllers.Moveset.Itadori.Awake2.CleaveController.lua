-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Itadori.Awake2.CleaveController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
require(v_u_6.Modules.BloodyZee)
local v_u_10 = require(v_u_6.Modules.SraikoVFX)
local v_u_11 = RaycastParams.new()
v_u_11.FilterType = Enum.RaycastFilterType.Include
v_u_11.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v15 = v_u_1.CreateController({
	["Name"] = "CleaveController"
})
function v15.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_13, (copy) v_u_8, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2, (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (copy) v_u_6, (copy) v_u_10, (ref) v_u_12, (copy) v_u_11, (ref) v_u_14
	local v_u_60 = {
		["Start"] = function(p16)
			-- upvalues: (ref) v_u_13, (ref) v_u_8
			local v17 = p16:FindFirstChild("HumanoidRootPart")
			if v17 then
				v_u_13:PlaySound(v_u_8.Nanami.BluntCut.Start, v17, game.SoundService.Effect)
			end
		end,
		["Hit"] = function(p18, p19)
			-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_13, (ref) v_u_8
			if p18:FindFirstChild("HumanoidRootPart") then
				local v20 = p19:FindFirstChild("HumanoidRootPart")
				if v20 then
					if v_u_5.Character == p18 or v_u_5.Character == p19 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
					v_u_13:Flash(p19, Color3.new(1, 1, 1))
					v_u_13:PlaySound(v_u_8.Nanami.BluntCut.RatioHit, v20, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Dash"] = function(p21, p22)
			-- upvalues: (ref) v_u_2, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_6, (ref) v_u_13, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v_u_23 = p21.HumanoidRootPart
			if v_u_23 then
				v_u_2.Stepped:Wait()
				local v_u_24 = CFrame.new(p22, v_u_23.Position)
				local v25 = (p22 - v_u_23.Position).Magnitude
				local v26 = v_u_7.Mahito.Dash:Clone()
				v26.CFrame = v_u_24 + v_u_24.LookVector * v25 / 2
				v26.Size = Vector3.new(9, 9, v25)
				v26.Parent = workspace.Effects
				v_u_4:Create(v26, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(0, 0, v25),
					["CFrame"] = v26.CFrame * CFrame.Angles(0, 0, 3.141592653589793)
				}):Play()
				v_u_3:AddItem(v26, 0.7)
				local v27 = Instance.new("Highlight")
				v27.FillColor = Color3.new(0, 0, 0)
				v27.FillTransparency = 0
				v27.DepthMode = Enum.HighlightDepthMode.Occluded
				v27.Parent = v26
				local v28 = v_u_7.Itadori.Dismantle.DismatleProj.Stars:Clone()
				v28.Parent = v26
				v28:Emit(6)
				local v29 = Instance.new("Model")
				local v30 = v_u_6.Utils.Itadori.RushWind:Clone()
				v30.CFrame = v_u_23.CFrame * CFrame.new(0, -1, 0)
				v30.Parent = v29
				v29.Parent = workspace.Effects
				v29:ScaleTo(0.6)
				v30.Ring:Emit(7)
				v30.Dash1.Dash:Emit(1)
				v30.Dash2.Dash:Emit(1)
				v_u_3:AddItem(v29, 2)
				local v31 = v_u_7.Itadori.Shock:Clone()
				v31.CFrame = v_u_24 * CFrame.Angles(1.5707963267948966, 0, 0)
				v31.Parent = workspace.Effects
				v_u_4:Create(v31, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(10, 0, 10),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v31, 0.3)
				task.delay(0.075, function()
					-- upvalues: (ref) v_u_7, (copy) v_u_24, (ref) v_u_4, (ref) v_u_3, (copy) v_u_23
					local v32 = v_u_7.Itadori.Shock:Clone()
					v32.CFrame = v_u_24 * CFrame.Angles(1.5707963267948966, 0, 0) + v_u_24.LookVector * 3
					v32.Parent = workspace.Effects
					v_u_4:Create(v32, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v32, 0.2)
					task.wait(0.075)
					local v33 = v_u_7.Itadori.Shock:Clone()
					v33.CFrame = v_u_23.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
					v33.Parent = workspace.Effects
					v_u_4:Create(v33, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v33, 0.2)
				end)
				v_u_13:PlaySound(v_u_8.Itadori.Dismantle.Fire, v_u_23, game.SoundService.Effect)
				if v_u_5.Character == p21 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Hit2"] = function(p34, p35)
			-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_13, (ref) v_u_8
			if p34:FindFirstChild("HumanoidRootPart") then
				local v36 = p35:FindFirstChild("HumanoidRootPart")
				if v36 then
					if v_u_5.Character == p34 or v_u_5.Character == p35 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.MediumHit)
					end
					v_u_13:Flash(p35, Color3.new(1, 1, 1))
					v_u_13:PlaySound(v_u_8.Nanami.CrossCut.RatioHit, v36, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Hit3"] = function(p37, p38)
			-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_13, (ref) v_u_8
			local v39 = p37:FindFirstChild("HumanoidRootPart")
			if v39 then
				if p38:FindFirstChild("HumanoidRootPart") then
					if v_u_5.Character == p37 or v_u_5.Character == p38 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.MediumHit)
					end
					v_u_13:Flash(p38, Color3.new(1, 1, 1))
					v_u_13:PlaySound(v_u_8.Heian.Dismantle.Hit, v39, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Leap"] = function(p40, p41)
			-- upvalues: (ref) v_u_13, (ref) v_u_8, (ref) v_u_5
			local v42 = p40:FindFirstChild("HumanoidRootPart")
			if v42 then
				v_u_13:PlaySound(v_u_8.Nanami.CrossCut.Start, v42, game.SoundService.Effect)
				if p40 == v_u_5.Character then
					p41.Position = v42.Position + Vector3.new(0, 6, 0)
				end
			end
		end,
		["Spiderweb"] = function(p43, p44)
			-- upvalues: (ref) v_u_13, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_9
			local v45 = p43:FindFirstChild("HumanoidRootPart")
			if v45 then
				v_u_13:PlaySound(v_u_8.Heian.Dismantle.Start, v45, game.SoundService.Effect)
				local v46 = v_u_7.Megumi.Mahoraga.WorldSlash.mesh:Clone()
				v46.Position = p44
				v46.Decal.Transparency = 0.2
				v46.Mesh.Scale = Vector3.new(0.2, 10, 0.2)
				v46.Parent = workspace.Effects
				v_u_4:Create(v46, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
					["Size"] = Vector3.new(20, 10, 20),
					["CFrame"] = nil,
					["CFrame"] = v46.CFrame * CFrame.Angles(0, -3.12413936106985, 0)
				}):Play()
				v_u_4:Create(v46.Mesh, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
					["Scale"] = Vector3.new(10, 5, 10)
				}):Play()
				v_u_4:Create(v46.Decal, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v46, 1)
				if (workspace.CurrentCamera.CFrame.Position - p44).Magnitude < 100 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
				local v47 = v_u_7.Itadori.Dismantle.CleaveWeb:Clone()
				v47:PivotTo(CFrame.new(p44) * CFrame.Angles(-1.5707963267948966, 0, 0))
				v47.Parent = workspace.Effects
				local v48 = TweenInfo.new(0.4, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
				local v_u_49 = TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				for _, v_u_50 in v47:GetDescendants() do
					if v_u_50:IsA("Model") then
						local v51 = Instance.new("Highlight")
						v51.FillColor = Color3.new(0, 0, 0)
						v51.FillTransparency = 0
						v51.DepthMode = Enum.HighlightDepthMode.Occluded
						v51.Parent = v_u_50
					else
						if not v_u_50:IsA("BasePart") then
							continue
						end
						local v52 = v_u_50.Position
						v_u_50.Position = v_u_50.Position + Vector3.new(0, 10, 0)
						v_u_4:Create(v_u_50, v48, {
							["Size"] = v_u_50.Size * Vector3.new(1, 1, 0),
							["Position"] = v52
						}):Play()
						task.delay(0.4, function()
							-- upvalues: (ref) v_u_4, (copy) v_u_50, (copy) v_u_49
							v_u_4:Create(v_u_50, v_u_49, {
								["Size"] = v_u_50.Size + Vector3.new(0, 0, 30)
							}):Play()
						end)
					end
				end
				task.wait(0.5)
				v47:Destroy()
				v_u_13:PlaySound(v_u_8.Itadori.Dismantle.Fire, v45, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - p44).Magnitude < 150 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
					if _G.Settings.Flash ~= true then
						return
					end
					local v53 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
					v53.TintColor = Color3.new(1, 1, 1)
					v53.Parent = game.Lighting
					task.wait(0.04)
					v53.Brightness = 200
					v53.Contrast = -1000
					task.wait(0.04)
					v53:Destroy()
				end
				local v54 = v_u_7.Itadori.Dismantle.CleaveWebEnd:Clone()
				v54.Position = p44
				v54.Parent = workspace.Effects
				v_u_3:AddItem(v54, 0.5)
				v_u_4:Create(v54.PointLight, TweenInfo.new(0.5), {
					["Brightness"] = 0
				}):Play()
				v54.Smear:Emit(40)
				v54.Stars:Emit(30)
			end
		end,
		["LaunchDown"] = function(p55, _)
			-- upvalues: (ref) v_u_7, (ref) v_u_10, (ref) v_u_13, (ref) v_u_8
			local v56 = p55:FindFirstChild("HumanoidRootPart")
			if v56 then
				local v57 = v_u_7.Mechamaru.BoostOnVFX.BoostHit.Meshes.Mesh
				v_u_10.EmitMesh(v57, v56.CFrame * CFrame.Angles(-0.7853981633974483, 0, 0) * v57.Offset.Value)
				v_u_13:PlaySound(v_u_8.Itadori.Rush.Rush, v56, game.SoundService.Effect)
			end
		end,
		["Finisher"] = function(p58)
			-- upvalues: (ref) v_u_13, (ref) v_u_8
			local v59 = p58:FindFirstChild("HumanoidRootPart")
			if v59 then
				v_u_13:PlaySound(v_u_8.Yuta.ResoluteHit, v59, game.SoundService.Effect)
				v_u_13:Bleed(p58)
			end
		end
	}
	v_u_12.Effects:Connect(function(p61, ...)
		-- upvalues: (copy) v_u_60
		local v62 = v_u_60[p61]
		if v62 then
			v62(...)
		end
	end)
	v_u_12.Hitbox:Connect(function(p63, p64, p65)
		-- upvalues: (ref) v_u_11, (ref) v_u_14
		local v66 = p64.HumanoidRootPart
		if v66 then
			local v67 = workspace:Raycast((v66.CFrame * CFrame.new(0, 0, -2.5)).Position, p63.Velocity.Unit * 8, v_u_11)
			local v68 = v_u_14:SphereHitbox(p64, CFrame.new(0, -5, -5), 12)
			if v67 then
				local v69
				if v67 then
					v69 = v67.Position
				else
					v69 = v67
				end
				local v70
				if v67 then
					v70 = v67.Normal
				else
					v70 = v67
				end
				p65:FireServer(v68, v69, v70)
				if v67 then
					p63:Destroy()
				end
			end
			task.wait(0.025)
			if p63.Parent then
				continue
			end
		end
	end)
end
function v15.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_12, (copy) v_u_1, (ref) v_u_14, (ref) v_u_13
	v_u_12 = v_u_1.GetService("CleaveService")
	v_u_14 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("FXController")
end
return v15