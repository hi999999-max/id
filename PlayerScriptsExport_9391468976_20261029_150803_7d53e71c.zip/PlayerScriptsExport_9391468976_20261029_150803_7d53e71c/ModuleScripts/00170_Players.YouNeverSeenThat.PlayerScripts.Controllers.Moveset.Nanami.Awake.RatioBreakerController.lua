-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Nanami.Awake.RatioBreakerController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
require(v_u_6.Modules.BloodyZee)
local v_u_10 = require(v_u_6.Modules.SraikoVFX)
local v_u_11 = require(v_u_6.Modules.LightningBeams)
local v_u_12 = RaycastParams.new()
v_u_12.FilterType = Enum.RaycastFilterType.Include
v_u_12.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_13 = Random.new()
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = nil
local v17 = v_u_1.CreateController({
	["Name"] = "RatioBreakerController"
})
local v_u_18 = {
	"rbxassetid://74285508054294",
	"rbxassetid://99132465087026",
	"rbxassetid://114891301322696",
	"rbxassetid://85813887517647",
	"rbxassetid://76321503224643",
	"rbxassetid://78626248888940",
	"rbxassetid://115760318978716",
	"rbxassetid://103659957620708",
	"rbxassetid://129941782677974",
	"rbxassetid://72590467800262",
	"rbxassetid://115486948939199",
	"rbxassetid://120088088651914",
	"rbxassetid://76659571940765",
	"rbxassetid://135487679567493",
	"rbxassetid://105922249024859",
	"rbxassetid://127194758766478"
}
function v17.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_18, (ref) v_u_15, (copy) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (copy) v_u_12, (copy) v_u_10, (copy) v_u_13, (copy) v_u_11, (copy) v_u_5, (copy) v_u_9, (copy) v_u_6, (copy) v_u_2, (ref) v_u_14
	task.spawn(function()
		-- upvalues: (ref) v_u_18
		local v19 = {}
		for _, v20 in pairs(v_u_18) do
			table.insert(v19, v20)
		end
		game.ContentProvider:PreloadAsync(v19)
	end)
	local v_u_205 = {
		["Start"] = function(p21, p22, p23)
			-- upvalues: (ref) v_u_15, (ref) v_u_8
			local v24 = p21:FindFirstChild("HumanoidRootPart")
			if v24 then
				local v_u_25
				if p23 == 1 then
					v_u_25 = v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB1.Whoosh, v24, game.SoundService.Effect)
				else
					if p23 == 2 then
						v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB2.Whoosh, v24, game.SoundService.Effect)
						return
					end
					if p23 ~= 4 then
						return
					end
					v_u_25 = v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB4.Start, v24, game.SoundService.Effect)
				end
				p22.AncestryChanged:Once(function()
					-- upvalues: (ref) v_u_25
					if v_u_25 then
						v_u_25:Destroy()
					end
				end)
			end
		end,
		["Slash"] = function(p26)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v27 = p26:FindFirstChild("HumanoidRootPart")
			if v27 then
				local v28 = v_u_7.Nanami.RatioBreaker.Attack1.SlashEmit:Clone()
				v28.Weld.Part0 = v27
				v28.Parent = workspace.Effects
				for _, v29 in pairs(v28:GetDescendants()) do
					if not v29:IsA("ParticleEmitter") then
						continue
					end
					v29:Emit(v29:GetAttribute("EmitCount"))
				end
				v_u_3:AddItem(v28, 1.5)
				local v30 = v_u_7.Nanami.RatioBreaker.Attack1.SlashBeam:Clone()
				v30.Weld.Part0 = v27
				v30.Parent = workspace.Effects
				v_u_3:AddItem(v30, 1.5)
				for _, v31 in pairs(v30:GetDescendants()) do
					if not v31:IsA("Beam") then
						continue
					end
					v31.Enabled = true
				end
				for _, v_u_32 in pairs(v30:GetDescendants()) do
					if not v_u_32:IsA("Beam") then
						continue
					end
					v_u_4:Create(v_u_32, TweenInfo.new(0.19), {
						["Width0"] = 0,
						["Width1"] = 0
					}):Play()
					task.delay(0.29000000000000004, function()
						-- upvalues: (copy) v_u_32
						v_u_32.Enabled = false
						v_u_32.Width0 = 17
						v_u_32.Width1 = 17
					end)
				end
			end
		end,
		["SlashHit"] = function(p33, p34)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_15, (ref) v_u_8
			local v35 = p33:FindFirstChild("HumanoidRootPart")
			if v35 then
				local v36 = p34:FindFirstChild("HumanoidRootPart")
				if v36 then
					local v37 = v_u_7.Nanami.RatioBreaker.Attack1.SlashHit:Clone()
					v37.Parent = v36
					local v38 = CFrame.lookAt
					local v39 = v36.Position
					local v40 = v35.Position.X
					local v41 = v36.Position.Y
					local v42 = v35.Position.Z
					v37.WorldCFrame = v38(v39, (Vector3.new(v40, v41, v42)))
					for _, v43 in pairs(v37:GetDescendants()) do
						if not v43:IsA("ParticleEmitter") then
							continue
						end
						v43:Emit(v43:GetAttribute("EmitCount"))
					end
					v_u_3:AddItem(v37, 1)
					v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB1.SlashHit, v35, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["WindCharge"] = function(p44)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_10, (ref) v_u_3
			local v45 = p44:FindFirstChild("HumanoidRootPart")
			if v45 then
				local v46 = workspace:Raycast(v45.Position, Vector3.new(-0, -7.5, -0), v_u_12)
				if v46 then
					for _, v47 in pairs(v_u_7.Nanami.BluntCut.Charge:GetChildren()) do
						if not v47:IsA("Model") then
							continue
						end
						local v48 = v47:Clone()
						local v49 = v_u_10.HandleMesh(v48, CFrame.new(v46.Position, v46.Position + v46.Normal) * CFrame.Angles(-1.5707963267948966, 0, 0))
						v48.Parent = workspace.Effects
						v_u_3:AddItem(v48, v49)
					end
				end
			end
		end,
		["ArmEmit"] = function(p50)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_15, (ref) v_u_8
			local v51 = p50:FindFirstChild("HumanoidRootPart")
			if v51 then
				v_u_10.Emit(v_u_7.Nanami.RatioBreaker.Attack1.ArmEmit, v51.CFrame)
				v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB1.Charge, v51, game.SoundService.Effect)
			end
		end,
		["Whoosh1"] = function(p52)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_10
			local v53 = p52:FindFirstChild("HumanoidRootPart")
			if v53 then
				local v54 = v_u_7.Nanami.RatioBreaker.Attack1.BlackFlash.BlackFlash:Clone()
				v54.CFrame = v53.CFrame * CFrame.new(0, 0, -8)
				v54.Parent = workspace.Effects
				v_u_3:AddItem(v54, 4)
				for _, v55 in pairs(v54.Black:GetDescendants()) do
					if not (v55:IsA("ParticleEmitter") and v55:GetAttribute("Whiff")) then
						continue
					end
					v55:Emit(v55:GetAttribute("EmitCount"))
				end
				for _, v56 in pairs(v_u_7.Nanami.RatioBreaker.Attack1.BlackFlash.Meshes:GetChildren()) do
					if not v56:IsA("Model") then
						continue
					end
					local v57 = v56:Clone()
					local v58 = v_u_10.HandleMesh(v57, v53.CFrame * CFrame.new(0, 0, -6) * CFrame.Angles(0.2617993877991494, 0, 0))
					v57.Parent = workspace.Effects
					v_u_3:AddItem(v57, v58)
				end
			end
		end,
		["WhooshUlt"] = function(p59)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_10
			local v60 = p59:FindFirstChild("HumanoidRootPart")
			if v60 then
				local v61 = v_u_7.Nanami.RatioBreaker.Attack1.BlackFlash.BlackFlash:Clone()
				v61.CFrame = v60.CFrame * CFrame.new(0, 0, -2.95)
				v61.Parent = workspace.Effects
				v_u_3:AddItem(v61, 4)
				for _, v62 in pairs(v61.Black:GetDescendants()) do
					if not (v62:IsA("ParticleEmitter") and v62:GetAttribute("Whiff")) then
						continue
					end
					v62:Emit(v62:GetAttribute("EmitCount"))
				end
				for _, v63 in pairs(v_u_7.Nanami.RatioBreaker.Attack1.BlackFlash.Meshes:GetChildren()) do
					if not v63:IsA("Model") then
						continue
					end
					local v64 = v63:Clone()
					local v65 = v_u_10.HandleMesh(v64, v60.CFrame * CFrame.new(0, 0, -1.25) * CFrame.Angles(0.2617993877991494, 0, 0))
					v64.Parent = workspace.Effects
					v_u_3:AddItem(v64, v65)
				end
			end
		end,
		["BlackFlashHit"] = function(p66, p_u_67, p68)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_3, (ref) v_u_15, (ref) v_u_8, (ref) v_u_4, (ref) v_u_13, (ref) v_u_11, (ref) v_u_5, (ref) v_u_9
			local v69 = p66:FindFirstChild("HumanoidRootPart")
			if v69 then
				local v_u_70 = p_u_67:FindFirstChild("HumanoidRootPart")
				if v_u_70 then
					local v71 = workspace:Raycast(v69.Position, CFrame.lookAt(v69.Position, v_u_70.Position).LookVector * 11, v_u_12)
					local v72 = v71 and v71.Distance or 11
					local v73 = v_u_7.Nanami.RatioBreaker.Attack1.BlackFlash.BlackFlash:Clone()
					v73.Position = (CFrame.lookAt(v69.Position, v_u_70.Position) * CFrame.new(0, 0, -v72)).Position
					v73.Parent = workspace.Effects
					v_u_3:AddItem(v73, 2)
					for _, v74 in pairs(v73:GetDescendants()) do
						if not v74:IsA("ParticleEmitter") or v74:GetAttribute("Whiff") then
							continue
						end
						v74:Emit(v74:GetAttribute("EmitCount"))
					end
					local v_u_75 = v_u_7.Itadori.DivergentFist.BlackFlashHit:Clone()
					v_u_75.Position = (CFrame.lookAt(v69.Position, v_u_70.Position) * CFrame.new(0, 0, -v72)).Position
					v_u_75.Parent = workspace.Effects
					v_u_3:AddItem(v_u_75, 2)
					v_u_15:Flash(p_u_67, Color3.new(1, 0, 0))
					v_u_15:PlaySound(p68 == 1 and v_u_8.Nanami.RatioBreaker.RB1.Hit or v_u_8.Nanami.RatioBreaker.RB2.Hit, v69, game.SoundService.Effect)
					v_u_4:Create(v_u_75.PointLight, TweenInfo.new(1), {
						["Brightness"] = 0
					}):Play()
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_75
						v_u_75.Blast:Emit(8)
						v_u_75.Sparks:Emit(15)
						v_u_75.Lightning:Emit(6)
						v_u_75.Wind:Emit(7)
					end)
					task.spawn(function()
						-- upvalues: (copy) p_u_67, (copy) v_u_70, (ref) v_u_13, (ref) v_u_12, (ref) v_u_11
						local v76 = Instance.new("Model", workspace.Effects)
						local v77 = Instance.new("Highlight", v76)
						v77.DepthMode = Enum.HighlightDepthMode.Occluded
						v77.OutlineColor = Color3.new(1, 0, 0)
						v77.FillColor = Color3.new(0, 0, 0)
						v77.FillTransparency = 0
						local v78 = p_u_67.Torso.BodyBackAttachment
						local v79 = tick()
						local v80 = Instance.new("Attachment", v_u_70)
						local v81 = workspace:Raycast(v_u_70.Position, v_u_13:NextUnitVector() * 30, v_u_12)
						if v81 then
							v80.Position = v81.Position
						else
							v80.Position = v_u_13:NextUnitVector() * 30
						end
						local v_u_82 = v_u_11.new(v78, v80, nil, v76)
						v_u_82.Color = Color3.new(1, 0, 0)
						v_u_82.PulseSpeed = 300
						v_u_82.FadeLength = 0.35
						v_u_82.MaxRadius = 20
						v_u_82.MinRadius = 0
						v_u_82.AnimationSpeed = 75
						v_u_82.MinThicknessMultiplier = 0.1
						v_u_82.MaxThicknessMultiplier = 3
						task.delay(0.15, function()
							-- upvalues: (copy) v_u_82
							v_u_82:Destroy()
						end)
						task.wait(0.02)
						if tick() - v79 <= 0.15 then
							continue
						end
					end)
					if v_u_5.Character == p66 or v_u_5.Character == p_u_67 then
						v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(1.5)
						if _G.Settings.Flash ~= true then
							return
						end
						local v83 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
						v83.Parent = game.Lighting
						task.wait(0.04)
						v83.TintColor = Color3.new(1, 1, 1)
						task.wait(0.04)
						v83.Brightness = 200
						v83.Contrast = -1000
						task.wait(0.04)
						v83:Destroy()
					end
				end
			else
				return
			end
		end,
		["ArmCharge"] = function(p84)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_10, (ref) v_u_3
			local v85 = p84:FindFirstChild("HumanoidRootPart")
			if v85 then
				local v86 = workspace:Raycast(v85.Position, Vector3.new(-0, -7.5, -0), v_u_12)
				if v86 then
					local v87 = v_u_7.Nanami.RatioBreaker.Attack2.NewSlash:Clone()
					local v88 = v_u_10.HandleMesh(v87, CFrame.new(v86.Position, v86.Position + v86.Normal) * CFrame.Angles(-1.5707963267948966, 0, 0))
					v87.Parent = workspace.Effects
					v_u_3:AddItem(v87, v88)
				end
				v_u_10.Emit(v_u_7.Nanami.RatioBreaker.Attack2.ArmEmit, v85.CFrame)
			end
		end,
		["Whoosh2"] = function(p89)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_10, (ref) v_u_9
			local v90 = p89:FindFirstChild("HumanoidRootPart")
			if v90 then
				local v91 = v_u_7.Nanami.RatioBreaker.Attack1.BlackFlash.BlackFlash:Clone()
				v91.CFrame = v90.CFrame * CFrame.new(0, 0, -1.5)
				v91.Parent = workspace.Effects
				v_u_3:AddItem(v91, 4)
				for _, v92 in pairs(v91.Black:GetDescendants()) do
					if not (v92:IsA("ParticleEmitter") and v92:GetAttribute("Whiff")) then
						continue
					end
					v92:Emit(v92:GetAttribute("EmitCount"))
				end
				for _, v93 in pairs(v_u_7.Nanami.RatioBreaker.Attack1.BlackFlash.Meshes:GetChildren()) do
					if not v93:IsA("Model") then
						continue
					end
					local v94 = v93:Clone()
					local v95 = v_u_10.HandleMesh(v94, v90.CFrame * CFrame.new(0, 0, -1) * CFrame.Angles(0.2617993877991494, 0, 0))
					v94.Parent = workspace.Effects
					v_u_3:AddItem(v94, v95)
				end
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.MediumHit)
			end
		end,
		["Jump"] = function(p96)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_10, (ref) v_u_3, (ref) v_u_15, (ref) v_u_8, (ref) v_u_9
			local v97 = p96:FindFirstChild("HumanoidRootPart")
			if v97 then
				local v98 = workspace:Raycast(v97.Position, Vector3.new(-0, -7.5, -0), v_u_12)
				if v98 then
					for _, v99 in pairs(v_u_7.Nanami.RatioBreaker.Attack3.Jump.Meshes:GetChildren()) do
						local v100 = v99:Clone()
						local v101 = v_u_10.HandleMesh(v100, CFrame.new(v98.Position, v98.Position + v98.Normal) * CFrame.Angles(-1.5707963267948966, 0, 0))
						v100.Parent = workspace.Effects
						v_u_3:AddItem(v100, v101)
					end
					v_u_10.Emit(v_u_7.Nanami.RatioBreaker.Attack3.Jump.Whoosh, v97.CFrame)
				end
				v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB3.Jump, v97, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v97.Position).Magnitude < 80 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["JumpHitbox"] = function(p102, p103, p104)
			-- upvalues: (ref) v_u_5, (ref) v_u_12
			local v105 = p102:FindFirstChild("HumanoidRootPart")
			if v105 then
				if p102 == v_u_5.Character then
					local v106 = workspace
					local v107 = (v105.CFrame * CFrame.new(0, 0, -2)).Position
					local v108 = p103.Velocity.Unit
					local v109 = p103.Velocity.Magnitude
					local v110 = v106:Raycast(v107, v108 * math.clamp(v109, 3, 10), v_u_12)
					if v110 then
						p104:FireServer(v110.Position, v110.Normal)
						p103:Destroy()
					end
					task.wait(0.025)
					if p103.Parent then
						continue
					end
				end
			end
		end,
		["Slam"] = function(p111, p112, p113)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_15, (ref) v_u_8, (ref) v_u_10, (ref) v_u_9, (ref) v_u_5, (ref) v_u_13, (ref) v_u_12, (ref) v_u_11
			local v114 = p111:FindFirstChild("HumanoidRootPart")
			if v114 then
				local v115 = v_u_7.Nanami.RatioBreaker.Attack3.Slam.Slam:Clone()
				local v116 = Instance.new("Model")
				v115.Parent = v116
				v116:ScaleTo(1.5)
				v_u_3:AddItem(v116, 0.1)
				v115:PivotTo(p112 * CFrame.Angles(-1.5707963267948966, 0, 0))
				v115.Parent = workspace.Effects
				v_u_3:AddItem(v115, 4)
				for _, v117 in pairs(v115.Black:GetDescendants()) do
					if not (v117:IsA("ParticleEmitter") and v117:GetAttribute("Whiff")) then
						continue
					end
					v117:Emit(v117:GetAttribute("EmitCount"))
				end
				local v118 = v_u_7.Megumi.Mahoraga.Earthquake:Clone()
				v118.CFrame = p112 * CFrame.Angles(-1.5707963267948966, 0, 0)
				v118.Parent = workspace.Effects
				v118.Air:Destroy()
				v_u_4:Create(v118.PointLight, TweenInfo.new(0.6), {
					["Brightness"] = 0
				}):Play()
				v_u_4:Create(v118.Floor.Ring2, TweenInfo.new(0.4), {
					["TimeScale"] = 0.5
				}):Play()
				v118.Floor.Ring2:Emit(10)
				v118.Floor.Wind2:Emit(15)
				v118.Floor.Dust:Emit(100)
				v_u_3:AddItem(v118, 3)
				local v119 = v_u_7.Megumi.Mahoraga.WorldSlash.mesh:Clone()
				v119.CFrame = p112 * CFrame.Angles(-1.5707963267948966, 0, 0)
				v119.Decal.Transparency = 0
				v119.Mesh.Scale = Vector3.new(2, 50, 2)
				v119.Parent = v118
				v_u_4:Create(v119, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
					["Size"] = Vector3.new(80, 40, 80),
					["CFrame"] = nil,
					["CFrame"] = v119.CFrame * CFrame.Angles(0, -3.12413936106985, 0)
				}):Play()
				v_u_4:Create(v119.Mesh, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
					["Scale"] = Vector3.new(60, 10, 60)
				}):Play()
				v_u_4:Create(v119.Decal, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v119, 1)
				v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB3.Slam, v114, game.SoundService.Effect)
				for _, v120 in pairs(v_u_7.Nanami.RatioBreaker.Attack3.Slam.Meshes:GetChildren()) do
					local v121 = v120:Clone()
					local v122 = v_u_10.HandleMesh(v121, p112 * CFrame.Angles(-1.5707963267948966, 0, 0))
					v121.Parent = workspace.Effects
					v_u_3:AddItem(v121, v122)
				end
				if #p113 > 0 then
					if (workspace.CurrentCamera.CFrame.Position - p112.Position).Magnitude < 150 then
						v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(1.5)
					end
					v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB3.Hit, v114, game.SoundService.Effect)
					if v_u_5.Character == p111 and _G.Settings.Flash == true then
						local v123 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
						v123.Parent = game.Lighting
						task.wait(0.04)
						v123.TintColor = Color3.new(1, 1, 1)
						task.wait(0.04)
						v123.Brightness = 200
						v123.Contrast = -1000
						task.wait(0.04)
						v123:Destroy()
					end
					for _, v124 in pairs(v115.Black:GetDescendants()) do
						if not v124:IsA("ParticleEmitter") or v124:GetAttribute("Whiff") then
							continue
						end
						v124:Emit(v124:GetAttribute("EmitCount"))
					end
					for _, v125 in pairs(p113) do
						if v125 == v_u_5.Character then
							v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(1.5)
							if _G.Settings.Flash == true then
								local v126 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
								v126.Parent = game.Lighting
								task.wait(0.04)
								v126.TintColor = Color3.new(1, 1, 1)
								task.wait(0.04)
								v126.Brightness = 200
								v126.Contrast = -1000
								task.wait(0.04)
								v126:Destroy()
							end
						end
						local v127 = v125:FindFirstChild("HumanoidRootPart")
						local v_u_128 = v_u_7.Itadori.DivergentFist.BlackFlashHit:Clone()
						v_u_128.Position = v127.Position
						v_u_128.Parent = workspace.Effects
						v_u_3:AddItem(v_u_128, 2)
						v_u_15:Flash(v125, Color3.new(1, 0, 0))
						v_u_4:Create(v_u_128.PointLight, TweenInfo.new(1), {
							["Brightness"] = 0
						}):Play()
						task.delay(0.1, function()
							-- upvalues: (copy) v_u_128
							v_u_128.Blast:Emit(8)
							v_u_128.Sparks:Emit(15)
							v_u_128.Lightning:Emit(6)
							v_u_128.Wind:Emit(7)
						end)
					end
					local v129 = Instance.new("Model", workspace.Effects)
					local v130 = Instance.new("Highlight", v129)
					v130.DepthMode = Enum.HighlightDepthMode.Occluded
					v130.OutlineColor = Color3.new(1, 0, 0)
					v130.FillColor = Color3.new(0, 0, 0)
					v130.FillTransparency = 0
					local v131 = p111["Right Arm"].RightGripAttachment
					local v132 = tick()
					local v133 = Instance.new("Attachment", v114)
					local v134 = workspace:Raycast(v114.Position, (v_u_13:NextUnitVector() * Vector3.new(1, 0, 1)).Unit * 50, v_u_12)
					if v134 then
						v133.Position = v134.Position
					else
						v133.Position = (v_u_13:NextUnitVector() * Vector3.new(1, 0, 1)).Unit * 50
					end
					local v_u_135 = v_u_11.new(v131, v133, nil, v129)
					v_u_135.Color = Color3.new(1, 0, 0)
					v_u_135.PulseSpeed = 300
					v_u_135.FadeLength = 0.35
					v_u_135.MaxRadius = 10
					v_u_135.MinRadius = 0
					v_u_135.AnimationSpeed = 75
					v_u_135.MinThicknessMultiplier = 0.1
					v_u_135.MaxThicknessMultiplier = 3
					task.delay(0.125, function()
						-- upvalues: (copy) v_u_135
						v_u_135:Destroy()
					end)
					task.wait(0.01)
					if tick() - v132 <= 0.2 then
						continue
					end
				elseif (workspace.CurrentCamera.CFrame.Position - p112.Position).Magnitude < 150 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end,
		["ArmCharge2"] = function(p136)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_15, (ref) v_u_8
			local v137 = p136:FindFirstChild("HumanoidRootPart")
			if v137 then
				v_u_10.Emit(v_u_7.Nanami.RatioBreaker.Attack3.ArmEmit, v137, true)
				v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB3.Charge, v137, game.SoundService.Effect)
			end
		end,
		["RatioBreakerBlackFlash"] = function(p138, p_u_139, p140)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9, (ref) v_u_13, (ref) v_u_12, (ref) v_u_11
			local v_u_141 = p_u_139:FindFirstChild("HumanoidRootPart")
			if v_u_141 then
				local v142 = v_u_7.Nanami.RatioBreaker.Attack4.BlackFlash:Clone()
				local v143 = Instance.new("Model")
				v142.Parent = v143
				v143:ScaleTo(1.6)
				v_u_3:AddItem(v143, 0.1)
				v142.CFrame = CFrame.new(p140)
				v142.Parent = workspace.Effects
				v_u_3:AddItem(v142, 10)
				for _, v144 in pairs(v142:GetDescendants()) do
					if not v144:IsA("ParticleEmitter") or v144:GetAttribute("Whiff") then
						continue
					end
					v144:Emit(v144:GetAttribute("EmitCount"))
				end
				if v_u_5.Character == p138 or p_u_139 == v_u_5.Character then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
				task.spawn(function()
					-- upvalues: (copy) p_u_139, (copy) v_u_141, (ref) v_u_13, (ref) v_u_12, (ref) v_u_11
					local v145 = Instance.new("Model", workspace.Effects)
					local v146 = Instance.new("Highlight", v145)
					v146.DepthMode = Enum.HighlightDepthMode.Occluded
					v146.OutlineColor = Color3.new(1, 0, 0)
					v146.FillColor = Color3.new(0, 0, 0)
					v146.FillTransparency = 0
					local v147 = p_u_139.Torso.BodyBackAttachment
					local v148 = tick()
					local v149 = Instance.new("Attachment", v_u_141)
					local v150 = workspace:Raycast(v_u_141.Position, v_u_13:NextUnitVector() * 30, v_u_12)
					if v150 then
						v149.Position = v150.Position
					else
						v149.Position = v_u_13:NextUnitVector() * 30
					end
					local v_u_151 = v_u_11.new(v147, v149, nil, v145)
					v_u_151.Color = Color3.new(1, 0, 0)
					v_u_151.PulseSpeed = 10
					v_u_151.FadeLength = 0.35
					v_u_151.MaxRadius = 20
					v_u_151.MinRadius = 0
					v_u_151.AnimationSpeed = 5
					v_u_151.MinThicknessMultiplier = 0.1
					v_u_151.MaxThicknessMultiplier = 2
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_151
						v_u_151.AnimationSpeed = 0.5
						v_u_151.PulseSpeed = 5
					end)
					task.delay(1.4500000000000002, function()
						-- upvalues: (copy) v_u_151
						v_u_151.AnimationSpeed = 75
						v_u_151.PulseSpeed = 300
						task.delay(0.125, function()
							-- upvalues: (ref) v_u_151
							v_u_151:Destroy()
						end)
					end)
					task.wait(0.025)
					if tick() - v148 <= 0.15 then
						continue
					end
				end)
				task.wait(0.1)
				for _, v152 in pairs(v142:GetDescendants()) do
					if not v152:IsA("ParticleEmitter") then
						continue
					end
					v152.TimeScale = 0.01
				end
				task.wait(1.35)
				if (workspace.CurrentCamera.CFrame.Position - v_u_141.Position).Magnitude < 80 then
					v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(1.5)
				end
				for _, v153 in pairs(v142:GetDescendants()) do
					if not v153:IsA("ParticleEmitter") then
						continue
					end
					v153.TimeScale = 0.7
				end
			end
		end,
		["Dash"] = function(p154, p_u_155, p_u_156, _)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_6, (ref) v_u_13, (ref) v_u_11, (ref) v_u_5, (ref) v_u_9, (ref) v_u_15, (ref) v_u_8
			local v_u_157 = p154:FindFirstChild("HumanoidRootPart")
			if v_u_157 then
				local v_u_158 = CFrame.new(p_u_155, p_u_156)
				local v159 = (p_u_155 - p_u_156).Magnitude
				local v160 = v_u_7.Mahito.Dash:Clone()
				v160.CFrame = v_u_158 + v_u_158.LookVector * v159 / 2
				v160.Size = Vector3.new(5, 5, v159)
				v160.Color = Color3.fromRGB(255, 0, 0)
				v160.Parent = workspace.Effects
				v_u_4:Create(v160, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(0, 0, v159),
					["CFrame"] = v160.CFrame * CFrame.Angles(0, 0, 3.141592653589793)
				}):Play()
				v_u_3:AddItem(v160, 0.2)
				local v161 = Instance.new("Highlight", v160)
				v161.DepthMode = Enum.HighlightDepthMode.Occluded
				v161.OutlineColor = Color3.new(1, 0, 0)
				v161.FillColor = Color3.new(0, 0, 0)
				v161.FillTransparency = 0
				local v162 = Instance.new("Model")
				local v163 = v_u_6.Utils.Itadori.RushWind:Clone()
				v163.CFrame = v_u_157.CFrame * CFrame.new(0, -1, 0)
				v163.Parent = v162
				v162.Parent = workspace.Effects
				v162:ScaleTo(0.6)
				v163.Ring:Emit(7)
				v163.Dash1.Dash:Emit(1)
				v163.Dash2.Dash:Emit(1)
				v_u_3:AddItem(v162, 2)
				local v164 = v_u_7.Itadori.Shock:Clone()
				v164.CFrame = v_u_158 * CFrame.Angles(1.5707963267948966, 0, 0)
				v164.Parent = workspace.Effects
				v_u_4:Create(v164, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(10, 0, 10),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v164, 0.3)
				task.delay(0.075, function()
					-- upvalues: (ref) v_u_7, (copy) v_u_158, (ref) v_u_4, (ref) v_u_3, (copy) v_u_157
					local v165 = v_u_7.Itadori.Shock:Clone()
					v165.CFrame = v_u_158 * CFrame.Angles(1.5707963267948966, 0, 0) + v_u_158.LookVector * 3
					v165.Parent = workspace.Effects
					v_u_4:Create(v165, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v165, 0.2)
					task.wait(0.075)
					local v166 = v_u_7.Itadori.Shock:Clone()
					v166.CFrame = v_u_157.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
					v166.Parent = workspace.Effects
					v_u_4:Create(v166, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v166, 0.2)
				end)
				local v_u_167 = Instance.new("Model", workspace.Effects)
				v_u_3:AddItem(v_u_167, 5)
				local v168 = Instance.new("Highlight", v_u_167)
				v168.DepthMode = Enum.HighlightDepthMode.Occluded
				v168.OutlineColor = Color3.new(1, 0, 0)
				v168.FillColor = Color3.new(0, 0, 0)
				v168.FillTransparency = 0
				tick()
				for _ = 1, 5 do
					task.spawn(function()
						-- upvalues: (copy) p_u_155, (ref) v_u_13, (copy) p_u_156, (ref) v_u_3, (ref) v_u_11, (copy) v_u_167
						local v169 = Instance.new("Attachment", workspace.Terrain)
						v169.WorldPosition = p_u_155 + v_u_13:NextUnitVector() * 5
						local v170 = Instance.new("Attachment", workspace.Terrain)
						v170.WorldPosition = p_u_156 + v_u_13:NextUnitVector() * 5
						v_u_3:AddItem(v169, 5)
						v_u_3:AddItem(v170, 5)
						local v171 = v_u_11.new(v170, v169, nil, v_u_167)
						v171.Color = Color3.new(1, 0, 0)
						v171.PulseSpeed = 5
						v171.FadeLength = 0.35
						v171.MaxRadius = 10
						v171.MinRadius = 0
						v171.AnimationSpeed = 1
						v171.MinThicknessMultiplier = 0.1
						v171.MaxThicknessMultiplier = 1.5
						task.wait(0.1)
						v171.PulseSpeed = 25
						v171.AnimationSpeed = 5
						for _ = 1, 12 do
							v171.Thickness = v171.Thickness * 0.85
							v171.PulseSpeed = v171.PulseSpeed * 0.85
							v171.MaxRadius = v171.MaxRadius * 0.85
							task.wait(0.020833333333333332)
						end
						v171:Destroy()
					end)
				end
				if p154 == v_u_5.Character then
					v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(1)
				end
				v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB4.Dash, v_u_157, game.SoundService.Effect)
			end
		end,
		["RatioBreakerHit"] = function(p_u_172, p173, _)
			-- upvalues: (ref) v_u_5, (ref) v_u_15, (ref) v_u_8, (ref) v_u_4, (ref) v_u_18, (ref) v_u_9, (ref) v_u_7, (ref) v_u_3, (ref) v_u_2
			local v_u_174 = p_u_172:FindFirstChild("HumanoidRootPart")
			if v_u_174 then
				local v_u_175 = p173:FindFirstChild("HumanoidRootPart")
				if v_u_175 then
					if p_u_172 == v_u_5.Character or p173 == v_u_5.Character then
						v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB4.Hit, workspace, game.SoundService.Effect)
						local v_u_176 = workspace.CurrentCamera
						task.spawn(function()
							-- upvalues: (ref) v_u_5, (ref) v_u_4, (ref) v_u_18, (ref) v_u_9, (ref) v_u_7, (copy) v_u_175, (ref) v_u_3
							local v177 = Instance.new("ScreenGui")
							v177.IgnoreGuiInset = true
							v177.Parent = v_u_5.PlayerGui
							local v178 = Instance.new("Frame")
							v178.BackgroundTransparency = 0
							v178.BackgroundColor3 = Color3.new(0, 0, 0)
							v178.AnchorPoint = Vector2.new(0.5, 0.5)
							v178.Size = UDim2.fromScale(1, 1)
							v178.Position = UDim2.fromScale(0.5, 0.5)
							v178.Parent = v177
							local v179 = game.ReplicatedStorage.Utils.Nanami.Ratio.Bar:Clone()
							v179.Parent = v178
							local _ = v179.Cursor
							v179.Rotation = -140
							v179.Size = UDim2.fromScale(0.24, 3.5999999999999996)
							v_u_4:Create(v179, TweenInfo.new(0.35, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
								["Rotation"] = 80,
								["Size"] = nil,
								["Position"] = nil,
								["Size"] = UDim2.fromScale(0.16, 2.4),
								["Position"] = UDim2.fromScale(0.6, 0.45)
							}):Play()
							task.wait(0.2)
							v178.BackgroundColor3 = Color3.new(1, 1, 1)
							v179.Bar.ImageColor3 = Color3.new(0, 0, 0)
							v179.Cursor.Visible = false
							v179.Hit2.Visible = true
							task.wait(0.15)
							local v180 = tick()
							local v181 = Instance.new("ScreenGui")
							v181.ResetOnSpawn = false
							v181.IgnoreGuiInset = true
							for v182 = 1, #v_u_18, 2 do
								local v183 = Instance.new("ImageLabel")
								v183.Name = tostring(v182)
								v183.Image = v_u_18[v182]
								v183.Size = UDim2.new(0, 1, 0, 1)
								v183.BackgroundColor3 = Color3.new(0, 0, 0)
								v183.Parent = v181
							end
							v181.Parent = v_u_5.PlayerGui
							for v184 = 1, #v_u_18, 2 do
								v181[tostring(v184)].Size = UDim2.new(1, 0, 1, 0)
								if v184 ~= 1 then
									local v185 = v184 - 2
									v181[tostring(v185)]:Destroy()
								end
								repeat
									task.wait()
								until tick() - v180 >= 0.041666666666666664
								v180 = tick()
							end
							v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.HeavyHit):StartFadeOut(3)
							v181:Destroy()
							v177:Destroy()
							local v186 = v_u_7.Nanami.RatioBreaker.Attack4.HitEnd:Clone()
							v186.CFrame = v_u_175.CFrame
							v186.Parent = workspace.Effects
							v186.BloodParticle:Emit(70)
							v_u_3:AddItem(v186, 2)
							if _G.Settings.Flash == true then
								local v187 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
								v187.Parent = game.Lighting
								task.wait(0.04)
								v187.TintColor = Color3.new(1, 1, 1)
								task.wait(0.04)
								v187.Brightness = 200
								v187.Contrast = -1000
								task.wait(0.04)
								v187:Destroy()
							end
							v186.BloodParticle.TimeScale = 0.075
							local v188 = TweenInfo.new(1.6, Enum.EasingStyle.Circular, Enum.EasingDirection.In)
							for _, v189 in v186:GetDescendants() do
								if v189:IsA("ParticleEmitter") then
									v_u_4:Create(v189, v188, {
										["TimeScale"] = 1
									}):Play()
								else
									if not v189:IsA("Beam") then
										continue
									end
									v_u_4:Create(v189, v188, {
										["Width0"] = 0,
										["Width1"] = 0,
										["TextureSpeed"] = nil,
										["TextureSpeed"] = v189.TextureSpeed * 5
									}):Play()
								end
							end
						end)
						if v_u_5.Character == p173 then
							local v_u_190 = v_u_7.Nanami.OvertimeAura.Music:Clone()
							v_u_190.Parent = v_u_174
							v_u_190.SoundGroup = game.SoundService.Music
							v_u_190.TimePosition = 38.3
							v_u_190:Play()
							task.delay(2, function()
								-- upvalues: (ref) v_u_4, (copy) v_u_190
								v_u_4:Create(v_u_190, TweenInfo.new(1), {
									["Volume"] = 0
								}):Play()
							end)
						end
						task.wait(0.6)
						local v_u_191 = 0
						local v_u_192 = nil
						tick()
						local v_u_193 = v_u_7.Nanami.RatioBreaker.Attack4.CutsceneFrames
						v_u_192 = v_u_2.RenderStepped:Connect(function(p194)
							-- upvalues: (ref) v_u_191, (copy) v_u_193, (copy) p_u_172, (copy) v_u_174, (copy) v_u_176, (ref) v_u_192, (ref) v_u_5, (ref) v_u_4, (ref) v_u_9, (ref) v_u_7
							v_u_191 = v_u_191 + p194 * 60
							local v195 = v_u_193.Frames
							local v196 = v_u_191
							local v197 = math.ceil(v196)
							local v198 = v195:FindFirstChild((tonumber(v197)))
							local v199 = v_u_193.FOV
							local v200 = v_u_191
							local v201 = math.ceil(v200)
							local v202 = v199:FindFirstChild((tonumber(v201)))
							if v198 and (v202 and (p_u_172.Parent and v_u_174)) then
								v_u_176.CFrame = v_u_174.CFrame * v198.Value
								v_u_176.FieldOfView = v202.Value
								v_u_176.CameraType = Enum.CameraType.Scriptable
							else
								v_u_192:Disconnect()
								v_u_176.CameraType = Enum.CameraType.Custom
								v_u_176.FieldOfView = 70
								v_u_176.CameraSubject = (v_u_5.Character or v_u_5.CharacterAdded:Wait()):WaitForChild("Humanoid")
								v_u_176.FieldOfView = 70
								game.Lighting.ExposureCompensation = 2
								v_u_4:Create(game.Lighting, TweenInfo.new(1), {
									["ExposureCompensation"] = 0
								}):Play()
								v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
								if _G.Settings.Flash == true then
									local v203 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
									v203.Parent = game.Lighting
									task.wait(0.04)
									v203.TintColor = Color3.new(1, 1, 1)
									task.wait(0.04)
									v203.Brightness = 200
									v203.Contrast = -1000
									task.wait(0.04)
									v203:Destroy()
								end
							end
						end)
					else
						v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB4.Hit, v_u_175, game.SoundService.Effect)
					end
				else
					return
				end
			else
				return
			end
		end,
		["RatioBreakerFinisher"] = function(p204)
			-- upvalues: (ref) v_u_15
			if p204:FindFirstChild("HumanoidRootPart") then
				v_u_15:Bleed(p204)
			end
		end
	}
	v_u_14.Effects:Connect(function(p206, ...)
		-- upvalues: (copy) v_u_205
		local v207 = v_u_205[p206]
		if v207 then
			v207(...)
		end
	end)
end
function v17.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_14, (copy) v_u_1, (ref) v_u_16, (ref) v_u_15
	v_u_14 = v_u_1.GetService("RatioBreakerService")
	v_u_16 = v_u_1.GetController("HitboxController")
	v_u_15 = v_u_1.GetController("FXController")
end
return v17