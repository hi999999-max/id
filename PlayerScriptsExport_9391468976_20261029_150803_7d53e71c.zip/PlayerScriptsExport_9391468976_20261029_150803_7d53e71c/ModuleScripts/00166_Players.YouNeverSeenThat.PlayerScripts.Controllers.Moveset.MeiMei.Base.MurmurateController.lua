-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.MeiMei.Base.MurmurateController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "MurmurateController"
})
local v_u_13 = RaycastParams.new()
v_u_13.FilterType = Enum.RaycastFilterType.Include
v_u_13.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_5, (copy) v_u_2, (copy) v_u_13, (ref) v_u_11, (copy) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_9, (copy) v_u_6, (copy) v_u_4, (ref) v_u_10
	local v_u_14 = 1
	local v_u_93 = {
		["Flight"] = function(p15, p_u_16, p_u_17)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_13
			local v_u_18 = p15:FindFirstChild("HumanoidRootPart")
			if v_u_18 then
				p15:FindFirstChild("Humanoid")
				if p15 == v_u_5.Character then
					local v_u_19 = tick()
					local v_u_20 = 0.55
					local v_u_21 = 40
					local v_u_22 = 80
					local v23 = v_u_18.CFrame.LookVector
					local _ = v_u_18.CFrame.RightVector
					local v_u_24 = (v23 + Vector3.new(0, 1, 0)).Unit
					local v_u_25 = (v23 - Vector3.new(0, 1, 0)).Unit
					local v_u_26 = (v23 - Vector3.new(0, 20, 0)).Unit
					local v_u_27 = 1
					local v_u_28 = Instance.new("BodyGyro")
					v_u_28.P = 10000
					v_u_28.MaxTorque = Vector3.new(40000, 40000, 40000)
					v_u_28.CFrame = CFrame.lookAt(Vector3.new(0, 0, 0), v_u_24)
					v_u_28.Parent = v_u_18
					local v_u_29 = nil
					v_u_29 = v_u_2.Heartbeat:Connect(function(_)
						-- upvalues: (copy) p_u_16, (copy) v_u_18, (ref) v_u_29, (copy) v_u_28, (ref) v_u_19, (ref) v_u_20, (ref) v_u_27, (copy) v_u_24, (copy) v_u_25, (ref) v_u_21, (ref) v_u_22, (copy) v_u_26, (ref) v_u_13, (copy) p_u_17
						if p_u_16 and (p_u_16.Parent and v_u_18.Parent) then
							local v30 = (tick() - v_u_19) / v_u_20
							local v31 = math.clamp(v30, 0, 1)
							local v32
							if v_u_27 == 1 then
								v32 = v_u_24:Lerp(v_u_25, v31).Unit
								if v31 >= 1 then
									v_u_27 = 2
									v_u_19 = tick()
									v_u_21 = v_u_22
									v_u_22 = v_u_22 + 125
									v_u_20 = 1.25
								end
							else
								v32 = v_u_25:Lerp(v_u_26, v31).Unit
							end
							local v33 = v_u_21 + (v_u_22 - v_u_21) * v31
							local v34 = CFrame.lookAt(Vector3.new(0, 0, 0), v32)
							workspace:Raycast((v_u_18.CFrame * CFrame.new(0, 0, -2)).Position, p_u_16.Velocity.Unit * 6, v_u_13)
							v_u_28.CFrame = CFrame.lookAt(Vector3.new(0, 0, 0), v32 * Vector3.new(1, 0, 1))
							p_u_16.Velocity = v34.LookVector * v33
							if p_u_16.Velocity.Y <= 0 then
								local v35 = workspace:Raycast((v_u_18.CFrame * CFrame.new(0, 0, -7)).Position, (p_u_16.Velocity * Vector3.new(0, 1, 0)).Unit * 6, v_u_13)
								local v36
								if v35 then
									v36 = nil
								else
									v36 = workspace:Raycast(v_u_18.Position, Vector3.new(-0, -5, -0), v_u_13)
								end
								if v35 or (v36 or v_u_18.Position.Y < -100) then
									p_u_17:FireServer(v35 and v35.Position or (v_u_18.CFrame * CFrame.new(0, 0, -7)).Position - Vector3.new(0, 3.5, 0), v35 and v35.Normal or Vector3.new(0, 1, 0))
									p_u_16:Destroy()
									v_u_28:Destroy()
								end
							end
						else
							v_u_29:Disconnect()
							p_u_16:Destroy()
							v_u_28:Destroy()
							return
						end
					end)
				end
			end
		end,
		["Start"] = function(p37)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v38 = p37:FindFirstChild("HumanoidRootPart")
			if v38 then
				v_u_11:PlaySound(v_u_8.MeiMei.Murmurate.AxeThrow, v38, game.SoundService.Effect)
			end
		end,
		["Hit"] = function(p39, p40)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			if p39:FindFirstChild("HumanoidRootPart") then
				local v41 = p40:FindFirstChild("HumanoidRootPart")
				if v41 then
					v_u_11:PlaySound(v_u_8.MeiMei.Gliding["SpinHit" .. math.random(1, 2)], v41, game.SoundService.Effect)
					v_u_11:Flash(p40, Color3.new(1, 1, 1))
					local v42 = v_u_7.Mahito.CrushingRushdown.DrillImpact:Clone()
					v42.Position = v41.Position
					v42.Parent = workspace.Effects
					v_u_3:AddItem(v42, 1)
					v42.Sparks.Color = ColorSequence.new(Color3.new(0.513725, 0.643137, 1))
					v42.Wind.Color = v42.Sparks.Color
					v42.Wind2.Color = v42.Sparks.Color
					v42.Sparks:Emit(30)
					v42.Wind2:Emit(7)
				end
			else
				return
			end
		end,
		["Hit2"] = function(p43, p44)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v45 = p43:FindFirstChild("HumanoidRootPart")
			if v45 then
				local v46 = p44:FindFirstChild("HumanoidRootPart")
				if v46 then
					v_u_11:PlaySound(v_u_8.MeiMei.Gliding.FallHit, v46, game.SoundService.Effect)
					v_u_11:Flash(p44, Color3.new(1, 1, 1))
					local v47 = v_u_7.MeiMei.SlashHit:Clone()
					local v48 = Instance.new("Model")
					v47.Parent = v48
					v48:ScaleTo(1.7)
					v_u_3:AddItem(v48, 0.1)
					v47.CFrame = CFrame.lookAlong(v46.Position, v45.CFrame.LookVector) * CFrame.Angles(0, 0, 1.5707963267948966)
					for _, v49 in v47:GetDescendants() do
						if not v49:IsA("ParticleEmitter") or v49.Lifetime ~= 0.15 then
							continue
						end
						v49.Lifetime = 0.25
					end
					v47.Parent = workspace.Effects
					v_u_3:AddItem(v47, 0.5)
					v_u_11:PlayParticles(v47)
					if v_u_5.Character == p43 or v_u_5.Character == p44 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.SnapOh)
					end
				end
			else
				return
			end
		end,
		["Slash2"] = function(p50)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_6, (ref) v_u_3, (ref) v_u_4
			local v51 = p50:FindFirstChild("HumanoidRootPart")
			if v51 then
				v_u_11:PlaySound(v_u_8.MeiMei.Gliding.FallSlash, v51, game.SoundService.Effect)
				local v52 = v_u_6.Utils.MeiMei.MeiMeiSlash:Clone()
				local v53 = Instance.new("Model")
				v52.Parent = v53
				v53:ScaleTo(1.7)
				v_u_3:AddItem(v53, 0.1)
				v52.Weld.Part0 = v51
				v52.Weld.C0 = CFrame.Angles(0, 3.141592653589793, -1.5707963267948966)
				for _, v54 in pairs(v52:GetDescendants()) do
					if not v54:IsA("ParticleEmitter") then
						continue
					end
					local v55 = NumberRange.new
					local v56 = v54.RotSpeed.Max
					v54.RotSpeed = v55((math.abs(v56)))
					v54:Emit(v54:GetAttribute("EmitCount"))
				end
				v52.Parent = workspace.Effects
				v_u_3:AddItem(v52, 1)
				local v57 = v_u_6.Utils.MeiMei.Circling.SwingMesh:Clone()
				v57.Transparency = 0.05
				v57.Mesh.Scale = Vector3.new(0.25, 1, 0.25)
				v57.Mesh.VertexColor = Vector3.new(1.5, 1.5, 2.25)
				v57.Weld.Part0 = v51
				v57.Weld.C0 = CFrame.Angles(0, 0, -1.5707963267948966)
				v_u_4:Create(v57.Weld, TweenInfo.new(0.15, Enum.EasingStyle.Linear), {
					["C0"] = v57.Weld.C0 * CFrame.Angles(0, 3.1066860685499065, 0)
				}):Play()
				v_u_4:Create(v57.Mesh, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Scale"] = Vector3.new(1, 0.25, 1)
				}):Play()
				v_u_4:Create(v57.Mesh, TweenInfo.new(0.09999999999999999, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
					["VertexColor"] = Vector3.new(0.5, 0.5, 0.75)
				}):Play()
				v_u_4:Create(v57, TweenInfo.new(0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.In), {
					["Transparency"] = 1
				}):Play()
				v57.Parent = workspace.Effects
				v_u_3:AddItem(v57, 0.15)
				task.wait(0.3)
				v52.Weld:Destroy()
				v52.Anchored = true
			end
		end,
		["Slash"] = function(p58, p59)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_14, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v60 = p58:FindFirstChild("HumanoidRootPart")
			if v60 then
				if p59 and not p59:GetAttribute("Start") then
					p59:SetAttribute("Start", true)
					v_u_11:PlaySound(v_u_8.MeiMei.Gliding.Start, v60, game.SoundService.Effect)
				else
					v_u_11:PlaySound(v_u_8.MeiMei.Gliding["Slash" .. v_u_14], v60, game.SoundService.Effect)
					v_u_14 = v_u_14 + 1
					if v_u_14 > 3 then
						v_u_14 = 1
					end
				end
				local v_u_61 = v_u_7.MeiMei.Circling.MeiMeiWideSlash3:Clone()
				v_u_61.Weld.Part0 = v60
				v_u_61.Weld.C0 = CFrame.new(-0.5, 0, 0) * CFrame.Angles(0, 0, -1.5707963267948966)
				for _, v62 in pairs(v_u_61:GetDescendants()) do
					if not v62:IsA("ParticleEmitter") then
						continue
					end
					v62:Emit(v62:GetAttribute("EmitCount"))
				end
				v_u_61.Parent = workspace.Effects
				task.delay(0.25, function()
					-- upvalues: (copy) v_u_61
					v_u_61.Weld:Destroy()
					v_u_61.Anchored = true
				end)
				v_u_3:AddItem(v_u_61, 1.5)
				for v63 = 1, 2 do
					local v64 = v63 == 2 and 180 or 0
					local v65 = v_u_7.MeiMei.Circling.SwingMesh:Clone()
					v65.Transparency = 0.05
					v65.Mesh.Scale = Vector3.new(0.15, 1, 0.15)
					v65.Mesh.VertexColor = Vector3.new(1.5, 1.5, 2.25)
					v65.Weld.Part0 = v60
					v65.Weld.C0 = CFrame.new(-0.5, -1, 0) * CFrame.Angles(3.141592653589793, 1.5707963267948966, 3.141592653589793) * CFrame.Angles(0, math.rad(v64), 0) * CFrame.Angles(1.5707963267948966, 0, 0)
					v_u_4:Create(v65.Weld, TweenInfo.new(0.25, Enum.EasingStyle.Linear), {
						["C0"] = v65.Weld.C0 * CFrame.Angles(0, 3.1066860685499065, 0)
					}):Play()
					v_u_4:Create(v65.Mesh, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Scale"] = Vector3.new(0.5, 0.25, 0.5)
					}):Play()
					v_u_4:Create(v65.Mesh, TweenInfo.new(0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["VertexColor"] = Vector3.new(0.5, 0.5, 0.75)
					}):Play()
					v_u_4:Create(v65, TweenInfo.new(0.25, Enum.EasingStyle.Quint, Enum.EasingDirection.In), {
						["Transparency"] = 1
					}):Play()
					v65.Parent = workspace.Effects
					v_u_3:AddItem(v65, 0.25)
				end
				local v66 = v_u_7.MeiMei.Circling.WindMesh2:Clone()
				v66.Weld.Part0 = v60
				v66.Weld.C0 = CFrame.new(-0.5, -2, 0) * CFrame.Angles(0, 1.5707963267948966, 0) * CFrame.Angles(1.5707963267948966, 0, 0)
				v66.Transparency = 0.95
				v66.Size = Vector3.new(10, 2.5, 10)
				v_u_4:Create(v66, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(35, 15, 35),
					["Transparency"] = 1
				}):Play()
				v_u_4:Create(v66.Weld, TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
					["C0"] = v66.Weld.C0 * CFrame.new(0, -0.5, 0) * CFrame.Angles(0, -3.12413936106985, 0)
				}):Play()
				v66.Parent = workspace.Effects
				v_u_3:AddItem(v66, 0.25)
			end
		end,
		["Land"] = function(p67, p68)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9
			local v69 = p67:FindFirstChild("HumanoidRootPart")
			if v69 then
				local v70 = v_u_6.Utils.MeiMei.Slam:Clone()
				local v71 = Instance.new("Model")
				v70.Parent = v71
				v71:ScaleTo(1.5)
				v_u_3:AddItem(v71, 0.1)
				v70.CFrame = CFrame.lookAt(p68, p68 + v69.CFrame.lookVector) + v69.CFrame.LookVector * 3
				v_u_11:PlayParticles(v70)
				v70.Parent = workspace.Effects
				v_u_3:AddItem(v70, 1)
				v_u_11:PlaySound(v_u_8.MeiMei.Gliding.Impact, v70, game.SoundService.Effect)
				local v72 = v_u_6.Utils.MeiMei.ShockwaveMesh:Clone()
				v72.Transparency = 0
				v72.Size = Vector3.new(1, 0.01, 10)
				v72.CFrame = v70.CFrame * CFrame.Angles(0, 3.141592653589793, 0) * CFrame.new(-2, 2.75, -2) * CFrame.Angles(-1.5707963267948966, 0, 1.2217304763960306)
				v72.Parent = workspace.Effects
				v_u_4:Create(v72, TweenInfo.new(0.28, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["CFrame"] = nil,
					["Size"] = Vector3.new(30, 0, 5),
					["Transparency"] = 1,
					["CFrame"] = v72.CFrame * CFrame.new(-15, 0, -0.5)
				}):Play()
				v_u_4:Create(v72, TweenInfo.new(0.28, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v72, 1)
				local v73 = v_u_6.Utils.MeiMei.ShockwaveMesh:Clone()
				v73.Transparency = 0
				v73.Size = Vector3.new(1, 1, 10)
				v73.CFrame = v70.CFrame * CFrame.Angles(0, 3.141592653589793, 0) * CFrame.new(2, 2.75, -2) * CFrame.Angles(-1.5707963267948966, 0, 1.9198621771937625)
				v73.Parent = workspace.Effects
				v_u_4:Create(v73, TweenInfo.new(0.28, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["CFrame"] = nil,
					["Size"] = Vector3.new(30, 0, 5),
					["CFrame"] = v73.CFrame * CFrame.new(-15, 0, -0.5)
				}):Play()
				v_u_4:Create(v73, TweenInfo.new(0.28, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v73, 1)
				local v74 = v_u_6.Utils.MeiMei.WindMesh2:Clone()
				local v75 = v69.CFrame * CFrame.new(0, -2, 0)
				local v76 = CFrame.Angles
				local v77 = math.random(-180, 180)
				v74.CFrame = v75 * v76(0, math.rad(v77), 0)
				v74.Transparency = 0.95
				v74.Size = Vector3.new(10, 2.5, 10)
				v_u_4:Create(v74, TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
					["CFrame"] = nil,
					["Size"] = Vector3.new(35, 15, 35),
					["Transparency"] = 1,
					["CFrame"] = v74.CFrame * CFrame.new(0, -0.5, 0) * CFrame.Angles(0, -3.12413936106985, 0)
				}):Play()
				v74.Parent = workspace.Effects
				v_u_3:AddItem(v74, 0.2)
				local v78 = v_u_6.Utils.MeiMei.SpikeMesh1:Clone()
				v78.Size = Vector3.new(1, 20, 1)
				v78.Transparency = 0.75
				local v79 = CFrame.new(p68) * CFrame.new(0, 10, 0)
				local v80 = CFrame.Angles
				local v81 = math.random(-180, 180)
				v78.CFrame = v79 * v80(0, math.rad(v81), 0)
				v_u_4:Create(v78, TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
					["CFrame"] = nil,
					["Size"] = Vector3.new(20, 2.5, 20),
					["Transparency"] = 1,
					["CFrame"] = v78.CFrame * CFrame.new(0, -10, 0) * CFrame.Angles(0, 1.5707963267948966, 0)
				}):Play()
				v78.Parent = workspace.Effects
				v_u_3:AddItem(v78, 0.2)
				if v_u_5.Character == p67 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Throw"] = function(p82, p83, p84)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v85 = p82:FindFirstChild("HumanoidRootPart")
			if v85 then
				local v86 = v_u_11:PlaySound(v_u_8.MeiMei.Murmurate.AxeSpin, v85, game.SoundService.Effect)
				local v87 = v_u_7.MeiMei.Murmurate:Clone()
				v87.Parent = p83.Stick
				v_u_3:AddItem(v87, 10)
				for _, v88 in v87:GetDescendants() do
					if not v88:IsA("ParticleEmitter") then
						continue
					end
					v88:Emit(v88:GetAttribute("EmitCount"))
					v88.Lifetime = NumberRange.new(v88.Lifetime.Min * 0.5, v88.Lifetime.Max * 0.5)
				end
				task.wait(0.15)
				for _, v89 in v87:GetDescendants() do
					if not v89:IsA("ParticleEmitter") then
						continue
					end
					v89:Emit(v89:GetAttribute("EmitCount"))
				end
				if p84.Parent ~= nil then
					break
				end
				for _, v90 in v87:GetDescendants() do
					if not v90:IsA("ParticleEmitter") then
						continue
					end
					v90.LockedToPart = false
				end
				v_u_4:Create(v86, TweenInfo.new(0.25), {
					["Volume"] = 0
				}):Play()
				v_u_3:AddItem(v86, 0.25)
			end
		end,
		["Catch"] = function(p91)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v92 = p91:FindFirstChild("HumanoidRootPart")
			if v92 then
				v_u_11:PlaySound(v_u_8.MeiMei.Murmurate.AxeCatch, v92, game.SoundService.Effect)
			end
		end
	}
	v_u_10.Effects:Connect(function(p94, ...)
		-- upvalues: (copy) v_u_93
		local v95 = v_u_93[p94]
		if v95 then
			v95(...)
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("MurmurateService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12