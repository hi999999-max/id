-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Hanami.HanamiController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v_u_10 = require(v_u_6.Modules.BloodyZee)
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "HanamiController"
})
local v_u_15 = { Color3.fromRGB(86, 66, 54), Color3.fromRGB(76, 60, 51), Color3.fromRGB(86, 60, 51) }
local v_u_16 = RaycastParams.new()
v_u_16.FilterType = Enum.RaycastFilterType.Include
v_u_16.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
function v14.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_13, (copy) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (copy) v_u_4, (copy) v_u_15, (copy) v_u_2, (copy) v_u_6, (copy) v_u_10, (copy) v_u_16, (copy) v_u_1, (ref) v_u_11
	local v_u_231 = {
		["Hit"] = function(p17, p18)
			-- upvalues: (ref) v_u_13, (ref) v_u_8
			local v19 = p17:FindFirstChild("HumanoidRootPart")
			if v19 then
				v_u_13:Flash(p17, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit" .. p18), v19, game.SoundService.Effect)
			end
		end,
		["ChaseHit"] = function(p20, p21)
			-- upvalues: (ref) v_u_13, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v22 = p20:FindFirstChild("HumanoidRootPart")
			if v22 then
				local v23 = p21:FindFirstChild("HumanoidRootPart")
				if v23 then
					v_u_13:Flash(p21, Color3.new(1, 1, 1))
					v_u_13:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit3"), v23, game.SoundService.Effect)
					local v24 = v_u_7.ChaseHit:Clone()
					local v25 = CFrame.new
					local v26 = v23.Position
					local v27 = v22.Position.X
					local v28 = v23.Position.Y
					local v29 = v22.Position.Z
					v24.CFrame = v25(v26, (Vector3.new(v27, v28, v29))) * CFrame.Angles(0, 3.141592653589793, 0)
					v24.Parent = workspace.Effects
					v24.Ring:Emit(7)
					v24.Sparks:Emit(12)
					v_u_3:AddItem(v24, 0.5)
				end
			else
				return
			end
		end,
		["AerialHit"] = function(p30, p31)
			-- upvalues: (ref) v_u_13, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (ref) v_u_3
			local v32 = p30:FindFirstChild("HumanoidRootPart")
			if v32 then
				local v33 = p31:FindFirstChild("HumanoidRootPart")
				if v33 then
					v_u_13:Flash(p31, Color3.new(1, 1, 1))
					v_u_13:PlaySound(v_u_8.Itadori.CraniumSmash.Hit2, v33, game.SoundService.Effect)
					if v_u_5.Character == p30 or v_u_5.Character == p31 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					end
					local v34 = CFrame.new(v32.Position, v33.Position - Vector3.new(0, 4, 0))
					local v35 = v_u_7.Gojo.HardHit:Clone()
					v35.CFrame = v34 + v34.LookVector * 4
					v35.Parent = workspace.Effects
					v35.Dust:Emit(5)
					v35.Ring:Emit(5)
					v35.Sparks:Emit(10)
					v_u_3:AddItem(v35, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p36)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_8
			local v37 = p36.HumanoidRootPart
			if v37 then
				local v38 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v38.CFrame = v37.CFrame * CFrame.new(0, 1, -4)
				v38.Size = Vector3.new(0, 0, 2)
				v38.Parent = workspace.Effects
				v_u_4:Create(v38, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v38, 0.3)
				v_u_13:PlaySound(v_u_8.Misc.Chase, v37, game.SoundService.Effect)
				v_u_13:DustTrail(p36, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p39)
			-- upvalues: (ref) v_u_13, (ref) v_u_8
			local v40 = p39:FindFirstChild("HumanoidRootPart")
			if v40 then
				v_u_13:PlaySound(v_u_8.Misc.Swing.Fist, v40, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p41, p42, p43)
			-- upvalues: (ref) v_u_13
			if p43 == "Down" then
				v_u_13:ArmFlash(p41["Right Leg"], Color3.fromRGB(172, 203, 163), 0.4)
				return
			elseif p42 == 1 and p41:GetAttribute("InUlt") then
				v_u_13:ArmFlash(p41["Left Arm"], Color3.fromRGB(172, 203, 163), 0.3)
			else
				v_u_13:ArmFlash(p41["Right Arm"], Color3.fromRGB(172, 203, 163), 0.3)
			end
		end,
		["Launch"] = function(p44, p45)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v46 = p44:FindFirstChild("HumanoidRootPart")
			if v46 then
				local v47 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v47.CFrame = CFrame.new(v46.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v47.Size = Vector3.new(0, 0, 5)
				v47.Parent = workspace.Effects
				v_u_4:Create(v47, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v47.Position + Vector3.new(0, p45, 0)
				}):Play()
				v_u_3:AddItem(v47, 0.3)
				if p45 < 0 then
					v_u_13:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v46, game.SoundService.Effect)
					v_u_13:DustBreak(v46.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v46.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			end
		end,
		["ApplyDaze"] = function(p48, p49)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_13
			local v50 = p48:FindFirstChild("Torso")
			if v50 then
				local v_u_51 = v_u_7.Hanami.Petals:Clone()
				v_u_51.Parent = workspace.Effects
				v_u_51.Weld.Part0 = v50
				p49.Destroying:Once(function()
					-- upvalues: (copy) v_u_51, (ref) v_u_3
					for _, v52 in v_u_51:QueryDescendants("ParticleEmitter") do
						v52.Enabled = false
					end
					v_u_3:AddItem(v_u_51, 2)
				end)
				while p49.Parent do
					v_u_13:Flash(p48, Color3.fromRGB(255, 170, 255), 8)
					v_u_51.Root.Ring:Emit(2)
					task.wait(8)
				end
			end
		end,
		["ApplyBud"] = function(p53, p_u_54)
			-- upvalues: (ref) v_u_7, (ref) v_u_3
			local v55 = p53:FindFirstChild("Torso")
			if v55 then
				local v_u_56 = v_u_7.Hanami.Buds:Clone()
				v_u_56.Parent = workspace.Effects
				v_u_56.Weld.Part0 = v55
				v_u_56.Root.Sparks:Emit(10)
				task.spawn(function()
					-- upvalues: (copy) v_u_56, (copy) p_u_54
					local v57 = v_u_56.Weld.C1
					for _, v58 in v_u_56.Buds:GetChildren() do
						local v59 = v58.Name
						if tonumber(v59) <= p_u_54.Value then
							continue
						end
						v58:Destroy()
					end
					for v60 = 1, p_u_54.Value do
						if v_u_56.Buds:FindFirstChild(v60) then
							continue
						end
						local v61 = v_u_56.Buds["1"]:Clone()
						v61.Name = v60
						local v62 = v61.Weld
						local v63 = CFrame.new(math.random(-5, 5) / 10, math.random(-5, 5) / 10, 0)
						local v64 = CFrame.Angles
						local v65 = math.random(-45, 45)
						local v66 = math.rad(v65)
						local v67 = math.random(-45, 45)
						local v68 = math.rad(v67)
						local v69 = math.random(0, 360)
						v62.C0 = v63 * v64(v66, v68, (math.rad(v69)))
						v61.Parent = v_u_56.Buds
					end
					local v70 = v_u_56.Weld
					local v71 = CFrame.Angles
					local v72 = math.random(-7, 7)
					local v73 = math.rad(v72)
					local v74 = math.random(-7, 7)
					local v75 = math.rad(v74)
					local v76 = math.random(-5, 5)
					v70.C1 = v57 * v71(v73, v75, (math.rad(v76)))
					task.wait(0.05)
					if v_u_56.Parent then
						break
					end
				end)
				p_u_54.Destroying:Once(function()
					-- upvalues: (copy) v_u_56, (ref) v_u_3
					v_u_56.Root.Charge.Enabled = false
					v_u_56.Root.Sparks:Emit(10)
					v_u_3:AddItem(v_u_56, 1)
					v_u_56.Buds:Destroy()
				end)
			end
		end,
		["Field"] = function(p77, p78)
			-- upvalues: (ref) v_u_7, (ref) v_u_13, (ref) v_u_8
			if p77:FindFirstChild("HumanoidRootPart") then
				local v79 = workspace:Raycast(p78.Position + p78.lookVector * 1, Vector3.new(0, -12, 0), _G.MapParams)
				if v79 then
					local v80 = v_u_7.Hanami.FlowerField:Clone()
					v80.CFrame = p78 - p78.Position + v79.Position + Vector3.new(0, 0.3, 0)
					v80.Parent = workspace.Effects
					v_u_13:PlaySound(v_u_8.Hanami.FlowersField.Field, v80, game.SoundService.Effect)
					local v81 = v80.CFrame
					local v82 = v80.CFrame + p78.lookVector * 24
					local v83 = tick()
					local v84 = (tick() - v83) / 0.3
					local v85 = v81:Lerp(v82, (math.clamp(v84, 0, 1)))
					local v86 = workspace:Raycast(v85.Position + Vector3.new(0, 2, 0), Vector3.new(0, -12, 0), _G.MapParams)
					if v86 then
						v80.CFrame = CFrame.lookAlong(v86.Position + Vector3.new(0, 0.3, 0), v85.LookVector)
					end
					task.wait()
					if tick() - v83 <= 0.3 then
						continue
					end
					for _, v87 in v80:GetDescendants() do
						if not v87:IsA("ParticleEmitter") then
							continue
						end
						v87.Enabled = false
					end
					task.wait(2)
					v80:Destroy()
				end
			end
		end,
		["FieldStart"] = function(p88)
			-- upvalues: (ref) v_u_13, (ref) v_u_8
			local v89 = p88:FindFirstChild("HumanoidRootPart")
			if v89 then
				v_u_13:PlaySound(v_u_8.Hanami.FlowersField.Startup, v89, game.SoundService.Effect)
			end
		end,
		["FlowersFieldHit"] = function(p90)
			-- upvalues: (ref) v_u_13, (ref) v_u_8
			local v91 = p90:FindFirstChild("HumanoidRootPart")
			if v91 then
				v_u_13:PlaySound(v_u_8.Hanami.FlowersField.Hit, v91, game.SoundService.Effect)
			end
		end,
		["Lasso"] = function(p92, p_u_93, p94)
			-- upvalues: (ref) v_u_15, (ref) v_u_13, (ref) v_u_8, (ref) v_u_2, (ref) v_u_4
			local v95 = p92.HumanoidRootPart
			if v95 then
				local v96 = p94.lookVector
				local v97 = p94.rightVector
				local v98 = workspace:Raycast(p94.Position + v97 * 3 - v96 * 4, Vector3.new(0, -12, 0), _G.MapParams)
				if v98 then
					local v99 = Random.new()
					local v_u_100 = v98.Position
					local v_u_101 = v98.Position
					local v_u_102 = v98.Position
					local v103 = v_u_15[v99:NextInteger(1, #v_u_15)]
					local v_u_104 = p94 * CFrame.new(0, 1, -40)
					v_u_13:DustBreak(v98.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					v_u_13:PlaySound(v_u_8.Hanami.AOESpikes.WoodBallsAppear, v95, game.SoundService.Effect)
					v_u_13:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v95, game.SoundService.Effect)
					local v105 = v_u_100
					local v_u_106 = {}
					local v_u_107 = nil
					local v_u_108 = nil
					local v_u_109 = nil
					local v_u_110 = nil
					for v111 = 1, 8 do
						local v112 = v111 / 8
						local v113 = v112 * -0.9 + 1.3
						local v114 = v_u_100 + (v_u_102 - v_u_100) * v112
						local v115 = v114 + (v_u_102 + (v_u_101 - v_u_102) * v112 - v114) * v112
						local v116 = Instance.new("Part")
						v116.Name = v111
						v116.CanCollide = false
						v116.Transparency = 0
						v116.Anchored = true
						v116.Color = v_u_15[v99:NextInteger(1, #v_u_15)]
						v116.Material = Enum.Material.Wood
						v116.CFrame = CFrame.new(v115, v105) * CFrame.new(0, 0, -(v105 - v115).Magnitude / 2)
						local v117 = (v115 - v105).Magnitude * 1.25
						v116.Size = vector.create(v113, v113, v117)
						v_u_106[v111] = v116
						v116.Parent = p_u_93.Parts
						v105 = v115
					end
					local v_u_118 = 0
					local v_u_119 = 0
					local v_u_120 = 0.4
					local v_u_121 = v98.Position + Vector3.new(0, 2.5, 0) + -v96 * 10 + v97 * 10
					local v_u_122 = v98.Position + Vector3.new(0, 10, 0) + v97 * 10
					local v_u_123 = v98.Position + Vector3.new(0, 10, 0) + v96 * 10
					local v_u_124 = v98.Position + Vector3.new(0, 2.5, 0) + -v96 * 10
					local v_u_125 = false
					local _ = v_u_2.PreRender:Connect(function()
						-- upvalues: (copy) p_u_93, (ref) v_u_125, (ref) v_u_107, (ref) v_u_108, (ref) v_u_109, (ref) v_u_110, (copy) v_u_100, (copy) v_u_106, (ref) v_u_102, (ref) v_u_101
						if p_u_93.Parent then
							if v_u_125 == false and p_u_93.Grab.Value then
								v_u_125 = true
							end
						else
							if v_u_107 then
								v_u_107:Disconnect()
								v_u_107 = nil
							end
							if v_u_108 then
								v_u_108:Disconnect()
								v_u_108 = nil
							end
							if v_u_109 then
								v_u_109:Disconnect()
								v_u_109 = nil
							end
							if v_u_110 then
								v_u_110:Disconnect()
								v_u_110 = nil
							end
						end
						local v126 = v_u_100
						for v127, v128 in ipairs(v_u_106) do
							local v129 = v127 / #v_u_106
							local v130 = v_u_100
							local v131 = v_u_102
							local v132 = v_u_101
							local v133 = v130 + (v131 - v130) * v129
							local v134 = v133 + (v131 + (v132 - v131) * v129 - v133) * v129
							local v135 = (v134 - v126).Magnitude
							v128.CFrame = CFrame.new(v134, v126) * CFrame.new(0, 0, -v135 / 2)
							local v136 = v128.Size.X
							local v137 = v128.Size.Y
							local v138 = v135 * 1.25
							v128.Size = vector.create(v136, v137, v138)
							v126 = v134
						end
					end)
					local v146 = v_u_2.PreRender:Connect(function(p139)
						-- upvalues: (ref) v_u_118, (ref) v_u_102, (copy) v_u_121, (copy) v_u_122, (ref) v_u_109
						v_u_118 = v_u_118 + p139
						local v140 = v_u_118 / 0.2
						local v141 = math.min(v140, 1)
						local v142 = v_u_102
						local v143 = v_u_121
						local v144 = v_u_122
						local v145 = v142 + (v143 - v142) * v141
						v_u_102 = v145 + (v143 + (v144 - v143) * v141 - v145) * v141
						if v141 >= 1 then
							v_u_109:Disconnect()
							v_u_109 = nil
						end
					end)
					local v154 = v_u_2.PreRender:Connect(function(p147)
						-- upvalues: (ref) v_u_119, (ref) v_u_120, (ref) v_u_101, (copy) v_u_123, (copy) v_u_124, (ref) v_u_110
						v_u_119 = v_u_119 + p147
						local v148 = v_u_119 / v_u_120
						local v149 = math.min(v148, 1)
						local v150 = v_u_101
						local v151 = v_u_123
						local v152 = v_u_124
						local v153 = v150 + (v151 - v150) * v149
						v_u_101 = v153 + (v151 + (v152 - v151) * v149 - v153) * v149
						if v149 >= 1 then
							v_u_110:Disconnect()
							v_u_110 = nil
						end
					end)
					task.wait(0.2)
					v_u_13:PlaySound(v_u_8.Hanami.DefenseResponse.Startup, v95, game.SoundService.Effect)
					if v146 then
						v146:Disconnect()
					end
					if v154 then
						v154:Disconnect()
					end
					v_u_118 = 0
					local v_u_155 = (v_u_122 + v_u_104.Position) / 2 - v97 * 2.5
					v146 = v_u_2.PreRender:Connect(function(p156)
						-- upvalues: (ref) v_u_118, (ref) v_u_102, (copy) v_u_155, (ref) v_u_104
						v_u_118 = v_u_118 + p156
						local v157 = v_u_118 / 0.2
						local v158 = math.min(v157, 1)
						local v159 = v_u_102
						local v160 = v_u_155
						local v161 = v_u_104.Position
						local v162 = v159 + (v160 - v159) * v158
						v_u_102 = v162 + (v160 + (v161 - v160) * v158 - v162) * v158
					end)
					v_u_119 = 0
					local v_u_163 = (v_u_122 + v_u_104.Position) / 2 + Vector3.new(0, 5, 0) + v97 * 10
					v154 = v_u_2.PreRender:Connect(function(p164)
						-- upvalues: (ref) v_u_119, (ref) v_u_120, (ref) v_u_101, (copy) v_u_163, (ref) v_u_104
						v_u_119 = v_u_119 + p164
						local v165 = v_u_119 / v_u_120
						local v166 = math.min(v165, 1)
						local v167 = v_u_101
						local v168 = v_u_163
						local v169 = v_u_104.Position
						local v170 = v167 + (v168 - v167) * v166
						v_u_101 = v170 + (v168 + (v169 - v168) * v166 - v170) * v166
					end)
					task.wait(0.1)
					if v_u_125 and p_u_93.Grab.Value then
						v_u_120 = 0.13333333333333333
						local v_u_171 = p_u_93.Grab.Value
						local v172 = {}
						for v173 = 1, 2 do
							local v174 = Instance.new("Part")
							v174.Name = "StrangleRoot" .. v173
							v174.CanCollide = false
							v174.Anchored = false
							v174.Massless = true
							v174.Color = v103
							v174.Material = Enum.Material.Wood
							v174.Size = Vector3.new(1, 0.5, 1.5)
							v174.CFrame = v_u_171.HumanoidRootPart.CFrame * CFrame.new(0, 1, 0)
							if v173 == 2 then
								v174.CFrame = v174.CFrame * (CFrame.new(0, 0.25, 0) * CFrame.Angles(0, 0, 0.2617993877991494))
							end
							v_u_4:Create(v174, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
								["Size"] = Vector3.new(2.3, 0.6, 1.5)
							}):Play()
							v174.Parent = p_u_93.Parts
							local v175 = Instance.new("WeldConstraint")
							v175.Part0 = v_u_171.HumanoidRootPart
							v175.Part1 = v174
							v175.Parent = v174
							table.insert(v172, v174)
						end
						local v_u_176 = Instance.new("Part")
						v_u_176.Name = "WrappingRoot"
						v_u_176.CanCollide = false
						v_u_176.Anchored = true
						v_u_176.Color = v103
						v_u_176.Material = Enum.Material.Wood
						v_u_176.Size = Vector3.new(1, 7, 1)
						v_u_176.CFrame = CFrame.lookAt(v_u_171.HumanoidRootPart.CFrame * CFrame.new(0, 3, 3).Position, v_u_171.HumanoidRootPart.CFrame * CFrame.new(0, 2, 0).Position)
						v_u_176.Parent = p_u_93.Parts
						v_u_4:Create(v_u_176, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["Size"] = Vector3.new(0.5, 0, 0.5)
						}):Play()
						local v_u_177 = nil
						local v_u_178 = 0
						local v_u_179 = 0
						local _ = v_u_2.PreRender:Connect(function(p180)
							-- upvalues: (ref) v_u_177, (copy) v_u_176, (copy) v_u_171, (ref) v_u_178, (ref) v_u_179, (ref) v_u_104
							v_u_177 = v_u_176.Size.Y / 1.5
							local v181 = (v_u_171.HumanoidRootPart.CFrame * CFrame.new(0, v_u_171.HumanoidRootPart.Size.Y / 2, 0)).Position
							v_u_178 = v_u_178 - 40 * p180
							v_u_179 = v_u_179 + 20 * p180
							local v182 = v_u_178
							local v183 = math.cos(v182) * v_u_177
							local v184 = v_u_179
							local v185 = math.cos(v184) * 0.5
							local v186 = v_u_178
							local v187 = math.sin(v186) * v_u_177
							local v188 = v181 + vector.create(v183, v185, v187)
							local v189 = (v_u_171.HumanoidRootPart.CFrame * CFrame.new(0, 1, 0)).Position
							v_u_176.CFrame = CFrame.lookAt(v188, v189) * CFrame.Angles(0, 0, 0.7853981633974483) * CFrame.Angles(1.5707963267948966, 0, 0)
							v_u_104 = CFrame.new(v_u_171.HumanoidRootPart.CFrame.Position) * CFrame.new(0, v_u_171.HumanoidRootPart.Size.Y / 2, 0)
						end)
					end
				end
			end
		end,
		["LassoFail"] = function(p190, p191)
			-- upvalues: (ref) v_u_13, (ref) v_u_8, (ref) v_u_6
			local v192 = p190:FindFirstChild("HumanoidRootPart")
			if v192 then
				v_u_13:PlaySound(v_u_8.Hanami.RootDisappear, v192, game.SoundService.Effect)
				local v193 = v_u_6.Utils.Hanami.ParticleDissipationHolder
				for _, v194 in p191.Parts:GetChildren() do
					for _, v195 in v193:GetChildren() do
						local v196 = v195:Clone()
						v196.Shape = Enum.ParticleEmitterShape.Box
						v196.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v194.Size.X * 2, 0), NumberSequenceKeypoint.new(1, v194.Size.X * 2, 0) })
						v196.Parent = v194
					end
					v_u_13:PlayParticles(v194)
					v194.Transparency = 1
				end
			end
		end,
		["GrappleHit"] = function(p197)
			-- upvalues: (ref) v_u_13, (ref) v_u_8
			local v198 = p197:FindFirstChild("HumanoidRootPart")
			if v198 then
				v_u_13:Flash(p197, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_8.Gojo.LapseBlue.Grab, v198, game.SoundService.Effect)
			end
		end,
		["UppercutSpike"] = function(p199, p200, p201)
			-- upvalues: (ref) v_u_7, (ref) v_u_13, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3
			local v202 = workspace:Raycast(p199.Position, Vector3.new(0, -12, 0), _G.MapParams)
			if v202 then
				local v203 = v_u_7.Hanami.UppercutRoot:Clone()
				v203.CFrame = p199 - p199.Position + v202.Position - Vector3.new(0, 7, 0)
				v203.Parent = workspace.Effects
				for v204 = 1, 5 do
					local v205 = v_u_7.Hanami.ParticleDissipationHolder:Clone()
					v205.BlackDust.Size = NumberSequence.new(4 - v204 / 2, 7 - v204 / 2)
					v205.RedDust1.Size = v205.BlackDust.Size
					v205.RedDust2.Size = v205.BlackDust.Size
					local v206 = v204 * 2.5 + -6
					v205.Position = Vector3.new(0, v206, 0)
					v205.Parent = v203
				end
				v_u_13:DustBreak(v202.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
				if p200 == nil then
					v_u_13:PlaySound(v_u_8.Hanami.Uppercut, v203, game.SoundService.Effect)
				elseif p200 == true then
					v_u_13:PlaySound(v_u_8.Hanami.AOESpikes.Spikes, v203, game.SoundService.Effect)
				elseif p200 == 2 then
					v_u_13:PlaySound(v_u_8.Hanami.DefenseResponse.Root, v203, game.SoundService.Effect)
				end
				v_u_4:Create(v203, TweenInfo.new(0.2), {
					["Position"] = v202.Position + Vector3.new(0, 6, 0)
				}):Play()
				task.wait(0.5)
				if p201 and p201:GetAttribute("Dead") then
					tick()
					repeat
						task.wait()
					until p201.Parent == nil
				end
				v_u_4:Create(v203, TweenInfo.new(0.2), {
					["Transparency"] = 1
				}):Play()
				v_u_13:PlayParticles(v203)
				v_u_13:PlaySound(v_u_8.Hanami.RootDisappear, v203, game.SoundService.Effect)
				v_u_3:AddItem(v203, 1)
			end
		end,
		["DownslamRoot"] = function(p207)
			if not workspace:Raycast(p207.Position, Vector3.new(0, -12, 0), _G.MapParams) then
			end
		end,
		["Pierced"] = function(p208)
			-- upvalues: (ref) v_u_13, (ref) v_u_8, (ref) v_u_10, (ref) v_u_9
			local v209 = p208:FindFirstChild("HumanoidRootPart")
			if v209 then
				v_u_13:PlaySound(v_u_8.Hiromi.Stab, v209, game.SoundService.Effect)
				for _ = 1, 40 do
					v_u_10:Blood(p208.Torso.CFrame, math.random(-150, -5), 25, 25)
				end
				if (workspace.CurrentCamera.CFrame.Position - v209.Position).Magnitude < 70 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.SnapOh)
				end
			end
		end,
		["EmpowerStart"] = function(p210, p_u_211, p212)
			-- upvalues: (ref) v_u_6, (ref) v_u_16, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_8
			local v213 = p210:FindFirstChild("HumanoidRootPart")
			if v213 then
				local v214
				if p212 then
					v214 = p210["Left Arm"] or v213
				else
					v214 = v213
				end
				local v_u_215 = v_u_6.Utils.Hanami.EmpowerCharge:Clone()
				v_u_215.Parent = workspace.Effects
				v_u_215.CFrame = v213.CFrame * CFrame.new(0, -3 * p210:GetScale(), 0) * CFrame.new(0, 0.1, 0)
				local v216 = workspace:Raycast(v214.Position, Vector3.new(-0, -20, -0), v_u_16)
				if v216 then
					v_u_215.Position = v216.Position + Vector3.new(0, 0.1, 0)
				end
				v_u_4:Create(v_u_215.PointLight, TweenInfo.new(0.7), {
					["Brightness"] = 5
				}):Play()
				v_u_215.Charge.Ring:Emit(1)
				v_u_3:AddItem(v_u_215, 4)
				p_u_211:GetPropertyChangedSignal("Value"):Connect(function()
					-- upvalues: (ref) v_u_4, (copy) v_u_215
					v_u_4:Create(v_u_215.PointLight, TweenInfo.new(0.4), {
						["Brightness"] = 0
					}):Play()
					v_u_215.Charge.Light:Emit(1)
				end)
				p_u_211.Destroying:Connect(function()
					-- upvalues: (copy) p_u_211, (copy) v_u_215
					if p_u_211.Value ~= true then
						v_u_215:Destroy()
					end
				end)
				v_u_13:PlaySound(v_u_8.Hanami.EmpowerStart, v213, game.SoundService.Effect)
				task.wait()
				local v217 = workspace:Raycast(v214.Position, Vector3.new(-0, -20, -0), v_u_16)
				if v217 then
					v_u_215.Position = v217.Position + Vector3.new(0, 0.1, 0)
				end
				if p_u_211.Parent ~= nil and p_u_211.Value ~= true then
					continue
				end
				v_u_13:PlaySound(v_u_8.Hanami.Empower, v213, game.SoundService.Effect)
			end
		end,
		["Chat"] = function(p218)
			-- upvalues: (ref) v_u_13, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			local v219 = p218:FindFirstChild("Torso")
			if v219 then
				v_u_13:PlaySound(v_u_8.Hanami.Awaken, v219, game.SoundService.Effect)
				local v220 = v_u_7.Hanami.Dialogue:Clone()
				v220.Parent = v219
				local v221 = v220.Chat1.Position
				v220.Chat1.Position = v221 - UDim2.new(0, 0, 0.15, 0)
				v_u_4:Create(v220.Chat1, TweenInfo.new(0.9, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v221
				}):Play()
				v_u_4:Create(v220.Chat1, TweenInfo.new(0.3), {
					["BackgroundTransparency"] = 0
				}):Play()
				v_u_4:Create(v220.Chat1.Sub, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				task.wait(1.1)
				local v222 = v220.Chat2.Position
				v220.Chat2.Position = v222 - UDim2.new(0, 0, 0.15, 0)
				v_u_4:Create(v220.Chat2, TweenInfo.new(0.9, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v222
				}):Play()
				v_u_4:Create(v220.Chat2, TweenInfo.new(0.3), {
					["BackgroundTransparency"] = 0
				}):Play()
				v_u_4:Create(v220.Chat2.Sub, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				task.wait(1.1)
				v_u_3:AddItem(v220, 0.6)
				for _, v223 in v220:GetDescendants() do
					if v223:IsA("Frame") then
						v_u_4:Create(v223, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["Position"] = nil,
							["BackgroundTransparency"] = 1,
							["Position"] = v223.Position - UDim2.new(0, 0, 0.2, 0)
						}):Play()
					else
						if not v223:IsA("TextLabel") then
							continue
						end
						v_u_4:Create(v223, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["TextTransparency"] = 1
						}):Play()
						if not v223:FindFirstChild("UIStroke") then
							continue
						end
						v_u_4:Create(v223:FindFirstChild("UIStroke"), TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["Transparency"] = 1
						}):Play()
					end
				end
			end
		end,
		["RipSound"] = function(p224)
			-- upvalues: (ref) v_u_13, (ref) v_u_8, (ref) v_u_7, (ref) v_u_1
			local v225 = p224:FindFirstChild("Torso")
			if v225 then
				v_u_13:PlaySound(v_u_8.Hanami.ArmWrapRip, v225, game.SoundService.Effect)
				for _, v226 in v_u_7.Misc.M.Awk.mokultMeh["3"]:GetChildren() do
					v226:PivotTo(p224.HumanoidRootPart.CFrame)
					v_u_1.GetController("MokouController"):ArcTween(v226.Start, true)
				end
			end
		end,
		["BeamOffCD"] = function(p227)
			-- upvalues: (ref) v_u_13, (ref) v_u_6, (ref) v_u_8, (ref) v_u_3
			local v228 = p227:FindFirstChild("HumanoidRootPart")
			if v228 then
				v_u_13:Flash(p227, Color3.new(1, 1, 0.498039), 0.5)
				local v229 = v_u_6.Utils.Hanami.EmpowerAura:Clone()
				v229.Parent = v228
				v229.HanamiAuraBurst:Emit(1)
				v_u_13:PlaySound(v_u_8.Hanami.Empower, v228, game.SoundService.Effect)
				v_u_3:AddItem(v229, 1)
			end
		end,
		["PlantGuide"] = function(p230)
			p230.Ring:Emit(1)
			p230.Shine.Enabled = true
		end
	}
	v_u_11.Effects:Connect(function(p232, ...)
		-- upvalues: (copy) v_u_231
		local v233 = v_u_231[p232]
		if v233 then
			v233(...)
		end
	end)
end
function v14.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13
	v_u_11 = v_u_1.GetService("HanamiService")
	v_u_12 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("FXController")
end
return v14