-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Megumi.Mahoraga.GroundPitchController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "GroundPitchController"
})
local v12 = RaycastParams.new()
v12.FilterType = Enum.RaycastFilterType.Include
v12.FilterDescendantsInstances = { workspace.Map, workspace.Spawns, workspace.Domains }
function v11.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_8, (ref) v_u_10, (copy) v_u_7, (copy) v_u_4, (copy) v_u_6, (copy) v_u_3, (copy) v_u_2, (ref) v_u_9
	local v_u_48 = {
		["Crunch"] = function(p13, p_u_14, p15)
			-- upvalues: (ref) v_u_8, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_6, (ref) v_u_3
			local v_u_16 = p13:FindFirstChild("HumanoidRootPart")
			if v_u_16 then
				local v17 = TweenInfo.new(0.5)
				local v18 = #p15
				local v19 = (workspace.CurrentCamera.CFrame.Position - p_u_14.Position).Magnitude
				if v19 < 40 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
				task.delay(0.3, function()
					-- upvalues: (copy) p_u_14, (copy) v_u_16, (ref) v_u_10, (ref) v_u_7
					if p_u_14.Parent and v_u_16.Parent then
						v_u_10:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Wind, v_u_16, game.SoundService.Effect)
					end
				end)
				if v19 <= 75 then
					for _, v20 in p15 do
						local v21 = Instance.new("Part")
						v21.CanCollide = false
						v21.Massless = true
						v21.Position = v20[1]
						v21.Orientation = v20[2]
						v21.Color = v20[3]
						v21.Material = v20[4]
						v21.Size = v20[5]
						v21.Transparency = v20[6]
						v21.Parent = p_u_14.Rocks
						local v22 = Instance.new("Weld")
						v22.C1 = p_u_14.CFrame:ToObjectSpace(v21.CFrame)
						v22.Part1 = v21
						v22.Part0 = p_u_14
						v22.Parent = v21
						local v23 = v_u_4
						local v24 = {}
						local v25 = CFrame.new(math.random(-v18, v18) / 20, math.random(-v18, v18) / 20, math.random(-v18, v18) / 20)
						local v26 = CFrame.Angles
						local v27 = math.random(0, 360)
						local v28 = math.rad(v27)
						local v29 = math.random(0, 360)
						local v30 = math.rad(v29)
						local v31 = math.random(0, 360)
						v24.C1 = v25 * v26(v28, v30, (math.rad(v31)))
						v23:Create(v22, v17, v24):Play()
					end
					p_u_14.Destroying:Connect(function()
						-- upvalues: (copy) p_u_14, (ref) v_u_6, (ref) v_u_3, (ref) v_u_10, (ref) v_u_7, (ref) v_u_8, (ref) v_u_4
						local v32 = p_u_14.Ring
						local v33 = v_u_6.Megumi.Mahoraga.Rock:Clone()
						v33.Transparency = 1
						v33.Anchored = true
						v33.CFrame = p_u_14.CFrame
						v33.Parent = workspace.Effects
						v32.Parent = v33
						v33.Attachment.Dust:Emit(20)
						v33.Attachment.Hit:Emit(20)
						v33.Attachment.Sparks:Emit(20)
						v_u_3:AddItem(v33, 1.5)
						v_u_10:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Break, v33, game.SoundService.Effect)
						local v34 = (workspace.CurrentCamera.CFrame.Position - p_u_14.Position).Magnitude
						if v34 < 40 then
							v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
						end
						if v34 < 100 then
							local v35 = TweenInfo.new(3, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
							for v36, v37 in p_u_14.Rocks:GetChildren() do
								if v36 > 25 then
									continue
								end
								v37.CanCollide = true
								v37.CollisionGroup = "Effects"
								v37.Parent = workspace.Effects
								v_u_3:AddItem(v37, 3)
								v_u_4:Create(v37, v35, {
									["Size"] = Vector3.new(0, 0, 0)
								}):Play()
							end
						end
					end)
				end
			else
				return
			end
		end,
		["Throw"] = function(p38)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v39 = p38:FindFirstChild("HumanoidRootPart")
			if v39 then
				v_u_10:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Throw, v39, game.SoundService.Effect)
			end
		end,
		["Interp"] = function(p_u_40)
			-- upvalues: (ref) v_u_2
			local v_u_41 = p_u_40.CFrame
			local v_u_42 = tick()
			local v_u_43 = p_u_40:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_41, (copy) p_u_40, (ref) v_u_42
				v_u_41 = p_u_40.CFrame
				v_u_42 = tick()
			end)
			local v_u_44 = nil
			v_u_44 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_40, (ref) v_u_44, (copy) v_u_43, (ref) v_u_41, (ref) v_u_42
				if p_u_40.Parent then
					workspace:BulkMoveTo({ p_u_40 }, { v_u_41 + v_u_41.LookVector * (150 * (tick() - v_u_42)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_44:Disconnect()
					v_u_43:Disconnect()
				end
			end)
		end,
		["Hit"] = function(p45)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v46 = p45:FindFirstChild("HumanoidRootPart")
			if v46 then
				v_u_10:Flash(p45, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.Itadori.M1:FindFirstChild("Hit1"), v46, game.SoundService.Effect)
				v_u_10:PlaySound(v_u_7.Itadori.Rush.RushHit, v46, game.SoundService.Effect)
			end
		end,
		["Finisher"] = function(p47)
			-- upvalues: (ref) v_u_10
			if p47.HumanoidRootPart then
				v_u_10:Bleed(p47)
			end
		end
	}
	v_u_9.Effects:Connect(function(p49, ...)
		-- upvalues: (copy) v_u_48
		local v50 = v_u_48[p49]
		if v50 then
			v50(...)
		end
	end)
end
function v11.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("GroundPitchService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11