-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Itadori.Awake.DismantleController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "DismantleController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_2, (copy) v_u_6, (copy) v_u_3, (copy) v_u_9, (copy) v_u_4, (copy) v_u_8, (ref) v_u_12, (ref) v_u_10
	local v_u_69 = {
		["Swing"] = function(p14)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			v_u_11:PlaySound(v_u_7.Misc.Swing.Fist, v15, game.SoundService.Effect)
		end,
		["Hit"] = function(p16, p17, p18)
			-- upvalues: (ref) v_u_2, (ref) v_u_6, (ref) v_u_3
			local v19 = p16:FindFirstChild("HumanoidRootPart")
			if v19 then
				local v20 = p17:FindFirstChild("HumanoidRootPart")
				if v20 then
					local v21 = Instance.new("Model", workspace.Effects)
					v_u_2:AddItem(v21, 0.05 * p18 + 0.15)
					local v22 = Instance.new("Highlight", v21)
					v22.DepthMode = Enum.HighlightDepthMode.Occluded
					v22.FillTransparency = 0
					v22.FillColor = Color3.new(0, 0, 0)
					for _ = 1, p18 do
						local v23 = CFrame.new(v19.Position, v20.Position) * CFrame.new(math.random(-40, 40) / 10, math.random(-40, 40) / 10, 0)
						local v24 = CFrame.Angles
						local v25 = math.random(0, 360)
						local v_u_26 = v23 * v24(0, 0, (math.rad(v25)))
						local v_u_27 = v_u_6.Itadori.Dismantle.DismantleFly:Clone()
						v_u_27.CFrame = v_u_26
						v_u_27.Parent = v21
						task.delay(0, function()
							-- upvalues: (ref) v_u_3, (copy) v_u_27, (copy) v_u_26
							v_u_3:Create(v_u_27, TweenInfo.new(0.1), {
								["Size"] = Vector3.new(15, 0, 0),
								["CFrame"] = nil,
								["CFrame"] = v_u_26 + v_u_26.LookVector * 30
							}):Play()
							task.wait(0.1)
							v_u_27.Transparency = 1
							task.wait(0.05)
							v_u_27:Destroy()
						end)
						task.wait(0.05)
					end
				end
			else
				return
			end
		end,
		["Hit2"] = function(p28)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_9
			local v29 = p28:FindFirstChild("HumanoidRootPart")
			if v29 then
				v_u_11:Flash(p28, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Itadori.Dismantle.Slash, v29, game.SoundService.Effect)
				v_u_9:Blood(p28.Torso.CFrame, 50, 180, 180)
			end
		end,
		["Finisher"] = function(p30)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7
			local v31 = p30:FindFirstChild("HumanoidRootPart")
			if v31 then
				local v32 = v_u_6.Itadori.Dismantle.Dismantle:Clone()
				v32.Anchored = true
				v32.CFrame = v31.CFrame
				v32.Slash1.Enabled = false
				v32.Parent = workspace.Effects
				v_u_2:AddItem(v32, 2)
				v32.SlashFinish2.Glow:Emit(1)
				v32.SlashFinish2.Wind:Emit(2)
				v_u_11:PlaySound(v_u_7.Itadori.Dismantle.FinishSlash, v32, game.SoundService.Effect)
				task.wait(0.2)
				v32.SlashFinish1:Emit(4)
				v_u_11:PlaySound(v_u_7.Itadori.Dismantle.Explode, v32, game.SoundService.Effect)
				v_u_11:Bleed(p30)
			end
		end,
		["Chant"] = function(p33, p34)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_11, (ref) v_u_7
			local v35 = p33:FindFirstChild("HumanoidRootPart")
			if v35 then
				local v_u_36 = v_u_6.Heian.Chant.Chant:Clone()
				v_u_36.Parent = p33.Head
				v_u_2:AddItem(v_u_36, 1)
				v_u_3:Create(v_u_36, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
					["StudsOffset"] = Vector3.new(2, 2, 2)
				}):Play()
				task.delay(0.5, function()
					-- upvalues: (ref) v_u_3, (copy) v_u_36
					v_u_3:Create(v_u_36.Chat, TweenInfo.new(0.5), {
						["ImageTransparency"] = 1
					}):Play()
					v_u_3:Create(v_u_36.Chat.Sub, TweenInfo.new(0.5), {
						["TextTransparency"] = 1
					}):Play()
				end)
				if p34 == 1 then
					v_u_11:Flash(p33, Color3.fromRGB(255, 255, 255), 2)
					v_u_11:PlaySound(v_u_7.Itadori.Dismantle.WorldSlash1, v35, game.SoundService.Effect)
					return
				elseif p34 == 2 then
					v_u_11:Flash(p33, Color3.fromRGB(255, 255, 255), 2)
					v_u_11:PlaySound(v_u_7.Itadori.Dismantle.WorldSlash2, v35, game.SoundService.Effect)
					v_u_36.Chat.Sub.Text = "RECOIL..."
				elseif p34 == 3 then
					v_u_11:Flash(p33, Color3.fromRGB(255, 0, 0), 1)
					v_u_11:PlaySound(v_u_7.Itadori.Dismantle.WorldSlash3, v35, game.SoundService.Effect)
					v_u_36.Chat.Sub.Text = "TWIN METEORS."
					task.wait(0.5)
					local v37 = v_u_6.Gojo.LapseBlue.LapseBlue.Grab:Clone()
					v37.Weld.Part0 = v37
					v37.Weld.Part1 = v35
					v37.Parent = workspace.Effects
					local v38 = Instance.new("Highlight", v37)
					v38.FillTransparency = 1
					v38.OutlineTransparency = 1
					v_u_3:Create(v37, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
						["Size"] = Vector3.new(100, 6, 10),
						["Transparency"] = 50
					}):Play()
					v_u_2:AddItem(v37, 0.5)
				end
			else
				return
			end
		end,
		["WorldSlash"] = function(p39, p40)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v41 = p39:FindFirstChild("HumanoidRootPart")
			if v41 then
				v_u_11:PlaySound(v_u_7.Heian.Dismantle.FireWCS, v41, game.SoundService.Effect)
				local v42 = v_u_6.Itadori.Dismantle.WorldSlash:Clone()
				v42.CFrame = p40 + p40.LookVector * 30
				v42.Parent = workspace.Effects
				v_u_3:Create(v42.Slash, TweenInfo.new(0.1), {
					["Size"] = Vector3.new(0, 0, 60)
				}):Play()
				v_u_3:Create(v42.Weld, TweenInfo.new(0.1), {
					["C1"] = CFrame.new(0, 0, 30)
				}):Play()
				v_u_2:AddItem(v42.Slash, 0.1)
				local v43 = Instance.new("Highlight", v42.Slash)
				v43.DepthMode = Enum.HighlightDepthMode.Occluded
				v43.FillTransparency = 0
				v43.FillColor = Color3.new(0, 0, 0)
				v_u_2:AddItem(v42, 0.5)
				v42.Smear:Emit(50)
				v42.Stars:Emit(30)
				local v44 = v_u_6.Itadori.Dismantle.WorldSlash.Slash:Clone()
				v44.Material = Enum.Material.Glass
				local v45 = Instance.new("Weld", v44)
				v44.Weld.Part0 = v42
				v44.Weld.Part1 = v44
				v44.Weld.C1 = CFrame.new(0, 0, 30)
				v44.Transparency = 50
				v44.Size = Vector3.new(100, 6, 10)
				v44.Parent = v42
				local v46 = Instance.new("Highlight", v44)
				v46.FillTransparency = 1
				v46.OutlineTransparency = 1
				v_u_3:Create(v44, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(0, 0, 60),
					["Transparency"] = 1
				}):Play()
				v_u_3:Create(v45, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["C1"] = CFrame.new(0, 0, 15)
				}):Play()
				if v_u_4.Character == p39 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["WorldHit"] = function(p47, p48)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (ref) v_u_6
			local v49 = p47:FindFirstChild("HumanoidRootPart")
			if v49 then
				v_u_11:Flash(p47, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Itadori.Dismantle.Slash, v49, game.SoundService.Effect)
				if p48 then
					v_u_11:PlaySound(v_u_7.Itadori.Dismantle.Explode, v49, game.SoundService.Effect)
					v_u_11:Bleed(p47)
					if v_u_4.Character == p47 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
						if _G.Settings.Flash ~= true then
							return
						end
						local v50 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
						v50.TintColor = Color3.new(1, 1, 1)
						v50.Parent = game.Lighting
						task.wait(0.04)
						v50.Brightness = 200
						v50.Contrast = -1000
						task.wait(0.04)
						v50:Destroy()
					end
				end
			end
		end,
		["DismantleFly"] = function(p51, p52, p53)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v54 = p51:FindFirstChild("HumanoidRootPart")
			if v54 then
				local v55 = v_u_11:PlaySound(v_u_7.Heian.Dismantle.Fire, v54, game.SoundService.Effect)
				v55.Volume = v55.Volume * 2
				local v56 = v_u_6.Itadori.Dismantle.DismatleProj:Clone()
				v56.CFrame = p52 + p52.LookVector * 30
				v56.Parent = workspace.Effects
				v_u_3:Create(v56.Slash, TweenInfo.new(0.1), {
					["Size"] = Vector3.new(0, 0, 60)
				}):Play()
				v_u_3:Create(v56.Weld, TweenInfo.new(0.1), {
					["C1"] = CFrame.new(0, 0, 30)
				}):Play()
				v_u_2:AddItem(v56.Slash, 0.1)
				local v57 = Instance.new("Highlight", v56.Slash)
				v57.DepthMode = Enum.HighlightDepthMode.Occluded
				v57.FillTransparency = 0
				v57.FillColor = Color3.new(0, 0, 0)
				v_u_2:AddItem(v56, 0.5)
				v56.Smear:Emit(50)
				v56.Stars:Emit(30)
				local v58 = v_u_6.Itadori.Dismantle.WorldSlash.Slash:Clone()
				v58.Material = Enum.Material.Glass
				local v59 = Instance.new("Weld", v58)
				v58.Weld.Part0 = v56
				v58.Weld.Part1 = v58
				v58.Weld.C1 = CFrame.new(0, 0, 30)
				v58.Transparency = 50
				v58.Size = Vector3.new(100, 6, 10)
				v58.Parent = v56
				local v60 = Instance.new("Highlight", v58)
				v60.FillTransparency = 1
				v60.OutlineTransparency = 1
				v_u_3:Create(v58, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(0, 0, 60),
					["Transparency"] = 1
				}):Play()
				v_u_3:Create(v59, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["C1"] = CFrame.new(0, 0, 15)
				}):Play()
				if v_u_4.Character == p51 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
					if p53 then
						if _G.Settings.Flash ~= true then
							return
						end
						local v61 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
						v61.TintColor = Color3.new(1, 1, 1)
						v61.Parent = game.Lighting
						task.wait(0.04)
						v61.Brightness = 200
						v61.Contrast = -1000
						task.wait(0.04)
						v61:Destroy()
					end
				end
			end
		end,
		["Aerial"] = function(p62, p63, p64)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_12
			local v65 = p62:FindFirstChild("HumanoidRootPart")
			if v65 then
				local v66 = p62:FindFirstChild("Humanoid")
				if v66 then
					p63.Position = v65.Position + Vector3.new(0, p64 and 0 or 12, 0)
					v_u_11:PlaySound(v_u_7.Itadori.CursedStrikes.Spin, v65, game.SoundService.Effect)
					local v67 = Instance.new("BodyGyro", v65)
					v67.P = 10000
					v67.MaxTorque = Vector3.new(40000, 40000, 40000)
					v66.PlatformStand = true
					repeat
						local v68 = v_u_12:GetMouseTarget()
						v67.CFrame = CFrame.new(v65.Position, v68)
						task.wait()
					until not p63.Parent
					v67:Destroy()
					v66.PlatformStand = false
				end
			else
				return
			end
		end
	}
	v_u_10.Effects:Connect(function(p70, ...)
		-- upvalues: (copy) v_u_69
		local v71 = v_u_69[p70]
		if v71 then
			v71(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("DismantleService")
	v_u_11 = v_u_1.GetController("FXController")
	v_u_12 = v_u_1.GetController("ToolController")
end
return v13