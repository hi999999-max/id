-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Haruta.Base.BackstabController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.BloodyZee)
local v10 = RaycastParams.new()
v10.FilterType = Enum.RaycastFilterType.Include
v10.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "BackstabController"
})
function v14.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_9, (copy) v_u_4, (copy) v_u_8, (ref) v_u_11
	local v_u_42 = {
		["Start"] = function(p15)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_12:PlaySound(v_u_7.Haruta.Backstab, v16, game.SoundService.Effect)
			end
		end,
		["Whoosh"] = function(p17, p18)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v19 = p17:FindFirstChild("HumanoidRootPart")
			if v19 then
				if p18 then
					v_u_12:PlaySound(v_u_7.Haruta.BackstabFinisher.Whoosh, v19, game.SoundService.Effect).PlaybackSpeed = math.random(90, 110) / 100
				else
					v_u_12:PlaySound(v_u_7.Haruta.Backstab, v19, game.SoundService.Effect)
				end
				local v20 = v_u_6.Choso.CounterSwing:Clone()
				v20:PivotTo(v19.CFrame * CFrame.new(-1, 0, -8) * CFrame.Angles(0, 0.17453292519943295, 0))
				v20.Parent = workspace.Effects
				v20.Shockwave:Destroy()
				v_u_2:AddItem(v20, 0.3)
				v20.Shock.Size = Vector3.new(10, 2, 10)
				v_u_3:Create(v20.Shock, TweenInfo.new(0.125), {
					["Size"] = Vector3.new(2, 15, 2),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v20.Shock2.Position + v19.CFrame.LookVector * 3
				}):Play()
				v_u_3:Create(v20.Shock2, TweenInfo.new(0.1), {
					["Size"] = Vector3.new(8, 0, 8),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v20.Shock2.Position + v19.CFrame.LookVector * 3
				}):Play()
			end
		end,
		["Stab"] = function(p21, p22, p23, p24)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_9, (ref) v_u_4, (ref) v_u_8
			if p21:FindFirstChild("HumanoidRootPart") then
				local v25 = p22:FindFirstChild("HumanoidRootPart")
				if v25 then
					v_u_12:Flash(p22, Color3.new(0.745098, 0, 0.0117647))
					if p24 then
						v_u_12:PlaySound(v_u_7.Haruta.BackstabFinisher["Stab" .. p24], v25, game.SoundService.Effect)
					else
						v_u_12:PlaySound(p23 and v_u_7.Haruta.BackstabBack or v_u_7.Haruta.BackstabFront, v25, game.SoundService.Effect)
					end
					for _ = 1, 20 do
						v_u_9:Blood(p22.Torso.CFrame, math.random(5, 80), 25, 25)
					end
					if p21 == v_u_4.Character or p22 == v_u_4.Character then
						if p23 then
							v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
							return
						end
						v_u_8.CurrentShaker:ShakeSustain(v_u_8.Presets.HeavyHit):StartFadeOut(0.4)
					end
				end
			else
				return
			end
		end,
		["Crush"] = function(p26, p27, p28)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_12, (ref) v_u_7
			if p26:FindFirstChild("HumanoidRootPart") then
				local v29 = p27:FindFirstChild("HumanoidRootPart")
				if v29 then
					local v30 = v_u_6.Hiromi.Shockwave:Clone()
					local v31 = Instance.new("Model")
					v30.Parent = v31
					v31:ScaleTo(0.65)
					v_u_2:AddItem(v31, 0.1)
					v30.Position = p28
					v30.Parent = workspace.Effects
					local v32 = v30.CFrame
					local v33 = CFrame.Angles
					local v34 = math.random(-179, 179)
					v30.CFrame = v32 * v33(0, math.rad(v34), 0)
					v_u_3:Create(v30.mesh.Mesh, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
						["Scale"] = Vector3.new(12, 0, 12)
					}):Play()
					v_u_3:Create(v30.mesh.Decal, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
						["Transparency"] = 1
					}):Play()
					v30.Floor.Glow:Emit(1)
					v30.Floor.Ring:Emit(4)
					v_u_2:AddItem(v30, 1.5)
					v_u_12:PlaySound(v_u_7.Haruta.BackstabFinisher.Slam, v29, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Kick"] = function(p35, p36)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v37 = p35:FindFirstChild("HumanoidRootPart")
			if v37 then
				local v38 = p36:FindFirstChild("HumanoidRootPart")
				if v38 then
					v_u_12:Flash(p36, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Haruta.BackstabFinisher.Kick, v38, game.SoundService.Effect)
					local v39 = CFrame.new(v37.Position, v38.Position + Vector3.new(0, 2, 0))
					local v40 = v_u_6.Gojo.HardHit:Clone()
					local v41 = Instance.new("Model")
					v40.Parent = v41
					v41:ScaleTo(0.8)
					v_u_2:AddItem(v41, 0.1)
					v40.CFrame = v39 + v39.LookVector * 3.5
					v40.Parent = workspace.Effects
					v40.Dust:Emit(5)
					v40.Ring:Emit(5)
					v40.Sparks:Emit(10)
					v_u_2:AddItem(v40, 0.5)
					if v_u_4.Character == p35 or v_u_4.Character == p36 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end
	}
	v_u_11.Effects:Connect(function(p43, ...)
		-- upvalues: (copy) v_u_42
		local v44 = v_u_42[p43]
		if v44 then
			v44(...)
		end
	end)
end
function v14.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_13, (ref) v_u_12
	v_u_11 = v_u_1.GetService("BackstabService")
	v_u_13 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v14