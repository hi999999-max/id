-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Reggie.Base.SpeedCrashController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
require(v5.Modules.BloodyZee)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "SpeedCrashController"
})
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_2, (ref) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_3, (copy) v_u_8, (copy) v_u_4, (ref) v_u_9
	local v_u_54 = {
		["Throw"] = function(p13, p14)
			-- upvalues: (ref) v_u_2
			local v15 = p13:FindFirstChild("HumanoidRootPart")
			if v15 then
				local v16 = p14:Clone()
				v16.Parent = workspace.Effects
				v16.CanCollide = true
				v16.AssemblyLinearVelocity = v15.AssemblyLinearVelocity
				v_u_2:AddItem(v16, 2)
			end
		end,
		["Start"] = function(p17)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v18 = p17:FindFirstChild("HumanoidRootPart")
			if v18 then
				v_u_11:PlaySound(v_u_7.Reggie.SpeedCrash.Start, v18, game.SoundService.Effect)
			end
		end,
		["Drive"] = function(p19, p20)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v21 = p19:FindFirstChild("HumanoidRootPart")
			if v21 then
				v_u_11:PlaySound(p20 and v_u_7.Reggie.SpeedCrash.DriveBoost or v_u_7.Reggie.SpeedCrash.Drive, v21, game.SoundService.Effect)
			end
		end,
		["Explode"] = function(p22, p23, p24, p25)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_11, (ref) v_u_7, (ref) v_u_8
			if p22:FindFirstChild("HumanoidRootPart") then
				for _ = 1, 5 do
					local v_u_26 = v_u_6.Hiromi.GavelShard:Clone()
					local v27 = p23.CFrame
					local v28 = CFrame.new
					local v29 = (math.random() - 0.5) * p23.Size.X
					local v30 = (math.random() - 0.5) * p23.Size.Y
					local v31 = (math.random() - 0.5) * p23.Size.Z
					v_u_26.Position = (v27 * v28((Vector3.new(v29, v30, v31)))).Position
					v_u_26.Size = v_u_26.Size * (p23.Size.Magnitude / 5)
					v_u_26.Color = p23.Color
					local v32 = math.random(-50, 50)
					local v33 = math.random(-50, 50)
					local v34 = math.random
					v_u_26.Velocity = Vector3.new(v32, v33, v34(-50, 50))
					local v35 = math.random(-50, 50)
					local v36 = math.random(-50, 50)
					local v37 = math.random
					v_u_26.RotVelocity = Vector3.new(v35, v36, v37(-50, 50))
					v_u_26.Parent = workspace.Effects
					v_u_2:AddItem(v_u_26, 2)
					task.delay(1, function()
						-- upvalues: (ref) v_u_3, (copy) v_u_26
						v_u_3:Create(v_u_26, TweenInfo.new(1), {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
					end)
				end
				local v38 = v_u_6.Reggie.BikeExplode:Clone()
				if p25 then
					local v39 = Instance.new("Model")
					v38.Parent = v39
					v39:ScaleTo(1.5)
					v_u_2:AddItem(v39, 0.2)
				end
				v38.Parent = workspace.Effects
				v38.Position = p24
				v_u_2:AddItem(v38, 6)
				v_u_11:PlayParticles(v38)
				v_u_11:PlaySound(v_u_7.Reggie.SpeedCrash.Explode, v38, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - p24).Magnitude < 35 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["Hit"] = function(p40, p41)
			-- upvalues: (ref) v_u_11, (ref) v_u_4, (ref) v_u_8
			if p41:FindFirstChild("HumanoidRootPart") then
				v_u_11:Flash(p41, Color3.new(1, 1, 1))
				if p40 == v_u_4.Character or p41 == v_u_4.Character then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.SnapOh)
				end
			end
		end,
		["Hit2"] = function(p42, p43)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v44 = p42:FindFirstChild("HumanoidRootPart")
			if v44 then
				local v45 = p43:FindFirstChild("HumanoidRootPart")
				if v45 then
					v_u_11:Flash(p43, Color3.new(1, 1, 1))
					v_u_11:PlaySound(v_u_7.Reggie.SpeedCrash.Hit, v45, game.SoundService.Effect)
					local v46 = v44.CFrame
					local v47 = v_u_6.Itadori.DivergentFist.BlackFlashLaunch:Clone()
					local v48 = Instance.new("Model")
					v47.Parent = v48
					v48:ScaleTo(0.75)
					v_u_2:AddItem(v48, 0.2)
					v47.CFrame = v46 * CFrame.new(0, 0, -5)
					v47.Parent = workspace.Effects
					v47.Wind:Emit(10)
					v47.PointLight:Destroy()
					v47.Wind.Lifetime = NumberRange.new(0.9, 1.5)
					v47.Back1.Back.Size = NumberSequence.new(0)
					v47.Back2.Back.Size = NumberSequence.new(0)
					v_u_2:AddItem(v47, 3)
					local v49 = v_u_6.Choso.CounterSwing.Shock:Clone()
					v49.Size = Vector3.new(3, 15, 3)
					v49.CFrame = v46 * CFrame.Angles(1.5707963267948966, 0, 0)
					v49.Parent = workspace.Effects
					v_u_2:AddItem(v49, 0.2)
					v_u_3:Create(v49, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(17.5, 0, 17.5),
						["Transparency"] = 1,
						["Position"] = nil,
						["Position"] = v49.Position + v46.LookVector * 12.5
					}):Play()
					if p42 == v_u_4.Character or p43 == v_u_4.Character then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["Slide"] = function(p50, p51)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v52 = p50:FindFirstChild("HumanoidRootPart")
			if v52 then
				v_u_11:PlaySound(v_u_7.Reggie.SpeedCrash.Slide, v52, game.SoundService.Effect)
				local v53 = p51 and 0.5 or 0.3
				v_u_11:DustTrail(p50, v53, CFrame.new(1.872, -0, -1.132) * CFrame.Angles(0, -1.5707963267948966, 0))
				v_u_11:DustTrail(p50, v53, CFrame.new(-2.734, -0, -0.24) * CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end
	}
	v_u_9.Effects:Connect(function(p55, ...)
		-- upvalues: (copy) v_u_54
		local v56 = v_u_54[p55]
		if v56 then
			v56(...)
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("SpeedCrashService")
	v_u_10 = v_u_1.GetController("HitboxController")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12