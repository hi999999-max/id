-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Megumi.Base.RabbitEscapeController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "RabbitEscapeController"
})
local v_u_13 = RaycastParams.new()
v_u_13.FilterType = Enum.RaycastFilterType.Include
v_u_13.FilterDescendantsInstances = { workspace.Map, workspace.Spawns, workspace.Domains }
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_11, (copy) v_u_8, (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (copy) v_u_13, (copy) v_u_2, (copy) v_u_5, (copy) v_u_9, (ref) v_u_10
	local v_u_61 = {
		["Start"] = function(p14)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_11:PlaySound(v_u_8.Megumi.Rabbit.Start, v15, game.SoundService.Effect)
			end
		end,
		["Rab"] = function(p16, p_u_17, p_u_18, p19)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_8, (ref) v_u_11, (ref) v_u_2
			local v_u_20 = p16:FindFirstChild("HumanoidRootPart")
			if v_u_20 then
				local v_u_21 = v_u_7.Megumi.Rabbits[p19]:Clone()
				v_u_21.Parent = workspace.Effects
				v_u_21.Size = Vector3.new(11, 2, 11)
				v_u_21.Color = Color3.new(0, 0, 0)
				v_u_4:Create(v_u_21, TweenInfo.new(0.1), {
					["Size"] = v_u_7.Megumi.Rabbits.Default.Size,
					["Color"] = Color3.new(1, 1, 1)
				}):Play()
				local v22 = v_u_7.Megumi.Shadow:Clone()
				v22.Parent = workspace.Effects
				v22.Dive.Enabled = false
				v22.Shadow.Enabled = false
				v_u_3:AddItem(v22, 1)
				local v23 = workspace:Raycast(p_u_17 + Vector3.new(0, 2, 0), Vector3.new(0, -8, 0), v_u_13)
				if v23 then
					p_u_17 = v23.Position
					v22.CFrame = CFrame.new(p_u_17, p_u_17 + v23.Normal)
					v22.Shadow:Emit(4)
					v22.Dive:Emit(1)
				else
					v22.Position = p_u_17
					v22.ShadowAir:Emit(4)
				end
				local v_u_24 = tick()
				local v25 = math.random(-40, 40) / 10
				local v26 = math.random(-40, 40) / 10
				local v_u_27 = Vector3.new(v25, 0, v26)
				local v_u_28 = 1
				local v_u_29 = math.random(5, 13) / 10
				v_u_21.CFrame = CFrame.new(p_u_17, v_u_20.Position - Vector3.new(0, 3, 0))
				v_u_8.Megumi.Rabbit.Spawn.PlaybackSpeed = math.random(80, 120) / 100
				v_u_11:PlaySound(v_u_8.Megumi.Rabbit.Spawn, v_u_21, game.SoundService.Effect)
				local v_u_30 = nil
				v_u_30 = v_u_2.Stepped:Connect(function(_, p31)
					-- upvalues: (copy) v_u_24, (copy) v_u_20, (copy) p_u_18, (ref) v_u_30, (ref) v_u_4, (copy) v_u_21, (ref) v_u_11, (ref) v_u_8, (ref) v_u_3, (copy) v_u_27, (ref) p_u_17, (ref) v_u_13, (ref) v_u_29, (ref) v_u_28
					local v32 = tick() - v_u_24
					if v_u_20.Parent and p_u_18 + 0.4 > v32 then
						local v33 = v_u_20.Position - Vector3.new(0, 3, 0) + v_u_27
						local v34 = CFrame.new(p_u_17, v33).LookVector
						local v35 = p_u_17:Lerp(v33, v32 / p_u_18)
						local v36 = workspace:Raycast(v35 + Vector3.new(0, 2, 0), Vector3.new(0, -8, 0), v_u_13)
						local v37 = CFrame.new
						local v38 = v35 + v34
						local v39 = v_u_29 / 2
						local v40 = v37(v35, v38 + Vector3.new(0, v39, 0))
						if v36 then
							v40 = v40 - v40.Position + v36.Position
						end
						v_u_29 = v_u_29 - 10 * p31
						v_u_28 = v_u_28 + v_u_29
						if v_u_28 <= 0 then
							v_u_28 = 1
							v_u_29 = math.random(5, 13) / 10
						end
						v_u_21.CFrame = v40
						if v36 then
							local v41 = v_u_21
							local v42 = v_u_28
							v41.CFrame = v41.CFrame + Vector3.new(0, v42, 0)
						end
					else
						v_u_30:Disconnect()
						v_u_4:Create(v_u_21, TweenInfo.new(0.1), {
							["Color"] = Color3.new(0, 0, 0)
						}):Play()
						v_u_11:PlaySound(v_u_8.Megumi.Rabbit.Despawn, v_u_21, game.SoundService.Effect)
						task.wait(0.1)
						v_u_21.Decal:Destroy()
						v_u_21.Transparency = 1
						if v_u_21:FindFirstChild("Skin") then
							v_u_21.Skin:Destroy()
						end
						v_u_21.Despawn:Emit(3)
						v_u_3:AddItem(v_u_21, 0.6)
					end
				end)
			end
		end,
		["Hit"] = function(p43)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7
			local v44 = p43:FindFirstChild("HumanoidRootPart")
			if v44 then
				v_u_11:Flash(p43, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit" .. math.random(1, 4)), v44, game.SoundService.Effect)
				if p43:GetAttribute("Dead") then
					local v45 = nil
					for _, v46 in p43:GetChildren() do
						if not v_u_7.Damage.Skeleton:FindFirstChild(v46.Name) or v46.Transparency ~= 0 then
							continue
						end
						v45 = v46
					end
					if not v45 then
						return
					end
					v45.Transparency = 1
					local v47 = v_u_7.Damage.Skeleton:FindFirstChild(v45.Name):Clone()
					local v48 = Instance.new("Weld", v47)
					v48.Part0 = v45
					v48.Part1 = v47
					v47.Parent = v45
					v_u_11:PlaySound(v_u_8.Megumi.Rabbit.Eat, v44, game.SoundService.Effect)
				end
			end
		end,
		["Hit2"] = function(p49, p50)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v51 = p50:FindFirstChild("HumanoidRootPart")
			if v51 then
				v_u_11:Flash(p50, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_8.Hakari.EnergySurge.Hit2, v51, game.SoundService.Effect)
				if v_u_5 == p49 or v_u_5.Character == p50 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Launch"] = function(p52, p53)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v_u_54 = p52:FindFirstChild("HumanoidRootPart")
			if v_u_54 then
				v_u_11:PlaySound(v_u_8.Megumi.Rabbit.Spawn, v_u_54, game.SoundService.Effect)
				local v55 = v_u_7.Megumi.RabbitLaunch[p53]:Clone()
				v55.CFrame = v_u_54.CFrame - Vector3.new(0, 2, 0)
				v55.Parent = workspace.Effects
				v_u_3:AddItem(v55, 3)
				v_u_4:Create(v55, TweenInfo.new(0.2), {
					["CFrame"] = v_u_54.CFrame + Vector3.new(0, 5, 0)
				}):Play()
				task.wait(0.2)
				for _, v_u_56 in v55:GetChildren() do
					local v57 = v_u_56:FindFirstChild("Weld")
					if v57 then
						v57:Destroy()
					end
					v_u_56.CollisionGroup = "Effects"
					v_u_56.CanCollide = true
					local v58 = math.random(60, 80)
					v_u_56.Velocity = Vector3.new(0, v58, 0)
					task.delay(math.random(150, 200) / 100, function()
						-- upvalues: (ref) v_u_11, (ref) v_u_8, (copy) v_u_54, (copy) v_u_56, (ref) v_u_4
						v_u_11:PlaySound(v_u_8.Megumi.Rabbit.Despawn, v_u_54, game.SoundService.Effect)
						for _, v59 in v_u_56:GetDescendants() do
							if v59:IsA("BasePart") then
								v_u_4:Create(v59, TweenInfo.new(0.5), {
									["Color"] = Color3.new(0, 0, 0)
								}):Play()
							else
								if v59.ClassName ~= "SpecialMesh" then
									continue
								end
								v_u_4:Create(v59, TweenInfo.new(0.5), {
									["VertexColor"] = Vector3.new(0, 0, 0)
								}):Play()
							end
						end
						v_u_4:Create(v_u_56, TweenInfo.new(0.5), {
							["Size"] = v_u_56.Size * Vector3.new(0, 1, 1),
							["Color"] = Color3.new(0, 0, 0)
						}):Play()
						task.wait(0.5)
						for _, v60 in v_u_56:GetDescendants() do
							if not v60:IsA("BasePart") then
								continue
							end
							v_u_4:Create(v60, TweenInfo.new(0.5), {
								["Transparency"] = 1
							}):Play()
						end
						v_u_4:Create(v_u_56, TweenInfo.new(0.5), {
							["Transparency"] = 1
						}):Play()
					end)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p62, ...)
		-- upvalues: (copy) v_u_61
		local v63 = v_u_61[p62]
		if v63 then
			v63(...)
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("RabbitEscapeService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12