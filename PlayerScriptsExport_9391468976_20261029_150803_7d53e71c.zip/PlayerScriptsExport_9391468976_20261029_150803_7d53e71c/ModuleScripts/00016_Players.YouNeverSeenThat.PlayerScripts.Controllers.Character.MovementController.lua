-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Character.MovementController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Debris")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game.Players.LocalPlayer
local v_u_7 = game.ReplicatedStorage
local v_u_8 = v_u_7.Animations
local v_u_9 = v_u_7.Utils
local v_u_10 = v_u_7.Sounds
local v_u_11 = UserSettings().GameSettings
local v_u_12 = require(v_u_7.Modules.CameraShaker)
local v13 = v_u_1.CreateController({
	["Name"] = "MovementController"
})
local v_u_14 = tick()
_G.Shift = false
v13.LockOn = nil
local v_u_15 = RaycastParams.new()
v_u_15.FilterType = Enum.RaycastFilterType.Include
v_u_15.FilterDescendantsInstances = {
	workspace.Map,
	workspace.Domains,
	workspace.Spawns,
	workspace.Terrain
}
_G.MapParams = v_u_15
local v_u_16 = RaycastParams.new()
v_u_16.FilterType = Enum.RaycastFilterType.Include
v_u_16.FilterDescendantsInstances = { workspace.Map }
local v_u_17 = v_u_8.Misc.Movement.Parkour
local v_u_18 = v_u_10.Misc.Footstep.Water
local v_u_19 = {
	[Enum.Material.Plastic] = "rbxassetid://5761648082",
	[Enum.Material.SmoothPlastic] = "rbxassetid://5761648082",
	[Enum.Material.Slate] = "rbxassetid://5639243489",
	[Enum.Material.Concrete] = "rbxassetid://5639243489",
	[Enum.Material.Brick] = "rbxassetid://5639243489",
	[Enum.Material.Cobblestone] = "rbxassetid://5639243489",
	[Enum.Material.Fabric] = "rbxassetid://619083295",
	[Enum.Material.Glass] = "rbxassetid://3437778169",
	[Enum.Material.Metal] = "rbxassetid://5639245164",
	[Enum.Material.DiamondPlate] = "rbxassetid://5639245590",
	[Enum.Material.Wood] = "rbxassetid://5632735811",
	[Enum.Material.WoodPlanks] = "rbxassetid://5632735811",
	[Enum.Material.Grass] = "rbxassetid://5639244517",
	[Enum.Material.Ground] = "rbxassetid://5639243992",
	[Enum.Material.Sand] = "rbxassetid://5639245918",
	[Enum.Material.Snow] = "rbxassetid://7437372937"
}
local v_u_20 = nil
local v_u_21 = {
	["Back"] = Vector3.new(0, 0, 1),
	["Front"] = Vector3.new(0, 0, -1),
	["Left"] = Vector3.new(-1, 0, 0),
	["Right"] = Vector3.new(1, 0, 0)
}
local v_u_22 = nil
local v_u_23 = 0
local v_u_24 = nil
local v_u_25 = nil
local v_u_26 = 0
local v_u_27 = {
	["Vault"] = {
		"125187993473697",
		"95602001882956",
		"107860751460547",
		"79201532345509"
	},
	["Dive"] = { "98195977533316", "85222050280022" },
	["Slide"] = { "98500512116998" },
	["Climb"] = { "104763108763761" },
	["BounceR"] = { "94327920127463" },
	["BounceL"] = { "113609963676386" }
}
local v_u_28 = nil
local v_u_29 = nil
for v30, v31 in v_u_19 do
	local v32 = v_u_18:Clone()
	v32.SoundId = v31
	v32.Parent = v_u_18.Parent
	v_u_19[v30] = v32
end
function v13.Dash(_, p33, p_u_34, p35) -- name: Dash
	-- upvalues: (ref) v_u_20, (copy) v_u_10, (copy) v_u_6, (copy) v_u_5, (copy) v_u_21, (copy) v_u_8, (ref) v_u_14, (ref) v_u_22, (copy) v_u_4, (copy) v_u_3
	local v_u_36 = p_u_34.HumanoidRootPart
	if v_u_36 then
		local v_u_37 = p_u_34.Humanoid
		if v_u_37 then
			v_u_20:PlaySound(v_u_10.Misc.Dash, v_u_36, game.SoundService.Effect)
			local v38 = v_u_20
			local v39 = 0.4
			local v40 = p35 == "Left" and CFrame.new() or (p35 == "Back" and CFrame.Angles(0, 1.5707963267948966, 0) or p35 == "Right" and CFrame.Angles(0, 3.141592653589793, 0))
			if not v40 then
				if p35 == "Front" then
					v40 = CFrame.Angles(0, -1.5707963267948966, 0)
				else
					v40 = false
				end
			end
			v38:DustTrail(p_u_34, v39, v40)
			if v_u_6 == p33 then
				local v41 = p_u_34.Info:FindFirstChild("DashMultiplier")
				local v42 = v41 and v41.Value or 1
				v_u_5:Create(workspace.CurrentCamera, TweenInfo.new(0.5), {
					["FieldOfView"] = 70
				}):Play()
				local v43 = v_u_21[p35] * (200 * v42)
				local v_u_44 = v_u_37:LoadAnimation((v_u_8.Misc.Movement:FindFirstChild("Dash" .. p35)))
				v_u_44.Priority = Enum.AnimationPriority.Movement
				v_u_44:Play(nil, nil, p35 == "Back" and 0.8 or 1.8)
				v_u_14 = tick()
				v_u_22:ClearForce(p_u_34.Torso)
				v_u_22:ClearForce(v_u_36)
				local v45 = p_u_34:FindFirstChild("Info")
				local v_u_46
				if v45 and v45.Parent then
					v_u_46 = Instance.new("BoolValue")
					v_u_46.Name = "InDash"
					v_u_46.Parent = v45
				else
					v_u_46 = nil
				end
				local v_u_47 = Instance.new("BodyVelocity", p_u_34.Torso)
				v_u_47.MaxForce = Vector3.new(40000, 0, 40000)
				v_u_47.P = 40000
				v_u_47.Name = "MovementForce"
				v_u_4:AddItem(v_u_47, 0.4)
				v_u_22:Swing(v_u_36, v_u_47, 0.4, v43)
				local v48 = v_u_47:FindFirstChildWhichIsA("NumberValue")
				if v48 then
					v_u_5:Create(v48, TweenInfo.new(0.4, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
						["Value"] = 16 * v42
					}):Play()
				end
				local v_u_49 = nil
				v_u_49 = v_u_3.RenderStepped:Connect(function()
					-- upvalues: (copy) v_u_47, (ref) v_u_49, (copy) v_u_37, (copy) p_u_34, (copy) v_u_36
					if not v_u_47.Parent then
						v_u_49:Disconnect()
					end
					if v_u_37.AutoRotate == false then
						return
					elseif p_u_34.Head.LocalTransparencyModifier == 0 then
						local v50 = workspace.CurrentCamera.CFrame.LookVector
						local v51 = v_u_36
						local v52 = CFrame.new
						local v53 = v_u_36.Position
						local v54 = v_u_36.Position
						local v55 = v50.X
						local v56 = v50.Z
						v51.CFrame = v52(v53, v54 + Vector3.new(v55, 0, v56))
					end
				end)
				local v_u_57 = p_u_34:GetAttributeChangedSignal("Stun"):Connect(function()
					-- upvalues: (copy) p_u_34, (copy) v_u_47, (ref) v_u_46, (copy) v_u_44, (ref) v_u_49
					if p_u_34:GetAttribute("Stun") and v_u_47.Parent then
						if v_u_46 and v_u_46.Parent then
							v_u_46:Destroy()
						end
						v_u_47.Velocity = Vector3.new(0, 0, 0)
						v_u_47:Destroy()
						v_u_44:Stop()
						v_u_49:Disconnect()
					end
				end)
				task.delay(0.4, function()
					-- upvalues: (ref) v_u_46, (ref) v_u_57, (ref) v_u_49
					if v_u_46 and v_u_46.Parent then
						v_u_46:Destroy()
					end
					v_u_57:Disconnect()
					v_u_49:Disconnect()
				end)
			end
		end
	else
		return
	end
end
local v_u_58 = {
	Vector3.new(0.5, 0.5, 0.5),
	Vector3.new(-0.5, 0.5, 0.5),
	Vector3.new(0.5, 0.5, -0.5),
	Vector3.new(-0.5, 0.5, -0.5),
	Vector3.new(0.5, -0.5, 0.5),
	Vector3.new(-0.5, -0.5, 0.5),
	Vector3.new(0.5, -0.5, -0.5),
	Vector3.new(-0.5, -0.5, -0.5)
}
local v59 = {}
local function v_u_66(p60, p61, p62) -- name: inPart
	local v63 = p60:PointToObjectSpace(p62)
	local v64 = p61 / 2
	local v65
	if v63.X >= -v64.X and (v63.X <= v64.X and (v63.Y >= -v64.Y and (v63.Y <= v64.Y and v63.Z >= -v64.Z))) then
		v65 = v63.Z <= v64.Z
	else
		v65 = false
	end
	return v65
end
for v67, _ in v_u_58 do
	v59[v67] = v_u_58[v67].Unit
end
local function v_u_70(p68) -- name: accessoryLoad
	local v69 = p68:FindFirstChild("Handle")
	if v69 then
		v69.Parent = Instance.new("Folder", p68)
	end
end
function v13.Tilt(_, p_u_71) -- name: Tilt
	-- upvalues: (copy) v_u_6, (copy) v_u_27, (copy) v_u_17, (copy) v_u_70, (copy) v_u_3, (copy) v_u_58, (copy) v_u_10, (ref) v_u_20, (copy) v_u_18, (copy) v_u_15, (copy) v_u_9, (copy) v_u_4, (copy) v_u_19, (copy) v_u_12
	local v_u_72 = p_u_71:FindFirstChild("HumanoidRootPart")
	local v_u_73 = p_u_71:FindFirstChild("Humanoid")
	if v_u_72 and v_u_73 then
		if not p_u_71:GetAttribute("NoProcess") then
			if v_u_6.Character == p_u_71 then
				v_u_73:SetStateEnabled(Enum.HumanoidStateType.FallingDown, false)
				v_u_73:SetStateEnabled(Enum.HumanoidStateType.Dead, false)
				for _, v74 in v_u_27 do
					for _, v75 in v74 do
						v_u_17.AnimationId = "rbxassetid://" .. v75
						v_u_73:LoadAnimation(v_u_17)
					end
				end
				if p_u_71:GetAttribute("Ragdoll") > 0 and not p_u_71:GetAttribute("NoRagdoll") then
					v_u_73:ChangeState(Enum.HumanoidStateType.Physics)
				end
				p_u_71:GetAttributeChangedSignal("Ragdoll"):Connect(function()
					-- upvalues: (copy) p_u_71, (copy) v_u_73
					if p_u_71:GetAttribute("NoRagdoll") then
						return
					elseif p_u_71:GetAttribute("Ragdoll") > 0 then
						v_u_73:ChangeState(Enum.HumanoidStateType.Physics)
					else
						v_u_73:ChangeState(Enum.HumanoidStateType.GettingUp)
					end
				end)
			end
			for _, v76 in p_u_71:GetChildren() do
				if not v76:IsA("Accessory") then
					continue
				end
				local v77 = v76:FindFirstChild("Handle")
				if not v77 then
					continue
				end
				v77.Parent = Instance.new("Folder", v76)
			end
			p_u_71.ChildAdded:Connect(function(p78)
				-- upvalues: (ref) v_u_70
				if p78:IsA("Accessory") then
					task.defer(v_u_70, p78)
				end
			end)
			local v_u_79 = 0
			local v_u_80 = {
				["Left Arm"] = false,
				["Right Arm"] = false,
				["Left Leg"] = false,
				["Right Leg"] = false,
				["Head"] = false
			}
			local v_u_81 = nil
			v_u_81 = v_u_3.Stepped:Connect(function()
				-- upvalues: (copy) v_u_72, (ref) v_u_81, (copy) p_u_71, (copy) v_u_80, (ref) v_u_58, (ref) v_u_79, (ref) v_u_10, (ref) v_u_20
				if v_u_72 and v_u_72.parent then
					if p_u_71:GetAttribute("Ragdoll") <= 0 or (workspace.CurrentCamera.CFrame.Position - v_u_72.Position).Magnitude > 300 then
						for v82, _ in v_u_80 do
							v_u_80[v82] = false
						end
						return
					elseif _G.Settings.RagSFX then
						for v83, _ in v_u_80 do
							local v84 = p_u_71:FindFirstChild(v83)
							if not v84 then
								continue
							end
							local v85 = v84.CFrame.LookVector
							local v86 = v84.CFrame.RightVector
							local v87 = v84.CFrame.UpVector
							local v88 = false
							for v89 = 1, 8 do
								local v90 = v85 * v_u_58[v89].Z + v86 * v_u_58[v89].X + v87 * v_u_58[v89].Y
								local v91 = v_u_72.Position + v90 * v84.Size
								if not workspace:Raycast(v91, v90.Unit * 0.2, _G.MapParams) then
									continue
								end
								v88 = true
							end
							if v88 and v_u_80[v83] == false then
								v_u_80[v83] = true
								if tick() - v_u_79 <= 0.075 then
									break
								end
								v_u_79 = tick()
								v_u_20:PlaySound(v_u_10.Impact.Players.Ragdoll_Collision["Hit" .. math.random(1, 8)], v84, game.SoundService.Effect)
							else
								if v88 or v_u_80[v83] ~= true then
									break
								end
								v_u_80[v83] = false
							end
						end
					end
				else
					v_u_81:Disconnect()
					return
				end
			end)
			local v_u_92 = v_u_72:WaitForChild("RootJoint")
			local v_u_93 = v_u_92.C1
			local v_u_94 = nil
			v_u_94 = v_u_3.Stepped:Connect(function(_, p95)
				-- upvalues: (copy) v_u_72, (copy) v_u_92, (ref) v_u_94, (copy) p_u_71, (copy) v_u_93, (copy) v_u_80, (ref) v_u_58, (ref) v_u_79, (ref) v_u_20, (ref) v_u_18, (ref) v_u_10
				if v_u_72 and v_u_92 then
					if p_u_71:GetAttribute("NoTilt") then
						v_u_92.C1 = v_u_93
					else
						local v96 = v_u_72.CFrame:VectorToObjectSpace(v_u_72.Velocity)
						local v97 = v_u_92
						local v98 = v_u_92.C1
						local v99 = v_u_93
						local v100 = CFrame.Angles
						local v101 = v96.Z
						local v102 = math.clamp(v101, -6, 6)
						local v103 = math.rad(v102)
						local v104 = v96.X
						local v105 = math.clamp(v104, -6, 6)
						local v106 = math.rad(v105)
						local v107 = v96.X
						local v108 = math.clamp(v107, -6, 6)
						local v109 = v99 * v100(v103, v106, (math.rad(v108)))
						local v110 = CFrame.Angles
						local v111 = v_u_72.RotVelocity.Y
						local v112 = math.clamp(v111, -6, 6)
						v97.C1 = v98:lerp(v109 * v110(0, 0, (math.rad(v112))), 6 * p95)
					end
					if p_u_71:GetAttribute("Ragdoll") <= 0 or (workspace.CurrentCamera.CFrame.Position - v_u_72.Position).Magnitude > 300 then
						for v113, _ in v_u_80 do
							v_u_80[v113] = false
						end
					elseif _G.Settings.RagSFX then
						for v114, _ in v_u_80 do
							local v115 = p_u_71:FindFirstChild(v114)
							if not v115 then
								continue
							end
							local v116 = v115.CFrame.LookVector
							local v117 = v115.CFrame.RightVector
							local v118 = v115.CFrame.UpVector
							local v119 = nil
							for v120 = 1, 8 do
								local v121 = v116 * v_u_58[v120].Z + v117 * v_u_58[v120].X + v118 * v_u_58[v120].Y
								local v122 = v_u_72.Position + v121 * v115.Size
								local v123 = workspace:Raycast(v122, v121.Unit * 0.2, _G.MapParams)
								if not v123 then
									continue
								end
								v119 = v123
							end
							if v119 and v_u_80[v114] == false then
								v_u_80[v114] = true
								if tick() - v_u_79 <= 0.075 then
									break
								end
								v_u_79 = tick()
								if v119.Material == Enum.Material.Water then
									v_u_20:PlaySound(v_u_18, v115, game.SoundService.Effect)
								else
									v_u_20:PlaySound(v_u_10.Impact.Players.Ragdoll_Collision["Hit" .. math.random(1, 8)], v115, game.SoundService.Effect)
								end
							else
								if v119 or v_u_80[v114] ~= true then
									break
								end
								v_u_80[v114] = false
							end
						end
					end
				else
					v_u_94:Disconnect()
					return
				end
			end)
			local v_u_124 = {
				{ false, tick() },
				{ false, tick() }
			}
			local v_u_125 = { p_u_71:FindFirstChild("Left Leg"), p_u_71:FindFirstChild("Right Leg") }
			local v_u_126 = nil
			v_u_126 = v_u_3.Stepped:Connect(function()
				-- upvalues: (copy) p_u_71, (copy) v_u_125, (ref) v_u_126, (copy) v_u_72, (ref) v_u_15, (copy) v_u_124, (ref) v_u_20, (ref) v_u_10, (ref) v_u_9, (ref) v_u_4, (ref) v_u_19, (ref) v_u_12
				if p_u_71.Parent and (v_u_125[1] and v_u_125[2]) then
					local v127 = p_u_71:GetScale()
					local v128 = v_u_72.Velocity.Magnitude
					for v129, v130 in v_u_125 do
						local v131 = v130.Position + v130.CFrame.UpVector * (1 * v127)
						local v132 = workspace:Raycast(v131, v130.CFrame.UpVector * -(2 * v127 + 0.3), v_u_15)
						if v132 and v_u_124[v129][1] == false then
							v_u_124[v129][1] = true
							if tick() - v_u_124[v129][2] < 0.1 then
								continue
							end
							v_u_124[v129][2] = tick()
							local v133 = v132.Material
							if v133 == Enum.Material.Water then
								if v128 > 50 then
									v_u_20:PlaySound(v_u_10.Misc.Footstep.WaterHard, v_u_72, game.SoundService.Effect)
									local v134 = v_u_9.WaterHard:Clone()
									if p_u_71:GetScale() > 1.2 then
										v134:ScaleTo(p_u_71:GetScale())
									end
									v134.Water.CFrame = CFrame.new(v132.Position + v132.Normal * 0.1, v132.Position + v132.Normal) * CFrame.Angles(-1.5707963267948966, 0, 0)
									v134.Water.Ring:Emit(4)
									v134.Water.Splash:Emit(40)
									v134.Water.Sparks1:Emit(6)
									v134.Water.Shockwave:Emit(5)
									v134.Water.Smoke:Emit(6)
									v134.Parent = workspace.Effects
									v_u_4:AddItem(v134, 4)
								else
									v_u_20:PlaySound(v_u_10.Misc.Footstep.Water, v_u_72, game.SoundService.Effect)
									local v135 = v_u_9.Water:Clone()
									v135.CFrame = CFrame.new(v132.Position + v132.Normal * 0.1, v132.Position + v132.Normal) * CFrame.Angles(-1.5707963267948966, 0, 0)
									v135.Ring:Emit(3)
									v135.Splash:Emit(7)
									v135.Parent = workspace.Effects
									v_u_4:AddItem(v135, 4)
								end
							else
								if not v_u_19[v133] then
									v133 = Enum.Material.Plastic
								end
								if v133 == Enum.Material.Air then
									return
								end
								if p_u_71:GetAttribute("Makora") or p_u_71:GetAttribute("UltMecha") then
									v_u_19[v133].Volume = 3
									v_u_19[v133].PlaybackSpeed = v129 == 1 and 0.8 or 0.9
									if (workspace.CurrentCamera.CFrame.Position - v_u_72.Position).Magnitude < 30 then
										v_u_12.CurrentShaker:Shake(v_u_12.Presets.LightHit)
									end
								else
									v_u_19[v133].Volume = 0.5
									v_u_19[v133].PlaybackSpeed = v129 == 1 and 0.9 or 1
								end
								v_u_20:PlaySound(v_u_19[v133], v_u_72, game.SoundService.Effect)
							end
						else
							if v132 or v_u_124[v129][1] ~= true then
								continue
							end
							v_u_124[v129][1] = false
						end
					end
				else
					v_u_126:Disconnect()
				end
			end)
		end
	else
		return
	end
end
local v_u_136 = 2
function v13.DashRequest(p137) -- name: DashRequest
	-- upvalues: (copy) v_u_6, (ref) v_u_28, (ref) v_u_29, (ref) v_u_14, (ref) v_u_25, (ref) v_u_136
	local v138 = v_u_6.Character
	if v138 then
		local v139 = v138.HumanoidRootPart
		local v140 = v138.Humanoid
		if v139 and v140 then
			local v141 = workspace.CurrentCamera.CFrame.LookVector
			local v142 = CFrame.new
			local v143 = v139.Position
			local v144 = v139.Position
			local v145 = v141.X
			local v146 = v141.Z
			local v147 = v142(v143, v144 + Vector3.new(v145, 0, v146))
			local v148 = v140.MoveDirection:Dot(v147.LookVector)
			local v149 = math.round(v148)
			local v150 = v140.MoveDirection:Dot(v147.RightVector)
			local v151 = math.round(v150)
			local v152 = v149 == 1 and "Front" or (v149 == -1 and "Back" or (v151 == 1 and "Right" or (v151 == -1 and "Left" or "Front")))
			if v138.Info:FindFirstChild("Knockback") or v138:GetAttribute("Burst") and not v138.Info:GetAttribute("Burst") or v138.Info:FindFirstChild("ForceEsc") and v138.Info.ForceEsc.Value then
				v_u_28.Dash:Fire(v152, true)
				return
			else
				local v153 = v138:FindFirstChild("CustomChar")
				if v153 then
					v153 = v138.CustomChar:GetAttribute("CustomChase")
				end
				if not v153 or v152 ~= "Front" then
					if v138.Info:FindFirstChild("Block") then
						return
					end
					if v138.Info:FindFirstChild("Stun") then
						return
					end
					if v138:GetAttribute("Ragdoll") > 0 then
						return
					end
					local v154 = v138.Info:FindFirstChild("InSkill")
					if v154 and (v154.Value == false and not v138.Info:FindFirstChild("AllowDashInSkill")) then
						return
					end
				end
				if v138.Info:FindFirstChild("NoDash") then
					return
				else
					local v155 = false
					if v138.Info:FindFirstChild("DisableChase") then
						local v156 = v_u_29:GetTarget(200)
						if v156 and (v156:GetAttribute("Ragdoll") <= 0 and not v156:GetAttribute("Stun")) then
							local v157 = (CFrame.lookAt(v139.Position, v156.HumanoidRootPart.Position).LookVector * Vector3.new(1, 0, 1)).Unit
							local v158 = (v156.HumanoidRootPart.CFrame.LookVector * Vector3.new(1, 0, 1)).Unit
							local v159 = (v156.HumanoidRootPart.Velocity * Vector3.new(1, 0, 1)).Unit
							v155 = v157:Dot(v158) > -0.2 and v157:Dot(v159) > 0.2 and true or v155
						end
					end
					local v160 = v138:GetAttribute("Moveset") == "Toji" and v152 == "Back" and v138.Info:FindFirstChild("Stance")
					if v160 then
						v160 = v138.Info.Stance.Value == "COATM"
					end
					if (v152 == "Front" or v160) and (v138:GetAttribute("Moveset") ~= "Naoya" and not (v138.Info:FindFirstChild("DomainClash") or v155)) then
						if tick() - v_u_14 < 0.4 and not v153 then
							return
						else
							local v161 = v138.Info:FindFirstChild("Item")
							if v161 and v161:FindFirstChild("Dash") then
								v_u_25.Dash:Fire()
								return
							elseif v153 then
								v_u_29:GetToolService("CustomService").Chase:Fire(v_u_29.ExtraData.Custom())
							else
								v_u_29:UseSetService("Chase", v140.FloorMaterial == Enum.Material.Air, v152)
							end
						end
					else
						local v162 = v138.Info:FindFirstChild("NoSprint")
						if v162 and (v162.Value == false and not v162:GetAttribute("AllowDash")) then
							return
						elseif v138:GetAttribute("Moveset") == "Naoya" or (v138.Info:FindFirstChild("DomainClash") or v155) then
							if tick() - v_u_14 < ((v155 or v138.Info:FindFirstChild("DomainClash")) and 0.3 or 0.45) then
								return
							else
								if tick() - v_u_14 > (v138.Info:FindFirstChild("DomainClash") and 0.8 or 2) then
									v_u_136 = 2
								end
								if v_u_136 > 0 then
									if not v155 then
										v_u_136 = v_u_136 - 1
									end
									v_u_28.Dash:Fire(v152)
									p137:Dash(v_u_6, v138, v152)
								end
							end
						elseif tick() - v_u_14 >= 2 then
							v_u_28.Dash:Fire(v152)
							p137:Dash(v_u_6, v138, v152)
						end
					end
				end
			end
		else
			return
		end
	else
		return
	end
end
function v13.Parkour(_, p_u_163, p164, p_u_165) -- name: Parkour
	-- upvalues: (copy) v_u_16, (ref) v_u_26, (ref) v_u_22, (copy) v_u_10, (ref) v_u_20, (ref) v_u_28, (copy) v_u_27, (copy) v_u_17
	if p_u_163.Info:GetAttribute("Parkour") then
		return
	elseif p_u_163.Info:FindFirstChild("NoParkour") then
		return
	else
		local v166 = p164.Position
		local v167 = p_u_165:GetState()
		if v167 ~= Enum.HumanoidStateType.Climbing then
			local v168 = p164.CFrame
			local v169 = CFrame.lookAlong(v168.Position, v168.LookVector * Vector3.new(1, 0, 1))
			local v170 = p_u_163:GetScale()
			local v171 = v169.LookVector * v170
			local v172 = v169.UpVector * v170 * 1
			local v173 = v169.RightVector * v170
			if v167 == Enum.HumanoidStateType.Running then
				if workspace:Raycast(v166, v172 * -3, v_u_16) then
					v_u_26 = 0
				end
				local v174 = workspace:Raycast(v166, v171 * 3.5, v_u_16)
				if v174 then
					local v175 = workspace:Raycast(v166 + v172 * 1.5, v171 * 3.5, v_u_16)
					local v176 = workspace:Raycast(v166 - v172 * 2.5, v171 * 3.5, v_u_16)
					if v175 or not v176 then
						if workspace:Raycast(v166 + v172 * 1.5, v171 * 6, v_u_16) and not workspace:Raycast(v166 - v172 * 2.5, v171 * 6, v_u_16) then
							local v177 = v166 - v172 * 2.5 + v171 * 6
							if not workspace:Raycast(v177, v172 * 5, v_u_16) then
								v_u_22:ClearForce(p_u_163.Torso)
								p_u_163:SetAttribute("Movement", true)
								p_u_165.HipHeight = -2
								task.delay(0.35, function()
									-- upvalues: (copy) p_u_163, (copy) p_u_165
									p_u_163:SetAttribute("Movement", nil)
									p_u_165.HipHeight = 0
								end)
								v_u_10.Misc.Parkour.Parkour.Pitch = math.random(90, 110) / 100
								v_u_20:PlaySound(v_u_10.Misc.Parkour.Parkour, p164, game.SoundService.Effect)
								v_u_28.Parkour:Fire()
								v_u_17.AnimationId = "rbxassetid://" .. v_u_27.Slide[math.random(1, #v_u_27.Slide)]
								local v178 = p_u_165:LoadAnimation(v_u_17)
								v178.Priority = Enum.AnimationPriority.Movement
								v178:Play(0.06)
								v_u_22:MovementForce(p_u_163, v171 * 35 - v172 * 80, v171 * 28, 0.3)
								return
							end
						end
					else
						if workspace:Raycast(v166 + v172 * 4, v171 * 3.5, v_u_16) then
							v_u_22:ClearForce(p_u_163.Torso)
							p_u_163:SetAttribute("Movement", true)
							p_u_165.HipHeight = -2
							task.delay(0.4, function()
								-- upvalues: (copy) p_u_163, (copy) p_u_165
								p_u_163:SetAttribute("Movement", nil)
								p_u_165.HipHeight = 0
							end)
							v_u_10.Misc.Parkour.Parkour.Pitch = math.random(90, 110) / 100
							v_u_20:PlaySound(v_u_10.Misc.Parkour.Parkour, p164, game.SoundService.Effect)
							v_u_28.Parkour:Fire()
							v_u_17.AnimationId = "rbxassetid://" .. v_u_27.Dive[math.random(1, #v_u_27.Dive)]
							local v179 = p_u_165:LoadAnimation(v_u_17)
							v179.Priority = Enum.AnimationPriority.Movement
							v179:Play(0.1)
							v_u_22:MovementForce(p_u_163, v171 * 35 + Vector3.new(0, 30, 0), v171 * 28, 0.3)
							return
						end
						if v176.Distance - v174.Distance > -2 * v170 then
							v_u_22:ClearForce(p_u_163.Torso)
							p_u_163:SetAttribute("Movement", true)
							task.delay(0.3, function()
								-- upvalues: (copy) p_u_163
								p_u_163:SetAttribute("Movement", nil)
							end)
							v_u_10.Misc.Parkour.Parkour.Pitch = math.random(90, 110) / 100
							v_u_20:PlaySound(v_u_10.Misc.Parkour.Parkour, p164, game.SoundService.Effect)
							v_u_28.Parkour:Fire()
							v_u_17.AnimationId = "rbxassetid://" .. v_u_27.Vault[math.random(1, #v_u_27.Vault)]
							local v180 = p_u_165:LoadAnimation(v_u_17)
							v180.Priority = Enum.AnimationPriority.Movement
							v180:Play(0.1)
							v_u_22:MovementForce(p_u_163, v171 * 24 + v172 * 40, v171 * 24, 0.3)
							return
						end
					end
				end
			elseif v167 == Enum.HumanoidStateType.Freefall then
				local v181 = workspace:Raycast(v166, v172 * 4, v_u_16)
				if not v181 then
					local v182 = v166 + v172 * 4 + v171 * 3
					local v183 = workspace:Raycast(v166 + v172 * 4, v171 * 3, v_u_16)
					if v183 then
						v182 = v183.Position
					end
					local v184 = workspace:Raycast(v182 - v171 * 0.2, v172 * -2, v_u_16)
					if v184 then
						local v185 = true
						local v186 = workspace
						local v187 = v166.X
						local v188 = v184.Position.Y - 0.02
						local v189 = v166.Z
						local v190 = v186:Raycast(Vector3.new(v187, v188, v189), v171 * 3, v_u_16)
						if v190 then
							local v191 = (v183 and v183.Distance or 3) - v190.Distance
							if v191 < 0 then
								v191 = -v191
							end
							if v191 < 0.4 then
								v185 = false
							end
						end
						if v185 == true then
							v_u_22:ClearForce(p_u_163.Torso)
							p_u_163:SetAttribute("Movement", true)
							task.delay(0.3, function()
								-- upvalues: (copy) p_u_163
								p_u_163:SetAttribute("Movement", nil)
							end)
							v_u_10.Misc.Parkour.Parkour.Pitch = math.random(90, 110) / 100
							v_u_20:PlaySound(v_u_10.Misc.Parkour.Parkour, p164, game.SoundService.Effect)
							v_u_28.Parkour:Fire()
							v_u_17.AnimationId = "rbxassetid://" .. v_u_27.Climb[math.random(1, #v_u_27.Climb)]
							local v192 = p_u_165:LoadAnimation(v_u_17)
							v192.Priority = Enum.AnimationPriority.Movement
							v192:Play(0.1)
							v_u_22:MovementForce(p_u_163, v172 * 40, v172 * 10 + v171 * 12, 0.3)
						end
					end
				end
				local v193 = p_u_165.MoveDirection:Dot(p164.CFrame.RightVector)
				local v194 = math.round(v193)
				local v195 = p_u_163.Info:FindFirstChild("DomainClash") and 1 or (p_u_163:GetAttribute("Moveset") == "Goku" and 4 or 3)
				if p_u_165.Health < p_u_165.MaxHealth * 0.33 then
					v195 = v195 - 2
				elseif p_u_165.Health < p_u_165.MaxHealth * 0.66 then
					v195 = v195 - 1
				end
				if v194 ~= 0 and (v_u_26 < v195 and (not p_u_163:GetAttribute("Movement") and (p_u_165.Jump == true and (not v181 and workspace:Raycast(v166, v173 * (v194 * 3), v_u_16))))) then
					v_u_22:ClearForce(p_u_163.Torso)
					p_u_163:SetAttribute("Movement", true)
					v_u_26 = v_u_26 + 1
					task.delay(0.4, function()
						-- upvalues: (copy) p_u_163
						p_u_163:SetAttribute("Movement", nil)
					end)
					v_u_10.Misc.Parkour.Parkour.Pitch = math.random(90, 110) / 100
					v_u_20:PlaySound(v_u_10.Misc.Parkour.Parkour, p164, game.SoundService.Effect)
					v_u_28.Parkour:Fire()
					local v196 = v194 == 1 and v_u_27.BounceR or v_u_27.BounceL
					if v170 > 1 and v170 < 1.5 then
						v171 = v169.LookVector
						v172 = v169.UpVector
						v173 = v169.RightVector
					end
					v_u_17.AnimationId = "rbxassetid://" .. v196[math.random(1, #v196)]
					local v197 = p_u_165:LoadAnimation(v_u_17)
					v197.Priority = Enum.AnimationPriority.Movement
					v197:Play(0.1)
					v_u_22:MovementForce(p_u_163, p164.Velocity + v173 * (v194 * 50), v172 * 20 - v173 * (v194 * 40) + v171 * 30, 0.4)
				end
			end
		end
	end
end
local _ = {
	["Itadori"] = { Color3.fromRGB(85, 255, 255), Color3.fromRGB(255, 0, 0) },
	["Hakari"] = { Color3.fromRGB(85, 255, 127) },
	["Megumi"] = { Color3.fromRGB(31, 31, 31) },
	["Mahoraga"] = { Color3.fromRGB(255, 255, 127) },
	["Mahito"] = { Color3.fromRGB(170, 85, 255) },
	["Choso"] = { Color3.fromRGB(170, 0, 0) },
	["Locust"] = { Color3.fromRGB(0, 170, 127) },
	["Yuki"] = { Color3.fromRGB(255, 170, 255) },
	["Mechamaru"] = { Color3.fromRGB(225, 10, 75) }
}
function v13.KnitStart(p_u_198) -- name: KnitStart
	-- upvalues: (ref) v_u_28, (copy) v_u_10, (ref) v_u_20, (copy) v_u_9, (copy) v_u_4, (copy) v_u_5, (ref) v_u_14, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (ref) v_u_23, (copy) v_u_3, (ref) v_u_24, (copy) v_u_11, (ref) v_u_29, (copy) v_u_66
	for _, v199 in workspace.Characters:GetChildren() do
		p_u_198:Tilt(v199)
	end
	workspace.Characters.ChildAdded:Connect(function(p_u_200)
		-- upvalues: (copy) p_u_198
		task.defer(function()
			-- upvalues: (ref) p_u_198, (copy) p_u_200
			p_u_198:Tilt(p_u_200)
		end)
	end)
	v_u_28.Effects:Connect(function(p201, p202, p203, p204)
		-- upvalues: (copy) p_u_198, (ref) v_u_10, (ref) v_u_20, (ref) v_u_9, (ref) v_u_4, (ref) v_u_5
		if p202 == "Dash" then
			p_u_198:Dash(p201, p203, p204)
			return
		elseif p202 == "Parkour" then
			local v205 = p203.HumanoidRootPart
			if v205 then
				if p204 then
					v_u_10.Misc.Parkour.Roll.Pitch = math.random(90, 110) / 100
					v_u_20:PlaySound(v_u_10.Misc.Parkour.Roll, v205, game.SoundService.Effect)
				else
					v_u_10.Misc.Parkour.Parkour.Pitch = math.random(90, 110) / 100
					v_u_20:PlaySound(v_u_10.Misc.Parkour.Parkour, v205, game.SoundService.Effect)
				end
			else
				return
			end
		elseif p202 == "Escape" then
			local v206 = p203.HumanoidRootPart
			if v206 then
				if p201 == 1 then
					local v207 = v_u_9.DashCancel:Clone()
					v207.Position = v206.Position
					v207.Parent = workspace.Effects
					v207.Ring:Emit(7)
					v207.Wind:Emit(4)
					v_u_4:AddItem(v207, 0.5)
				else
					v_u_20:PlaySound(v_u_10.Misc.Burst2, v206, game.SoundService.Effect)
					v_u_20:Flash(p203, Color3.new(1, 1, 1), 1)
					local v208 = v_u_9.DashCancel:Clone()
					v208.Position = v206.Position
					v208.Parent = workspace.Effects
					v208.Burst:Emit(8)
					v208.Sparks:Emit(20)
					v208.Ring:Emit(7)
					v208.Wind:Emit(4)
					v_u_4:AddItem(v208, 1)
					local v_u_209 = v_u_9.Damage.Rage:Clone()
					v_u_209.Color = ColorSequence.new(Color3.new(1, 1, 1))
					v_u_209.Parent = p203.Torso
					v_u_4:AddItem(v_u_209, 8)
					v_u_209.Rate = 80
					v_u_5:Create(v_u_209, TweenInfo.new(1), {
						["Rate"] = 0
					}):Play()
					task.delay(1, function()
						-- upvalues: (copy) v_u_209
						v_u_209.Enabled = false
					end)
				end
			else
				return
			end
		elseif p202 == "Grab" then
			local v210 = p203.HumanoidRootPart
			if v210 then
				v_u_20:PlaySound(v_u_10.Misc["Throwable" .. p201], v210, game.SoundService.Effect)
			end
		else
			if p202 == "Hit" then
				local v211 = p203.HumanoidRootPart
				if not v211 then
					return
				end
				local v212 = v_u_9.Gojo.Twofold.Sparks:Clone()
				v212.Parent = v211.RootAttachment
				v212:Emit(20)
				v_u_4:AddItem(v212, 0.4)
				v_u_20:Flash(p203, Color3.new(1, 1, 1))
				v_u_20:PlaySound(v_u_10.Itadori.DivergentFist.DivergentHit, v211, game.SoundService.Effect)
			end
			return
		end
	end)
	v_u_28.Throwable:Connect(function(p213, p214, p215)
		-- upvalues: (ref) v_u_5
		local v216 = p213.PrimaryPart:FindFirstChildWhichIsA("Weld")
		if v216 then
			local v217 = p214:FindFirstChild("Head")
			if v217 then
				local v218 = v216.C1
				v216.C1 = p215:ToObjectSpace(v217.CFrame)
				v_u_5:Create(v216, TweenInfo.new(0.26666666666666666, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {
					["C1"] = v218
				}):Play()
			end
		else
			return
		end
	end)
	v_u_28.ResetDash:Connect(function()
		-- upvalues: (ref) v_u_14
		v_u_14 = tick() - 2
	end)
	v_u_7.Keybind.Combat.Dash.Pressed:Connect(function()
		-- upvalues: (ref) v_u_6, (copy) p_u_198
		if v_u_6.Character then
			if not v_u_6.Character:IsDescendantOf(workspace.Effects) then
				p_u_198:DashRequest()
			end
		else
			return
		end
	end)
	v_u_2.InputBegan:Connect(function(p219, p220)
		-- upvalues: (ref) v_u_6, (ref) v_u_23
		if p220 then
			return
		else
			local v221 = v_u_6.Character
			if v221 then
				if not v221:IsDescendantOf(workspace.Effects) then
					if p219.KeyCode == Enum.KeyCode.W then
						if v221.Info:FindFirstChild("NoSprint") then
							return
						end
						if tick() - v_u_23 >= 0.2 then
							v_u_23 = tick()
							return
						end
						v221:SetAttribute("Sprint", true)
					end
				end
			else
				return
			end
		end
	end)
	v_u_2.InputEnded:Connect(function(p222, _)
		-- upvalues: (ref) v_u_6
		local v223 = v_u_6.Character
		if v223 then
			if not v223:IsDescendantOf(workspace.Effects) then
				if p222.KeyCode == Enum.KeyCode.W then
					v223:SetAttribute("Sprint", nil)
				end
			end
		else
			return
		end
	end)
	local v_u_224 = nil
	local v_u_225 = nil
	local v_u_226 = nil
	local v_u_227 = nil
	local v_u_228 = {
		["Stun"] = 0,
		["InSkill"] = 0,
		["NoJump"] = 0,
		["Block"] = 0,
		["Emote"] = 0,
		["NoLock"] = 0
	}
	local v_u_229 = nil
	local v_u_230 = nil
	local v_u_231 = require(v_u_6.PlayerScripts.PlayerModule)
	local v_u_232 = 0
	local v_u_233 = nil
	local v_u_234 = nil
	local v_u_235 = nil
	v_u_3.Stepped:Connect(function(_, p236)
		-- upvalues: (ref) v_u_224, (ref) v_u_225, (ref) v_u_226, (ref) v_u_227, (ref) v_u_6, (copy) v_u_228, (ref) v_u_229, (ref) v_u_230, (copy) p_u_198, (ref) v_u_232, (ref) v_u_24, (ref) v_u_233, (ref) v_u_9, (ref) v_u_5, (ref) v_u_20, (ref) v_u_10, (ref) v_u_234, (copy) v_u_231, (ref) v_u_235
		if v_u_224 and (v_u_224.Parent and (v_u_225 and (v_u_226 and v_u_227))) then
			local v237 = 1 - v_u_226.Health / v_u_226.MaxHealth
			local v238 = math.clamp(v237, 0, 1) * 3
			local v239 = v238 ~= v238 and 0 or v238
			local v240 = (workspace.CurrentCamera.CFrame.LookVector * Vector3.new(1, 0, 1)).Unit:Dot(v_u_226.MoveDirection)
			local v241 = game.StarterPlayer.CharacterWalkSpeed - v239
			local v242 = game.StarterPlayer.CharacterJumpPower
			local v243 = v_u_228.NoJump > 0 and 0 or v242
			local v244 = v_u_227:FindFirstChild("NoSprint")
			if v244 then
				v_u_224:SetAttribute("Sprint", nil)
				if v244:GetAttribute("S") then
					v241 = v244:GetAttribute("S")
				end
			elseif v240 > 0.5 and _G.Settings.AutoRun then
				v_u_224:SetAttribute("Sprint", true)
			elseif v240 < 0.5 then
				v_u_224:SetAttribute("Sprint", nil)
			end
			if v_u_228.Stun > 0 then
				v241 = 0.1
				v243 = 0
			elseif v_u_228.Block > 0 then
				v241 = v240 < 0 and 4 or 6
				v243 = 0
			elseif v_u_224:GetAttribute("Sprint") then
				v241 = game.StarterPlayer.CharacterWalkSpeed * 1.375 - v239
				if not v_u_224:GetAttribute("Movement") then
					p_u_198:Parkour(v_u_224, v_u_225, v_u_226)
				end
			end
			local v245 = v_u_227:FindFirstChild("Emote")
			if v245 then
				for _, v246 in game:GetService("CollectionService"):GetTagged("Emote") do
					v246.Enabled = false
				end
				if v245:GetAttribute("Team") then
					v_u_232 = v_u_232 + p236
					if v_u_232 >= 300 then
						v_u_232 = 0
						v_u_24.Give:Fire("Committed to the peace")
					end
				end
			else
				for _, v247 in game:GetService("CollectionService"):GetTagged("Emote") do
					v247.Enabled = true
				end
				v_u_232 = 0
			end
			if v_u_226:GetAttribute("Speed") then
				v241 = v241 * v_u_226:GetAttribute("Speed")
			end
			if v_u_226:GetAttribute("Speed2") then
				v241 = v241 * v_u_226:GetAttribute("Speed2")
			end
			if v_u_226:GetAttribute("Jump") then
				v243 = v243 * v_u_226:GetAttribute("Jump")
			end
			if v_u_6:GetAttribute("Spectate") == true then
				v241 = 0
				v243 = 0
			end
			local v248 = v_u_224:GetAttribute("Movement") and 0 or v243
			v_u_226.WalkSpeed = v241
			v_u_226.JumpPower = v248
			v_u_225.Anchored = false
			local v249 = v_u_6.PlayerGui.Main.Controls.Ultimate.Evade.Fill
			v249.Size = UDim2.new(v_u_224:GetAttribute("Evade") / 50, 0, 1, 0)
			if v_u_224:GetAttribute("Dead") then
				v249.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
				v249.Gradient.Enabled = true
				if v_u_233 then
					v_u_233:Destroy()
					v_u_233 = nil
				end
				if v_u_234 then
					v_u_234:Destroy()
					v_u_234 = nil
				end
			else
				local v250 = v_u_224:GetAttribute("Burst")
				if v250 then
					v250 = not v_u_224.Info:GetAttribute("Burst")
				end
				local v251 = ((v_u_224:GetAttribute("Evade") ~= 50 or not v_u_224.Info:FindFirstChild("Knockback")) and true or false) and v_u_224.Info:FindFirstChild("ForceEsc")
				if v251 then
					v251 = v_u_224.Info.ForceEsc.Value
				end
				if v251 then
					for _, v252 in v_u_224.Info:GetChildren() do
						if not v252:GetAttribute("Disable") then
							continue
						end
						v251 = false
					end
				end
				if v250 then
					v249.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
					v249.Gradient.Enabled = false
					if not (v_u_233 and v_u_233.Parent) then
						v_u_233 = v_u_9.Damage.BurstIcon.BurstIcon:Clone()
						v_u_233.Parent = v_u_225
						v_u_233.Glow:Emit(1)
						v_u_5:Create(v_u_233.Icon.Glow, TweenInfo.new(0.1), {
							["ImageTransparency"] = 0
						}):Play()
						v_u_20:PlaySound(v_u_10.Misc.Evade, v_u_225, game.SoundService.Effect)
					end
					if not (v_u_234 and v_u_234.Parent) then
						v_u_234 = Instance.new("Highlight", v_u_224)
						v_u_234.FillColor = Color3.fromRGB(255, 255, 255)
						v_u_234.FillTransparency = 0.95
					end
				else
					v249.BackgroundColor3 = v251 and Color3.fromRGB(0, 174, 255) or Color3.fromRGB(0, 85, 127)
					v249.Gradient.Enabled = true
					if v_u_233 then
						v_u_233:Destroy()
						v_u_233 = nil
					end
					if v_u_234 then
						v_u_234:Destroy()
						v_u_234 = nil
					end
				end
			end
			local v253 = v_u_225:FindFirstChild("RagdollControl")
			if v_u_224:GetAttribute("Ragdoll") > 0 then
				local v254 = v_u_225.Velocity.X
				local v255 = v_u_225.Velocity.Z
				local v256 = Vector3.new(v254, 0, v255).Unit:Dot(v_u_226.MoveDirection)
				local v257 = v256 <= 0 and 1 or -(v256 - 1)
				local v258 = v_u_225.Velocity.Magnitude * 1.3 * v257
				local v259 = v_u_225
				v259.Velocity = v259.Velocity + v_u_226.MoveDirection * v258 * p236
				local v260 = v_u_231:GetControls():GetMoveVector()
				if v260.X == 0 and v260.Z == 0 then
					if v253 then
						v253:Destroy()
					end
				elseif v_u_224:GetAttribute("Dead") or not v_u_224.Info:FindFirstChild("Knockback") then
					if not v253 then
						v253 = Instance.new("AngularVelocity")
						v253.Name = "RagdollControl"
						v253.MaxTorque = 10000
						v253.Attachment0 = v_u_225.RootAttachment
						v253.Parent = v_u_225
					end
					v253.AngularVelocity = workspace.CurrentCamera.CFrame.RightVector * (v260.Z * 5) + workspace.CurrentCamera.CFrame.LookVector * (v260.X * 5)
				else
					if v260.X ~= 0 then
						local v261 = v_u_225
						v261.RotVelocity = v261.RotVelocity + workspace.CurrentCamera.CFrame.LookVector * (v260.X * 60 * p236)
					end
					if v260.Z ~= 0 then
						local v262 = v_u_225
						v262.RotVelocity = v262.RotVelocity + workspace.CurrentCamera.CFrame.RightVector * (v260.Z * 60 * p236)
					end
					if v253 then
						v253:Destroy()
					end
				end
			elseif v253 then
				v253:Destroy()
			end
			if v_u_226:GetState() == Enum.HumanoidStateType.Swimming and (v_u_228.InSkill > 0 or v_u_228.Block > 0) then
				if not v_u_235 then
					v_u_235 = Instance.new("AlignOrientation")
					v_u_235.Mode = Enum.OrientationAlignmentMode.OneAttachment
					v_u_235.RigidityEnabled = true
					v_u_235.Attachment0 = v_u_225.RootAttachment
					v_u_235.Parent = v_u_225
				end
				v_u_235.CFrame = workspace.CurrentCamera.CFrame
			elseif v_u_235 then
				v_u_235:Destroy()
				v_u_235 = nil
			end
		else
			v_u_224 = v_u_6.Character
			if v_u_224 then
				v_u_225 = v_u_224:FindFirstChild("HumanoidRootPart")
				v_u_226 = v_u_224:FindFirstChild("Humanoid")
				v_u_227 = v_u_224:FindFirstChild("Info")
				if v_u_225 and (v_u_226 and v_u_227) then
					for v263, _ in v_u_228 do
						v_u_228[v263] = 0
					end
					for _, v264 in v_u_227:GetChildren() do
						if not v_u_228[v264.Name] then
							continue
						end
						local v265 = v_u_228
						local v266 = v264.Name
						local v267 = v_u_228[v264.Name] + 1
						v265[v266] = math.clamp(v267, 0, (1 / 0))
					end
					if v_u_229 then
						v_u_229:Disconnect()
						v_u_229 = nil
					end
					v_u_229 = v_u_227.ChildAdded:Connect(function(p268)
						-- upvalues: (ref) v_u_228
						if v_u_228[p268.Name] then
							local v269 = v_u_228
							local v270 = p268.Name
							local v271 = v_u_228[p268.Name] + 1
							v269[v270] = math.clamp(v271, 0, (1 / 0))
						end
					end)
					if v_u_230 then
						v_u_230:Disconnect()
						v_u_230 = nil
					end
					v_u_230 = v_u_227.ChildRemoved:Connect(function(p272)
						-- upvalues: (ref) v_u_228
						if v_u_228[p272.Name] then
							local v273 = v_u_228
							local v274 = p272.Name
							local v275 = v_u_228[p272.Name] - 1
							v273[v274] = math.clamp(v275, 0, (1 / 0))
						end
					end)
				end
			else
				return
			end
		end
	end)
	local v_u_276 = nil
	v_u_3:BindToRenderStep("Cam", Enum.RenderPriority.Camera.Value + 1, function(p277)
		-- upvalues: (ref) v_u_224, (ref) v_u_225, (ref) v_u_226, (ref) v_u_227, (ref) v_u_11, (ref) v_u_2, (ref) v_u_29, (ref) v_u_6, (copy) p_u_198, (copy) v_u_228, (ref) v_u_66, (ref) v_u_276, (ref) v_u_20, (ref) v_u_10
		if v_u_224 and (v_u_224.Parent and (v_u_225 and (v_u_226 and v_u_227))) then
			if v_u_224:FindFirstChild("Head") then
				local v278 = workspace.CurrentCamera
				local v279 = (v_u_224.Head.Position - workspace.CurrentCamera.CFrame.Position).Magnitude
				local v280
				if _G.Shift == true and v279 > 2 then
					v_u_11.RotationType = Enum.RotationType.CameraRelative
					v_u_2.MouseBehavior = Enum.MouseBehavior.LockCenter
					v280 = v_u_29.LastInput == "Mobile" and Vector3.new(2, 0.75, 0) or Vector3.new(1.75, 0, 0)
				else
					v280 = Vector3.new(0, 0, 0)
				end
				local v281 = v_u_224:GetScale()
				local v282 = v280 * v281
				local v283 = v_u_6.PlayerGui.Controls.LockTarget
				if p_u_198.LockOn == nil then
					v283.Adornee = nil
					v283.Enabled = false
					v_u_6:SetAttribute("LockOn", nil)
				else
					local v284 = p_u_198.LockOn:FindFirstChild("HumanoidRootPart")
					if v_u_226.Health <= 0 or not v284 then
						p_u_198.LockOn = nil
						_G.Shift = false
						v283.Adornee = nil
						v283.Enabled = false
						v_u_6:SetAttribute("LockOn", nil)
					elseif p_u_198.LockOn:FindFirstChild("CantLockOn") then
						_G.Shift = false
						v283.Enabled = false
					elseif v278.CameraType ~= Enum.CameraType.Scriptable then
						_G.Shift = true
						v_u_6:SetAttribute("LockOn", true)
						if v_u_228.NoLock <= 0 then
							local v285 = v284.Position + v_u_225.CFrame.RightVector * 1.75 * v281
							local v286 = CFrame.lookAt(v278.CFrame.Position, v285)
							local v287 = 54 * p277
							local v288 = math.clamp(v287, 0, 1)
							local v289 = v278.CFrame:Lerp(v286, v288)
							v278.CFrame = v289 - v289.Position + v278.CFrame.Position
							v283.Adornee = v284
							v283.Enabled = true
						end
					end
				end
				if v278.CameraSubject == v_u_226 then
					local v290 = _G.Settings.Follow == true and ((v_u_225.CFrame + v_u_225.CFrame.UpVector * 1.5):PointToObjectSpace(v_u_224.Head.Position) or Vector3.new(0, 0, 0)) or Vector3.new(0, 0, 0)
					if v_u_224:GetAttribute("Dead") then
						v278.CameraSubject = v_u_224.Head
					else
						v_u_226.CameraOffset = v282 + (v_u_226.CameraOffset - v282):Lerp(v290, v_u_224:GetAttribute("Ragdoll") > 0 and 1 or 0.5)
					end
				else
					v_u_226.CameraOffset = v_u_226.CameraOffset:Lerp(Vector3.new(0, 0, 0), 0.5)
				end
				local v291 = false
				local v292 = game.CollectionService:GetTagged("Water")
				if #v292 > 0 then
					for _, v293 in v292 do
						if not (v293:IsA("Part") and v_u_66(v293.CFrame, v293.Size, v278.CFrame.Position)) then
							continue
						end
						v291 = true
					end
				end
				if v291 and not v_u_276 then
					game.SoundService.AmbientReverb = Enum.ReverbType.UnderWater
					v_u_276 = v_u_20:PlaySound(v_u_10.Misc.Underwater, workspace, game.SoundService.Effect, true)
				elseif not v291 and v_u_276 then
					game.SoundService.AmbientReverb = Enum.ReverbType.NoReverb
					v_u_276:Destroy()
					v_u_276 = nil
				end
				if v_u_224:GetAttribute("AntiVoid") == true and (v_u_225.Position.Y < workspace.FallenPartsDestroyHeight + 50 and not workspace:Raycast(v_u_225.Position, Vector3.new(0, -400, 0), _G.MapParams)) then
					v_u_225.Velocity = Vector3.new(0, -5, 0)
				end
			end
		else
			return
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_28, (copy) v_u_1, (ref) v_u_25, (ref) v_u_24, (ref) v_u_29, (ref) v_u_22, (ref) v_u_20
	v_u_28 = v_u_1.GetService("MovementService")
	v_u_25 = v_u_1.GetService("ItemService")
	v_u_24 = v_u_1.GetService("AchievementService")
	v_u_29 = v_u_1.GetController("ToolController")
	v_u_22 = v_u_1.GetController("HandicapController")
	v_u_20 = v_u_1.GetController("FXController")
end
return v13