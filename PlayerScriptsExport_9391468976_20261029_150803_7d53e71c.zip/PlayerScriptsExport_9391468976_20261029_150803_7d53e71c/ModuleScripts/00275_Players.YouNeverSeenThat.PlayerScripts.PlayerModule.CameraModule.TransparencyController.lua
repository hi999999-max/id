-- Original instance: Players.YouNeverSeenThat.PlayerScripts.PlayerModule.CameraModule.TransparencyController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = game:GetService("VRService")
local v_u_2 = {
	"BasePart",
	"Decal",
	"Beam",
	"ParticleEmitter",
	"Trail",
	"Fire",
	"Smoke",
	"Sparkles",
	"Explosion"
}
local v_u_3 = require(script.Parent:WaitForChild("CameraUtils"))
local v_u_4 = {}
v_u_4.__index = v_u_4
function v_u_4.new() -- name: new
	-- upvalues: (copy) v_u_4
	local v5 = v_u_4
	local v6 = setmetatable({}, v5)
	v6.transparencyDirty = false
	v6.enabled = false
	v6.lastTransparency = nil
	v6.descendantAddedConn = nil
	v6.descendantRemovingConn = nil
	v6.toolDescendantAddedConns = {}
	v6.toolDescendantRemovingConns = {}
	v6.cachedParts = {}
	return v6
end
function v_u_4.HasToolAncestor(p7, p8) -- name: HasToolAncestor
	if p8.Parent == nil then
		return false
	end
	local v9 = p8.Parent
	assert(v9, "")
	return p8.Parent:IsA("Tool") or p7:HasToolAncestor(p8.Parent)
end
function v_u_4.IsValidPartToModify(p10, p11) -- name: IsValidPartToModify
	-- upvalues: (copy) v_u_2
	for _, v12 in v_u_2 do
		if not p11:IsA(v12) then
			continue
		end
		return not p10:HasToolAncestor(p11)
	end
	return false
end
function v_u_4.CachePartsRecursive(p13, p14) -- name: CachePartsRecursive
	if p14 then
		if p13:IsValidPartToModify(p14) then
			p13.cachedParts[p14] = true
			p13.transparencyDirty = true
		end
		for _, v15 in pairs(p14:GetChildren()) do
			p13:CachePartsRecursive(v15)
		end
	end
end
function v_u_4.TeardownTransparency(p16) -- name: TeardownTransparency
	for v17, _ in pairs(p16.cachedParts) do
		v17.LocalTransparencyModifier = 0
	end
	p16.cachedParts = {}
	p16.transparencyDirty = true
	p16.lastTransparency = nil
	if p16.descendantAddedConn then
		p16.descendantAddedConn:disconnect()
		p16.descendantAddedConn = nil
	end
	if p16.descendantRemovingConn then
		p16.descendantRemovingConn:disconnect()
		p16.descendantRemovingConn = nil
	end
	for v18, v19 in pairs(p16.toolDescendantAddedConns) do
		v19:Disconnect()
		p16.toolDescendantAddedConns[v18] = nil
	end
	for v20, v21 in pairs(p16.toolDescendantRemovingConns) do
		v21:Disconnect()
		p16.toolDescendantRemovingConns[v20] = nil
	end
end
function v_u_4.SetupTransparency(p_u_22, p_u_23) -- name: SetupTransparency
	p_u_22:TeardownTransparency()
	if p_u_22.descendantAddedConn then
		p_u_22.descendantAddedConn:disconnect()
	end
	p_u_22.descendantAddedConn = p_u_23.DescendantAdded:Connect(function(p24)
		-- upvalues: (copy) p_u_22, (copy) p_u_23
		if p_u_22:IsValidPartToModify(p24) then
			p_u_22.cachedParts[p24] = true
			p_u_22.transparencyDirty = true
		elseif p24:IsA("Tool") then
			if p_u_22.toolDescendantAddedConns[p24] then
				p_u_22.toolDescendantAddedConns[p24]:Disconnect()
			end
			p_u_22.toolDescendantAddedConns[p24] = p24.DescendantAdded:Connect(function(p25)
				-- upvalues: (ref) p_u_22
				p_u_22.cachedParts[p25] = nil
				if p25:IsA("BasePart") or p25:IsA("Decal") then
					p25.LocalTransparencyModifier = 0
				end
			end)
			if p_u_22.toolDescendantRemovingConns[p24] then
				p_u_22.toolDescendantRemovingConns[p24]:disconnect()
			end
			p_u_22.toolDescendantRemovingConns[p24] = p24.DescendantRemoving:Connect(function(p26)
				-- upvalues: (ref) p_u_23, (ref) p_u_22
				wait()
				if p_u_23 and (p26 and (p26:IsDescendantOf(p_u_23) and p_u_22:IsValidPartToModify(p26))) then
					p_u_22.cachedParts[p26] = true
					p_u_22.transparencyDirty = true
				end
			end)
		end
	end)
	if p_u_22.descendantRemovingConn then
		p_u_22.descendantRemovingConn:disconnect()
	end
	p_u_22.descendantRemovingConn = p_u_23.DescendantRemoving:connect(function(p27)
		-- upvalues: (copy) p_u_22
		if p_u_22.cachedParts[p27] then
			p_u_22.cachedParts[p27] = nil
			p27.LocalTransparencyModifier = 0
		end
	end)
	p_u_22:CachePartsRecursive(p_u_23)
end
function v_u_4.Enable(p28, p29) -- name: Enable
	if p28.enabled ~= p29 then
		p28.enabled = p29
	end
end
function v_u_4.SetSubject(p30, p31) -- name: SetSubject
	local v32
	if p31 and p31:IsA("Humanoid") then
		v32 = p31.Parent
	else
		v32 = nil
	end
	if p31 and (p31:IsA("VehicleSeat") and p31.Occupant) then
		v32 = p31.Occupant.Parent
	end
	if v32 then
		p30:SetupTransparency(v32)
	else
		p30:TeardownTransparency()
	end
end
function v_u_4.Update(p33, p34) -- name: Update
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v35 = workspace.CurrentCamera
	if v35 and p33.enabled then
		local v36 = (v35.Focus.p - v35.CoordinateFrame.p).magnitude
		local v37 = v36 < 2 and 1 - (v36 - 0.5) / 1.5 or 0
		local v38 = v37 < 0.5 and 0 or v37
		if p33.lastTransparency and (v38 < 1 and p33.lastTransparency < 0.95) then
			local v39 = v38 - p33.lastTransparency
			local v40 = 2.8 * p34
			local v41 = -v40
			local v42 = math.clamp(v39, v41, v40)
			v38 = p33.lastTransparency + v42
		else
			p33.transparencyDirty = true
		end
		local v43 = v_u_3.Round(v38, 2)
		local v44 = math.clamp(v43, 0, 1)
		if p33.transparencyDirty or p33.lastTransparency ~= v44 then
			for v45, _ in pairs(p33.cachedParts) do
				if v_u_1.VREnabled and v_u_1.AvatarGestures then
					local v46 = {
						[Enum.AccessoryType.Hat] = true,
						[Enum.AccessoryType.Hair] = true,
						[Enum.AccessoryType.Face] = true,
						[Enum.AccessoryType.Eyebrow] = true,
						[Enum.AccessoryType.Eyelash] = true
					}
					if v45.Parent:IsA("Accessory") and v46[v45.Parent.AccessoryType] or v45.Name == "Head" then
						v45.LocalTransparencyModifier = v44
					else
						v45.LocalTransparencyModifier = 0
					end
				else
					v45.LocalTransparencyModifier = v44
				end
			end
			p33.transparencyDirty = false
			p33.lastTransparency = v44
		end
	end
end
return v_u_4