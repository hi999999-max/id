-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Toji.COATM.LassoController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = Random.new()
local v_u_6 = game.Players.LocalPlayer
local v7 = game.ReplicatedStorage
local _ = v7.Animations
local v_u_8 = v7.Utils
local v_u_9 = v7.Sounds
local v_u_10 = require(v7.Modules.CameraShaker)
require(v7.Modules.StaticLightning)
require(v7.Modules.LightningBeams)
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "LassoController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_9, (copy) v_u_8, (copy) v_u_3, (copy) v_u_4, (copy) v_u_2, (copy) v_u_5, (copy) v_u_6, (copy) v_u_10, (ref) v_u_11
	local v_u_76 = {
		["Start"] = function(p14, p15)
			-- upvalues: (ref) v_u_12, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3
			local v16 = p14:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_12:PlaySound(v_u_9.Toji.COATM.Lasso.Start, v16, game.SoundService.Effect)
				task.wait(0.2)
				local v17 = p14.SetAssets:FindFirstChild("COATM")
				for v18 = 5, 6 do
					local v19 = v17:FindFirstChild("Beam" .. v18)
					if not v19 then
						continue
					end
					local v_u_20 = v_u_8.Toji.COATMCombatTrail:Clone()
					v_u_20.Parent = v17
					v_u_20.Attachment0 = v19.Attachment0
					v_u_20.Attachment1 = v19.Attachment1
					v_u_20.Enabled = true
					task.delay(0.575, function()
						-- upvalues: (copy) v_u_20, (ref) v_u_3
						v_u_20.Enabled = false
						v_u_3:AddItem(v_u_20, 0.2)
					end)
					p15.Destroying:Connect(function()
						-- upvalues: (copy) v_u_20, (ref) v_u_3
						v_u_20.Enabled = false
						v_u_3:AddItem(v_u_20, 0.2)
					end)
				end
			end
		end,
		["ChainGrab"] = function(p21, p_u_22, p23)
			-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_2, (ref) v_u_5
			local v24 = p21 and p21:FindFirstChild("SetAssets") or nil
			if v24 then
				local v25 = v24:FindFirstChild("COATM")
				if v25 then
					local v26 = Instance.new("Attachment", workspace.Terrain)
					local v27 = Instance.new("Attachment", workspace.Terrain)
					v25["Beam" .. 2].Enabled = false
					v25["Beam" .. 3].Enabled = false
					v25["Beam" .. 4].Enabled = false
					v25["Beam" .. 5].Enabled = false
					v25["Beam" .. 6].Enabled = false
					local v28 = v25.Beam2:Clone()
					v28.Parent = workspace.Effects
					v28.Attachment0 = v26
					v28.Attachment1 = v27
					v28.Enabled = true
					local v29 = tick()
					local v_u_30 = p_u_22:GetScale() * 0.3
					task.spawn(function()
						local v31 = Instance.new("Part")
						v31.CanCollide = false
						v31.Massless = false
						v31.Size = Vector3.new(1, 1, 1)
						v31.Transparency = 1
					end)
					local v_u_32 = {}
					local v_u_33 = 0
					local v_u_34 = 30
					local v_u_35 = Instance.new("Part")
					v_u_35.CanCollide = false
					v_u_35.Massless = false
					v_u_35.Size = Vector3.new(1, 1, 1)
					v_u_35.Transparency = 1
					v_u_35.Parent = workspace.Effects
					local v_u_36 = Instance.new("Weld")
					v_u_36.Part0 = p_u_22.Torso
					v_u_36.Part1 = v_u_35
					v_u_36.C0 = CFrame.new(0, 0.5, 0)
					v_u_36.Parent = v_u_35
					v_u_4:Create(v_u_36, TweenInfo.new(0.15, Enum.EasingStyle.Linear), {
						["C0"] = CFrame.new(0, -1, 0)
					}):Play()
					local v_u_37 = v_u_8.Toji.ChainTip:Clone()
					local v_u_38 = Instance.new("Weld")
					v_u_38.Part0 = v_u_35
					v_u_38.Part1 = v_u_37.ChainTip
					v_u_38.Parent = v_u_37
					v_u_37:ScaleTo(v_u_30)
					v_u_37.Parent = workspace.Effects
					local v_u_44 = v_u_2.PreSimulation:Connect(function(p39)
						-- upvalues: (copy) v_u_36, (copy) v_u_38
						local v40 = v_u_36
						local v41 = v40.C1
						local v42 = CFrame.Angles
						local v43 = -5000 * p39
						v40.C1 = v41 * v42(0, math.rad(v43), 0)
						v_u_38.C0 = CFrame.new(0, 0, -1.7463007959288808 * p39)
					end)
					task.delay(0.075, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_37, (ref) v_u_44, (copy) v_u_35
						v_u_4:Create(v_u_37.ChainTip.Attachment1, TweenInfo.new(0.075, Enum.EasingStyle.Linear), {
							["CFrame"] = CFrame.new(0, 0, 0)
						}):Play()
						task.wait(0.075)
						v_u_44:Disconnect()
						v_u_35:Destroy()
						v_u_37:Destroy()
					end)
					task.spawn(function()
						-- upvalues: (copy) p_u_22, (ref) v_u_33, (ref) v_u_34, (ref) v_u_8, (ref) v_u_5, (copy) v_u_30, (ref) v_u_4, (copy) v_u_32, (copy) v_u_37
						for _ = 1, 3 do
							if not (p_u_22 and (p_u_22.Parent and p_u_22:FindFirstChild("Torso"))) then
								break
							end
							v_u_33 = v_u_33 + 0.35
							v_u_34 = v_u_34 / 1.5
							local v45 = v_u_8.Toji.ChainCircles:Clone()
							local v46 = CFrame.new(0, 0.5 - v_u_33, 0)
							local v47 = CFrame.Angles
							local v48 = v_u_5:NextNumber(-25, 25)
							local v49 = v46 * v47(math.rad(v48), 0, 0)
							local v50 = CFrame.Angles
							local v51 = v_u_5:NextNumber(-5, 5)
							local v52 = v49 * v50(0, 0, (math.rad(v51)))
							v45:PivotTo(p_u_22.Torso.CFrame * v52)
							local v53 = Instance.new("WeldConstraint")
							v53.Part0 = p_u_22.Torso
							v53.Part1 = v45.PrimaryPart
							v53.Parent = v45
							local v54 = v_u_5:NextNumber(0, 1)
							for _, v55 in v45.PrimaryPart:GetChildren() do
								if not v55:IsA("Beam") then
									continue
								end
								v55:SetTextureOffset(v54)
								v55.TextureSpeed = v_u_34
								v55.Width0 = 1 * v_u_30
								v55.Width1 = 1 * v_u_30
								v_u_4:Create(v55, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
									["Width0"] = 2 * v_u_30,
									["Width1"] = 2 * v_u_30
								}):Play()
								v_u_4:Create(v55, TweenInfo.new(0.16666666666666666, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
									["TextureSpeed"] = 0
								}):Play()
								if v55.Name == "Beam0" then
									v55.CurveSize0 = -4
									v55.CurveSize1 = 4
								else
									v55.CurveSize0 = 4
									v55.CurveSize1 = -4
								end
							end
							v45:ScaleTo(v_u_30)
							local v56 = v_u_32
							table.insert(v56, v45)
							v45.Parent = workspace.Effects
							task.wait(0.049999999999999996)
						end
						v_u_37:Destroy()
					end)
					local v57 = v_u_44
					task.wait()
					local v58
					if p_u_22 and p_u_22.Parent then
						v58 = p_u_22:FindFirstChild("Torso") or nil
					else
						v58 = nil
					end
					if v58 and v58.Parent then
						v26.WorldCFrame = CFrame.lookAt(v58.Position, v25["1"].Position) * CFrame.Angles(0, 0, 1.5707963267948966)
						v27.WorldCFrame = CFrame.lookAt(v25["1"].Position, v58.Position)
						if p23 and (p23.Parent and tick() - v29 <= 3) then
							continue
						end
					end
					v25["Beam" .. 2].Enabled = true
					v25["Beam" .. 3].Enabled = true
					v25["Beam" .. 4].Enabled = true
					v25["Beam" .. 5].Enabled = true
					v25["Beam" .. 6].Enabled = true
					v27:Destroy()
					v26:Destroy()
					v28:Destroy()
					v57:Disconnect()
					v_u_35:Destroy()
					v_u_37:Destroy()
					for _, v59 in v_u_32 do
						v59:Destroy()
					end
				end
			else
				return
			end
		end,
		["Hit"] = function(p60, p61)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_12, (ref) v_u_9, (ref) v_u_6, (ref) v_u_10
			if p60:FindFirstChild("HumanoidRootPart") then
				local v62 = p61:FindFirstChild("HumanoidRootPart") or p61.PrimaryPart
				if v62 then
					local v63 = v_u_8.Toji.ChainHit:Clone()
					v63.Position = v62.Position
					v63.Parent = workspace.Effects
					v_u_3:AddItem(v63, 0.5)
					for _, v64 in v63:GetChildren() do
						v64:Emit(v64:GetAttribute("EmitCount"))
					end
					v_u_12:PlaySound(v_u_9.Toji.COATM.Lasso.Hit, v62, game.SoundService.Effect)
					if p61:IsDescendantOf(workspace.Characters) then
						v_u_12:Flash(p61, Color3.new(1, 1, 1))
					end
					if v_u_6.Character == p60 or v_u_6.Character == p61 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["Pull"] = function(p65)
			-- upvalues: (ref) v_u_12, (ref) v_u_9
			local v66 = p65:FindFirstChild("HumanoidRootPart")
			if v66 then
				v_u_12:PlaySound(v_u_9.Toji.COATM.Lasso.Pull, v66, game.SoundService.Effect)
			end
		end,
		["KickWhoosh"] = function(p67)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_4
			local v68 = p67:FindFirstChild("HumanoidRootPart")
			if v68 then
				local v69 = v68.CFrame
				local v70 = v_u_8.Itadori.DivergentFist.BlackFlashLaunch:Clone()
				local v71 = Instance.new("Model")
				v70.Parent = v71
				v71:ScaleTo(0.7)
				v_u_3:AddItem(v71, 0.2)
				v70.CFrame = v69 * CFrame.new(0, 0, -5)
				v70.Parent = workspace.Effects
				v70.Wind:Emit(10)
				v70.PointLight:Destroy()
				v70.Wind.Lifetime = NumberRange.new(0.9, 1.5)
				v70.Back1.Back.Size = NumberSequence.new(0)
				v70.Back2.Back.Size = NumberSequence.new(0)
				v_u_3:AddItem(v70, 3)
				local v72 = v_u_8.Choso.CounterSwing.Shock:Clone()
				v72.Size = Vector3.new(3, 15, 3)
				v72.CFrame = v69 * CFrame.Angles(1.5707963267948966, 0, 0)
				v72.Parent = workspace.Effects
				v_u_3:AddItem(v72, 0.2)
				v_u_4:Create(v72, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(17.5, 0, 17.5),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v72.Position + v69.LookVector * 10
				}):Play()
			end
		end,
		["Hit2"] = function(p73, p74)
			-- upvalues: (ref) v_u_12, (ref) v_u_9
			if p73:FindFirstChild("HumanoidRootPart") then
				local v75 = p74:FindFirstChild("HumanoidRootPart") or p74.PrimaryPart
				if v75 then
					if p74:IsDescendantOf(workspace.Characters) then
						v_u_12:Flash(p74, Color3.new(1, 1, 1))
					end
					v_u_12:PlaySound(v_u_9.Nanami.SeveranceKick.HitBack, v75, game.SoundService.Effect)
				end
			else
				return
			end
		end
	}
	v_u_11.Effects:Connect(function(p77, ...)
		-- upvalues: (copy) v_u_76
		local v78 = v_u_76[p77]
		if v78 then
			v78(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12
	v_u_11 = v_u_1.GetService("LassoService")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13