-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Naoya.Base.DecisiveStrikeController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = require(v_u_5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "DecisiveStrikeController"
})
function v14.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_5, (ref) v_u_13, (copy) v_u_4, (copy) v_u_8, (copy) v_u_9, (ref) v_u_10, (ref) v_u_11
	local v_u_150 = {
		["Weave"] = function(p15)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				local v17 = TweenInfo.new(1.2)
				v_u_12:DustTrail(p15, 0.5, CFrame.Angles(0, -1.5707963267948966, 0))
				v_u_12:PlaySound(v_u_7.Naoya.Decisive.Startup, v16, game.SoundService.Effect)
				for v18 = 1, 3 do
					local v19 = v_u_6.Damage.HitGlow:Clone()
					v_u_2:AddItem(v19, 1.2)
					v19.Parent = workspace.Effects
					for _, v20 in v19:GetChildren() do
						v20.Color = Color3.fromRGB(128, 126, 255)
						v20.Anchored = true
						v20.CFrame = p15[v20.Name].CFrame
						v_u_3:Create(v20, v17, {
							["Transparency"] = 1,
							["Position"] = nil,
							["Position"] = v20.Position + v16.CFrame.LookVector * 4
						}):Play()
					end
					local v21 = {}
					for _, v22 in p15:GetDescendants() do
						if not (v22:IsA("BasePart") or v22:IsA("Decal")) or v22.Transparency == 1 then
							continue
						end
						local v23 = v22.Transparency
						v22.Transparency = 1
						v21[v22] = v23
					end
					task.wait(0.1)
					for v24, v25 in v21 do
						if not v24.Parent then
							continue
						end
						v24.Transparency = v25
					end
					local v26 = v_u_6.Damage.HitGlow:Clone()
					v_u_2:AddItem(v26, 1.2)
					v26.Parent = workspace.Effects
					for _, v27 in v26:GetChildren() do
						v27.Color = Color3.fromRGB(128, 126, 255)
						v27.Anchored = true
						v27.CFrame = p15[v27.Name].CFrame
						v_u_3:Create(v27, v17, {
							["Transparency"] = 1,
							["Position"] = nil,
							["Position"] = v27.Position + v16.CFrame.LookVector * 4
						}):Play()
					end
					if v18 == 2 then
						v_u_12:PlaySound(v_u_7.Naoya.Decisive.Flicker1, v16, game.SoundService.Effect)
					elseif v18 == 3 then
						v_u_12:PlaySound(v_u_7.Naoya.Decisive.Flicker2, v16, game.SoundService.Effect)
					end
					local v28 = v_u_6.Naoya.Teleport:Clone()
					v28.CFrame = v16.CFrame
					v28.Parent = workspace.Effects
					v28.Lines:Emit(8)
					v28.Floor.Dust:Emit(30)
					v_u_2:AddItem(v28, 1)
					task.wait(0.1)
				end
			end
		end,
		["Flick"] = function(p29, p30, p31)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_5, (ref) v_u_2, (ref) v_u_6, (ref) v_u_3
			local v_u_32 = p29:FindFirstChild("HumanoidRootPart")
			if v_u_32 then
				local v_u_33 = v_u_32.CFrame
				if p31 > 1 and p30 then
					local v34 = v_u_12:PlaySound(v_u_7.Naoya.Decisive.Boost, v_u_32, game.SoundService.Effect)
					v34.Volume = v34.Volume * (p31 / 3)
					local v35 = Instance.new("Model")
					local v36 = v_u_5.Utils.Itadori.RushWind:Clone()
					v36.CFrame = v_u_33 * CFrame.new(0, -1, 0)
					v36.Parent = v35
					v35.Parent = workspace.Effects
					v35:ScaleTo(0.25 * p31)
					v36.Ring:Emit(7)
					v_u_2:AddItem(v35, 2)
					local v37 = v_u_6.Itadori.Shock:Clone()
					local v38 = Instance.new("Model")
					v37.Parent = v38
					v38:ScaleTo(0.4 * p31)
					v_u_2:AddItem(v38, 0.2)
					v37.CFrame = v_u_33 * CFrame.Angles(1.5707963267948966, 0, 0)
					v37.Parent = workspace.Effects
					v_u_3:Create(v37, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v37, 0.2)
					task.delay(0.05, function()
						-- upvalues: (ref) v_u_6, (copy) v_u_33, (copy) v_u_32, (ref) v_u_3, (ref) v_u_2
						local v39 = v_u_6.Itadori.Shock:Clone()
						v39.CFrame = (v_u_33 - v_u_33.Position + v_u_32.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
						v39.Parent = workspace.Effects
						v_u_3:Create(v39, TweenInfo.new(0.2), {
							["Size"] = Vector3.new(8, 0, 8),
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v39, 0.2)
					end)
				end
				local v40 = TweenInfo.new(1.2)
				v_u_12:DustTrail(p29, 0.5, CFrame.Angles(0, -1.5707963267948966, 0))
				local v41 = v_u_6.Damage.HitGlow:Clone()
				v_u_2:AddItem(v41, 1.2)
				v41.Parent = workspace.Effects
				for _, v42 in v41:GetChildren() do
					v42.Color = Color3.fromRGB(128, 126, 255)
					v42.Anchored = true
					v42.CFrame = p29[v42.Name].CFrame
					v_u_3:Create(v42, v40, {
						["Transparency"] = 1,
						["Position"] = nil,
						["Position"] = v42.Position + v_u_32.CFrame.LookVector * 4
					}):Play()
				end
				local v43 = {}
				for _, v44 in p29:GetDescendants() do
					if not (v44:IsA("BasePart") or v44:IsA("Decal")) or v44.Transparency == 1 then
						continue
					end
					local v45 = v44.Transparency
					v44.Transparency = 1
					v43[v44] = v45
				end
				task.wait(0.1)
				for v46, v47 in v43 do
					if not v46.Parent then
						continue
					end
					v46.Transparency = v47
				end
				local v48 = v_u_6.Damage.HitGlow:Clone()
				v_u_2:AddItem(v48, 1.2)
				v48.Parent = workspace.Effects
				for _, v49 in v48:GetChildren() do
					v49.Color = Color3.fromRGB(128, 126, 255)
					v49.Anchored = true
					v49.CFrame = p29[v49.Name].CFrame
					v_u_3:Create(v49, v40, {
						["Transparency"] = 1,
						["Position"] = nil,
						["Position"] = v49.Position + v_u_32.CFrame.LookVector * 4
					}):Play()
				end
				local v50 = math.random(1, 3)
				v_u_12:PlaySound(v_u_7.Naoya.Decisive["Flicker" .. v50], v_u_32, game.SoundService.Effect).PlaybackSpeed = math.random(90, 110) / 100
				local v51 = v_u_6.Naoya.Teleport:Clone()
				v51.CFrame = v_u_32.CFrame
				v51.Parent = workspace.Effects
				v51.Lines:Emit(8)
				v51.Floor.Dust:Emit(30)
				v_u_2:AddItem(v51, 1)
			end
		end,
		["ClearForce"] = function(p52)
			-- upvalues: (ref) v_u_13
			local v53 = p52:FindFirstChild("HumanoidRootPart")
			if v53 then
				v_u_13:ClearForce(v53)
				v_u_13:ClearForce(p52.Torso)
			end
		end,
		["FlickBar"] = function(p54, p_u_55)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2
			if p54 and p_u_55 then
				local v56 = p54:FindFirstChild("HumanoidRootPart")
				if v56 then
					local v_u_57 = v_u_6.Yuta.Outburst.ChargeMeter:Clone()
					v_u_57.Parent = v56
					local v_u_58 = v_u_57:FindFirstChild("Bars")
					v_u_3:Create(v_u_58, TweenInfo.new(0), {
						["GroupTransparency"] = 0
					}):Play()
					local v_u_61 = p_u_55.Changed:Connect(function()
						-- upvalues: (copy) v_u_58, (copy) p_u_55, (ref) v_u_6
						local v59 = v_u_58:FindFirstChild(p_u_55.Value)
						if v59 then
							local v60 = v_u_6.Naoya.Projection.Bar.Bar.UIGradient:Clone()
							v60.Rotation = 90
							v60.Parent = v59
							v59.BackgroundColor3 = Color3.new(1, 1, 1)
							v59.BackgroundTransparency = 0
						end
					end)
					p_u_55.AncestryChanged:Once(function()
						-- upvalues: (copy) v_u_57, (ref) v_u_3, (copy) v_u_58, (ref) v_u_2, (copy) v_u_61
						if v_u_57 and v_u_57.Parent then
							v_u_3:Create(v_u_58, TweenInfo.new(0.3), {
								["GroupTransparency"] = 1
							}):Play()
							v_u_2:AddItem(v_u_57, 0.3)
						end
						v_u_61:Disconnect()
					end)
				end
			else
				return
			end
		end,
		["Ding"] = function(p62)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v63 = p62:FindFirstChild("HumanoidRootPart")
			if v63 then
				v_u_12:PlaySound(v_u_7.Naoya.Decisive.Ding, v63, game.SoundService.Effect)
			end
		end,
		["Windup"] = function(p64)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v65
			if p64 then
				v65 = p64:FindFirstChild("HumanoidRootPart") or nil
			else
				v65 = nil
			end
			if v65 then
				local v_u_66 = v_u_12:ArmFlash(p64["Right Arm"], Color3.fromRGB(128, 126, 255), 0.65)
				local v67 = p64:FindFirstChild("Info")
				local v_u_68 = nil
				v_u_68 = v67.ChildAdded:Connect(function(p69)
					-- upvalues: (ref) v_u_68, (copy) v_u_66
					if p69.Name == "NaoyaFrame" then
						v_u_68:Disconnect()
						if v_u_66 and v_u_66.Parent then
							v_u_66:Destroy()
						end
					end
				end)
				v_u_66.AncestryChanged:Once(function()
					-- upvalues: (ref) v_u_68
					v_u_68:Disconnect()
				end)
				task.wait(0.2)
				v_u_12:PlaySound(v_u_7.Naoya.Decisive.Swing, v65, game.SoundService.Effect)
			end
		end,
		["Hit1"] = function(p70, p71)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v72 = p71:FindFirstChild("HumanoidRootPart")
			if v72 then
				local v73 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v73.Position = v72.Position
				v73.Parent = workspace.Effects
				v_u_2:AddItem(v73, 1)
				v73.Sparks.Color = ColorSequence.new(Color3.new(0.666667, 0.666667, 1))
				v73.Wind.Color = v73.Sparks.Color
				v73.Wind2.Color = v73.Sparks.Color
				v73.Sparks:Emit(50)
				v73.Wind:Emit(7)
				v73.Wind2:Emit(7)
				v_u_12:Flash(p71, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_7.Naoya.Decisive.FirstHit, v72, game.SoundService.Effect)
				v_u_12:ArmFlash(p70["Right Arm"], Color3.fromRGB(128, 126, 255), 0.3)
				if v_u_4.Character == p70 or v_u_4.Character == p71 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["Hit2"] = function(p74, p75)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v76 = p74:FindFirstChild("HumanoidRootPart")
			if v76 then
				local v77 = p75:FindFirstChild("HumanoidRootPart")
				if v77 then
					v_u_12:Flash(p75, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Naoya.Decisive.SecondHit, v77, game.SoundService.Effect)
					v_u_12:ArmFlash(p74["Left Arm"], Color3.fromRGB(128, 126, 255), 0.3)
					v_u_12:PlaySound(v_u_7.Naoya.Decisive.Swing2, v76, game.SoundService.Effect)
					if v_u_4.Character == p74 or v_u_4.Character == p75 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["Hit"] = function(p78, p79)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v80 = p78:FindFirstChild("HumanoidRootPart")
			if v80 then
				local v81 = p79:FindFirstChild("HumanoidRootPart")
				if v81 then
					v_u_12:Flash(p79, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Naoya.Decisive:FindFirstChild("Hit" .. math.random(1, 4)), v81, game.SoundService.Effect)
					local v82 = math.random(140, 200) / 10
					local v83 = v_u_6.Gojo.LapseBlue.Throw:Clone()
					v83.Transparency = 0.7
					v83.Position = p79.Head.Position
					local v84 = math.random(-180, 180)
					local v85 = math.random(-180, 180)
					local v86 = math.random
					v83.Orientation = Vector3.new(v84, v85, v86(-180, 180))
					v83.Size = Vector3.new(0, 0, 7)
					v83.Parent = workspace.Effects
					v_u_3:Create(v83, TweenInfo.new(0.1, Enum.EasingStyle.Quad), {
						["Size"] = nil,
						["Transparency"] = 1,
						["Size"] = Vector3.new(v82, v82, 0)
					}):Play()
					v_u_2:AddItem(v83, 0.1)
					if v_u_4.Character == p78 or v_u_4.Character == p79 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightLoop)
					end
					local v87 = TweenInfo.new(0.075, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
					local v88 = TweenInfo.new(0.075, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
					for _ = 1, 2 do
						local v89 = v_u_6.Naoya.Barrage:Clone()
						v89.Parent = workspace.Effects
						v_u_2:AddItem(v89, 0.075)
						local v90 = v89.Arm1
						local v91 = v80.CFrame * CFrame.new(math.random(15, 35) / 10, math.random(-5, 15) / 10, math.random(-10, 30) / 10)
						local v92 = CFrame.Angles
						local v93 = math.random(-5, 5)
						local v94 = math.rad(v93)
						local v95 = math.random(10, 25)
						v90.CFrame = v91 * v92(v94, math.rad(v95), math.random(0, 3.141592653589793))
						local v96 = v89.Arm2
						local v97 = v80.CFrame * CFrame.new(-math.random(15, 35) / 10, math.random(-5, 15) / 10, math.random(-10, 30) / 10)
						local v98 = CFrame.Angles
						local v99 = math.random(-5, 5)
						local v100 = math.rad(v99)
						local v101 = math.random(-25, -10)
						v96.CFrame = v97 * v98(v100, math.rad(v101), math.random(0, 3.141592653589793))
						local v102 = v_u_3
						local v103 = v89.Arm1
						local v104 = {}
						local v105 = v89.Arm1.CFrame * CFrame.new(0, 0, -4)
						local v106 = CFrame.Angles
						local v107 = math.random(30, 60)
						v104.CFrame = v105 * v106(0, math.rad(v107), 0)
						v102:Create(v103, v87, v104):Play()
						local v108 = v_u_3
						local v109 = v89.Arm2
						local v110 = {}
						local v111 = v89.Arm2.CFrame * CFrame.new(0, 0, -4)
						local v112 = CFrame.Angles
						local v113 = math.random(30, 60)
						v110.CFrame = v111 * v112(0, math.rad(v113), 0)
						v108:Create(v109, v87, v110):Play()
						v_u_3:Create(v89.Arm1, v88, {
							["Transparency"] = 1
						}):Play()
						v_u_3:Create(v89.Arm2, v88, {
							["Transparency"] = 1
						}):Play()
						task.wait(0.05)
					end
				end
			else
				return
			end
		end,
		["Hit3"] = function(p114, p115)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_9, (ref) v_u_4, (ref) v_u_8
			local v116 = p114:FindFirstChild("HumanoidRootPart")
			if v116 then
				local v117 = p115:FindFirstChild("HumanoidRootPart")
				if v117 then
					v_u_12:Flash(p115, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Naoya.Decisive:FindFirstChild("Hit" .. math.random(1, 4)), v117, game.SoundService.Effect)
					local v118 = math.random(140, 200) / 10
					local v119 = v_u_6.Gojo.LapseBlue.Throw:Clone()
					v119.Transparency = 0.7
					v119.Position = p115.Head.Position
					local v120 = math.random(-180, 180)
					local v121 = math.random(-180, 180)
					local v122 = math.random
					v119.Orientation = Vector3.new(v120, v121, v122(-180, 180))
					v119.Size = Vector3.new(0, 0, 7)
					v119.Parent = workspace.Effects
					v_u_3:Create(v119, TweenInfo.new(0.1, Enum.EasingStyle.Quad), {
						["Size"] = nil,
						["Transparency"] = 1,
						["Size"] = Vector3.new(v118, v118, 0)
					}):Play()
					v_u_2:AddItem(v119, 0.1)
					v_u_9:Blood(p115.Head.CFrame, math.random(25, 55), 80, 15)
					if v_u_4.Character == p114 or v_u_4.Character == p115 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightLoop)
					end
					local v123 = TweenInfo.new(0.075, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
					local v124 = TweenInfo.new(0.075, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
					for _ = 1, 2 do
						local v125 = v_u_6.Naoya.Barrage:Clone()
						v125.Parent = workspace.Effects
						v_u_2:AddItem(v125, 0.075)
						local v126 = v125.Arm1
						local v127 = v116.CFrame * CFrame.new(math.random(5, 15) / 10, math.random(-5, 15) / 10, math.random(-10, 30) / 10)
						local v128 = CFrame.Angles
						local v129 = math.random(-5, 5)
						local v130 = math.rad(v129)
						local v131 = math.random(-15, 15)
						v126.CFrame = v127 * v128(v130, math.rad(v131), math.random(0, 3.141592653589793))
						local v132 = v125.Arm2
						local v133 = v116.CFrame * CFrame.new(math.random(5, 15) / 10, math.random(-5, 15) / 10, math.random(-10, 30) / 10)
						local v134 = CFrame.Angles
						local v135 = math.random(-5, 5)
						local v136 = math.rad(v135)
						local v137 = math.random(-15, 15)
						v132.CFrame = v133 * v134(v136, math.rad(v137), math.random(0, 3.141592653589793))
						local v138 = v_u_3
						local v139 = v125.Arm1
						local v140 = {}
						local v141 = v125.Arm1.CFrame * CFrame.new(0, 0, -4)
						local v142 = CFrame.Angles
						local v143 = math.random(30, 60)
						v140.CFrame = v141 * v142(0, math.rad(v143), 0)
						v138:Create(v139, v123, v140):Play()
						local v144 = v_u_3
						local v145 = v125.Arm2
						local v146 = {}
						local v147 = v125.Arm2.CFrame * CFrame.new(0, 0, -4)
						local v148 = CFrame.Angles
						local v149 = math.random(30, 60)
						v146.CFrame = v147 * v148(0, math.rad(v149), 0)
						v144:Create(v145, v123, v146):Play()
						v_u_3:Create(v125.Arm1, v124, {
							["Transparency"] = 1
						}):Play()
						v_u_3:Create(v125.Arm2, v124, {
							["Transparency"] = 1
						}):Play()
						task.wait(0.05)
					end
				end
			else
				return
			end
		end
	}
	v_u_10.Effects:Connect(function(p151, ...)
		-- upvalues: (copy) v_u_150
		local v152 = v_u_150[p151]
		if v152 then
			v152(...)
		end
	end)
	v_u_11.Effects:Connect(function(p153, ...)
		-- upvalues: (copy) v_u_150
		local v154 = v_u_150[p153]
		if v154 then
			v154(...)
		end
	end)
end
function v14.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13
	v_u_10 = v_u_1.GetService("DecisiveStrikeService")
	v_u_11 = v_u_1.GetService("DecisiveStrike2Service")
	v_u_12 = v_u_1.GetController("FXController")
	v_u_13 = v_u_1.GetController("HandicapController")
end
return v14