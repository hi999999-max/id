-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Character.JoinController.ShopController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = game:GetService("TextChatService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Utils
local v_u_6 = v_u_5.Sounds
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = game:GetService("MarketplaceService")
local v_u_10 = v_u_1.CreateController({
	["Name"] = "ShopController"
})
local v_u_11 = script.SendRobux
local v_u_12 = {
	[718947270] = "GamePass",
	[718699461] = "GamePass",
	[742180133] = "GamePass",
	[857428668] = "GamePass",
	[984868818] = "GamePass",
	[1151174294] = "GamePass"
}
local v_u_13 = {
	15691934088,
	15692322754,
	16379484942,
	16380012541,
	16938511900
}
local v_u_14 = {
	"Looking to buy something?",
	"Welcome to the shop!",
	"Hope you\'ll buy something this time.",
	"Check out the selection!",
	"What\'s up?",
	"Got something you\'re looking for?",
	"I\'ve got some stuff for you!",
	"It\'s time to spend!",
	"How\'s the portable shop service?",
	"Welcome!",
	"Hope you have fun shopping!",
	"Get me out of here.",
	"Buying something for someone? We have gifting options!",
	"hiiiii!!!!!!",
	"How are you?",
	"How\'s your day?",
	"feed me cash",
	"omg hiiiiii!!!",
	"Thinking about buying some emotes?",
	"Thinking about gifting gamepasses?"
}
local v_u_15 = {
	"ow",
	"yeow",
	"yeowch",
	"stop",
	"stop it",
	"that hurts"
}
function v_u_10._initDonateMenu() -- name: _initDonateMenu
	-- upvalues: (copy) v_u_11, (ref) v_u_7
	v_u_11.Frame.Buttons.Cancel.MouseButton1Click:Connect(function()
		-- upvalues: (ref) v_u_11
		v_u_11.Parent = script
	end)
	v_u_11.Frame.Buttons.Send.MouseButton1Click:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_7
		local v16 = v_u_11.Frame.TextBox.Text
		local v17 = tonumber(v16)
		if v17 then
			v_u_11.Parent = script
			v_u_7.SendRobux:Fire(v_u_11:GetAttribute("ReceiverId"), v17)
		end
	end)
end
function v_u_10.PromptDonateMenu(_, p18, p19) -- name: PromptDonateMenu
	-- upvalues: (copy) v_u_11, (copy) v_u_4
	if v_u_11.Parent == script then
		local v20 = p19 or game.Players:GetNameFromUserIdAsync(p18)
		v_u_11.Frame.Title.Text = ("Sending to %*"):format(v20)
		v_u_11.Frame.TextBox.Text = ""
		v_u_11:SetAttribute("ReceiverId", p18)
		v_u_11.Parent = v_u_4.PlayerGui
	end
end
local v_u_21 = nil
function v_u_10.GetGiftSelect(_) -- name: GetGiftSelect
	-- upvalues: (ref) v_u_21
	return v_u_21
end
function v_u_10.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_4, (copy) v_u_10, (ref) v_u_7, (ref) v_u_8, (copy) v_u_6, (copy) v_u_3, (ref) v_u_21, (copy) v_u_12, (copy) v_u_9, (copy) v_u_5, (copy) v_u_13, (copy) v_u_14, (copy) v_u_2, (copy) v_u_15
	local v_u_22 = v_u_4.PlayerGui:WaitForChild("Menus")
	local v_u_23 = v_u_4.PlayerGui:WaitForChild("Emotes")
	local v_u_24 = v_u_22.Group.Shop
	v_u_24:SetAttribute("Loaded", true)
	local v_u_25 = v_u_22.Keeper
	local v_u_26 = v_u_25.Keeper
	v_u_10._initDonateMenu()
	v_u_7.Notification:Connect(function(p27, p28, p29)
		-- upvalues: (ref) v_u_8, (ref) v_u_6
		if p28 == 1 then
			v_u_8:PlaySound(v_u_6.Misc.UI.Purchase, workspace, game.SoundService.Effect)
			v_u_8:Notification(p27, Color3.fromRGB(255, 255, 0), p29)
			return
		elseif p28 == 2 then
			v_u_8:Notification(p27, Color3.fromRGB(255, 255, 255), p29)
			return
		elseif p28 == 3 then
			v_u_8:PlaySound(v_u_6.Misc.UI.Announcement, workspace, game.SoundService.Effect)
			v_u_8:Notification(p27, Color3.fromRGB(255, 78, 119), p29)
		elseif p28 == "Halloween" then
			v_u_8:Notification(p27, Color3.fromRGB(255, 126, 21), p29)
		end
	end)
	v_u_7.Chat:Connect(function(p30)
		-- upvalues: (ref) v_u_3
		v_u_3.TextChannels.RBXGeneral:DisplaySystemMessage(p30)
	end)
	local v_u_31 = v_u_24.OddsList
	local v_u_32 = v_u_24.Preview
	v_u_24:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (copy) v_u_25, (copy) v_u_24, (copy) v_u_31, (copy) v_u_32
		v_u_25.Visible = v_u_24.Visible
		v_u_31.Visible = false
		v_u_32.Visible = false
	end)
	local function v_u_36(p33) -- name: SelectCategory
		-- upvalues: (copy) v_u_24, (copy) v_u_25, (copy) v_u_31, (copy) v_u_32, (ref) v_u_8, (ref) v_u_6
		for _, v34 in v_u_24.Categories:GetChildren() do
			if not v34:IsA("TextButton") then
				continue
			end
			v34.Select.Visible = v34 == p33
		end
		if p33.Name ~= "Shop" then
			v_u_25.Visible = true
			v_u_31.Visible = false
			v_u_32.Visible = false
		end
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		for _, v35 in v_u_24.Items:GetChildren() do
			v35.Visible = v35.Name == p33.Name
		end
	end
	local function v_u_41(p_u_37) -- name: Talk
		-- upvalues: (copy) v_u_25, (copy) v_u_22, (copy) v_u_24, (copy) v_u_26
		if v_u_25:FindFirstChild("Chat") then
			v_u_25:FindFirstChild("Chat"):Destroy()
		end
		local v_u_38 = v_u_22.Preset.Chat:Clone()
		v_u_38.Parent = v_u_25
		task.spawn(function()
			-- upvalues: (copy) p_u_37, (copy) v_u_38, (ref) v_u_24, (ref) v_u_25, (ref) v_u_26
			for v39 = 1, #p_u_37 do
				if not v_u_38.Parent then
					break
				end
				v_u_24.Talk:Play()
				local v40 = p_u_37
				v_u_25.Chat.Text = string.sub(v40, 0, v39)
				v_u_26.Head.Mouth.Transparency = v39 % 2
				task.wait(0.035)
			end
			if v_u_38.Parent then
				v_u_26.Head.Mouth.Transparency = 1
			end
		end)
		return v_u_38
	end
	for _, v_u_42 in v_u_24.Categories:GetChildren() do
		if not v_u_42:IsA("TextButton") then
			continue
		end
		v_u_42.MouseButton1Down:Connect(function()
			-- upvalues: (copy) v_u_36, (copy) v_u_42
			v_u_36(v_u_42)
		end)
	end
	local v_u_43 = v_u_24.Items.Gifting.ProductList
	v_u_21 = v_u_4.UserId
	for v_u_44, _ in v_u_12 do
		local v_u_45 = v_u_22.Preset.Gamepass:Clone()
		v_u_45.Parent = v_u_24.Items.Gamepass.Gamepasses
		task.spawn(function()
			-- upvalues: (ref) v_u_9, (copy) v_u_44, (copy) v_u_45, (copy) v_u_43, (ref) v_u_21, (ref) v_u_4, (ref) v_u_7
			local v46 = v_u_9:GetProductInfo(v_u_44, Enum.InfoType.GamePass)
			local v_u_47 = v46.Name
			v_u_45.Gamepass.Text = v_u_47
			v_u_45.Purchase.Robux.Text = "\238\128\130" .. (v46.PriceInRobux or "NIL")
			v_u_45.Description.Text = v46.Description or ""
			v_u_45.Name = v_u_47
			v_u_45.Icon.Image = "rbxassetid://" .. v46.IconImageAssetId
			local v48 = v_u_43.Configuration.Product:Clone()
			v48.Title.Text = ("[GAMEPASS]\n%*"):format(v_u_47)
			v48.MouseButton1Click:Connect(function()
				-- upvalues: (ref) v_u_21, (ref) v_u_4, (ref) v_u_7, (copy) v_u_47
				if v_u_21 then
					if v_u_21 ~= v_u_4.UserId then
						v_u_7.Purchase:Fire(v_u_47, "Gamepass", v_u_21)
					end
				else
					return
				end
			end)
			v48.Icon.Image = "rbxassetid://" .. v46.IconImageAssetId
			v48.Parent = v_u_43
		end)
		v_u_45.Purchase.Robux.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_7, (copy) v_u_45
			v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
			v_u_7.Purchase:Fire(v_u_45.Gamepass.Text, "Gamepass")
		end)
	end
	v_u_22.Warning.Buttons.Robux.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (copy) v_u_22, (ref) v_u_7, (ref) v_u_21
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_22.Warning.Visible = false
		v_u_7.Purchase:Fire(nil, "Gamepass", v_u_21)
	end)
	v_u_22.Warning.Buttons.Cancel.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (copy) v_u_22
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_22.Warning.Visible = false
	end)
	local v_u_49 = v_u_24.Items.Gifting.PlayerList.Players
	local v_u_50 = v_u_49.Parent.For
	local function v_u_57(p_u_51, p52, p53) -- name: createGiftPlayer
		-- upvalues: (copy) v_u_22, (copy) v_u_49, (ref) v_u_21, (ref) v_u_8, (ref) v_u_6
		local v_u_54 = v_u_22.Preset.Player:Clone()
		v_u_54.Name = p_u_51
		v_u_54.Display.Text = p53 or p52
		v_u_54.Main.Text = "(@" .. p52 .. ")"
		v_u_54.Parent = v_u_49
		v_u_54.Select.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_21, (copy) p_u_51, (ref) v_u_8, (ref) v_u_6, (ref) v_u_49, (copy) v_u_54
			v_u_21 = p_u_51
			v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
			for _, v55 in v_u_49:GetChildren() do
				if not v55:IsA("Frame") then
					continue
				end
				if v55 == v_u_54 then
					v55.BackgroundTransparency = 0.5
				else
					v55.BackgroundTransparency = 1
				end
			end
		end)
		task.spawn(function()
			-- upvalues: (copy) p_u_51, (copy) v_u_54
			local v56 = game.Players:GetUserThumbnailAsync(p_u_51, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size48x48)
			v_u_54.Icon.Image = v56
		end)
		return v_u_54
	end
	local v_u_58 = tick()
	local function v70() -- name: updateGiftList
		-- upvalues: (copy) v_u_50, (ref) v_u_21, (copy) v_u_49, (ref) v_u_4, (copy) v_u_57, (ref) v_u_58
		local v_u_59 = v_u_50.Text
		v_u_21 = nil
		for _, v60 in v_u_49:GetChildren() do
			if not v60:IsA("Frame") then
				continue
			end
			if game.Players:GetPlayerByUserId(v60.Name) then
				v60.BackgroundTransparency = 1
			else
				v60:Destroy()
			end
		end
		local v61 = #game.Players:GetChildren() - 1
		for _, v62 in game.Players:GetChildren() do
			if v62 == v_u_4 then
				continue
			end
			local v63 = v_u_49:FindFirstChild(v62.UserId) or v_u_57(v62.UserId, v62.Name, v62.DisplayName)
			if v_u_59 == "" then
				continue
			end
			local v64 = v62.Name
			local v65 = #v_u_59
			v63.Visible = string.sub(v64, 0, v65) == v_u_59
			if v63.Visible ~= false then
				continue
			end
			v61 = v61 - 1
		end
		if v61 == 0 and v_u_59 ~= "" then
			local function v69()
				-- upvalues: (ref) v_u_58, (copy) v_u_59, (ref) v_u_4, (ref) v_u_57
				v_u_58 = tick()
				local v66 = v_u_58
				local v67 = game.Players:GetUserIdFromNameAsync(v_u_59)
				if v67 == v_u_4.UserId then
					return
				else
					local v68 = game:GetService("UserService"):GetUserInfosByUserIdsAsync({ v67 })
					if v_u_58 == v66 and v68 then
						v_u_57(v68[1].Id, v68[1].Username, v68[1].DisplayName)
					end
				end
			end
			pcall(v69)
		end
	end
	v_u_50:GetPropertyChangedSignal("Text"):Connect(v70)
	for _, v_u_71 in v_u_7:GetGiftProducts() do
		local v_u_72 = v_u_43.Configuration.Product:Clone()
		v_u_72.Title.Text = v_u_71[2]
		v_u_72.MouseButton1Click:Connect(function()
			-- upvalues: (ref) v_u_21, (ref) v_u_4, (ref) v_u_7, (copy) v_u_71
			if v_u_21 then
				if v_u_21 ~= v_u_4.UserId then
					v_u_7.Purchase:Fire(v_u_71[2], "Robux", v_u_21)
				end
			else
				return
			end
		end)
		v_u_72.Parent = v_u_43
		local v_u_73 = v_u_71[3]
		task.spawn(function()
			-- upvalues: (ref) v_u_9, (copy) v_u_73, (copy) v_u_72
			local v74 = v_u_9:GetProductInfo(v_u_73, Enum.InfoType.Product)
			v_u_72.Title.Text = v74.Name
			v_u_72.Icon.Image = "rbxassetid://" .. v74.IconImageAssetId
		end)
	end
	local v_u_75 = false
	v_u_24.Items.Merch:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (ref) v_u_75, (copy) v_u_24, (ref) v_u_9, (copy) v_u_22, (ref) v_u_8, (ref) v_u_6, (ref) v_u_4
		if v_u_75 ~= true then
			v_u_75 = true
			local v76 = game.ReplicatedStorage.Remotes.ShopUGC:InvokeServer()
			v_u_24.Items.Merch.Loading.Visible = false
			for v_u_77, v_u_78 in v76 do
				task.delay(0.1 * v_u_77, function()
					-- upvalues: (ref) v_u_9, (copy) v_u_78, (ref) v_u_22, (copy) v_u_77, (ref) v_u_24, (ref) v_u_8, (ref) v_u_6, (ref) v_u_4
					local v79 = v_u_9:GetProductInfo(v_u_78, Enum.InfoType.Asset)
					local v80 = v_u_22.Preset.MerchItem:Clone()
					local v81 = DateTime.fromIsoDate(v79.Created):ToUniversalTime()
					local v82 = v81.Year
					local v83 = ("%*%*%*"):format(tostring(v82):sub(3), (v81.Month < 10 and "0" or "") .. v81.Month, (v81.Day < 10 and "0" or "") .. v81.Day)
					v80.LayoutOrder = -tonumber(v83)
					v80.Price.Text = "\238\128\130" .. v79.PriceInRobux
					if v_u_77 <= 2 then
						v80.BackgroundColor3 = Color3.fromRGB(170, 255, 255)
					end
					v80.Image = "rbxthumb://type=Asset&id=" .. v_u_78 .. "&w=150&h=150"
					v80.Parent = v_u_24.Items.Merch.Merch
					v80.MouseButton1Down:Connect(function()
						-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_9, (ref) v_u_4, (ref) v_u_78
						v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
						v_u_9:PromptPurchase(v_u_4, v_u_78)
					end)
				end)
			end
		end
	end)
	local v_u_84 = v_u_24.Items.Shop.Shop.Emote.Right
	local v_u_85 = v_u_24.Items.Shop.Shop.Skin.Right
	local v86 = v_u_24.Items.Shop.Shop.MVP
	local v87 = v_u_24.Items.Shop.Shop.Soda
	local v88 = v_u_24.Items.Shop.Shop.Item
	local v_u_89 = v_u_24.Items.Shop.Shop.Codes
	local v_u_90 = 1
	local v_u_91 = { 1, 5, 10 }
	local v_u_92 = 1
	v_u_84.Multiplier.Alt.Multiplier.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_90, (ref) v_u_92, (copy) v_u_91, (copy) v_u_84
		v_u_90 = v_u_90 + 1
		if v_u_90 > 3 then
			v_u_90 = 1
		end
		v_u_92 = v_u_91[v_u_90]
		v_u_84.Multiplier.Alt.Multiplier.Text = ("%dx"):format(v_u_92)
		v_u_84.Purchase.Buttons.Robux.Text = ("\238\128\130%d"):format(v_u_92 * 25)
		v_u_84.Purchase.Buttons.Cash.Text = ("$%d"):format(v_u_92 * 250)
	end)
	v_u_84.Purchase.Buttons.Robux.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_7, (ref) v_u_92
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7.Purchase:Fire(("Emote%*"):format(v_u_92), "Robux")
	end)
	v_u_84.Purchase.Buttons.Cash.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_7, (ref) v_u_92
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7.Purchase:Fire(("Emote%*"):format(v_u_92), "Cash")
	end)
	v_u_84.Purchase.Odds.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_7
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7.UpdateOdds:Fire("Emotes")
	end)
	local v_u_93 = 1
	local v_u_94 = { 1, 5, 10 }
	local v_u_95 = 1
	v_u_85.Multiplier.Alt.Multiplier.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_93, (ref) v_u_95, (copy) v_u_94, (copy) v_u_85
		v_u_93 = v_u_93 + 1
		if v_u_93 > 3 then
			v_u_93 = 1
		end
		v_u_95 = v_u_94[v_u_93]
		v_u_85.Multiplier.Alt.Multiplier.Text = ("%dx"):format(v_u_95)
		v_u_85.Purchase.Buttons.Robux.Text = ("\238\128\130%d"):format(v_u_95 * 25)
		v_u_85.Purchase.Buttons.Cash.Text = ("$%d"):format(v_u_95 * 250)
	end)
	v_u_85.Purchase.Buttons.Robux.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_7, (ref) v_u_95
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7.Purchase:Fire(("Skin%*"):format(v_u_95), "Robux")
	end)
	v_u_85.Purchase.Buttons.Cash.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_7, (ref) v_u_95
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7.Purchase:Fire(("Skin%*"):format(v_u_95), "Cash")
	end)
	v_u_85.Purchase.Odds.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_7
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7.UpdateOdds:Fire("Skins")
	end)
	v86.Purchase.Buttons.Robux.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_7
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7.Purchase:Fire("MVP", "Robux")
	end)
	v86.Purchase.Buttons.Cash.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_7
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7.Purchase:Fire("MVP", "Cash")
	end)
	v86.Odds.MouseButton1Click:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_7
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7.UpdateOdds:Fire("MVPs")
	end)
	v87.Purchase.Cash.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_7
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7.Purchase:Fire("Soda", "Cash")
	end)
	v88.Purchase.Cash.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_7
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7.Purchase:Fire("Item", "Cash")
	end)
	v_u_89.TextBox.Redeem.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_7, (copy) v_u_89
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7.Code:Fire(v_u_89.TextBox.Text)
		v_u_89.TextBox.Text = ""
	end)
	local v96 = v_u_5.Animations.Misc.ShopOpen
	local v_u_97 = {}
	for _, v98 in v_u_13 do
		v96.AnimationId = "rbxassetid://" .. v98
		local v99 = v_u_26.Humanoid:LoadAnimation(v96)
		table.insert(v_u_97, v99)
	end
	local v_u_100 = nil
	local v_u_101 = nil
	v_u_24:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (copy) v_u_24, (copy) v_u_97, (ref) v_u_100, (copy) v_u_25, (ref) v_u_101, (copy) v_u_41, (ref) v_u_14, (copy) v_u_26, (ref) v_u_2
		if v_u_24.Visible == true then
			local v_u_102 = v_u_97[math.random(1, #v_u_97)]
			v_u_102:Play(0, nil, 1)
			v_u_100 = v_u_102:GetMarkerReachedSignal("Chat"):Connect(function()
				-- upvalues: (copy) v_u_102, (ref) v_u_25, (ref) v_u_101, (ref) v_u_41, (ref) v_u_14
				v_u_102:AdjustSpeed(0)
				v_u_25.Button.Visible = true
				v_u_101 = v_u_41(v_u_14[math.random(1, #v_u_14)])
			end)
			v_u_26.Head.Mouth.Transparency = 1
			v_u_25.Button.Visible = false
			v_u_25.ImageTransparency = 1
			v_u_25.Position = UDim2.new(0.75, 0, 0.675, 0)
			v_u_2:Create(v_u_25, TweenInfo.new(2, Enum.EasingStyle.Elastic), {
				["Position"] = UDim2.new(0.75, 0, 0.875, 0)
			}):Play()
			v_u_2:Create(v_u_25, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["ImageTransparency"] = 0
			}):Play()
		else
			if v_u_100 then
				v_u_100:Disconnect()
				v_u_100 = nil
			end
			if v_u_101 then
				v_u_101:Destroy()
				v_u_101 = nil
			end
			for _, v103 in v_u_97 do
				v103:Stop(0)
			end
			v_u_2:Create(v_u_25, TweenInfo.new(0), {
				["ImageTransparency"] = 1
			}):Play()
		end
	end)
	v_u_25.Button.MouseButton1Down:Connect(function()
		-- upvalues: (copy) v_u_25, (ref) v_u_2, (ref) v_u_8, (ref) v_u_6, (ref) v_u_101, (copy) v_u_41, (ref) v_u_15
		v_u_25.Size = UDim2.new(0.275, 0, 0.55, 0)
		v_u_25.AnchorPoint = Vector2.new(0.5, 0.9)
		v_u_2:Create(v_u_25, TweenInfo.new(1, Enum.EasingStyle.Elastic), {
			["Size"] = UDim2.new(0.25, 0, 0.6, 0),
			["AnchorPoint"] = Vector2.new(0.5, 1)
		}):Play()
		v_u_8:PlaySound(v_u_6.Misc.UI.Squeak, workspace, game.SoundService.Effect)
		v_u_101 = v_u_41(v_u_15[math.random(1, #v_u_15)])
	end)
	local v_u_104 = v_u_4.PlayerGui.Emotes.EmoteSelect
	function v_u_5.Remotes.PickEmotePrompt.OnClientInvoke(p_u_105)
		-- upvalues: (copy) v_u_104, (copy) v_u_22, (ref) v_u_8, (ref) v_u_6
		v_u_104.Visible = true
		local v_u_106 = v_u_104.Search
		local v_u_107 = v_u_104.TextBox
		local v_u_108 = nil
		local function v_u_110() -- name: clearSearch
			-- upvalues: (copy) v_u_106
			for _, v109 in v_u_106:GetChildren() do
				if not v109:IsA("Frame") then
					continue
				end
				v109:Destroy()
			end
		end
		local function v114() -- name: updateSearch
			-- upvalues: (copy) v_u_110, (copy) v_u_107, (copy) p_u_105, (ref) v_u_22, (copy) v_u_106, (ref) v_u_8, (ref) v_u_6, (ref) v_u_108, (ref) v_u_104
			v_u_110()
			local v111 = v_u_107.Text:lower()
			for _, v_u_112 in p_u_105 do
				if v_u_107 ~= "" and not v_u_112:lower():find(v111) then
					continue
				end
				local v113 = v_u_22.Preset.Emote:Clone()
				v113.EmoteName.Text = v_u_112
				v113.Visible = true
				v113.Parent = v_u_106
				v113.MouseEnter:Connect(function()
					-- upvalues: (ref) v_u_8, (ref) v_u_6
					v_u_8:PlaySound(v_u_6.Misc.UI.Hover, workspace, game.SoundService.Effect)
				end)
				v113.EmoteName.MouseButton1Down:Connect(function()
					-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_108, (copy) v_u_112, (ref) v_u_104
					v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
					v_u_108 = v_u_112
					v_u_104.Visible = false
				end)
			end
		end
		v114()
		local v115 = v_u_107:GetPropertyChangedSignal("Text"):Connect(v114)
		v_u_104.Cancel.MouseButton1Click:Once(function()
			-- upvalues: (ref) v_u_104
			v_u_104.Visible = false
			return nil
		end)
		v_u_104:GetPropertyChangedSignal("Visible"):Wait()
		v_u_110()
		v115:Disconnect()
		return v_u_108
	end
	local v_u_116 = v_u_31.Configuration.Item
	local v_u_117 = v_u_31.Configuration.Category
	local v_u_118 = {}
	for v119, v120 in require(game.ReplicatedStorage.Modules.ListData).MoveList do
		v_u_118[v120[1][1]] = { v119, v120[1][2] }
	end
	local function v139(p121, p_u_122) -- name: updateOdds
		-- upvalues: (copy) v_u_25, (copy) v_u_31, (copy) v_u_32, (copy) v_u_117, (copy) v_u_118, (ref) v_u_7, (copy) v_u_116
		v_u_25.Visible = false
		v_u_31.Visible = true
		v_u_32.Visible = true
		if p_u_122 == "Skins" then
			table.sort(p121, function(p123, p124)
				return p123[2]:lower() < p124[2]:lower()
			end)
		else
			table.sort(p121, function(p125, p126)
				return p125:lower() < p126:lower()
			end)
		end
		for _, v127 in v_u_31:GetChildren() do
			if not (v127:IsA("TextButton") or v127:IsA("Frame")) then
				continue
			end
			v127:Destroy()
		end
		local v128 = 100 / #p121
		local v129 = string.format("%.3f", v128):gsub("%.?0+$", "")
		for v130, v_u_131 in p121 do
			if p_u_122 == "Skins" then
				local v132 = v_u_131[1]
				local v133 = v_u_31:FindFirstChild(v132)
				if not v133 then
					local v_u_134 = v_u_117:Clone()
					v_u_134.Dropdown.Title.Text = v132
					v_u_134.Name = v132
					local v_u_135 = v_u_134.Dropdown.Icon
					v_u_134.Dropdown.MouseButton1Click:Connect(function()
						-- upvalues: (copy) v_u_135, (ref) v_u_134
						v_u_135.Text = v_u_135.Text == "v" and ">" or "v"
						v_u_134.List.Visible = v_u_135.Text == "v"
					end)
					v_u_134.Parent = v_u_31
					local v136 = v_u_118[v132:upper()]
					if v136 then
						v_u_134.LayoutOrder = v136[1]
						v_u_134.Dropdown.BackgroundColor3 = v136[2]
						v133 = v_u_134
					else
						v_u_134.LayoutOrder = 99
						v133 = v_u_134
					end
				end
				local v137 = v133.Configuration.Item:Clone()
				v137.ItemName.Text = ("%* | %*"):format(v_u_131[2], v_u_131[3])
				v137.Odds.Text = ("%*%%"):format(v129)
				v137.LayoutOrder = v130
				v137.Parent = v133.List
				v137.MouseButton1Click:Connect(function()
					-- upvalues: (ref) v_u_7, (copy) p_u_122, (copy) v_u_131
					v_u_7.Preview:Fire(p_u_122, v_u_131)
				end)
			else
				local v138 = v_u_116:Clone()
				v138.ItemName.Text = v_u_131
				v138.Odds.Text = ("%*%%"):format(v129)
				v138.LayoutOrder = v130
				v138.Parent = v_u_31
				v138.MouseButton1Click:Connect(function()
					-- upvalues: (ref) v_u_7, (copy) p_u_122, (copy) v_u_131
					v_u_7.Preview:Fire(p_u_122, v_u_131)
				end)
			end
		end
	end
	v_u_7.UpdateOdds:Connect(v139)
	v_u_7.Preview:Connect(function(p140, p141) -- name: updatePreview
		-- upvalues: (copy) v_u_32, (copy) v_u_23
		for _, v142 in v_u_32:GetChildren() do
			if v142:IsA("UIStroke") or v142.Name == "NoPreview" then
				continue
			end
			v142:Destroy()
		end
		v_u_32.NoPreview.Visible = false
		local v143 = Instance.new("Camera")
		v143.Parent = v_u_32
		v_u_32.CurrentCamera = v143
		if p140 == "Emotes" then
			local v144 = v_u_23.Preset.Rig:Clone()
			v144.Parent = v_u_32
			if p141 then
				local v145 = Instance.new("Animation", v144)
				v145.AnimationId = p141
				if p141 ~= "0" then
					local v_u_146 = v144.Humanoid:LoadAnimation(v145)
					v_u_146.Looped = true
					v_u_146:Play()
					v_u_146:GetMarkerReachedSignal("Loop"):Connect(function(p147)
						-- upvalues: (copy) v_u_146
						v_u_146.TimePosition = p147
					end)
				end
			end
			v143.CFrame = v144.HumanoidRootPart.CFrame * CFrame.new(0, 0, -30) * CFrame.Angles(0, 3.141592653589793, 0)
			v143.FieldOfView = 17
		elseif p140 == "Skins" then
			if not p141 then
				v_u_32.NoPreview.Visible = true
				return
			end
			local v148 = Instance.new("Model")
			v148.Parent = v_u_32
			p141.Parent = v148
			local v149 = v148:FindFirstChildWhichIsA("BasePart", true)
			local v150 = Instance.new("Model", v148)
			if v149.Parent == p141 then
				v149.Parent = v150
			else
				v149.Parent.Parent = v150
			end
			v150:PivotTo(CFrame.new())
			local _, v151 = v150:GetBoundingBox()
			v143.CFrame = CFrame.lookAt(CFrame.new(0, 0, -v151.Magnitude * 0.8).Position, v149.Position)
		end
	end)
	local function v152()
		-- upvalues: (ref) v_u_4
		return game:GetService("PolicyService"):GetPolicyInfoForPlayerAsync(v_u_4)
	end
	local v153, v154 = pcall(v152)
	if v153 and v154.ArePaidRandomItemsRestricted then
		v_u_84.Purchase.Buttons.Robux.Visible = false
		v86.Purchase.Buttons.Robux.Visible = false
	end
end
function v_u_10.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (ref) v_u_8
	v_u_7 = v_u_1.GetService("ShopService")
	v_u_8 = v_u_1.GetController("FXController")
end
return v_u_10