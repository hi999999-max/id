-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Hanami.Base.RootSwarmController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v_u_4 = game.ReplicatedStorage
local _ = v_u_4.Animations
local v_u_5 = v_u_4.Utils
local v_u_6 = v_u_4.Sounds
require(v_u_4.Modules.CameraShaker)
require(v_u_4.Modules.BloodyZee)
local v_u_7 = nil
local v_u_8 = nil
local v9 = v_u_1.CreateController({
	["Name"] = "RootSwarmController"
})
local v_u_10 = { Color3.fromRGB(86, 66, 54), Color3.fromRGB(76, 60, 51), Color3.fromRGB(86, 60, 51) }
function v9.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_8, (copy) v_u_6, (copy) v_u_10, (copy) v_u_4, (copy) v_u_2, (copy) v_u_3, (copy) v_u_5, (ref) v_u_7
	local v_u_71 = {
		["Startup"] = function(p11)
			-- upvalues: (ref) v_u_8, (ref) v_u_6
			local v12 = p11:FindFirstChild("HumanoidRootPart")
			if v12 then
				v_u_8:PlaySound(v_u_6.Hanami.RootSwarm.Startup, v12, game.SoundService.Effect)
			end
		end,
		["Roots"] = function(p13)
			-- upvalues: (ref) v_u_10, (ref) v_u_4, (ref) v_u_8, (ref) v_u_2, (ref) v_u_6, (ref) v_u_3
			local v_u_14 = Random.new()
			if workspace:Raycast(p13.Position + p13.lookVector * 1, Vector3.new(0, -5, 0), _G.MapParams) or workspace:Raycast(p13.Position, Vector3.new(0, -15, 0), _G.MapParams) then
				local v_u_15 = {}
				local v_u_16 = false
				local v_u_17 = {}
				local v_u_18 = nil
				for v_u_19 = 0, 8 do
					local v_u_20 = p13 * CFrame.new(0, -2, (v_u_19 + 1) * -4)
					task.spawn(function()
						-- upvalues: (ref) v_u_10, (copy) v_u_14, (copy) v_u_20, (ref) v_u_18, (ref) v_u_4, (ref) v_u_8, (ref) v_u_2, (copy) v_u_19, (ref) v_u_6, (copy) v_u_15, (ref) v_u_16, (copy) v_u_17
						local v21 = math.random(2, 5)
						local v22 = Color3.new(1, 1, 1)
						local v23 = 25
						for v24 = 1, 3 do
							local v25 = v_u_10[v_u_14:NextInteger(1, #v_u_10)]
							local v26 = v_u_14:NextNumber(-40, 40) / 10
							local v27 = v_u_14:NextNumber(-6, -3)
							local v28 = v_u_14:NextNumber(-3, 3)
							local v29 = v_u_14:NextNumber(1, 5)
							local v30 = vector.create(0, v29, 0)
							local _ = v_u_20 * CFrame.new(v26, -2, -4 + v27).Position
							local v31 = v_u_20 * CFrame.new(v26 + v28, -2, 4 + v27).Position
							local v_u_32 = workspace:Raycast(v_u_20 * CFrame.new(v26, 1, -4 + v27).Position, Vector3.new(0, -4, 0), _G.MapParams)
							local v_u_33
							if v_u_32 then
								v_u_33 = v_u_20 * CFrame.new(v26, -1.5, -4 + v27).Position
								v_u_18 = v_u_20
							else
								v_u_33 = v_u_20 * CFrame.new(v26, v_u_14:NextNumber(-4, 4), -4 + v27).Position
								local v34 = v_u_14:NextNumber(-2, 2)
								local v35 = v_u_14:NextNumber(-4, 4)
								local v36 = v_u_14
								v30 = vector.create(v34, v35, v36:NextNumber(-2, 2))
							end
							local v37 = workspace:Raycast(v_u_20 * CFrame.new(v26 + v28, 1, 4 + v27).Position, Vector3.new(0, -3, 0), _G.MapParams)
							if v37 then
								v31 = v_u_20 * CFrame.new(v26 + v28, -1.5, 4 + v27).Position
								v_u_18 = v_u_20
								v22 = v37.Instance.Color
							elseif v_u_18 then
								v31 = v_u_18 * CFrame.new(v26, -1.5, 4 + v27).Position
							end
							local v38 = (v31 + v_u_33) / 2 + v30
							local v_u_39 = v_u_14:NextNumber(1.5, 2)
							v23 = v23 * (v_u_14:NextInteger(0, 1) * 2 - 1)
							local v40 = v_u_4.Utils.Hanami.RootsDust:Clone()
							v40.Position = v31
							v40.Size = vector.create(v_u_39, 0.25, v_u_39)
							v40.Bits.Color = ColorSequence.new(v22)
							v_u_8:PlayParticles(v40)
							v40.Parent = workspace.Effects
							v_u_2:AddItem(v40, 2)
							if v24 == 1 and v_u_19 == 0 then
								v_u_8:PlaySound(v_u_6.Hanami.RootSwarm.Swarm, v40, game.SoundService.Effect)
							end
							local v41 = v31
							for v42 = 1, v21 do
								local v43 = v42 / v21
								local v44 = v_u_14:NextNumber(0.75, 1.25)
								local v45 = v43 * 3.141592653589793
								local v46 = v_u_39 * (v44 + math.cos(v45) * 0.25)
								local v47 = Instance.new("Part")
								v47.Name = v42
								v47.CanCollide = false
								v47.Anchored = true
								v47.Color = v25
								v47.Material = Enum.Material.Wood
								v47.Size = vector.create(v46, v46, 0.1)
								if v_u_32 then
									local v48 = v_u_15
									table.insert(v48, v47)
								else
									v_u_16 = true
									v47.CanCollide = true
									local v49 = v_u_17[("%*_%*"):format(v_u_19, v24)]
									if not v49 then
										v49 = {}
										v_u_17[("%*_%*"):format(v_u_19, v24)] = v49
									end
									table.insert(v49, 1, v47)
								end
								local v50 = v31 + (v38 - v31) * v43
								local v51 = v50 + (v38 + (v_u_33 - v38) * v43 - v50) * v43
								v47.Position = v51
								v47.CFrame = CFrame.new(v51, v41) * CFrame.new(0, 0, -(v41 - v51).Magnitude / 2) * CFrame.Angles(0, 0, math.random(0, 360))
								local v52 = (v51 - v41).Magnitude * 1.25
								v47.Size = vector.create(v46, v46, v52)
								task.delay(0.04 / v21, function()
									-- upvalues: (copy) v_u_32, (ref) v_u_4, (ref) v_u_33, (copy) v_u_39, (ref) v_u_8, (ref) v_u_2
									if v_u_32 then
										local v53 = v_u_4.Utils.Hanami.RootsDust:Clone()
										v53.Position = v_u_33
										local v54 = 1 * v_u_39
										local v55 = 1 * v_u_39
										v53.Size = vector.create(v54, 0.25, v55)
										v53.Bits.Color = ColorSequence.new(v_u_32.Instance.Color)
										v_u_8:PlayParticles(v53)
										v53.Parent = workspace.Effects
										v_u_2:AddItem(v53, 2)
									end
								end)
								v47.Parent = workspace.Effects
								task.wait(0.04 / v21)
								v41 = v51
							end
						end
					end)
					task.wait(0.04)
				end
				task.wait(v_u_16 and 3 or 1)
				local v_u_56 = false
				for _, v57 in v_u_15 do
					if not v_u_56 then
						v_u_8:PlaySound(v_u_6.Hanami.RootSwarm.Disappear, v57, game.SoundService.Effect)
						v_u_56 = true
					end
					v_u_3:Create(v57, TweenInfo.new(0.75), {
						["Position"] = v57.Position - Vector3.new(0, 4, 0),
						["Size"] = v57.Size * Vector3.new(0, 0, 1)
					}):Play()
				end
				for _, v_u_58 in v_u_17 do
					local v_u_59 = 1 / #v_u_58
					local v_u_60 = CFrame.Angles(0, 0, 3.141592653589793)
					task.spawn(function()
						-- upvalues: (copy) v_u_58, (ref) v_u_56, (ref) v_u_8, (ref) v_u_6, (ref) v_u_3, (copy) v_u_59, (copy) v_u_60
						for v61, v62 in v_u_58 do
							if not v_u_56 then
								v_u_56 = true
								v_u_8:PlaySound(v_u_6.Hanami.RootSwarm.Disappear, v62, game.SoundService.Effect)
							end
							local v63 = v62.Size
							local v64 = v_u_58[v61 + 1] and v_u_58[v61 + 1].CFrame or v62.CFrame * CFrame.new(0, 0, -v63.Z)
							v_u_3:Create(v62, TweenInfo.new(v_u_59), {
								["Size"] = v63 * Vector3.new(0, 0, 0),
								["CFrame"] = v64 * v_u_60
							}):Play()
							task.wait(v_u_59 / 2)
						end
					end)
				end
				task.wait(1.4)
				for _, v65 in v_u_15 do
					v65:Destroy()
				end
				for _, v66 in v_u_17 do
					for _, v67 in v66 do
						v67:Destroy()
					end
				end
			end
		end,
		["Hit"] = function(p68)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_8, (ref) v_u_6
			local v69 = p68:FindFirstChild("HumanoidRootPart")
			if v69 then
				local v70 = v_u_5.Mahito.CrushingRushdown.DrillImpact:Clone()
				v70.Position = v69.Position
				v70.Parent = workspace.Effects
				v_u_2:AddItem(v70, 1)
				v70.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 0.498039))
				v70.Wind.Color = v70.Sparks.Color
				v70.Wind2.Color = v70.Sparks.Color
				v70.Sparks:Emit(30)
				v70.Wind2:Emit(7)
				v_u_8:Flash(p68, Color3.new(1, 1, 1))
				v_u_8:PlaySound(v_u_6.Hakari.EnergySurge.Hit1, v69, game.SoundService.Effect)
			end
		end
	}
	v_u_7.Effects:Connect(function(p72, ...)
		-- upvalues: (copy) v_u_71
		local v73 = v_u_71[p72]
		if v73 then
			v73(...)
		end
	end)
end
function v9.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (ref) v_u_8
	v_u_7 = v_u_1.GetService("RootSwarmService")
	v_u_8 = v_u_1.GetController("FXController")
end
return v9