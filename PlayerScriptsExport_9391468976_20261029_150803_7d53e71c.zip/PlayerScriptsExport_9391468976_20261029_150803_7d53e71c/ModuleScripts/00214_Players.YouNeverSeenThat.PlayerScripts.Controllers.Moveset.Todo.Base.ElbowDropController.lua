-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Todo.Base.ElbowDropController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("TweenService")
game:GetService("UserInputService")
local v_u_5 = game:GetService("SoundService")
local v_u_6 = game:GetService("ReplicatedStorage")
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local _ = v_u_6.Animations
local _ = workspace.CurrentCamera
local v_u_9 = game.Players.LocalPlayer
local v_u_10 = require(v_u_6.Knit.Knit)
require(v_u_6.Modules.EffectUtils)
local v_u_11 = require(v_u_6.Modules.CameraShaker)
local v12 = RaycastParams.new()
v12.FilterType = Enum.RaycastFilterType.Include
v12.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v16 = v_u_10.CreateController({
	["Name"] = "ElbowDropController"
})
local function v_u_28(p17, p18, p_u_19) -- name: dustTrail
	-- upvalues: (copy) v_u_7, (copy) v_u_1, (ref) v_u_13, (copy) v_u_4, (copy) v_u_3
	local v_u_20
	if p17 then
		v_u_20 = p17:FindFirstChild("HumanoidRootPart") or nil
	else
		v_u_20 = nil
	end
	if v_u_20 and v_u_20.Parent then
		local v_u_21 = v_u_7.Misc.SmokeTrail:Clone()
		v_u_21.CFrame = v_u_20.CFrame * (p_u_19 or CFrame.identity)
		v_u_21.Parent = workspace.Effects
		v_u_1:AddItem(v_u_21, p18 + 0.6)
		local v_u_22 = v_u_13:GetCharacterHeight(p17) * 2
		if p_u_19 then
			v_u_21.Dash.Smoke.Enabled = true
			v_u_4:Create(v_u_21.Dash.Smoke, TweenInfo.new(p18), {
				["Rate"] = 0
			}):Play()
			local v23 = workspace:Raycast(v_u_20.Position, Vector3.new(0, 1, 0) * -v_u_22, _G.MapParams)
			if v23 then
				v_u_21.Position = v23.Position
				v_u_21.Dash.Smoke:Emit(15)
			end
		end
		local v_u_24 = nil
		local v_u_27 = v_u_3.RenderStepped:Connect(function()
			-- upvalues: (copy) v_u_21, (copy) v_u_20, (copy) v_u_22, (copy) p_u_19, (ref) v_u_24
			if v_u_21 and v_u_21.Parent then
				local v25 = v_u_20.Position
				local v26 = workspace:Raycast(v25 + Vector3.new(0, 1, 0), Vector3.new(0, 1, 0) * -v_u_22, _G.MapParams)
				if v26 then
					if p_u_19 then
						v_u_21.Dash.Smoke.Enabled = true
					end
					v_u_21.CFrame = v_u_20.CFrame * (p_u_19 or CFrame.identity) - v25 + v26.Position
					v_u_21.Velocity = v_u_20.AssemblyLinearVelocity
					if not v_u_24 then
						v_u_24 = v_u_21.Smoke
						v_u_24.Color = ColorSequence.new(v26.Instance.Color)
						v_u_24.Enabled = true
						return
					end
					if v_u_24.Color.Keypoints[1].Value ~= v26.Instance.Color then
						v_u_24.Enabled = false
						v_u_24 = v_u_24:Clone()
						v_u_24.Color = ColorSequence.new(v26.Instance.Color)
						v_u_24.Enabled = true
						v_u_24.Parent = v_u_21
						return
					end
				else
					v_u_21.Dash.Smoke.Enabled = false
					if v_u_24 then
						v_u_24.Enabled = false
					end
				end
			end
		end)
		task.delay(p18, function()
			-- upvalues: (copy) v_u_27, (copy) v_u_21, (ref) v_u_24
			v_u_27:Disconnect()
			if v_u_21 and v_u_21.Parent then
				if v_u_24 then
					v_u_24.Enabled = false
				end
				v_u_21.Dash.Smoke.Enabled = false
			end
		end)
		return v_u_21
	end
end
function v16.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_15, (copy) v_u_8, (copy) v_u_9, (copy) v_u_11, (copy) v_u_4, (copy) v_u_7, (copy) v_u_1, (copy) v_u_3, (copy) v_u_6, (copy) v_u_5, (copy) v_u_28, (copy) v_u_2, (ref) v_u_14
	local v_u_120 = {
		["Hit"] = function(p29, p30, p31)
			-- upvalues: (ref) v_u_15, (ref) v_u_8, (ref) v_u_9, (ref) v_u_11
			local v32
			if p30 then
				v32 = p30:FindFirstChild("HumanoidRootPart") or nil
			else
				v32 = nil
			end
			if v32 then
				v_u_15:Flash(p30, Color3.new(1, 1, 1))
				v_u_15:PlaySound(v_u_8.Itadori.M1.Hit2, v32, game.SoundService.Effect)
				v_u_15:PlaySound(v_u_8.Itadori.Rush.RushBreak, v32, game.SoundService.Effect)
				if v_u_9 == p29 or v_u_9.Character == p30 then
					v_u_11.CurrentShaker:Shake(p31 and v_u_11.Presets.MediumHit or v_u_11.Presets.HeavyHit)
				end
			end
		end,
		["Jump"] = function(p33, p34)
			-- upvalues: (ref) v_u_9, (ref) v_u_4
			local v35 = p34.Parent.Parent:FindFirstChild("HumanoidRootPart")
			if v35 then
				local v36 = v35.CFrame.LookVector * 3 - Vector3.new(0, 5, 0)
				if v_u_9.Character == v35.Parent then
					v_u_4:Create(p34, TweenInfo.new(0.5), {
						["P"] = 100000
					}):Play()
					repeat
						p34.Position = p33.Position - v36
						task.wait()
					until not (p34.Parent and p33)
				else
					repeat
						local v37 = v35.CFrame - v35.Position + p33.Position - v36
						v35.CFrame = v35.CFrame:Lerp(v37, 0.15)
						task.wait()
					until not (p34.Parent and p33)
				end
				v_u_4:Create(p34, TweenInfo.new(0.5), {
					["P"] = 100000
				}):Play()
				repeat
					p34.Position = p33.Position - v36
					task.wait()
				until not (p34.Parent and p33)
			end
		end,
		["Crush"] = function(p38, p39)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_1, (ref) v_u_15, (ref) v_u_8, (ref) v_u_9, (ref) v_u_11
			local v40 = v_u_7.Itadori.CrushingBlow:Clone()
			v40.Position = p39
			v40.Parent = workspace.Effects
			v40.Floor.Wind2.Color = ColorSequence.new(Color3.new(0.333333, 0.666667, 1))
			v40.Floor.Sparks.Color = ColorSequence.new(Color3.new(0.333333, 0.666667, 1))
			v_u_4:Create(v40.Air, TweenInfo.new(0.2), {
				["Position"] = Vector3.new(0, 0, 0)
			}):Play()
			v_u_4:Create(v40.PointLight, TweenInfo.new(0.6), {
				["Brightness"] = 0
			}):Play()
			v40.Floor.Ring:Emit(10)
			v40.Floor.Sparks:Emit(10)
			v40.Floor.Wind2:Emit(8)
			v_u_1:AddItem(v40, 1.5)
			v_u_15:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v40, game.SoundService.Effect)
			v_u_15:DustBreak(p39 + Vector3.new(0, 1, 0), Vector3.new(0, 1, 0), 13, 15, 0.4, 1)
			v_u_15:PlaySound(v_u_8.Itadori.CrushingBlow.GroundImpact, v40, game.SoundService.Effect)
			if v_u_9 == p38 then
				v_u_11.CurrentShaker:Shake(v_u_11.Presets.Snap)
			end
		end,
		["Woah"] = function(p41, p42)
			-- upvalues: (ref) v_u_9, (ref) v_u_15, (ref) v_u_8, (ref) v_u_7, (ref) v_u_1, (ref) v_u_4
			if v_u_9.Character == p41 or v_u_9.Character == p42 then
				v_u_15:PlaySound(v_u_8.Todo.Boom, workspace, game.SoundService.Effect)
				local v43 = v_u_7.Todo.Woah:Clone()
				v43.ImageLabel.Image = "rbxassetid://73458769859093"
				v43.Parent = v_u_9.PlayerGui
				v_u_1:AddItem(v43, 1)
				v_u_4:Create(v43.ImageLabel, TweenInfo.new(1), {
					["ImageTransparency"] = 1
				}):Play()
			end
		end,
		["Force"] = function(p_u_44, p_u_45)
			-- upvalues: (ref) v_u_3
			local v_u_46
			if p_u_44 then
				v_u_46 = p_u_44:FindFirstChild("HumanoidRootPart") or nil
			else
				v_u_46 = nil
			end
			if v_u_46 and (v_u_46.Parent and (p_u_45 and p_u_45.Parent)) then
				local v_u_47 = nil
				local v_u_48 = nil
				local v_u_49 = v_u_46.CFrame.LookVector * Vector3.new(1, 0, 1)
				p_u_45.Velocity = v_u_49 * p_u_45.Velocity.Magnitude
				v_u_47 = v_u_3.Stepped:Connect(function(_, p50)
					-- upvalues: (copy) p_u_45, (ref) v_u_47, (copy) v_u_46, (copy) v_u_49
					if p_u_45 and p_u_45.Parent then
						local v51 = v_u_46.Position
						local v52 = p_u_45.Velocity * p50 + v_u_49 * 2
						if workspace:Blockcast(CFrame.new(v51), v_u_46.Size, v52, _G.MapParams) then
							p_u_45.Velocity = Vector3.new(0, 0, 0)
						end
					else
						v_u_47:Disconnect()
					end
				end)
				v_u_48 = v_u_3.RenderStepped:Connect(function()
					-- upvalues: (copy) p_u_44, (copy) p_u_45, (ref) v_u_48, (copy) v_u_46, (copy) v_u_49
					if p_u_44 and (p_u_44.Parent and (p_u_45 and p_u_45.Parent)) then
						local v53 = v_u_46.Position
						p_u_44:PivotTo((CFrame.lookAt(v53, v53 + v_u_49)))
					else
						v_u_48:Disconnect()
					end
				end)
			end
		end,
		["SlideStart"] = function(p54, p55)
			-- upvalues: (ref) v_u_6, (ref) v_u_1, (ref) v_u_15, (ref) v_u_8, (ref) v_u_5, (ref) v_u_28
			local v56
			if p54 then
				v56 = p54:FindFirstChild("HumanoidRootPart") or nil
			else
				v56 = nil
			end
			if v56 and (v56.Parent and (p55 and p55.Parent)) then
				local v57 = p55.Velocity.Magnitude
				local v58 = v_u_6.Utils.Itadori.RushWind:Clone()
				v58.CFrame = v56.CFrame
				v58.Parent = workspace.Effects
				v_u_1:AddItem(v58, 2)
				v58.Dash1.Dash:Emit(1)
				v58.Dash2.Dash:Emit(1)
				local v59 = v_u_15:PlaySound(v_u_8.Gojo.TeleportDrag, v56, v_u_5.Effect)
				local v60 = v_u_28(p54, 1.5, CFrame.new(0, 0, 1) * CFrame.Angles(0, -1.5707963267948966, 0))
				local v61 = 1 - v57 / 85 or v57 / 85
				local v62 = math.lerp(1.15, 1.4, v61)
				v59.PlaybackSpeed = math.clamp(v62, 1.15, 1.4)
				v59.Volume = v59.Volume * 0.7
				if v56 and (v56.Parent and p55.Velocity.Magnitude >= 10) then
					local v63 = p55.Velocity.Magnitude
					local v64 = v63 / 85
					local v65 = math.lerp(0.7, 1.6, v64)
					local v66 = math.clamp(v65, 0.7, 1.6)
					local v67 = v63 / 85
					local v68 = math.lerp(2, 4, v67)
					local v69 = math.clamp(v68, 2, 4)
					local v70 = v63 / 85
					local v71 = math.lerp(2, 6, v70)
					local v72 = math.clamp(v71, 2, 6)
					v_u_15:DustBreak(v56.Position, Vector3.new(0, 1, 0), v69, v72, 0.2, v66)
					task.wait(0.2)
					if p55 and p55.Parent then
						continue
					end
				end
				if v60 and v60.Parent then
					v60:Destroy()
				end
				if v59 and v59.Parent then
					v59:Destroy()
				end
			end
		end,
		["SlideKnockback"] = function(p73, p_u_74, p75, p76, p77)
			-- upvalues: (ref) v_u_15, (ref) v_u_8, (ref) v_u_5, (ref) v_u_3
			local v_u_78 = p73 and p73:FindFirstChild("HumanoidRootPart") or nil
			local v_u_79
			if p_u_74 then
				v_u_79 = p_u_74:FindFirstChild("HumanoidRootPart") or nil
			else
				v_u_79 = nil
			end
			if v_u_78 and (v_u_78.Parent and (v_u_79 and v_u_79.Parent)) then
				v_u_15:Flash(p_u_74, Color3.new(1, 1, 1))
				v_u_15:PlaySound(v_u_8.Todo.SlideKick.Slide, v_u_78, v_u_5.Effect)
				v_u_15:PlaySound(v_u_8.Todo.SlideKick.Kick1, v_u_79, v_u_5.Effect)
				local v_u_80 = nil
				local v_u_81 = nil
				local v82 = workspace:GetServerTimeNow() - p77
				local v_u_83 = 0
				local v_u_84 = v_u_78.AssemblyLinearVelocity * Vector3.new(1, 0, 1)
				local v85 = v_u_84.Magnitude / 90
				local v86 = math.lerp(4, 8, v85)
				local v_u_87 = math.clamp(v86, 4, 8)
				local v88 = p76 - v82
				local v_u_89 = math.max(0, v88)
				local v_u_106 = v_u_3.Heartbeat:Connect(function(p90)
					-- upvalues: (copy) v_u_78, (copy) v_u_79, (ref) v_u_83, (ref) v_u_84, (ref) v_u_89, (copy) v_u_87, (copy) p_u_74
					if v_u_78 and (v_u_78.Parent and (v_u_79 and v_u_79.Parent)) then
						v_u_83 = v_u_83 + p90
						v_u_84 = v_u_78.AssemblyLinearVelocity * Vector3.new(1, 0, 1)
						local v91 = v_u_83
						local v92 = v_u_89
						local v93 = v_u_87
						local v94
						if v92 <= 0 then
							v94 = 0
						else
							local v95 = math.clamp(v91, 0, v92)
							v94 = v93 * 4 / v92 ^ 2 * v95 * (v92 - v95)
						end
						local v96 = v94 + 2.5
						local v97 = CFrame.new(v_u_78.Position + Vector3.new(0, 1, 0) * v96)
						local v98 = CFrame.Angles
						local v99 = math.random(1, 3) * p90
						local v100 = math.rad(v99)
						local v101 = math.random(1, 3) * p90
						local v102 = math.rad(v101)
						local v103 = math.random(1, 3) * p90
						local v104 = v97 * v98(v100, v102, (math.rad(v103)))
						for _, v105 in p_u_74:GetChildren() do
							if not (v105:IsA("BasePart") and (v105:GetAttribute("D_CC") and v105.CanCollide)) then
								continue
							end
							v105.CanCollide = false
						end
						v_u_79.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
						v_u_79.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
						p_u_74:PivotTo(v104)
					end
				end)
				local function v108() -- name: cleanupGrab
					-- upvalues: (ref) v_u_80, (ref) v_u_81, (copy) v_u_106, (copy) v_u_79, (copy) p_u_74
					v_u_80:Disconnect()
					v_u_81:Disconnect()
					v_u_106:Disconnect()
					if v_u_79 and v_u_79.Parent then
						for _, v107 in p_u_74:GetChildren() do
							if not v107:IsA("BasePart") or (not v107:GetAttribute("D_CC") or v107.CanCollide) then
								continue
							end
							v107.CanCollide = true
						end
						v_u_79.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
						v_u_79.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
					end
				end
				v_u_81 = p_u_74.AncestryChanged:Once(v108)
				v_u_80 = p75.AncestryChanged:Once(v108)
			end
		end,
		["SlideKick"] = function(p109, p110)
			-- upvalues: (ref) v_u_9, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_1, (ref) v_u_6, (ref) v_u_15, (ref) v_u_8, (ref) v_u_5
			if v_u_9 == v_u_2:GetPlayerFromCharacter(p109) or v_u_9.Character == p110 then
				v_u_11.CurrentShaker:Shake(v_u_11.Presets.Snap)
			end
			local v111 = p109 and p109:FindFirstChild("HumanoidRootPart") or nil
			local v112
			if p110 then
				v112 = p110:FindFirstChild("HumanoidRootPart") or nil
			else
				v112 = nil
			end
			if v111 and (v111.Parent and (v112 and v112.Parent)) then
				local v_u_113 = CFrame.new(v111.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				local v114 = CFrame.new(v112.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				local v115 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v115.CFrame = v114
				v115.Size = Vector3.new(0, 0, 5)
				v115.Parent = workspace.Effects
				v_u_4:Create(v115, TweenInfo.new(0.4), {
					["Size"] = Vector3.new(12, 12, 0),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v115.Position + Vector3.new(0, 2, 0)
				}):Play()
				v_u_1:AddItem(v115, 0.4)
				local v116 = v_u_7.Mahito.CrushingRushdown.DrillImpact:Clone()
				v116.Position = v112.Position
				v116.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 1))
				v116.Wind.Color = v116.Sparks.Color
				v116.Wind2.Color = v116.Sparks.Color
				v116.Sparks.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.165, 1, 0.2), NumberSequenceKeypoint.new(1, 0) })
				v116.Sparks.Speed = NumberRange.new(10, 30)
				v116.Wind2.Size = NumberSequence.new(15)
				v116.Parent = workspace.Effects
				v_u_1:AddItem(v116, 1)
				v116.Sparks:Emit(30)
				v116.Wind2:Emit(7)
				local v117 = v_u_6.Utils.Itadori.RushWind:Clone()
				v117.CFrame = v_u_113
				v117.Parent = workspace.Effects
				v_u_1:AddItem(v117, 2)
				v117.Dust:Emit(7)
				v117.Ring:Emit(7)
				local v118 = v_u_7.Itadori.Shock:Clone()
				v118.CFrame = v_u_113
				v118.Parent = workspace.Effects
				v_u_4:Create(v118, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(8, 0, 8),
					["Transparency"] = 1
				}):Play()
				v_u_1:AddItem(v118, 0.2)
				task.delay(0.1, function()
					-- upvalues: (ref) v_u_7, (copy) v_u_113, (ref) v_u_4, (ref) v_u_1
					local v119 = v_u_7.Itadori.Shock:Clone()
					v119.CFrame = v_u_113
					v119.Parent = workspace.Effects
					v_u_4:Create(v119, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_1:AddItem(v119, 0.2)
				end)
				v_u_15:Flash(p110, Color3.new(1, 1, 1))
				v_u_15:PlaySound(v_u_8.Todo.SlideKick.Kick2, v112, v_u_5.Effect)
				v_u_15:PlaySound(v_u_8.Ryu.SecondHelping.Hit, v112, v_u_5.Effect)
				v_u_15:PlaySound(v_u_8.Todo.SlideKick.WhooshKick2, v111, v_u_5.Effect)
			end
		end
	}
	v_u_14.Effects:Connect(function(p121, ...)
		-- upvalues: (copy) v_u_120
		local v122 = v_u_120[p121]
		if v122 then
			v122(...)
		end
	end)
end
function v16.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_13, (copy) v_u_10, (ref) v_u_14, (ref) v_u_15
	v_u_13 = v_u_10.GetController("HandicapController")
	v_u_14 = v_u_10.GetService("ElbowDropService")
	v_u_15 = v_u_10.GetController("FXController")
end
return v16