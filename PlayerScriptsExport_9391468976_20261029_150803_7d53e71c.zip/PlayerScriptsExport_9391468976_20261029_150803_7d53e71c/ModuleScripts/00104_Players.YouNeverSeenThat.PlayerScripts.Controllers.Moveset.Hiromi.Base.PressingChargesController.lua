-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Hiromi.Base.PressingChargesController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v_u_4 = game.ReplicatedStorage
local _ = v_u_4.Animations
local v_u_5 = v_u_4.Utils
local v_u_6 = v_u_4.Sounds
require(v_u_4.Modules.CameraShaker)
local v_u_7 = nil
local v_u_8 = nil
local v9 = v_u_1.CreateController({
	["Name"] = "PressingChargesController"
})
function v9.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_8, (copy) v_u_6, (copy) v_u_4, (copy) v_u_3, (copy) v_u_2, (copy) v_u_5, (ref) v_u_7
	local v_u_26 = {
		["Startup"] = function(p10)
			-- upvalues: (ref) v_u_8, (ref) v_u_6
			local v11 = p10:FindFirstChild("HumanoidRootPart")
			if v11 then
				v_u_8:PlaySound(v_u_6.Hiromi.Twirl.Start, v11, game.SoundService.Effect)
			end
		end,
		["Dash"] = function(p12, p13)
			-- upvalues: (ref) v_u_4, (ref) v_u_3, (ref) v_u_2, (ref) v_u_8, (ref) v_u_6
			local v14 = p12:FindFirstChild("HumanoidRootPart")
			if v14 then
				local v15 = Instance.new("Model")
				local v16 = v_u_4.Utils.Itadori.RushWind:Clone()
				v16.CFrame = p13 * CFrame.new(0, -1, 0)
				v16.Parent = v15
				v15.Parent = workspace.Effects
				v15:ScaleTo(0.8)
				for _, v17 in v16:GetDescendants() do
					if not v17:IsA("ParticleEmitter") then
						continue
					end
					v17.LockedToPart = true
				end
				v16.Ring:Emit(7)
				v16.Dash1.Dash:Emit(1)
				v16.Dash2.Dash:Emit(1)
				v_u_3:Create(v16, TweenInfo.new(0.6), {
					["CFrame"] = v16.CFrame * CFrame.new(0, 0, -7)
				}):Play()
				v_u_2:AddItem(v15, 2)
				v_u_8:ArmFlash(p12["Right Leg"], Color3.fromRGB(179, 130, 61), 0.4)
				v_u_8:PlaySound(v_u_6.Gojo.ReversalRed.Aim, v14, game.SoundService.Effect)
			end
		end,
		["Dash2"] = function(p18)
			-- upvalues: (ref) v_u_8
			if p18:FindFirstChild("HumanoidRootPart") then
				v_u_8:DustTrail(p18, 0.6, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Hit"] = function(p19)
			-- upvalues: (ref) v_u_8, (ref) v_u_6
			local v20 = p19:FindFirstChild("HumanoidRootPart")
			if v20 then
				v_u_8:Flash(p19, Color3.new(1, 1, 1))
				v_u_8:PlaySound(v_u_6.Hiromi.Twirl.Hit, v20, game.SoundService.Effect)
			end
		end,
		["Hit2"] = function(p21)
			-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_5, (ref) v_u_2
			local v22 = p21:FindFirstChild("HumanoidRootPart")
			if v22 then
				v_u_8:Flash(p21, Color3.new(1, 1, 1))
				v_u_8:PlaySound(v_u_6.Itadori.CraniumSmash.Hit2, v22, game.SoundService.Effect)
				v_u_8:PlaySound(v_u_6.Hakari.EnergySurge.Hit2, v22, game.SoundService.Effect)
				local v23 = v_u_5.Mahito.CrushingRushdown.DrillImpact:Clone()
				v23.Position = v22.Position
				v23.Parent = workspace.Effects
				v_u_2:AddItem(v23, 1)
				v23.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 0.498039))
				v23.Wind.Color = v23.Sparks.Color
				v23.Wind2.Color = v23.Sparks.Color
				v23.Sparks:Emit(30)
				v23.Wind:Emit(7)
				v23.Wind2:Emit(7)
			end
		end,
		["Finisher"] = function(p24)
			-- upvalues: (ref) v_u_8, (ref) v_u_6
			local v25 = p24:FindFirstChild("HumanoidRootPart")
			if v25 then
				v_u_8:PlaySound(v_u_6.Hiromi.JudgeReachFinisher, v25, game.SoundService.Effect).TimePosition = 0.733
			end
		end
	}
	v_u_7.Effects:Connect(function(p27, ...)
		-- upvalues: (copy) v_u_26
		local v28 = v_u_26[p27]
		if v28 then
			v28(...)
		end
	end)
end
function v9.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (ref) v_u_8
	v_u_7 = v_u_1.GetService("PressingChargesService")
	v_u_8 = v_u_1.GetController("FXController")
end
return v9