-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Megumi.Mahoraga.AdaptationController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "AdaptationController"
})
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_11, (copy) v_u_8, (copy) v_u_4, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (copy) v_u_6, (copy) v_u_7, (copy) v_u_2, (ref) v_u_10
	local v_u_73 = {
		["Glow"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				local v15 = p13:FindFirstChild("Outfit")
				if v15 then
					v_u_11:PlaySound(v_u_8.Megumi.Mahoraga.AdaptGlow, v14, game.SoundService.Effect)
					local v16 = v15.Head.DivineWheel
					local v17 = v16:Clone()
					v17.Color = Color3.fromRGB(188, 155, 93)
					v17.Material = Enum.Material.Neon
					v17.Size = v17.Size + Vector3.new(0.1, 0.1, 0.1)
					local v18 = Instance.new("Weld", v17)
					v18.Part0 = v16
					v18.Part1 = v17
					v17.Parent = workspace.Effects
					v_u_4:Create(v17, TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v17, 0.6)
				end
			end
		end,
		["Adapt"] = function(p19, p20, p21)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9, (ref) v_u_6, (ref) v_u_3
			local v22 = p19:FindFirstChild("HumanoidRootPart")
			if v22 then
				local v23 = p19:FindFirstChild("DivineWheelWeld", true)
				if v23 then
					v_u_11:PlaySound(v_u_8.Megumi.Mahoraga.Adapt2, v22, game.SoundService.Effect)
					v23.C1 = CFrame.new() * CFrame.Angles(0, -90, 0)
					v_u_4:Create(v23, TweenInfo.new(1, Enum.EasingStyle.Elastic), {
						["C1"] = CFrame.new()
					}):Play()
				end
				if v_u_5.Character == p19 or v_u_5.Character == p20 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					if not p21 then
						local v24 = v_u_6.Utils.Megumi.Mahoraga.Adapt:Clone()
						v24.Type.Text = (p19:GetAttribute("A1") or "Melee") .. " Attacks"
						if p19:GetAttribute("A2") == 1.1 then
							v24.Effect.Text = "-10% DMG"
						elseif p19:GetAttribute("A2") == 1.3 then
							v24.Effect.Text = "-30% DMG"
						elseif p19:GetAttribute("A2") == 1.5 then
							v24.Effect.Text = "-50% DMG"
						elseif p19:GetAttribute("A2") == 1.7 then
							v24.Effect.Text = "-70% DMG"
						else
							v24.Effect.Text = "FULL ADAPTATION"
						end
						v24.Parent = v_u_5.PlayerGui
						v_u_3:AddItem(v24, 1)
						v_u_4:Create(v24.Fade, TweenInfo.new(0.4), {
							["Size"] = nil,
							["ImageTransparency"] = 1,
							["Size"] = UDim2.new(3, 0, 3, 0)
						}):Play()
						v_u_4:Create(v24.Wheel, TweenInfo.new(1, Enum.EasingStyle.Elastic), {
							["Rotation"] = 90
						}):Play()
						v_u_4:Create(v24.Wheel.UIGradient, TweenInfo.new(1, Enum.EasingStyle.Elastic), {
							["Rotation"] = 0
						}):Play()
						v_u_4:Create(v24.Wheel, TweenInfo.new(1), {
							["ImageTransparency"] = 1
						}):Play()
						v_u_4:Create(v24.Type, TweenInfo.new(1), {
							["TextTransparency"] = 1
						}):Play()
						v_u_4:Create(v24.Effect, TweenInfo.new(1), {
							["TextTransparency"] = 1
						}):Play()
					end
				end
			end
		end,
		["Start"] = function(p25)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v26 = p25:FindFirstChild("HumanoidRootPart")
			if v26 then
				v_u_11:PlaySound(v_u_8.Megumi.Mahoraga.Takedown.Startup, v26, game.SoundService.Effect)
			end
		end,
		["Teleport"] = function(p_u_27)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9
			local v_u_28 = p_u_27:FindFirstChild("HumanoidRootPart")
			if v_u_28 then
				local v29 = Instance.new("Model")
				local v_u_30 = v_u_7.Gojo.Teleport:Clone()
				v_u_30.CFrame = v_u_28.CFrame + Vector3.new(0, 2, 0)
				v_u_30.Parent = v29
				v29:ScaleTo(2)
				v_u_30.Parent = workspace.Effects
				v29:Destroy()
				v_u_3:AddItem(v_u_30, 1.1)
				v_u_30.Floor.Dust:Emit(30)
				v_u_30.Lines:Emit(30)
				v_u_11:PlaySound(v_u_8.Megumi.Mahoraga.Takedown.Teleport, v_u_28, game.SoundService.Effect)
				task.delay(0.02, function()
					-- upvalues: (copy) v_u_30, (copy) v_u_28, (ref) v_u_4, (copy) p_u_27
					v_u_30.CFrame = v_u_28.CFrame
					v_u_30.Lines:Emit(30)
					v_u_30.Floor.Dust:Emit(30)
					local v31 = v_u_28:FindFirstChild("RootJoint")
					if v31 then
						local v32 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 1, -0)
						v31.C0 = v32 * CFrame.new(7, 0, 0)
						v_u_4:Create(v31, TweenInfo.new(0.5, Enum.EasingStyle.Elastic), {
							["C0"] = v32
						}):Play()
					end
					local v33 = p_u_27:FindFirstChild("Outfit")
					if v33 then
						local v34 = TweenInfo.new(0.15, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
						for _, v35 in v33:GetDescendants() do
							if not v35:IsA("BasePart") then
								continue
							end
							local v36 = v35.Transparency
							v35.Transparency = 1
							v_u_4:Create(v35, v34, {
								["Transparency"] = v36
							}):Play()
						end
					end
				end)
				if v_u_5.Character == p_u_27 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
				end
			end
		end,
		["Hit"] = function(p37, p38)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8, (ref) v_u_9
			local v39 = p37:FindFirstChild("HumanoidRootPart")
			if v39 then
				local v40 = p38:FindFirstChild("HumanoidRootPart")
				if v40 then
					local v41 = v_u_7.Gojo.HardHit:Clone()
					v41.CFrame = v39.CFrame * CFrame.Angles(0.5235987755982988, 0, 0) + v39.CFrame.LookVector * 3.5
					v41.Position = v40.Position
					v41.Parent = workspace.Effects
					v41.Dust:Emit(5)
					v41.Ring:Emit(5)
					v41.Sparks:Emit(10)
					v_u_3:AddItem(v41, 0.5)
					v_u_11:Flash(p38, Color3.new(1, 1, 1))
					v_u_11:PlaySound(v_u_8.Megumi.Elephant.Hit, v40, game.SoundService.Effect)
					v_u_11:PlaySound(v_u_8.Itadori.Rush.RushLaunch, v40, game.SoundService.Effect)
					if (workspace.CurrentCamera.CFrame.Position - v40.Position).Magnitude < 150 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
					end
				end
			else
				return
			end
		end,
		["WorldSlash"] = function(p42)
			-- upvalues: (ref) v_u_7, (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_9
			local v43 = p42:FindFirstChild("HumanoidRootPart")
			if v43 then
				local v_u_44 = v_u_7.Megumi.Mahoraga.WorldSlash:Clone()
				v_u_44:ScaleTo(2)
				v_u_44:PivotTo(v43.CFrame * CFrame.new(0, -6, 0) * CFrame.Angles(0, -1.5707963267948966, 0))
				v_u_44.Char.Value = p42
				v_u_44.Parent = workspace.Effects
				v_u_11:PlaySound(v_u_8.Megumi.Mahoraga.WorldSlash.Startup, v43, game.SoundService.Effect)
				local v45 = TweenInfo.new(0.7, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
				for _, v46 in v_u_44.groundwavepart.windbeamburst:GetDescendants() do
					if not v46:IsA("Beam") then
						continue
					end
					v_u_4:Create(v46, v45, {
						["Brightness"] = 0,
						["TextureSpeed"] = 0
					}):Play()
				end
				local v47 = TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
				v_u_4:Create(v_u_44.mesh.Decal, v47, {
					["Transparency"] = 1
				}):Play()
				v_u_4:Create(v_u_44.mesh.Mesh, v47, {
					["Scale"] = Vector3.new(16, 0, 16)
				}):Play()
				v_u_4:Create(v_u_44.mesh, v47, {
					["CFrame"] = v_u_44.mesh.CFrame * CFrame.new(0, -12, 0) * CFrame.Angles(0, -3.12413936106985, 0)
				}):Play()
				v_u_44.groundwavepart.speedlines1:Emit(10)
				v_u_44.groundwavepart.speedlines2:Emit(10)
				v_u_44.groundwavepart.groundwave.groundwave1:Emit(10)
				v_u_44.groundwavepart.groundwave.groundwave2:Emit(4)
				v_u_44.groundwavepart.groundwave.groundwave3:Emit(8)
				v_u_44.groundwavepart.groundwave.groundwave4:Emit(8)
				v_u_44.groundwavepart.groundwave.groundwave5:Emit(4)
				v_u_44.groundwavepart.groundwave.groundwave6:Emit(4)
				v_u_44.groundwavepart.groundwave.groundwave7:Emit(4)
				v_u_44.groundwavepart.groundwave.groundwave8:Emit(6)
				v_u_44.groundwavepart.groundwave.groundwave9:Emit(10)
				v_u_44.groundwavepart.groundwave.groundwave10:Emit(5)
				v_u_44.groundwavepart.groundwave.groundwave11:Emit(1)
				v_u_3:AddItem(v_u_44, 3)
				local v48 = p42.Info:FindFirstChild("WorldSlash")
				if v48 then
					if (workspace.CurrentCamera.CFrame.Position - v_u_44.PrimaryPart.Position).Magnitude < 150 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					end
					v48.Destroying:Connect(function()
						-- upvalues: (copy) v_u_44
						for _, v49 in v_u_44:GetDescendants() do
							if not (v49:IsA("ParticleEmitter") or v49:IsA("Beam")) then
								continue
							end
							v49.Enabled = false
						end
					end)
				end
			end
		end,
		["WorldSparkle"] = function(p50)
			-- upvalues: (ref) v_u_7, (ref) v_u_9
			local v51 = nil
			for _, v52 in workspace.Effects:GetChildren() do
				if v52.Name ~= "WorldSlash" then
					continue
				end
				local v53 = v52:FindFirstChild("Char")
				if not v53 or v53.Value ~= p50 then
					continue
				end
				v51 = v52
			end
			if v51 then
				if v51.groundwavepart.chargespeedlines1.Enabled ~= false then
					if _G.Settings.Flash == true then
						v51.groundwavepart.sparklelines1.Enabled = true
						v51.groundwavepart.sparklelines2.Enabled = true
						task.wait(0.25)
						if v51.groundwavepart.chargespeedlines1.Enabled == false then
							return
						end
						v51.groundwavepart.sparklelines1.Enabled = false
						v51.groundwavepart.sparklelines2.Enabled = false
					else
						task.wait(0.25)
					end
					if (workspace.CurrentCamera.CFrame.Position - v51.PrimaryPart.Position).Magnitude < 150 then
						if _G.Settings.Flash == true then
							local v_u_54 = v_u_7.Megumi.Mahoraga.ImpactFrames:Clone()
							v_u_54.Parent = game.Lighting
							task.delay(0.05, function()
								-- upvalues: (copy) v_u_54, (ref) v_u_9
								v_u_54.Contrast = 0
								v_u_54.Saturation = 64
								task.wait(0.05)
								v_u_54.Contrast = 8
								v_u_54.Saturation = -1
								task.wait(0.05)
								v_u_54.Contrast = -8
								task.wait(0.05)
								v_u_54:Destroy()
								v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
							end)
						else
							task.delay(0.2, function()
								-- upvalues: (ref) v_u_9
								v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
							end)
						end
					end
					for _, v_u_55 in v51.groundwavepart.impactframes["1"]:GetChildren() do
						v_u_55.Enabled = true
						task.delay(0.167, function()
							-- upvalues: (copy) v_u_55
							v_u_55.Enabled = false
						end)
					end
				end
			else
				return
			end
		end,
		["Interp"] = function(p56, p_u_57)
			-- upvalues: (ref) v_u_2, (ref) v_u_4, (ref) v_u_11, (ref) v_u_8
			local v_u_58 = p_u_57.CFrame
			local v_u_59 = tick()
			local v_u_60 = p_u_57:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_58, (copy) p_u_57, (ref) v_u_59
				v_u_58 = p_u_57.CFrame
				v_u_59 = tick()
			end)
			local v_u_61 = nil
			v_u_61 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_57, (ref) v_u_61, (copy) v_u_60, (ref) v_u_58, (ref) v_u_59
				if p_u_57.Parent then
					workspace:BulkMoveTo({ p_u_57 }, { v_u_58 + v_u_58.LookVector * (250 * (tick() - v_u_59)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_61:Disconnect()
					v_u_60:Disconnect()
				end
			end)
			local v62 = TweenInfo.new(0.7, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
			v_u_4:Create(p_u_57.slash.a, v62, {
				["Width1"] = 0
			}):Play()
			v_u_4:Create(p_u_57.slash.a2, v62, {
				["Width1"] = 0
			}):Play()
			v_u_4:Create(p_u_57.slash.b, v62, {
				["Width1"] = 0
			}):Play()
			v_u_4:Create(p_u_57.slash.b2, v62, {
				["Width1"] = 0
			}):Play()
			task.delay(0.5, function()
				-- upvalues: (copy) p_u_57
				for _, v63 in p_u_57:GetDescendants() do
					if not v63:IsA("ParticleEmitter") then
						continue
					end
					v63.Enabled = false
				end
			end)
			local v64 = p56:FindFirstChild("HumanoidRootPart")
			if v64 then
				v_u_11:PlaySound(v_u_8.Megumi.Mahoraga.WorldSlash.Swing, v64, game.SoundService.Effect)
				local v65 = nil
				for _, v66 in workspace.Effects:GetChildren() do
					if v66.Name ~= "WorldSlash" then
						continue
					end
					local v67 = v66:FindFirstChild("Char")
					if not v67 or v67.Value ~= p56 then
						continue
					end
					v65 = v66
				end
				if v65 then
					for _, v68 in v65:GetDescendants() do
						if not (v68:IsA("ParticleEmitter") or v68:IsA("Beam")) then
							continue
						end
						v68.Enabled = false
					end
					v65.groundwavepart.slash.slash1:Emit(8)
					v65.groundwavepart.slash.slash2:Emit(4)
					v65.groundwavepart.slash.slash3:Emit(8)
					v65.groundwavepart.slash.slash4:Emit(8)
				end
			else
				return
			end
		end,
		["WorldHit"] = function(p69, p70)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7
			local v71 = p69:FindFirstChild("HumanoidRootPart")
			if v71 then
				v_u_11:Flash(p69, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_8.Itadori.Dismantle.Slash, v71, game.SoundService.Effect)
				if p70 then
					v_u_11:PlaySound(v_u_8.Itadori.Dismantle.Explode, v71, game.SoundService.Effect)
					v_u_11:Bleed(p69)
					if v_u_5.Character == p69 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
						if _G.Settings.Flash ~= true then
							return
						end
						local v72 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
						v72.TintColor = Color3.new(1, 1, 1)
						v72.Parent = game.Lighting
						task.wait(0.04)
						v72.Brightness = 200
						v72.Contrast = -1000
						task.wait(0.04)
						v72:Destroy()
					end
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p74, ...)
		-- upvalues: (copy) v_u_73
		local v75 = v_u_73[p74]
		if v75 then
			v75(...)
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("AdaptationService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12