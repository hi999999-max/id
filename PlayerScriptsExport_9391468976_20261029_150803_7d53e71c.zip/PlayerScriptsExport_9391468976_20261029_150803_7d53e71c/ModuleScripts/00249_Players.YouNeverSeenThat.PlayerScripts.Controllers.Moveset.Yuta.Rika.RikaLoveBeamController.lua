-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Yuta.Rika.RikaLoveBeamController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v4 = game.ReplicatedStorage
local _ = v4.Animations
local v_u_5 = v4.Utils
local v_u_6 = v4.Sounds
local v_u_7 = require(v4.Modules.CameraShaker)
require(v4.Modules.BloodyZee)
local v_u_8 = require(v4.Modules.StaticLightning)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "RikaLoveBeamController"
})
local v_u_12 = Random.new()
local v_u_13 = workspace.CurrentCamera
local function v_u_33(p14, p15, p16) -- name: drawBeam
	local v17 = p14.BlackStart.Size.X
	local v18 = p16.X / 2
	local v19
	if p16.Z < 65 then
		v19 = 0.6923076923076923 * p16.Z
		v18 = 0.3076923076923077 * p16.Z
	else
		v19 = 45
	end
	local v20 = p16.Z - v19 - v18
	local v21 = math.max(v20, 0)
	p14.BlackStart.CFrame = p15 * CFrame.new(0, 0, -v19 / 2) * CFrame.Angles(-1.5707963267948966, 0, 0)
	local v22 = p14.BlackStart
	local v23 = p16.X
	local v24 = p16.Y
	v22.Size = Vector3.new(v23, v19, v24)
	p14.PinkStart.CFrame = p14.BlackStart.CFrame
	p14.PinkStart.Size = p14.BlackStart.Size * Vector3.new(0.875, 1, 0.875)
	p14.BlackMiddle.CFrame = p15 * CFrame.new(0, 0, -(v19 + v21 / 2)) * CFrame.Angles(-1.5707963267948966, 0, 0)
	local v25 = p14.BlackMiddle
	local v26 = p16.X
	local v27 = p16.Y
	v25.Size = Vector3.new(v26, v21, v27)
	p14.PinkMiddle.CFrame = p14.BlackMiddle.CFrame
	p14.PinkMiddle.Size = p14.BlackMiddle.Size * Vector3.new(0.875, 1, 0.875)
	p14.BlackEnd.CFrame = p15 * CFrame.new(0, 0, -(v19 + v21 + v18 / 2)) * CFrame.Angles(1.5707963267948966, 0, 0)
	local v28 = p14.BlackEnd
	local v29 = p16.X
	local v30 = p16.X
	v28.Size = Vector3.new(v29, v18, v30)
	p14.PinkEnd.CFrame = p14.BlackEnd.CFrame
	p14.PinkEnd.Size = p14.BlackEnd.Size * Vector3.new(0.875, 1, 0.875)
	for _, v31 in p14:GetDescendants() do
		if not v31:IsA("Beam") then
			continue
		end
		local v32 = v17 / v31.CurveSize0
		v31.CurveSize0 = p16.X / v32
	end
end
local function v_u_38(p34) -- name: shootSpec
	-- upvalues: (copy) v_u_5, (copy) v_u_3
	local v35 = v_u_5.Yuta.LoveBeam.BlackSpec:Clone()
	v35.CFrame = p34.PinkStart.CFrame * CFrame.new(0, -10, 0)
	v35.Parent = p34
	local v36 = p34.BlackMiddle.Size.X
	local v37 = p34.BlackMiddle.Size.Y
	v_u_3:Create(v35, TweenInfo.new(0.3), {
		["Size"] = Vector3.new(v36, 20, v36),
		["CFrame"] = v35.CFrame * CFrame.new(0, v37 / 2, 0)
	}):Play()
	task.wait(0.2)
	v_u_3:Create(v35, TweenInfo.new(0.3), {
		["Size"] = Vector3.new(v36, 0, v36),
		["CFrame"] = p34.PinkStart.CFrame * CFrame.new(0, v37, 0)
	}):Play()
	task.wait(0.3)
	v35:Destroy()
end
function v11.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_10, (copy) v_u_6, (copy) v_u_3, (copy) v_u_5, (copy) v_u_12, (copy) v_u_13, (copy) v_u_7, (copy) v_u_33, (copy) v_u_8, (copy) v_u_38, (copy) v_u_2
	local v_u_101 = {
		["ScaleTo"] = function(p39, p40)
			-- upvalues: (ref) v_u_10, (ref) v_u_6
			local v41 = p39:FindFirstChild("RootPart")
			if v41 then
				v_u_10:PlaySound(v_u_6.Yuta.LoveBeam.RikaMovement, v41, game.SoundService.Effect)
				local v42 = p39:GetScale()
				local v43 = tick()
				local v44 = p40 or 1.7
				repeat
					task.wait()
					local v45 = (tick() - v43) / 0.2
					p39:ScaleTo(v42 + math.clamp(v45, 0, 1) * (v44 - v42))
				until tick() - v43 >= 0.2
				p39:ScaleTo(v44)
			end
		end,
		["Charge"] = function(p46)
			-- upvalues: (ref) v_u_3, (ref) v_u_5, (ref) v_u_12
			v_u_3:Create(p46, TweenInfo.new(0.5), {
				["Size"] = Vector3.new(1.5, 1.5, 1.5)
			}):Play()
			v_u_3:Create(p46.Outline, TweenInfo.new(0.5), {
				["Size"] = Vector3.new(1.57, 1.57, 1.57)
			}):Play()
			p46.Attachment.Charge.Enabled = false
			p46.Attachment.Circles.Enabled = false
			local v47 = v_u_5.Yuta.LoveBeam.ChargeBallEffects.Attachment:Clone()
			v47.Parent = p46
			v47.EnergyBits1.Enabled = true
			task.wait(0.1)
			v47.EnergyBits2.Enabled = true
			v47.EnergyGlow1.Enabled = true
			task.wait(0.2)
			v47.EnergyBits3.Enabled = true
			v47.EnergyGlow2.Enabled = true
			task.wait(0.2)
			p46.Outline:Destroy()
			v_u_3:Create(p46, TweenInfo.new(0.1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, true), {
				["Size"] = Vector3.new(2.25, 2.25, 2.25)
			}):Play()
			task.wait(0.1)
			v_u_3:Create(p46, TweenInfo.new(0.1), {
				["Size"] = Vector3.new(3.25, 3.25, 3.25)
			}):Play()
			for _, v48 in v47:GetChildren() do
				v48.Enabled = true
			end
			local v49 = p46.CFrame
			repeat
				task.wait()
				p46.CFrame = v49 + v_u_12:NextUnitVector() * 0.3
			until not p46.Parent
		end,
		["StartBeamSound"] = function(p50)
			if p50 and p50.Parent then
				local v51 = p50.TrueLove
				v51:Clone().Parent = p50
				v51:Destroy()
				p50.TrueLove.EmitterSize = 100
				p50.TrueLove:Play()
			end
		end,
		["StartBeam"] = function(p_u_52, p53)
			-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_13, (ref) v_u_7, (ref) v_u_33, (ref) v_u_8, (ref) v_u_12, (ref) v_u_38, (ref) v_u_3, (ref) v_u_2
			local v_u_54 = p_u_52:GetAttribute("BeamStartCFrame")
			local v55 = p53:FindFirstChild("TrueLove")
			local v_u_56 = Instance.new("Model", workspace.Effects)
			v_u_56.Name = "WhiteHighlight"
			local v57 = Instance.new("Highlight", v_u_56)
			v57.OutlineTransparency = 1
			v57.FillTransparency = 0.2
			v57.FillColor = Color3.new(1, 1, 1)
			v57.Adornee = v_u_56
			v57.DepthMode = Enum.HighlightDepthMode.Occluded
			local v_u_58 = v_u_5.Yuta.LoveBeam.ChargeBall2:Clone()
			v_u_58.CFrame = v_u_54 * CFrame.new(0, 0, 3)
			v_u_58.Transparency = 1
			v_u_58.Parent = v57
			v_u_10:PlayParticles(v_u_58.Attachment1)
			local v59 = v_u_13.CFrame
			local v60 = v_u_54.Position - v59.Position
			if v60.Unit:Dot(v59.LookVector) >= 0.7 and v60.Magnitude < 70 then
				v_u_7.CurrentShaker:Shake(v_u_7.Presets.HeavyHit)
				if _G.Settings.Flash == true then
					local v61 = v_u_5.Itadori.DivergentFist.BlackFlashCC:Clone()
					v61.TintColor = Color3.new(1, 0.3, 1)
					v61.Parent = game.Lighting
					task.wait(0.04)
					v61.TintColor = Color3.new(1, 1, 1)
					task.wait(0.04)
					v61.Brightness = 200
					v61.Contrast = -1000
					task.wait(0.04)
					v61:Destroy()
				end
			else
				task.wait(0.12)
			end
			local v_u_62 = v_u_5.Yuta.LoveBeam.Beam:Clone()
			local v_u_63 = Instance.new("Part", workspace.Effects)
			v_u_63.CanCollide = false
			v_u_63.CanQuery = false
			v_u_63.CanTouch = false
			v_u_63.Transparency = 1
			v_u_63.CastShadow = false
			v_u_63.Anchored = true
			v_u_63.CFrame = v_u_62.BlackMiddle.CFrame
			if v55 then
				v55.Parent = v_u_63
				v55.RollOffMinDistance = 180
			end
			p53:Destroy()
			local v_u_64 = Instance.new("Vector3Value")
			v_u_64.Value = Vector3.new(30, 30, 180)
			v_u_33(v_u_62, v_u_54 * CFrame.new(0, 0, -5), (Vector3.new(30, 30, p_u_52:GetAttribute("BeamLength"))))
			v_u_62.Parent = workspace.Effects
			v_u_58.Transparency = 0
			local v_u_65 = true
			local v_u_66 = v_u_58.Position
			task.spawn(function()
				-- upvalues: (ref) v_u_8, (copy) v_u_58, (ref) v_u_12, (ref) v_u_65, (copy) v_u_56, (copy) v_u_66, (copy) v_u_62
				local v_u_67 = v_u_8.ThicknessFade(0.1, 0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.InOut)
				local v_u_68 = {
					{},
					{},
					{}
				}
				task.wait(0.06)
				local v69 = v_u_58.CFrame
				local v_u_70 = v69.Position
				for v_u_71, v_u_72 in v_u_68 do
					local v73 = v_u_12:NextUnitVector()
					local v_u_74 = v_u_70 + v69.LookVector * v_u_12:NextNumber(5, 30) + v73 * 20
					local v_u_75 = (v_u_70 + v_u_74) / 2 + v73 * 30
					task.spawn(function()
						-- upvalues: (ref) v_u_65, (ref) v_u_72, (copy) v_u_68, (copy) v_u_71, (ref) v_u_8, (ref) v_u_70, (copy) v_u_74, (copy) v_u_75, (ref) v_u_58, (copy) v_u_67, (ref) v_u_56, (ref) v_u_66, (ref) v_u_12
						for _ = 1, 3 do
							if not v_u_65 then
								break
							end
							v_u_72 = v_u_68[v_u_71]
							v_u_68[v_u_71] = v_u_8.CreateBolt({
								["Position1"] = v_u_70,
								["Position2"] = v_u_74,
								["CurveCenter"] = v_u_75,
								["Color"] = v_u_58.Color,
								["Thickness"] = v_u_67,
								["PartPool"] = v_u_72,
								["Parent"] = v_u_56
							})
							v_u_58.Position = v_u_66 + v_u_12:NextUnitVector() * 0.3
							v_u_70 = v_u_58.Position
							task.wait(0.02)
						end
					end)
				end
				if v_u_62.Parent and v_u_65 then
					break
				end
				v_u_56:Destroy()
			end)
			local v_u_76 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_5, (ref) v_u_13, (ref) v_u_54, (ref) v_u_7, (copy) p_u_52, (ref) v_u_76, (ref) v_u_12, (ref) v_u_33, (copy) v_u_62, (copy) v_u_64, (copy) v_u_63
				local v77 = v_u_5.Yuta.LoveBeam.CameraFX:Clone()
				local v78
				if (v_u_13.CFrame.Position - v_u_54.Position).Magnitude < 180 then
					v78 = v_u_7.CurrentShaker:ShakeSustain(v_u_7.Presets.HeavyHit)
				else
					v78 = nil
				end
				v_u_54 = p_u_52:GetAttribute("BeamStartCFrame")
				local v79 = v_u_76 and Vector3.new(1, 1, 0) * v_u_12:NextNumber(1, 5) or Vector3.new(0, 0, 0)
				local v80 = p_u_52
				v_u_33(v_u_62, v_u_54, v_u_64.Value * Vector3.new(1, 1, 0) + v79 + Vector3.new(0, 0, v80:GetAttribute("BeamLength")))
				v_u_63.CFrame = v_u_54
				local v81, v82 = v_u_62:GetBoundingBox()
				local v83 = v82 / 2
				local v84 = v81:PointToObjectSpace(v_u_13.CFrame.Position)
				local v85
				if v84.Z > v83.Z or v84.Z < -v83.Z then
					v85 = nil
				else
					v85 = (v84 * Vector3.new(1, 1, 0)).Magnitude <= v83.X and true or nil
				end
				if v85 then
					v77.Parent = game.Lighting
				else
					v77.Parent = nil
				end
				task.wait()
				if v_u_62.Parent then
					continue
				end
				if v78 then
					v78:StartFadeOut(0.5)
				end
				v77:Destroy()
			end)
			local v_u_86 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_38, (copy) v_u_62, (ref) v_u_86
				repeat
					task.spawn(v_u_38, v_u_62)
					task.wait(0.3)
				until not (v_u_62.Parent and v_u_86)
			end)
			v_u_3:Create(v_u_64, TweenInfo.new(0.3), {
				["Value"] = Vector3.new(60, 60, 180)
			}):Play()
			task.wait(0.3)
			v_u_3:Create(v_u_64, TweenInfo.new(0.1), {
				["Value"] = Vector3.new(40, 40, 180)
			}):Play()
			task.wait(0.1)
			v_u_3:Create(v_u_64, TweenInfo.new(1), {
				["Value"] = Vector3.new(30, 30, 180)
			}):Play()
			v_u_3:Create(v_u_62.PinkStart, TweenInfo.new(1), {
				["Color"] = Color3.fromRGB(255, 100, 255)
			}):Play()
			v_u_3:Create(v_u_62.PinkMiddle, TweenInfo.new(1), {
				["Color"] = Color3.fromRGB(255, 100, 255)
			}):Play()
			v_u_3:Create(v_u_62.PinkEnd, TweenInfo.new(1), {
				["Color"] = Color3.fromRGB(255, 100, 255)
			}):Play()
			local function v94() -- name: updateWidth
				-- upvalues: (copy) p_u_52, (ref) v_u_3, (copy) v_u_64
				local v87 = p_u_52:GetAttribute("Width")
				local v88 = v_u_3
				local v89 = v_u_64
				local v90 = TweenInfo.new(0.2)
				local v91 = {}
				local v92 = v87.X - 5
				local v93 = v87.Y - 5
				v91.Value = Vector3.new(v92, v93, 180)
				v88:Create(v89, v90, v91):Play()
			end
			v94()
			p_u_52:GetAttributeChangedSignal("Width"):Connect(v94)
			repeat
				task.wait()
			until not p_u_52.Parent
			v_u_86 = false
			v_u_3:Create(v_u_64, TweenInfo.new(0.5), {
				["Value"] = Vector3.new(0, 0, 180)
			}):Play()
			for _, v95 in v_u_62:GetDescendants() do
				if v95:IsA("Beam") then
					v_u_3:Create(v95, TweenInfo.new(0.25), {
						["Width0"] = 0,
						["Width1"] = 0
					}):Play()
				else
					if not v95:IsA("ParticleEmitter") then
						continue
					end
					v95.Enabled = false
				end
			end
			task.wait(0.25)
			v_u_65 = false
			v_u_76 = false
			task.wait(0.25)
			v_u_62:Destroy()
			v_u_2:AddItem(v_u_63, 10)
		end,
		["Hit"] = function(p96)
			-- upvalues: (ref) v_u_10
			v_u_10:Flash(p96, Color3.fromRGB(255, 170, 255))
		end,
		["Finisher"] = function(p97)
			-- upvalues: (ref) v_u_5
			local v98 = v_u_5.Yuta.LoveBeam.Smoke
			for _, v99 in p97:GetDescendants() do
				if v99:IsA("BasePart") or v99:IsA("Decal") then
					v99.Transparency = 1
				end
				if v99:IsA("BasePart") then
					v99.CollisionGroup = "NoPlayerCollision"
				end
				if v99.Name == "HumanoidRootPart" or v99.Parent ~= p97 then
					continue
				end
				local v100 = v98:Clone()
				v100.Parent = v99
				v100:Emit(20)
			end
		end
	}
	RikaLoveBeamService.Effects:Connect(function(p102, ...)
		-- upvalues: (copy) v_u_101
		local v103 = v_u_101[p102]
		if v103 then
			v103(...)
		end
	end)
end
function v11.KnitInit(_) -- name: KnitInit
	-- upvalues: (copy) v_u_1, (ref) v_u_9, (ref) v_u_10
	RikaLoveBeamService = v_u_1.GetService("RikaLoveBeamService")
	v_u_9 = v_u_1.GetController("HitboxController")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11