-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.FXController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game:GetService("CollectionService")
local v_u_6 = game.Players.LocalPlayer
local v_u_7 = game.ReplicatedStorage
local v_u_8 = v_u_7.Remotes
local v_u_9 = v_u_7.Utils
local v_u_10 = v_u_7.Sounds
local v_u_11 = require(v_u_7.Modules.BloodyZee)
local v12 = v_u_7.Sounds.Impact.Enviroment
local v_u_13 = {
	[Enum.Material.Brick] = { 1.3, v12.BrickImpact },
	[Enum.Material.Cobblestone] = { 1.2, v12.BrickImpact },
	[Enum.Material.Slate] = { 1.1, v12.BrickImpact },
	[Enum.Material.Glass] = { 0.2, v12.GlassImpact },
	[Enum.Material.Concrete] = { 0.8, v12.StoneImpact },
	[Enum.Material.Plastic] = { 1, v12.StoneImpact },
	[Enum.Material.SmoothPlastic] = { 1, v12.StoneImpact },
	[Enum.Material.Wood] = { 0.8, v12.WoodImpact },
	[Enum.Material.WoodPlanks] = { 0.75, v12.WoodImpact },
	[Enum.Material.Grass] = { 0.6, v12.GrassImpact },
	[Enum.Material.Sand] = { 0.5, v12.GrassImpact },
	[Enum.Material.Metal] = { 0.5, v12.MetalImpact },
	[Enum.Material.DiamondPlate] = { 0.5, v12.MetalImpact },
	[Enum.Material.Neon] = { 0.5, v12.NeonImpact }
}
local v_u_14 = v_u_1.CreateController({
	["Name"] = "FXController"
})
function v_u_14.PlaySound(_, p15, p16, p17, p18) -- name: PlaySound
	local v_u_19 = p15:Clone()
	v_u_19.Parent = p16
	v_u_19.SoundGroup = p17
	v_u_19:Play()
	if p15.PlayOnRemove ~= true then
		if not p18 then
			v_u_19.Ended:Once(function()
				-- upvalues: (copy) v_u_19
				v_u_19:Destroy()
			end)
			v_u_19.Loaded:Once(function()
				-- upvalues: (copy) v_u_19
				if not v_u_19.IsLoaded then
					v_u_19:Destroy()
				end
			end)
		end
		return v_u_19
	end
	v_u_19:Destroy()
end
function v_u_14.PlayParticles(_, p20) -- name: PlayParticles
	local v21 = p20:GetDescendants()
	table.insert(v21, p20)
	for _, v_u_22 in v21 do
		if not v_u_22:IsA("ParticleEmitter") then
			continue
		end
		local v23 = v_u_22:GetAttribute("EmitDelay")
		local function v24() -- name: emit
			-- upvalues: (copy) v_u_22
			v_u_22:Emit(v_u_22:GetAttribute("EmitCount"))
			if v_u_22:GetAttribute("EmitDuration") ~= 0 then
				v_u_22.Enabled = true
				task.delay(v_u_22:GetAttribute("EmitDuration"), function()
					-- upvalues: (ref) v_u_22
					v_u_22.Enabled = false
				end)
			end
		end
		if v23 and v23 ~= 0 then
			task.delay(v23, v24)
		else
			v24()
		end
	end
end
function v_u_14.ResizeParticle(_, p25, p26) -- name: ResizeParticle
	local v27 = {}
	for _, v28 in pairs(p25.Size.Keypoints) do
		local v29 = NumberSequenceKeypoint.new
		local v30 = v28.Time
		local v31 = v28.Value * p26
		local v32 = v28.Envelope * p26
		table.insert(v27, v29(v30, v31, v32))
	end
	p25.Size = NumberSequence.new(v27)
end
function v_u_14.PreloadMeshFlipbook(_, p33) -- name: PreloadMeshFlipbook
	local v34 = Instance.new("Part")
	v34.Transparency = 0.99
	v34.Size = Vector3.new(0.1, 0.1, 0.1)
	local v35 = Instance.new("Attachment", v34)
	local v36 = Instance.new("Attachment", workspace.CurrentCamera)
	v36.Position = Vector3.new(0, 0, 0.2)
	local v37 = Instance.new("RigidConstraint")
	v37.Attachment0 = v36
	v37.Attachment1 = v35
	v34.Parent = workspace.Effects
	for _, v38 in pairs(p33) do
		local v39 = Instance.new("Texture")
		v39.Texture = v38
		v39.Parent = v34
	end
	return v34
end
function v_u_14.PlayMeshFlipbook(_, p_u_40, p_u_41, p_u_42, p_u_43) -- name: PlayMeshFlipbook
	-- upvalues: (copy) v_u_2
	local v_u_44 = p_u_41 / #p_u_42
	local v_u_45 = 0
	local v_u_46 = p_u_40:IsA("MeshPart") and "TextureID" or (p_u_40:IsA("SpecialMesh") and "TextureId" or nil)
	local v_u_47 = nil
	v_u_47 = v_u_2.Heartbeat:Connect(function(p48)
		-- upvalues: (ref) v_u_45, (copy) p_u_41, (copy) v_u_44, (copy) p_u_40, (ref) v_u_46, (copy) p_u_42, (ref) v_u_47, (copy) p_u_43
		local v49 = v_u_45 + p48
		local v50 = p_u_41
		v_u_45 = math.min(v49, v50)
		local v51 = v_u_45 / v_u_44
		p_u_40[v_u_46] = p_u_42[math.round(v51)] or p_u_42[1]
		if v_u_45 == p_u_41 then
			v_u_47:Disconnect()
			if p_u_43 then
				p_u_43()
			end
		end
	end)
end
function v_u_14.Flash(_, p52, p53, p54) -- name: Flash
	-- upvalues: (copy) v_u_9, (copy) v_u_3, (copy) v_u_4
	local v55 = workspace.CurrentCamera.CFrame.Position
	local v56 = p52.PrimaryPart.Position
	local v57 = v55.X - v56.X
	local v58 = math.abs(v57)
	local v59 = v55.Y - v56.Y
	local v60 = v58 + math.abs(v59)
	local v61 = v55.Z - v56.Z
	if v60 + math.abs(v61) <= 200 then
		local v62 = v_u_9.Damage.HitGlow:Clone()
		if p52:GetScale() ~= 1 then
			v62:ScaleTo(p52:GetScale())
		end
		v62.Parent = workspace.Effects
		v_u_3:AddItem(v62, p54 or 0.15)
		for _, v63 in v62:GetChildren() do
			local v64 = p52:FindFirstChild(v63.Name)
			if v64 then
				local v65 = Instance.new("Weld", v63)
				v65.Part0 = v63
				v65.Part1 = v64
			end
			v63.CanQuery = false
			v63.Color = p53
			if not p54 then
				continue
			end
			v_u_4:Create(v63, TweenInfo.new(p54), {
				["Transparency"] = 1
			}):Play()
		end
		return v62
	end
end
function v_u_14.ArmFlash(_, p66, p67, p68) -- name: ArmFlash
	-- upvalues: (copy) v_u_9, (copy) v_u_4, (copy) v_u_3
	local v69 = workspace.CurrentCamera.CFrame.Position
	local v70 = p66.Position
	local v71 = v69.X - v70.X
	local v72 = math.abs(v71)
	local v73 = v69.Y - v70.Y
	local v74 = v72 + math.abs(v73)
	local v75 = v69.Z - v70.Z
	if v74 + math.abs(v75) <= 200 then
		local v_u_76 = v_u_9.Damage.CombatTrail:Clone()
		v_u_76.Size = p66.Size * 1.1
		v_u_76.Color = p67
		v_u_76.Trail.Color = ColorSequence.new(p67)
		v_u_76.Weld.Part0 = p66
		v_u_76.Parent = workspace.Effects
		task.delay(p68 or 0.2, function()
			-- upvalues: (copy) v_u_76, (ref) v_u_4, (ref) v_u_3
			if v_u_76 and v_u_76.Parent then
				v_u_76.Trail.Enabled = false
				v_u_4:Create(v_u_76, TweenInfo.new(0.1), {
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v_u_76, 0.2)
			end
		end)
		return v_u_76
	end
end
function v_u_14.Notification(_, p77, p78, p79) -- name: Notification
	-- upvalues: (copy) v_u_6, (copy) v_u_3, (copy) v_u_4
	local v80 = p79 or 3
	local v81 = v_u_6.PlayerGui:WaitForChild("Menus")
	local v82 = v81.Preset.Notification:Clone()
	v82.Noti.Text = p77
	v82.Noti.UIGradient.Color = ColorSequence.new({
		ColorSequenceKeypoint.new(0, p78),
		ColorSequenceKeypoint.new(0.4, p78),
		ColorSequenceKeypoint.new(0.45, Color3.new(1, 1, 1)),
		ColorSequenceKeypoint.new(0.55, Color3.new(1, 1, 1)),
		ColorSequenceKeypoint.new(0.6, p78),
		ColorSequenceKeypoint.new(1, p78)
	})
	v82.Parent = v81.Notif
	v_u_3:AddItem(v82, v80 + 0.5)
	local v83 = v82.Noti
	v_u_4:Create(v83, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		["Position"] = nil,
		["TextTransparency"] = 0,
		["Position"] = UDim2.new(0, 0, 0, 0)
	}):Play()
	v_u_4:Create(v83.UIStroke, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		["Transparency"] = 0
	}):Play()
	v_u_4:Create(v83.UIGradient, TweenInfo.new(2), {
		["Offset"] = Vector2.new(1, 0)
	}):Play()
	v_u_4:Create(v83.UIStroke.UIGradient, TweenInfo.new(3.5), {
		["Offset"] = Vector2.new(1, 0)
	}):Play()
	task.wait(v80)
	v_u_4:Create(v83, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
		["Position"] = nil,
		["TextTransparency"] = 1,
		["Position"] = UDim2.new(0, 0, 0, -35)
	}):Play()
	v_u_4:Create(v83.UIStroke, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
		["Transparency"] = 1
	}):Play()
end
function v_u_14.DustBreak(_, p84, p85, p86, p87, p88, p89, p90) -- name: DustBreak
	-- upvalues: (copy) v_u_9, (copy) v_u_4, (copy) v_u_3
	local v91 = workspace.CurrentCamera.CFrame.Position
	local v92 = v91.X - p84.X
	local v93 = math.abs(v92)
	local v94 = v91.Y - p84.Y
	local v95 = v93 + math.abs(v94)
	local v96 = v91.Z - p84.Z
	if v95 + math.abs(v96) > 200 then
		return
	elseif _G.Settings.DesPHY then
		local v97 = CFrame.new(p84, p84 + p85)
		for _ = 1, p87 do
			local v98 = (v97 * CFrame.Angles(0, 0, math.random(0, 3.141592653589793)) * CFrame.new(math.random(0, p86 * 10) / 10, 0, 0)).Position
			local v99 = workspace:Raycast(v98, v97.LookVector * -(p90 or 8), _G.MapParams)
			if not v99 then
				continue
			end
			local v_u_100 = v_u_9.Damage.DebreeRef:Clone()
			v_u_100.Color = v99.Instance.Color
			v_u_100.Material = v99.Instance.Material
			v_u_100.Transparency = v99.Instance.Transparency
			local v101 = math.random(p88 * 10, p89 * 10) / 10
			local v102 = math.random(p88 * 10, p89 * 10) / 10
			local v103 = math.random(p88 * 10, p89 * 10) / 10
			v_u_100.Size = Vector3.new(v101, v102, v103)
			v_u_100.Position = v99.Position
			v_u_100.CollisionGroup = "Effects"
			v_u_100.Anchored = false
			local v104 = math.random(-20, 20)
			local v105 = math.random(20, 40)
			local v106 = math.random
			v_u_100.Velocity = Vector3.new(v104, v105, v106(-20, 20))
			local v107 = math.random(-200, 200)
			local v108 = math.random(-200, 200)
			local v109 = math.random
			v_u_100.RotVelocity = Vector3.new(v107, v108, v109(-200, 200))
			v_u_100.Parent = workspace.Effects
			task.delay(3, function()
				-- upvalues: (ref) v_u_4, (copy) v_u_100, (ref) v_u_3
				v_u_4:Create(v_u_100, TweenInfo.new(1), {
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v_u_100, 1)
			end)
		end
	end
end
function v_u_14.DustTrail(_, p110, p111, p_u_112) -- name: DustTrail
	-- upvalues: (copy) v_u_9, (copy) v_u_3, (copy) v_u_4, (copy) v_u_2
	local v113 = workspace.CurrentCamera.CFrame.Position
	local v114 = p110.PrimaryPart.Position
	local v115 = v113.X - v114.X
	local v116 = math.abs(v115)
	local v117 = v113.Y - v114.Y
	local v118 = v116 + math.abs(v117)
	local v119 = v113.Z - v114.Z
	if v118 + math.abs(v119) <= 200 then
		local v_u_120 = p110.HumanoidRootPart
		if v_u_120 then
			local v_u_121 = v_u_9.Misc.SmokeTrail:Clone()
			v_u_121.Parent = workspace.Effects
			v_u_121.CFrame = v_u_120.CFrame * (p_u_112 or CFrame.new())
			v_u_3:AddItem(v_u_121, p111 + 0.6)
			if p_u_112 then
				v_u_121.Dash.Smoke.Enabled = true
				v_u_4:Create(v_u_121.Dash.Smoke, TweenInfo.new(p111), {
					["Rate"] = 0
				}):Play()
				local v122 = workspace
				local v123 = v_u_120.Position
				local v124 = -v_u_120.Size.Y * 1.6
				local v125 = v122:Raycast(v123, Vector3.new(0, v124, 0), _G.MapParams)
				if v125 then
					v_u_121.Position = v125.Position
					v_u_121.Dash.Smoke:Emit(15)
				end
			end
			local v_u_126 = nil
			local v_u_131 = v_u_2.RenderStepped:Connect(function()
				-- upvalues: (copy) v_u_121, (copy) v_u_120, (copy) p_u_112, (ref) v_u_126
				if v_u_121 and v_u_121.Parent then
					local v127 = workspace
					local v128 = v_u_120.Position
					local v129 = -v_u_120.Size.Y * 1.6
					local v130 = v127:Raycast(v128, Vector3.new(0, v129, 0), _G.MapParams)
					if v130 then
						if p_u_112 then
							v_u_121.Dash.Smoke.Enabled = true
						end
						v_u_121.CFrame = v_u_120.CFrame * (p_u_112 or CFrame.new()) - v_u_120.Position + v130.Position
						v_u_121.Velocity = v_u_120.Velocity
						if not v_u_126 then
							v_u_126 = v_u_121.Smoke
							v_u_126.Color = ColorSequence.new(v130.Instance.Color)
							v_u_126.Enabled = true
							return
						end
						if v_u_126.Color.Keypoints[1].Value ~= v130.Instance.Color then
							v_u_126.Enabled = false
							v_u_126 = v_u_126:Clone()
							v_u_126.Color = ColorSequence.new(v130.Instance.Color)
							v_u_126.Enabled = true
							v_u_126.Parent = v_u_121
							return
						end
					else
						v_u_121.Dash.Smoke.Enabled = false
						if v_u_126 then
							v_u_126.Enabled = false
						end
					end
				end
			end)
			task.delay(p111, function()
				-- upvalues: (copy) v_u_131, (copy) v_u_121, (ref) v_u_126
				v_u_131:Disconnect()
				if v_u_121 and v_u_121.Parent then
					if v_u_126 then
						v_u_126.Enabled = false
					end
					v_u_121.Dash.Smoke.Enabled = false
				end
			end)
			return v_u_121
		end
	end
end
function v_u_14.Bleed(_, p_u_132) -- name: Bleed
	-- upvalues: (copy) v_u_9, (copy) v_u_11
	if _G.Settings.Gore == true then
		for _, v133 in v_u_9.Damage.Explode:GetDescendants() do
			if not v133:IsA("Attachment") then
				continue
			end
			v133:Clone().Parent = p_u_132:FindFirstChild(v133.Parent.Name)
		end
		if not p_u_132:GetAttribute("Bleeding") then
			p_u_132:SetAttribute("Bleeding", true)
			task.spawn(function()
				-- upvalues: (ref) v_u_11, (copy) p_u_132
				repeat
					v_u_11:Blood(p_u_132.Torso.CFrame, 50, 180, 180)
					task.wait(0.1)
				until not p_u_132.Parent
			end)
		end
	else
		return
	end
end
function v_u_14.Burn(_, p134) -- name: Burn
	-- upvalues: (copy) v_u_9
	for _, v135 in p134:GetChildren() do
		if v135:IsA("BasePart") then
			v135.Color = Color3.new(0.1, 0.1, 0.1)
			v_u_9.Damage.LegBurn.Smoke:Clone().Parent = v135
		elseif v135:IsA("Shirt") or (v135:IsA("Pants") or v135:IsA("TShirt")) then
			v135.Color3 = Color3.new(0.1, 0.1, 0.1)
		else
			if not v135:IsA("Accessory") then
				continue
			end
			local v136 = v135:FindFirstChild("Handle", true)
			v136.Color = Color3.new(0.1, 0.1, 0.1)
			v136:FindFirstChildWhichIsA("SpecialMesh").TextureId = ""
		end
	end
end
function v_u_14.DomainMapFade(_, _, _, _) -- name: DomainMapFade end
function v_u_14.DomainBurst(p137, p138) -- name: DomainBurst
	-- upvalues: (copy) v_u_9, (copy) v_u_4, (copy) v_u_3, (copy) v_u_7
	local v139 = v_u_9.DomainBurst:Clone()
	v139.Position = p138.Position
	v139.Parent = workspace.Effects
	v_u_4:Create(v139, TweenInfo.new(0.3), {
		["Size"] = Vector3.new(75, 75, 75),
		["Transparency"] = 1
	}):Play()
	v139.Attachment.Spark:Emit(1)
	v_u_3:AddItem(v139, 0.4)
	p137:PlaySound(v_u_7.Sounds.Misc.Domain.DomainOpen, p138, game.SoundService.Effect)
end
local v_u_140 = nil
local v_u_141 = {
	[0] = 0.5,
	[1] = 0.3,
	[2] = 0.7
}
for _, v142 in v_u_7.Animations:GetDescendants() do
	if v142.Name ~= "DomainWarn" then
		continue
	end
	v_u_9.DomainWarn.Panel.Viewport.Display.Humanoid:LoadAnimation(v142)
end
function v_u_14.ApplyCopyOutfit(_, p143, p144) -- name: ApplyCopyOutfit
	-- upvalues: (copy) v_u_9
	p144:ScaleTo(p143:GetScale())
	local v145 = {
		"Head",
		"Left Arm",
		"Left Leg",
		"Right Arm",
		"Right Leg",
		"Torso"
	}
	for _, v146 in p143:GetChildren() do
		if v146:IsA("Shirt") or (v146:IsA("TShirt") or (v146:IsA("Pants") or v146:IsA("BodyColors"))) then
			v146:Clone().Parent = p144
		elseif v146:IsA("Accessory") then
			local v147 = v146:Clone()
			v147.Parent = p144
			local v148 = v147:FindFirstChild("AccessoryWeld", true)
			v148.Part1 = p144:FindFirstChild(v148.Part1.Name)
		else
			if not v146:IsA("CharacterMesh") then
				continue
			end
			v146:Clone().Parent = p144
		end
	end
	if p143.Head:FindFirstChild("Mesh") then
		p144.Head.Mesh:Destroy()
		p143.Head.Mesh:Clone().Parent = p144.Head
	end
	p144:ScaleTo(1)
	local v149 = p143.Head:FindFirstChild("face")
	if v149 then
		p144.Head.face.Texture = v149.Texture
	end
	if p143:FindFirstChild("Outfit") then
		local v150 = v_u_9.Megumi.Mahoraga.Mahoraga.Outfit:Clone()
		v150.Head.Beard:Destroy()
		v150.Head.Hat:Destroy()
		v150:ScaleTo(0.6666666666666666)
		for _, v151 in v150:GetDescendants() do
			if not (v151:IsA("Weld") or v151:IsA("Motor6D")) then
				continue
			end
			if table.find(v145, v151.Part0.Name) then
				v151.Part0 = p144:FindFirstChild(v151.Part0.Name)
			end
			if not table.find(v145, v151.Part1.Name) then
				continue
			end
			v151.Part1 = p144:FindFirstChild(v151.Part1.Name)
		end
		v150.Parent = p144
	end
	if p144["Left Arm"]:FindFirstChild("FingersL") then
		for _, v152 in p144["Left Arm"].FingersL:GetChildren() do
			if not v152:IsA("BasePart") then
				continue
			end
			v152.Color = p143["Left Arm"].Color
		end
		for _, v153 in p144["Right Arm"].FingersR:GetChildren() do
			if not v153:IsA("BasePart") then
				continue
			end
			v153.Color = p143["Right Arm"].Color
		end
	end
end
function v_u_14.WorldModelChar(_, p_u_154, p_u_155) -- name: WorldModelChar
	-- upvalues: (copy) v_u_2
	local v156 = p_u_154:Clone()
	local v_u_157 = Instance.new("WorldModel")
	for _, v158 in v156:GetChildren() do
		v158.Parent = v_u_157
	end
	v_u_157.PrimaryPart = v_u_157.Humanoid.RootPart
	for _, v159 in v_u_157:GetDescendants() do
		if not (v159:IsA("Sound") or v159:IsA("Script")) then
			continue
		end
		v159:Destroy()
	end
	v156:Destroy()
	v_u_157.Parent = p_u_155
	for _, v160 in v_u_157:GetChildren() do
		if not v160:IsA("BasePart") then
			continue
		end
		v160.Anchored = true
	end
	local v_u_161 = nil
	v_u_161 = v_u_2.Stepped:Connect(function()
		-- upvalues: (copy) p_u_154, (copy) p_u_155, (ref) v_u_161, (copy) v_u_157
		if p_u_154.Parent and p_u_155.Parent then
			for _, v162 in v_u_157:GetChildren() do
				if not v162:IsA("BasePart") then
					continue
				end
				local v163 = p_u_154:FindFirstChild(v162.Name)
				if not v163 then
					continue
				end
				v162.CFrame = v163.CFrame
			end
		else
			v_u_161:Disconnect()
			v_u_157:Destroy()
		end
	end)
	return v_u_157
end
function v_u_14.Domain(p_u_164, p_u_165, p166) -- name: Domain
	-- upvalues: (copy) v_u_9, (copy) v_u_6, (copy) v_u_4, (copy) v_u_141, (copy) v_u_3
	local v_u_167 = v_u_9.DomainWarn:Clone()
	v_u_167.Parent = v_u_6.PlayerGui
	local v_u_168 = v_u_167.Panel.Viewport.Display
	pcall(function()
		-- upvalues: (copy) p_u_164, (copy) p_u_165, (copy) v_u_168
		p_u_164:ApplyCopyOutfit(p_u_165, v_u_168)
	end)
	local v169 = Instance.new("Camera", v_u_167.Panel)
	v169.FieldOfView = 40
	v169.CFrame = v_u_168.HumanoidRootPart.CFrame * CFrame.new(0, 1, -5) * CFrame.Angles(0, 3.141592653589793, 0)
	v_u_167.Panel.Viewport.CurrentCamera = v169
	p166(v_u_167, v_u_168)
	v_u_4:Create(v_u_167.FlashText, TweenInfo.new(1.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
		["Size"] = UDim2.new(1.5, 0, 0.43, 0)
	}):Play()
	task.delay(0.625, function()
		-- upvalues: (ref) v_u_4, (copy) v_u_167
		v_u_4:Create(v_u_167.FlashText.Text1, TweenInfo.new(0.625), {
			["TextTransparency"] = 1
		}):Play()
		v_u_4:Create(v_u_167.FlashText.Text1.UIStroke, TweenInfo.new(0.625), {
			["Transparency"] = 1
		}):Play()
		v_u_4:Create(v_u_167.FlashText.Text2, TweenInfo.new(0.625), {
			["TextTransparency"] = 1
		}):Play()
		v_u_4:Create(v_u_167.FlashText.Text2.UIStroke, TweenInfo.new(0.625), {
			["Transparency"] = 1
		}):Play()
	end)
	local v170 = 0
	for _, v171 in v_u_6.PlayerGui:GetChildren() do
		if v171.Name ~= "DomainWarn" or (v171 == v_u_167 or v171:GetAttribute("Order") < v170) then
			continue
		end
		v170 = v171:GetAttribute("Order")
	end
	local v172 = v170 + 1
	local v173 = UDim2.new(1, 0, 0.35, 0)
	v_u_167:SetAttribute("Order", v172)
	if v172 <= 1 or v172 > 3 then
		local v174 = UDim2.new(0.5, 0, v_u_141[v172 % 3], 0)
		for _, v175 in v_u_167:GetChildren() do
			v_u_4:Create(v175, TweenInfo.new(1.25, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
				["Position"] = v174
			}):Play()
		end
	elseif v172 == 2 then
		for _, v176 in v_u_6.PlayerGui:GetChildren() do
			if v176.Name ~= "DomainWarn" or (v176 == v_u_167 or v176:GetAttribute("Order") ~= 1) then
				continue
			end
			for _, v177 in v176:GetChildren() do
				local v178 = UDim2.new(0.2, 0, 0.5, 0)
				local v179 = TweenInfo.new(1.25, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
				v_u_4:Create(v177, v179, {
					["Position"] = nil,
					["Rotation"] = -100,
					["Position"] = v178
				}):Play()
				if v177.Name == "Panel" then
					v_u_4:Create(v177.Viewport, v179, {
						["Rotation"] = 100,
						["Size"] = nil,
						["Size"] = v173
					}):Play()
					if not v177:FindFirstChild("ImageLabel") then
						continue
					end
					v_u_4:Create(v177.ImageLabel, v179, {
						["Rotation"] = 100
					}):Play()
				else
					if v177.Name ~= "FlashText" then
						continue
					end
					v_u_4:Create(v177.Text1, v179, {
						["Rotation"] = 100
					}):Play()
					v_u_4:Create(v177.Text2, v179, {
						["Rotation"] = 100
					}):Play()
				end
			end
		end
		for _, v180 in v_u_167:GetChildren() do
			local v181 = UDim2.new(0.8, 0, 0.5, 0)
			local v182 = TweenInfo.new(1.25, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
			v_u_4:Create(v180, v182, {
				["Position"] = nil,
				["Rotation"] = -80,
				["Position"] = v181
			}):Play()
			if v180.Name == "Panel" then
				v_u_4:Create(v180.Viewport, v182, {
					["Rotation"] = 80,
					["Size"] = nil,
					["Size"] = v173
				}):Play()
				if not v180:FindFirstChild("ImageLabel") then
					continue
				end
				v_u_4:Create(v180.ImageLabel, v182, {
					["Rotation"] = 80
				}):Play()
			else
				if v180.Name ~= "FlashText" then
					continue
				end
				v_u_4:Create(v180.Text1, v182, {
					["Rotation"] = 80
				}):Play()
				v_u_4:Create(v180.Text2, v182, {
					["Rotation"] = 80
				}):Play()
			end
		end
	elseif v172 == 3 then
		for _, v183 in v_u_167:GetChildren() do
			local v184 = UDim2.new(0.5, 0, 0.5, 0)
			local v185 = TweenInfo.new(1.25, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
			v183.Rotation = -70
			v_u_4:Create(v183, v185, {
				["Position"] = nil,
				["Rotation"] = -90,
				["Position"] = v184
			}):Play()
			if v183.Name == "Panel" then
				v183.Viewport.Rotation = 70
				v_u_4:Create(v183.Viewport, v185, {
					["Rotation"] = 90,
					["Size"] = nil,
					["Size"] = v173
				}):Play()
				if not v183:FindFirstChild("ImageLabel") then
					continue
				end
				v183.ImageLabel.Rotation = 70
				v_u_4:Create(v183.ImageLabel, v185, {
					["Rotation"] = 90
				}):Play()
			else
				if v183.Name ~= "FlashText" then
					continue
				end
				v183.Text1.Rotation = 70
				v183.Text2.Rotation = 70
				v_u_4:Create(v183.Text1, v185, {
					["Rotation"] = 90
				}):Play()
				v_u_4:Create(v183.Text2, v185, {
					["Rotation"] = 90
				}):Play()
			end
		end
	end
	v_u_4:Create(v_u_167.Panel, TweenInfo.new(0.625, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
		["Size"] = UDim2.new(1.5, 0, 0.4, 0)
	}):Play()
	v_u_4:Create(v_u_167.PanelBack, TweenInfo.new(0.625, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
		["Size"] = UDim2.new(1.5, 0, 0.43, 0)
	}):Play()
	task.wait(0.625)
	v_u_4:Create(v_u_167.Panel, TweenInfo.new(0.625, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
		["Size"] = UDim2.new(1.5, 0, 0, 0)
	}):Play()
	v_u_4:Create(v_u_167.PanelBack, TweenInfo.new(0.625, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
		["Size"] = UDim2.new(1.5, 0, 0.03, 0)
	}):Play()
	v_u_3:AddItem(v_u_167, 0.625)
end
function v_u_14.DebreeSound(p186, p187) -- name: DebreeSound
	-- upvalues: (copy) v_u_13
	local v188 = workspace.CurrentCamera.CFrame.Position
	local v189 = p187.Position
	local v190 = v188.X - v189.X
	local v191 = math.abs(v190)
	local v192 = v188.Y - v189.Y
	local v193 = v191 + math.abs(v192)
	local v194 = v188.Z - v189.Z
	if v193 + math.abs(v194) <= 300 then
		local v195 = v_u_13[p187.Material]
		if v195 then
			local v196 = v195[2]:GetChildren()
			p186:PlaySound(v196[math.random(1, #v196)], p187, game.SoundService.Effect)
		end
	end
end
function v_u_14.ColorSeqLerpVec(_, p_u_197, p_u_198, p_u_199, p200) -- name: ColorSeqLerpVec
	-- upvalues: (copy) v_u_2
	local v_u_201 = p200 or 1
	local function v_u_217(p202, p203) -- name: evalColorSequence
		if p203 == 0 then
			local v204 = p202.Keypoints[#p202.Keypoints].Value.R
			local v205 = p202.Keypoints[#p202.Keypoints].Value.G
			local v206 = p202.Keypoints[#p202.Keypoints].Value.B
			return vector.create(v204, v205, v206)
		end
		if p203 == 1 then
			local v207 = p202.Keypoints[#p202.Keypoints].Value.R
			local v208 = p202.Keypoints[#p202.Keypoints].Value.G
			local v209 = p202.Keypoints[#p202.Keypoints].Value.B
			return vector.create(v207, v208, v209)
		end
		for v210 = 1, #p202.Keypoints - 1 do
			local v211 = p202.Keypoints[v210]
			local v212 = p202.Keypoints[v210 + 1]
			if v211.Time > p203 or p203 >= v212.Time then
				continue
			end
			local v213 = (p203 - v211.Time) / (v212.Time - v211.Time)
			local v214 = (v212.Value.R - v211.Value.R) * v213 + v211.Value.R
			local v215 = (v212.Value.G - v211.Value.G) * v213 + v211.Value.G
			local v216 = (v212.Value.B - v211.Value.B) * v213 + v211.Value.B
			return vector.create(v214, v215, v216)
		end
	end
	local v_u_218 = time()
	local v_u_219 = nil
	v_u_219 = v_u_2.PreRender:Connect(function(_)
		-- upvalues: (copy) v_u_217, (copy) p_u_198, (copy) v_u_218, (copy) p_u_199, (copy) p_u_197, (ref) v_u_201, (ref) v_u_219
		local v220 = v_u_217
		local v221 = p_u_198
		local v222 = (time() - v_u_218) / p_u_199
		p_u_197.VertexColor = v220(v221, (math.clamp(v222, 0, 1))) * v_u_201
		if p_u_199 <= time() - v_u_218 then
			v_u_219:Disconnect()
		end
	end)
end
function v_u_14.ColorSeqLerpc(_, p_u_223, p_u_224, p_u_225, p226) -- name: ColorSeqLerpc
	-- upvalues: (copy) v_u_2
	local v_u_227 = p226 or 1
	local function v_u_234(p228, p229) -- name: evalColorSequence
		if p229 == 0 then
			return p228.Keypoints[#p228.Keypoints].Value
		end
		if p229 == 1 then
			return p228.Keypoints[#p228.Keypoints].Value
		end
		for v230 = 1, #p228.Keypoints - 1 do
			local v231 = p228.Keypoints[v230]
			local v232 = p228.Keypoints[v230 + 1]
			if v231.Time > p229 or p229 >= v232.Time then
				continue
			end
			local v233 = (p229 - v231.Time) / (v232.Time - v231.Time)
			return Color3.new((v232.Value.R - v231.Value.R) * v233 + v231.Value.R, (v232.Value.G - v231.Value.G) * v233 + v231.Value.G, (v232.Value.B - v231.Value.B) * v233 + v231.Value.B)
		end
	end
	local v_u_235 = time()
	local v_u_236 = nil
	v_u_236 = v_u_2.PreRender:Connect(function(_)
		-- upvalues: (copy) v_u_234, (copy) p_u_224, (copy) v_u_235, (copy) p_u_225, (copy) p_u_223, (ref) v_u_227, (ref) v_u_236
		local v237 = v_u_234
		local v238 = p_u_224
		local v239 = (time() - v_u_235) / p_u_225
		p_u_223.Color = v237(v238, (math.clamp(v239, 0, 1))) * v_u_227
		if p_u_225 <= time() - v_u_235 then
			v_u_236:Disconnect()
		end
	end)
end
function v_u_14.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_140, (copy) v_u_6, (copy) v_u_2, (copy) v_u_4, (copy) v_u_5, (copy) v_u_8, (copy) v_u_14, (copy) v_u_10
	v_u_140.CFix:Connect(function(p240)
		-- upvalues: (ref) v_u_6
		local v241 = v_u_6.Character
		if v241 then
			local v242 = v_u_6.PlayerGui:FindFirstChild("Freecam")
			if v242 then
				v242:SetAttribute("ow", workspace.CurrentCamera.CFrame.Position + p240)
			end
			for _, v243 in v241:GetDescendants() do
				if not v243:IsA("BodyPosition") and (not v243:IsA("AlignPosition") or v243.Mode ~= Enum.PositionAlignmentMode.OneAttachment) then
					continue
				end
				v243.Position = v243.Position + p240
			end
		end
	end)
	local v_u_244 = false
	local v_u_245 = v_u_6.PlayerGui:WaitForChild("DomainFade").DomainFade
	v_u_2.RenderStepped:Connect(function(p246)
		-- upvalues: (ref) v_u_6, (ref) v_u_244, (copy) v_u_245, (ref) v_u_4, (ref) v_u_5
		local v247 = workspace.CurrentCamera.CFrame.Position
		local v248 = nil
		for _, v249 in workspace.Domains:GetChildren() do
			if not v249:GetAttribute("Health") or (not v249:GetAttribute("Fade") or (v249.Position - v247).Magnitude >= v249.Size.Y / 2) then
				continue
			end
			v248 = v249
		end
		local v250 = nil
		local v251 = v_u_6.Character
		if v251 then
			v251 = v_u_6.Character.Parent
		end
		if v251 and v251:FindFirstChild("Info") then
			v250 = v251.Info:FindFirstChild("DomainTag")
		end
		if v248 and (not v250 and v_u_244 == false) then
			v_u_244 = true
			v_u_245.BackgroundColor3 = v248.Color
			v_u_4:Create(v_u_245, TweenInfo.new(0), {
				["BackgroundTransparency"] = 0
			}):Play()
		elseif not v248 and v_u_244 == true then
			v_u_244 = false
			v_u_4:Create(v_u_245, TweenInfo.new(0.2), {
				["BackgroundTransparency"] = 1
			}):Play()
		end
		if workspace:GetAttribute("CC1") then
			if p246 > 0.16666666666666666 then
				_G.Lag = true
				local v252 = v_u_5:GetTagged("C_VFX")
				if #v252 > 300 then
					for v253 = 1, #v252 - 300 do
						if not v252[v253] then
							continue
						end
						v252[v253]:Destroy()
					end
					return
				end
			else
				_G.Lag = false
			end
		end
	end)
	v_u_8.Message.OnClientEvent:Connect(function(p254, p255)
		-- upvalues: (ref) v_u_14, (ref) v_u_10
		game.TextChatService.TextChannels.RBXGeneral:DisplaySystemMessage(p254)
		if p255 then
			v_u_14:PlaySound(v_u_10.Misc.UI.Click, workspace, game.SoundService.Effect)
		end
	end)
	pcall(function()
		local v256 = Instance.new("Humanoid")
		v256.Parent = workspace.Effects
		local v257 = next
		local v258, v259 = game:GetService("ReplicatedStorage").Utils.Preload:GetChildren()
		for _, v260 in v257, v258, v259 do
			if not v260:IsA("Animation") then
				continue
			end
			local v261 = v256.LoadAnimation
			pcall(v261, v256, v260)
		end
		task.delay(10, v256.Destroy, v256)
	end)
end
function v_u_14.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_140, (copy) v_u_1
	v_u_140 = v_u_1.GetService("DomainService")
end
return v_u_14