-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Toji.SSK.DebilitateController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("Debris")
game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game:GetService("SoundService")
game:GetService("UserInputService")
local v_u_6 = workspace.CurrentCamera
local v_u_7 = game.Players.LocalPlayer
local v8 = game.ReplicatedStorage
local _ = v8.Animations
local v_u_9 = v8.Utils
local v_u_10 = v8.Sounds
require(v8.Modules.BloodyZee)
local v_u_11 = require(v8.Modules.CameraShaker)
require(v8.Modules.BloodyZee)
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "DebilitateController"
})
function v14.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_10, (copy) v_u_5, (copy) v_u_7, (copy) v_u_11, (copy) v_u_9, (copy) v_u_4, (copy) v_u_2, (copy) v_u_6, (copy) v_u_3, (ref) v_u_13
	local v_u_86 = {
		["Swing"] = function(p15)
			-- upvalues: (ref) v_u_12, (ref) v_u_10, (ref) v_u_5
			if p15 then
				local v16 = p15:FindFirstChild("HumanoidRootPart")
				if v16 then
					v_u_12:PlaySound(v_u_10.Nanami.CleavingWhirlwind.Start, v16, v_u_5.Effect).TimePosition = 0.6
				end
			else
				return
			end
		end,
		["Hitbox"] = function(p17, p18, p19)
			-- upvalues: (ref) v_u_12, (ref) v_u_10, (ref) v_u_5, (ref) v_u_7, (ref) v_u_11
			if p17 and p18 then
				local v20 = p17:FindFirstChild("HumanoidRootPart")
				if v20 then
					if p18:FindFirstChild("HumanoidRootPart") then
						v_u_12:Flash(p18, Color3.new(1, 1, 1))
						v_u_12:PlaySound(v_u_10.Haruta.Trip, v20, v_u_5.Effect)
						if p19 then
							v_u_12:PlaySound(v_u_10.Haruta.Trip2, v20, v_u_5.Effect)
							v_u_12:PlaySound(v_u_10.Nanami.CleavingWhirlwind.Hit, v20, v_u_5.Effect)
						end
						if p17 == v_u_7.Character or p18 == v_u_7.Character then
							v_u_11.CurrentShaker:Shake(v_u_11.Presets.MediumHit)
						end
					end
				else
					return
				end
			else
				return
			end
		end,
		["Hitbox1"] = function(p21, p22)
			-- upvalues: (ref) v_u_12, (ref) v_u_10, (ref) v_u_5, (ref) v_u_9, (ref) v_u_4, (ref) v_u_2, (ref) v_u_7, (ref) v_u_11
			if p21 and p22 then
				local v_u_23 = p21:FindFirstChild("HumanoidRootPart")
				if v_u_23 then
					v_u_12:PlaySound(v_u_10.Toji.SSK.Debilitate.Slash1, v_u_23, v_u_5.Effect)
					local v_u_24 = v_u_9.Toji.Flourish:FindFirstChild("Slash3"):Clone()
					v_u_24.CFrame = v_u_23.CFrame * v_u_24.Weld.C0
					v_u_24.Parent = workspace.Effects
					v_u_4:Create(v_u_24, TweenInfo.new(0.4), {
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v_u_24, 0.4)
					if _G.Settings.Flash == true then
						task.delay(0.05, function()
							-- upvalues: (copy) v_u_24
							v_u_24.Material = Enum.Material.Neon
							v_u_24.Color = Color3.fromRGB(85, 0, 0)
						end)
					else
						v_u_24.Material = Enum.Material.Neon
						v_u_24.Color = Color3.fromRGB(85, 0, 0)
					end
					task.spawn(function()
						-- upvalues: (copy) v_u_24, (copy) v_u_23
						local v25 = tick()
						local v26 = 1
						local v27 = task.wait()
						if v_u_24.Parent and v_u_23.Parent then
							v_u_24.Weld.C0 = v_u_24.Weld.C0:Lerp(v_u_24.Weld:GetAttribute("Goal"), 7 * v27)
							if tick() - v25 > 0.1 then
								local v28 = 12 * v27
								v26 = math.lerp(v26, 0, v28)
							end
							v_u_24.CFrame = v_u_24.CFrame:Lerp(v_u_23.CFrame * v_u_24.Weld.C0, v26)
							if v_u_23.Parent then
								continue
							end
						end
					end)
					for _, v29 in p22 do
						local v30 = v29:FindFirstChild("HumanoidRootPart")
						if not v30 then
							continue
						end
						v_u_12:Flash(v29, Color3.new(1, 1, 1))
						local v31 = v_u_9.Yuta.SlashHit:Clone()
						v31.CFrame = CFrame.lookAlong(v30.Position, v_u_23.CFrame.LookVector)
						local v32 = v31.CFrame
						local v33 = CFrame.Angles
						local v34 = -90 + math.random(-4, 4)
						v31.CFrame = v32 * v33(0, 0, (math.rad(v34)))
						v31.Parent = workspace.Effects
						v31.Slash:Emit(5)
						v_u_2:AddItem(v31, 0.5)
						if v29 ~= v_u_7.Character then
							continue
						end
						local v35 = v_u_11.CameraShakeInstance.new(3.8, 13, 0.1, 0.4)
						v35.PositionInfluence = Vector3.new(0.5, 0.5, 0)
						v35.RotationInfluence = Vector3.new(0, 0, 0)
						v_u_11.CurrentShaker:Shake(v35)
					end
					if p21 == v_u_7.Character then
						local v36 = v_u_11.CameraShakeInstance.new(3.8, 13, 0.1, 0.4)
						v36.PositionInfluence = Vector3.new(0.5, 0.5, 0)
						v36.RotationInfluence = Vector3.new(0, 0, 0)
						v_u_11.CurrentShaker:Shake(v36)
					end
				end
			else
				return
			end
		end,
		["Jump"] = function(p37)
			-- upvalues: (ref) v_u_12, (ref) v_u_10, (ref) v_u_5, (ref) v_u_9, (ref) v_u_4, (ref) v_u_2, (ref) v_u_7, (ref) v_u_11
			if p37 then
				local v_u_38 = p37:FindFirstChild("HumanoidRootPart")
				if v_u_38 then
					v_u_12:PlaySound(v_u_10.Toji.SSK.Debilitate.Dash, v_u_38, v_u_5.Effect)
					for v39 = 1, 4 do
						task.delay(v39 * 0.05, function()
							-- upvalues: (ref) v_u_9, (copy) v_u_38, (ref) v_u_4, (ref) v_u_2
							local v40 = v_u_9.Itadori.Shock:Clone()
							v40.CFrame = CFrame.lookAlong(v_u_38.Position, v_u_38.Velocity) * CFrame.Angles(1.5707963267948966, 0, 0)
							v40.Transparency = 0.3
							v40.Parent = workspace.Effects
							v_u_4:Create(v40, TweenInfo.new(0.15), {
								["Size"] = Vector3.new(20, 0, 20),
								["Transparency"] = 1
							}):Play()
							v_u_2:AddItem(v40, 0.15)
						end)
					end
					local v41 = v_u_9.Naoya.Fall:Clone()
					v41:PivotTo(v_u_38.CFrame)
					v41.Parent = workspace.Effects
					v_u_2:AddItem(v41, 1.5)
					v41.Mesh.Start.Transparency = 0.7
					v41.Mesh2.Start.Transparency = 0.7
					v41.Mesh3.Start.Transparency = 0.7
					v_u_4:Create(v41.Mesh.Start, TweenInfo.new(0.5, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
						["Size"] = nil,
						["Transparency"] = 1,
						["CFrame"] = nil,
						["Size"] = v41.Mesh.End.Size,
						["CFrame"] = v41.Mesh.End.CFrame
					}):Play()
					v_u_4:Create(v41.Mesh2.Start, TweenInfo.new(0.7, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
						["Size"] = nil,
						["Transparency"] = 1,
						["CFrame"] = nil,
						["Size"] = v41.Mesh2.End.Size,
						["CFrame"] = v41.Mesh2.End.CFrame
					}):Play()
					v_u_4:Create(v41.Mesh3.Start, TweenInfo.new(1, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
						["Size"] = nil,
						["Transparency"] = 1,
						["CFrame"] = nil,
						["Size"] = v41.Mesh3.End.Size,
						["CFrame"] = v41.Mesh3.End.CFrame
					}):Play()
					v41.Mesh.End:Destroy()
					v41.Mesh2.End:Destroy()
					v41.Mesh3.End:Destroy()
					if p37 == v_u_7.Character then
						local v42 = v_u_11.CameraShakeInstance.new(3.4, 9, 0.15, 0.5)
						v42.PositionInfluence = Vector3.new(0.3, 0.3, 0)
						v42.RotationInfluence = Vector3.new(0, 0, 0)
						v_u_11.CurrentShaker:Shake(v42)
					end
				end
			else
				return
			end
		end,
		["Hitbox2"] = function(p_u_43, p44, p_u_45, p_u_46)
			-- upvalues: (ref) v_u_12, (ref) v_u_10, (ref) v_u_5, (ref) v_u_4, (ref) v_u_6, (ref) v_u_7, (ref) v_u_11, (ref) v_u_9, (ref) v_u_2
			if p_u_43 and p44 then
				local v_u_47 = p_u_43:FindFirstChild("HumanoidRootPart")
				if v_u_47 then
					v_u_12:PlaySound(v_u_10.Toji.SSK.Debilitate.Slash2, v_u_47, v_u_5.Effect)
					local function v51() -- name: tweenFOV
						-- upvalues: (ref) v_u_4, (ref) v_u_6, (copy) p_u_45, (copy) p_u_46
						local v_u_48 = v_u_4:Create(v_u_6, TweenInfo.new(p_u_45, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
							["FieldOfView"] = 65
						})
						local v_u_49 = v_u_4:Create(v_u_6, TweenInfo.new(0.3, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
							["FieldOfView"] = 70
						})
						v_u_48:Play()
						local v_u_50 = p_u_46.AncestryChanged:Once(function()
							-- upvalues: (copy) v_u_48, (copy) v_u_49
							v_u_48:Cancel()
							v_u_49:Play()
						end)
						task.delay(p_u_45, function()
							-- upvalues: (ref) p_u_46, (copy) v_u_48, (copy) v_u_49, (copy) v_u_50
							if p_u_46 and p_u_46.Parent then
								v_u_48:Cancel()
								v_u_49:Play()
								v_u_50:Disconnect()
							end
						end)
					end
					for _, v_u_52 in p44 do
						local v_u_53 = v_u_52:FindFirstChild("HumanoidRootPart")
						if not v_u_53 then
							continue
						end
						v_u_12:PlaySound(v_u_10.Toji.SSK.Debilitate.Hit1, v_u_53, v_u_5.Effect)
						if v_u_52 == v_u_7.Character then
							v51()
							local v54 = v_u_11.CameraShakeInstance.new(3.2, 17, 0.12, 0.3)
							v54.PositionInfluence = Vector3.new(0.5, 0.5, 0)
							v54.RotationInfluence = Vector3.new(0, 0, 0)
							v_u_11.CurrentShaker:Shake(v54)
						end
						task.spawn(function()
							-- upvalues: (ref) v_u_9, (copy) v_u_53, (ref) v_u_2, (ref) v_u_4, (ref) v_u_12, (copy) v_u_52, (copy) p_u_45, (copy) v_u_47, (copy) p_u_43, (ref) v_u_7, (ref) v_u_11
							local v_u_55 = v_u_9.Toji.DebilitateHitstop:Clone()
							v_u_55.Position = v_u_53.Position
							v_u_55.Parent = workspace.Effects
							v_u_2:AddItem(v_u_55, 2)
							v_u_55.Wind2:Emit(7)
							task.delay(0.1, function()
								-- upvalues: (copy) v_u_55
								v_u_55.Wind:Emit(7)
							end)
							local v56 = TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
							v_u_4:Create(v_u_55.Blood, v56, {
								["TimeScale"] = 1
							}):Play()
							v_u_4:Create(v_u_55.Beam, v56, {
								["TextureSpeed"] = 3
							}):Play()
							v_u_4:Create(v_u_55.Beam2, v56, {
								["TextureSpeed"] = 2
							}):Play()
							for v57 = 1, 6 do
								v_u_12:Flash(v_u_52, Color3.new(1, 1, 1), p_u_45)
								local v58 = v_u_9.Yuta.SlashHit:Clone()
								v58.CFrame = CFrame.lookAlong(v_u_53.Position, v_u_47.CFrame.LookVector)
								local v59 = v58.CFrame
								local v60 = CFrame.Angles
								local v61 = -90 + math.random(-4, 4)
								v58.CFrame = v59 * v60(0, 0, (math.rad(v61)))
								v58.Parent = workspace.Effects
								v58.Slash:Emit(5)
								v_u_2:AddItem(v58, 0.5)
								if p_u_43 == v_u_7.Character or v_u_7.Character == v_u_52 then
									v_u_11.CurrentShaker:Shake(v_u_11.Presets.HeavyHit)
								end
								task.wait(0.2 / v57)
							end
							v_u_55.Blood.Enabled = false
							v_u_4:Create(v_u_55.Beam, TweenInfo.new(0.1), {
								["Width0"] = 0,
								["Width1"] = 0
							}):Play()
							v_u_4:Create(v_u_55.Beam2, TweenInfo.new(0.1), {
								["Width0"] = 0,
								["Width1"] = 0
							}):Play()
						end)
					end
					if p_u_43 == v_u_7.Character then
						v51()
						local v62 = v_u_11.CameraShakeInstance.new(3.2, 17, 0.12, 0.3)
						v62.PositionInfluence = Vector3.new(0.5, 0.5, 0)
						v62.RotationInfluence = Vector3.new(0, 0, 0)
						v_u_11.CurrentShaker:Shake(v62)
					end
				end
			else
				return
			end
		end,
		["Hitstop"] = function(p_u_63, p64, p_u_65, p66, p_u_67)
			-- upvalues: (ref) v_u_11, (ref) v_u_3
			if p_u_67 <= 0 then
				return
			elseif p_u_63 and p64 then
				if p_u_63:FindFirstChild("HumanoidRootPart") then
					local v_u_68 = 0
					local v_u_69 = Vector3.new(0, 0, 0)
					local v_u_70 = v_u_11.CameraShakeInstance.new(p_u_65.Magnitude, p66, 0, p_u_67)
					v_u_70.PositionInfluence = p_u_65
					v_u_70.RotationInfluence = Vector3.new(0, 0, 0)
					local v_u_74 = v_u_3.RenderStepped:Connect(function(p71)
						-- upvalues: (ref) v_u_68, (copy) p_u_67, (copy) p_u_63, (copy) v_u_70, (copy) p_u_65, (ref) v_u_69
						if p_u_67 <= v_u_68 then
							return
						elseif p_u_63 and p_u_63.Parent then
							local v72 = p_u_63:GetPivot()
							local v73 = v_u_70:UpdateShake(p71) * p_u_65
							p_u_63:PivotTo(v72 * CFrame.new(v73 - v_u_69))
							v_u_69 = v73
							v_u_68 = v_u_68 + p71
						end
					end)
					p64.AncestryChanged:Once(function()
						-- upvalues: (copy) v_u_74
						v_u_74:Disconnect()
					end)
				end
			else
				return
			end
		end,
		["Launch"] = function(p75, p76)
			-- upvalues: (ref) v_u_12, (ref) v_u_10, (ref) v_u_5, (ref) v_u_9, (ref) v_u_2, (ref) v_u_7, (ref) v_u_11, (ref) v_u_4
			if p75 and p76 then
				local v_u_77 = p75:FindFirstChild("HumanoidRootPart")
				if v_u_77 then
					v_u_12:PlaySound(v_u_10.Toji.SSK.Debilitate.Slash3, v_u_77, v_u_5.Effect)
					for _, v78 in p76 do
						local v79 = v78:FindFirstChild("HumanoidRootPart")
						if not v79 then
							continue
						end
						v_u_12:PlaySound(v_u_10.Toji.SSK.Debilitate.Hit2, v79, v_u_5.Effect)
						v_u_12:Flash(v78, Color3.new(1, 1, 1))
						local v80 = v_u_9.Mahito.CrushingRushdown.DrillImpact:Clone()
						v80.Position = v79.Position
						v80.Parent = workspace.Effects
						v_u_2:AddItem(v80, 1)
						v80.Sparks.Color = ColorSequence.new(Color3.fromRGB(85, 0, 0))
						v80.Wind.Color = v80.Sparks.Color
						v80.Wind2.Color = v80.Sparks.Color
						v80.Sparks:Emit(30)
						v80.Wind2:Emit(7)
						if v78 ~= v_u_7.Character then
							continue
						end
						v_u_11.CurrentShaker:Shake(v_u_11.Presets.Snap)
					end
					if p75 == v_u_7.Character or table.find(p76, v_u_7.Character) then
						v_u_11.CurrentShaker:Shake(v_u_11.Presets.Snap)
					end
					local v_u_81 = v_u_9.Toji.Flourish:FindFirstChild("Slash3"):Clone()
					v_u_81.CFrame = v_u_77.CFrame * v_u_81.Weld.C0
					v_u_81.Parent = workspace.Effects
					v_u_4:Create(v_u_81, TweenInfo.new(0.4), {
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v_u_81, 0.4)
					if _G.Settings.Flash == true then
						task.delay(0.05, function()
							-- upvalues: (copy) v_u_81
							v_u_81.Material = Enum.Material.Neon
							v_u_81.Color = Color3.fromRGB(85, 0, 0)
						end)
					else
						v_u_81.Material = Enum.Material.Neon
						v_u_81.Color = Color3.fromRGB(85, 0, 0)
					end
					task.spawn(function()
						-- upvalues: (copy) v_u_81, (copy) v_u_77
						local v82 = tick()
						local v83 = 1
						local v84 = task.wait()
						if v_u_81.Parent and v_u_77.Parent then
							v_u_81.Weld.C0 = v_u_81.Weld.C0:Lerp(v_u_81.Weld:GetAttribute("Goal"), 7 * v84)
							if tick() - v82 > 0.1 then
								local v85 = 12 * v84
								v83 = math.lerp(v83, 0, v85)
							end
							v_u_81.CFrame = v_u_81.CFrame:Lerp(v_u_77.CFrame * v_u_81.Weld.C0, v83)
							if v_u_77.Parent then
								continue
							end
						end
					end)
				end
			else
				return
			end
		end
	}
	v_u_13.Effects:Connect(function(p87, ...)
		-- upvalues: (copy) v_u_86
		local v88 = v_u_86[p87]
		if v88 then
			v88(...)
		end
	end)
end
function v14.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_12, (copy) v_u_1, (ref) v_u_13
	v_u_12 = v_u_1.GetController("FXController")
	v_u_13 = v_u_1.GetService("DebilitateService")
end
return v14