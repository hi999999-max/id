-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.ItemController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Debris")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game.Players.LocalPlayer
local v7 = game.ReplicatedStorage
local _ = v7.Animations
local v_u_8 = v7.Utils
local v_u_9 = v7.Sounds
local v_u_10 = require(v7.Modules.CameraShaker)
local v_u_11 = require(v7.Modules.BloodyZee)
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v15 = v_u_1.CreateController({
	["Name"] = "ItemController"
})
function v15.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_4, (ref) v_u_13, (copy) v_u_11, (copy) v_u_9, (copy) v_u_8, (copy) v_u_10, (copy) v_u_5, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (ref) v_u_12
	local v_u_178 = {
		["Soda"] = function(p16, p17)
			-- upvalues: (ref) v_u_4
			local v18 = p16.HumanoidRootPart
			if v18 then
				local v19 = p17:Clone()
				v_u_4:AddItem(v19, 2)
				v19.Weld:Destroy()
				v19.CFrame = p17.CFrame
				v19.CollisionGroup = "Effects"
				v19.Part.CollisionGroup = "Effects"
				v19.CanCollide = true
				v19.Part.CanCollide = true
				v19.Parent = workspace.Effects
				if v18 and v18.Parent then
					v19.Velocity = v18.CFrame.RightVector * 20
				end
				p17.Transparency = 1
				for _, v20 in p17:GetDescendants() do
					if not v20:IsA("BasePart") then
						continue
					end
					v20.Transparency = 1
				end
			end
		end,
		["SodaHit"] = function(p21)
			-- upvalues: (ref) v_u_13, (ref) v_u_11, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_10
			local v22 = p21.HumanoidRootPart
			if v22 then
				v_u_13:Flash(p21, Color3.new(1, 1, 1))
				for _ = 1, 20 do
					v_u_11:Blood(p21.Head.CFrame, math.random(5, 150), 45, 45)
				end
				v_u_13:PlaySound(v_u_9.Misc.Items.SodaHit, v22, game.SoundService.Effect)
				v_u_13:PlaySound(v_u_9.Itadori.DivergentFist.DivergentHit, v22, game.SoundService.Effect)
				local v23 = v_u_8.Gojo.Twofold.Sparks:Clone()
				v23.Parent = p21.Head
				v23:Emit(20)
				v_u_4:AddItem(v23, 0.4)
				if (workspace.CurrentCamera.CFrame.Position - v22.Position).Magnitude < 60 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
				end
			end
		end,
		["Gunfire"] = function(p24)
			-- upvalues: (ref) v_u_5, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			p24.Mesh.Attachment.Flash:Emit(2)
			p24.Mesh.Attachment.PointLight.Brightness = 15
			v_u_5:Create(p24.Mesh.Attachment.PointLight, TweenInfo.new(0.6), {
				["Brightness"] = 0
			}):Play()
			v_u_13:PlaySound(v_u_9.Misc.Items.Gunfire, p24, game.SoundService.Effect)
			if not p24:GetAttribute("Roulette") or p24:GetAttribute("GoHam") then
				if (workspace.CurrentCamera.CFrame.Position - p24.Position).Magnitude < 100 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
				end
			end
		end,
		["Sniperfire"] = function(p25)
			-- upvalues: (ref) v_u_5, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			p25.Sniper.Attachment.Flash:Emit(2)
			p25.Sniper.Attachment.PointLight.Brightness = 15
			v_u_5:Create(p25.Sniper.Attachment.PointLight, TweenInfo.new(1), {
				["Brightness"] = 0
			}):Play()
			v_u_13:PlaySound(v_u_9.Misc.Items.Sniperfire, p25, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p25.Position).Magnitude < 100 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
			end
		end,
		["RPGfire"] = function(p26)
			-- upvalues: (ref) v_u_5, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			p26.Mesh.Attachment.Flash:Emit(2)
			p26.Mesh.Attachment.Smoke:Emit(10)
			p26.Mesh.Attachment.Ring:Emit(3)
			p26.Mesh.Attachment.PointLight.Brightness = 15
			v_u_5:Create(p26.Mesh.Attachment.PointLight, TweenInfo.new(0.6), {
				["Brightness"] = 0
			}):Play()
			v_u_13:PlaySound(v_u_9.Misc.Items.RPGfire, p26, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p26.Position).Magnitude < 100 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
			end
		end,
		["SniperBolt"] = function(p27)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			v_u_13:PlaySound(v_u_9.Misc.Items.Bolt, p27, game.SoundService.Effect)
			task.wait(0.1)
			p27.Sniper.Attachment.Bolt.Casing:Emit(1)
			p27.Sniper.Attachment.Bolt.Dust:Emit(6)
		end,
		["SniperAim"] = function(p28, p29)
			-- upvalues: (ref) v_u_6, (ref) v_u_8, (ref) v_u_2, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9
			if v_u_6 == p28 then
				if p29 == true then
					if v_u_6.PlayerGui:FindFirstChild("Crosshair") then
						return
					end
					local v_u_30 = v_u_8.Misc.Items.Crosshair:Clone()
					v_u_30.Parent = v_u_6.PlayerGui
					v_u_6.CameraMode = Enum.CameraMode.LockFirstPerson
					v_u_2.MouseDeltaSensitivity = 0.1 * _G.Settings.SENS
					local v_u_31 = nil
					v_u_31 = v_u_3.RenderStepped:Connect(function()
						-- upvalues: (copy) v_u_30, (ref) v_u_31, (ref) v_u_6
						if v_u_30.Parent then
							local v32 = v_u_6.Character
							if v32 then
								v32 = v_u_6.Character:FindFirstChild("Humanoid")
							end
							if v32 then
								v32.CameraOffset = Vector3.new(0, 0, 0)
								local v33 = workspace.CurrentCamera
								if v33.CameraType == Enum.CameraType.Custom then
									local v34 = v33.CFrame.LookVector.X
									local v35 = v33.CFrame.LookVector.Z
									local v36 = Vector3.new(v34, 0, v35)
									v33.CFrame = CFrame.lookAlong(v33.CFrame.Position, v36)
									v33.FieldOfView = 10
								end
							else
								return
							end
						else
							v_u_31:Disconnect()
							return
						end
					end)
				else
					v_u_6.CameraMode = Enum.CameraMode.Classic
					local v37 = v_u_6.PlayerGui:FindFirstChild("Crosshair")
					if v37 then
						v37:Destroy()
					end
					v_u_2.MouseDeltaSensitivity = _G.Settings.SENS
					workspace.CurrentCamera.FieldOfView = 70
					if v_u_6.CameraMinZoomDistance == 0.5 then
						v_u_6.CameraMinZoomDistance = 10
						task.wait(0.1)
						v_u_6.CameraMinZoomDistance = 0.5
					end
				end
			end
			local v38 = p28.Character
			if v38 then
				v38 = p28.Character:FindFirstChild("HumanoidRootPart")
			end
			if v38 then
				if p29 then
					v_u_13:PlaySound(v_u_9.Misc.Items.ScopeIn, v38, game.SoundService.Effect)
				else
					v_u_13:PlaySound(v_u_9.Misc.Items.ScopeOut, v38, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Interp"] = function(p_u_39)
			-- upvalues: (ref) v_u_3
			local v_u_40 = p_u_39.CFrame
			local v_u_41 = tick()
			local v_u_42 = p_u_39:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_40, (copy) p_u_39, (ref) v_u_41
				v_u_40 = p_u_39.CFrame
				v_u_41 = tick()
			end)
			local v_u_43 = nil
			v_u_43 = v_u_3.Stepped:Connect(function()
				-- upvalues: (copy) p_u_39, (ref) v_u_43, (copy) v_u_42, (ref) v_u_40, (ref) v_u_41
				if p_u_39.Parent == workspace.Bullets then
					if p_u_39.Parent then
						workspace:BulkMoveTo({ p_u_39 }, { v_u_40 + v_u_40.LookVector * (p_u_39:GetAttribute("Speed") * (tick() - v_u_41)) }, Enum.BulkMoveMode.FireCFrameChanged)
						if p_u_39.CanCollide then
							p_u_39.Velocity = v_u_40.LookVector * p_u_39:GetAttribute("Speed")
						end
					else
						v_u_43:Disconnect()
						v_u_42:Disconnect()
					end
				else
					v_u_43:Disconnect()
					v_u_42:Disconnect()
					return
				end
			end)
		end,
		["GunBreak"] = function(p44, p45)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_13, (ref) v_u_9, (ref) v_u_6, (ref) v_u_10
			local v46 = p44:FindFirstChild("HumanoidRootPart")
			if v46 then
				for _ = 1, 10 do
					local v_u_47 = v_u_8.Hiromi.GavelShard:Clone()
					v_u_47.Position = p45
					v_u_47.Size = v_u_47.Size * (math.random(30, 100) / 100)
					v_u_47.Color = Color3.fromRGB(33, 33, 33)
					local v48 = math.random(-50, 50)
					local v49 = math.random(-50, 50)
					local v50 = math.random
					v_u_47.Velocity = Vector3.new(v48, v49, v50(-50, 50))
					local v51 = math.random(-50, 50)
					local v52 = math.random(-50, 50)
					local v53 = math.random
					v_u_47.RotVelocity = Vector3.new(v51, v52, v53(-50, 50))
					v_u_47.Parent = workspace.Effects
					v_u_4:AddItem(v_u_47, 2)
					task.delay(1, function()
						-- upvalues: (ref) v_u_5, (copy) v_u_47
						v_u_5:Create(v_u_47, TweenInfo.new(1), {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
					end)
				end
				v_u_13:PlaySound(v_u_9.Misc.Items.Gunbreak, v46, game.SoundService.Effect)
				if v_u_6.Character == p44 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
				end
			end
		end,
		["Breakball"] = function(p54)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_13, (ref) v_u_9
			if p54.Parent then
				for _ = 1, 10 do
					local v_u_55 = v_u_8.Hiromi.GavelShard:Clone()
					v_u_55.Position = p54.Position
					v_u_55.Size = v_u_55.Size * (math.random(30, 100) / 100)
					v_u_55.Color = Color3.fromRGB(33, 33, 33)
					local v56 = math.random(-50, 50)
					local v57 = math.random(-50, 50)
					local v58 = math.random
					v_u_55.Velocity = Vector3.new(v56, v57, v58(-50, 50))
					local v59 = math.random(-50, 50)
					local v60 = math.random(-50, 50)
					local v61 = math.random
					v_u_55.RotVelocity = Vector3.new(v59, v60, v61(-50, 50))
					v_u_55.Parent = workspace.Effects
					v_u_4:AddItem(v_u_55, 2)
					task.delay(1, function()
						-- upvalues: (ref) v_u_5, (copy) v_u_55
						v_u_5:Create(v_u_55, TweenInfo.new(1), {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
					end)
				end
				v_u_13:PlaySound(v_u_9.Misc.Items.Breakball, p54, game.SoundService.Effect)
			end
		end,
		["BulletHit"] = function(p62)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_6, (ref) v_u_10
			local v63 = p62:FindFirstChild("HumanoidRootPart")
			if v63 then
				v_u_13:Flash(p62, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Mahito.Soulfire.Hit, v63, game.SoundService.Effect)
				local v64 = v_u_8.Gojo.Twofold.Sparks:Clone()
				v64.Parent = v63.RootAttachment
				v64:Emit(20)
				v_u_4:AddItem(v64, 0.4)
				if v_u_6.Character == p62 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
				end
			end
		end,
		["Coin"] = function(p65)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			v_u_13:PlaySound(v_u_9.Misc.Items.Coin, p65, game.SoundService.Effect)
			p65.Coin.Shine:Emit(1)
		end,
		["CoinParry"] = function(p66)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			v_u_13:PlaySound(v_u_9.Misc.Items.Parry, p66, game.SoundService.Effect)
			p66.Coin.Sparks:Emit(15)
			p66.Coin.Wind2:Emit(15)
			if (workspace.CurrentCamera.CFrame.Position - p66.Position).Magnitude < 100 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
			end
		end,
		["BananaPeel"] = function(p67)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			v_u_13:PlaySound(v_u_9.Misc.Items.BananaPeel, p67, game.SoundService.Effect)
		end,
		["BananaPeelSlip"] = function(p68)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			v_u_13:PlaySound(v_u_9.Misc.Items.BananaPeelSlip, p68, game.SoundService.Effect)
		end,
		["TNT"] = function(p69)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_5
			v_u_13:PlaySound(v_u_9.Misc.Items.TNT, p69, game.SoundService.Effect)
			local v70 = Instance.new("Highlight")
			v70.DepthMode = Enum.HighlightDepthMode.Occluded
			v70.FillColor = Color3.new(1, 1, 1)
			v70.FillTransparency = 1
			v70.OutlineTransparency = 1
			v70.Parent = p69.Part
			task.wait(0.25)
			for v71 = 1, 7 do
				if v71 == 7 and p69.Parent then
					v_u_5:Create(p69.Part, TweenInfo.new(0.65, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
						["Size"] = Vector3.new(4, 4, 4)
					}):Play()
				end
				v_u_5:Create(v70, TweenInfo.new(0.25), {
					["FillTransparency"] = 0.25
				}):Play()
				task.wait(0.25)
				v_u_5:Create(v70, TweenInfo.new(0.25), {
					["FillTransparency"] = 1
				}):Play()
				task.wait(0.25)
			end
		end,
		["TNTExplode"] = function(p72)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			local v73 = v_u_8.Misc.Items.TNTExplosion:Clone()
			v_u_4:AddItem(v73, 5)
			v73.Position = p72
			v73.Parent = workspace.Effects
			v73.Effect:Emit(255)
			v_u_13:PlaySound(v_u_9.Misc.Items.TNTExplode, v73, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p72).Magnitude < 100 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
			end
		end,
		["JetSwing"] = function(p74)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			v_u_13:PlaySound(v_u_9.Misc.Swing.Sword, p74, game.SoundService.Effect)
		end,
		["JetHit"] = function(p75)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v76 = p75:FindFirstChild("HumanoidRootPart")
			if v76 then
				v_u_13:Flash(p75, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Megumi.Mahoraga.M1:FindFirstChild("Hit1"), v76, game.SoundService.Effect)
			end
		end,
		["Explode"] = function(p77)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			local v78 = v_u_8.Misc.Items.EyeBomb:Clone()
			v78.Position = p77
			v78.Parent = workspace.Effects
			v_u_4:AddItem(v78, 3)
			for _, v79 in v78:GetChildren() do
				v79:Emit(v79:GetAttribute("EmtiCount"))
			end
			v_u_13:PlaySound(v_u_9.Misc.Items.Eye, v78, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p77).Magnitude < 100 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
			end
		end,
		["RPGExplode"] = function(p80)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			local v81 = v_u_8.Misc.Items.EyeBomb:Clone()
			v81.Position = p80
			v81.Parent = workspace.Effects
			v_u_4:AddItem(v81, 6)
			v_u_5:Create(v81.Smoke, TweenInfo.new(0.4), {
				["TimeScale"] = 0.3
			}):Play()
			local v82 = v_u_8.Mechamaru.Dust:Clone()
			v82.Position = p80 - Vector3.new(0, 3, 0)
			v82.Parent = workspace.Effects
			v_u_4:AddItem(v82, 5)
			for _, v83 in v82:GetDescendants() do
				if not v83:IsA("ParticleEmitter") then
					continue
				end
				v83.TimeScale = v83.TimeScale / 2
				v83.Color = ColorSequence.new(Color3.fromRGB(100, 100, 100), Color3.fromRGB(0, 0, 0))
				v83:Emit(v83:GetAttribute("EmitCount"))
			end
			for _, v84 in v81:GetChildren() do
				v84:Emit(v84:GetAttribute("EmtiCount"))
			end
			v_u_13:PlaySound(v_u_9.Misc.Items.Eye, v81, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p80).Magnitude < 100 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
				if _G.Settings.Flash == true then
					local v85 = v_u_8.Itadori.DivergentFist.BlackFlashCC:Clone()
					v85.TintColor = Color3.new(1, 1, 1)
					v85.Parent = game.Lighting
					task.wait(0.04)
					v85.Brightness = 200
					v85.Contrast = -1000
					task.wait(0.04)
					v85:Destroy()
				end
			end
		end,
		["Voice"] = function(p86, p87)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			local v88 = v_u_8.Misc.Items.Voice:Clone()
			v88.Position = p86
			v88.Parent = workspace.Effects
			v_u_4:AddItem(v88, 4)
			for _, v89 in v88:GetChildren() do
				v89:Emit(v89:GetAttribute("EmtiCount"))
			end
			v_u_13:PlaySound(v_u_9.Misc.Items.Voice, v88, game.SoundService.Effect)
			if p87 == "Plummet" then
				v_u_13:PlaySound(v_u_9.Yuta.MutualLove.VoiceCrush, v88, game.SoundService.Voice)
			elseif p87 == "Blast" then
				v_u_13:PlaySound(v_u_9.Misc.Items.Voice3, v88, game.SoundService.Voice)
			else
				v_u_13:PlaySound(v_u_9.Misc.Items.Voice2, v88, game.SoundService.Voice)
			end
			if (workspace.CurrentCamera.CFrame.Position - p86).Magnitude < 100 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
			end
		end,
		["VoiceHit"] = function(p90, p91)
			-- upvalues: (ref) v_u_6, (ref) v_u_10, (ref) v_u_5, (ref) v_u_4, (ref) v_u_8
			local v92 = p90.HumanoidRootPart
			if v92 then
				if v_u_6.Character == p90 then
					v_u_10.CurrentShaker:ShakeSustain(v_u_10.Presets.Snap):StartFadeOut(1)
					if _G.Settings.Flash == true then
						local v_u_93 = Instance.new("ColorCorrectionEffect", game.Lighting)
						v_u_93.Contrast = -2
						task.delay(0.1, function()
							-- upvalues: (copy) v_u_93, (ref) v_u_5, (ref) v_u_4
							v_u_93.Saturation = -2
							task.wait(0.1)
							v_u_93.Contrast = 0
							v_u_5:Create(v_u_93, TweenInfo.new(0.5), {
								["Saturation"] = 0
							}):Play()
							v_u_4:AddItem(v_u_93, 0.5)
						end)
					end
				end
				local v94 = v_u_8.Misc.Items.VoiceHit:Clone()
				v94.Weld.Part0 = v92
				v94.Parent = workspace.Effects
				for _ = 1, 2 do
					local v95 = workspace.CurrentCamera.CFrame
					local v96 = v_u_8.Damage.HitGlow:GetChildren()
					local v97 = v96[math.random(1, #v96)]
					if not p90:FindFirstChild(v97.Name) then
						continue
					end
					local v98 = v97:Clone()
					v98.Anchored = true
					v98.BrickColor = BrickColor.random()
					v98.Parent = workspace.Effects
					v98.CFrame = p90:FindFirstChild(v98.Name).CFrame + v95.LookVector * 0.3 + v95.RightVector * math.random(-70, 70) / 100 + v95.UpVector * math.random(-70, 70) / 100
					v_u_4:AddItem(v98, 0.04)
				end
				task.wait(0.02)
				if p90.Parent and p91.Parent then
					break
				end
				v94.Aura.Enabled = false
				v94.Lines.Enabled = false
				v94.Attachment.Sparks1:Emit(20)
				v94.Attachment.WindCircle:Emit(2)
				v_u_4:AddItem(v94, 1)
			end
		end,
		["VoiceSwitch"] = function(p99)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v100 = { Color3.fromRGB(255, 80, 80), Color3.fromRGB(255, 190, 60), Color3.fromRGB(80, 255, 80) }
			p99.Part.Mode.Glow.Color = ColorSequence.new(v100[p99:GetAttribute("Mode")])
			v_u_13:PlaySound(v_u_9.Misc.Items.VoiceSwitch, p99, game.SoundService.Effect)
		end,
		["Wall"] = function(p_u_101)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_5, (ref) v_u_4
			v_u_13:PlaySound(v_u_9.Misc.Items.Wall, p_u_101, game.SoundService.Effect)
			p_u_101:GetPropertyChangedSignal("Size"):Connect(function()
				-- upvalues: (ref) v_u_8, (copy) p_u_101, (ref) v_u_5, (ref) v_u_4
				for _ = 1, 2 do
					local v102 = v_u_8.Mahito.Morph:Clone()
					v102.Weld.Part0 = p_u_101
					v102.Color = p_u_101.Color
					v102.Material = p_u_101.Material
					v102.Weld.C1 = CFrame.new(math.random(-p_u_101.Size.X / 2, p_u_101.Size.X / 2), math.random(-p_u_101.Size.Y / 2, p_u_101.Size.Y / 2), math.random(-p_u_101.Size.Z / 2, p_u_101.Size.Z / 2))
					v102.Parent = workspace.Effects
					v102.Size = Vector3.new(1, 1, 1) * (math.random(30, 60) / 10)
					v_u_5:Create(v102, TweenInfo.new(math.random(10, 40) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_4:AddItem(v102, 0.4)
				end
			end)
		end,
		["PlayfulSwing"] = function(p103, p104, p105)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v106 = p103.HumanoidRootPart
			if v106 then
				if p105 == "Down" then
					v_u_13:ArmFlash(p103["Right Leg"], Color3.fromRGB(255, 0, 0), 0.4)
					v_u_13:PlaySound(v_u_9.Misc.Swing.Fist, v106, game.SoundService.Effect)
					return
				elseif p105 == "Up" then
					v_u_13:ArmFlash(p103["Right Arm"], Color3.fromRGB(255, 0, 0), 0.3)
					v_u_13:PlaySound(v_u_9.Misc.Swing.Fist, v106, game.SoundService.Effect)
				else
					v_u_13:PlaySound(v_u_9.Misc.Items.PlayfulSwing["Swing" .. p104], v106, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["PlayfulHit"] = function(p107, p108)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4
			local v109 = p107:FindFirstChild("HumanoidRootPart")
			if v109 then
				v_u_13:Flash(p107, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Itadori.M1:FindFirstChild("Hit" .. p108), v109, game.SoundService.Effect)
				v_u_13:PlaySound(v_u_9.Hiromi.M1:FindFirstChild("Hit" .. p108), v109, game.SoundService.Effect)
				local v110 = v_u_8.Misc.Items.BiteHit:Clone()
				v110.Position = v109.Position
				v110.Parent = workspace.Effects
				v_u_4:AddItem(v110, 0.5)
				for _, v111 in v110:GetChildren() do
					v111:Emit(v111:GetAttribute("EmitCount"))
				end
			end
		end,
		["PlayfulBreak"] = function(p112, p113)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_13, (ref) v_u_9
			local v114 = p112:FindFirstChild("HumanoidRootPart")
			if v114 then
				for _ = 1, 10 do
					local v_u_115 = v_u_8.Hiromi.GavelShard:Clone()
					v_u_115.Position = p113.Core.Position
					v_u_115.Size = v_u_115.Size * (math.random(30, 100) / 100)
					v_u_115.Color = Color3.fromRGB(194, 46, 46)
					local v116 = math.random(-50, 50)
					local v117 = math.random(-50, 50)
					local v118 = math.random
					v_u_115.Velocity = Vector3.new(v116, v117, v118(-50, 50))
					local v119 = math.random(-50, 50)
					local v120 = math.random(-50, 50)
					local v121 = math.random
					v_u_115.RotVelocity = Vector3.new(v119, v120, v121(-50, 50))
					v_u_115.Parent = workspace.Effects
					v_u_4:AddItem(v_u_115, 2)
					task.delay(1, function()
						-- upvalues: (ref) v_u_5, (copy) v_u_115
						v_u_5:Create(v_u_115, TweenInfo.new(1), {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
					end)
				end
				v_u_13:PlaySound(v_u_9.Misc.Items.Gunbreak, v114, game.SoundService.Effect)
			end
		end,
		["PlayfulStuck"] = function(p122, _)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_10
			local v123 = p122:FindFirstChild("HumanoidRootPart")
			if v123 then
				v_u_13:Flash(p122, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Mahito.Soulfire.Hit, v123, game.SoundService.Effect)
				v_u_13:PlaySound(v_u_9.Hiromi.Execution.Sever, v123, game.SoundService.Effect)
				local v124 = v_u_8.Misc.Items.BiteHit:Clone()
				v124.Position = v123.Position
				v124.Parent = workspace.Effects
				v_u_4:AddItem(v124, 0.5)
				for _, v125 in v124:GetChildren() do
					v125:Emit(v125:GetAttribute("EmitCount"))
				end
				if (workspace.CurrentCamera.CFrame.Position - v123.Position).Magnitude < 50 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
				end
			end
		end,
		["PlayfulImpact"] = function(p126)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			local v127 = v_u_8.Megumi.Mahoraga.Rock:Clone()
			v127.Transparency = 1
			v127.Anchored = true
			v127.Position = p126
			v127.Parent = workspace.Effects
			v127.Attachment.Dust:Emit(20)
			v127.Attachment.Hit:Emit(20)
			v127.Attachment.Sparks:Emit(20)
			v_u_4:AddItem(v127, 1.5)
			v_u_13:PlaySound(v_u_9.Itadori.CrushingBlow.GroundImpact, v127, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p126).Magnitude < 100 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
			end
		end,
		["TintedGlassesOn"] = function(p128, p_u_129)
			local v_u_130 = {}
			local function v_u_133() -- name: Clean
				-- upvalues: (copy) v_u_130
				for v131, v132 in next, v_u_130 do
					if typeof(v132) == "RBXScriptConnection" then
						v132:Disconnect()
					else
						v132:Destroy()
					end
					v_u_130[v131] = nil
				end
			end
			local v134 = p128.AncestryChanged
			table.insert(v_u_130, v134:Connect(function(_, p135)
				-- upvalues: (copy) p_u_129, (copy) v_u_133
				if not (p135 and p135:IsDescendantOf(p_u_129)) then
					v_u_133()
				end
			end))
			local v136 = p_u_129.AncestryChanged
			table.insert(v_u_130, v136:Connect(function(_, p137)
				-- upvalues: (copy) v_u_133
				if not p137 then
					v_u_133()
				end
			end))
			local function v143(p138) -- name: ApplyCD
				-- upvalues: (copy) v_u_130
				local v139 = p138:WaitForChild("HumanoidRootPart", 2)
				if v139 then
					if not game.Players:GetPlayerFromCharacter(p138) then
						return
					end
					if p138:GetAttribute("Moveset") == "Toji" then
						local v140 = v139:FindFirstChild("Reveal")
						if v140 then
							v140:Destroy()
						end
						return
					end
					local v141 = game:GetService("ReplicatedStorage").Utils.Reveal:Clone()
					v141.MaxDistance = 75
					v141.Handle.Enabled = true
					v141.Parent = v139
					local v142 = v_u_130
					table.insert(v142, v141)
				end
			end
			local v144 = workspace.Characters.ChildAdded
			table.insert(v_u_130, v144:Connect(v143))
			local v145 = next
			local v146, v147 = workspace.Characters:GetChildren()
			for _, v148 in v145, v146, v147 do
				if v148 == p_u_129 then
					continue
				end
				v143(v148)
			end
		end,
		["SnowballHit"] = function(p149)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_6, (ref) v_u_10
			local v150 = p149:FindFirstChild("HumanoidRootPart")
			if v150 then
				v_u_13:Flash(p149, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Misc.Items.Snowball.Hit, v150, game.SoundService.Effect)
				v_u_13:PlaySound(v_u_9.Misc.Items.Snowball.Hit2, v150, game.SoundService.Effect)
				if v_u_6.Character == p149 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
				end
			end
		end,
		["Snowball"] = function(p151, p152)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v153 = p151:FindFirstChild("HumanoidRootPart")
			if v153 then
				if p152 then
					v_u_13:PlaySound(v_u_9.Misc.Items.Snowball.Form, v153, game.SoundService.Effect)
				else
					v_u_13:PlaySound(v_u_9.Misc.Items.Snowball.Startup, v153, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["SnowballSpin"] = function(p154)
			-- upvalues: (ref) v_u_5
			local v_u_155 = p154:FindFirstChild("Handle")
			if not v_u_155 then
				return
			end
			v_u_155.Tween.Value = false
			task.wait()
			v_u_155.Tween.Value = true
			v_u_155.Sound:Play()
			local v_u_156 = false
			v_u_155.Tween:GetPropertyChangedSignal("Value"):Once(function()
				-- upvalues: (copy) v_u_155, (ref) v_u_156
				if not v_u_155.Tween.Value then
					v_u_156 = true
				end
			end)
			local v157 = v_u_156
			for v158 = 1, 3 do
				if v157 then
					break
				end
				for _ = 1, 10 do
					if v157 then
						break
					end
					local _, v159, v160 = v_u_155.CFrame:ToOrientation()
					local v161 = ((v158 - 1) * 0.12 + 0.05) / 2
					v_u_5:Create(v_u_155, TweenInfo.new(v161, Enum.EasingStyle.Linear), {
						["CFrame"] = CFrame.new(v_u_155.Position) * CFrame.fromOrientation(0, v159, v160) * CFrame.Angles(0, 0, 36)
					}):Play()
					task.wait(v161)
				end
			end
			local _, v162 = v_u_155.CFrame:ToOrientation()
			v_u_5:Create(v_u_155, TweenInfo.new(0.1, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
				["CFrame"] = CFrame.new(v_u_155.Position) * CFrame.Angles(0, v162, 0.05754350543825305)
			}):Play()
			if not v157 then
				v_u_155.Tween.Value = false
			end
		end,
		["Clash"] = function(p163)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_10
			local v164 = p163:FindFirstChild("HumanoidRootPart")
			if v164 then
				v_u_13:Flash(p163, Color3.new(1, 1, 0.498039), 0.6)
				v_u_13:PlaySound(v_u_9.Misc.Items.Clash, v164, game.SoundService.Effect)
				local v165 = v_u_8.Misc.Items.Clash.Attachment:Clone()
				v165.Parent = v164
				v_u_4:AddItem(v165, 0.9)
				for _, v166 in v165:GetChildren() do
					if v166:IsA("PointLight") then
						v_u_5:Create(v166, TweenInfo.new(v166:GetAttribute("Duration")), {
							["Brightness"] = 0
						}):Play()
					else
						v166:Emit(v166:GetAttribute("EmitCount"))
					end
				end
				if (workspace.CurrentCamera.CFrame.Position - v164.Position).Magnitude < 150 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
				end
			end
		end,
		["BowlingHit"] = function(p167)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v168 = p167:FindFirstChild("HumanoidRootPart")
			if v168 then
				v_u_13:Flash(p167, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Misc.Items.Hitball, v168, game.SoundService.Effect)
			end
		end,
		["NaginataVaultHit"] = function(p169)
			-- upvalues: (ref) v_u_11, (ref) v_u_6, (ref) v_u_10
			local v170 = p169:FindFirstChild("HumanoidRootPart")
			if v170 then
				for _ = 1, 13 do
					v_u_11:Blood(v170.CFrame - Vector3.new(0, 2, 0), 50, 30, 90)
				end
				if v_u_6.Character == p169 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.MediumHit)
				end
			end
		end,
		["NaginataVaultSlam"] = function(p171)
			-- upvalues: (ref) v_u_6, (ref) v_u_10
			if v_u_6.Character == p171 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
			end
		end,
		["CrowbarSwing"] = function(p172)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v173 = p172:FindFirstChild("HumanoidRootPart")
			if v173 then
				v_u_13:PlaySound(v_u_9.Misc.Items.Crowbar, v173, game.SoundService.Effect)
				v_u_13:PlaySound(v_u_9.Misc.Items.Crowbar3, v173, game.SoundService.Effect)
				task.wait(0.4)
				v_u_13:PlaySound(v_u_9.Misc.Items.Crowbar2, v173, game.SoundService.Effect)
			end
		end,
		["CrowbarHit"] = function(p174)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_10
			local v175 = p174:FindFirstChild("HumanoidRootPart")
			if v175 then
				v_u_13:Flash(p174, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Misc.Items.CrowbarHIt, v175, game.SoundService.Effect)
				for _ = 1, 20 do
					v_u_11:Blood(p174.Head.CFrame, math.random(5, 150), 45, 45)
				end
				local v176 = v_u_8.Locust.Slam:Clone()
				v176.Position = p174.Torso.Position
				v176.Parent = workspace.Effects
				for _, v177 in v176.Attachment:GetChildren() do
					v177:Emit(v177:GetAttribute("EmitCount"))
				end
				v_u_4:AddItem(v176, 0.5)
				if (workspace.CurrentCamera.CFrame.Position - v175.Position).Magnitude < 100 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
				end
			end
		end
	}
	v_u_12.Effects:Connect(function(p179, ...)
		-- upvalues: (copy) v_u_178
		local v180 = v_u_178[p179]
		if v180 then
			v180(...)
		end
	end)
end
function v15.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_12, (copy) v_u_1, (ref) v_u_13, (ref) v_u_14
	v_u_12 = v_u_1.GetService("ItemService")
	v_u_13 = v_u_1.GetController("FXController")
	v_u_14 = v_u_1.GetController("CharlesController")
end
return v15