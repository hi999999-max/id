-- Original instance: Players.YouNeverSeenThat.PlayerScripts.PlayerModule.CameraModule.CameraInput
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = game:GetService("ContextActionService")
local v_u_2 = game:GetService("UserInputService")
local v3 = game:GetService("Players")
game:GetService("RunService")
local v_u_4 = UserSettings():GetService("UserGameSettings")
local v_u_5 = game:GetService("VRService")
local v_u_6 = game:GetService("GuiService")
local v7 = script.Parent.Parent:WaitForChild("CommonUtils")
local v8 = require(v7:WaitForChild("FlagUtil"))
local v_u_9 = v8.getUserFlag("UserPSSinkUnknownTouchEvents")
local v10 = v8.getUserFlag("UserPSTextboxResetCameraInput")
local v11 = v8.getUserFlag("UserFixVRCameraGamepadReset")
local v_u_12 = v8.getUserFlag("UserPlayerScriptsSupportTVRemoteKeycodes")
local v_u_13 = v3.LocalPlayer
local v_u_14 = Enum.ContextActionPriority.Medium.Value
local v_u_15 = Vector2.new(1, 0.77) * 0.06981317007977318 * 60
local v_u_16 = Vector2.new(1, 0.77) * 0.008726646259971648
local v_u_17 = Vector2.new(1, 0.77) * 0.12217304763960307
local v_u_18 = Vector2.new(1, 0.66) * 0.017453292519943295
local v_u_19 = Instance.new("BindableEvent")
local v_u_20 = Instance.new("BindableEvent")
local v_u_21 = v_u_19.Event
local v_u_22 = v_u_20.Event
v_u_2.InputBegan:Connect(function(p23, p24)
	-- upvalues: (copy) v_u_19
	if not p24 and p23.UserInputType == Enum.UserInputType.MouseButton2 then
		v_u_19:Fire()
	end
end)
v_u_2.InputEnded:Connect(function(p25, _)
	-- upvalues: (copy) v_u_20
	if p25.UserInputType == Enum.UserInputType.MouseButton2 then
		v_u_20:Fire()
	end
end)
local function v_u_29(p26) -- name: thumbstickCurve
	local v27 = (math.abs(p26) - 0.1) / 0.9 * 2
	local v28 = (math.exp(v27) - 1) / 6.38905609893065
	return math.sign(p26) * math.clamp(v28, 0, 1)
end
local function v_u_34(p30) -- name: adjustTouchPitchSensitivity
	local v31 = workspace.CurrentCamera
	if not v31 then
		return p30
	end
	local v32 = v31.CFrame:ToEulerAnglesYXZ()
	if p30.Y * v32 >= 0 then
		return p30
	end
	local v33 = (1 - (math.abs(v32) * 2 / 3.141592653589793) ^ 0.75) * 0.75 + 0.25
	return Vector2.new(1, v33) * p30
end
local function v_u_41(p35) -- name: isInDynamicThumbstickArea
	-- upvalues: (copy) v_u_13
	local v36 = v_u_13:FindFirstChildOfClass("PlayerGui")
	if v36 then
		v36 = v36:FindFirstChild("TouchGui")
	end
	local v37
	if v36 then
		v37 = v36:FindFirstChild("TouchControlFrame")
	else
		v37 = v36
	end
	if v37 then
		v37 = v37:FindFirstChild("DynamicThumbstickFrame")
	end
	if not v37 then
		return false
	end
	if not v36.Enabled then
		return false
	end
	local v38 = v37.AbsolutePosition
	local v39 = v38 + v37.AbsoluteSize
	local v40
	if p35.X >= v38.X and (p35.Y >= v38.Y and p35.X <= v39.X) then
		v40 = p35.Y <= v39.Y
	else
		v40 = false
	end
	return v40
end
local v42 = {}
local v_u_43 = {}
local v_u_44 = 0
local v_u_45 = {
	["Thumbstick2"] = nil,
	["ButtonLeft"] = 0,
	["ButtonRight"] = 0,
	["Thumbstick2"] = Vector2.new()
}
local v_u_46 = {
	["Left"] = 0,
	["Right"] = 0,
	["I"] = 0,
	["O"] = 0
}
local v_u_47 = {
	["Movement"] = nil,
	["Wheel"] = 0,
	["Pan"] = nil,
	["Pinch"] = 0,
	["Movement"] = Vector2.new(),
	["Pan"] = Vector2.new()
}
local v_u_48 = {
	["Move"] = nil,
	["Pinch"] = 0,
	["Move"] = Vector2.new()
}
local v_u_49 = Instance.new("BindableEvent")
v42.gamepadZoomPress = v_u_49.Event
local v_u_50
if v11 then
	v_u_50 = Instance.new("BindableEvent")
	v42.gamepadReset = v_u_50.Event
else
	v_u_50 = v_u_5.VREnabled and Instance.new("BindableEvent") or nil
	if v_u_5.VREnabled then
		v42.gamepadReset = v_u_50.Event
	end
end
function v42.getRotationActivated() -- name: getRotationActivated
	-- upvalues: (copy) v_u_12, (ref) v_u_44, (copy) v_u_45
	if v_u_12 then
		return (v_u_44 > 0 or v_u_45.Thumbstick2.Magnitude > 0) and true or v_u_45.ButtonRight - v_u_45.ButtonLeft ~= 0
	else
		return v_u_44 > 0 and true or v_u_45.Thumbstick2.Magnitude > 0
	end
end
function v42.getRotation(p51, p52) -- name: getRotation
	-- upvalues: (copy) v_u_4, (copy) v_u_46, (copy) v_u_12, (copy) v_u_45, (copy) v_u_47, (copy) v_u_34, (copy) v_u_48, (copy) v_u_15, (copy) v_u_16, (copy) v_u_17, (copy) v_u_18
	local v53 = Vector2.new(1, v_u_4:GetCameraYInvertValue())
	local v54 = Vector2.new(v_u_46.Right - v_u_46.Left, 0) * p51
	local v55
	if v_u_12 then
		local v56 = Vector2.new(v_u_45.ButtonRight - v_u_45.ButtonLeft, 0)
		v55 = (v_u_45.Thumbstick2 + v56) * v_u_4.GamepadCameraSensitivity * p51
	else
		v55 = v_u_45.Thumbstick2 * v_u_4.GamepadCameraSensitivity * p51
	end
	local v57 = v_u_47.Movement
	local v58 = v_u_47.Pan
	local v59 = v_u_34(v_u_48.Move)
	if p52 then
		v54 = Vector2.new()
	end
	return (v54 * 2.0943951023931953 + v55 * v_u_15 + v57 * v_u_16 + v58 * v_u_17 + v59 * v_u_18) * v53
end
function v42.getZoomDelta() -- name: getZoomDelta
	-- upvalues: (copy) v_u_46, (copy) v_u_47, (copy) v_u_48
	local v60 = v_u_46.O - v_u_46.I
	local v61 = -v_u_47.Wheel + v_u_47.Pinch
	local v62 = -v_u_48.Pinch
	return v60 * 0.1 + v61 * 1 + v62 * 0.04
end
local function v_u_65(_, _, p63) -- name: thumbstick
	-- upvalues: (copy) v_u_45, (ref) v_u_29
	local v64 = p63.Position
	v_u_45[p63.KeyCode.Name] = Vector2.new(v_u_29(v64.X), -v_u_29(v64.Y))
	return Enum.ContextActionResult.Pass
end
local function v_u_68(_, p66, p67) -- name: directionalButtons
	-- upvalues: (copy) v_u_45, (ref) v_u_29
	if p66 == Enum.UserInputState.Cancel then
		v_u_45[p67.KeyCode.Name] = 0
	else
		v_u_45[p67.KeyCode.Name] = v_u_29(p67.Position.Z)
	end
	return Enum.ContextActionResult.Pass
end
local function v_u_71(_, p69, p70) -- name: keypress
	-- upvalues: (copy) v_u_46
	v_u_46[p70.KeyCode.Name] = p69 == Enum.UserInputState.Begin and 1 or 0
end
local function v_u_73(_, p72, _) -- name: gamepadZoomPress
	-- upvalues: (copy) v_u_49
	if p72 == Enum.UserInputState.Begin then
		v_u_49:Fire()
	end
end
local function v_u_75(_, p74, _) -- name: gamepadReset
	-- upvalues: (ref) v_u_50
	if p74 == Enum.UserInputState.Begin then
		v_u_50:Fire()
	end
end
local function v_u_80() -- name: resetInputDevices
	-- upvalues: (copy) v_u_45, (copy) v_u_46, (copy) v_u_47, (copy) v_u_48, (ref) v_u_44
	local v76 = {
		v_u_45,
		v_u_46,
		v_u_47,
		v_u_48
	}
	for _, v77 in pairs(v76) do
		for v78, v79 in pairs(v77) do
			if type(v79) == "boolean" then
				v77[v78] = false
			else
				v77[v78] = v77[v78] * 0
			end
		end
	end
	v_u_44 = 0
end
local v_u_81 = {}
local v_u_82 = nil
local v_u_83 = nil
local function v_u_89(p84, p85) -- name: touchBegan
	-- upvalues: (ref) v_u_82, (copy) v_u_41, (ref) v_u_44, (ref) v_u_81
	local v86 = p84.UserInputType == Enum.UserInputType.Touch
	assert(v86)
	local v87 = p84.UserInputState == Enum.UserInputState.Begin
	assert(v87)
	if v_u_82 == nil and (v_u_41(p84.Position) and not p85) then
		v_u_82 = p84
	else
		if not p85 then
			local v88 = v_u_44 + 1
			v_u_44 = math.max(0, v88)
		end
		v_u_81[p84] = p85
	end
end
local function v_u_94(p90, _) -- name: touchEnded
	-- upvalues: (ref) v_u_82, (ref) v_u_81, (ref) v_u_83, (ref) v_u_44
	local v91 = p90.UserInputType == Enum.UserInputType.Touch
	assert(v91)
	local v92 = p90.UserInputState == Enum.UserInputState.End
	assert(v92)
	if p90 == v_u_82 then
		v_u_82 = nil
	end
	if v_u_81[p90] == false then
		v_u_83 = nil
		local v93 = v_u_44 - 1
		v_u_44 = math.max(0, v93)
	end
	v_u_81[p90] = nil
end
local function v_u_106(p95, p96) -- name: touchChanged
	-- upvalues: (ref) v_u_82, (ref) v_u_81, (copy) v_u_9, (copy) v_u_48, (ref) v_u_83
	local v97 = p95.UserInputType == Enum.UserInputType.Touch
	assert(v97)
	local v98 = p95.UserInputState == Enum.UserInputState.Change
	assert(v98)
	if p95 == v_u_82 then
		return
	else
		if v_u_81[p95] == nil then
			if v_u_9 then
				v_u_81[p95] = true
			else
				v_u_81[p95] = p96
			end
		end
		local v99 = {}
		for v100, v101 in pairs(v_u_81) do
			if v101 then
				continue
			end
			table.insert(v99, v100)
		end
		if #v99 == 1 and v_u_81[p95] == false then
			local v102 = p95.Delta
			local v103 = v_u_48
			v103.Move = v103.Move + Vector2.new(v102.X, v102.Y)
		end
		if #v99 == 2 then
			local v104 = (v99[1].Position - v99[2].Position).Magnitude
			if v_u_83 then
				local v105 = v_u_48
				v105.Pinch = v105.Pinch + (v104 - v_u_83)
			end
			v_u_83 = v104
		else
			v_u_83 = nil
		end
	end
end
local function v_u_107() -- name: resetTouchState
	-- upvalues: (ref) v_u_81, (ref) v_u_82, (ref) v_u_83, (ref) v_u_44
	v_u_81 = {}
	v_u_82 = nil
	v_u_83 = nil
	v_u_44 = 0
end
local function v_u_112(p108, p109, p110, p111) -- name: pointerAction
	-- upvalues: (copy) v_u_47
	if not p111 then
		v_u_47.Wheel = p108
		v_u_47.Pan = p109
		v_u_47.Pinch = -p110
	end
end
local function v_u_116(p113, p114) -- name: inputBegan
	-- upvalues: (ref) v_u_89, (ref) v_u_44
	if p113.UserInputType == Enum.UserInputType.Touch then
		v_u_89(p113, p114)
	elseif p113.UserInputType == Enum.UserInputType.MouseButton2 and not p114 then
		local v115 = v_u_44 + 1
		v_u_44 = math.max(0, v115)
	end
end
local function v_u_120(p117, p118) -- name: inputChanged
	-- upvalues: (ref) v_u_106, (copy) v_u_47
	if p117.UserInputType == Enum.UserInputType.Touch then
		v_u_106(p117, p118)
	elseif p117.UserInputType == Enum.UserInputType.MouseMovement then
		local v119 = p117.Delta
		v_u_47.Movement = Vector2.new(v119.X, v119.Y)
	end
end
local function v_u_124(p121, p122) -- name: inputEnded
	-- upvalues: (ref) v_u_94, (ref) v_u_44
	if p121.UserInputType == Enum.UserInputType.Touch then
		v_u_94(p121, p122)
	elseif p121.UserInputType == Enum.UserInputType.MouseButton2 then
		local v123 = v_u_44 - 1
		v_u_44 = math.max(0, v123)
	end
end
local v_u_125 = false
function v42.setInputEnabled(p126) -- name: setInputEnabled
	-- upvalues: (ref) v_u_125, (copy) v_u_80, (ref) v_u_107, (copy) v_u_1, (copy) v_u_65, (copy) v_u_14, (copy) v_u_12, (copy) v_u_68, (copy) v_u_71, (copy) v_u_5, (copy) v_u_75, (copy) v_u_73, (ref) v_u_43, (copy) v_u_2, (copy) v_u_116, (copy) v_u_120, (copy) v_u_124, (copy) v_u_112, (copy) v_u_6
	if v_u_125 == p126 then
		return
	else
		v_u_125 = p126
		v_u_80()
		v_u_107()
		if v_u_125 then
			v_u_1:BindActionAtPriority("RbxCameraThumbstick", v_u_65, false, v_u_14, Enum.KeyCode.Thumbstick2)
			if v_u_12 then
				v_u_1:BindActionAtPriority("RbxCameraDirectionalButtons", v_u_68, false, v_u_14, Enum.KeyCode.ButtonLeft, Enum.KeyCode.ButtonRight)
			end
			v_u_1:BindActionAtPriority("RbxCameraKeypress", v_u_71, false, v_u_14, Enum.KeyCode.Left, Enum.KeyCode.Right, Enum.KeyCode.I, Enum.KeyCode.O)
			if v_u_5.VREnabled then
				v_u_1:BindAction("RbxCameraGamepadReset", v_u_75, false, Enum.KeyCode.ButtonL3)
			end
			v_u_1:BindAction("RbxCameraGamepadZoom", v_u_73, false, Enum.KeyCode.ButtonR3)
			local v127 = v_u_43
			local v128 = v_u_2.InputBegan
			local v129 = v_u_116
			table.insert(v127, v128:Connect(v129))
			local v130 = v_u_43
			local v131 = v_u_2.InputChanged
			local v132 = v_u_120
			table.insert(v130, v131:Connect(v132))
			local v133 = v_u_43
			local v134 = v_u_2.InputEnded
			local v135 = v_u_124
			table.insert(v133, v134:Connect(v135))
			local v136 = v_u_43
			local v137 = v_u_2.PointerAction
			local v138 = v_u_112
			table.insert(v136, v137:Connect(v138))
			local v139 = v_u_43
			local v140 = v_u_6.MenuOpened
			local v141 = v_u_107
			table.insert(v139, v140:connect(v141))
		else
			v_u_1:UnbindAction("RbxCameraThumbstick")
			if v_u_12 then
				v_u_1:UnbindAction("RbxCameraDirectionalButtons")
			end
			v_u_1:UnbindAction("RbxCameraMouseMove")
			v_u_1:UnbindAction("RbxCameraMouseWheel")
			v_u_1:UnbindAction("RbxCameraKeypress")
			v_u_1:UnbindAction("RbxCameraGamepadZoom")
			if v_u_5.VREnabled then
				v_u_1:UnbindAction("RbxCameraGamepadReset")
			end
			for _, v142 in pairs(v_u_43) do
				v142:Disconnect()
			end
			v_u_43 = {}
		end
	end
end
function v42.getInputEnabled() -- name: getInputEnabled
	-- upvalues: (ref) v_u_125
	return v_u_125
end
function v42.resetInputForFrameEnd() -- name: resetInputForFrameEnd
	-- upvalues: (copy) v_u_47, (copy) v_u_48
	v_u_47.Movement = Vector2.new()
	v_u_48.Move = Vector2.new()
	v_u_48.Pinch = 0
	v_u_47.Wheel = 0
	v_u_47.Pan = Vector2.new()
	v_u_47.Pinch = 0
end
v_u_2.WindowFocused:Connect(v_u_80)
v_u_2.WindowFocusReleased:Connect(v_u_80)
if v10 then
	v_u_2.TextBoxFocusReleased:Connect(v_u_80)
end
local v_u_143 = false
local v_u_144 = false
local v_u_145 = 0
function v42.getHoldPan() -- name: getHoldPan
	-- upvalues: (ref) v_u_143
	return v_u_143
end
function v42.getTogglePan() -- name: getTogglePan
	-- upvalues: (ref) v_u_144
	return v_u_144
end
function v42.getPanning() -- name: getPanning
	-- upvalues: (ref) v_u_144, (ref) v_u_143
	return v_u_144 or v_u_143
end
function v42.setTogglePan(p146) -- name: setTogglePan
	-- upvalues: (ref) v_u_144
	v_u_144 = p146
end
local v_u_147 = false
local v_u_148 = nil
local v_u_149 = nil
function v42.enableCameraToggleInput() -- name: enableCameraToggleInput
	-- upvalues: (ref) v_u_147, (ref) v_u_143, (ref) v_u_144, (ref) v_u_148, (ref) v_u_149, (ref) v_u_21, (ref) v_u_145, (ref) v_u_22, (copy) v_u_2
	if not v_u_147 then
		v_u_147 = true
		v_u_143 = false
		v_u_144 = false
		if v_u_148 then
			v_u_148:Disconnect()
		end
		if v_u_149 then
			v_u_149:Disconnect()
		end
		v_u_148 = v_u_21:Connect(function()
			-- upvalues: (ref) v_u_143, (ref) v_u_145
			v_u_143 = true
			v_u_145 = tick()
		end)
		v_u_149 = v_u_22:Connect(function()
			-- upvalues: (ref) v_u_143, (ref) v_u_145, (ref) v_u_144, (ref) v_u_2
			v_u_143 = false
			if tick() - v_u_145 < 0.3 and (v_u_144 or v_u_2:GetMouseDelta().Magnitude < 2) then
				v_u_144 = not v_u_144
			end
		end)
	end
end
function v42.disableCameraToggleInput() -- name: disableCameraToggleInput
	-- upvalues: (ref) v_u_147, (ref) v_u_148, (ref) v_u_149
	if v_u_147 then
		v_u_147 = false
		if v_u_148 then
			v_u_148:Disconnect()
			v_u_148 = nil
		end
		if v_u_149 then
			v_u_149:Disconnect()
			v_u_149 = nil
		end
	end
end
return v42