-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Character.KoganeController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game:GetService("TextChatService")
local v_u_6 = game:GetService("MarketplaceService")
local v_u_7 = game.Players.LocalPlayer
local v8 = game.ReplicatedStorage
local v_u_9 = v8.Animations
local v_u_10 = v8.Utils
local v_u_11 = v8.Sounds
local v_u_12 = v_u_1.CreateController({
	["Name"] = "KoganeController"
})
local v_u_13 = workspace.CurrentCamera
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = nil
local v_u_18 = nil
local v_u_19 = nil
local function v_u_33() -- name: koganeScreen
	-- upvalues: (ref) v_u_19, (copy) v_u_10, (ref) v_u_14, (copy) v_u_11, (copy) v_u_4, (copy) v_u_7
	v_u_19 = v_u_10.Kogane.Shenanigans:Clone()
	local v_u_20 = v_u_19.Screen
	v_u_14:PlaySound(v_u_11.Kogane.ShenanigansUI, workspace, game.SoundService.Effect)
	local function v_u_28(p_u_21, p_u_22) -- name: noiseEffect
		-- upvalues: (copy) v_u_20, (ref) v_u_4
		local v_u_23 = v_u_20.NoiseEffect.ImageLabel
		local v_u_24 = v_u_20.Topbar
		local v_u_25 = v_u_20.List
		v_u_24.Visible = not p_u_22
		v_u_25.Visible = not p_u_22
		v_u_23.Parent.Visible = true
		if p_u_22 then
			v_u_23.ImageTransparency = 0.5
			v_u_4:Create(v_u_23, TweenInfo.new(p_u_21), {
				["ImageTransparency"] = 1
			}):Play()
		else
			v_u_4:Create(v_u_23, TweenInfo.new(p_u_21), {
				["ImageTransparency"] = 0.5
			}):Play()
		end
		task.spawn(function()
			-- upvalues: (copy) p_u_21, (copy) v_u_23
			local v26 = 0
			while v26 < p_u_21 do
				v26 = v26 + task.wait()
				local v27 = v_u_23
				v27.Rotation = v27.Rotation + 180
				v_u_23.Position = UDim2.new(0.5, math.random(-100, 100), 0.5, math.random(-100, 100))
			end
			v_u_23.Parent.Visible = false
		end)
		task.delay(p_u_22 and p_u_21 / 2 or 0.1, function()
			-- upvalues: (copy) v_u_24, (copy) p_u_22, (copy) v_u_25
			v_u_24.Visible = p_u_22
			v_u_25.Visible = p_u_22
		end)
	end
	local v29 = v_u_20.Size
	v_u_20.Size = UDim2.new(0.1, 0, 0, 0)
	v_u_20.KoganeTop.Size = UDim2.fromScale(1, 0.3)
	v_u_20.KoganeBottom.Size = UDim2.fromScale(1, 0.5)
	v_u_20.BackgroundTransparency = 1
	v_u_20.UIShadow.Enabled = false
	v_u_20.InnerGlow.Visible = false
	v_u_19.Parent = v_u_7.PlayerGui
	v_u_4:Create(v_u_20, TweenInfo.new(0.2), {
		["Size"] = UDim2.new(v29.X.Scale, v29.X.Offset, 0, 0)
	}):Play()
	v_u_4:Create(v_u_20.KoganeTop, TweenInfo.new(0.2), {
		["Size"] = UDim2.new(1.85, 0, 0.3, 0)
	}):Play()
	v_u_4:Create(v_u_20.KoganeBottom, TweenInfo.new(0.2), {
		["Size"] = UDim2.new(1.85, 0, 0.5, 0)
	}):Play()
	task.wait(0.2)
	v_u_20.BackgroundTransparency = 0.2
	v_u_20.UIShadow.Enabled = true
	v_u_20.InnerGlow.Visible = true
	v_u_4:Create(v_u_20, TweenInfo.new(0.4, Enum.EasingStyle.Back), {
		["Size"] = v29
	}):Play()
	v_u_28(0.4, true)
	local function v_u_31() -- name: closeUI
		-- upvalues: (copy) v_u_20, (ref) v_u_4, (copy) v_u_28, (ref) v_u_19
		local v30 = v_u_20.Size
		v_u_4:Create(v_u_20, TweenInfo.new(0.4, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
			["Size"] = UDim2.new(v30.X.Scale, v30.X.Offset, 0, 0)
		}):Play()
		v_u_28(0.5, false)
		task.wait(0.4)
		v_u_20.BackgroundTransparency = 1
		v_u_20.UIShadow.Enabled = false
		v_u_20.InnerGlow.Visible = false
		v_u_4:Create(v_u_20, TweenInfo.new(0.2), {
			["Size"] = UDim2.new(0.15, 0, 0, 0)
		}):Play()
		v_u_4:Create(v_u_20.KoganeTop, TweenInfo.new(0.2), {
			["Size"] = UDim2.new(1, 0, 0.3, 0)
		}):Play()
		v_u_4:Create(v_u_20.KoganeBottom, TweenInfo.new(0.2), {
			["Size"] = UDim2.new(1, 0, 0.5, 0)
		}):Play()
		v_u_4:Create(v_u_20, TweenInfo.new(1), {
			["Position"] = nil,
			["Rotation"] = 45,
			["Position"] = UDim2.new(1.2, 0, -0.2, 0)
		}):Play()
		task.wait(1)
		v_u_19:Destroy()
		v_u_19 = nil
	end
	local v_u_32 = v_u_20.Topbar.Close
	v_u_32.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_32, (ref) v_u_14, (ref) v_u_11
		v_u_32.Text = "[X]"
		v_u_14:PlaySound(v_u_11.Misc.UI.Hover, workspace, game.SoundService.Effect)
	end)
	v_u_32.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_32
		v_u_32.Text = "[x]"
	end)
	v_u_32.MouseButton1Click:Connect(v_u_31)
	v_u_32:GetPropertyChangedSignal("Visible"):Once(function()
		-- upvalues: (copy) v_u_31
		v_u_31()
	end)
	return v_u_20
end
function v_u_12.ShenanigansList(_, p34, p35) -- name: ShenanigansList
	-- upvalues: (ref) v_u_19, (ref) v_u_15, (copy) v_u_33, (ref) v_u_14, (copy) v_u_11, (ref) v_u_17, (copy) v_u_4, (copy) v_u_3
	if not v_u_19 then
		v_u_15.IconButton:deselect()
		local v_u_36 = v_u_33()
		v_u_36.Topbar.Balance.Text = ("[%* POINTS]"):format(p34)
		local v_u_37 = Color3.fromRGB(170, 0, 0)
		for _, v_u_38 in p35 do
			local v_u_39 = v_u_19.Prefabs.Shenanigan:Clone()
			v_u_39.Title.Title.Text = v_u_38.Name
			v_u_39.Description.Text = v_u_38.Description
			local v40 = v_u_38.Cost
			local v_u_41 = v_u_39.Activate
			v_u_41.Text = ("[%*<font size=\"5\">PTS</font>]"):format(v40)
			v_u_41.MouseEnter:Connect(function()
				-- upvalues: (copy) v_u_41, (ref) v_u_14, (ref) v_u_11
				v_u_41.Size = UDim2.fromScale(0.3, 0.3)
				v_u_14:PlaySound(v_u_11.Misc.UI.Hover, workspace, game.SoundService.Effect)
			end)
			v_u_41.MouseLeave:Connect(function()
				-- upvalues: (copy) v_u_41
				v_u_41.Size = UDim2.fromScale(0.25, 0.3)
			end)
			v_u_41.MouseButton1Click:Connect(function()
				-- upvalues: (ref) v_u_17, (copy) v_u_38, (copy) v_u_36, (ref) v_u_14, (ref) v_u_11, (copy) v_u_39, (ref) v_u_4, (ref) v_u_3, (copy) v_u_37
				local v42, v43 = v_u_17:ActivateShenanigans(v_u_38.Name)
				if v43 then
					v_u_36.Topbar.Balance.Text = ("[%* POINTS]"):format(v43)
				end
				if v42 == true then
					v_u_14:PlaySound(v_u_11.Misc.UI.Winner1, workspace, game.SoundService.Effect)
					local v44 = Instance.new("Frame")
					v44.Size = UDim2.fromScale(1, 0)
					v44.AnchorPoint = Vector2.new(0.5, 0.5)
					v44.Position = UDim2.fromScale(0.5, 0.5)
					v44.ZIndex = 10
					v44.BackgroundColor3 = Color3.new(1, 1, 1)
					v44.BorderSizePixel = 0
					v44.Parent = v_u_39
					v_u_4:Create(v44, TweenInfo.new(0.4, Enum.EasingStyle.Back), {
						["Size"] = UDim2.fromScale(1, 1)
					}):Play()
					task.wait(0.3)
					v_u_4:Create(v_u_39, TweenInfo.new(0.1), {
						["Size"] = UDim2.fromScale(1, 0)
					}):Play()
					task.wait(0.1)
					v_u_36.Topbar.Close.Visible = false
					return
				elseif v42 == "CanRepeat" then
					v_u_14:PlaySound(v_u_11.Misc.UI.Winner1, workspace, game.SoundService.Effect)
					local v45 = Instance.new("Frame")
					v45.Size = UDim2.fromScale(1, 0)
					v45.AnchorPoint = Vector2.new(0.5, 0.5)
					v45.Position = UDim2.fromScale(0.5, 0.5)
					v45.ZIndex = 10
					v45.BackgroundColor3 = Color3.new(1, 1, 1)
					v45.BorderSizePixel = 0
					v45.Parent = v_u_39
					v_u_4:Create(v45, TweenInfo.new(0.1, Enum.EasingStyle.Back), {
						["Size"] = UDim2.fromScale(1, 1)
					}):Play()
					task.wait(0.1)
					v_u_4:Create(v45, TweenInfo.new(0.3, Enum.EasingStyle.Back), {
						["Size"] = UDim2.fromScale(1, 0)
					}):Play()
					v_u_3:AddItem(v45, 0.3)
				elseif v42 == "Broke" then
					v_u_14:PlaySound(v_u_11.Misc.UI.Create, workspace, game.SoundService.Effect)
					local v46 = v_u_36.Topbar.Balance
					if v46.TextColor3 == v_u_37 then
						return
					end
					local v47 = v46.TextColor3
					v46.TextColor3 = v_u_37
					task.wait(0.5)
					v46.TextColor3 = v47
				end
			end)
			v_u_39.LayoutOrder = v40
			v_u_39.Parent = v_u_36.List
		end
	end
end
function v_u_12.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_7, (copy) v_u_9, (copy) v_u_4, (ref) v_u_17, (ref) v_u_14, (copy) v_u_11, (copy) v_u_13, (copy) v_u_5, (copy) v_u_10, (copy) v_u_12, (ref) v_u_19, (ref) v_u_15, (copy) v_u_33, (copy) v_u_6, (ref) v_u_18, (copy) v_u_2, (copy) v_u_3
	local v_u_48 = v_u_7.PlayerGui:WaitForChild("Emotes").Emote
	local v_u_49 = v_u_48.Kogane
	local v50 = v_u_49.ViewportFrame
	local v_u_51 = v50.WorldModel.Kogane
	local v52 = Instance.new("Camera")
	v52.Parent = v50.WorldModel
	v52.CFrame = v_u_51.RootPart.CFrame * CFrame.new(0, 0, -10) * CFrame.Angles(0, 3.141592653589793, 0)
	v52.FieldOfView = 17
	v50.CurrentCamera = v52
	local v53 = v_u_51.AnimationController
	local v_u_54 = v53:LoadAnimation(v_u_9.Kogane.Idle)
	v_u_54:Play()
	local v_u_55 = v53:LoadAnimation(v_u_9.Kogane.Appear)
	local v_u_56 = v53:LoadAnimation(v_u_9.Kogane.Spin)
	local v_u_57 = v53:LoadAnimation(v_u_9.Kogane.StartScreen)
	local v_u_58 = v53:LoadAnimation(v_u_9.Kogane.IdleScreen)
	local v_u_59 = v53:LoadAnimation(v_u_9.Kogane.EndScreen)
	v_u_56:GetMarkerReachedSignal("Function"):Connect(function()
		-- upvalues: (copy) v_u_56, (copy) v_u_57, (copy) v_u_58, (ref) v_u_4, (copy) v_u_49
		v_u_56:Stop()
		v_u_57:Play()
		v_u_58:Play()
		v_u_4:Create(v_u_49, TweenInfo.new(0.3), {
			["BackgroundTransparency"] = 0.5
		}):Play()
		v_u_49.Title.Text = "Emotes"
		v_u_49.Title.Visible = true
	end)
	v_u_57:GetMarkerReachedSignal("Function"):Connect(function(_)
		-- upvalues: (copy) v_u_51
		local v60 = v_u_51["Kogane Screen"]
		v60.BodyScreen.Transparency = 0
		v60.Screen.Transparency = 0.25
		v60.body1.Transparency = 0
		v_u_51.BodyTop.Transparency = 1
		v_u_51.BodyMiddle.Transparency = 1
	end)
	v_u_59:GetMarkerReachedSignal("Function"):Connect(function(_)
		-- upvalues: (copy) v_u_51, (ref) v_u_4, (copy) v_u_49
		local v61 = v_u_51["Kogane Screen"]
		v61.BodyScreen.Transparency = 1
		v61.Screen.Transparency = 1
		v61.body1.Transparency = 1
		v_u_51.BodyTop.Transparency = 0
		v_u_51.BodyMiddle.Transparency = 0
		v_u_4:Create(v_u_49, TweenInfo.new(0.3), {
			["BackgroundTransparency"] = 0.5
		}):Play()
		v_u_49.Title.Text = "Kogane"
		v_u_49.Title.Visible = true
	end)
	v_u_48:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (copy) v_u_48, (copy) v_u_58, (copy) v_u_55
		if v_u_48.Visible then
			if not v_u_58.IsPlaying then
				v_u_55:Play()
			end
		end
	end)
	v_u_49.MouseButton1Click:Connect(function()
		-- upvalues: (copy) v_u_48, (ref) v_u_17, (copy) v_u_54, (copy) v_u_55, (copy) v_u_56, (copy) v_u_49, (ref) v_u_4, (copy) v_u_58, (copy) v_u_57, (copy) v_u_59
		v_u_48.KoganeMenu.Visible = not v_u_48.KoganeMenu.Visible
		v_u_48.EmoteMenu.Visible = not v_u_48.KoganeMenu.Visible
		if v_u_48.KoganeMenu.Visible then
			v_u_17.Action:Fire("Spawn")
			v_u_54:Stop()
			v_u_55:Stop()
			v_u_56:Play()
			v_u_56:AdjustSpeed(1.5)
			v_u_49.BackgroundTransparency = 1
			v_u_49.Title.Visible = false
			v_u_4:Create(v_u_49, TweenInfo.new(0.7, Enum.EasingStyle.Circular), {
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.new(0.5, 0, 0.5, 0)
			}):Play()
		else
			v_u_58:Stop()
			v_u_57:Stop()
			v_u_56:Stop()
			v_u_59:Play()
			v_u_59.TimePosition = 0.2
			v_u_54:Play()
			v_u_49.BackgroundTransparency = 1
			v_u_49.Title.Visible = false
			v_u_4:Create(v_u_49, TweenInfo.new(0.3), {
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.new(1.2, 0, 0.5, 0)
			}):Play()
		end
	end)
	v_u_48.KoganeMenu.Pet.MouseButton1Click:Connect(function()
		-- upvalues: (ref) v_u_17
		v_u_17.Action:Fire("Pet")
	end)
	v_u_48.KoganeMenu.Leaderboard.MouseButton1Click:Connect(function()
		-- upvalues: (ref) v_u_17
		v_u_17.Action:Fire("Leaderboard")
	end)
	v_u_48.KoganeMenu.Shenanigans.MouseButton1Click:Connect(function()
		-- upvalues: (ref) v_u_17
		v_u_17.Action:Fire("Shenanigans")
	end)
	v_u_48.KoganeMenu.Playlist.MouseButton1Click:Connect(function()
		-- upvalues: (ref) v_u_17
		v_u_17.Action:Fire("Playlist")
	end)
	local v_u_62 = false
	local v_u_63 = {
		["Enabled"] = false,
		["NPCs"] = false,
		["Shuffle"] = false,
		["Time"] = 15,
		["List"] = nil,
		["List"] = {}
	}
	local v_u_64 = v_u_7
	local v_u_65 = {}
	local v_u_129 = {
		["Interpolation"] = function(p_u_66)
			-- upvalues: (ref) v_u_14, (ref) v_u_11, (ref) v_u_13, (ref) v_u_4
			local v_u_67 = p_u_66.Rig.RootPart
			local v_u_68 = CFrame.Angles(0.5235987755982988, 0, 0)
			p_u_66.Ring:Emit(5)
			p_u_66.Smoke:Emit(12)
			v_u_14:PlaySound(v_u_11.Kogane.Appear, p_u_66, game.SoundService.Effect)
			v_u_14:PlaySound(v_u_11.Kogane.Disappear, p_u_66, game.SoundService.Effect)
			v_u_67.Fly.Playing = true
			v_u_67.CFrame = p_u_66.CFrame * v_u_68
			p_u_66:GetPropertyChangedSignal("CFrame"):Connect(function()
				-- upvalues: (copy) p_u_66, (ref) v_u_13, (copy) v_u_68, (ref) v_u_4, (copy) v_u_67
				local v69 = p_u_66.CFrame
				if p_u_66.Info:FindFirstChild("LookAtCamera") then
					v69 = CFrame.lookAt(v69.Position, v_u_13.CFrame.Position)
				end
				local v70 = {
					["CFrame"] = v69 * v_u_68
				}
				v_u_4:Create(v_u_67, TweenInfo.new(0.35), v70):Play()
			end)
			p_u_66.Info.ChildAdded:Connect(function(p71)
				-- upvalues: (copy) p_u_66, (ref) v_u_13
				if p71.Name == "LookAtCamera" then
					while p71.Parent do
						task.wait()
						p_u_66.CFrame = CFrame.lookAt(p_u_66.Position, v_u_13.CFrame.Position)
					end
				end
			end)
		end,
		["TweenSize"] = function(p72, p73)
			local v74 = p72.Rig
			local v75 = p72.Info:FindFirstChild("ResizeSingleton")
			if v75 then
				v75:Destroy()
			end
			local v76 = Instance.new("Folder", p72.Info)
			v76.Name = "ResizeSingleton"
			local v77 = v74:GetScale()
			local v78 = tick()
			task.wait()
			if v76.Parent then
				local v79 = (tick() - v78) / 0.5
				v74:ScaleTo(v77 + math.clamp(v79, 0, 1) * (p73 - v77))
				if tick() - v78 < 0.5 then
					continue
				end
			end
			if v76.Parent then
				v74:ScaleTo(p73)
				v76:Destroy()
			end
		end,
		["PlaySound"] = function(p80, p81)
			-- upvalues: (ref) v_u_14, (ref) v_u_11
			if p80.Parent then
				v_u_14:PlaySound(v_u_11.Kogane[p81], p80, game.SoundService.Effect)
			end
		end,
		["Despawn"] = function(p82)
			-- upvalues: (ref) v_u_14, (ref) v_u_11
			p82.Rig:Destroy()
			p82.Ring:Emit(5)
			p82.Smoke:Emit(12)
			v_u_14:PlaySound(v_u_11.Kogane.Disappear, p82, game.SoundService.Effect)
		end,
		["Speak"] = function(p83, p84)
			-- upvalues: (ref) v_u_5, (ref) v_u_14, (ref) v_u_11
			v_u_5:DisplayBubble(p83.Rig.RootPart, p84)
			v_u_14:PlaySound(v_u_11.Kogane.Dabaesaba, p83, game.SoundService.Effect)
		end,
		["Sad"] = function(p85)
			-- upvalues: (ref) v_u_14, (ref) v_u_11
			v_u_14:PlaySound(v_u_11.Kogane.Sad, p85, game.SoundService.Effect)
		end,
		["LeaderboardStats"] = function(p86, p87, p88)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v89 = p86.Rig["Kogane Screen"].Screen
			local v_u_90 = v_u_10.Kogane.SurfaceGui:Clone()
			v_u_90.Parent = v_u_7.PlayerGui
			v_u_90.Adornee = v89
			v_u_90.Enabled = true
			for v91, v92 in p87 do
				local v93 = game.Players:GetPlayerByUserId(v91)
				if not v93 then
					continue
				end
				local v_u_94 = v_u_90.Configuration.PlayerInfo:Clone()
				v_u_94.Username.Text = v93.Name
				v_u_94.Stats.Points.Value.Text = v92[1]
				v_u_94.Stats.Elo.Value.Text = v92[2]
				v_u_94.Stats.Completion.Value.Text = ("%*%%"):format(v92[3])
				v_u_94.LayoutOrder = -v92[1]
				v_u_94.Stickman.Image = "rbxassetid://94174511682459"
				v_u_94.Parent = v_u_90.List
				local v_u_95 = nil
				v_u_95 = v93.CharacterAdded:Connect(function(p96)
					-- upvalues: (copy) v_u_90, (ref) v_u_95, (copy) v_u_94
					if v_u_90.Parent then
						v_u_94.Stickman.Image = "rbxassetid://103206767162326"
						p96:GetAttributeChangedSignal("Dead"):Once(function()
							-- upvalues: (ref) v_u_90, (ref) v_u_94
							if v_u_90.Parent then
								v_u_94.Stickman.Image = "rbxassetid://94174511682459"
							end
						end)
					else
						v_u_95:Disconnect()
					end
				end)
				if not v93.Character then
					continue
				end
				local v97 = v93.Character
				v_u_94.Stickman.Image = "rbxassetid://103206767162326"
				v97:GetAttributeChangedSignal("Dead"):Once(function()
					-- upvalues: (copy) v_u_90, (copy) v_u_94
					if v_u_90.Parent then
						v_u_94.Stickman.Image = "rbxassetid://94174511682459"
					end
				end)
			end
			p88.AncestryChanged:Once(function()
				-- upvalues: (copy) v_u_90
				v_u_90:Destroy()
			end)
		end,
		["Shenanigans"] = function(p98, p99)
			-- upvalues: (ref) v_u_12
			v_u_12:ShenanigansList(p98, p99)
		end,
		["UpdatePetTimer"] = function(p100)
			-- upvalues: (copy) v_u_48, (ref) v_u_62
			local v101 = v_u_48.KoganeMenu.Pet.Title.Timer
			if p100 > 86400 then
				v101.Text = "[CLAIM]"
				return
			elseif v_u_62 then
				v_u_62 = p100
			else
				v_u_62 = p100
				while v_u_62 < 86400 do
					local v102 = 86400 - v_u_62
					local v103 = v102 / 3600
					local v104 = math.floor(v103)
					local v105 = v102 - v104 * 3600
					local v106 = v105 / 60
					local v107 = math.floor(v106)
					v101.Text = ("[%*:%*:%*]"):format(v104, v107, v105 - v107 * 60)
					v_u_62 = v_u_62 + 1
					task.wait(1)
				end
				v_u_62 = false
				v101.Text = "[CLAIM]"
			end
		end,
		["Playlist"] = function()
			-- upvalues: (ref) v_u_19, (ref) v_u_15, (ref) v_u_33, (ref) v_u_63, (ref) v_u_17, (ref) v_u_6, (ref) v_u_14, (ref) v_u_11
			if not v_u_19 then
				v_u_15.IconButton:deselect()
				local v_u_108 = v_u_33()
				v_u_108.Topbar.ListIcon:Destroy()
				v_u_108.Topbar.Balance:Destroy()
				v_u_108.Topbar.Title:Destroy()
				for _, v109 in v_u_108.Parent.Prefabs.Playlist:GetChildren() do
					local v_u_110 = v109:Clone()
					v_u_110.Parent = v_u_108.Topbar
					if v_u_110:FindFirstChild("Toggle") and v_u_63[v_u_110.Name] ~= nil then
						if v_u_63[v_u_110.Name] == true then
							v_u_110.Toggle.Side.Position = UDim2.new(0.5, 0, 0, 0)
							v_u_110.Toggle.Side.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
						end
						v_u_110.Toggle.Side.MouseButton1Click:Connect(function()
							-- upvalues: (ref) v_u_63, (copy) v_u_110, (ref) v_u_17
							v_u_63[v_u_110.Name] = not v_u_63[v_u_110.Name]
							if v_u_63[v_u_110.Name] == true then
								v_u_110.Toggle.Side.Position = UDim2.new(0.5, 0, 0, 0)
								v_u_110.Toggle.Side.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							else
								v_u_110.Toggle.Side.Position = UDim2.new(0, 0, 0, 0)
								v_u_110.Toggle.Side.BackgroundColor3 = Color3.fromRGB(44, 74, 29)
							end
							v_u_17.Playlist:Fire(v_u_63)
						end)
					else
						if not v_u_110:FindFirstChild("TextBox") or v_u_63[v_u_110.Name] == nil then
							continue
						end
						v_u_110.TextBox.Text = v_u_63[v_u_110.Name]
						v_u_110.TextBox.FocusLost:Connect(function(_)
							-- upvalues: (ref) v_u_63, (copy) v_u_110, (ref) v_u_17
							local v111 = v_u_63
							local v112 = v_u_110.Name
							local v113 = v_u_110.TextBox.Text
							v111[v112] = tonumber(v113) or 0
							v_u_110.TextBox.Text = v_u_63[v_u_110.Name]
							v_u_17.Playlist:Fire(v_u_63)
						end)
					end
				end
				local v_u_114 = v_u_108.Parent.Prefabs.MusicInsert:Clone()
				v_u_114.Parent = v_u_108.List
				v_u_114.FocusLost:Connect(function(p115)
					-- upvalues: (copy) v_u_114, (ref) v_u_63, (copy) v_u_108, (ref) v_u_6, (ref) v_u_17, (ref) v_u_14, (ref) v_u_11
					if p115 then
						local v116 = v_u_114.Text
						local v_u_117 = tonumber(v116)
						v_u_114.Text = ""
						if table.find(v_u_63.List, v_u_117) then
							return
						elseif #v_u_63.List > 20 then
							return
						else
							local v_u_118 = v_u_108.Parent.Prefabs.Music:Clone()
							v_u_118.Description.Text = v_u_117
							v_u_118.Parent = v_u_108.List
							local function v119()
								-- upvalues: (ref) v_u_6, (copy) v_u_117
								return v_u_6:GetProductInfo(v_u_117, Enum.InfoType.Asset)
							end
							local v120, v121 = pcall(v119)
							if v120 and v121 then
								v_u_118.Title.Title.Text = string.upper(v121.Name)
								local v122 = v_u_63.List
								table.insert(v122, v_u_117)
								v_u_17.Playlist:Fire(v_u_63)
								v_u_118.Delete.MouseButton1Click:Connect(function()
									-- upvalues: (ref) v_u_63, (copy) v_u_117, (copy) v_u_118, (ref) v_u_17
									local v123 = table.find(v_u_63.List, v_u_117)
									if not v123 then
										v_u_118:Destroy()
									end
									table.remove(v_u_63.List, v123)
									v_u_118:Destroy()
									v_u_17.Playlist:Fire(v_u_63)
								end)
								v_u_118.Delete.MouseEnter:Connect(function()
									-- upvalues: (copy) v_u_118, (ref) v_u_14, (ref) v_u_11
									v_u_118.Delete.Text = "[X]"
									v_u_14:PlaySound(v_u_11.Misc.UI.Hover, workspace, game.SoundService.Effect)
								end)
								v_u_118.Delete.MouseLeave:Connect(function()
									-- upvalues: (copy) v_u_118
									v_u_118.Delete.Text = "[x]"
								end)
							else
								v_u_118:Destroy()
							end
						end
					else
						return
					end
				end)
				for _, v_u_124 in v_u_63.List do
					local v_u_125 = v_u_108.Parent.Prefabs.Music:Clone()
					v_u_125.Description.Text = v_u_124
					v_u_125.Parent = v_u_108.List
					task.spawn(function()
						-- upvalues: (ref) v_u_6, (copy) v_u_124, (copy) v_u_125
						local function v127()
							-- upvalues: (ref) v_u_6, (ref) v_u_124, (ref) v_u_125
							local v126 = v_u_6:GetProductInfo(v_u_124, Enum.InfoType.Asset)
							v_u_125.Title.Title.Text = string.upper(v126.Name)
						end
						pcall(v127)
					end)
					v_u_125.Delete.MouseButton1Click:Connect(function()
						-- upvalues: (ref) v_u_63, (copy) v_u_124, (copy) v_u_125, (ref) v_u_17
						local v128 = table.find(v_u_63.List, v_u_124)
						if not v128 then
							v_u_125:Destroy()
						end
						table.remove(v_u_63.List, v128)
						v_u_125:Destroy()
						v_u_17.Playlist:Fire(v_u_63)
					end)
					v_u_125.Delete.MouseEnter:Connect(function()
						-- upvalues: (copy) v_u_125, (ref) v_u_14, (ref) v_u_11
						v_u_125.Delete.Text = "[X]"
						v_u_14:PlaySound(v_u_11.Misc.UI.Hover, workspace, game.SoundService.Effect)
					end)
					v_u_125.Delete.MouseLeave:Connect(function()
						-- upvalues: (copy) v_u_125
						v_u_125.Delete.Text = "[x]"
					end)
				end
			end
		end
	}
	v_u_17.Effects:Connect(function(p130, ...)
		-- upvalues: (copy) v_u_129
		local v131 = v_u_129[p130]
		if v131 then
			v131(...)
		end
	end)
	v_u_17.Playlist:Connect(function(p132, p133)
		-- upvalues: (ref) v_u_7, (ref) v_u_63, (copy) v_u_65
		if p132 == v_u_7 then
			v_u_63 = p133
		else
			v_u_65[p132] = p133
		end
	end)
	game.Players.PlayerRemoving:Connect(function(p134)
		-- upvalues: (copy) v_u_65
		if v_u_65[p134] then
			v_u_65[p134] = nil
		end
	end)
	v_u_18.LastHit:Connect(function(p135)
		-- upvalues: (ref) v_u_64, (ref) v_u_7, (ref) v_u_63
		if p135 == true then
			v_u_64 = v_u_7
			_G.LastHit = -50
			return
		elseif p135:IsA("Model") and p135.Parent == workspace.Characters then
			local v136 = game.Players:GetPlayerFromCharacter(p135)
			if v136 or v_u_63.NPCs ~= false then
				if v136 and v_u_63.Shuffle == true then
					v_u_64 = v136
				else
					v_u_64 = v_u_7
				end
				_G.LastHit = tick()
			end
		else
			v_u_64 = v_u_7
			_G.LastHit = tick()
			return
		end
	end)
	local v_u_137 = nil
	v_u_2.Heartbeat:Connect(function(p138)
		-- upvalues: (ref) v_u_7, (ref) v_u_63, (ref) v_u_137, (copy) v_u_65, (ref) v_u_64, (ref) v_u_4, (ref) v_u_3
		local v139 = v_u_7.Character
		if v139 and (tick() - (_G.LastHit or 0) < v_u_63.Time and v_u_63.Enabled) then
			local v140 = v139:FindFirstChild("HumanoidRootPart")
			if not v_u_137 then
				v_u_137 = Instance.new("Sound")
				v_u_137.Name = "CombatMusic"
				v_u_137.Volume = 0
				v_u_137.Looped = true
				local v141 = v_u_65[v_u_64] or v_u_63.List
				v_u_137.SoundId = "rbxassetid://" .. (#v141 <= 0 and 0 or v141[math.random(1, #v141)])
				v_u_137.SoundGroup = game.SoundService.Music3
				v_u_137.Parent = workspace
				v_u_137:Play()
				v_u_137.DidLoop:Connect(function()
					-- upvalues: (ref) v_u_65, (ref) v_u_64, (ref) v_u_63, (ref) v_u_137
					local v142 = v_u_65[v_u_64] or v_u_63.List
					v_u_137.SoundId = "rbxassetid://" .. (#v142 <= 0 and 0 or v142[math.random(1, #v142)])
					v_u_137:Play()
				end)
			end
			local v143 = nil
			for _, v144 in workspace:GetChildren() do
				if not v144:IsA("Sound") or (v144 == v_u_137 or v144.SoundGroup ~= game.SoundService.Music and v144.SoundGroup ~= game.SoundService.Music2) then
					continue
				end
				v143 = true
			end
			if v143 or v140:FindFirstChild("Music") then
				local v145 = v_u_137
				local v146 = v_u_137.Volume
				v145.Volume = math.lerp(v146, 0, p138)
			else
				local v147 = v_u_137
				local v148 = v_u_137.Volume
				v147.Volume = math.lerp(v148, 1, p138)
			end
		else
			if v_u_137 then
				v_u_4:Create(v_u_137, TweenInfo.new(3), {
					["Volume"] = 0
				}):Play()
				v_u_3:AddItem(v_u_137, 3)
				v_u_137 = nil
			end
			return
		end
	end)
end
function v_u_12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_14, (copy) v_u_1, (ref) v_u_15, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18
	v_u_14 = v_u_1.GetController("FXController")
	v_u_15 = v_u_1.GetController("EmoteController")
	v_u_16 = v_u_1.GetController("AchievementController")
	v_u_17 = v_u_1.GetService("KoganeService")
	v_u_18 = v_u_1.GetService("HandicapService")
end
return v_u_12