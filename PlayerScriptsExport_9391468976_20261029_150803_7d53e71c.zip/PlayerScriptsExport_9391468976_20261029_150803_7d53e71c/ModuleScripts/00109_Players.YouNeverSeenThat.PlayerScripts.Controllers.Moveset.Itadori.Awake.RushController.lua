-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Itadori.Awake.RushController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = RaycastParams.new()
v_u_9.FilterType = Enum.RaycastFilterType.Include
v_u_9.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "RushController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_5, (copy) v_u_2, (copy) v_u_4, (copy) v_u_8, (copy) v_u_9, (copy) v_u_6, (copy) v_u_3, (ref) v_u_12, (ref) v_u_10
	local v_u_62 = {
		["Dash"] = function(p14, p15)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_5, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v16 = p14:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_11:PlaySound(v_u_7.Itadori.Rush.Rush, v16, game.SoundService.Effect)
				local v17 = v_u_5.Utils.Itadori.RushWind:Clone()
				v17.CFrame = v16.CFrame
				v17.Parent = workspace.Effects
				v17.Dust:Emit(7)
				v17.Ring:Emit(7)
				v17.Dash1.Dash:Emit(1)
				v17.Dash2.Dash:Emit(1)
				v_u_2:AddItem(v17, 2)
				if v_u_4.Character == p14 then
					v_u_8.CurrentShaker:Shake(p15 and v_u_8.Presets.LightHit or v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Hit"] = function(_, p18, p19, p20, p21)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (ref) v_u_9
			local v22 = p18:FindFirstChild("HumanoidRootPart")
			if v22 then
				local v23 = p19:FindFirstChild("HumanoidRootPart")
				if v23 then
					v_u_11:Flash(p19, Color3.new(1, 1, 1))
					v_u_11:PlaySound(v_u_7.Itadori.M1:FindFirstChild("Hit1"), v23, game.SoundService.Effect)
					v_u_11:PlaySound(v_u_7.Itadori.Rush.RushHit, v23, game.SoundService.Effect)
					if v_u_4.Character == p18 or v_u_4.Character == p19 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
					if v_u_4.Character ~= p18 then
						local v24 = 65 * task.wait()
						if not workspace:Raycast(v22.Position, p20 * v24, v_u_9) then
							v22.CFrame = v22.CFrame + p20 * v24
						end
						if v22.Parent and p21.Parent then
							continue
						end
					end
				end
			else
				return
			end
		end,
		["FinalHit"] = function(p25, p26)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v27 = p26:FindFirstChild("HumanoidRootPart")
			if v27 then
				v_u_11:Flash(p26, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Itadori.M1:FindFirstChild("Hit2"), v27, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Itadori.Rush.RushBreak, v27, game.SoundService.Effect)
				if v_u_4 == p25 or v_u_4.Character == p26 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
				end
				task.wait(0.2)
				v_u_11:Flash(p26, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Itadori.M1:FindFirstChild("Hit4"), v27, game.SoundService.Effect)
				if v_u_4 == p25 or v_u_4.Character == p26 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["AerialHit"] = function(p28, p29)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (ref) v_u_6, (ref) v_u_2
			local v30 = p28:FindFirstChild("HumanoidRootPart")
			if v30 then
				local v31 = p29:FindFirstChild("HumanoidRootPart")
				if v31 then
					v_u_11:Flash(p29, Color3.new(1, 1, 1))
					v_u_11:PlaySound(v_u_7.Itadori.CraniumSmash.Hit2, v31, game.SoundService.Effect)
					v_u_11:PlaySound(v_u_7.Itadori.Rush.RushLaunch, v30, game.SoundService.Effect)
					if v_u_4.Character == p28 or v_u_4.Character == p29 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
					local v32 = CFrame.new(v31.Position, v30.CFrame * CFrame.new(0, -250, -40).Position)
					local v33 = v_u_6.Gojo.HardHit:Clone()
					v33.CFrame = v32 + v32.LookVector * 4
					v33.Parent = workspace.Effects
					v33.Dust:Emit(5)
					v33.Ring:Emit(5)
					v33.Sparks:Emit(10)
					v_u_2:AddItem(v33, 0.5)
				end
			else
				return
			end
		end,
		["Jump"] = function(p34, p35)
			-- upvalues: (ref) v_u_4, (ref) v_u_3, (ref) v_u_12
			local v36 = p35.Parent.Parent:FindFirstChild("HumanoidRootPart")
			if v36 then
				local v37 = v36.CFrame.LookVector * 5
				if v_u_4.Character == v36.Parent then
					v_u_3:Create(p35, TweenInfo.new(0.5), {
						["P"] = 100000
					}):Play()
					repeat
						p35.Position = p34.Position - v37
						task.wait()
					until not (p35.Parent and p34)
				else
					if v_u_12.lastRecvServer[v36.Parent] ~= nil then
						v_u_12.lastRecvServer[v36.Parent] = false
					end
					local v38 = v36.CFrame - v36.Position + p34.Position - v37
					v36.CFrame = v36.CFrame:Lerp(v38, 0.15)
					task.wait()
					if p35.Parent and p34 then
						continue
					end
				end
			end
		end,
		["JumpBurst"] = function(p39)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7
			local v40 = v_u_6.Itadori.CrushingBlow:Clone()
			v40.Position = p39
			v40.PointLight:Destroy()
			v40.Air:Destroy()
			v40.Parent = workspace.Effects
			v40.Floor.Wind2.Color = ColorSequence.new(Color3.new(1, 0, 0))
			v40.Floor.Sparks.Color = ColorSequence.new(Color3.new(1, 0, 0))
			v40.Floor.Ring:Emit(10)
			v40.Floor.Sparks:Emit(10)
			v40.Floor.Wind2:Emit(8)
			v_u_2:AddItem(v40, 1.5)
			v_u_11:PlaySound(v_u_7.Itadori.CrushingBlow.GroundImpact, v40, game.SoundService.Effect)
		end,
		["Grab"] = function(p41, p42)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v43 = p41:FindFirstChild("HumanoidRootPart")
			if v43 then
				v_u_11:PlaySound(v_u_7.Naoya.Ultimate.Parry, v43, game.SoundService.Effect)
				local v44 = v_u_6.Misc.C.M1.Hit1:Clone()
				v44.Parent = p42["Right Arm"]
				v44.Position = Vector3.new(0, -1, 0)
				for _, v45 in v44:GetDescendants() do
					if not v45:IsA("ParticleEmitter") then
						continue
					end
					v45:Emit(v45:GetAttribute("EmitCount"))
					v45.LockedToPart = true
				end
				v_u_2:AddItem(v44, 0.5)
				if v_u_4.Character == p42 or v_u_4.Character == p41 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Choke"] = function(p46, p47)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v48 = p46:FindFirstChild("HumanoidRootPart")
			if v48 then
				v_u_11:Flash(p46, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Gojo.LapseBlue.Grab, v48, game.SoundService.Effect)
				if v_u_4.Character == p47 or v_u_4.Character == p46 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["Shove"] = function(p49, p50)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v51 = p49:FindFirstChild("HumanoidRootPart")
			if v51 then
				v_u_11:Flash(p49, Color3.new(1, 1, 1))
				v_u_11:Flash(p49, Color3.new(1, 0, 0), 1)
				v_u_11:Flash(p49, Color3.new(0, 0, 0), 2)
				v_u_11:PlaySound(v_u_7.Itadori.Transfer.Eat, v51, game.SoundService.Effect)
				if v_u_4.Character == p50 or v_u_4.Character == p49 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.SnapOh)
				end
			end
		end,
		["Land"] = function(p52)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_11, (ref) v_u_7
			local v53 = p52:FindFirstChild("HumanoidRootPart")
			if v53 then
				local v54 = v_u_6.Naoya.Fall:Clone()
				v54:PivotTo(v53.CFrame)
				v54.Parent = workspace.Effects
				v_u_2:AddItem(v54, 1.5)
				v_u_3:Create(v54.Mesh.Start, TweenInfo.new(0.7, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = nil,
					["Size"] = v54.Mesh.End.Size,
					["CFrame"] = v54.Mesh.End.CFrame
				}):Play()
				v_u_3:Create(v54.Mesh2.Start, TweenInfo.new(1, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = nil,
					["Size"] = v54.Mesh2.End.Size,
					["CFrame"] = v54.Mesh2.End.CFrame
				}):Play()
				v_u_3:Create(v54.Mesh3.Start, TweenInfo.new(1.5, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = nil,
					["Size"] = v54.Mesh3.End.Size,
					["CFrame"] = v54.Mesh3.End.CFrame
				}):Play()
				v54.Mesh.End:Destroy()
				v54.Mesh2.End:Destroy()
				v54.Mesh3.End:Destroy()
				v_u_11:PlaySound(v_u_7.Naoya.Ultimate.Fall, v53, game.SoundService.Effect)
				task.wait(0.5)
				local v55 = v_u_6.Itadori.Switch.Fade:Clone()
				v55.Parent = p52.Torso
				v55.Enabled = true
				v55.TimeScale = 0
				v_u_3:Create(v55, TweenInfo.new(0.7), {
					["TimeScale"] = 1
				}):Play()
				task.wait(1)
				v55.Enabled = false
				v_u_2:AddItem(v55, 1)
			end
		end,
		["Chat"] = function(p56)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2
			local v57 = p56:FindFirstChild("Torso")
			if v57 then
				task.wait(0.7)
				local v58 = v_u_6.Gojo.Dialogue:Clone()
				v58.Parent = v57
				v58.Chat1.Sub.Text = "REMEMBER WHEN I SAID..."
				v58.Chat2.Sub.Text = "WE\'D SEE SOMETHING INTERESTING"
				local v59 = v58.Chat1.Position
				v58.Chat1.Position = v59 - UDim2.new(0, 0, 0.15, 0)
				v_u_3:Create(v58.Chat1, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v59
				}):Play()
				v_u_3:Create(v58.Chat1, TweenInfo.new(0.3), {
					["BackgroundTransparency"] = 0
				}):Play()
				v_u_3:Create(v58.Chat1.Sub, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				task.wait(0.5)
				local v60 = v58.Chat2.Position
				v58.Chat2.Position = v60 - UDim2.new(0, 0, 0.15, 0)
				v_u_3:Create(v58.Chat2, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v60
				}):Play()
				v_u_3:Create(v58.Chat2, TweenInfo.new(0.3), {
					["BackgroundTransparency"] = 0
				}):Play()
				v_u_3:Create(v58.Chat2.Sub, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				task.wait(1)
				v_u_2:AddItem(v58, 0.6)
				for _, v61 in v58:GetDescendants() do
					if v61:IsA("Frame") then
						v_u_3:Create(v61, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["Position"] = nil,
							["BackgroundTransparency"] = 1,
							["Position"] = v61.Position - UDim2.new(0, 0, 0.2, 0)
						}):Play()
					else
						if not v61:IsA("TextLabel") then
							continue
						end
						v_u_3:Create(v61, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["TextTransparency"] = 1
						}):Play()
					end
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p63, ...)
		-- upvalues: (copy) v_u_62
		local v64 = v_u_62[p63]
		if v64 then
			v64(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("RushService")
	v_u_11 = v_u_1.GetController("FXController")
	v_u_12 = v_u_1.GetController("JoinController")
end
return v13