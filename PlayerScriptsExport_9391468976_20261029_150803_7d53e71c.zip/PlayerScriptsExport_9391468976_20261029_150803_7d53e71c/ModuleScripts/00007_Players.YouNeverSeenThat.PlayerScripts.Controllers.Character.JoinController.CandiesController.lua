-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Character.JoinController.CandiesController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v4 = game:GetService("ReplicatedStorage")
game:GetService("MarketplaceService")
local v_u_5 = game.Players.LocalPlayer
local _ = v4.Utils
local v_u_6 = v4.Sounds
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v10 = v_u_1.CreateController({
	["Name"] = "CandiesController"
})
function v10.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_3, (ref) v_u_8, (ref) v_u_7, (ref) v_u_9, (copy) v_u_6
	local v_u_11 = v_u_2.TouchEnabled and v_u_5.PlayerGui:WaitForChild("CandiesMobile") or v_u_5.PlayerGui:WaitForChild("Candies")
	if v_u_11.Name == "CandiesMobile" then
		v_u_5.PlayerGui:WaitForChild("Candies"):Destroy()
	else
		v_u_5.PlayerGui:WaitForChild("CandiesMobile"):Destroy()
	end
	local v_u_12 = v_u_5.PlayerGui:WaitForChild("HalloweenShop")
	local v_u_13 = v_u_11.Amount
	local v_u_14 = v_u_13.Purchase
	local v_u_15 = v_u_13.Icon
	local v_u_16 = v_u_5:GetAttribute("Candies2026")
	local v_u_17
	if v_u_16 then
		v_u_17 = true
	else
		v_u_16 = 0
		v_u_17 = nil
	end
	local v18 = v_u_16
	v_u_13.Text = tostring(v18)
	v_u_5:GetAttributeChangedSignal("Candies2026"):Connect(function()
		-- upvalues: (ref) v_u_16, (ref) v_u_5, (copy) v_u_13, (ref) v_u_17
		v_u_16 = v_u_5:GetAttribute("Candies2026") or 0
		local v19 = v_u_16
		v_u_13.Text = tostring(v19)
		if not v_u_17 then
			v_u_17 = true
		end
	end)
	local v_u_20 = v_u_15.Size
	local v_u_21 = v_u_15.Rotation
	v_u_15.InputBegan:Connect(function(p22)
		-- upvalues: (ref) v_u_3, (copy) v_u_15
		if p22.UserInputType == Enum.UserInputType.MouseMovement then
			v_u_3:Create(v_u_15, TweenInfo.new(0.2), {
				["Size"] = nil,
				["Rotation"] = 20,
				["Size"] = UDim2.fromScale(2.5, 2.5)
			}):Play()
		end
	end)
	v_u_15.InputEnded:Connect(function(p23)
		-- upvalues: (ref) v_u_3, (copy) v_u_15, (copy) v_u_20, (copy) v_u_21
		if p23.UserInputType == Enum.UserInputType.MouseMovement then
			local v24 = {
				["Size"] = v_u_20,
				["Rotation"] = v_u_21
			}
			v_u_3:Create(v_u_15, TweenInfo.new(0.2), v24):Play()
		end
	end)
	local v_u_25 = false
	v_u_15.MouseButton1Click:Connect(function()
		-- upvalues: (ref) v_u_25, (copy) v_u_11, (ref) v_u_3, (copy) v_u_14
		v_u_25 = not v_u_25
		if v_u_11.Name == "CandiesMobile" then
			v_u_3:Create(v_u_14, TweenInfo.new(0.5), {
				["Position"] = UDim2.new(v_u_25 and -1 or 0, 0, 0, -20)
			}):Play()
		else
			v_u_3:Create(v_u_14, TweenInfo.new(0.5), {
				["Position"] = UDim2.new(v_u_25 and 1 or 2, 0, 0, -20)
			}):Play()
		end
	end)
	for _, v_u_26 in v_u_14:GetChildren() do
		if not v_u_26:IsA("TextButton") then
			continue
		end
		v_u_26.InputBegan:Connect(function(p27)
			-- upvalues: (ref) v_u_3, (copy) v_u_26
			if p27.UserInputType == Enum.UserInputType.MouseMovement then
				v_u_3:Create(v_u_26, TweenInfo.new(0.2), {
					["Size"] = nil,
					["TextSize"] = 50,
					["Size"] = UDim2.fromOffset(100, 40)
				}):Play()
			end
		end)
		v_u_26.InputEnded:Connect(function(p28)
			-- upvalues: (ref) v_u_3, (copy) v_u_26
			if p28.UserInputType == Enum.UserInputType.MouseMovement then
				v_u_3:Create(v_u_26, TweenInfo.new(0.2), {
					["Size"] = nil,
					["TextSize"] = 40,
					["Size"] = UDim2.fromOffset(100, 25)
				}):Play()
			end
		end)
		v_u_26.MouseButton1Click:Connect(function()
			-- upvalues: (ref) v_u_8, (copy) v_u_26
			v_u_8.Purchase:Fire(("Candies%*"):format(v_u_26.Name), "Robux")
		end)
	end
	local v_u_29 = v_u_12.Fade
	local v_u_30 = v_u_12.Shop
	local function v_u_32() -- name: fadeDrop
		-- upvalues: (copy) v_u_30, (copy) v_u_29, (ref) v_u_3, (copy) v_u_12
		v_u_30.Parent = v_u_29
		v_u_29.Position = UDim2.new(0, 0, -0.2, 0)
		v_u_29.GroupTransparency = 1
		local v31 = v_u_3:Create(v_u_29, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
			["Position"] = nil,
			["GroupTransparency"] = 0,
			["Position"] = UDim2.new(0, 0, 0, 0)
		})
		v31:Play()
		v31.Completed:Once(function()
			-- upvalues: (ref) v_u_30, (ref) v_u_12
			v_u_30.Parent = v_u_12
		end)
	end
	v_u_7.OpenShop:Connect(function(p_u_33)
		-- upvalues: (copy) v_u_30, (ref) v_u_5, (copy) v_u_32
		if v_u_30.Visible then
			return
		else
			local v_u_34 = v_u_5.Character
			local v_u_35
			if v_u_34 then
				v_u_35 = v_u_34:FindFirstChild("HumanoidRootPart")
			else
				v_u_35 = v_u_34
			end
			if v_u_35 then
				local v36 = v_u_5.PlayerGui:WaitForChild("Menus"):FindFirstChild("Group")
				if v36 then
					local v37 = next
					local v38, v39 = v36:GetChildren()
					local v_u_40 = {}
					for _, v_u_41 in v37, v38, v39 do
						v_u_41.Visible = false
						local v42 = v_u_41:GetPropertyChangedSignal("Visible")
						local function v43()
							-- upvalues: (copy) v_u_41, (ref) v_u_30
							if v_u_41.Visible then
								v_u_30.Visible = false
							end
						end
						table.insert(v_u_40, v42:Connect(v43))
					end
					v_u_30.Visible = true
					v_u_32()
					task.spawn(function()
						-- upvalues: (ref) v_u_30, (copy) v_u_35, (copy) p_u_33, (copy) v_u_34, (copy) v_u_40
						while v_u_30.Visible and ((v_u_35.Position - p_u_33.Position).Magnitude < 12 and (v_u_34.Parent and v_u_35.Parent)) do
							task.wait(0.1)
						end
						v_u_30.Visible = false
						for v44, v45 in next, v_u_40 do
							v45:Disconnect()
							v_u_40[v44] = nil
						end
					end)
				end
			else
				return
			end
		end
	end)
	local v46 = v_u_30.Items.Shop
	v46.Emote.Candy.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_7
		v_u_9:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7.Purchase:Fire("Emote")
	end)
	v46.Skin.Candy.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_7
		v_u_9:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7.Purchase:Fire("Skin")
	end)
	v46.OldEmote.Candy.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_7
		v_u_9:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7.Purchase:Fire("OldEmote")
	end)
	v46.Item.Candy.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_7
		v_u_7.Purchase:Fire("Item")
	end)
end
function v10.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (ref) v_u_8, (ref) v_u_9
	v_u_7 = v_u_1.GetService("CandiesService")
	v_u_8 = v_u_1.GetService("ShopService")
	v_u_9 = v_u_1.GetController("FXController")
end
return v10