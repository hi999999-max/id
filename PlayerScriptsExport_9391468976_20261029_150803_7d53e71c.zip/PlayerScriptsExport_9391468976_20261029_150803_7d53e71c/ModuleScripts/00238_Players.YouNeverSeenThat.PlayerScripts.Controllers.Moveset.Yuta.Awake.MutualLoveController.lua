-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Yuta.Awake.MutualLoveController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local v_u_7 = v_u_6.Animations
local v_u_8 = v_u_6.Utils
local v_u_9 = v_u_6.Sounds
local v_u_10 = require(v_u_6.Modules.CameraShaker)
require(v_u_6.Modules.StaticLightning)
require(v_u_6.Modules.BloodyZee)
local v_u_11 = workspace.CurrentCamera
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "MutualLoveController"
})
function v14.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_9, (copy) v_u_5, (copy) v_u_7, (copy) v_u_4, (copy) v_u_8, (copy) v_u_6, (copy) v_u_3, (copy) v_u_10, (copy) v_u_2, (copy) v_u_11, (ref) v_u_13
	local v_u_15 = Random.new()
	local v_u_235 = {
		["Startup"] = function(p_u_16)
			-- upvalues: (ref) v_u_12, (ref) v_u_9, (ref) v_u_5, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (ref) v_u_6
			local v17 = p_u_16:FindFirstChild("HumanoidRootPart")
			if v17 then
				v_u_12:PlaySound(v_u_9.Yuta.MutualLove.Voice, v17, game.SoundService.Voice)
				v_u_12:DomainBurst(v17)
				local v18 = v_u_5.Character
				if v18 and v18:FindFirstChild("HumanoidRootPart") then
					local v19 = v18:FindFirstChild("HumanoidRootPart")
					if (v17.Position - v19.Position).Magnitude <= 37.5 then
						v_u_12:Domain(p_u_16, function(p20, p21)
							-- upvalues: (copy) p_u_16, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (ref) v_u_6
							local v22 = p_u_16.SetAssets:FindFirstChild("YutaSword")
							local v23
							if v22 and p_u_16:GetAttribute("Sword") then
								v23 = p21.Humanoid:LoadAnimation(v_u_7.Yuta.DomainWarn2)
								local v24 = v22.Sword:Clone()
								v24.Weld.Part0 = p21["Left Arm"]
								v24.Name = "Sword"
								v24.Parent = p21
							else
								v23 = p21.Humanoid:LoadAnimation(v_u_7.Yuta.DomainWarn1)
							end
							v23:Play(0)
							p20.Panel.ImageLabel.Image = "rbxassetid://80698598530653"
							p20.Panel.ImageLabel.Size = UDim2.new(0.8, 0, 0.25, 0)
							p20.Panel.Viewport.LightColor = Color3.fromRGB(255, 255, 255)
							p20.Panel.Viewport.Ambient = Color3.fromRGB(255, 224, 254)
							p20.Panel.Viewport.LightDirection = Vector3.new(0, -1, 0)
							v_u_4:Create(p20.Panel.Viewport, TweenInfo.new(1.5), {
								["LightColor"] = Color3.fromRGB(255, 192, 250),
								["Ambient"] = Color3.fromRGB(255, 181, 254)
							}):Play()
							local v25 = v_u_8.Yuta.MutualLove.YutaRing:Clone()
							for _, v26 in p21["Left Arm"].FingersL:GetChildren() do
								if not v26:IsA("BasePart") or v26.Name ~= "Ring" then
									continue
								end
								v25.Weld.Part0 = v26
							end
							v25.Parent = p21
							local v27 = v_u_6.Utils.Yuta.ElbowRush.MetalArm:Clone()
							v27.Weld.Part0 = p21["Right Arm"]
							v27.Parent = p21
							for _, v28 in p21["Right Arm"].FingersR:GetChildren() do
								if not v28:IsA("BasePart") then
									continue
								end
								v28.Color = Color3.fromRGB(44, 44, 44)
							end
							p21["Right Arm"].FingersR:Destroy()
						end)
					end
				end
			end
		end,
		["Opening"] = function(p29, p30, p_u_31, p_u_32, p33)
			-- upvalues: (ref) v_u_12, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_10, (copy) v_u_15
			local v_u_34 = v_u_12:PlaySound(v_u_9.Yuta.MutualLove.Start, workspace, game.SoundService.Effect)
			local v_u_35 = v_u_12:PlaySound(p33 and v_u_9.Yuta.MutualLove.OSTClash or v_u_9.Yuta.MutualLove.OST, workspace, game.SoundService.Music)
			local v_u_36 = v_u_12:PlaySound(v_u_9.Yuta.MutualLove.AmbianceLoop, workspace, game.SoundService.Effect, true)
			local v_u_37 = v_u_8.Yuta.MutualLove.YutaDomain:Clone()
			v_u_37:PivotTo(p29.CFrame * CFrame.new(0, 14, 0) * CFrame.Angles(0, 0, 1.5707963267948966))
			task.spawn(function()
				-- upvalues: (copy) p_u_31, (copy) v_u_37, (copy) v_u_34, (copy) v_u_35, (copy) v_u_36
				repeat
					task.wait()
				until not (p_u_31.Parent and (p_u_31.Parent.Parent and p_u_31.Parent.Parent.Parent))
				v_u_37:Destroy()
				if v_u_34.Parent then
					v_u_34:Destroy()
				end
				if v_u_35.Parent then
					v_u_35:Destroy()
				end
				if v_u_36.Parent then
					v_u_36:Destroy()
				end
			end)
			local v_u_38 = v_u_37.DomainBG
			local v_u_39 = v_u_38.Color
			v_u_38.Color = Color3.new()
			local v40 = {}
			if not p_u_32 then
				for _, v41 in v_u_38.Props:GetDescendants() do
					if not v41:IsA("BasePart") then
						continue
					end
					v40[v41] = v41.CFrame
					v41.Transparency = 1
					v41.CFrame = v41.CFrame * CFrame.new(0, -20, 0)
				end
			end
			local v42 = v_u_38.Base
			local v43 = v42.Size
			if p_u_32 then
				v_u_37.Parent = p29
			else
				v42.Size = Vector3.new(2, 0, 0)
				for _, v44 in v_u_38.AllBows:GetDescendants() do
					if not v44:IsA("BasePart") then
						continue
					end
					v44.Transparency = 1
				end
				v_u_37.Parent = p29
				local v_u_45 = p30.DomainGround
				v_u_45.Surround.Enabled = true
				v_u_4:Create(v_u_45.Surround, TweenInfo.new(0.8), {
					["ShapePartial"] = 1
				}):Play()
				v_u_3:AddItem(v_u_45, 2)
				task.delay(0.8, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_45, (ref) v_u_12
					v_u_4:Create(v_u_45, TweenInfo.new(0.4), {
						["Transparency"] = 0
					}):Play()
					v_u_12:DomainMapFade(Color3.fromRGB(0, 0, 0), 0.4, 1.6)
				end)
				task.wait(1.5)
				for _, v46 in v_u_38.AllBows:GetChildren() do
					if v46.Name ~= "Bow" then
						continue
					end
					for _, v47 in v46:GetChildren() do
						if v47.Name ~= "Bow1" and v47.Name ~= "Bow2" then
							continue
						end
						local v48 = v47.Name == "Bow2" and 1 or -1
						local v_u_49 = {}
						for _, v50 in v47:GetChildren() do
							if not v50:IsA("BasePart") then
								continue
							end
							local v51 = v50.CFrame:VectorToObjectSpace(v50.CFrame.RightVector * (v50.Size.X / 2 * v48))
							local v52 = v50.Name
							v_u_49[tonumber(v52)] = {
								["Part"] = v50,
								["Original"] = {
									["CFrame"] = v50.CFrame,
									["Size"] = v50.Size
								},
								["Offset"] = v51
							}
							local v53 = v50.Size.Y
							local v54 = v50.Size.Z
							v50.Size = Vector3.new(0, v53, v54)
							v50.Transparency = 1
						end
						task.spawn(function()
							-- upvalues: (copy) v_u_49, (ref) v_u_4
							local v55 = #v_u_49
							for v56 = 1, #v_u_49 do
								if not v_u_49[v56] then
									continue
								end
								local v57 = v_u_49[v56].Part
								local v58 = v_u_49[v56].Original
								local v59 = v_u_49[v56].Offset
								local v60 = v58.CFrame * CFrame.new(-v59)
								local v61 = CFrame.Angles
								local v62 = math.random(-15, 15)
								v57.CFrame = v60 * v61(-1.5707963267948966, math.rad(v62), 0)
								v57.Transparency = 0
								local _ = v56 / v55
								local v63 = v_u_4:Create(v57, TweenInfo.new(0.015), {
									["Size"] = v58.Size,
									["CFrame"] = v58.CFrame
								})
								v63:Play()
								v63.Completed:Wait()
							end
						end)
					end
				end
			end
			task.delay(0.285, function()
				-- upvalues: (copy) p_u_32, (copy) v_u_38, (ref) v_u_4, (ref) v_u_10, (copy) v_u_39, (ref) v_u_15, (ref) v_u_8, (ref) v_u_12, (ref) v_u_9
				local v_u_64 = {}
				if not p_u_32 then
					local v65 = TweenInfo.new(0.3)
					for _, v66 in v_u_38.AllBows:GetDescendants() do
						if not v66:IsA("BasePart") then
							continue
						end
						local v67 = v66:Clone()
						v67.Parent = v66.Parent
						v67.Material = Enum.Material.Plastic
						v67.Color = Color3.new(1, 1, 1)
						v67.CFrame = v66.CFrame
						v67.Size = v66.Size
						v_u_4:Create(v67, v65, {
							["Size"] = nil,
							["Transparency"] = 1,
							["Size"] = v67.Size * Vector3.new(2, 5, 5)
						}):Play()
						table.insert(v_u_64, v67)
					end
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
				end
				task.delay(0.5, function()
					-- upvalues: (copy) v_u_64, (ref) v_u_4, (ref) v_u_38, (ref) v_u_39, (ref) v_u_15, (ref) v_u_8, (ref) v_u_12, (ref) v_u_9
					for _, v68 in v_u_64 do
						v68:Destroy()
					end
					local v69 = {
						["Color"] = v_u_39
					}
					v_u_4:Create(v_u_38, TweenInfo.new(1), v69):Play()
					v_u_38.Stars.Enabled = true
					task.wait(1.2)
					for v_u_70 = 1, v_u_15:NextInteger(30, 40) do
						task.delay(v_u_15:NextNumber(0, 1.5), function()
							-- upvalues: (ref) v_u_8, (ref) v_u_38, (ref) v_u_15, (ref) v_u_12, (ref) v_u_9, (ref) v_u_4, (copy) v_u_70
							local v71 = v_u_8.Yuta.MutualLove.Sword:Clone()
							local v72 = CFrame.lookAlong(v_u_38.Position + Vector3.new(0, 50, 0), Vector3.new(-0, -1, -0))
							local v73 = CFrame.Angles
							local v74 = v_u_15:NextInteger(0, 360)
							v71.CFrame = v72 * v73(0, 0, (math.rad(v74)))
							v71.CFrame = v71.CFrame * CFrame.new(0, v_u_15:NextNumber(40, 120), 0)
							v71.Parent = v_u_38
							v_u_12:PlaySound(v_u_9.Yuta.MutualLove.SwordFall, v71, game.SoundService.Effect).PlaybackSpeed = v_u_15:NextNumber(2, 3)
							v_u_4:Create(v71, TweenInfo.new(0.2), {
								["CFrame"] = v71.CFrame * CFrame.new(0, 0, -(46 + v_u_15:NextNumber(0, 0.7)))
							}):Play()
							task.wait(0.2)
							v71.Blade.Sparks:Emit(10)
							v_u_12:PlaySound(v_u_9.Yuta.MutualLove[("SwordGround%*"):format(v_u_70 % 3 + 1)], v71, game.SoundService.Effect)
							local v75 = v_u_4
							local v76 = TweenInfo.new(0.1)
							local v77 = {}
							local v78 = v71.CFrame
							local v79 = CFrame.Angles
							local v80 = v_u_15:NextNumber(-45, 45)
							v77.CFrame = v78 * v79(math.rad(v80), 0, v_u_15:NextNumber(-45, 45))
							v75:Create(v71, v76, v77):Play()
						end)
					end
				end)
				while v_u_38.Parent do
					local v81 = task.wait()
					if not v_u_38.Parent then
						break
					end
					local v82 = v_u_38.AllBows
					local v83 = v_u_38.AllBows:GetPivot()
					local v84 = CFrame.Angles
					local v85 = 15 * v81
					v82:PivotTo(v83 * v84(0, math.rad(v85), 0))
				end
			end)
			task.wait(1)
			if not p_u_32 then
				v_u_10.CurrentShaker:ShakeSustain(v_u_10.Presets.HeavyHit):StartFadeOut(3)
				v_u_4:Create(v42, TweenInfo.new(2, Enum.EasingStyle.Linear), {
					["Size"] = v43
				}):Play()
				while v42.Size ~= v43 do
					local v86 = (v42.Size * Vector3.new(0, 1, 1)).Magnitude / 2
					for v87, v88 in v40 do
						if v87.Transparency == 0 or (v87.Position - v42.Position).Magnitude > v86 then
							continue
						end
						v87.Transparency = 0
						v_u_4:Create(v87, TweenInfo.new(0.3, Enum.EasingStyle.Circular, Enum.EasingDirection.InOut), {
							["CFrame"] = v88
						}):Play()
					end
					local v89 = Instance.fromExisting(v42)
					v89.Size = Vector3.new(2, 0, 0)
					v89.Position = v89.Position + (v_u_15:NextUnitVector() * Vector3.new(1, 0, 1)).Unit * v86
					v89.Parent = v42
					v_u_4:Create(v89, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, true), {
						["Size"] = Vector3.new(2, 50, 50)
					}):Play()
					v_u_3:AddItem(v89, 0.4)
					task.wait(0.05)
				end
			end
		end,
		["DropSwords"] = function(p90, p91)
			-- upvalues: (ref) v_u_5, (ref) v_u_12, (ref) v_u_9, (copy) v_u_15, (ref) v_u_4
			for v92, v93 in p90 do
				if v_u_5 == p91 then
					v93.Handle.Color = Color3.fromRGB(117, 0, 0)
				end
				v_u_12:PlaySound(v_u_9.Yuta.MutualLove.SwordFall, v93, game.SoundService.Effect).PlaybackSpeed = v_u_15:NextNumber(2, 3)
				v_u_4:Create(v93, TweenInfo.new(0.2), {
					["CFrame"] = v93.CFrame * CFrame.new(0, 0, -(46 + v_u_15:NextNumber(0, 0.7)))
				}):Play()
				task.wait(0.2)
				if not v93.Parent then
					return
				end
				v93.Blade.Sparks:Emit(10)
				v_u_12:PlaySound(v_u_9.Yuta.MutualLove[("SwordGround%*"):format(v92 % 3 + 1)], v93, game.SoundService.Effect)
				local v94 = v_u_4
				local v95 = TweenInfo.new(0.1)
				local v96 = {}
				local v97 = v93.CFrame
				local v98 = CFrame.Angles
				local v99 = v_u_15:NextNumber(-45, 45)
				v96.CFrame = v97 * v98(math.rad(v99), 0, v_u_15:NextNumber(-45, 45))
				v94:Create(v93, v95, v96):Play()
			end
		end,
		["Pickup"] = function(p100)
			-- upvalues: (ref) v_u_12, (ref) v_u_9
			local v101 = p100:FindFirstChild("HumanoidRootPart")
			if v101 then
				v_u_12:PlaySound(v_u_9.Yuta.MutualLove.PickupSword, v101, game.SoundService.Effect)
			end
		end,
		["RunSwing"] = function(p102)
			-- upvalues: (ref) v_u_12, (ref) v_u_9
			local v103 = p102:FindFirstChild("HumanoidRootPart")
			if v103 then
				v_u_12:PlaySound(v_u_9.Yuta.MutualLove.RunSlash, v103, game.SoundService.Effect)
			end
		end,
		["Run"] = function(p104, p105, p_u_106)
			-- upvalues: (ref) v_u_12, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10, (ref) v_u_4, (ref) v_u_2
			local v107 = p104:FindFirstChild("HumanoidRootPart")
			if v107 then
				v_u_12:PlaySound(v_u_9.Hiromi.Sprint, v107, game.SoundService.Effect)
				if v_u_5.Character == p104 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
					local v_u_108 = Instance.new("NumberValue", p105)
					v_u_108.Value = 100
					v_u_4:Create(v_u_108, TweenInfo.new(1.5, Enum.EasingStyle.Sine), {
						["Value"] = 0
					}):Play()
					p_u_106.AncestryChanged:Once(function()
						-- upvalues: (copy) p_u_106, (ref) v_u_4, (copy) v_u_108
						if not p_u_106.Parent then
							v_u_4:Create(v_u_108, TweenInfo.new(0.5), {
								["Value"] = 0
							}):Play()
						end
					end)
					repeat
						p105.Velocity = v107.CFrame.LookVector * v_u_108.Value
						v_u_2.Stepped:Wait()
					until not (p105.Parent and v107.Parent)
				end
			end
		end,
		["SwordHit"] = function(p109, p110)
			-- upvalues: (ref) v_u_12, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3
			local v111 = p109:FindFirstChild("HumanoidRootPart")
			if v111 then
				local v112 = p110:FindFirstChild("HumanoidRootPart")
				if v112 then
					v_u_12:Flash(p110, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_9.Yuta.M1.Hit1, v112, game.SoundService.Effect)
					local v113 = v_u_8.Yuta.SlashHit:Clone()
					v113.CFrame = CFrame.lookAlong(v112.Position, v111.CFrame.LookVector) * CFrame.Angles(0, 0, 1.3089969389957472)
					v113.Parent = workspace.Effects
					v_u_3:AddItem(v113, 0.5)
					v113.Slash:Emit(5)
				end
			else
				return
			end
		end,
		["BigVoice"] = function(p114, p115)
			-- upvalues: (ref) v_u_10, (ref) v_u_8, (ref) v_u_3, (ref) v_u_12, (ref) v_u_9
			if (workspace.CurrentCamera.CFrame.Position - p114).Magnitude < 200 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
				local v116 = v_u_8.Yuta.MutualLove.BigVoice:Clone()
				v116.Position = p114
				v116.Parent = workspace.Effects
				v_u_3:AddItem(v116, 4)
				for _, v117 in v116:GetChildren() do
					v117:Emit(v117:GetAttribute("EmitCount"))
				end
				if p115 == "Plummet" then
					v_u_12:PlaySound(v_u_9.Misc.Items.Voice, workspace, game.SoundService.Effect)
					v_u_12:PlaySound(v_u_9.Yuta.MutualLove.VoiceCrush, workspace, game.SoundService.Voice)
					return
				end
				if p115 == "Die" then
					v_u_12:PlaySound(v_u_9.Misc.Items.Voice, workspace, game.SoundService.Effect)
					v_u_12:PlaySound(v_u_9.Yuta.MutualLove.VoiceDie, workspace, game.SoundService.Voice)
					return
				end
				local v118 = v_u_12:PlaySound(v_u_9.Misc.Items.Voice, workspace, game.SoundService.Effect)
				v118.Volume = v118.Volume * 2
				local v119 = v_u_12:PlaySound(v_u_9.Misc.Items.Voice2, workspace, game.SoundService.Voice)
				v119.Volume = v119.Volume * 2
			end
		end,
		["Shikigami"] = function(p120, p121, p122, p_u_123)
			-- upvalues: (ref) v_u_12, (ref) v_u_9, (ref) v_u_8, (ref) v_u_6, (ref) v_u_4, (copy) v_u_15, (ref) v_u_3
			local v124 = p120:FindFirstChild("HumanoidRootPart")
			if v124 then
				local v_u_125 = p121:FindFirstChild("HumanoidRootPart")
				if v_u_125 then
					local v126 = v124.CFrame
					local v127 = {
						v126.RightVector,
						-v126.RightVector,
						v126.UpVector / 2 + v126.RightVector / 2,
						v126.UpVector / 2 - v126.RightVector / 2
					}
					v_u_12:PlaySound(v_u_9.Yuta.MutualLove.MiniRikaToggle, v124, game.SoundService.Effect)
					local v128 = {}
					for v129 = 1, 4 do
						local v130 = v_u_8.Yuta.MutualLove["Mini Rika"]:Clone()
						v130.Head.CFrame = CFrame.lookAlong(v126.Position + v127[v129] * 4, v126.LookVector)
						v130.Parent = workspace.Effects
						v130.AnimationController.Animator:LoadAnimation(v_u_6.Animations.Yuta.Rika.MiniRikaFly):Play()
						v130.Head.Start.Sparks:Emit(15)
						v130.Head.Start.Sparks2:Emit(10)
						v_u_12:PlaySound(v_u_9.Yuta.MutualLove.MiniRikaFly, v130.Head, game.SoundService.Effect)
						local v131 = { v130.Head, v130.Head.Position }
						table.insert(v128, v131)
					end
					local v132 = tick()
					task.wait()
					local v133 = (tick() - v132) / p122
					local v134 = v_u_4:GetValue(math.clamp(v133, 0, 1), Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
					local v135 = v_u_125.Position
					for v136, v137 in v128 do
						local v138 = v137[2]
						local v139 = v137[1]
						local v140 = (v138 + v135) / 2 + v127[v136] * 20
						local v141 = v138:Lerp(v140, v134):Lerp(v140:Lerp(v135, v134), v134)
						local v142
						if v139.Position:FuzzyEq(v141) then
							v142 = v126.LookVector
						else
							v142 = CFrame.new(v139.Position, v141).LookVector
						end
						v139.CFrame = CFrame.lookAlong(v141, v142)
					end
					if v134 ~= 1 then
						break
					end
					local v_u_143 = v_u_12:PlaySound(v_u_9.Yuta.MutualLove.MiniRikaSwarm, v_u_125, game.SoundService.Effect)
					for _, v_u_144 in v128 do
						task.spawn(function()
							-- upvalues: (ref) v_u_144, (ref) v_u_15, (copy) v_u_125, (copy) p_u_123, (ref) v_u_3
							v_u_144 = v_u_144[1]
							local v145 = v_u_15:NextNumber(0.33, 0.66)
							local v146 = v_u_15:NextNumber(5, 8)
							local v147 = tick()
							local v148 = CFrame.Angles
							local v149 = v_u_15:NextInteger(-45, 45)
							local v150 = math.rad(v149)
							local v151 = v_u_15:NextInteger(-45, 45)
							local v152 = v148(v150, 0, (math.rad(v151)))
							local v153 = task.wait()
							local v154 = v_u_125.Position
							local v155 = CFrame.Angles
							local v156 = 1 / v145 * v153 * 360
							v152 = v152 * v155(0, math.rad(v156), 0)
							v_u_144.CFrame = CFrame.new(v154) * v152 * CFrame.new(0, 0, -v146)
							if v145 <= tick() - v147 then
								local v157 = CFrame.Angles
								local v158 = v_u_15:NextInteger(-45, 45)
								local v159 = math.rad(v158)
								local v160 = v_u_15:NextInteger(-45, 45)
								v152 = v157(v159, 0, (math.rad(v160)))
								v147 = tick()
								v145 = v_u_15:NextNumber(0.33, 0.66)
								v146 = v_u_15:NextNumber(5, 7)
							end
							if p_u_123.Parent and v_u_125.Parent then
								continue
							end
							v_u_144.Start.Sparks:Emit(5)
							v_u_144.Start.Sparks2:Emit(3)
							for _, v161 in v_u_144.Parent:GetDescendants() do
								if v161:IsA("BasePart") then
									v161.Transparency = 1
								else
									if not (v161:IsA("Beam") or v161:IsA("PointLight")) then
										continue
									end
									v161.Enabled = false
								end
							end
							v_u_3:AddItem(v_u_144.Parent, 0.1)
						end)
					end
					p_u_123.AncestryChanged:Once(function()
						-- upvalues: (copy) v_u_143, (ref) v_u_12, (ref) v_u_9, (copy) v_u_125
						v_u_143:Destroy()
						v_u_12:PlaySound(v_u_9.Yuta.MutualLove.MiniRikaToggle, v_u_125, game.SoundService.Effect)
					end)
				end
			else
				return
			end
		end,
		["ShikigamiHit"] = function(p162)
			-- upvalues: (ref) v_u_12, (ref) v_u_9
			local v163 = p162:FindFirstChild("HumanoidRootPart")
			if v163 then
				v_u_12:Flash(p162, Color3.new(1, 1, 1))
				local v164 = v_u_12:PlaySound(v_u_9.Yuta.MutualLove.CleaveSlash, v163, game.SoundService.Effect)
				v164.PlaybackSpeed = 1.8
				v164.Volume = 1
			end
		end,
		["Dodge"] = function(p165)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_12, (ref) v_u_9
			local v166 = p165:FindFirstChild("HumanoidRootPart")
			if v166 then
				local v167 = p165:FindFirstChild("Humanoid")
				if v167 then
					local v168 = v_u_6.Animations.Yuta.Dodges:GetChildren()
					local v169 = v_u_6.Utils.Yuta.MutualLove.Shadow:Clone()
					v169.Parent = workspace.Effects
					v_u_3:AddItem(v169, 1)
					local v170 = next
					local v171, v172 = v169:GetDescendants()
					for _, v173 in v170, v171, v172 do
						if not v173:IsA("BasePart") then
							continue
						end
						v173.CollisionGroup = "Effects"
						v_u_4:Create(v173, TweenInfo.new(0.4), {
							["Transparency"] = 1
						}):Play()
						if not p165:FindFirstChild(v173.Name) then
							continue
						end
						v173.CFrame = p165:FindFirstChild(v173.Name).CFrame
						v173.Anchored = true
					end
					local v174 = next
					local v175, v176 = v167:GetPlayingAnimationTracks()
					for _, v177 in v174, v175, v176 do
						local v178 = v177.Name
						if string.sub(v178, 1, 5) ~= "Dodge" then
							continue
						end
						v177:Stop(0)
					end
					if v_u_5.Character == p165 then
						local v179 = v167:LoadAnimation(v168[math.random(1, #v168)])
						v179.Priority = Enum.AnimationPriority.Action2
						v179:Play(0)
					end
					v_u_12:PlaySound(v_u_9.Yuta.M1.Swing4, v166, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["JLFinisher"] = function(p180)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5
			local v181 = p180:FindFirstChild("HumanoidRootPart")
			if v181 then
				if p180:FindFirstChild("Humanoid") then
					local v_u_182 = v_u_6.Utils.Yuta.MutualLove.Shadow:Clone()
					v_u_182.Parent = workspace.Effects
					v_u_182.HumanoidRootPart.Anchored = true
					v_u_3:AddItem(v_u_182, 2)
					local v183 = next
					local v184, v185 = v_u_182:GetDescendants()
					for _, v186 in v183, v184, v185 do
						if not v186:IsA("BasePart") or v186.Name == "HumanoidRootPart" then
							continue
						end
						v186.CollisionGroup = "Effects"
						v186.Color = Color3.new(1, 1, 1)
						v186.Transparency = 0.5
					end
					task.delay(1, function()
						-- upvalues: (copy) v_u_182, (ref) v_u_4
						local v187 = next
						local v188, v189 = v_u_182:GetDescendants()
						for _, v190 in v187, v188, v189 do
							if not v190:IsA("BasePart") or v190.Name == "HumanoidRootPart" then
								continue
							end
							v_u_4:Create(v190, TweenInfo.new(1), {
								["Transparency"] = 1
							}):Play()
						end
					end)
					v_u_182.HumanoidRootPart.CFrame = v181.CFrame
					local v191 = v_u_182.Humanoid:LoadAnimation(v_u_6.Animations.Yuta.JacobLadderTarget)
					v191.Priority = Enum.AnimationPriority.Action2
					v191:Play(0)
					v_u_4:Create(v_u_182.HumanoidRootPart, TweenInfo.new(2), {
						["CFrame"] = v181.CFrame * CFrame.new(0, 15, 0)
					}):Play()
					if v_u_5.Character == p180 then
						workspace.CurrentCamera.CameraSubject = v_u_182.HumanoidRootPart
					end
				end
			else
				return
			end
		end,
		["Dodge2"] = function(p192)
			-- upvalues: (ref) v_u_5, (ref) v_u_6, (ref) v_u_8, (ref) v_u_3, (ref) v_u_4
			if v_u_5.Character == p192 then
				local v193 = p192:FindFirstChild("HumanoidRootPart")
				if v193 then
					local v194 = v_u_6.Animations.Yuta.Dodges:GetChildren()
					local v195 = v_u_8.Charles.Afterimage:Clone()
					v195.HumanoidRootPart.CFrame = v193.CFrame
					v195.Parent = workspace.Effects
					v_u_3:AddItem(v195, 0.6)
					local v196 = v195.Control:LoadAnimation(v194[math.random(1, #v194)])
					v196.Priority = Enum.AnimationPriority.Action2
					v196:Play(0, nil, 0.6)
					local v197 = Instance.new("Highlight", v195)
					v197.DepthMode = Enum.HighlightDepthMode.Occluded
					v197.FillColor = Color3.new(1, 1, 1)
					v197.FillTransparency = 0.9
					v197.OutlineTransparency = 0.6
					v_u_4:Create(v197, TweenInfo.new(0.4), {
						["OutlineTransparency"] = 1,
						["FillTransparency"] = 1
					}):Play()
					local v198 = next
					local v199, v200 = v195:GetDescendants()
					for _, v201 in v198, v199, v200 do
						if not v201:IsA("BasePart") then
							continue
						end
						v201.CollisionGroup = "Effects"
						v_u_4:Create(v201, TweenInfo.new(0.4), {
							["Transparency"] = 1
						}):Play()
					end
				end
			else
				return
			end
		end,
		["TIBHit"] = function(p202)
			-- upvalues: (ref) v_u_12, (ref) v_u_9
			local v203 = p202:FindFirstChild("HumanoidRootPart")
			if v203 then
				v_u_12:Flash(p202, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_9.Itadori.CraniumSmash.Hit2, v203, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_9.Todo.BruteForce.Hit, v203, game.SoundService.Effect)
			end
		end,
		["Shatter"] = function(p204)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_12, (ref) v_u_9, (ref) v_u_4
			local v205 = v_u_8.Domain:Clone()
			v205.Transparency = 1
			v205.CanCollide = false
			v205.Position = p204
			v205.Shatter.Color = ColorSequence.new(Color3.new(0, 0, 0))
			v205.Parent = workspace.Effects
			v_u_3:AddItem(v205, 3)
			for _, v206 in v205:GetChildren() do
				if v206.Name == "Shatter" then
					v206:Emit(100)
				else
					v206:Destroy()
				end
			end
			v_u_12:PlaySound(v_u_9.Itadori.MalevolantShrine.Shatter, v205, game.SoundService.Effect)
			v205.Transparency = 0
			v205.Color = Color3.new(0, 0, 0)
			v_u_4:Create(v205, TweenInfo.new(0.2), {
				["Transparency"] = 1
			}):Play()
			if _G.Settings.DesPHY then
				if (workspace.CurrentCamera.CFrame.Position - v205.Position).Magnitude > 150 then
					return
				end
				local v207 = Random.new()
				local v208 = TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
				for _ = 1, 80 do
					local v209 = v_u_8.Gojo.Shard:Clone()
					local v210 = v207:NextUnitVector().Unit
					local v211 = math.random(1, 8)
					local v212 = math.random
					v209.Size = Vector3.new(0.1, v211, v212(1, 8))
					v209.CFrame = CFrame.lookAlong(p204, v210) * CFrame.Angles(1.5707963267948966, 0, 0) + v210 * 37.5
					v209.CFrame = v209.CFrame * CFrame.Angles(0, math.random(0, 3.141592653589793), 0)
					v209.Color = Color3.new(0, 0, 0)
					v209.CanCollide = true
					v209.CollisionGroup = "Effects"
					v209.Parent = workspace.Effects
					local v213 = math.random(-50, 50)
					local v214 = math.random(-50, 50)
					local v215 = math.random
					v209.RotVelocity = Vector3.new(v213, v214, v215(-50, 50))
					v209.Transparency = 0
					v209.Material = Enum.Material.Neon
					v_u_4:Create(v209, v208, {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_3:AddItem(v209, 4)
				end
			end
		end,
		["JacobLadder"] = function(p216)
			-- upvalues: (ref) v_u_8, (ref) v_u_12, (ref) v_u_9, (ref) v_u_4, (ref) v_u_11, (ref) v_u_10, (copy) v_u_15
			local v_u_217 = p216:FindFirstChild("HumanoidRootPart")
			if v_u_217 then
				local v_u_218 = v_u_8.Yuta.MutualLove.JLSky:Clone()
				local v219 = v_u_8.Yuta.MutualLove.JLBeam:Clone()
				local v_u_220 = v_u_218:FindFirstChild("SurfaceGui")
				v_u_12:PlaySound(v_u_9.Yuta.JacobLadder, v_u_217, game.SoundService.Effect)
				task.spawn(function()
					-- upvalues: (copy) v_u_220, (ref) v_u_4, (copy) v_u_218, (copy) v_u_217
					for _, v_u_221 in v_u_220:GetChildren() do
						local v_u_222 = v_u_221.Size
						local v_u_223 = TweenInfo.new(0.6)
						v_u_221.Size = UDim2.fromScale(0, 0)
						task.delay(v_u_221:GetAttribute("Delay"), function()
							-- upvalues: (ref) v_u_4, (copy) v_u_221, (copy) v_u_223, (copy) v_u_222
							v_u_4:Create(v_u_221, v_u_223, {
								["Size"] = v_u_222
							}):Play()
						end)
					end
					v_u_218.Parent = workspace.Effects
					v_u_218.Position = v_u_217.Position + Vector3.new(0, 50, 0)
					task.delay(0.6, function()
						-- upvalues: (ref) v_u_218
						v_u_218.Glow.Enabled = true
					end)
					v_u_220.Star.Rotation = 0
					v_u_4:Create(v_u_220.Star, TweenInfo.new(4.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
						["Rotation"] = 485.99999999999994
					}):Play()
					v_u_220.Crosses.Rotation = 0
					v_u_4:Create(v_u_220.Crosses, TweenInfo.new(4.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
						["Rotation"] = -162
					}):Play()
					task.wait(4.5)
					v_u_218.Glow.Enabled = false
					for _, v_u_224 in v_u_220:GetChildren() do
						local v_u_225 = TweenInfo.new(0.4)
						task.delay(0.7 - v_u_224:GetAttribute("Delay"), function()
							-- upvalues: (ref) v_u_4, (copy) v_u_224, (copy) v_u_225
							v_u_4:Create(v_u_224, v_u_225, {
								["Size"] = UDim2.fromScale(0, 0)
							}):Play()
						end)
					end
					task.wait(0.7)
					for _, v226 in v_u_220.Crosses:GetChildren() do
						if not v226:IsA("Frame") then
							continue
						end
						v_u_4:Create(v226, TweenInfo.new(0.2), {
							["Size"] = UDim2.fromScale(0, 0)
						}):Play()
					end
					task.wait(0.2)
					v_u_218:Destroy()
				end)
				for _, v227 in v219:GetDescendants() do
					if not (v227:IsA("ParticleEmitter") or v227:IsA("Beam")) then
						continue
					end
					v227.Enabled = false
				end
				task.wait(2.25)
				v219.Parent = workspace.Effects
				for _, v228 in v219:GetDescendants() do
					if not (v228:IsA("ParticleEmitter") or v228:IsA("Beam")) then
						continue
					end
					if v228:IsA("Beam") then
						local v229 = v228.Width0
						local v230 = v228.Width1
						v228.Width0 = 0
						v228.Width1 = 0
						v_u_4:Create(v228, TweenInfo.new(1), {
							["Width0"] = v229,
							["Width1"] = v230
						}):Play()
					end
					v228.Enabled = true
				end
				v219.Body.Size = Vector3.new(100, 0, 0)
				v_u_4:Create(v219.Body, TweenInfo.new(1), {
					["Size"] = Vector3.new(100, 15, 15)
				}):Play()
				local v231
				if (v_u_11.CFrame.Position - v_u_217.Position).Magnitude < 180 then
					v231 = v_u_10.CurrentShaker:ShakeSustain(v_u_10.Presets.HeavyHit)
				else
					v231 = nil
				end
				local v232 = Instance.new("Highlight")
				v232.FillColor = Color3.new()
				v232.FillTransparency = 0.4
				v232.OutlineTransparency = 1
				v232.Parent = p216
				local v233 = tick()
				task.wait()
				v_u_218.Position = v_u_217.Position + Vector3.new(0, 50, 0)
				v219.Position = v_u_217.Position + Vector3.new(0, 47, 0)
				v219.Body.Position = v_u_217.Position
				if tick() - v233 >= 1 then
					v219.Body.Size = Vector3.new(100, 15, 15) + v_u_15:NextUnitVector() * Vector3.new(0, 3, 3)
				end
				if tick() - v233 < 3 then
					continue
				end
				if v231 then
					v231:StartFadeOut(0.5)
				end
				v_u_4:Create(v219.Body, TweenInfo.new(0.5), {
					["Size"] = Vector3.new(100, 0, 0)
				}):Play()
				for _, v234 in v219:GetDescendants() do
					if v234:IsA("ParticleEmitter") or v234:IsA("Beam") then
						if v234:IsA("Beam") then
							v_u_4:Create(v234, TweenInfo.new(0.5), {
								["Width0"] = 0,
								["Width1"] = 0
							}):Play()
						else
							v234.Enabled = false
						end
					else
						if not (v234:IsA("PointLight") or v234:IsA("SpotLight")) then
							continue
						end
						v_u_4:Create(v234, TweenInfo.new(0.5), {
							["Brightness"] = 0
						}):Play()
					end
				end
				v232:Destroy()
				task.wait(0.5)
				v219:Destroy()
			end
		end
	}
	v_u_13.Effects:Connect(function(p236, ...)
		-- upvalues: (copy) v_u_235
		local v237 = v_u_235[p236]
		if v237 then
			v237(...)
		end
	end)
end
function v14.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_13, (copy) v_u_1, (ref) v_u_12
	v_u_13 = v_u_1.GetService("MutualLoveService")
	v_u_12 = v_u_1.GetController("FXController")
end
return v14