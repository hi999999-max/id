-- Original instance: Players.YouNeverSeenThat.PlayerScripts.PlayerModule.CameraModule.BaseCamera
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v1 = game:GetService("Players")
game:GetService("UserInputService")
local v_u_2 = game:GetService("VRService")
local v_u_3 = UserSettings():GetService("UserGameSettings")
local v4 = script.Parent.Parent:WaitForChild("CommonUtils")
local v_u_5 = require(v4:WaitForChild("ConnectionUtil"))
require(v4:WaitForChild("FlagUtil"))
local v_u_6 = require(script.Parent:WaitForChild("CameraUtils"))
local v_u_7 = require(script.Parent:WaitForChild("ZoomController"))
local v_u_8 = require(script.Parent:WaitForChild("CameraToggleStateController"))
local v_u_9 = require(script.Parent:WaitForChild("CameraInput"))
local v_u_10 = require(script.Parent:WaitForChild("CameraUI"))
local v_u_11 = v1.LocalPlayer
Vector2.new(0, 0)
local v_u_12 = {}
v_u_12.__index = v_u_12
function v_u_12.new() -- name: new
	-- upvalues: (copy) v_u_12, (copy) v_u_5, (copy) v_u_11, (copy) v_u_3
	local v13 = v_u_12
	local v14 = setmetatable({}, v13)
	v14._connections = v_u_5.new()
	v14.gamepadZoomLevels = { 0, 10, 20 }
	v14.FIRST_PERSON_DISTANCE_THRESHOLD = 1
	v14.cameraType = nil
	v14.cameraMovementMode = nil
	v14.lastCameraTransform = nil
	v14.lastUserPanCamera = tick()
	v14.humanoidRootPart = nil
	v14.humanoidCache = {}
	v14.lastSubject = nil
	v14.lastSubjectPosition = Vector3.new(0, 5, 0)
	v14.lastSubjectCFrame = CFrame.new(v14.lastSubjectPosition)
	local v15 = v_u_11.CameraMinZoomDistance
	local v16 = v_u_11.CameraMaxZoomDistance
	v14.currentSubjectDistance = math.clamp(12.5, v15, v16)
	v14.inFirstPerson = false
	v14.inMouseLockedMode = false
	v14.resetCameraAngle = true
	v14.enabled = false
	v14.cameraChangedConn = nil
	v14.shouldUseVRRotation = false
	v14.VRRotationIntensityAvailable = false
	v14.lastVRRotationIntensityCheckTime = 0
	v14.lastVRRotationTime = 0
	v14.vrRotateKeyCooldown = {}
	v14.cameraTranslationConstraints = Vector3.new(1, 1, 1)
	v14.humanoidJumpOrigin = nil
	v14.trackingHumanoid = nil
	v14.cameraFrozen = false
	v14.subjectStateChangedConn = nil
	v14.gamepadZoomPressConnection = nil
	v14.mouseLockOffset = Vector3.new(0, 0, 0)
	v_u_3:SetCameraYInvertVisible()
	v_u_3:SetGamepadCameraSensitivityVisible()
	return v14
end
function v_u_12.GetModuleName(_) -- name: GetModuleName
	return "BaseCamera"
end
function v_u_12._setUpConfigurations(p_u_17) -- name: _setUpConfigurations
	-- upvalues: (copy) v_u_11
	p_u_17._connections:trackConnection("CHARACTER_ADDED", v_u_11.CharacterAdded:Connect(function(p18)
		-- upvalues: (copy) p_u_17
		p_u_17:OnCharacterAdded(p18)
	end))
	p_u_17.humanoidRootPart = nil
	p_u_17._connections:trackConnection("CAMERA_MODE_CHANGED", v_u_11:GetPropertyChangedSignal("CameraMode"):Connect(function()
		-- upvalues: (copy) p_u_17
		p_u_17:OnPlayerCameraPropertyChange()
	end))
	p_u_17._connections:trackConnection("CAMERA_MIN_DISTANCE_CHANGED", v_u_11:GetPropertyChangedSignal("CameraMinZoomDistance"):Connect(function()
		-- upvalues: (copy) p_u_17
		p_u_17:OnPlayerCameraPropertyChange()
	end))
	p_u_17._connections:trackConnection("CAMERA_MAX_DISTANCE_CHANGED", v_u_11:GetPropertyChangedSignal("CameraMaxZoomDistance"):Connect(function()
		-- upvalues: (copy) p_u_17
		p_u_17:OnPlayerCameraPropertyChange()
	end))
	p_u_17:OnPlayerCameraPropertyChange()
end
function v_u_12.OnCharacterAdded(p19, _) -- name: OnCharacterAdded
	p19.resetCameraAngle = p19.resetCameraAngle or p19:GetEnabled()
	p19.humanoidRootPart = nil
end
function v_u_12.GetHumanoidRootPart(p20) -- name: GetHumanoidRootPart
	-- upvalues: (copy) v_u_11
	local v21 = (not p20.humanoidRootPart and v_u_11.Character and true or false) and v_u_11.Character:FindFirstChildOfClass("Humanoid")
	if v21 then
		p20.humanoidRootPart = v21.RootPart
	end
	return p20.humanoidRootPart
end
function v_u_12.GetBodyPartToFollow(_, p22, _) -- name: GetBodyPartToFollow
	if p22:GetState() == Enum.HumanoidStateType.Dead then
		local v23 = p22.Parent
		if v23 and v23:IsA("Model") then
			return v23:FindFirstChild("Head") or p22.RootPart
		end
	end
	return p22.RootPart
end
function v_u_12.GetSubjectCFrame(p24) -- name: GetSubjectCFrame
	local v25 = p24.lastSubjectCFrame
	local v26 = workspace.CurrentCamera
	if v26 then
		v26 = v26.CameraSubject
	end
	if not v26 then
		return v25
	end
	if v26:IsA("Humanoid") then
		local v27 = v26:GetState() == Enum.HumanoidStateType.Dead
		local v28 = v26.CameraOffset
		if p24:GetIsMouseLocked() then
			v28 = Vector3.new()
		end
		local v29 = v26.RootPart
		if v27 and (v26.Parent and v26.Parent:IsA("Model")) then
			v29 = v26.Parent:FindFirstChild("Head") or v29
		end
		if v29 and v29:IsA("BasePart") then
			local v30
			if v26.RigType == Enum.HumanoidRigType.R15 then
				if v26.AutomaticScalingEnabled then
					v30 = Vector3.new(0, 1.5, 0)
					local v31 = v26.RootPart
					if v29 == v31 then
						local v32 = (v31.Size.Y - 2) / 2
						v30 = v30 + Vector3.new(0, v32, 0)
					end
				else
					v30 = Vector3.new(0, 2, 0)
				end
			else
				v30 = Vector3.new(0, 1.5, 0)
			end
			v25 = v29.CFrame * CFrame.new((v27 and Vector3.new(0, 0, 0) or v30) + v28)
		end
	elseif v26:IsA("BasePart") then
		v25 = v26.CFrame
	elseif v26:IsA("Model") then
		if v26.PrimaryPart then
			v25 = v26:GetPrimaryPartCFrame()
		else
			v25 = CFrame.new()
		end
	end
	if v25 then
		p24.lastSubjectCFrame = v25
	end
	return v25
end
function v_u_12.GetSubjectVelocity(_) -- name: GetSubjectVelocity
	local v33 = workspace.CurrentCamera
	if v33 then
		v33 = v33.CameraSubject
	end
	if not v33 then
		return Vector3.new(0, 0, 0)
	end
	if v33:IsA("BasePart") then
		return v33.Velocity
	end
	if v33:IsA("Humanoid") then
		local v34 = v33.RootPart
		if v34 then
			return v34.Velocity
		end
	else
		local v35 = v33:IsA("Model") and v33.PrimaryPart
		if v35 then
			return v35.Velocity
		end
	end
	return Vector3.new(0, 0, 0)
end
function v_u_12.GetSubjectRotVelocity(_) -- name: GetSubjectRotVelocity
	local v36 = workspace.CurrentCamera
	if v36 then
		v36 = v36.CameraSubject
	end
	if not v36 then
		return Vector3.new(0, 0, 0)
	end
	if v36:IsA("BasePart") then
		return v36.RotVelocity
	end
	if v36:IsA("Humanoid") then
		local v37 = v36.RootPart
		if v37 then
			return v37.RotVelocity
		end
	else
		local v38 = v36:IsA("Model") and v36.PrimaryPart
		if v38 then
			return v38.RotVelocity
		end
	end
	return Vector3.new(0, 0, 0)
end
function v_u_12.StepZoom(p39) -- name: StepZoom
	-- upvalues: (copy) v_u_9, (copy) v_u_7
	local v40 = p39.currentSubjectDistance
	local v41 = v_u_9.getZoomDelta()
	if math.abs(v41) > 0 then
		local v42
		if v41 > 0 then
			local v43 = v40 + v41 * (v40 * 0.5 + 1)
			local v44 = p39.FIRST_PERSON_DISTANCE_THRESHOLD
			v42 = math.max(v43, v44)
		else
			local v45 = (v40 + v41) / (1 - v41 * 0.5)
			v42 = math.max(v45, 0.5)
		end
		p39:SetCameraToSubjectDistance(v42 < p39.FIRST_PERSON_DISTANCE_THRESHOLD and 0.5 or v42)
	end
	return v_u_7.GetZoomRadius()
end
function v_u_12.GetSubjectPosition(p46) -- name: GetSubjectPosition
	local v47 = p46.lastSubjectPosition
	local v48 = game.Workspace.CurrentCamera
	if v48 then
		v48 = v48.CameraSubject
	end
	if not v48 then
		return nil
	end
	if v48:IsA("Humanoid") then
		local v49 = v48:GetState() == Enum.HumanoidStateType.Dead
		local v50 = v48.CameraOffset
		if p46:GetIsMouseLocked() then
			v50 = Vector3.new()
		end
		local v51 = v48.RootPart
		if v49 and (v48.Parent and v48.Parent:IsA("Model")) then
			v51 = v48.Parent:FindFirstChild("Head") or v51
		end
		if v51 and v51:IsA("BasePart") then
			local v52
			if v48.RigType == Enum.HumanoidRigType.R15 then
				if v48.AutomaticScalingEnabled then
					v52 = Vector3.new(0, 1.5, 0)
					if v51 == v48.RootPart then
						local v53 = v48.RootPart.Size.Y / 2 - 1
						v52 = v52 + Vector3.new(0, v53, 0)
					end
				else
					v52 = Vector3.new(0, 2, 0)
				end
			else
				v52 = Vector3.new(0, 1.5, 0)
			end
			v47 = v51.CFrame.p + v51.CFrame:vectorToWorldSpace((v49 and Vector3.new(0, 0, 0) or v52) + v50)
		end
	elseif v48:IsA("VehicleSeat") then
		v47 = v48.CFrame.p + v48.CFrame:vectorToWorldSpace(Vector3.new(0, 5, 0))
	elseif v48:IsA("SkateboardPlatform") then
		v47 = v48.CFrame.p + Vector3.new(0, 5, 0)
	elseif v48:IsA("BasePart") then
		v47 = v48.CFrame.p
	elseif v48:IsA("Model") then
		if v48.PrimaryPart then
			v47 = v48:GetPrimaryPartCFrame().p
		else
			v47 = v48:GetModelCFrame().p
		end
	end
	p46.lastSubject = v48
	p46.lastSubjectPosition = v47
	return v47
end
function v_u_12.OnCurrentCameraChanged(p_u_54) -- name: OnCurrentCameraChanged
	if p_u_54.cameraSubjectChangedConn then
		p_u_54.cameraSubjectChangedConn:Disconnect()
		p_u_54.cameraSubjectChangedConn = nil
	end
	local v55 = game.Workspace.CurrentCamera
	if v55 then
		p_u_54.cameraSubjectChangedConn = v55:GetPropertyChangedSignal("CameraSubject"):Connect(function()
			-- upvalues: (copy) p_u_54
			p_u_54:OnNewCameraSubject()
		end)
		p_u_54:OnNewCameraSubject()
	end
end
function v_u_12.OnPlayerCameraPropertyChange(p56) -- name: OnPlayerCameraPropertyChange
	p56:SetCameraToSubjectDistance(p56.currentSubjectDistance)
end
function v_u_12.InputTranslationToCameraAngleChange(_, p57, p58) -- name: InputTranslationToCameraAngleChange
	return p57 * p58
end
function v_u_12.GamepadZoomPress(p59) -- name: GamepadZoomPress
	-- upvalues: (copy) v_u_11
	local v60 = p59:GetCameraToSubjectDistance()
	local v61 = v_u_11.CameraMaxZoomDistance
	for v62 = #p59.gamepadZoomLevels, 1, -1 do
		local v63 = p59.gamepadZoomLevels[v62]
		if v61 < v63 then
			continue
		end
		if v63 < v_u_11.CameraMinZoomDistance then
			v63 = v_u_11.CameraMinZoomDistance
			if v61 == v63 then
				break
			end
		end
		if v63 + (v61 - v63) / 2 < v60 then
			p59:SetCameraToSubjectDistance(v63)
			return
		end
		v61 = v63
	end
	p59:SetCameraToSubjectDistance(p59.gamepadZoomLevels[#p59.gamepadZoomLevels])
end
function v_u_12.Enable(p64, p65) -- name: Enable
	if p64.enabled ~= p65 then
		p64.enabled = p65
		p64:OnEnabledChanged()
	end
end
function v_u_12.OnEnabledChanged(p_u_66) -- name: OnEnabledChanged
	-- upvalues: (copy) v_u_9, (copy) v_u_11
	if p_u_66.enabled then
		p_u_66:_setUpConfigurations()
		v_u_9.setInputEnabled(true)
		p_u_66.gamepadZoomPressConnection = v_u_9.gamepadZoomPress:Connect(function()
			-- upvalues: (copy) p_u_66
			p_u_66:GamepadZoomPress()
		end)
		if v_u_11.CameraMode == Enum.CameraMode.LockFirstPerson then
			p_u_66.currentSubjectDistance = 0.5
			if not p_u_66.inFirstPerson then
				p_u_66:EnterFirstPerson()
			end
		end
		if p_u_66.cameraChangedConn then
			p_u_66.cameraChangedConn:Disconnect()
			p_u_66.cameraChangedConn = nil
		end
		p_u_66.cameraChangedConn = workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
			-- upvalues: (copy) p_u_66
			p_u_66:OnCurrentCameraChanged()
		end)
		p_u_66:OnCurrentCameraChanged()
	else
		p_u_66._connections:disconnectAll()
		v_u_9.setInputEnabled(false)
		if p_u_66.gamepadZoomPressConnection then
			p_u_66.gamepadZoomPressConnection:Disconnect()
			p_u_66.gamepadZoomPressConnection = nil
		end
		p_u_66:Cleanup()
	end
end
function v_u_12.GetEnabled(p67) -- name: GetEnabled
	return p67.enabled
end
function v_u_12.Cleanup(p68) -- name: Cleanup
	-- upvalues: (copy) v_u_6
	if p68.subjectStateChangedConn then
		p68.subjectStateChangedConn:Disconnect()
		p68.subjectStateChangedConn = nil
	end
	if p68.cameraChangedConn then
		p68.cameraChangedConn:Disconnect()
		p68.cameraChangedConn = nil
	end
	p68.lastCameraTransform = nil
	p68.lastSubjectCFrame = nil
	v_u_6.restoreMouseBehavior()
end
function v_u_12.UpdateMouseBehavior(p69) -- name: UpdateMouseBehavior
	-- upvalues: (copy) v_u_3, (copy) v_u_10, (copy) v_u_9, (copy) v_u_8, (copy) v_u_6
	local v70 = v_u_3.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove
	if p69.isCameraToggle and v70 == false then
		v_u_10.setCameraModeToastEnabled(true)
		v_u_9.enableCameraToggleInput()
		v_u_8(p69.inFirstPerson)
		return
	else
		v_u_10.setCameraModeToastEnabled(false)
		v_u_9.disableCameraToggleInput()
		if p69.inFirstPerson or p69.inMouseLockedMode then
			v_u_6.setRotationTypeOverride(Enum.RotationType.CameraRelative)
			v_u_6.setMouseBehaviorOverride(Enum.MouseBehavior.LockCenter)
			return
		else
			v_u_6.restoreRotationType()
			if v_u_9.getRotationActivated() then
				v_u_6.setMouseBehaviorOverride(Enum.MouseBehavior.LockCurrentPosition)
			else
				v_u_6.restoreMouseBehavior()
			end
		end
	end
end
function v_u_12.UpdateForDistancePropertyChange(p71) -- name: UpdateForDistancePropertyChange
	p71:SetCameraToSubjectDistance(p71.currentSubjectDistance)
end
function v_u_12.SetCameraToSubjectDistance(p72, p73) -- name: SetCameraToSubjectDistance
	-- upvalues: (copy) v_u_11, (copy) v_u_7
	local v74 = p72.currentSubjectDistance
	if v_u_11.CameraMode == Enum.CameraMode.LockFirstPerson then
		p72.currentSubjectDistance = 0.5
		if not p72.inFirstPerson then
			p72:EnterFirstPerson()
		end
	else
		local v75 = v_u_11.CameraMinZoomDistance
		local v76 = v_u_11.CameraMaxZoomDistance
		local v77 = math.clamp(p73, v75, v76)
		if v77 < 1 then
			p72.currentSubjectDistance = 0.5
			if not p72.inFirstPerson then
				p72:EnterFirstPerson()
			end
		else
			p72.currentSubjectDistance = v77
			if p72.inFirstPerson then
				p72:LeaveFirstPerson()
			end
		end
	end
	local v78 = v_u_7.SetZoomParameters
	local v79 = p72.currentSubjectDistance
	local v80 = p73 - v74
	v78(v79, (math.sign(v80)))
	return p72.currentSubjectDistance
end
function v_u_12.SetCameraType(p81, p82) -- name: SetCameraType
	p81.cameraType = p82
end
function v_u_12.GetCameraType(p83) -- name: GetCameraType
	return p83.cameraType
end
function v_u_12.SetCameraMovementMode(p84, p85) -- name: SetCameraMovementMode
	p84.cameraMovementMode = p85
end
function v_u_12.GetCameraMovementMode(p86) -- name: GetCameraMovementMode
	return p86.cameraMovementMode
end
function v_u_12.SetIsMouseLocked(p87, p88) -- name: SetIsMouseLocked
	p87.inMouseLockedMode = p88
end
function v_u_12.GetIsMouseLocked(p89) -- name: GetIsMouseLocked
	return p89.inMouseLockedMode
end
function v_u_12.SetMouseLockOffset(p90, p91) -- name: SetMouseLockOffset
	p90.mouseLockOffset = p91
end
function v_u_12.GetMouseLockOffset(p92) -- name: GetMouseLockOffset
	return p92.mouseLockOffset
end
function v_u_12.InFirstPerson(p93) -- name: InFirstPerson
	return p93.inFirstPerson
end
function v_u_12.EnterFirstPerson(p94) -- name: EnterFirstPerson
	p94.inFirstPerson = true
	p94:UpdateMouseBehavior()
end
function v_u_12.LeaveFirstPerson(p95) -- name: LeaveFirstPerson
	p95.inFirstPerson = false
	p95:UpdateMouseBehavior()
end
function v_u_12.GetCameraToSubjectDistance(p96) -- name: GetCameraToSubjectDistance
	return p96.currentSubjectDistance
end
function v_u_12.GetMeasuredDistanceToFocus(_) -- name: GetMeasuredDistanceToFocus
	local v97 = game.Workspace.CurrentCamera
	if v97 then
		return (v97.CoordinateFrame.p - v97.Focus.p).magnitude
	else
		return nil
	end
end
function v_u_12.GetCameraLookVector(_) -- name: GetCameraLookVector
	return game.Workspace.CurrentCamera and game.Workspace.CurrentCamera.CFrame.LookVector or Vector3.new(0, 0, 1)
end
function v_u_12.CalculateNewLookCFrameFromArg(p98, p99, p100) -- name: CalculateNewLookCFrameFromArg
	local v101 = p99 or p98:GetCameraLookVector()
	local v102 = v101.Y
	local v103 = math.asin(v102)
	local v104 = p100.Y
	local v105 = v103 + -1.3962634015954636
	local v106 = v103 + 1.3962634015954636
	local v107 = math.clamp(v104, v105, v106)
	local v108 = Vector2.new(p100.X, v107)
	local v109 = CFrame.new(Vector3.new(0, 0, 0), v101)
	return CFrame.Angles(0, -v108.X, 0) * v109 * CFrame.Angles(-v108.Y, 0, 0)
end
function v_u_12.CalculateNewLookVectorFromArg(p110, p111, p112) -- name: CalculateNewLookVectorFromArg
	return p110:CalculateNewLookCFrameFromArg(p111, p112).LookVector
end
function v_u_12.CalculateNewLookVectorVRFromArg(p113, p114) -- name: CalculateNewLookVectorVRFromArg
	local v115 = ((p113:GetSubjectPosition() - game.Workspace.CurrentCamera.CFrame.p) * Vector3.new(1, 0, 1)).unit
	local v116 = Vector2.new(p114.X, 0)
	local v117 = CFrame.new(Vector3.new(0, 0, 0), v115)
	return ((CFrame.Angles(0, -v116.X, 0) * v117 * CFrame.Angles(-v116.Y, 0, 0)).LookVector * Vector3.new(1, 0, 1)).unit
end
function v_u_12.GetHumanoid(p118) -- name: GetHumanoid
	-- upvalues: (copy) v_u_11
	local v119 = v_u_11
	if v119 then
		v119 = v_u_11.Character
	end
	if not v119 then
		return nil
	end
	local v120 = p118.humanoidCache[v_u_11]
	if v120 and v120.Parent == v119 then
		return v120
	end
	p118.humanoidCache[v_u_11] = nil
	local v121 = v119:FindFirstChildOfClass("Humanoid")
	if v121 then
		p118.humanoidCache[v_u_11] = v121
	end
	return v121
end
function v_u_12.GetHumanoidPartToFollow(_, p122, p123) -- name: GetHumanoidPartToFollow
	if p123 == Enum.HumanoidStateType.Dead then
		local v124 = p122.Parent
		if v124 then
			return v124:FindFirstChild("Head") or p122.Torso
		else
			return p122.Torso
		end
	else
		return p122.Torso
	end
end
function v_u_12.OnNewCameraSubject(p125) -- name: OnNewCameraSubject
	if p125.subjectStateChangedConn then
		p125.subjectStateChangedConn:Disconnect()
		p125.subjectStateChangedConn = nil
	end
end
function v_u_12.IsInFirstPerson(p126) -- name: IsInFirstPerson
	return p126.inFirstPerson
end
function v_u_12.Update(_, _) -- name: Update
	error("BaseCamera:Update() This is a virtual function that should never be getting called.", 2)
end
function v_u_12.GetCameraHeight(p127) -- name: GetCameraHeight
	-- upvalues: (copy) v_u_2
	return (not v_u_2.VREnabled or p127.inFirstPerson) and 0 or 0.25881904510252074 * p127.currentSubjectDistance
end
return v_u_12