-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Character.JoinController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("RunService")
game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local v_u_7 = require(v_u_6.Modules.Icon)
v_u_7.closeableOverflowMenus = true
local _ = v_u_6.Animations
local v_u_8 = v_u_6.Utils
local v_u_9 = v_u_6.Sounds
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "JoinController"
})
v13.lastRecvServer = {}
local function v_u_24(p14) -- name: readCFrame
	local v15 = buffer.readu16(p14, 0) * 256 + buffer.readu8(p14, 2)
	if v15 >= 8388608 then
		v15 = v15 - 16777216
	end
	local v16 = v15 / 100
	local v17 = buffer.readu16(p14, 3) * 256 + buffer.readu8(p14, 5)
	if v17 >= 8388608 then
		v17 = v17 - 16777216
	end
	local v18 = v17 / 100
	local v19 = buffer.readu16(p14, 6) * 256 + buffer.readu8(p14, 8)
	if v19 >= 8388608 then
		v19 = v19 - 16777216
	end
	local v20 = v19 / 100
	local v21 = buffer.readi16(p14, 9) / 1000
	local v22 = buffer.readi16(p14, 11) / 1000
	local v23 = buffer.readi16(p14, 13) / 1000
	return CFrame.new(v16, v18, v20) * CFrame.Angles(v21, v22, v23)
end
local function v_u_45(p25) -- name: writeCFrame
	local v26 = buffer.create(15)
	local v27 = p25.X
	local v28 = p25.Y
	local v29 = p25.Z
	local v30, v31, v32 = p25:ToEulerAnglesXYZ()
	local v33 = v27 * 100
	if v33 < 0 then
		v33 = v33 + 16777216
	end
	local v34 = v33 / 256
	buffer.writeu16(v26, 0, v34)
	local v35 = v33 % 256
	buffer.writeu8(v26, 2, v35)
	local v36 = v28 * 100
	if v36 < 0 then
		v36 = v36 + 16777216
	end
	local v37 = v36 / 256
	buffer.writeu16(v26, 3, v37)
	local v38 = v36 % 256
	buffer.writeu8(v26, 5, v38)
	local v39 = v29 * 100
	if v39 < 0 then
		v39 = v39 + 16777216
	end
	local v40 = v39 / 256
	buffer.writeu16(v26, 6, v40)
	local v41 = v39 % 256
	buffer.writeu8(v26, 8, v41)
	local v42 = v30 * 1000
	buffer.writei16(v26, 9, v42)
	local v43 = v31 * 1000
	buffer.writei16(v26, 11, v43)
	local v44 = v32 * 1000
	buffer.writei16(v26, 13, v44)
	return v26
end
function v13.CreateIcon(_, p46, p47, p_u_48) -- name: CreateIcon
	-- upvalues: (copy) v_u_7, (ref) v_u_10
	local v49 = v_u_7.new()
	if p47 then
		v49:setImage(p47)
	end
	v49:setLabel(p46)
	v49:bindEvent("selected", function(p50)
		-- upvalues: (ref) v_u_10, (copy) p_u_48
		p50:deselect()
		v_u_10.Change:Fire(p_u_48)
	end)
	return v49
end
function v13.CreateIconBase(_, p51, p52, p_u_53) -- name: CreateIconBase
	-- upvalues: (copy) v_u_7, (ref) v_u_10
	local v54 = v_u_7.new()
	if p52 then
		v54:setImage(p52)
	end
	v54:setLabel(p51)
	v54:modifyTheme({ "IconLabel", "TextColor3", Color3.fromRGB(152, 152, 152) })
	v54:bindEvent("selected", function(p55)
		-- upvalues: (ref) v_u_10, (copy) p_u_53
		p55:deselect()
		v_u_10.Change:Fire(p_u_53)
	end)
	return v54
end
function v13.KnitStart(p_u_56) -- name: KnitStart
	-- upvalues: (copy) v_u_7, (copy) v_u_5, (ref) v_u_10, (copy) v_u_4, (copy) v_u_6, (ref) v_u_12, (copy) v_u_2, (copy) v_u_3, (copy) v_u_45, (ref) v_u_11, (copy) v_u_24, (copy) v_u_9, (copy) v_u_8
	script:SetAttribute("KnitLoaded", true)
	local v_u_57 = v_u_7.new()
	v_u_57:setImage("rbxassetid://7992557358")
	v_u_57:setLabel("Characters")
	v_u_57:setEnabled(false)
	v_u_57:setDropdown({
		p_u_56:CreateIcon("Honored One", nil, "Gojo"),
		p_u_56:CreateIcon("Vessel", nil, "Itadori"),
		p_u_56:CreateIcon("Restless Gambler", nil, "Hakari"),
		p_u_56:CreateIcon("Ten Shadows", nil, "Megumi"),
		p_u_56:CreateIcon("Perfection", nil, "Mahito"),
		p_u_56:CreateIcon("Blood Manipulator", nil, "Choso"),
		p_u_56:CreateIcon("Switcher", nil, "Todo"),
		p_u_56:CreateIcon("Defense Attorney", nil, "Hiromi"),
		p_u_56:CreateIcon("Cursed Partners", nil, "Yuta"),
		p_u_56:CreateIcon("Puppet Master", nil, "Mechamaru"),
		p_u_56:CreateIcon("Head of the Hei", nil, "Naoya"),
		p_u_56:CreateIcon("Salaryman", nil, "Nanami"),
		p_u_56:CreateIcon("Disaster Plants", nil, "Hanami"),
		p_u_56:CreateIcon("True Cannon", nil, "Ryu"),
		p_u_56:CreateIcon("Register", nil, "Reggie"),
		p_u_56:CreateIcon("Hired Killer", nil, "Toji"),
		p_u_56:CreateIconBase("Locust Guy", nil, "Locust"),
		p_u_56:CreateIconBase("Star Rage", nil, "Yuki"),
		p_u_56:CreateIconBase("Aspiring Mangaka", nil, "Charles"),
		p_u_56:CreateIconBase("Lucky Coward", nil, "Haruta"),
		p_u_56:CreateIconBase("Crow Charmer", nil, "MeiMei"),
		p_u_56:CreateIconBase("Black Death", nil, "Kurourushi"),
		p_u_56:CreateIconBase("Sky Assassin", nil, "Uro")
	})
	local v_u_58 = nil
	local v_u_59 = nil
	local v_u_60 = nil
	local function v61() -- name: updateTags
		-- upvalues: (ref) v_u_58, (ref) v_u_59, (ref) v_u_60, (copy) p_u_56, (copy) v_u_57, (ref) v_u_5
		if v_u_58 then
			v_u_58:destroy()
			v_u_58 = nil
		end
		if v_u_59 then
			v_u_59:destroy()
			v_u_59 = nil
		end
		if v_u_60 then
			v_u_60:destroy()
			v_u_60 = nil
		end
		if workspace:GetAttribute("AllowOP") then
			v_u_58 = p_u_56:CreateIcon("Strongest Of History", nil, "Heian")
			v_u_58:modifyTheme({ "IconLabel", "TextColor3", Color3.fromRGB(255, 170, 0) })
			v_u_58:joinDropdown(v_u_57)
		end
		if v_u_5:GetAttribute("Mokou") then
			v_u_59 = p_u_56:CreateIcon("Mokou", 129398506853336, "Mokou")
			v_u_59:modifyTheme({ "IconLabel", "TextColor3", Color3.fromRGB(255, 170, 0) })
			v_u_59:joinDropdown(v_u_57)
		end
		if v_u_5:GetAttribute("Goku") or workspace:GetAttribute("AllowOP") then
			v_u_60 = p_u_56:CreateIcon("Monkey Kid", 79537216753706, "Goku")
			v_u_60:modifyTheme({ "IconLabel", "TextColor3", Color3.fromRGB(255, 170, 0) })
			v_u_60:joinDropdown(v_u_57)
		end
	end
	v61()
	workspace:GetAttributeChangedSignal("AllowOP"):Connect(v61)
	v_u_5:GetAttributeChangedSignal("Mokou"):Connect(v61)
	v_u_5:GetAttributeChangedSignal("Goku"):Connect(v61)
	task.spawn(function()
		-- upvalues: (ref) v_u_7, (ref) v_u_10, (copy) v_u_57
		local function v_u_73(p62) -- name: updateFolder
			-- upvalues: (ref) v_u_7, (ref) v_u_10, (ref) v_u_57
			local function v71(p_u_63) -- name: addCustomChar
				-- upvalues: (ref) v_u_7, (ref) v_u_10, (ref) v_u_57
				if not p_u_63.Value then
					repeat
						task.wait()
					until p_u_63.Value or not p_u_63.Parent
				end
				if p_u_63.Parent then
					if p_u_63.Value then
						local v64 = p_u_63.Value:GetAttribute("MoveNameFt") or "Unnamed"
						local v65 = p_u_63.Value:GetAttribute("IMG")
						if v65 == 0 then
							v65 = nil
						end
						local v_u_66 = v_u_7.new()
						if v65 then
							v_u_66:setImage(v65)
						end
						v_u_66:setLabel(v64)
						v_u_66:bindEvent("selected", function(p67)
							-- upvalues: (ref) v_u_10, (copy) p_u_63
							p67:deselect()
							v_u_10.Change:Fire(p_u_63.Value:GetAttribute("MoveNameFt") or "Unnamed")
						end)
						v_u_66:modifyTheme({ "IconLabel", "TextColor3", Color3.fromRGB(85, 170, 255) })
						v_u_66:joinDropdown(v_u_57)
						p_u_63.Destroying:Connect(function()
							-- upvalues: (copy) v_u_66
							v_u_66:destroy()
						end)
						local function v70() -- name: updateCustomChar
							-- upvalues: (copy) p_u_63, (copy) v_u_66
							local v68 = p_u_63.Value:GetAttribute("MoveNameFt") or "Unnamed"
							local v69 = p_u_63.Value:GetAttribute("IMG")
							if v69 == 0 then
								v69 = nil
							end
							if v68 then
								v_u_66:setLabel(v68)
							end
							if v69 then
								v_u_66:setImage("rbxassetid://" .. v69)
							end
							if p_u_63.Value:GetAttribute("Flip") == true then
								v_u_66:setEnabled(true)
							else
								v_u_66:setEnabled(false)
							end
						end
						v70()
						p_u_63.Value:GetAttributeChangedSignal("IMG"):Connect(v70)
						p_u_63.Value:GetAttributeChangedSignal("MoveNameFt"):Connect(v70)
						p_u_63.Value:GetAttributeChangedSignal("Flip"):Connect(v70)
						p_u_63.Destroying:Connect(function()
							-- upvalues: (copy) v_u_66
							v_u_66:destroy()
						end)
					end
				else
					return
				end
			end
			for _, v72 in p62:GetChildren() do
				v71(v72)
			end
			p62.ChildAdded:Connect(v71)
		end
		if workspace.LogicData:FindFirstChild("CustomChar") then
			v_u_73(workspace.LogicData.CustomChar)
		else
			workspace.LogicData.ChildAdded:Connect(function(p74)
				-- upvalues: (copy) v_u_73
				if p74.Name == "CustomChar" then
					v_u_73(p74)
				end
			end)
		end
	end)
	v_u_5:WaitForChild("leaderstats")
	local v_u_75 = v_u_5:GetAttribute("Cash") or 0
	local v_u_76 = v_u_5.PlayerGui:WaitForChild("Menus").Group
	local v_u_77 = v_u_5.PlayerGui:WaitForChild("Menus").Fade
	local function v_u_81() -- name: fadeDrop
		-- upvalues: (copy) v_u_76, (copy) v_u_77, (ref) v_u_4
		local v78 = true
		for _, v79 in v_u_76:GetChildren() do
			if v79:GetAttribute("Loaded") then
				continue
			end
			v78 = false
		end
		if not v78 then
			task.wait(0.1)
		end
		if not v78 then
			break
		end
		v_u_76.Parent = v_u_77
		v_u_77.Position = UDim2.new(0, 0, -0.2, 0)
		v_u_77.GroupTransparency = 1
		local v80 = v_u_4:Create(v_u_77, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
			["Position"] = nil,
			["GroupTransparency"] = 0,
			["Position"] = UDim2.new(0, 0, 0, 0)
		})
		v80:Play()
		v80.Completed:Once(function()
			-- upvalues: (ref) v_u_76, (ref) v_u_77
			v_u_76.Parent = v_u_77.Parent
		end)
	end
	local v_u_82 = v_u_7.new()
	v_u_82:setImage("rbxassetid://9405933217")
	local v83 = v_u_75
	v_u_82:setLabel("$" .. tostring(v83))
	v_u_5:GetAttributeChangedSignal("Cash"):Connect(function()
		-- upvalues: (ref) v_u_75, (ref) v_u_5, (copy) v_u_82
		v_u_75 = v_u_5:GetAttribute("Cash") or 0
		local v84 = v_u_75
		v_u_82:setLabel("$" .. tostring(v84))
	end)
	v_u_82:bindEvent("selected", function(_)
		-- upvalues: (copy) v_u_76, (copy) v_u_81
		v_u_76.Shop.Visible = true
		v_u_81()
	end)
	v_u_82:bindEvent("deselected", function(_)
		-- upvalues: (copy) v_u_76
		v_u_76.Shop.Visible = false
	end)
	v_u_82:setEnabled(workspace:GetAttribute("Match") == nil)
	v_u_82:setCaption("Shop")
	local v85 = v_u_7.new()
	v85:setImage("rbxassetid://5480743826")
	v85:bindEvent("selected", function(_)
		-- upvalues: (copy) v_u_76, (copy) v_u_81
		v_u_76.Settings.Visible = true
		v_u_81()
	end)
	v85:bindEvent("deselected", function(_)
		-- upvalues: (copy) v_u_76
		v_u_76.Settings.Visible = false
	end)
	v85:setCaption("Settings")
	local v86 = v_u_7.new()
	v86:setImage("rbxassetid://6870729295")
	v86:bindEvent("selected", function(_)
		-- upvalues: (copy) v_u_76, (copy) v_u_81
		v_u_76.Inventory.Visible = true
		v_u_81()
	end)
	v86:bindEvent("deselected", function(_)
		-- upvalues: (copy) v_u_76
		v_u_76.Inventory.Visible = false
	end)
	v86:setEnabled(workspace:GetAttribute("Match") == nil)
	v86:setCaption("Inventory")
	local v87 = v_u_7.new()
	v87:setImage("rbxassetid://11829454151")
	v87:bindEvent("selected", function(_)
		-- upvalues: (copy) v_u_76, (copy) v_u_81
		v_u_76.Achievements.Visible = true
		v_u_81()
	end)
	v87:bindEvent("deselected", function(_)
		-- upvalues: (copy) v_u_76
		v_u_76.Achievements.Visible = false
	end)
	v87:setName("Achievement")
	v87:setCaption("Achievements")
	local v_u_88 = false
	local v_u_89 = v_u_7.new()
	v_u_89:setImage("rbxassetid://11214451393")
	v_u_89:bindEvent("selected", function(_)
		-- upvalues: (copy) v_u_76, (copy) v_u_81, (ref) v_u_88, (ref) v_u_6, (ref) v_u_12
		v_u_76.Logs.Visible = true
		v_u_81()
		if v_u_88 ~= true then
			v_u_88 = true
			v_u_6.Remotes.UpdateLog:FireServer(v_u_12.Ver)
		end
	end)
	v_u_89:bindEvent("deselected", function(_)
		-- upvalues: (copy) v_u_76
		v_u_76.Logs.Visible = false
	end)
	v_u_89:setRight()
	v_u_89:setCaption("Update Logs")
	local v_u_90 = {}
	for v_u_91, v_u_92 in require(v_u_6.Modules.RobloxChatVoice) do
		local function v96()
			-- upvalues: (ref) v_u_7, (copy) v_u_91, (copy) v_u_92, (ref) v_u_10, (copy) v_u_90
			local v93 = v_u_7.new()
			v93:setImage("rbxassetid://" .. v_u_91)
			v93:setLabel(v_u_92.Name)
			v93:bindEvent("selected", function(p94)
				-- upvalues: (ref) v_u_10, (ref) v_u_91
				p94:deselect()
				v_u_10.Talk:Fire(v_u_91)
			end)
			local v95 = v_u_90
			table.insert(v95, v93)
		end
		pcall(v96)
	end
	local v97 = v_u_7.new()
	v97:setRight()
	v97:setImage("rbxassetid://14809805905")
	v97:setCaption("Voice Clips")
	v97:setDropdown(v_u_90)
	task.spawn(function()
		-- upvalues: (ref) v_u_6, (ref) v_u_5, (ref) v_u_7, (copy) v_u_76, (copy) v_u_81
		local v_u_98 = require(v_u_6.Modules.Rules).Version
		local v99 = v_u_5:GetAttribute("LastRulesAccepted")
		if not v99 then
			v_u_5:GetAttributeChangedSignal("LastRulesAccepted"):Wait()
			v99 = v_u_5:GetAttribute("LastRulesAccepted")
		end
		local v_u_100 = v_u_7.new()
		v_u_100:setImage("rbxassetid://71437429504293")
		v_u_100:bindEvent("selected", function(_)
			-- upvalues: (ref) v_u_76, (ref) v_u_81
			v_u_76.Rules.Visible = true
			v_u_81()
		end)
		v_u_100:bindEvent("deselected", function(_)
			-- upvalues: (copy) v_u_98, (ref) v_u_5, (copy) v_u_100, (ref) v_u_76
			if v_u_98 == v_u_5:GetAttribute("LastRulesAccepted") then
				v_u_76.Rules.Visible = false
			else
				v_u_100:select()
			end
		end)
		v_u_100:setRight()
		v_u_100:setCaption("Rules")
		if v_u_98 ~= v99 then
			v_u_100:select()
		end
		v_u_5:GetAttributeChangedSignal("LastRulesAccepted"):Once(function()
			-- upvalues: (copy) v_u_98, (ref) v_u_5, (copy) v_u_100
			if v_u_98 == v_u_5:GetAttribute("LastRulesAccepted") then
				v_u_100:deselect()
			end
		end)
	end)
	v_u_6.Remotes.UpdateLog:FireServer()
	v_u_6.Remotes.UpdateLog.OnClientEvent:Connect(function(p101)
		-- upvalues: (ref) v_u_12, (copy) v_u_89
		if p101 ~= v_u_12.Ver then
			v_u_89:notify()
		end
	end)
	task.delay(0.05, function()
		-- upvalues: (ref) v_u_7, (copy) v_u_76, (copy) v_u_81, (ref) v_u_5, (ref) v_u_6, (ref) v_u_2
		local v102 = v_u_7.new()
		v102:setImage("rbxassetid://2599458148")
		v102:bindEvent("selected", function(_)
			-- upvalues: (ref) v_u_76, (ref) v_u_81
			v_u_76.Ranked.Visible = true
			v_u_81()
		end)
		v102:bindEvent("deselected", function(_)
			-- upvalues: (ref) v_u_76
			v_u_76.Ranked.Visible = false
		end)
		v102:setEnabled(workspace:GetAttribute("Match") == nil)
		v102:setCaption("Gamemodes")
		local v_u_103 = v_u_7.new()
		v_u_103:setEnabled(false)
		v_u_103:setImage("rbxassetid://401280105")
		v_u_103:bindEvent("selected", function(_)
			-- upvalues: (ref) v_u_76, (ref) v_u_81
			v_u_76.Private.Visible = true
			v_u_81()
		end)
		v_u_103:bindEvent("deselected", function(_)
			-- upvalues: (ref) v_u_76
			v_u_76.Private.Visible = false
		end)
		v_u_103:setCaption("PS+")
		if v_u_5:GetAttribute("PS_Owner") then
			v_u_103:setEnabled(true)
		end
		v_u_5:GetAttributeChangedSignal("PS_Owner"):Connect(function()
			-- upvalues: (ref) v_u_5, (copy) v_u_103
			if v_u_5:GetAttribute("PS_Owner") then
				v_u_103:setEnabled(true)
			elseif v_u_103 then
				v_u_103:setEnabled(false)
			end
		end)
		v_u_5:GetAttributeChangedSignal("PS_Perms"):Connect(function()
			-- upvalues: (ref) v_u_5, (copy) v_u_103
			if v_u_5:GetAttribute("PS_Owner") then
				return
			elseif v_u_5:GetAttribute("PS_Perms") then
				v_u_103:setEnabled(true)
			elseif v_u_103 then
				v_u_103:setEnabled(false)
			end
		end)
		local v104 = v_u_7.new()
		v104:setEnabled(false)
		v104:bindEvent("selected", function(_)
			-- upvalues: (ref) v_u_76, (ref) v_u_81
			v_u_76.Tutorial_Info.Visible = true
			v_u_81()
		end)
		v104:bindEvent("deselected", function(_)
			-- upvalues: (ref) v_u_76
			v_u_76.Tutorial_Info.Visible = false
		end)
		_G.TutorialIcon = v104
		local v_u_105 = v_u_7.new()
		v_u_105:setImage("rbxassetid://10626050757")
		v_u_105:bindEvent("selected", function(_)
			-- upvalues: (ref) v_u_76, (ref) v_u_81
			v_u_76.Workshop.Visible = true
			v_u_81()
		end)
		v_u_105:bindEvent("deselected", function(_)
			-- upvalues: (ref) v_u_76
			v_u_76.Workshop.Visible = false
		end)
		v_u_105:setCaption("Workshop")
		_G.WorkshopIcon = v_u_105
		if not v_u_5:GetAttribute("Workshop") then
			v_u_105:setEnabled(false)
		end
		v_u_5:GetAttributeChangedSignal("Workshop"):Connect(function()
			-- upvalues: (ref) v_u_5, (copy) v_u_105
			if v_u_5:GetAttribute("Workshop") then
				v_u_105:setEnabled(true)
			else
				v_u_105:setEnabled(false)
			end
		end)
		local v_u_106 = v_u_6:WaitForChild("CmdrClient", 2)
		if v_u_106 then
			v_u_106 = require(v_u_6.CmdrClient)
		end
		if v_u_106 then
			local v_u_107 = v_u_7.new()
			v_u_107:setImage("rbxassetid://95498291180289")
			v_u_107:bindEvent("selected", function(p108)
				-- upvalues: (copy) v_u_106, (ref) v_u_81
				v_u_106:Show()
				p108:deselect()
				v_u_81()
			end)
			v_u_107:setCaption("cmdr")
			local function v109() -- name: updateCmdr
				-- upvalues: (ref) v_u_5, (copy) v_u_107, (ref) v_u_2
				if v_u_5:GetAttribute("Cmdr") then
					if v_u_2.TouchEnabled then
						v_u_107:setEnabled(true)
					else
						v_u_107:setEnabled(false)
					end
				else
					v_u_107:setEnabled(false)
					return
				end
			end
			v_u_5:GetAttributeChangedSignal("Cmdr"):Connect(v109)
			v_u_2.InputChanged:Connect(v109)
			if not v_u_5:GetAttribute("Cmdr") then
				v_u_107:setEnabled(false)
				return
			end
			if v_u_2.TouchEnabled then
				v_u_107:setEnabled(true)
				return
			end
			v_u_107:setEnabled(false)
		end
	end)
	local v_u_110 = game:GetService("StarterGui")
	v_u_110:SetCoreGuiEnabled(Enum.CoreGuiType.Backpack, false)
	v_u_110:SetCoreGuiEnabled(Enum.CoreGuiType.EmotesMenu, false)
	local v_u_111 = Instance.new("BindableEvent")
	v_u_111.Event:Connect(function()
		-- upvalues: (ref) v_u_10
		v_u_10.Reset:Fire()
	end)
	v_u_10.Reset:Connect(function(p112, p113, _, _)
		game:GetService("StarterGui"):SetCore("SendNotification", {
			["Title"] = p112,
			["Text"] = p113
		})
	end)
	local v114 = game:GetService("TextChatService")
	workspace.Map.Core:FindFirstChild("Leaderboard")
	function v114.OnIncomingMessage(p115)
		local v116 = Instance.new("TextChatMessageProperties")
		if p115.TextSource then
			local v117 = game.Players:GetPlayerByUserId(p115.TextSource.UserId)
			if v117:GetAttribute("Title") then
				if v117:GetAttribute("Title") == "?" then
					v116.PrefixText = "<font color = \"#000000\">[ ? ] ?: </font>"
					return v116
				end
				v116.PrefixText = "[" .. v117:GetAttribute("Title") .. "] " .. p115.PrefixText
			end
		end
		return v116
	end
	v_u_3.Stepped:Connect(function()
		-- upvalues: (ref) v_u_5, (ref) v_u_45, (ref) v_u_11
		local v118 = v_u_5.Character
		local v119
		if v118 then
			v119 = v118:FindFirstChild("HumanoidRootPart")
		else
			v119 = v118
		end
		local v120 = buffer.create(9)
		local v121 = workspace.CurrentCamera.CFrame.X
		if v121 < 0 then
			v121 = v121 + 16777216
		end
		local v122 = v121 / 256
		buffer.writeu16(v120, 0, v122)
		local v123 = v121 % 256
		buffer.writeu8(v120, 2, v123)
		local v124 = workspace.CurrentCamera.CFrame.Y
		if v124 < 0 then
			v124 = v124 + 16777216
		end
		local v125 = v124 / 256
		buffer.writeu16(v120, 3, v125)
		local v126 = v124 % 256
		buffer.writeu8(v120, 5, v126)
		local v127 = workspace.CurrentCamera.CFrame.Z
		if v127 < 0 then
			v127 = v127 + 16777216
		end
		local v128 = v127 / 256
		buffer.writeu16(v120, 6, v128)
		local v129 = v127 % 256
		buffer.writeu8(v120, 8, v129)
		local v130
		if v119 then
			v130 = v_u_45(v119.CFrame)
		else
			v130 = nil
		end
		v_u_11.Camera:Fire(v120, v130, v118, (0 / 0))
	end)
	local v_u_131 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 1, -0)
	v_u_3.RenderStepped:Connect(function(p132)
		-- upvalues: (copy) p_u_56, (ref) v_u_5, (copy) v_u_131
		local v133 = tick()
		for v134, v135 in p_u_56.lastRecvServer do
			if v134 and v134.Parent then
				if v134 == v_u_5.Character then
					continue
				end
				local v136 = v134.HumanoidRootPart
				if v135 == false or ((v134:GetAttribute("Ragdoll") or 0) > 0 or v134.Humanoid.Sit == true) then
					v136.RootJoint.C0 = v_u_131
					v136:SetAttribute("MO", nil)
				elseif v135[1] and v135[2] then
					local v137
					if (v135[2].Position - v135[1].Position).Magnitude < 15 then
						local v138 = v135[2] or v136.CFrame
						local v139 = v135[1]
						local v140 = (v133 - v135[3]) / 0.05
						v137 = v138:Lerp(v139, (math.clamp(v140, 0, 1)))
					else
						v137 = v135[1]
					end
					local v141 = v136:FindFirstChild("GrabWeld")
					if v141 and (v141.Part0 and v141.Part0.Name ~= "HumanoidRootPart") then
						v136:SetAttribute("MO", (v137:ToObjectSpace(v136.CFrame)))
					else
						local v142 = (v137.Position - v136.Position) / p132
						local v143 = v142.Magnitude > 50 and Vector3.new(0, 0, 0) or v142
						v136.RootJoint.C0 = v_u_131
						v136:SetAttribute("MO", nil)
						v136.Velocity = v143
						v136.CFrame = v137
					end
				else
					v136.RootJoint.C0 = v_u_131
					v136:SetAttribute("MO", nil)
				end
			else
				p_u_56.lastRecvServer[v134] = nil
			end
		end
	end)
	v_u_11.Camera:Connect(function(p144)
		-- upvalues: (copy) p_u_56, (ref) v_u_24
		for v145, v146 in p144 do
			local v147 = game.Players:FindFirstChild(v145)
			if not v147 then
				continue
			end
			local v148 = v147.Character
			if not (v148 and v148.Parent) then
				continue
			end
			if type(v146) == "boolean" then
				p_u_56.lastRecvServer[v148] = false
			else
				local v149 = v148:FindFirstChild("HumanoidRootPart")
				local v150
				if v149 then
					v150 = v149.CFrame * (v149:GetAttribute("MO") or CFrame.new())
				else
					v150 = nil
				end
				p_u_56.lastRecvServer[v148] = { v_u_24(v146), v150 or v_u_24(v146), tick() }
			end
		end
	end)
	v_u_11.Teleport:Connect(function(p151, p152, p153)
		-- upvalues: (ref) v_u_5, (ref) v_u_11, (ref) v_u_24, (copy) p_u_56
		if v_u_5.Character == p151 then
			v_u_11.Teleport:Fire(p153)
			return
		elseif p151 and p151.Parent then
			p151:PivotTo((v_u_24(p152)))
			p_u_56.lastRecvServer[p151] = false
		end
	end)
	v_u_10.Talk:Connect(function(p154, p155)
		-- upvalues: (ref) v_u_6, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4
		local v156 = p154:FindFirstChild("HumanoidRootPart")
		if v156 then
			local v157 = require(v_u_6.Modules.RobloxChatVoice)[p155]
			local v158 = v157.Sound
			local v_u_159 = v_u_9.Impact.Players.Death:Clone()
			v_u_159.RollOffMaxDistance = 150
			v_u_159.SoundGroup = game.SoundService.Taunt
			v_u_159.SoundId = "rbxassetid://" .. v158
			v_u_159.Volume = v157.Volume or 1
			v_u_159.Parent = v156
			v_u_159:Play()
			v_u_159.Stopped:Connect(function()
				-- upvalues: (copy) v_u_159
				v_u_159:Destroy()
			end)
			local v160 = v_u_8.Voice:Clone()
			v160.ImageLabel.Image = "rbxassetid://" .. p155
			v160.Parent = v156
			v_u_4:Create(v160, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
				["StudsOffsetWorldSpace"] = Vector3.new(0, 5, 0)
			}):Play()
			v_u_4:Create(v160.ImageLabel, TweenInfo.new(1.5, Enum.EasingStyle.Linear), {
				["ImageTransparency"] = 1
			}):Play()
		end
	end)
	while not pcall(function()
		-- upvalues: (copy) v_u_110, (copy) v_u_111
		v_u_110:SetCore("ResetButtonCallback", v_u_111)
	end) do
		task.wait()
	end
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("JoinService")
	v_u_11 = v_u_1.GetService("AntiCheatService")
	v_u_12 = v_u_1.GetController("UpdateLogController")
end
return v13