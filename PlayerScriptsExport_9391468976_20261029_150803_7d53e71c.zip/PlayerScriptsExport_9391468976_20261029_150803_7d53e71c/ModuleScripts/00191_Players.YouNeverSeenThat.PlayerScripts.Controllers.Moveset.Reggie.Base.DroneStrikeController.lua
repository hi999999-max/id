-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Reggie.Base.DroneStrikeController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "DroneStrikeController"
})
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_5, (copy) v_u_3, (copy) v_u_4, (copy) v_u_9, (copy) v_u_2, (ref) v_u_10
	local v_u_53 = {
		["Start"] = function(p14)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_12:PlaySound(v_u_8.Reggie.DroneStrike.Whoosh, v15, game.SoundService.Effect)
			end
		end,
		["DroneStart"] = function(p16)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v17 = p16:FindFirstChild("HumanoidRootPart")
			if v17 then
				v_u_12:PlaySound(v_u_8.Reggie.DroneStrike.DroneStart, v17, game.SoundService.Effect)
			end
		end,
		["Press"] = function(p18)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v19 = p18:FindFirstChild("HumanoidRootPart")
			if v19 then
				v_u_12:PlaySound(v_u_8.Reggie.DroneStrike.Press, v19, game.SoundService.Effect)
			end
		end,
		["DroneLoop"] = function(p20)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			v_u_12:PlaySound(v_u_8.Reggie.DroneStrike.Loop, p20.Rootpart, game.SoundService.Effect)
		end,
		["Aim"] = function(p21, p22, p23)
			-- upvalues: (ref) v_u_7, (ref) v_u_5
			local v24 = p21:FindFirstChild("HumanoidRootPart")
			if v24 then
				local v25 = v_u_7.Reggie.Crosshair:Clone()
				v25.Parent = workspace.Effects
				v25.CFrame = v24.CFrame
				if not p22:GetAttribute("Fired") then
					local v26 = task.wait()
					p23:FireServer((require(v_u_5.PlayerScripts.PlayerModule.ControlModule):GetMoveVector()))
					local v27 = v24.CFrame * p22:GetAttribute("Aim")
					local v28 = workspace:Raycast(v24.Position, v27.Position - v24.Position, _G.MapParams)
					if v28 then
						v27 = CFrame.new(v28.Position) * v27.Rotation
					end
					v25.CFrame = v25.CFrame:Lerp(v27, v26 * 25)
					if p22.Value ~= true and p22.Parent ~= nil then
						continue
					end
				end
				v25:Destroy()
			end
		end,
		["Break"] = function(p29)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			for _ = 1, 3 do
				local v_u_30 = v_u_7.Hiromi.GavelShard:Clone()
				local v31 = p29.CFrame
				local v32 = CFrame.new
				local v33 = (math.random() - 0.5) * p29.Size.X
				local v34 = (math.random() - 0.5) * p29.Size.Y
				local v35 = (math.random() - 0.5) * p29.Size.Z
				v_u_30.Position = (v31 * v32((Vector3.new(v33, v34, v35)))).Position
				v_u_30.Size = v_u_30.Size * (p29.Size.Magnitude / 6)
				v_u_30.Color = Color3.fromRGB(173, 193, 184)
				local v36 = p29.CFrame.LookVector * math.random(10, 20)
				local v37 = math.random(-50, 50)
				local v38 = math.random(-50, 50)
				local v39 = math.random
				v_u_30.Velocity = v36 + Vector3.new(v37, v38, v39(-50, 50))
				local v40 = math.random(-50, 50)
				local v41 = math.random(-50, 50)
				local v42 = math.random
				v_u_30.RotVelocity = Vector3.new(v40, v41, v42(-50, 50))
				v_u_30.Parent = workspace.Effects
				v_u_3:AddItem(v_u_30, 2)
				task.delay(1, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_30
					v_u_4:Create(v_u_30, TweenInfo.new(1), {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
				end)
			end
		end,
		["Explode"] = function(p43, p44, p45)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v46 = v_u_7.Reggie.BikeExplode:Clone()
			local v47 = Instance.new("Model")
			v46.Parent = v47
			v47:ScaleTo(p45 and 0.7 or 0.45)
			v_u_3:AddItem(v47, 0.2)
			v46.Parent = workspace.Effects
			v46.Position = p44
			v_u_3:AddItem(v46, 6)
			v_u_12:PlayParticles(v46)
			v_u_12:PlaySound(v_u_8.Reggie.DroneStrike.Explode, v46, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p44).Magnitude < 29 or v_u_5.Character == p43 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
			end
		end,
		["Interp"] = function(p_u_48)
			-- upvalues: (ref) v_u_2
			local v_u_49 = p_u_48.CFrame
			local v_u_50 = tick()
			local v_u_51 = p_u_48:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_49, (copy) p_u_48, (ref) v_u_50
				v_u_49 = p_u_48.CFrame
				v_u_50 = tick()
			end)
			local v_u_52 = nil
			v_u_52 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_48, (ref) v_u_52, (copy) v_u_51, (ref) v_u_49, (ref) v_u_50
				if p_u_48.Parent then
					workspace:BulkMoveTo({ p_u_48 }, { v_u_49 + v_u_49.LookVector * (p_u_48:GetAttribute("Speed") * (tick() - v_u_50)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_52:Disconnect()
					v_u_51:Disconnect()
				end
			end)
		end
	}
	v_u_10.Effects:Connect(function(p54, ...)
		-- upvalues: (copy) v_u_53
		local v55 = v_u_53[p54]
		if v55 then
			v55(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("DroneStrikeService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13