-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.WorkshopController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
game:GetService("TweenService")
game:GetService("MarketplaceService")
local v_u_2 = game:GetService("Players")
local v_u_3 = game.Players.LocalPlayer
local v_u_4 = game.ReplicatedStorage
local _ = v_u_4.Animations
local _ = v_u_4.Utils
local v_u_5 = v_u_4.Sounds
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = v_u_1.CreateController({
	["Name"] = "WorkshopController"
})
v_u_10.UsernameCache = {}
v_u_10.CategoryPages = {
	["Map"] = { 1, 1, 0 },
	["Moveset"] = { 1, 1, 0 },
	["Favourite"] = { 1, 1, 0 }
}
function v_u_10.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_3, (copy) v_u_10, (copy) v_u_2, (ref) v_u_9, (copy) v_u_5, (copy) v_u_4, (ref) v_u_7, (ref) v_u_6, (ref) v_u_8
	local v_u_11 = v_u_3.PlayerGui:WaitForChild("Menus")
	local v_u_12 = v_u_11.Group.Workshop
	v_u_12:SetAttribute("Loaded", true)
	local v_u_13 = v_u_12.Items.Uploads.Edit
	local v_u_14 = v_u_12.ReportConfirm
	local v_u_15 = v_u_12.Options
	local v_u_16 = v_u_15.Sorting
	local v_u_17 = v_u_15.Page
	local v_u_18 = v_u_12.TextBox
	local v_u_19 = "Moveset"
	local v_u_20 = false
	local v_u_21 = {}
	local v_u_22 = {}
	local v_u_23 = nil
	local v_u_24 = nil
	local v_u_25 = nil
	local v_u_26 = v_u_11.Preset.WorkshopPreset
	local function v_u_57(p_u_27, p28) -- name: CreateItemFromInfo
		-- upvalues: (copy) v_u_12, (ref) v_u_19, (copy) v_u_26, (ref) v_u_10, (ref) v_u_2, (ref) v_u_22, (ref) v_u_9, (ref) v_u_5, (ref) v_u_4, (ref) v_u_3, (ref) v_u_20, (ref) v_u_24, (ref) v_u_23, (ref) v_u_25, (ref) v_u_7, (copy) v_u_14, (ref) v_u_6
		local v_u_29 = v_u_12.Items[("%*s"):format(v_u_19)]
		if v_u_29.Name == "Uploads" then
			v_u_29 = v_u_29.List
		end
		local v_u_30 = v_u_26:Clone()
		v_u_30.Title.Text = p_u_27.title or ""
		v_u_30.Description.Text = p_u_27.description or ""
		v_u_30.Background.Image = "rbxassetid://" .. (p_u_27.image or "")
		v_u_30.Option2.FavouriteAmt.Text = p_u_27.favorites or 0
		v_u_30.Creator.Text = "..."
		v_u_30.LayoutOrder = p28
		v_u_30.Parent = v_u_29
		task.spawn(function()
			-- upvalues: (ref) v_u_10, (copy) p_u_27, (ref) v_u_2, (copy) v_u_30
			local v_u_31 = v_u_10.UsernameCache[p_u_27.creator]
			if not v_u_31 then
				local function v32()
					-- upvalues: (ref) v_u_31, (ref) v_u_2, (ref) p_u_27
					v_u_31 = v_u_2:GetNameFromUserIdAsync(p_u_27.creator)
				end
				if pcall(v32) then
					v_u_10.UsernameCache[p_u_27.creator] = v_u_31
				else
					local v33 = "..."
					v_u_31 = v33
				end
			end
			v_u_30.Creator.Text = v_u_31
		end)
		if v_u_22[p_u_27._id] then
			v_u_30.Option2.Favourite.ImageColor3 = Color3.fromRGB(255, 255, 0)
		end
		v_u_30.Option2.Favourite.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_9, (ref) v_u_5, (ref) v_u_22, (copy) p_u_27, (ref) v_u_4, (copy) v_u_30
			v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
			if v_u_22[p_u_27._id] then
				if v_u_4.Remotes.WorkshopFavorite:InvokeServer(p_u_27._id, false) then
					v_u_30.Option2.Favourite.ImageColor3 = Color3.new(1, 1, 1)
					local v34 = v_u_30.Option2.FavouriteAmt
					local v35 = v_u_30.Option2.FavouriteAmt.Text
					v34.Text = tonumber(v35) - 1
					v_u_22[p_u_27._id] = nil
					return
				end
			elseif v_u_4.Remotes.WorkshopFavorite:InvokeServer(p_u_27._id, true) then
				v_u_30.Option2.Favourite.ImageColor3 = Color3.fromRGB(255, 255, 0)
				local v36 = v_u_30.Option2.FavouriteAmt
				local v37 = v_u_30.Option2.FavouriteAmt.Text
				v36.Text = tonumber(v37) + 1
				v_u_22[p_u_27._id] = true
			end
		end)
		if v_u_3.UserId == p_u_27.creator then
			v_u_30.Option1.Edit.Visible = true
			v_u_30.Option1.Donate.Visible = false
			v_u_30.Option1.Report.Image = "rbxassetid://14714840208"
			v_u_30.Option2.Favourite.Visible = false
			v_u_30.Option1.Edit.MouseButton1Down:Connect(function()
				-- upvalues: (ref) v_u_20, (ref) v_u_9, (ref) v_u_5, (ref) v_u_24, (ref) v_u_12, (copy) p_u_27, (ref) v_u_23, (ref) v_u_25, (ref) v_u_19, (ref) v_u_7
				if v_u_20 == true then
					return
				else
					v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
					v_u_24(v_u_12.Categories.Uploads)
					v_u_12.Items.Uploads.List.Visible = false
					v_u_12.Items.Uploads.Edit.Visible = true
					v_u_12.Options.Visible = false
					if p_u_27.type == "Map" then
						v_u_23 = p_u_27
						v_u_25()
						v_u_12.Items.Uploads.Edit.Data.TypeChoiceConfirm.Moveset.Text = ""
					else
						v_u_12.Items[("%*s"):format(v_u_19)].Visible = false
						v_u_20 = true
						v_u_12.Loading.Visible = true
						v_u_7.DataQuery:Fire(p_u_27._id)
					end
				end
			end)
			local v_u_38 = Instance.new("BindableFunction", v_u_30)
			function v_u_38.OnInvoke(p39) -- name: OnInvoke
				-- upvalues: (ref) v_u_20, (ref) v_u_9, (ref) v_u_5, (ref) v_u_29, (ref) v_u_12, (ref) v_u_7, (copy) p_u_27
				if v_u_20 == true then
					return
				else
					v_u_9:PlaySound(v_u_5.Misc.UI.Switch, workspace, game.SoundService.Effect)
					if p39 == "Yes" then
						v_u_29.Visible = false
						v_u_20 = true
						v_u_12.Loading.Visible = true
						v_u_7.Delete:Fire(p_u_27._id)
					end
				end
			end
			v_u_30.Option1.Report.MouseButton1Down:Connect(function()
				-- upvalues: (ref) v_u_9, (ref) v_u_5, (copy) v_u_38
				v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
				local v40 = {
					["Title"] = "DELETE UPLOAD",
					["Text"] = "Are you sure you want to delete this upload?",
					["Button1"] = "Yes",
					["Button2"] = "No",
					["Duration"] = 2,
					["Callback"] = nil,
					["Callback"] = v_u_38
				}
				game:GetService("StarterGui"):SetCore("SendNotification", v40)
			end)
		else
			v_u_30.Option1.Report.MouseButton1Down:Connect(function()
				-- upvalues: (ref) v_u_9, (ref) v_u_5, (ref) v_u_14, (ref) v_u_20, (ref) v_u_7, (copy) p_u_27
				v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
				if not v_u_14.Visible then
					v_u_20 = true
					local v_u_41 = v_u_14.Reason
					local v_u_42 = v_u_41.Dropdown
					local v_u_43 = "I don\'t like it"
					v_u_14.TextBox.Text = ""
					v_u_14.Visible = true
					local v_u_44 = { (v_u_41.MouseButton1Down:Connect(function()
							-- upvalues: (copy) v_u_42, (copy) v_u_41, (ref) v_u_43, (ref) v_u_14
							if v_u_42.Visible then
								v_u_42.Visible = false
								v_u_41.Text = ("%* \226\134\147"):format(v_u_43)
								v_u_42.Visible = false
								v_u_14.TextBox.Visible = v_u_43 == "Other"
							else
								v_u_42.Visible = true
								v_u_41.Text = ("%* \226\134\145"):format(v_u_43)
							end
						end)) }
					local v_u_45 = v_u_43
					for _, v_u_46 in v_u_42:QueryDescendants("TextButton") do
						local v47 = v_u_46.MouseButton1Click
						local function v48()
							-- upvalues: (ref) v_u_45, (copy) v_u_46, (copy) v_u_41, (copy) v_u_42, (ref) v_u_14
							v_u_45 = v_u_46.Text
							v_u_41.Text = ("%* \226\134\147"):format(v_u_45)
							v_u_42.Visible = false
							v_u_14.TextBox.Visible = v_u_45 == "Other"
						end
						table.insert(v_u_44, v47:Connect(v48))
					end
					v_u_14.Buttons.Report.MouseButton1Down:Once(function()
						-- upvalues: (ref) v_u_45, (ref) v_u_14, (ref) v_u_7, (ref) p_u_27, (copy) v_u_44, (ref) v_u_20
						local v49 = v_u_45 ~= "Other" and v_u_45 or v_u_14.TextBox.Text
						v_u_7.Report:Fire(p_u_27._id, v49)
						for _, v50 in v_u_44 do
							v50:Disconnect()
						end
						v_u_14.Visible = false
						v_u_20 = false
					end)
					v_u_14.Buttons.Cancel.MouseButton1Down:Once(function()
						-- upvalues: (copy) v_u_44, (ref) v_u_14, (ref) v_u_20
						for _, v51 in v_u_44 do
							v51:Disconnect()
						end
						v_u_14.Visible = false
						v_u_20 = false
					end)
				end
			end)
			v_u_30.Option1.Donate.MouseButton1Down:Connect(function()
				-- upvalues: (copy) v_u_30, (ref) v_u_6, (copy) p_u_27
				local v52 = v_u_30.Creator.Text
				local v53 = v_u_6
				local v54 = p_u_27.creator
				if v52 == "..." or not v52 then
					v52 = nil
				end
				v53:PromptDonateMenu(v54, v52)
			end)
		end
		local v_u_55 = Instance.new("BindableFunction", v_u_30)
		function v_u_55.OnInvoke(p56) -- name: OnInvoke
			-- upvalues: (ref) v_u_9, (ref) v_u_5, (ref) v_u_7, (copy) p_u_27
			v_u_9:PlaySound(v_u_5.Misc.UI.Switch, workspace, game.SoundService.Effect)
			if p56 == "Yes" then
				_G.WorkshopIcon:deselect()
				v_u_7.DataLoad:Fire(p_u_27._id)
			end
		end
		v_u_30.Option1.Load.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_9, (ref) v_u_5, (copy) p_u_27, (copy) v_u_55
			v_u_9:PlaySound(v_u_5.Misc.UI.Switch, workspace, game.SoundService.Effect)
			game:GetService("StarterGui"):SetCore("SendNotification", {
				["Title"] = nil,
				["Text"] = "Are you sure you want to load?",
				["Button1"] = "Yes",
				["Button2"] = "No",
				["Duration"] = 2,
				["Callback"] = nil,
				["Title"] = p_u_27.title,
				["Callback"] = v_u_55
			})
		end)
	end
	local function v_u_65(p58, p59, p60) -- name: LoadFromTable
		-- upvalues: (copy) v_u_12, (ref) v_u_19, (ref) v_u_3, (copy) v_u_57
		local v61 = v_u_12.Items[("%*s"):format(v_u_19)]
		if v61.Name == "Uploads" then
			v61 = v61.List
		end
		for _, v62 in v61:GetChildren() do
			if not v62:IsA("Frame") then
				continue
			end
			if v62.Name == "Upload" then
				v62.Visible = v_u_3:GetAttribute("PS_Owner") == true
			else
				v62:Destroy()
			end
		end
		for v63 = p59, p59 + p60 - 1 do
			local v64 = p58[v63]
			if not v64 then
				break
			end
			v_u_57(v64, v63)
		end
		v61.CanvasPosition = Vector2.new(0, 0)
		v61.Visible = false
		v61.Visible = true
	end
	local v_u_66 = {
		["\226\152\133 DAY"] = "daily",
		["\226\152\133 MONTH"] = "monthly",
		["\226\152\133 WEEK"] = "weekly",
		["NEW"] = "newest"
	}
	local function v_u_75(p67) -- name: UpdateSearch
		-- upvalues: (ref) v_u_19, (copy) v_u_18, (ref) v_u_10, (copy) v_u_65, (ref) v_u_21, (copy) v_u_66, (copy) v_u_16, (copy) v_u_12, (ref) v_u_20, (ref) v_u_7
		if v_u_19 == "Favourite" then
			if p67 then
				v_u_18.Text = ""
				v_u_65(v_u_21, (v_u_10.CategoryPages[v_u_19][1] - 1) * 20 + 1, 20)
				return
			end
			if #v_u_18.Text ~= 0 then
				local v68 = v_u_18.Text
				local v69 = {}
				for _, v70 in v_u_21 do
					if not string.find(string.lower(v70.title), string.lower(v68)) then
						continue
					end
					table.insert(v69, v70)
				end
				v_u_65(v69, 1, #v69)
				return
			end
		end
		local v71 = v_u_18.Text
		if #v71 == 0 then
			v71 = nil
		end
		if v71 then
			v71 = string.sub(v71, 0, 50)
		end
		local v72 = v_u_66[v_u_16.Text]
		local v73
		if v_u_19 == "Map" or v_u_19 == "Moveset" then
			v73 = v_u_10.CategoryPages[v_u_19][1]
		else
			v73 = nil
		end
		local v74 = {
			["type"] = v_u_19,
			["title"] = v71,
			["sort"] = v72,
			["page"] = v73
		}
		v_u_12.Items[("%*s"):format(v_u_19)].Visible = false
		v_u_20 = true
		v_u_12.Loading.Visible = true
		v_u_7.Load:Fire(v74)
	end
	local v_u_76 = nil
	local v_u_77 = nil
	v_u_25 = function()
		-- upvalues: (ref) v_u_23, (copy) v_u_13, (ref) v_u_3, (copy) v_u_11, (ref) v_u_76
		if not v_u_23 then
			v_u_23 = {
				["type"] = "Map",
				["title"] = nil,
				["description"] = nil,
				["image"] = nil
			}
		end
		if v_u_23.creator then
			v_u_13.Buy.Visible = false
			v_u_13.BuyRobux.Visible = false
			v_u_13.Upload.Text = "SAVE CHANGES"
			v_u_13.Data.TypeChoice.Visible = false
		else
			v_u_13.Buy.Visible = true
			v_u_13.BuyRobux.Visible = true
			v_u_13.Upload.Text = "UPLOAD (" .. (v_u_3:GetAttribute("WorkshopAllowCount") or 2) .. " LEFT)"
			v_u_13.Data.TypeChoice.Visible = true
		end
		if v_u_23.type == "Moveset" then
			v_u_13.Data.TypeChoice.Moveset.BorderColor3 = Color3.fromRGB(85, 255, 255)
			v_u_13.Data.TypeChoice.Map.BorderColor3 = Color3.new(0, 0, 0)
			v_u_13.Data.TypeChoiceConfirm.Map.Visible = false
			v_u_13.Data.TypeChoiceConfirm.Moveset.Visible = true
			v_u_13.List.Visible = true
		else
			v_u_13.Data.TypeChoice.Map.BorderColor3 = Color3.fromRGB(85, 255, 255)
			v_u_13.Data.TypeChoice.Moveset.BorderColor3 = Color3.new(0, 0, 0)
			v_u_13.Data.TypeChoiceConfirm.Map.Visible = true
			v_u_13.Data.TypeChoiceConfirm.Moveset.Visible = false
			v_u_13.List.Visible = false
		end
		v_u_13.Data.TypeChoiceConfirm.Moveset.Map.Visible = false
		v_u_13.Settings.Description.Text = v_u_23.description or ""
		v_u_13.Settings.Title.Text = v_u_23.title or ""
		v_u_13.Settings.ImageId.Text = v_u_23.image or ""
		if v_u_13.Settings:FindFirstChild("Preview") then
			v_u_13.Settings.Preview:Destroy()
		end
		local v78 = v_u_11.Preset.WorkshopPreset:Clone()
		v78.Size = UDim2.new(1, 0, 0.4, 0)
		v78.LayoutOrder = 4
		v78.Background.Image = "rbxassetid://" .. (v_u_23.image or "")
		v78.Title.Text = v_u_23.title or ""
		v78.Description.Text = v_u_23.description or ""
		v78.Creator.Text = v_u_3.Name
		v78.Name = "Preview"
		v78.Parent = v_u_13.Settings
		for _, v79 in v_u_13.List.List:GetChildren() do
			if not v79:IsA("TextButton") then
				continue
			end
			if v79.Text == v_u_76 then
				v79.BorderColor3 = Color3.fromRGB(85, 255, 255)
			else
				v79.BorderColor3 = Color3.fromRGB(0, 0, 0)
			end
		end
	end
	local v_u_80 = {
		["Movesets"] = "Moveset",
		["Maps"] = "Map",
		["Favourites"] = "Favourite",
		["Uploads"] = "Upload"
	}
	v_u_24 = function(p81)
		-- upvalues: (copy) v_u_12, (ref) v_u_9, (ref) v_u_5, (ref) v_u_77, (copy) v_u_80, (ref) v_u_19, (ref) v_u_10, (copy) v_u_17, (copy) v_u_15
		for _, v82 in v_u_12.Categories:GetChildren() do
			if not v82:IsA("TextButton") then
				continue
			end
			v82.Select.Visible = v82 == p81
		end
		local v83 = p81.Name
		v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
		for _, v84 in v_u_12.Items:GetChildren() do
			v84.Visible = v83 == v84.Name
		end
		v_u_77 = nil
		v_u_12.Warning.Visible = false
		v_u_12.Items.Uploads.List.Visible = true
		v_u_12.Items.Uploads.Edit.Visible = false
		v_u_12.Options.Visible = true
		if v_u_80[v83] then
			v_u_19 = v_u_80[v83]
		end
		local v85 = v_u_10.CategoryPages[v_u_19]
		if v85 then
			for _, v86 in v_u_12.Options:QueryDescendants(".PageInfo") do
				v86.Visible = true
			end
			local v87, v88, v89 = unpack(v85)
			v_u_17.Text = ("%*/%*"):format(v87, v88)
			v_u_15.Results.Text = v89
		else
			for _, v90 in v_u_12.Options:QueryDescendants(".PageInfo") do
				v90.Visible = false
			end
		end
	end
	local v_u_91 = v_u_25
	local v_u_92 = v_u_76
	local v_u_93 = v_u_23
	local v_u_94 = v_u_22
	local v_u_95 = v_u_21
	local v_u_96 = v_u_19
	local v_u_97 = v_u_24
	local v_u_98 = v_u_20
	for _, v_u_99 in v_u_12.Categories:GetChildren() do
		if not v_u_99:IsA("TextButton") then
			continue
		end
		v_u_99.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_98, (ref) v_u_97, (copy) v_u_99
			if v_u_98 ~= true then
				v_u_97(v_u_99)
			end
		end)
	end
	local v_u_100 = {
		"\226\152\133",
		"\226\152\133 DAY",
		"\226\152\133 WEEK",
		"\226\152\133 MONTH",
		"NEW"
	}
	v_u_16.MouseButton1Click:Connect(function()
		-- upvalues: (ref) v_u_98, (copy) v_u_16, (copy) v_u_100, (ref) v_u_9, (ref) v_u_5, (copy) v_u_75
		if v_u_98 ~= true then
			local v101 = v_u_16.Text
			v_u_16.Text = v_u_100[table.find(v_u_100, v101) + 1] or "\226\152\133"
			v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
			v_u_75()
		end
	end)
	v_u_15.Next.MouseButton1Click:Connect(function()
		-- upvalues: (ref) v_u_98, (ref) v_u_10, (ref) v_u_96, (copy) v_u_17, (ref) v_u_9, (ref) v_u_5, (copy) v_u_75
		if v_u_98 == true then
			return
		else
			local v102 = v_u_10.CategoryPages[v_u_96]
			if v102 then
				local v103, v104 = unpack(v102)
				local v105 = v103 + 1
				local v106 = math.min(v105, v104)
				if v103 ~= v106 then
					v102[1] = v106
					v_u_17.Text = ("%*/%*"):format(v106, v104)
					v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
					v_u_75(true)
				end
			else
				return
			end
		end
	end)
	v_u_15.Back.MouseButton1Click:Connect(function()
		-- upvalues: (ref) v_u_98, (ref) v_u_10, (ref) v_u_96, (copy) v_u_17, (ref) v_u_9, (ref) v_u_5, (copy) v_u_75
		if v_u_98 == true then
			return
		else
			local v107 = v_u_10.CategoryPages[v_u_96]
			if v107 then
				local v108, v109 = unpack(v107)
				local v110 = v108 - 1
				local v111 = math.clamp(v110, 1, v109)
				if v108 ~= v111 then
					v107[1] = v111
					v_u_17.Text = ("%*/%*"):format(v111, v109)
					v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
					v_u_75(true)
				end
			else
				return
			end
		end
	end)
	v_u_15.Page.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_98, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10, (ref) v_u_96, (copy) v_u_15, (copy) v_u_75
		if v_u_98 == true then
			return
		else
			v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
			local v_u_112 = v_u_10.CategoryPages[v_u_96]
			if v_u_112 then
				local v_u_113, v_u_114 = unpack(v_u_112)
				local v_u_115 = v_u_15.Page.TextBox
				v_u_115.Text = v_u_113
				v_u_115.Visible = true
				v_u_115:CaptureFocus()
				v_u_115.FocusLost:Once(function()
					-- upvalues: (copy) v_u_115, (copy) v_u_114, (copy) v_u_113, (copy) v_u_112, (ref) v_u_75
					v_u_115.Visible = false
					local v116 = v_u_115.Text
					local v117 = tonumber(v116)
					if v117 then
						local v118 = v_u_114
						local v119 = math.clamp(v117, 1, v118)
						if v119 ~= v_u_113 then
							v_u_112[1] = v119
							v_u_75(true)
						end
					else
						return
					end
				end)
			end
		end
	end)
	v_u_15.Load.MouseButton1Click:Connect(function()
		-- upvalues: (ref) v_u_98, (ref) v_u_9, (ref) v_u_5, (copy) v_u_75
		if v_u_98 ~= true then
			v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
			v_u_75()
		end
	end)
	v_u_18.FocusLost:Connect(function(p120)
		-- upvalues: (ref) v_u_98, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10, (ref) v_u_96, (copy) v_u_75
		if p120 then
			if v_u_98 ~= true then
				v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
				v_u_10.CategoryPages[v_u_96][1] = 1
				v_u_75()
			end
		else
			return
		end
	end)
	v_u_7.Load:Connect(function(p121, p122, p123)
		-- upvalues: (copy) v_u_12, (ref) v_u_97, (ref) v_u_3, (ref) v_u_98, (ref) v_u_10, (copy) v_u_15, (copy) v_u_17, (copy) v_u_18, (ref) v_u_95, (ref) v_u_94, (copy) v_u_57
		local v124 = v_u_12.Items[("%*s"):format(p122)]
		v_u_97(v_u_12.Categories[v124.Name])
		if v124.Name == "Uploads" then
			v124 = v124.List
		end
		for _, v125 in v124:GetChildren() do
			if not v125:IsA("Frame") then
				continue
			end
			if v125.Name == "Upload" then
				v125.Visible = v_u_3:GetAttribute("PS_Owner") == true
			else
				v125:Destroy()
			end
		end
		v124.CanvasPosition = Vector2.new(0, 0)
		v_u_98 = false
		v_u_12.Loading.Visible = false
		if not p121 then
			return
		end
		local v126 = v_u_10.CategoryPages[p122]
		v_u_15.Results.Text = p121.total
		if v126 then
			v126[3] = p121.total
		end
		if p122 == "Map" or p122 == "Moveset" then
			local v127 = p121.pages or 1
			local v128 = math.max(v127, 1)
			local v129 = p121.page or 1
			local v130 = math.clamp(v129, 1, v128)
			v126[1] = v130
			v126[2] = v128
			v_u_17.Text = ("%*/%*"):format(v130, v128)
		elseif p122 == "Favourite" then
			v_u_18.Text = ""
			v_u_95 = p121.results
			local v131 = p121.total / 12
			local v132 = math.ceil(v131)
			local v133 = math.max(v132, 1)
			v126[1] = 1
			v126[2] = v133
			v_u_17.Text = ("%*/%*"):format(1, v133)
		end
		v_u_94 = p123
		for v134, v135 in p121.results or {} do
			if v134 > 20 then
				break
			end
			v_u_57(v135, v134)
		end
	end)
	v_u_7.Buy:Connect(function(p136, p137)
		-- upvalues: (ref) v_u_93, (ref) v_u_92, (copy) v_u_13, (ref) v_u_98, (copy) v_u_12, (ref) v_u_91
		if p136 then
			v_u_93 = p136
			if p137 then
				local v138 = game:GetService("HttpService"):JSONDecode(p137)
				v_u_92 = v138.Char
				if #v138.Data > 199999 then
					v_u_13.Data.TypeChoiceConfirm.Moveset.Text = "Data over 200k characters cannot be previewed, please paste your new code to apply edits"
				else
					v_u_13.Data.TypeChoiceConfirm.Moveset.Text = v138.Data
				end
			end
		end
		v_u_98 = false
		v_u_12.Loading.Visible = false
		v_u_12.Items.Uploads.Visible = true
		v_u_91()
	end)
	local _ = v_u_11.Preset.WorkshopPreset
	v_u_12.Items.Uploads.List.Upload.Option1.Edit.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_5, (copy) v_u_12, (ref) v_u_93, (ref) v_u_92, (ref) v_u_91
		v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_12.Items.Uploads.List.Visible = false
		v_u_12.Items.Uploads.Edit.Visible = true
		v_u_12.Options.Visible = false
		v_u_93 = nil
		v_u_92 = nil
		v_u_91()
		v_u_12.Items.Uploads.Edit.Data.TypeChoiceConfirm.Moveset.Text = ""
	end)
	v_u_13.Upload.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_98, (ref) v_u_9, (ref) v_u_5, (copy) v_u_13, (copy) v_u_12, (ref) v_u_96, (ref) v_u_7, (ref) v_u_93, (ref) v_u_92
		if v_u_98 ~= true then
			v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
			print(#v_u_13.Data.TypeChoiceConfirm.Moveset.Text)
			v_u_12.Items[("%*s"):format(v_u_96)].Visible = false
			v_u_98 = true
			v_u_12.Loading.Visible = true
			v_u_7.Upload:Fire(v_u_93, v_u_13.Data.TypeChoiceConfirm.Moveset.Text, v_u_92)
		end
	end)
	v_u_13.Data.TypeChoice.Map.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_93, (ref) v_u_9, (ref) v_u_5, (ref) v_u_91
		if v_u_93 then
			v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
			v_u_93.type = "Map"
			v_u_91()
		end
	end)
	v_u_13.Data.TypeChoice.Moveset.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_93, (ref) v_u_9, (ref) v_u_5, (ref) v_u_91
		if v_u_93 then
			v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
			v_u_93.type = "Moveset"
			v_u_91()
		end
	end)
	v_u_13.Settings.Title.FocusLost:Connect(function()
		-- upvalues: (ref) v_u_93, (ref) v_u_9, (ref) v_u_5, (copy) v_u_13, (ref) v_u_91
		if v_u_93 then
			v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
			v_u_93.title = v_u_13.Settings.Title.Text
			v_u_91()
		end
	end)
	v_u_13.Settings.Description.FocusLost:Connect(function()
		-- upvalues: (ref) v_u_93, (ref) v_u_9, (ref) v_u_5, (copy) v_u_13, (ref) v_u_91
		if v_u_93 then
			v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
			v_u_93.description = v_u_13.Settings.Description.Text
			v_u_91()
		end
	end)
	v_u_13.Settings.ImageId.FocusLost:Connect(function()
		-- upvalues: (ref) v_u_93, (ref) v_u_9, (ref) v_u_5, (copy) v_u_13, (ref) v_u_91
		if v_u_93 then
			v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
			v_u_93.image = v_u_13.Settings.ImageId.Text
			v_u_91()
		end
	end)
	v_u_13.Data.TypeChoiceConfirm.Moveset.FocusLost:Connect(function()
		-- upvalues: (ref) v_u_93, (ref) v_u_4, (copy) v_u_13, (ref) v_u_9, (ref) v_u_5
		if v_u_93 then
			local v_u_139 = require(v_u_4.Modules.Base64)
			local function v141()
				-- upvalues: (copy) v_u_139, (ref) v_u_13
				local v140 = v_u_139.from_base64(v_u_13.Data.TypeChoiceConfirm.Moveset.Text)
				game:GetService("HttpService"):JSONDecode(v140)
			end
			local v142, _ = pcall(v141)
			if v142 then
				v_u_13.Data.TypeChoiceConfirm.Moveset.Map.Visible = false
				v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
			else
				v_u_13.Data.TypeChoiceConfirm.Moveset.Text = ""
				v_u_13.Data.TypeChoiceConfirm.Moveset.Map.Visible = true
				v_u_9:PlaySound(v_u_5.Misc.UI.Error, workspace, game.SoundService.Effect)
			end
		else
			return
		end
	end)
	local v143 = 0
	for _, v_u_144 in require(game.ReplicatedStorage.Modules.ListData).MoveList do
		local v145 = v_u_11.Preset.Button:Clone()
		v145.LayoutOrder = v143
		v145.BackgroundColor3 = v_u_144[1][2]
		v143 = v143 + 1
		v145.Parent = v_u_13.List.List
		v145.Text = v_u_144[1][1]
		v145.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_9, (ref) v_u_5, (ref) v_u_92, (copy) v_u_144, (ref) v_u_91
			v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
			if v_u_92 == v_u_144[1][1] then
				v_u_92 = nil
			else
				v_u_92 = v_u_144[1][1]
			end
			v_u_91()
		end)
	end
	local v_u_146 = Instance.new("BindableFunction", v_u_13.Buy)
	function v_u_146.OnInvoke(_) -- name: OnInvoke
		-- upvalues: (ref) v_u_9, (ref) v_u_5, (ref) v_u_8
		v_u_9:PlaySound(v_u_5.Misc.UI.Switch, workspace, game.SoundService.Effect)
		v_u_8.Purchase:Fire("WorkshopSlot", "Cash")
	end
	v_u_13.Buy.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_5, (copy) v_u_146
		v_u_9:PlaySound(v_u_5.Misc.UI.Switch, workspace, game.SoundService.Effect)
		local v147 = {
			["Title"] = "Buy Upload",
			["Text"] = "Are you sure you want to purchase?",
			["Button1"] = "Yes",
			["Button2"] = "No",
			["Duration"] = 2,
			["Callback"] = nil,
			["Callback"] = v_u_146
		}
		game:GetService("StarterGui"):SetCore("SendNotification", v147)
	end)
	v_u_13.BuyRobux.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_5, (ref) v_u_8
		v_u_9:PlaySound(v_u_5.Misc.UI.Switch, workspace, game.SoundService.Effect)
		v_u_8.Purchase:Fire("WorkshopSlot", "Robux")
	end)
	local v_u_148 = v_u_12.Items.Movesets.Upload
	v_u_148.Menu.Option1.Edit.MouseButton1Down:Connect(function()
		-- upvalues: (copy) v_u_148
		v_u_148.Menu.Visible = false
		v_u_148.Edit.Visible = true
	end)
	v_u_148.Edit.Option1.Edit.MouseButton1Down:Connect(function()
		-- upvalues: (copy) v_u_148, (ref) v_u_7
		v_u_148.Menu.Visible = true
		v_u_148.Edit.Visible = false
		v_u_7.CustomUpload:Fire(v_u_148.Edit.TextBox.Text)
	end)
	v_u_148.Edit.TextBox.FocusLost:Connect(function()
		-- upvalues: (ref) v_u_4, (copy) v_u_148, (ref) v_u_3, (ref) v_u_9, (ref) v_u_5
		local v_u_149 = require(v_u_4.Modules.Base64)
		local function v151()
			-- upvalues: (copy) v_u_149, (ref) v_u_148
			local v150 = v_u_149.from_base64(v_u_148.Edit.TextBox.Text)
			game:GetService("HttpService"):JSONDecode(v150)
		end
		local v152, _ = pcall(v151)
		if not (v152 and v_u_3:GetAttribute("PS_Owner")) then
			v_u_148.Edit.TextBox.Text = ""
			v_u_9:PlaySound(v_u_5.Misc.UI.Error, workspace, game.SoundService.Effect)
		end
	end)
end
function v_u_10.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_7, (ref) v_u_6, (ref) v_u_8
	v_u_9 = v_u_1.GetController("FXController")
	v_u_7 = v_u_1.GetService("WorkshopService")
	v_u_6 = v_u_1.GetController("ShopController")
	v_u_8 = v_u_1.GetService("ShopService")
end
return v_u_10