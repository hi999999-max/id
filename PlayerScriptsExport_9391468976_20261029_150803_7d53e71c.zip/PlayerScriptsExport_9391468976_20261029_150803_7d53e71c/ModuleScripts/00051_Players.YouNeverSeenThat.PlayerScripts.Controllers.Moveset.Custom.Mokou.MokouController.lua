-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Custom.Mokou.MokouController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "MokouController"
})
local function v_u_28(p14, p15, p16, p17) -- name: getTweenData
	local v18 = p14:GetAttribute(p16 .. "_TweenParams")
	local v19 = {
		{ "TweenStyle", p17 },
		{ "TweenDirection", Enum.EasingDirection.Out }
	}
	local v_u_20 = {}
	if typeof(v18) == "string" then
		local v21 = { v18:match("(%a+),(%a+)") }
		for v22 = 1, 2 do
			local v_u_23 = v21[v22]
			local v24 = v19[v22]
			local v_u_25 = v24[1]
			local v26 = v24[2]
			if v_u_23 then
				if pcall(function()
					-- upvalues: (copy) v_u_20, (copy) v_u_25, (copy) v_u_23
					v_u_20[v_u_25] = Enum[v_u_25][v_u_23]
				end) then
					continue
				end
				v_u_20[v_u_25] = v26
			else
				v_u_20[v_u_25] = v26
			end
		end
	else
		for _, v27 in v19 do
			v_u_20[v27[1]] = v27[2]
		end
	end
	return TweenInfo.new(p15, v_u_20.TweenStyle, v_u_20.TweenDirection)
end
function v13.ArcTween(_, p29, p30) -- name: ArcTween
	-- upvalues: (copy) v_u_4, (copy) v_u_28
	local v31 = p29.Parent:FindFirstChild("End")
	if v31 then
		local v32 = p29:Clone()
		local v33 = p29.Parent
		local v34 = tonumber(v33:GetAttribute("StartTransparency")) or 0
		if v32:IsA("MeshPart") then
			v32.Transparency = v34
		elseif v32:IsA("BasePart") and v32:FindFirstChildOfClass("Decal") then
			v32.Transparency = 1
		end
		v32.Parent = workspace.Effects
		local v35 = p29.Parent
		local v36 = tonumber(v35:GetAttribute("Duration")) or 0.1
		if v32:FindFirstChildOfClass("Decal") then
			v_u_4:Create(v32, v_u_28(p29.Parent, v36, "Part", Enum.EasingStyle.Cubic), {
				["Size"] = v31.Size,
				["CFrame"] = v31.CFrame
			}):Play()
		else
			v_u_4:Create(v32, v_u_28(p29.Parent, v36, "Part", Enum.EasingStyle.Cubic), {
				["Size"] = v31.Size,
				["CFrame"] = v31.CFrame,
				["Color"] = v31.Color
			}):Play()
			if p30 == true then
				v_u_4:Create(v32, v_u_28(p29.Parent, v36, "Part", Enum.EasingStyle.Cubic), {
					["Transparency"] = 1
				}):Play()
			else
				v32.Transparency = 0
			end
		end
		local v37 = v32:FindFirstChildOfClass("SpecialMesh")
		local v38 = v31:FindFirstChildOfClass("SpecialMesh")
		if v37 and v38 then
			v_u_4:Create(v37, v_u_28(p29.Parent, v36, "Mesh", Enum.EasingStyle.Sine), {
				["Scale"] = v38.Scale
			}):Play()
		end
		local v39 = v32:FindFirstChildOfClass("Decal")
		local v40 = v31:FindFirstChildOfClass("Decal")
		if v39 and v40 then
			v39.Transparency = v34
			v_u_4:Create(v39, v_u_28(p29.Parent, v36, "Decal", Enum.EasingStyle.Cubic), {
				["Color3"] = v40.Color3
			}):Play()
			if p30 == true then
				v_u_4:Create(v39, v_u_28(p29.Parent, v36, "Decal", Enum.EasingStyle.Cubic), {
					["Transparency"] = 1
				}):Play()
			else
				v39.Transparency = 0
			end
		end
		task.delay(v36, v32.Destroy, v32)
	else
		warn("Goal is not defined.")
	end
end
function v13.KnitStart(p_u_41) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2, (ref) v_u_10, (ref) v_u_11
	local v_u_138 = {
		["Hit"] = function(p42, p43)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			local v44 = p42:FindFirstChild("HumanoidRootPart")
			if v44 then
				v_u_12:Flash(p42, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Misc.M.M1:FindFirstChild("Hit" .. p43), v44, game.SoundService.Effect)
				local v45 = v_u_7.Misc.M.Hit:Clone()
				v45.CFrame = v44.CFrame * CFrame.new(math.random(-20, 20) / 10, math.random(-20, 20) / 10, math.random(-10, 10) / 10)
				v45.Parent = workspace.Effects
				v45.Sparks:Emit(20)
				v_u_4:Create(v45, TweenInfo.new(0.15), {
					["Size"] = Vector3.new(7, 7, 7),
					["Transparency"] = 1,
					["Color"] = nil,
					["Color"] = Color3.new(1, 0.333333, 0)
				}):Play()
				v_u_3:AddItem(v45, 0.6)
				if p43 == 4 then
					v45.Flames:Emit(20)
				end
			end
		end,
		["ChaseHit"] = function(p46, p47)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v48 = p46:FindFirstChild("HumanoidRootPart")
			if v48 then
				local v49 = p47:FindFirstChild("HumanoidRootPart")
				if v49 then
					v_u_12:Flash(p47, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Misc.M.M1:FindFirstChild("Hit3"), v48, game.SoundService.Effect)
					local v50 = v_u_7.ChaseHit:Clone()
					local v51 = CFrame.new
					local v52 = v49.Position
					local v53 = v48.Position.X
					local v54 = v49.Position.Y
					local v55 = v48.Position.Z
					v50.CFrame = v51(v52, (Vector3.new(v53, v54, v55))) * CFrame.Angles(0, 3.141592653589793, 0)
					v50.Parent = workspace.Effects
					v50.Ring:Emit(7)
					v50.Sparks:Emit(12)
					v_u_3:AddItem(v50, 0.5)
					local v56 = v_u_7.Misc.M.Hit:Clone()
					v56.CFrame = v48.CFrame * CFrame.new(math.random(-20, 20) / 10, math.random(-20, 20) / 10, math.random(-10, 10) / 10)
					v56.Parent = workspace.Effects
					v56.Sparks:Emit(20)
					v_u_4:Create(v56, TweenInfo.new(0.15), {
						["Size"] = Vector3.new(7, 7, 7),
						["Transparency"] = 1,
						["Color"] = nil,
						["Color"] = Color3.new(1, 0.333333, 0)
					}):Play()
					v_u_3:AddItem(v56, 0.6)
				end
			else
				return
			end
		end,
		["AerialHit"] = function(p57, p58)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (ref) v_u_3
			local v59 = p57:FindFirstChild("HumanoidRootPart")
			if v59 then
				local v60 = p58:FindFirstChild("HumanoidRootPart")
				if v60 then
					v_u_12:Flash(p58, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Itadori.CraniumSmash.Hit2, v60, game.SoundService.Effect)
					if v_u_5.Character == p57 or v_u_5.Character == p58 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					end
					local v61 = CFrame.new(v59.Position, v60.Position - Vector3.new(0, 4, 0))
					local v62 = v_u_7.Gojo.HardHit:Clone()
					v62.CFrame = v61 + v61.LookVector * 4
					v62.Parent = workspace.Effects
					v62.Dust:Emit(5)
					v62.Ring:Emit(5)
					v62.Sparks:Emit(10)
					v_u_3:AddItem(v62, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p63)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8
			local v64 = p63.HumanoidRootPart
			if v64 then
				local v65 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v65.CFrame = v64.CFrame * CFrame.new(0, 1, -4)
				v65.Size = Vector3.new(0, 0, 2)
				v65.Parent = workspace.Effects
				v_u_4:Create(v65, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v65, 0.3)
				v_u_12:PlaySound(v_u_8.Misc.Chase, v64, game.SoundService.Effect)
				v_u_12:DustTrail(p63, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing2"] = function(p66, p67, p68)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v69 = p66.HumanoidRootPart
			if v69 then
				v_u_12:PlaySound(v_u_8.Misc.M.Swing[math.clamp(p67, 1, 4)], v69, game.SoundService.Effect)
				if p68 == "Down" then
					v_u_12:ArmFlash(p66["Right Leg"], Color3.fromRGB(255, 85, 0), 0.4)
					return
				elseif p68 == "Up" then
					v_u_12:ArmFlash(p66["Right Arm"], Color3.fromRGB(255, 85, 0), 0.3)
					return
				elseif p67 == 1 then
					v_u_12:ArmFlash(p66["Left Arm"], Color3.fromRGB(255, 85, 0), 0.3)
					return
				elseif p67 == 2 or p67 == 3 then
					v_u_12:ArmFlash(p66["Right Leg"], Color3.fromRGB(255, 85, 0), 0.3)
					return
				elseif p67 == 4 then
					v_u_12:ArmFlash(p66["Left Leg"], Color3.fromRGB(255, 85, 0), 0.4)
				elseif p67 == 5 then
					v_u_12:ArmFlash(p66["Right Arm"], Color3.fromRGB(255, 85, 0), 0.4)
				end
			else
				return
			end
		end,
		["Launch"] = function(p70, p71)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v72 = p70:FindFirstChild("HumanoidRootPart")
			if v72 then
				local v73 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v73.CFrame = CFrame.new(v72.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v73.Size = Vector3.new(0, 0, 5)
				v73.Parent = workspace.Effects
				v_u_4:Create(v73, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v73.Position + Vector3.new(0, p71, 0)
				}):Play()
				v_u_3:AddItem(v73, 0.3)
				if p71 < 0 then
					v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v72, game.SoundService.Effect)
					v_u_12:DustBreak(v72.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v72.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			end
		end,
		["Revive"] = function(p_u_74, p_u_75, p76)
			-- upvalues: (ref) v_u_5, (ref) v_u_3, (ref) v_u_4, (ref) v_u_9, (ref) v_u_7, (ref) v_u_12, (ref) v_u_8
			task.spawn(function()
				-- upvalues: (ref) v_u_5, (copy) p_u_74, (copy) p_u_75, (ref) v_u_3, (ref) v_u_4
				if v_u_5 == p_u_74 then
					workspace.CurrentCamera.CameraType = Enum.CameraType.Scriptable
				end
				repeat
					task.wait()
				until not (p_u_75.Parent and (p_u_74.Character and p_u_74.Parent))
				if v_u_5 == p_u_74 then
					workspace.CurrentCamera.CameraType = Enum.CameraType.Custom
					workspace.CurrentCamera.CameraSubject = p_u_74.Character:WaitForChild("Humanoid")
				end
				local v77 = Instance.new("Highlight", p_u_74.Character)
				v77.DepthMode = Enum.HighlightDepthMode.Occluded
				v77.OutlineColor = Color3.fromRGB(255, 255, 127)
				v77.FillColor = Color3.fromRGB(255, 255, 127)
				v77.FillTransparency = 0
				v_u_3:AddItem(v77, 0.7)
				v_u_4:Create(v77, TweenInfo.new(0.7, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
					["FillTransparency"] = 1,
					["OutlineTransparency"] = 1,
					["FillColor"] = nil,
					["OutlineColor"] = nil,
					["FillColor"] = Color3.fromRGB(0, 0, 0),
					["OutlineColor"] = Color3.fromRGB(255, 0, 0)
				}):Play()
			end)
			if (workspace.CurrentCamera.CFrame.Position - p76.Position).Magnitude < 150 then
				v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(1)
			end
			local v78 = v_u_7.Misc.M.Revive:Clone()
			v78.CFrame = p76
			v78.Parent = workspace.Effects
			v_u_12:PlaySound(v_u_8.Misc.M.Revive, v78, game.SoundService.Effect)
			v_u_3:AddItem(v78, 3)
			for _, v79 in v78.Activate:GetChildren() do
				if (v79:GetAttribute("EmitDuration") or 0) > 0 then
					v79.Enabled = true
				end
				if (v79:GetAttribute("EmitCount") or 0) <= 0 then
					continue
				end
				v79:Emit(v79:GetAttribute("EmitCount") or 0)
			end
			task.wait(0.6)
			for _, v80 in v78.Activate:GetChildren() do
				v80.Enabled = false
			end
			for _, v_u_81 in v78.Explode:GetChildren() do
				if (v_u_81:GetAttribute("EmitDuration") or 0) > 0 then
					v_u_81.Enabled = true
					task.delay(v_u_81:GetAttribute("EmitDuration") or 0, function()
						-- upvalues: (copy) v_u_81
						v_u_81.Enabled = false
					end)
				end
				if (v_u_81:GetAttribute("EmitCount") or 0) <= 0 then
					continue
				end
				v_u_81:Emit(v_u_81:GetAttribute("EmitCount") or 0)
			end
		end,
		["Wing"] = function(p82, p83)
			-- upvalues: (ref) v_u_7, (ref) v_u_3
			local v_u_84 = v_u_7.Misc.M.wing:Clone()
			v_u_84.Parent = p82.Torso
			p83:GetPropertyChangedSignal("Value"):Connect(function()
				-- upvalues: (copy) v_u_84
				for _, v85 in v_u_84.Left:GetDescendants() do
					if not (v85:IsA("ParticleEmitter") or (v85:IsA("Beam") or v85:IsA("PointLight"))) then
						continue
					end
					v85.Enabled = true
				end
				for _, v86 in v_u_84.prewing:GetDescendants() do
					if not (v86:IsA("ParticleEmitter") or (v86:IsA("Beam") or v86:IsA("PointLight"))) then
						continue
					end
					v86.Enabled = false
				end
				for _, v87 in v_u_84.right:GetDescendants() do
					if not (v87:IsA("ParticleEmitter") or (v87:IsA("Beam") or v87:IsA("PointLight"))) then
						continue
					end
					v87.Enabled = true
				end
			end)
			repeat
				task.wait()
			until not p83:IsDescendantOf(workspace.Characters)
			v_u_3:AddItem(v_u_84, 1.5)
			for _, v88 in v_u_84:GetDescendants() do
				if not (v88:IsA("ParticleEmitter") or (v88:IsA("Beam") or v88:IsA("PointLight"))) then
					continue
				end
				v88.Enabled = false
			end
		end,
		["WingFly"] = function(p89)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v90 = p89.HumanoidRootPart
			if v90 then
				local v91 = v_u_7.Misc.M.WingFly:Clone()
				v91:PivotTo(v90.CFrame)
				v91.Parent = workspace.Effects
				v_u_3:AddItem(v91, 3)
				for _, v92 in v91.WHAT["1"]:GetDescendants() do
					if not v92:IsA("ParticleEmitter") then
						continue
					end
					v92:Emit(v92:GetAttribute("EmitCount"))
				end
				v_u_4:Create(v91.WHAT, TweenInfo.new(0.4, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(18, 18, 18),
					["Color"] = nil,
					["Transparency"] = 1,
					["Color"] = Color3.fromRGB(255, 64, 0)
				}):Play()
				v_u_4:Create(v91.Mesh.Start, TweenInfo.new(1.5, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = nil,
					["Size"] = v91.Mesh.End.Size,
					["CFrame"] = v91.Mesh.End.CFrame
				}):Play()
				v_u_4:Create(v91.Mesh2.Start, TweenInfo.new(2, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = nil,
					["Size"] = v91.Mesh2.End.Size,
					["CFrame"] = v91.Mesh2.End.CFrame
				}):Play()
				v_u_4:Create(v91.Mesh3.Start, TweenInfo.new(2.5, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = nil,
					["Size"] = v91.Mesh3.End.Size,
					["CFrame"] = v91.Mesh3.End.CFrame
				}):Play()
				v91.Mesh.End:Destroy()
				v91.Mesh2.End:Destroy()
				v91.Mesh3.End:Destroy()
			end
		end,
		["Interp"] = function(p_u_93, p94, p95, p96)
			-- upvalues: (ref) v_u_2
			local v_u_97 = p96:Clone()
			v_u_97.CFrame = p94
			v_u_97.Parent = workspace.Effects
			local v_u_98 = tick() + p95
			local v_u_99 = nil
			v_u_99 = v_u_2.Stepped:Connect(function(_, p100)
				-- upvalues: (copy) p_u_93, (copy) v_u_98, (copy) v_u_97, (ref) v_u_99
				if p_u_93.Parent and v_u_98 >= tick() then
					v_u_97.CFrame = v_u_97.CFrame:Lerp(v_u_97.CFrame * p_u_93.Value, p100)
				else
					v_u_97:Destroy()
					v_u_99:Disconnect()
				end
			end)
		end,
		["Kill"] = function(p101)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_5, (ref) v_u_9, (ref) v_u_4
			local v102 = p101.HumanoidRootPart
			if v102 then
				v_u_12:PlaySound(v_u_8.Misc.M.Kill, v102, game.SoundService.Effect)
				for _, v103 in p101:GetDescendants() do
					if not (v103:IsA("BasePart") or v103:IsA("Decal")) then
						continue
					end
					v103.Transparency = 1
				end
				local v104 = v_u_7.Misc.M.TouhouBurst.Attachment:Clone()
				v104.Parent = v102
				v104.Burst:Emit(1)
				v104.Power:Emit(6)
				v104.Power2:Emit(1)
				if v_u_5.Character == p101 then
					v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(2)
					game.Lighting.ExposureCompensation = 3
					v_u_4:Create(game.Lighting, TweenInfo.new(1), {
						["ExposureCompensation"] = 0
					}):Play()
				end
			end
		end,
		["Awaken"] = function(p105)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_9, (ref) v_u_7, (ref) v_u_3, (copy) p_u_41, (ref) v_u_4
			local v106 = p105.HumanoidRootPart
			if v106 then
				v_u_12:PlaySound(v_u_8.Misc.M.MokouUlt, v106, game.SoundService.Effect)
				task.wait(0.3)
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
				local v107 = v_u_7.Misc.M.Awk.Att:Clone()
				v107.Parent = workspace.Effects
				v_u_3:AddItem(v107, 10)
				for _, v108 in v_u_7.Misc.M.Awk.mokultMeh["1"]:GetChildren() do
					v108:PivotTo(v106.CFrame)
					p_u_41:ArcTween(v108.Start, true)
				end
				for _, v109 in v107:GetChildren() do
					local v110 = Instance.new("Weld", v109)
					v110.Part0 = p105[v109.Name]
					v110.Part1 = v109
				end
				for _, v111 in v107.HumanoidRootPart["1"]:GetDescendants() do
					if not v111:IsA("ParticleEmitter") then
						continue
					end
					v111:Emit(v111:GetAttribute("EmitCount"))
				end
				local v112 = v_u_7.Misc.M.Awk.melting:Clone()
				v112.Parent = workspace.Effects
				v112.Weld.Part0 = v106
				v_u_3:AddItem(v112, 10)
				task.wait(1.75)
				for _, v113 in v107["Right Arm"]["2"]:GetDescendants() do
					if not v113:IsA("ParticleEmitter") then
						continue
					end
					v113.Enabled = true
				end
				for _, v114 in v112.Melt:GetDescendants() do
					if not v114:IsA("ParticleEmitter") then
						continue
					end
					v114.Enabled = false
				end
				v112.Melt22.Enabled = true
				for _, v115 in v112.Melt2:GetDescendants() do
					if not v115:IsA("ParticleEmitter") then
						continue
					end
					v115.Enabled = true
				end
				task.wait(1)
				local v116 = v_u_7.Misc.M.Awk.Pre:Clone()
				v116.CFrame = v106.CFrame
				v116.Parent = workspace.Effects
				v_u_3:AddItem(v116, 5)
				task.wait(0.2)
				v116.ParticleEmitter.Enabled = false
				v116.Attachment.ParticleEmitter:Emit(v116.Attachment.ParticleEmitter:GetAttribute("EmitCount"))
				task.wait(0.2)
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.SnapOh)
				for _, v117 in v107.HumanoidRootPart["2"]:GetDescendants() do
					if not v117:IsA("ParticleEmitter") then
						continue
					end
					v117:Emit(v117:GetAttribute("EmitCount"))
				end
				for _, v118 in v107["Right Arm"]["2"]:GetDescendants() do
					if not v118:IsA("ParticleEmitter") then
						continue
					end
					v118.Enabled = false
				end
				for _, v119 in v107["Right Arm"]["1"]:GetDescendants() do
					if not v119:IsA("ParticleEmitter") then
						continue
					end
					v119.Enabled = false
				end
				for _, v120 in v112:GetDescendants() do
					if not v120:IsA("ParticleEmitter") then
						continue
					end
					v120.Enabled = false
				end
				for _, v121 in v107.Head:GetDescendants() do
					if not v121:IsA("ParticleEmitter") then
						continue
					end
					v121.Enabled = true
				end
				v_u_7.Misc.M.Awk.mokultMeh["2"].Mesh2.Start.Decal.Color3 = Color3.fromRGB(5000, 300, 100)
				v_u_7.Misc.M.Awk.mokultMeh["2"].Mesh2.End.Decal.Color3 = Color3.fromRGB(5000, 100, 100)
				for _, v122 in v_u_7.Misc.M.Awk.mokultMeh["2"]:GetChildren() do
					v122:PivotTo(v106.CFrame)
					p_u_41:ArcTween(v122.Start, true)
				end
				task.wait(0.3)
				for _, v123 in v107.HumanoidRootPart["3"]:GetDescendants() do
					if not v123:IsA("ParticleEmitter") then
						continue
					end
					v123:Emit(v123:GetAttribute("EmitCount"))
				end
				local v124 = v_u_7.Misc.M.Awk.meshUP:Clone()
				v124.CFrame = v116.CFrame * CFrame.Angles(0, 0, 1.5707963267948966) + Vector3.new(0, 5, 0)
				v124.Parent = workspace.Effects
				v_u_3:AddItem(v124, 0.4)
				v_u_4:Create(v124, TweenInfo.new(0.3, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(102.794, 0.001, 0.001),
					["CFrame"] = nil,
					["CFrame"] = v124.CFrame + Vector3.new(0, 30, 0)
				}):Play()
				for _, v125 in v_u_7.Misc.M.Awk.mokultMeh["3"]:GetChildren() do
					v125:PivotTo(v106.CFrame)
					p_u_41:ArcTween(v125.Start, true)
				end
				task.wait(0.25)
				for _, v126 in v107.Torso["1"]:GetDescendants() do
					if not v126:IsA("ParticleEmitter") then
						continue
					end
					v126.Enabled = true
				end
				task.wait(1.6)
				for _, v127 in v107.Torso["2"]:GetDescendants() do
					if not v127:IsA("ParticleEmitter") then
						continue
					end
					v127.Enabled = true
				end
				task.wait(0.4)
				for _, v128 in v107.Torso["1"]:GetDescendants() do
					if not v128:IsA("ParticleEmitter") then
						continue
					end
					v128.Enabled = false
				end
				for _, v129 in v107.Torso["2"]:GetDescendants() do
					if not v129:IsA("ParticleEmitter") then
						continue
					end
					v129.Enabled = false
				end
				for _, v130 in v107.Torso["2.5"]:GetDescendants() do
					if not v130:IsA("ParticleEmitter") then
						continue
					end
					v130:Emit(v130:GetAttribute("EmitCount"))
				end
				local v_u_131 = v_u_7.Misc.M.Awk.GETIN:Clone()
				v_u_131.CFrame = v106.CFrame
				v_u_131.Parent = workspace.Effects
				v_u_3:AddItem(v_u_131, 5)
				task.delay(0.2, function()
					-- upvalues: (copy) v_u_131
					for _, v132 in v_u_131:GetDescendants() do
						if not v132:IsA("ParticleEmitter") then
							continue
						end
						v132.Enabled = false
					end
					for _, v133 in v_u_131.Attachment:GetDescendants() do
						if not v133:IsA("ParticleEmitter") then
							continue
						end
						v133.Enabled = true
					end
					task.wait(0.5)
					for _, v134 in v_u_131.Attachment:GetDescendants() do
						if not v134:IsA("ParticleEmitter") then
							continue
						end
						v134.Enabled = false
					end
				end)
				task.wait(0.7)
				for _, v135 in v107.Torso["2.7"]:GetDescendants() do
					if not v135:IsA("ParticleEmitter") then
						continue
					end
					v135:Emit(v135:GetAttribute("EmitCount"))
				end
				task.wait(0.05)
				v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(2)
				for _, v136 in v107.Torso["3"]:GetDescendants() do
					if not v136:IsA("ParticleEmitter") then
						continue
					end
					v136:Emit(v136:GetAttribute("EmitCount"))
				end
				task.wait(0.5)
				for _, v137 in v107.Head:GetDescendants() do
					if not v137:IsA("ParticleEmitter") then
						continue
					end
					v137.Enabled = false
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p139, ...)
		-- upvalues: (copy) v_u_138
		local v140 = v_u_138[p139]
		if v140 then
			v140(...)
		end
	end)
	v_u_10.Hitbox:Connect(function(p141, p142, p143)
		-- upvalues: (ref) v_u_11, (ref) v_u_4
		local v144 = p142.HumanoidRootPart
		if v144 then
			local v145 = nil
			local v146 = v_u_11:SphereHitbox(p142, CFrame.new(0, 0, -4), 8)
			for _, v147 in v146 do
				local v148 = v147:FindFirstChild("Info")
				if not v148 then
					continue
				end
				local v149 = v148:FindFirstChild("Knockback")
				if v149 and v149.Value == false then
					continue
				end
				v145 = v146
			end
			if v145 then
				local v150 = p141:FindFirstChildWhichIsA("NumberValue")
				if v150 then
					v_u_4:Create(v150, TweenInfo.new(0.1), {
						["Value"] = 0
					}):Play()
				end
			else
				task.wait(0.05)
				if p141.Parent then
					break
				end
			end
			p143:FireServer(v145, v144.CFrame)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("MokouService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
v13.SpawnAnim = "109651238159963"
v13.SpawnFunc = {
	["Startup"] = function(p_u_151, p152)
		-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_5, (copy) v_u_6
		local v153 = p_u_151.HumanoidRootPart
		if v153 then
			v_u_12:PlaySound(v_u_8.Misc.M.MokouSpawnVoice, v153, game.SoundService.Voice)
			local v154 = v_u_12:PlaySound(v_u_8.Misc.M.MokouSpawn, v153, game.SoundService.Effect)
			table.insert(p152, v154)
			task.wait(0.1)
			if v154.Parent then
				local v155 = v_u_7.Misc.M.SnapArm:Clone()
				v155.Weld.Part0 = p_u_151["Right Arm"]
				v155.Parent = workspace.Effects
				v155.Core.Sparks:Emit(15)
				v155.Core.Burst:Emit(1)
				table.insert(p152, v155)
				if v_u_5.Character == p_u_151 then
					local v_u_156 = require(v_u_6.Modules.TekrinnDialogue)
					v_u_156.Speak(p_u_151, {
						{
							["Text"] = "I\'ll show you the legendary phoenix...",
							["Color"] = nil,
							["TextStrokeColor"] = nil,
							["Bold"] = false,
							["Italic"] = true,
							["Shake"] = nil,
							["TypeSpeed"] = 0.08,
							["Color"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 0, 0)), ColorSequenceKeypoint.new(0.5, Color3.fromRGB(255, 170, 0)), ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 255, 255)) }),
							["TextStrokeColor"] = Color3.new(0.333333, 0, 0),
							["Shake"] = {
								["Enabled"] = false,
								["Intensity"] = 1,
								["Lifetime"] = 1
							}
						}
					})
					task.delay(3.8, function()
						-- upvalues: (copy) p_u_151, (copy) v_u_156
						if p_u_151.Parent then
							v_u_156.Speak(p_u_151, {
								{
									["Text"] = "that grows stronger each time it\'s reborn.",
									["Color"] = nil,
									["TextStrokeColor"] = nil,
									["Bold"] = false,
									["Italic"] = true,
									["Shake"] = nil,
									["TypeSpeed"] = 0.025,
									["Color"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 0, 0)), ColorSequenceKeypoint.new(0.5, Color3.fromRGB(255, 170, 0)), ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 255, 255)) }),
									["TextStrokeColor"] = Color3.new(0.333333, 0, 0),
									["Shake"] = {
										["Enabled"] = true,
										["Intensity"] = 3,
										["Lifetime"] = 1
									}
								}
							})
						end
					end)
				end
			end
		else
			return
		end
	end,
	["Hitbox"] = function(p157, p158)
		-- upvalues: (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (copy) v_u_9
		local v159 = p157.HumanoidRootPart
		if v159 then
			local v160 = v_u_7.Misc.M.FlameArm:Clone()
			v160.Weld.Part0 = p157["Left Arm"]
			v160.Parent = workspace.Effects
			v160.Core.Sparks:Emit(25)
			v160.Core.Ring:Emit(6)
			v160.Core.Flash:Emit(1)
			v160.Core.Burst:Emit(1)
			v160.Core.Flare:Emit(1)
			v160.Core.Heat:Emit(2)
			v_u_4:Create(v160.PointLight, TweenInfo.new(1.5), {
				["Brightness"] = 0,
				["Color"] = nil,
				["Color"] = Color3.new(1, 0, 0)
			}):Play()
			v_u_4:Create(v160.Core.Flames, TweenInfo.new(1.5), {
				["Rate"] = 0
			}):Play()
			table.insert(p158, v160)
			local v161 = v_u_7.Hiromi.Shockwave:Clone()
			v161.Position = v159.Position - Vector3.new(0, 3, 0)
			v161.Parent = workspace.Effects
			local v162 = v161.CFrame
			local v163 = CFrame.Angles
			local v164 = math.random(-179, 179)
			v161.CFrame = v162 * v163(0, math.rad(v164), 0)
			v_u_4:Create(v161.mesh.Mesh, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
				["Scale"] = Vector3.new(15, 0, 15)
			}):Play()
			v_u_4:Create(v161.mesh.Decal, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
				["Transparency"] = 1
			}):Play()
			v161.Floor.Glow:Emit(1)
			v161.Floor.Ring:Emit(10)
			v_u_3:AddItem(v161, 1.5)
			if (workspace.CurrentCamera.CFrame.Position - v159.Position).Magnitude < 150 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
			end
		end
	end
}
return v13