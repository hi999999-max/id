-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Reggie.Base.PianoDropController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v4 = game.ReplicatedStorage
local _ = v4.Animations
local v_u_5 = v4.Utils
local v_u_6 = v4.Sounds
local v_u_7 = require(v4.Modules.CameraShaker)
require(v4.Modules.BloodyZee)
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "PianoDropController"
})
function v12.ToolDeactivate(_)
	-- upvalues: (ref) v_u_11
	return v_u_11:GetMouseTarget(75)
end
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_5, (copy) v_u_3, (ref) v_u_11, (ref) v_u_10, (copy) v_u_6, (copy) v_u_2, (copy) v_u_7, (ref) v_u_8
	local v_u_36 = {
		["Hitbox"] = function(p13, p14)
			-- upvalues: (ref) v_u_5, (ref) v_u_3, (ref) v_u_11
			local v15 = v_u_5.Megumi.HitArea:Clone()
			v15.Size = Vector3.new(15, 0, 15)
			for _, v16 in v15:GetChildren() do
				local v17 = v16.Transparency
				v16.Transparency = 1
				v_u_3:Create(v16, TweenInfo.new(0.4), {
					["Transparency"] = v17
				}):Play()
			end
			v15.Parent = workspace.Effects
			local v18
			if p14 then
				v18 = v_u_5.Megumi.HitArea:Clone()
				v18.Size = Vector3.new(30, 0, 30)
				for _, v19 in v18:GetChildren() do
					v19.Color3 = Color3.fromRGB(255, 150, 150)
					local v20 = v19.Transparency
					v19.Transparency = 1
					v_u_3:Create(v19, TweenInfo.new(0.4), {
						["Transparency"] = v20
					}):Play()
				end
				v18.Parent = workspace.Effects
			else
				v18 = nil
			end
			local v21 = v_u_11:GetMouseTarget(75)
			local v22 = workspace:Raycast(v21 + Vector3.new(0, 1, 0), Vector3.new(0, -300, 0), _G.MapParams)
			if v22 then
				v21 = v22.Position
			end
			v15.Position = v21 + Vector3.new(0, 0.01, 0)
			if v18 then
				v18.Position = v21
			end
			task.wait()
			if p13 and (p13.Parent and not p13.Value) then
				continue
			end
			v15:Destroy()
			if v18 then
				v18:Destroy()
			end
		end,
		["Spawn"] = function(_, p23)
			-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_6, (ref) v_u_2
			local v24 = p23.Root:Clone()
			v24.Parent = workspace.Effects
			local v25 = v_u_5.Reggie.PianoDrop.Wind1:Clone()
			v25.Parent = v24
			local v26 = v_u_5.Reggie.PianoDrop.Wind2:Clone()
			v26.Parent = v24
			local v27 = v_u_5.Reggie.PianoDrop.Stage2:Clone()
			v27.Parent = v24
			local v28 = v_u_10:PlaySound(v_u_6.Reggie.PianoFall, v24, game.SoundService.Effect)
			task.wait()
			if p23:FindFirstChild("Root") then
				if p23:GetAttribute("Speed") > 1 and v25.Enabled == false then
					v25.Enabled = true
					v26.Enabled = true
					for _, v29 in v27:GetChildren() do
						v29.Enabled = true
					end
				end
				v24.CFrame = p23.Root.CFrame
				if p23.Parent ~= nil and not p23:GetAttribute("Dropped") then
					continue
				end
			end
			v_u_2:AddItem(v24, 3)
			v28:Stop()
			v25.Enabled = false
			v26.Enabled = false
			for _, v30 in v27:GetChildren() do
				v30.Enabled = false
			end
		end,
		["Smash"] = function(p31, p32)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_3, (ref) v_u_10, (ref) v_u_6, (ref) v_u_7
			local v33 = v_u_5.Megumi.Smash:Clone()
			v33.Position = p31
			v33.Parent = workspace.Effects
			v33.Dust:Emit(10)
			v33.Ring:Emit(10)
			v_u_2:AddItem(v33, 4)
			if p32 then
				local v34 = v_u_5.Megumi.Mahoraga.Earthquake:Clone()
				v34.Position = p31
				v34.Parent = workspace.Effects
				v34.Air:Destroy()
				v_u_3:Create(v34.PointLight, TweenInfo.new(0.6), {
					["Brightness"] = 0
				}):Play()
				v_u_3:Create(v34.Floor.Ring2, TweenInfo.new(0.4), {
					["TimeScale"] = 0.5
				}):Play()
				v34.Floor.Ring2:Emit(10)
				v34.Floor.Wind2:Emit(15)
				v34.Floor.Dust:Emit(100)
				v_u_2:AddItem(v34, 3)
				local v35 = v_u_5.Megumi.Mahoraga.WorldSlash.mesh:Clone()
				v35.Position = p31
				v35.Decal.Transparency = 0
				v35.Mesh.Scale = Vector3.new(2, 50, 2)
				v35.Parent = v34
				v_u_3:Create(v35, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
					["Size"] = Vector3.new(80, 40, 80),
					["CFrame"] = nil,
					["CFrame"] = v35.CFrame * CFrame.Angles(0, -3.12413936106985, 0)
				}):Play()
				v_u_3:Create(v35.Mesh, TweenInfo.new(0.65, Enum.EasingStyle.Exponential), {
					["Scale"] = Vector3.new(35, 10, 35)
				}):Play()
				v_u_3:Create(v35.Decal, TweenInfo.new(0.65, Enum.EasingStyle.Exponential), {
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v35, 0.65)
			end
			v_u_10:PlaySound(v_u_6.Reggie.PianoBreak, v33, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p31).Magnitude < 100 then
				v_u_7.CurrentShaker:Shake(v_u_7.Presets.SnapOh)
			end
		end
	}
	v_u_8.Effects:Connect(function(p37, ...)
		-- upvalues: (copy) v_u_36
		local v38 = v_u_36[p37]
		if v38 then
			v38(...)
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_8, (copy) v_u_1, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11
	v_u_8 = v_u_1.GetService("PianoDropService")
	v_u_9 = v_u_1.GetController("HitboxController")
	v_u_10 = v_u_1.GetController("FXController")
	v_u_11 = v_u_1.GetController("ToolController")
end
return v12