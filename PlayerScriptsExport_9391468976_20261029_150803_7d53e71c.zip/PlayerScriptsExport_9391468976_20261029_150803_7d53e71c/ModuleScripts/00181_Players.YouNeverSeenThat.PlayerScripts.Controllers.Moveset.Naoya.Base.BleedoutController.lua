-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Naoya.Base.BleedoutController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "BleedoutController"
})
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_9, (copy) v_u_4, (copy) v_u_8, (ref) v_u_10
	local v_u_41 = {
		["Startup"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_11:PlaySound(v_u_7.Naoya.Bleedout.Startup, v14, game.SoundService.Effect)
			end
		end,
		["Stab"] = function(p15)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				local v17 = v_u_6.Choso.CounterSwing:Clone()
				v17:PivotTo(v16.CFrame * CFrame.new(1, -1, -4) * CFrame.Angles(0, 0.2617993877991494, 0))
				v17.Parent = workspace.Effects
				v_u_2:AddItem(v17, 0.3)
				v17.Shock.Size = Vector3.new(10, 2, 10)
				v_u_3:Create(v17.Shock, TweenInfo.new(0.15), {
					["Size"] = Vector3.new(0, 15, 0),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v17.Shock2.Position + v16.CFrame.LookVector * 3
				}):Play()
				v_u_3:Create(v17.Shock2, TweenInfo.new(0.1), {
					["Size"] = Vector3.new(8, 0, 8),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v17.Shock2.Position + v16.CFrame.LookVector * 3
				}):Play()
				v_u_3:Create(v17.Shockwave, TweenInfo.new(0.15), {
					["Size"] = Vector3.new(0, 10, 0),
					["Transparency"] = 1,
					["CFrame"] = nil,
					["CFrame"] = v17.Shockwave.CFrame * CFrame.Angles(0, 3.12413936106985, 0)
				}):Play()
			end
		end,
		["Hit"] = function(p18, p19, p20)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_4, (ref) v_u_8
			local v21 = p19:FindFirstChild("HumanoidRootPart")
			if v21 then
				v_u_11:Flash(p19, Color3.new(1, 1, 1))
				if p20 then
					v_u_11:PlaySound(v_u_7.Misc.Bleed, v21, game.SoundService.Effect)
				else
					v_u_11:PlaySound(v_u_7.Naoya.Bleedout.Hit, v21, game.SoundService.Effect)
				end
				for _ = 1, 5 do
					v_u_9:Blood(p19.Torso.CFrame, math.random(5, 20), 25, 25)
				end
				if v_u_4.Character == p19 or v_u_4 == p18 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["Hit2"] = function(p22, p23)
			-- upvalues: (ref) v_u_9, (ref) v_u_4, (ref) v_u_8
			if p23:FindFirstChild("HumanoidRootPart") then
				for _ = 1, 20 do
					v_u_9:Blood(p23.Torso.CFrame, math.random(5, 80), 25, 25)
				end
				if v_u_4.Character == p23 or v_u_4 == p22 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Hit2Freeze"] = function(p24, p25)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			if p25:FindFirstChild("HumanoidRootPart") then
				if _G.Settings.Gore == true then
					local v_u_26 = v_u_6.Naoya.BleedFreeze.Attachment:Clone()
					v_u_26.Parent = p25.Torso
					v_u_26.Blood:Emit(100)
					task.delay(0.3, function()
						-- upvalues: (copy) v_u_26, (ref) v_u_3
						v_u_26.Blood.TimeScale = 0.01
						task.wait(0.75)
						v_u_3:Create(v_u_26.Blood, TweenInfo.new(0.2), {
							["TimeScale"] = 0.5
						}):Play()
					end)
				end
				if v_u_4.Character == p25 or v_u_4 == p24 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Throw"] = function(p27)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v28 = p27:FindFirstChild("HumanoidRootPart")
			if v28 then
				v_u_11:PlaySound(v_u_7.Naoya.Bleedout.Throw, v28, game.SoundService.Effect)
			end
		end,
		["FinishingStab"] = function(p29, p30)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_4, (ref) v_u_8
			local v31 = p30:FindFirstChild("HumanoidRootPart")
			if v31 then
				v_u_11:PlaySound(v_u_7.Naoya.Bleedout.FinisherStab, v31, game.SoundService.Effect)
				for _ = 1, 20 do
					v_u_9:Blood(p30.Torso.CFrame, math.random(5, 80), 25, 25)
				end
				if v_u_4.Character == p30 or v_u_4 == p29 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["Afterimages"] = function(p32, p33)
			-- upvalues: (ref) v_u_4, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_6
			local v34 = p32:FindFirstChild("HumanoidRootPart")
			if v34 then
				if v_u_4.Character == p33 or v_u_4.Character == p32 then
					v_u_3:Create(workspace.CurrentCamera, TweenInfo.new(0.75, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["FieldOfView"] = 60
					}):Play()
					local v_u_35 = Instance.new("ColorCorrectionEffect", game.Lighting)
					v_u_2:AddItem(v_u_35, 2.2)
					v_u_35.TintColor = Color3.fromRGB(0, 0, 0)
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_35, (ref) v_u_3
						v_u_35.TintColor = Color3.fromRGB(135, 167, 255)
						v_u_35.Saturation = -0.5
						v_u_35.Brightness = 0.2
						task.wait(0.65)
						v_u_3:Create(v_u_35, TweenInfo.new(0.2), {
							["TintColor"] = nil,
							["Saturation"] = 0,
							["Brightness"] = 0,
							["TintColor"] = Color3.fromRGB(255, 255, 255)
						}):Play()
						v_u_3:Create(workspace.CurrentCamera, TweenInfo.new(0.4, Enum.EasingStyle.Exponential, Enum.EasingDirection.InOut), {
							["FieldOfView"] = 70
						}):Play()
					end)
					v_u_11:PlaySound(v_u_7.Naoya.Bleedout.Afterimages, workspace, game.SoundService.Effect)
				else
					v_u_11:PlaySound(v_u_7.Naoya.Bleedout.Afterimages, v34, game.SoundService.Effect)
				end
				for v36 = 1, 7 do
					local v37 = v_u_6.Damage.HitGlow:Clone()
					v_u_2:AddItem(v37, 1)
					v37.Parent = workspace.Effects
					local v38 = TweenInfo.new(1 - v36 * 0.1)
					for _, v39 in v37:GetChildren() do
						v39.Color = Color3.fromRGB(128, 126, 255)
						v39.Transparency = 0.2
						v39.Anchored = true
						v39.CFrame = p32[v39.Name].CFrame
						v_u_3:Create(v39, v38, {
							["Transparency"] = 1
						}):Play()
					end
					task.wait(0.1)
				end
			end
		end,
		["Flash"] = function(p40)
			-- upvalues: (ref) v_u_11
			if p40:FindFirstChild("HumanoidRootPart") then
				v_u_11:Flash(p40, Color3.new(1, 1, 1), 0.5)
			end
		end
	}
	v_u_10.Effects:Connect(function(p42, ...)
		-- upvalues: (copy) v_u_41
		local v43 = v_u_41[p42]
		if v43 then
			v43(...)
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("BleedoutService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12