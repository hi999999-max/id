-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.MeiMei.Base.BirdControlController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
require(v_u_5.Modules.CameraShaker)
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "BirdControlController"
})
local v12 = RaycastParams.new()
v12.FilterType = Enum.RaycastFilterType.Include
v12.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
function v11.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_6, (ref) v_u_9, (copy) v_u_3, (copy) v_u_7, (copy) v_u_5, (copy) v_u_2, (copy) v_u_4, (ref) v_u_8
	local v_u_57 = {
		["Eye"] = function(p13, p14)
			-- upvalues: (ref) v_u_6, (ref) v_u_9, (ref) v_u_3, (ref) v_u_7
			local v15 = p13:FindFirstChild("HumanoidRootPart")
			if v15 then
				local v16 = v_u_6.MeiMei.CrowEye:Clone()
				v16.Parent = p13.Head
				v_u_9:PlayParticles(v16)
				v_u_3:AddItem(v16, 1)
				v_u_9:PlaySound(v_u_7.MeiMei.BirdControl.CrowEye, v15, game.SoundService.Effect).Volume = 2
				if p14 then
					local v17 = p14:FindFirstChild("HumanoidRootPart")
					if not v17 then
						return
					end
					v_u_9:PlaySound(v_u_7.Hiromi.Grapple.Start, v15, game.SoundService.Effect)
					local v18 = v_u_6.Itadori.CounterHit.Feint:Clone()
					for _, v19 in v18:GetChildren() do
						v19.Color = ColorSequence.new(Color3.fromRGB(30, 40, 80))
						v19.TimeScale = 0.75
					end
					v18.Parent = v17
					v18.Sparks:Emit(30)
					v18.Ring:Emit(6)
					v_u_3:AddItem(v18, 1)
				end
			end
		end,
		["Hit"] = function(p20)
			-- upvalues: (ref) v_u_9, (ref) v_u_7
			local v21 = p20:FindFirstChild("HumanoidRootPart")
			if v21 then
				v_u_9:Flash(p20, Color3.new(1, 1, 1))
				v_u_9:PlaySound(v_u_7.MeiMei.BirdControl.Hit, v21, game.SoundService.Effect)
			end
		end,
		["Explode"] = function(_, p22)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_9, (ref) v_u_7
			local v23 = v_u_6.Damage.CrowExplode:Clone()
			v23.Parent = workspace.Effects
			v23.Position = p22
			v_u_3:AddItem(v23, 4)
			v_u_9:PlaySound(v_u_7.MeiMei.BirdControl.Impact, v23, game.SoundService.Effect)
			for _, v24 in v23:GetDescendants() do
				if not v24:IsA("ParticleEmitter") or v24.Name == "Sparks" then
					continue
				end
				v24:Emit(v24:GetAttribute("EmitCount"))
			end
		end,
		["Interp"] = function(p_u_25, p26, p27)
			-- upvalues: (ref) v_u_9, (ref) v_u_7, (ref) v_u_5, (ref) v_u_2
			if p26 then
				v_u_9:PlaySound(v_u_7.Misc.Crow["Caw" .. math.random(1, 3)], p_u_25, game.SoundService.Effect).RollOffMaxDistance = 250
			end
			local v_u_28 = v_u_9:PlaySound(v_u_7.MeiMei.BirdControl.Fly, p_u_25, game.SoundService.Effect)
			v_u_28.PlaybackSpeed = 2
			p_u_25:GetAttributeChangedSignal("Speed"):Connect(function()
				-- upvalues: (copy) v_u_28
				v_u_28.PlaybackSpeed = 1
			end)
			if p27 then
				local v29 = v_u_5.Utils.MeiMei.CrowWind:Clone()
				v29.Weld.Part0 = p_u_25
				v29.Parent = p_u_25.Parent
				v_u_9:PlaySound(v_u_7.MeiMei.CrowLaunch, p_u_25, game.SoundService.Effect)
			end
			local v_u_30 = p_u_25.CFrame
			local v_u_31 = tick()
			local v_u_32 = p_u_25:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_30, (copy) p_u_25, (ref) v_u_31
				v_u_30 = p_u_25.CFrame
				v_u_31 = tick()
			end)
			local v_u_33 = nil
			v_u_33 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_25, (ref) v_u_33, (copy) v_u_32, (copy) v_u_28, (ref) v_u_30, (ref) v_u_31
				if p_u_25.Parent and p_u_25:GetAttribute("Speed") then
					workspace:BulkMoveTo({ p_u_25 }, { v_u_30 + v_u_30.LookVector * (p_u_25:GetAttribute("Speed") * (tick() - v_u_31)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_33:Disconnect()
					v_u_32:Disconnect()
					v_u_28:Destroy()
				end
			end)
		end,
		["Flight"] = function(p34, p35, p36, p37)
			-- upvalues: (ref) v_u_9, (ref) v_u_7, (ref) v_u_4
			local v38 = p34:FindFirstChild("HumanoidRootPart")
			if v38 then
				local v39 = p34:FindFirstChild("Humanoid")
				local v40 = p37.PrimaryPart
				local v41 = v40.CFrame - v40.Position
				v_u_9:PlaySound(v_u_7.MeiMei.BirdControl.Grab, v38, game.SoundService.Effect)
				p36:Destroy()
				v40.Anchored = true
				local v42 = nil
				local v43 = task.wait()
				local v44 = p35.Velocity.Magnitude > 0 and p35.Velocity.Unit or v40.CFrame.LookVector
				v41 = v41:Lerp(CFrame.lookAt(Vector3.new(0, 0, 0), v44), 0.2 * v43 * 60)
				local v45 = p34["Left Arm"].CFrame:VectorToWorldSpace(Vector3.new(0, -1.5, 0))
				local v46 = p34["Left Arm"].Position + v45
				p37:PivotTo(CFrame.new(v46) * v41 * CFrame.new(0, 0, -1.4))
				if p34 == v_u_4.Character then
					local v47 = require(v_u_4.PlayerScripts.PlayerModule.ControlModule):GetMoveVector()
					local v48 = workspace.CurrentCamera.CFrame.LookVector
					local v49 = CFrame.lookAt
					local v50 = v48.X
					local v51 = v48.Z
					local v52 = v49(Vector3.new(0, 0, 0), Vector3.new(v50, 0, v51).Unit)
					local v53 = v52:VectorToWorldSpace(v47)
					if v42 == nil then
						v42 = Instance.new("BodyGyro")
						v42.P = 10000
						v42.MaxTorque = Vector3.new(40000, 40000, 40000)
						v42.CFrame = v52
						v42.Parent = v38
						v39.PlatformStand = true
					end
					local v54 = v53.X
					local v55 = v53.Z
					local v56 = Vector3.new(v54, 0, v55)
					if v56.Magnitude > 1 then
						v56 = v56.Unit
					end
					p35.Velocity = p35.Velocity:Lerp(v56 * 25 * 1.3, 0.05 * v43 * 60)
					if p35.Velocity.Magnitude < 0.5 then
						p35.Velocity = p35.Velocity.Unit * 0.5
					end
					v42.CFrame = v52
				end
				if v38.Parent ~= nil and (p35.Parent ~= nil and p34.Parent ~= nil) then
					continue
				end
				v39.PlatformStand = false
				if p35 then
					p35:Destroy()
				end
				if v42 then
					v42:Destroy()
				end
			end
		end
	}
	v_u_8.Effects:Connect(function(p58, ...)
		-- upvalues: (copy) v_u_57
		local v59 = v_u_57[p58]
		if v59 then
			v59(...)
		end
	end)
end
function v11.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_8, (copy) v_u_1, (ref) v_u_9, (ref) v_u_10
	v_u_8 = v_u_1.GetService("BirdControlService")
	v_u_9 = v_u_1.GetController("FXController")
	v_u_10 = v_u_1.GetController("ToolController")
end
return v11