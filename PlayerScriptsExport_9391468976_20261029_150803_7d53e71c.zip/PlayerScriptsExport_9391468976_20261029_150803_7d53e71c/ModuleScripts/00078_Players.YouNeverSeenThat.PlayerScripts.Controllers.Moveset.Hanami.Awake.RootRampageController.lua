-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Hanami.Awake.RootRampageController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
require(v_u_5.Modules.CameraShaker)
require(v_u_5.Modules.BloodyZee)
local v_u_8 = nil
local v_u_9 = nil
local v10 = v_u_1.CreateController({
	["Name"] = "RootRampageController"
})
local v_u_11 = workspace.CurrentCamera
local v_u_12 = Random.new()
local function v_u_46(p13, p14, p15) -- name: CreateRampageRootsForHitbox
	-- upvalues: (copy) v_u_12, (copy) v_u_5, (ref) v_u_9, (copy) v_u_2
	local v16 = 25
	local v17 = {}
	for _ = 1, 3 do
		local v18 = v_u_12:NextNumber(-2, 2)
		local v19 = v_u_12:NextNumber(-2, 2)
		local v20 = v_u_12:NextNumber(-4, 4)
		local v21 = v_u_12:NextNumber(4, 6)
		local v22 = math.cos(p14) * 1.5
		local v23 = v21 + math.sin(p14) * 2
		local v24 = p14 * 0.5
		local v25 = math.cos(v24) * 1.5
		local v26 = vector.create(v22, v23, v25)
		local _ = p13.CFrame * CFrame.new(v18, -1.5, -4 + v19).Position
		local v27 = p13.CFrame * CFrame.new(v18 + v20, -1.5, 4 + v19).Position
		p13.CFrame = p13.CFrame
		local v28
		if workspace:Raycast(p13.CFrame * CFrame.new(v18, 1, -4 + v19).Position, Vector3.new(0, -3, 0), _G.MapParams) then
			v28 = p13.CFrame * CFrame.new(v18, -1.5, -4 + v19).Position
			p13.CFrame = p13.CFrame
		else
			v28 = p13.CFrame * CFrame.new(v18, v_u_12:NextNumber(-4, 4), -4 + v19).Position
			local v29 = v_u_12:NextNumber(-10, 10) * math.cos(p14)
			local v30 = v_u_12:NextNumber(-10, 10) * math.cos(p14)
			local v31 = v_u_12:NextNumber(-10, 10) * math.cos(p14)
			v26 = vector.create(v29, v30, v31)
		end
		if workspace:Raycast(p13.CFrame * CFrame.new(v18 + v20, 1, 4 + v19).Position, Vector3.new(0, -3, 0), _G.MapParams) then
			v27 = p13.CFrame * CFrame.new(v18 + v20, -1.5, 4 + v19).Position
		elseif p13.CFrame then
			v28 = p13.CFrame * CFrame.new(v18, v_u_12:NextNumber(-2, 2), -6 + v19).Position
			v27 = p13.CFrame * CFrame.new(v18, -1.5, 10 + v19).Position
		end
		local v32 = (v27 + v28) / 2 + v26
		local v33 = v_u_12:NextNumber(1.5, 2)
		v16 = v16 * (v_u_12:NextInteger(0, 1) * 2 - 1)
		if not p15 then
			local v34 = v_u_5.Utils.Hanami.RootsDust:Clone()
			v34.Position = v27
			v34.Size = vector.create(v33, 0.25, v33)
			v_u_9:PlayParticles(v34)
			v34.Parent = workspace.Effects
			v_u_2:AddItem(v34, 2)
		end
		local v35 = v27
		for v36 = 1, 5 do
			local v37 = v36 / 5
			local v38 = v_u_12:NextNumber(0.75, 1.25)
			local v39 = v37 * 3.141592653589793
			local v40 = v33 * (v38 + math.cos(v39) * 0.25)
			local v41 = Instance.new("Part")
			v41.Name = v36
			v41.CanCollide = true
			v41.Anchored = true
			v41.Color = Color3.fromRGB(67, 47, 35)
			v41.Material = Enum.Material.Wood
			table.insert(v17, v41)
			local v42 = v35 + (v32 - v35) * v37
			local v43 = v42 + (v32 + (v28 - v32) * v37 - v42) * v37
			local v44 = (v43 - v27).Magnitude * 1.25
			v41.Size = vector.create(v40, v40, v44)
			v41.Position = v43
			local v45 = (v36 - 1) * math.rad(v16)
			v41.CFrame = CFrame.new(v43, v27) * CFrame.new(0, 0, -(v27 - v43).Magnitude / 2) * CFrame.Angles(0, 0, v45)
			v41.Parent = workspace.Effects
			if p15 then
				v27 = v43
			else
				task.wait(0.009999999999999998)
				v27 = v43
			end
		end
	end
	return v17
end
local function v_u_75(p47, p48) -- name: CreateSurfRootsForHitbox
	-- upvalues: (copy) v_u_12, (copy) v_u_5, (ref) v_u_9, (copy) v_u_2
	local v49 = 25
	local v50 = {}
	for _ = 1, 3 do
		local v51 = v_u_12:NextNumber(-2, 2)
		local v52 = v_u_12:NextNumber(-2, 2)
		local v53 = v_u_12:NextNumber(-4, 4)
		local v54 = v_u_12:NextNumber(4, 6)
		local v55 = vector.create(0, v54, 0)
		local _ = p47.CFrame * CFrame.new(v51, -1.5, -4 + v52).Position
		local v56 = p47.CFrame * CFrame.new(v51 + v53, -1.5, 4 + v52).Position
		p47.CFrame = p47.CFrame
		local v57
		if workspace:Raycast(p47.CFrame * CFrame.new(v51, 1, -4 + v52).Position, Vector3.new(0, -3, 0), _G.MapParams) then
			v57 = p47.CFrame * CFrame.new(v51, -1.5, -4 + v52).Position
			p47.CFrame = p47.CFrame
		else
			v57 = p47.CFrame * CFrame.new(v51, v_u_12:NextNumber(-4, 4), -4 + v52).Position
			local v58 = v_u_12:NextNumber(-2, 2)
			local v59 = v_u_12:NextNumber(-4, 4)
			local v60 = v_u_12
			v55 = vector.create(v58, v59, v60:NextNumber(-2, 2))
		end
		if workspace:Raycast(p47.CFrame * CFrame.new(v51 + v53, 1, 4 + v52).Position, Vector3.new(0, -3, 0), _G.MapParams) then
			v56 = p47.CFrame * CFrame.new(v51 + v53, -1.5, 4 + v52).Position
		elseif p47.CFrame then
			v57 = p47.CFrame * CFrame.new(v51, v_u_12:NextNumber(-2, 2), -6 + v52).Position
			v56 = p47.CFrame * CFrame.new(v51, -1.5, 10 + v52).Position
		end
		local v61 = (v56 + v57) / 2 + v55
		local v62 = v_u_12:NextNumber(1.5, 2)
		v49 = v49 * (v_u_12:NextInteger(0, 1) * 2 - 1)
		local v63 = v_u_5.Utils.Hanami.RootsDust:Clone()
		v63.Position = v56
		v63.Size = vector.create(v62, 0.25, v62)
		v_u_9:PlayParticles(v63)
		v63.Parent = p48
		v_u_2:AddItem(v63, 2)
		local v64 = v56
		for v65 = 1, 5 do
			local v66 = v65 / 5
			local v67 = v_u_12:NextNumber(0.75, 1.25)
			local v68 = v66 * 3.141592653589793
			local v69 = v62 * (v67 + math.cos(v68) * 0.25)
			local v70 = Instance.new("Part")
			v70.Name = v65
			v70.CanCollide = true
			v70.Anchored = true
			v70.Color = Color3.fromRGB(67, 47, 35)
			v70.Material = Enum.Material.Wood
			table.insert(v50, v70)
			local v71 = v56 + (v61 - v56) * v66
			local v72 = v71 + (v61 + (v57 - v61) * v66 - v71) * v66
			local v73 = (v72 - v64).Magnitude * 1.25
			v70.Size = vector.create(v69, v69, v73)
			v70.Position = v72
			local v74 = (v65 - 1) * math.rad(v49)
			v70.CFrame = CFrame.new(v72, v64) * CFrame.new(0, 0, -(v64 - v72).Magnitude / 2) * CFrame.Angles(0, 0, v74)
			v70.Parent = p48
			task.wait(0.009999999999999998)
			v64 = v72
		end
	end
	return v50
end
function v10.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_9, (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (copy) v_u_11, (copy) v_u_46, (copy) v_u_2, (copy) v_u_5, (copy) v_u_6, (copy) v_u_75, (ref) v_u_8
	local v_u_212 = {
		["Windup"] = function(p76, p77)
			-- upvalues: (ref) v_u_9, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			local v78 = p76:FindFirstChild("HumanoidRootPart")
			if v78 then
				v_u_9:PlaySound(v_u_7.Hanami.RootRampage.Start, v78, game.SoundService.Effect)
				local v79 = v_u_9
				local v80 = v_u_7.Hanami.RootRampage.OST
				if p76 == v_u_4.Character then
					v78 = workspace or v78
				end
				local v_u_81 = v79:PlaySound(v80, v78, game.SoundService.Music)
				p77.AncestryChanged:Connect(function()
					-- upvalues: (copy) v_u_81, (ref) v_u_3
					if v_u_81.Parent then
						v_u_3:Create(v_u_81, TweenInfo.new(1), {
							["Volume"] = 0
						}):Play()
						task.wait(1)
						v_u_81:Destroy()
					end
				end)
			end
		end,
		["Roots"] = function(p_u_82, p_u_83, p_u_84, p_u_85)
			-- upvalues: (ref) v_u_4, (ref) v_u_11, (ref) v_u_3, (ref) v_u_46, (ref) v_u_9, (ref) v_u_7, (ref) v_u_2, (ref) v_u_5
			local v_u_86
			if v_u_4 == p_u_82 then
				local v_u_87 = v_u_4.Character
				if not v_u_87 then
					return
				end
				local v_u_88 = v_u_87:FindFirstChild("HumanoidRootPart")
				if not v_u_88 then
					return
				end
				local v_u_89 = Instance.new("Part")
				v_u_89.Anchored = true
				v_u_89.Size = Vector3.new(1, 1, 1)
				v_u_89.CanCollide = false
				v_u_89.Transparency = 1
				v_u_89.CFrame = v_u_88.CFrame
				v_u_89.Parent = workspace.Effects
				v_u_11.CameraSubject = v_u_89
				task.spawn(function()
					-- upvalues: (copy) p_u_84, (ref) v_u_11, (ref) v_u_89, (copy) v_u_88, (copy) v_u_87
					while p_u_84.Parent do
						p_u_84:FireServer(v_u_11.CFrame.LookVector)
						task.wait()
					end
					local v90 = v_u_89.Position
					local v91 = tick()
					repeat
						local v92 = (tick() - v91) / 0.15
						v_u_89.Position = v90:Lerp(v_u_88.Position, v92)
						task.wait()
					until v92 >= 1
					v_u_11.CameraSubject = v_u_87.Humanoid
				end)
				v_u_86 = v_u_89
			else
				v_u_86 = nil
			end
			if p_u_82 then
				p_u_82 = p_u_82.Character.Info:FindFirstChild("DomainTag")
			end
			local v_u_93 = {}
			local v_u_94 = {}
			local v_u_95 = {}
			local v_u_96 = 0
			task.spawn(function()
				-- upvalues: (copy) p_u_83, (ref) v_u_96
				while p_u_83.Parent do
					v_u_96 = v_u_96 + 50 * task.wait()
				end
			end)
			p_u_83.OnClientEvent:Connect(function(p97, p98, p99, p_u_100)
				-- upvalues: (ref) v_u_11, (ref) v_u_86, (ref) v_u_3, (copy) p_u_85, (ref) v_u_46, (ref) v_u_96, (copy) v_u_93, (ref) v_u_9, (ref) v_u_7, (copy) v_u_95, (ref) v_u_2, (copy) v_u_94
				if p97 == "PB" then
					v_u_11.CFrame = CFrame.lookAlong(v_u_11.CFrame.Position, p98)
				else
					if v_u_86 and p99 then
						v_u_3:Create(v_u_86, TweenInfo.new(0.15), {
							["CFrame"] = p98 * CFrame.new(0, 5, 0)
						}):Play()
					end
					local v101 = {
						["CFrame"] = p98,
						["Size"] = p_u_85
					}
					local v_u_102 = v_u_46(v101, v_u_96)
					if v_u_93[p_u_100] then
						local function v103()
							-- upvalues: (ref) v_u_95, (copy) p_u_100, (copy) v_u_102
							v_u_95[p_u_100].Parent = v_u_102[#v_u_102]
						end
						pcall(v103)
					else
						v_u_9:PlaySound(v_u_7.Hanami.RootRampage.RootAppear, v_u_102[1], game.SoundService.Effect)
						v_u_95[p_u_100] = v_u_9:PlaySound(v_u_7.Hanami.RootRampage.RootLoop, v_u_102[#v_u_102], game.SoundService.Effect)
						v_u_2:AddItem(v_u_95[p_u_100], 8)
						v_u_93[p_u_100] = {}
						v_u_94[p_u_100] = {}
					end
					local v104 = v_u_94[p_u_100]
					table.insert(v104, v101)
					local v105 = #v_u_94[p_u_100] <= 3 and true or nil
					for _, v106 in v_u_102 do
						if v105 then
							v106.CanCollide = false
						end
						local v107 = v_u_93[p_u_100]
						table.insert(v107, v106)
					end
				end
			end)
			local v_u_108 = v_u_5.Utils.Hanami.ParticleDissipationHolder
			p_u_83.AncestryChanged:Once(function()
				-- upvalues: (copy) v_u_93, (copy) p_u_82, (ref) v_u_2, (copy) v_u_94, (copy) v_u_108, (ref) v_u_9
				for _, v109 in v_u_93 do
					v109[#v109]:ClearAllChildren()
				end
				task.wait(p_u_82 and 5 or 30)
				for _, v_u_110 in v_u_93 do
					task.spawn(function()
						-- upvalues: (copy) v_u_110, (ref) v_u_2
						for v111, v112 in v_u_110 do
							v112.Transparency = 1
							v112.CanCollide = false
							v_u_2:AddItem(v112, 2)
							if v111 % 9 ~= 0 then
								continue
							end
							task.wait(0.025)
						end
					end)
				end
				for _, v_u_113 in v_u_94 do
					task.spawn(function()
						-- upvalues: (copy) v_u_113, (ref) v_u_108, (ref) v_u_9, (ref) v_u_2
						for _, v114 in v_u_113 do
							local v115 = Instance.new("Part", workspace.Effects)
							v115.Transparency = 1
							v115.CanCollide = false
							v115.Anchored = true
							v115.CastShadow = false
							v115.CFrame = v114.CFrame
							v115.Size = v114.Size * Vector3.new(0.7, 0.7, 1)
							for _, v116 in v_u_108:GetChildren() do
								local v117 = v116:Clone()
								v117.Shape = Enum.ParticleEmitterShape.Box
								v117.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v115.Size.X * 2, 0), NumberSequenceKeypoint.new(1, v115.Size.X * 2, 0) })
								v117.Parent = v115
							end
							v_u_9:PlayParticles(v115)
							v_u_2:AddItem(v115, 2)
							task.wait(0.05)
						end
					end)
				end
			end)
		end,
		["ReplicateRoots"] = function(p118, p119, p120)
			-- upvalues: (ref) v_u_46, (ref) v_u_5, (ref) v_u_9, (ref) v_u_2
			local v_u_121 = {}
			for v122, v123 in p118 do
				v_u_121[v122] = {}
				for _, v124 in v123 do
					for _, v125 in v_u_46({
						["CFrame"] = v124,
						["Size"] = p120
					}, 0, true) do
						local v126 = v_u_121[v122]
						table.insert(v126, v125)
					end
				end
			end
			local v_u_127 = v_u_5.Utils.Hanami.ParticleDissipationHolder
			local v_u_128 = false
			local function v134() -- name: clearParts
				-- upvalues: (ref) v_u_128, (copy) v_u_121, (copy) v_u_127, (ref) v_u_9, (ref) v_u_2
				if not v_u_128 then
					v_u_128 = true
					for _, v_u_129 in v_u_121 do
						task.spawn(function()
							-- upvalues: (copy) v_u_129, (ref) v_u_127, (ref) v_u_9, (ref) v_u_2
							for v130, v131 in v_u_129 do
								for _, v132 in v_u_127:GetChildren() do
									local v133 = v132:Clone()
									v133.Shape = Enum.ParticleEmitterShape.Box
									v133.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v131.Size.X * 2, 0), NumberSequenceKeypoint.new(1, v131.Size.X * 2, 0) })
									v133.Parent = v131
								end
								v_u_9:PlayParticles(v131)
								v131.Transparency = 1
								v131.CanCollide = false
								v_u_2:AddItem(v131, 2)
								if v130 % 9 ~= 0 then
									break
								end
								task.wait(0.025)
							end
						end)
					end
				end
			end
			task.delay(typeof(p119) == "number" and p119 and p119 or 30, v134)
		end,
		["StartSurf"] = function(p135, p_u_136, p_u_137, p_u_138)
			-- upvalues: (ref) v_u_4, (ref) v_u_6, (ref) v_u_11, (ref) v_u_3, (ref) v_u_2, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (ref) v_u_75
			if p_u_137 == v_u_4.Character then
				local v_u_139 = p_u_137:FindFirstChild("HumanoidRootPart")
				task.spawn(function()
					-- upvalues: (ref) v_u_6, (copy) p_u_138, (copy) v_u_139, (ref) v_u_11, (copy) p_u_136, (ref) v_u_3, (ref) v_u_2
					local v140 = v_u_6.Megumi.HitArea:Clone()
					v140.Size = Vector3.new(40, 0, 40)
					v140.Parent = workspace.Effects
					while p_u_138.Parent do
						v_u_139.CFrame = CFrame.lookAlong(v_u_139.Position, v_u_11.CFrame.LookVector)
						local v141 = workspace:Raycast(v_u_139.Position, Vector3.new(0, -70, 0), _G.MapParams)
						if v141 then
							v140.Position = v141.Position + Vector3.new(0, 0.1, 0)
							local v142 = v141.Distance
							local v143 = p_u_136
							local v144 = math.rad(v143)
							local v145 = v142 * math.tan(v144) * 2
							v140.Size = Vector3.new(v145, 0, v145)
							if not v140.Parent then
								v140.Parent = workspace.Effects
							end
						else
							v140.Parent = nil
						end
						task.wait()
					end
					for _, v146 in v140:GetChildren() do
						v_u_3:Create(v146, TweenInfo.new(0.5), {
							["Transparency"] = 1
						}):Play()
					end
					v_u_2:AddItem(v140, 0.5)
				end)
			end
			local v_u_147 = {}
			local v_u_148 = v_u_5.Utils.Hanami.ParticleDissipationHolder
			local v_u_149 = nil
			local function v_u_153(p150) -- name: clearPart
				-- upvalues: (copy) v_u_148, (ref) v_u_9, (ref) v_u_2
				for _, v151 in v_u_148:GetChildren() do
					local v152 = v151:Clone()
					v152.Shape = Enum.ParticleEmitterShape.Box
					v152.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p150.Size.X * 2, 0), NumberSequenceKeypoint.new(1, p150.Size.X * 2, 0) })
					v152.Parent = p150
				end
				v_u_9:PlayParticles(p150)
				p150.Transparency = 1
				p150.CanCollide = false
				v_u_2:AddItem(p150, 2)
			end
			local v_u_154 = Instance.new("Folder", workspace.Effects)
			local function v_u_156() -- name: startClearing
				-- upvalues: (ref) v_u_149, (copy) v_u_147, (copy) v_u_153, (copy) v_u_154
				if not v_u_149 then
					v_u_149 = true
					for _, v155 in v_u_147 do
						v155.Parent = workspace.Effects
						v_u_153(v155)
					end
					v_u_154:Destroy()
				end
			end
			local v_u_157 = nil
			local v_u_158 = {}
			local v_u_159 = nil
			p135.OnClientEvent:Connect(function(p160, ...)
				-- upvalues: (ref) v_u_149, (ref) v_u_159, (ref) v_u_9, (ref) v_u_7, (copy) p_u_137, (ref) v_u_75, (copy) v_u_154, (copy) v_u_147, (copy) v_u_156, (ref) v_u_3, (ref) v_u_6, (copy) v_u_158, (ref) v_u_2, (ref) v_u_157, (copy) v_u_148
				if p160 == "Surf" then
					if not v_u_149 then
						local v161 = {
							["CFrame"] = nil,
							["Size"] = Vector3.new(6, 6, 20),
							["CFrame"] = ({ ... })[1]
						}
						if not v_u_159 then
							v_u_9:PlaySound(v_u_7.Hanami.RootRampage.RootAppear, p_u_137.HumanoidRootPart, game.SoundService.Effect)
							v_u_159 = v_u_9:PlaySound(v_u_7.Hanami.RootRampage.RootLoop, p_u_137.HumanoidRootPart, game.SoundService.Effect)
						end
						for _, v162 in v_u_75(v161, v_u_154) do
							local v163 = v_u_147
							table.insert(v163, v162)
						end
					end
				else
					if p160 == "WoodenBall" then
						v_u_156()
						v_u_149 = true
						local v164 = ({ ... })[1]
						local v165 = ({ ... })[2]
						v_u_3:Create(v_u_159, TweenInfo.new(1), {
							["Volume"] = 0
						}):Play()
						task.delay(1, function()
							-- upvalues: (ref) v_u_159
							v_u_159:Destroy()
						end)
						v_u_9:PlaySound(v_u_7.Hanami.AOESpikes.WoodBallsAppear, v164, game.SoundService.Effect)
						for _, v166 in v165 do
							local v167 = v166:FindFirstChild("HumanoidRootPart")
							if not v167 then
								continue
							end
							local v_u_168 = v_u_6.Megumi.HitArea:Clone()
							v_u_168.Size = Vector3.new(8, 0, 8)
							v_u_158[v167] = v_u_168
							task.delay(0.5, function()
								-- upvalues: (copy) v_u_168, (ref) v_u_3
								for _, v169 in v_u_168:GetChildren() do
									v_u_3:Create(v169, TweenInfo.new(0.3), {
										["Transparency"] = 1
									}):Play()
								end
							end)
							v_u_2:AddItem(v_u_168, 0.8)
						end
						v_u_157 = true
						while v_u_157 do
							for v170, v171 in v_u_158 do
								if not v170.Parent then
									continue
								end
								local v172 = workspace:Raycast(v170.Position, Vector3.new(-0, -5, -0), _G.MapParams)
								if v172 then
									v171.Position = v172.Position + Vector3.new(0, 0.1, 0)
									v171.Parent = workspace.Effects
								else
									v171.Parent = nil
								end
							end
							task.wait()
						end
					elseif p160 == "Spikes" then
						local v_u_173 = ({ ... })[1]
						local v174 = ({ ... })[2]
						v_u_157 = false
						if v_u_173 then
							v_u_3:Create(v_u_173, TweenInfo.new(0.2), {
								["Size"] = Vector3.new(9, 9, 9),
								["Position"] = nil,
								["Position"] = v_u_173.Position - Vector3.new(0, 3.5, 0)
							}):Play()
							local function v197(p175, p176, p177) -- name: createSpike
								-- upvalues: (copy) v_u_173, (ref) v_u_9, (ref) v_u_7
								local v178 = p176 / 5
								local v179 = math.floor(v178)
								local v180 = Random.new()
								local v181 = v_u_173.Position
								local v182 = v_u_173.Position + p175 * p176
								local v183 = p177 / v179
								v_u_9:PlaySound(v_u_7.Hanami.AOESpikes[("Spear%*"):format((v180:NextInteger(1, 2)))], v_u_173, game.SoundService.Effect)
								local v184 = v_u_173.Position
								local v185 = {}
								for v186 = 1, v179 do
									local v187 = v186 / v179
									local v188 = v187 * -1.4 + 2
									local v189
									if v186 > 1 and v186 < v179 then
										local v190 = v180:NextNumber(-0.3, 0.3)
										local v191 = v180:NextNumber(-0.3, 0.3)
										v189 = vector.create(v190, v191, v180:NextNumber(-0.2, 0.2))
									else
										v189 = Vector3.new(0, 0, 0)
									end
									local v192 = v181 + (v182 - v181) * v187 + v189
									if v186 == v179 then
										v192 = v182
									end
									local v193 = (v192 - v184).Magnitude
									local v194 = Instance.new("Part")
									v194.Transparency = 1
									v194.Name = ("Segment"):format(v186)
									v194.CanCollide = false
									v194.Anchored = false
									v194.Material = Enum.Material.Wood
									v194.Color = Color3.fromRGB(67, 47, 35)
									v194.Size = vector.create(v188, v188, v193)
									v194.CFrame = CFrame.lookAt((v184 + v192) / 2, v184)
									local v195 = Instance.new("Weld")
									v195.C0 = v194.CFrame:ToObjectSpace(v_u_173.CFrame)
									v195.Part0 = v194
									v195.Part1 = v_u_173
									v195.Parent = v194
									v194.Parent = v_u_173
									table.insert(v185, v194)
									v184 = v192
								end
								for _, v196 in v185 do
									v196.Transparency = 0
									task.wait(v183)
								end
							end
							for _, v198 in v174 do
								local v199 = v198[1]
								local v200 = v198[2]
								local v201 = v199:FindFirstChild("HumanoidRootPart")
								if not v201 then
									continue
								end
								local v202 = v_u_158[v201]
								local v203 = workspace:Raycast(v200, Vector3.new(-0, -5, -0), _G.MapParams)
								if v203 then
									v202.Position = v203.Position + Vector3.new(0, 0.1, 0)
									v202.Parent = workspace.Effects
								else
									v202:Destroy()
								end
							end
							task.wait(0.2)
							for _, v204 in v174 do
								local v205 = math.random(1, 5) / 100
								task.delay(v205, v197, v204[3], v204[4], 0.15 - v205)
							end
							return
						end
					elseif p160 == "DestroyWoodenBall" then
						local v206 = ({ ... })[1]
						local function v210(p207) -- name: prepareClearing
							-- upvalues: (ref) v_u_148
							p207.Transparency = 1
							for _, v208 in v_u_148:GetChildren() do
								local v209 = v208:Clone()
								v209.Shape = Enum.ParticleEmitterShape.Box
								v209.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p207.Size.X * 2, 0), NumberSequenceKeypoint.new(1, p207.Size.X * 2, 0) })
								v209.Parent = p207
							end
						end
						v210(v206)
						for _, v211 in v206:QueryDescendants("BasePart") do
							v210(v211)
						end
						v_u_9:PlayParticles(v206)
					end
					return
				end
			end)
			p135.AncestryChanged:Once(v_u_156)
		end
	}
	v_u_8.Effects:Connect(function(p213, ...)
		-- upvalues: (copy) v_u_212
		local v214 = v_u_212[p213]
		if v214 then
			v214(...)
		end
	end)
end
function v10.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_8, (copy) v_u_1, (ref) v_u_9
	v_u_8 = v_u_1.GetService("RootRampageService")
	v_u_9 = v_u_1.GetController("FXController")
end
return v10