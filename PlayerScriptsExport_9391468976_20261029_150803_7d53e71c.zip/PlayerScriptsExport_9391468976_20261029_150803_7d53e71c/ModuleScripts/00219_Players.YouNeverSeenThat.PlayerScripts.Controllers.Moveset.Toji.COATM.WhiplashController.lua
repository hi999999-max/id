-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Toji.COATM.WhiplashController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
require(v_u_5.Modules.StaticLightning)
require(v_u_5.Modules.LightningBeams)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "WhiplashController"
})
function v11.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_10, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_5, (copy) v_u_4, (copy) v_u_8, (copy) v_u_3, (ref) v_u_9
	local v_u_64 = {
		["Start"] = function(p12, p13)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2
			local v14 = p12:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_10:PlaySound(v_u_7.Toji.COATM.Whiplash.Start, v14, game.SoundService.Effect)
				task.wait(0.2)
				local v15 = p12.SetAssets:FindFirstChild("COATM")
				for v16 = 3, 6 do
					local v17 = v15:FindFirstChild("Beam" .. v16)
					if not v17 then
						continue
					end
					local v_u_18 = v_u_6.Toji.COATMCombatTrail:Clone()
					v_u_18.Parent = v15
					v_u_18.Attachment0 = v17.Attachment0
					v_u_18.Attachment1 = v17.Attachment1
					v_u_18.Enabled = true
					task.delay(0.25, function()
						-- upvalues: (copy) v_u_18, (ref) v_u_2
						v_u_18.Enabled = false
						v_u_2:AddItem(v_u_18, 0.2)
					end)
					p13.Destroying:Connect(function()
						-- upvalues: (copy) v_u_18, (ref) v_u_2
						v_u_18.Enabled = false
						v_u_2:AddItem(v_u_18, 0.2)
					end)
				end
			end
		end,
		["Spin"] = function(p19, p20)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2
			local v21 = p19:FindFirstChild("HumanoidRootPart")
			if v21 then
				local v_u_22 = v_u_10:PlaySound(v_u_7.Toji.COATM.Whiplash.Spin, v21, game.SoundService.Effect)
				p20.Destroying:Connect(function()
					-- upvalues: (copy) v_u_22
					v_u_22:Destroy()
				end)
				local v23 = p19.SetAssets:FindFirstChild("COATM")
				for v24 = 5, 6 do
					local v25 = v23:FindFirstChild("Beam" .. v24)
					if not v25 then
						continue
					end
					local v_u_26 = v_u_6.Toji.COATMCombatTrail:Clone()
					v_u_26.Parent = v23
					v_u_26.Attachment0 = v25.Attachment0
					v_u_26.Attachment1 = v25.Attachment1
					v_u_26.Enabled = true
					task.delay(1.25, function()
						-- upvalues: (copy) v_u_26, (ref) v_u_2
						v_u_26.Enabled = false
						v_u_2:AddItem(v_u_26, 0.2)
					end)
					p20.Destroying:Connect(function()
						-- upvalues: (copy) v_u_26, (ref) v_u_2
						v_u_26.Enabled = false
						v_u_2:AddItem(v_u_26, 0.2)
					end)
				end
			end
		end,
		["Whoosh"] = function(p27, p28)
			-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_2, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v29 = p27:FindFirstChild("HumanoidRootPart")
			if v29 then
				local v30 = p28 * CFrame.new(0, 1, 0)
				local v31 = workspace:Raycast((v30 * CFrame.new(0, 0, -27)).Position, Vector3.new(0, -8, 0), _G.MapParams)
				if not v31 then
					for v32 = 27, 0, -1 do
						v31 = workspace:Raycast((v30 * CFrame.new(0, 0, -v32)).Position, Vector3.new(0, -8, 0), _G.MapParams)
						if not v31 then
							continue
						end
					end
				end
				if v31 then
					local v33 = v30 or v29.CFrame
					local v34 = v31.Position
					local v35 = v_u_5.Utils.MeiMei.Slam:Clone()
					v35.CFrame = CFrame.lookAt(v34, v34 + v33.lookVector)
					v_u_10:PlayParticles(v35)
					v35.Parent = workspace.Effects
					v_u_2:AddItem(v35, 1)
					v_u_10:PlaySound(v_u_7.MeiMei.Gliding.Impact, v35, game.SoundService.Effect)
					if v_u_4.Character == p27 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
					end
				end
			else
				return
			end
		end,
		["Hit"] = function(p36, p37)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			if p36:FindFirstChild("HumanoidRootPart") then
				local v38 = p37:FindFirstChild("HumanoidRootPart")
				if v38 then
					local v39 = v_u_6.Toji.ChainHit:Clone()
					v39.Position = v38.Position
					v39.Parent = workspace.Effects
					v_u_2:AddItem(v39, 0.5)
					for _, v40 in v39:GetChildren() do
						v40:Emit(v40:GetAttribute("EmitCount"))
					end
					v_u_10:Flash(p37, Color3.new(1, 1, 1))
					v_u_10:PlaySound(v_u_7.Toji.COATM.Whiplash.Hit, v38, game.SoundService.Effect).PlaybackSpeed = math.random(90, 110) / 100
					if v_u_4.Character == p36 or v_u_4.Character == p37 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["Hit2"] = function(p41, p42)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			if p41:FindFirstChild("HumanoidRootPart") then
				local v43 = p42:FindFirstChild("HumanoidRootPart")
				if v43 then
					v_u_10:Flash(p42, Color3.new(1, 1, 1))
					v_u_10:PlaySound(v_u_7.Nanami.SeveranceKick.HitBack, v43, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Dash"] = function(p44, p_u_45)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v_u_46 = p44.HumanoidRootPart
			if v_u_46 then
				local v47 = p44:FindFirstChild("Humanoid")
				if v47 then
					local v48 = p44.SetAssets:FindFirstChild("COATM")
					local v_u_49 = {}
					for v50 = 5, 6 do
						local v51 = v48:FindFirstChild("Beam" .. v50)
						if not v51 then
							continue
						end
						local v_u_52 = v_u_6.Toji.COATMCombatTrail:Clone()
						v_u_52.Parent = v48
						v_u_52.Attachment0 = v51.Attachment0
						v_u_52.Attachment1 = v51.Attachment1
						v_u_52.Enabled = true
						task.delay(1.25, function()
							-- upvalues: (copy) v_u_52, (ref) v_u_2
							v_u_52.Enabled = false
							v_u_2:AddItem(v_u_52, 0.2)
						end)
						table.insert(v_u_49, v_u_52)
					end
					v_u_10:PlaySound(v_u_7.Reggie.Fleche.Dash, v_u_46, game.SoundService.Effect)
					local v53 = v_u_6.Itadori.Shock:Clone()
					v53.CFrame = v_u_46.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
					v53.Parent = workspace.Effects
					v_u_3:Create(v53, TweenInfo.new(0.3), {
						["Size"] = Vector3.new(10, 0, 10),
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v53, 0.3)
					task.delay(0.075, function()
						-- upvalues: (ref) v_u_6, (copy) v_u_46, (ref) v_u_3, (ref) v_u_2
						local v54 = v_u_6.Itadori.Shock:Clone()
						v54.CFrame = v_u_46.CFrame * CFrame.Angles(1.5707963267948966, 0, 0) + v_u_46.CFrame.LookVector * 3
						v54.Parent = workspace.Effects
						v_u_3:Create(v54, TweenInfo.new(0.2), {
							["Size"] = Vector3.new(8, 0, 8),
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v54, 0.2)
						task.wait(0.075)
						local v55 = v_u_6.Itadori.Shock:Clone()
						v55.CFrame = v_u_46.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
						v55.Parent = workspace.Effects
						v_u_3:Create(v55, TweenInfo.new(0.2), {
							["Size"] = Vector3.new(8, 0, 8),
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v55, 0.2)
					end)
					task.spawn(function()
						-- upvalues: (copy) p_u_45, (copy) v_u_49, (ref) v_u_2
						repeat
							task.wait()
						until not p_u_45.Parent
						for _, v56 in v_u_49 do
							v56.Enabled = false
							v_u_2:AddItem(v56, 0.2)
						end
					end)
					if v_u_4.Character == p44 then
						local v57 = Instance.new("BodyGyro", v_u_46)
						v57.P = 10000
						v57.MaxTorque = Vector3.new(40000, 40000, 40000)
						p_u_45.Position = v_u_46.Position + Vector3.new(0, 12, 0)
						local v58 = tick()
						v47.PlatformStand = true
						local v59 = workspace.CurrentCamera.CFrame.LookVector
						if tick() - v58 < 0.7 then
							local v60 = workspace:Raycast(v_u_46.Position, Vector3.new(0, -4.5, 0), _G.MapParams)
							if v59.Y < -0.3 and v60 then
								local v61 = v59.X
								local v62 = v59.Z
								v59 = Vector3.new(v61, 0, v62)
							end
							local v63 = workspace:Raycast(v_u_46.Position, v59 * 10, _G.MapParams)
							if v63 then
								p_u_45.Position = v63.Position - v59 * 4
							else
								p_u_45.Position = v_u_46.Position + v59 * 30
							end
						end
						v57.CFrame = CFrame.new(v_u_46.Position, v_u_46.Position + v59)
						task.wait()
						if p_u_45.Parent then
							continue
						end
						v47.PlatformStand = false
						v57:Destroy()
					end
				end
			else
				return
			end
		end
	}
	v_u_9.Effects:Connect(function(p65, ...)
		-- upvalues: (copy) v_u_64
		local v66 = v_u_64[p65]
		if v66 then
			v66(...)
		end
	end)
end
function v11.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("WhiplashService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11