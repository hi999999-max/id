-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Nanami.Awake.InterrogateController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = require(v_u_5.Modules.BloodyZee)
local v10 = require(v_u_5.Modules.SraikoVFX)
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "InterrogateController"
})
local _ = v10.Emit
local _ = v10.Enabled
local _ = v10.EmitMesh
function v14.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_7, (copy) v_u_5, (copy) v_u_2, (copy) v_u_6, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (copy) v_u_9, (ref) v_u_11
	local v_u_65 = {
		["Start"] = function(p15)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_12:PlaySound(v_u_7.Todo.BruteForce.Start, v16, game.SoundService.Effect)
				v_u_12:ArmFlash(p15["Left Arm"], Color3.fromRGB(129, 168, 203), 0.7)
			end
		end,
		["Swing"] = function(p17)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v18 = p17:FindFirstChild("HumanoidRootPart")
			if v18 then
				v_u_12:PlaySound(v_u_7.Misc.Swing.Fist, v18, game.SoundService.Effect)
			end
		end,
		["Dash"] = function(p19)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_6, (ref) v_u_3
			local v_u_20 = p19:FindFirstChild("HumanoidRootPart")
			if v_u_20 then
				local v21 = Instance.new("Model")
				local v22 = v_u_5.Utils.Itadori.RushWind:Clone()
				v22.CFrame = v_u_20.CFrame * CFrame.new(0, -1, 0)
				v22.Parent = v21
				v21.Parent = workspace.Effects
				v21:ScaleTo(0.6)
				v22.Ring:Emit(7)
				v22.Dash1.Dash:Emit(1)
				v22.Dash2.Dash:Emit(1)
				v_u_2:AddItem(v21, 2)
				local v23 = v_u_6.Itadori.Shock:Clone()
				v23.CFrame = v_u_20.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v23.Parent = workspace.Effects
				v_u_3:Create(v23, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(8, 0, 8),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v23, 0.2)
				task.delay(0.1, function()
					-- upvalues: (ref) v_u_6, (copy) v_u_20, (ref) v_u_3, (ref) v_u_2
					local v24 = v_u_6.Itadori.Shock:Clone()
					v24.CFrame = (v_u_20.CFrame - v_u_20.CFrame.Position + v_u_20.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
					v24.Parent = workspace.Effects
					v_u_3:Create(v24, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v24, 0.2)
				end)
			end
		end,
		["TrueRagdoll"] = function(p25)
			-- upvalues: (ref) v_u_12
			if p25:FindFirstChild("HumanoidRootPart") then
				v_u_12:Flash(p25, Color3.new(0, 0.682353, 1), 3)
			end
		end,
		["FinalSwing"] = function(p26, p27, p28)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_7, (ref) v_u_8
			local v29 = p26:FindFirstChild("HumanoidRootPart")
			if v29 then
				local v30 = v_u_6.Itadori.DivergentFist.BlackFlashLaunch:Clone()
				v30.CFrame = v29.CFrame * CFrame.new(2, 1, -5)
				v30.Parent = workspace.Effects
				v30.Wind:Emit(20)
				v30.PointLight:Destroy()
				v30.Back1.Back:Emit(1)
				v30.Back2.Back:Emit(1)
				v_u_2:AddItem(v30, 3)
				if p28 then
					if v_u_4.Character == p26 or v_u_4.Character == p27 then
						local v_u_31 = Instance.new("ColorCorrectionEffect", game.Lighting)
						v_u_31.Saturation = -1
						v_u_31.Contrast = 10
						v_u_2:AddItem(v_u_31, 1.5)
						v_u_3:Create(workspace.CurrentCamera, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
							["FieldOfView"] = 35
						}):Play()
						v_u_3:Create(v_u_31, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
							["Saturation"] = -0.5,
							["Contrast"] = 0
						}):Play()
						task.delay(1, function()
							-- upvalues: (ref) v_u_3, (copy) v_u_31
							v_u_3:Create(workspace.CurrentCamera, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
								["FieldOfView"] = 70
							}):Play()
							v_u_3:Create(v_u_31, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
								["Saturation"] = 0
							}):Play()
						end)
					end
					for _, v32 in v30:GetDescendants() do
						if not v32:IsA("ParticleEmitter") then
							continue
						end
						v32.TimeScale = 0
					end
					task.wait(1)
					for _, v33 in v30:GetDescendants() do
						if not v33:IsA("ParticleEmitter") then
							continue
						end
						v33.TimeScale = 1
					end
				end
				v_u_3:Create(v30.Back1, TweenInfo.new(2), {
					["CFrame"] = v30.Back1.CFrame - v30.Back1.CFrame.LookVector * 20
				}):Play()
				v_u_3:Create(v30.Back2, TweenInfo.new(2), {
					["CFrame"] = v30.Back2.CFrame - v30.Back2.CFrame.LookVector * 20
				}):Play()
				local v34 = v_u_6.Choso.CounterSwing.Shock:Clone()
				v34.Size = Vector3.new(6, 30, 6)
				v34.CFrame = v29.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v34.Parent = workspace.Effects
				v_u_2:AddItem(v34, 0.2)
				v_u_3:Create(v34, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(25, 0, 25),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v34.Position + v29.CFrame.LookVector * 10
				}):Play()
				v_u_12:PlaySound(v_u_7.Mahito.Stockpile.Swing2, v29, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_7.Todo.BruteForce.Swing, v29, game.SoundService.Effect)
				if v_u_4.Character == p26 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Ohno"] = function(p35, p36)
			-- upvalues: (ref) v_u_4, (ref) v_u_3, (ref) v_u_6, (ref) v_u_2
			local v37 = p35:FindFirstChild("HumanoidRootPart")
			if v37 then
				if v_u_4.Character == p35 or v_u_4.Character == p36 then
					v_u_3:Create(workspace.CurrentCamera, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["FieldOfView"] = 50
					}):Play()
					task.delay(1.5, function()
						-- upvalues: (ref) v_u_3
						v_u_3:Create(workspace.CurrentCamera, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.InOut), {
							["FieldOfView"] = 70
						}):Play()
					end)
				end
				local v38 = v_u_6.Mechamaru.Dust:Clone()
				v38.bigimpact:Destroy()
				v38.Smoke2:Destroy()
				v38.Position = v37.Position - Vector3.new(0, 3, 0)
				v38.Parent = workspace.Effects
				v_u_2:AddItem(v38, 2.5)
				for _, v39 in v38:GetChildren() do
					v39:Emit(v39:GetAttribute("EmitCount"))
					v_u_3:Create(v39, TweenInfo.new(0.4), {
						["TimeScale"] = 0.1
					}):Play()
				end
				task.wait(1.5)
				for _, v40 in v38:GetChildren() do
					v40:Emit(v40:GetAttribute("EmitCount"))
					v40.TimeScale = 1
				end
			end
		end,
		["Hit"] = function(p41)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_9, (ref) v_u_8
			local v42 = p41:FindFirstChild("HumanoidRootPart")
			if v42 then
				local v43 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v43.Position = v42.Position
				v43.Parent = workspace.Effects
				v_u_2:AddItem(v43, 1)
				v43.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 1))
				v43.Wind.Color = v43.Sparks.Color
				v43.Wind2.Color = v43.Sparks.Color
				v43.Sparks:Emit(50)
				v43.Wind:Emit(7)
				v43.Wind2:Emit(7)
				v_u_12:Flash(p41, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_7.Itadori.CraniumSmash.Hit2, v42, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_7.Todo.BruteForce.Hit, v42, game.SoundService.Effect)
				local v44 = v_u_6.Mechamaru.Dust:Clone()
				v44.bigimpact:Destroy()
				v44.Smoke2:Destroy()
				v44.Position = v42.Position - Vector3.new(0, 3, 0)
				v44.Parent = workspace.Effects
				v_u_2:AddItem(v44, 2)
				for _, v45 in v44:GetChildren() do
					v45:Emit(v45:GetAttribute("EmitCount"))
				end
				for _ = 1, 20 do
					v_u_9:Blood(p41.Head.CFrame, math.random(5, 80), 25, 25)
				end
				if (workspace.CurrentCamera.CFrame.Position - v42.Position).Magnitude < 80 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Grab"] = function(p46, p47)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_8
			local v48 = p46:FindFirstChild("HumanoidRootPart")
			if v48 then
				v_u_12:Flash(p46, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_7.Gojo.LapseBlue.Grab, v48, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_7.Nanami.Interrogate["Grab" .. p47], v48, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v48.Position).Magnitude < 80 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Chat"] = function(p49, p50, p51)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			if p49.Head:FindFirstChild("HiromiText") then
				p49.Head.HiromiText:Destroy()
			end
			v_u_12:PlaySound(v_u_7.Hiromi.DeadlySentence.Talk, p49.Head, game.SoundService.Voice).PlaybackSpeed = p51
			local v_u_52 = v_u_6.Hiromi.DeadlySentencing.HiromiText:Clone()
			v_u_52.TextLabel.Text = p50
			v_u_52.Parent = p49.Head
			v_u_2:AddItem(v_u_52, 1.5)
			task.delay(1, function()
				-- upvalues: (copy) v_u_52, (ref) v_u_3
				if v_u_52.Parent then
					v_u_3:Create(v_u_52.TextLabel, TweenInfo.new(0.5), {
						["BackgroundTransparency"] = 1,
						["TextTransparency"] = 1
					}):Play()
					v_u_3:Create(v_u_52.TextLabel.UIStroke, TweenInfo.new(0.5), {
						["Transparency"] = 1
					}):Play()
				end
			end)
		end,
		["FinalHit"] = function(p_u_53, p54)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_9, (ref) v_u_8
			local v55 = p_u_53:FindFirstChild("HumanoidRootPart")
			if v55 then
				local v56 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v56.Position = v55.Position
				v56.Parent = workspace.Effects
				v_u_2:AddItem(v56, 1)
				v56.Sparks.Color = ColorSequence.new(Color3.fromRGB(85, 170, 255))
				v56.Wind.Color = v56.Sparks.Color
				v56.Wind2.Color = v56.Sparks.Color
				v56.Sparks:Emit(50)
				v56.Wind:Emit(7)
				v56.Wind2:Emit(7)
				v_u_12:Flash(p_u_53, Color3.new(1, 1, 1))
				local v_u_57 = v_u_6.Mechamaru.Dust:Clone()
				v_u_57.bigimpact:Destroy()
				v_u_57.Smoke2:Destroy()
				v_u_57.Position = v55.Position - Vector3.new(0, 3, 0)
				v_u_57.Parent = workspace.Effects
				v_u_2:AddItem(v_u_57, 2.5)
				for _, v58 in v_u_57:GetChildren() do
					v58:Emit(v58:GetAttribute("EmitCount"))
				end
				if p54 then
					v_u_12:PlaySound(v_u_7.Nanami.Interrogate.FinisherHit, v55, game.SoundService.Effect)
					v_u_12:PlaySound(v_u_7.Nanami.Interrogate.Freeze, v55, game.SoundService.Effect)
					if _G.Settings.Gore == true then
						local v_u_59 = v_u_6.Naoya.BleedFreeze.Attachment:Clone()
						v_u_59.Parent = p_u_53.Head
						v_u_59.Blood:Emit(100)
						task.delay(0.05, function()
							-- upvalues: (copy) v_u_59, (ref) v_u_9, (copy) p_u_53
							v_u_59.Blood.TimeScale = 0
							task.wait(0.95)
							v_u_59.Blood.TimeScale = 1
							for _ = 1, 20 do
								v_u_9:Blood(p_u_53.Head.CFrame, math.random(5, 80), 25, 25)
							end
						end)
					end
					for _, v60 in v_u_57:GetChildren() do
						v60.TimeScale = 0
					end
					task.delay(1, function()
						-- upvalues: (copy) v_u_57
						for _, v61 in v_u_57:GetChildren() do
							v61.TimeScale = 1
						end
					end)
				else
					v_u_12:PlaySound(v_u_7.Nanami.Interrogate.Hit, v55, game.SoundService.Effect)
					for _ = 1, 20 do
						v_u_9:Blood(p_u_53.Head.CFrame, math.random(5, 80), 25, 25)
					end
				end
				if (workspace.CurrentCamera.CFrame.Position - v55.Position).Magnitude < 80 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.SnapOh)
				end
			end
		end,
		["FinalHit2"] = function(p62)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_8
			local v63 = p62:FindFirstChild("HumanoidRootPart")
			if v63 then
				local v64 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v64.Position = v63.Position
				v64.Parent = workspace.Effects
				v_u_2:AddItem(v64, 1)
				v64.Sparks.Color = ColorSequence.new(Color3.fromRGB(85, 170, 255))
				v64.Wind.Color = v64.Sparks.Color
				v64.Wind2.Color = v64.Sparks.Color
				v64.Sparks:Emit(50)
				v64.Wind:Emit(7)
				v64.Wind2:Emit(7)
				v_u_12:Flash(p62, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_7.Itadori.CraniumSmash.Hit2, v63, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_7.Todo.BruteForce.Hit, v63, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v63.Position).Magnitude < 80 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end
	}
	v_u_11.Effects:Connect(function(p66, ...)
		-- upvalues: (copy) v_u_65
		local v67 = v_u_65[p66]
		if v67 then
			v67(...)
		end
	end)
end
function v14.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13
	v_u_11 = v_u_1.GetService("InterrogateService")
	v_u_12 = v_u_1.GetController("FXController")
	v_u_13 = v_u_1.GetController("ToolController")
end
return v14