-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Yuta.Base.EnergyRippleController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "EnergyRippleController"
})
local v_u_13 = {
	10,
	5,
	55,
	50
}
local v_u_14 = {
	"rbxassetid://14881939208",
	"rbxassetid://14881938857",
	"rbxassetid://14881938578",
	"rbxassetid://14881938271",
	"rbxassetid://14881937942",
	"rbxassetid://14881937668",
	"rbxassetid://14881937499",
	"rbxassetid://14881937341",
	"rbxassetid://14881937187",
	"rbxassetid://14881937032",
	"rbxassetid://14881936897",
	"rbxassetid://14881936734",
	"rbxassetid://14881936492"
}
function v12.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_10, (copy) v_u_8, (copy) v_u_7, (copy) v_u_13, (copy) v_u_3, (copy) v_u_9, (copy) v_u_14, (copy) v_u_4, (copy) v_u_2, (copy) v_u_5, (ref) v_u_11
	local v_u_103 = {
		["Hit"] = function(p15, p16, p17)
			-- upvalues: (ref) v_u_10, (ref) v_u_8, (ref) v_u_7, (ref) v_u_13, (ref) v_u_3
			local v18 = p15:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = p16:FindFirstChild("HumanoidRootPart")
				if v19 then
					v_u_10:Flash(p16, Color3.fromRGB(255, 170, 255))
					local v20 = p17 % 3
					local v21 = v20 == 0 and 3 or v20
					v_u_10:PlaySound(v_u_8.Yuta.M1:FindFirstChild("Hit" .. v21), v19, game.SoundService.Effect)
					local v22 = v_u_7.Yuta.SlashHit:Clone()
					v22.Slash.Color = ColorSequence.new(Color3.fromRGB(255, 85, 255))
					local v23 = CFrame.lookAlong(v19.Position, v18.CFrame.LookVector)
					local v24 = CFrame.Angles
					local v25 = v_u_13[p17] or 0
					v22.CFrame = v23 * v24(0, 0, (math.rad(v25)))
					v22.Parent = workspace.Effects
					v_u_3:AddItem(v22, 0.5)
					v22.Slash:Emit(5)
				end
			else
				return
			end
		end,
		["AirHit"] = function(p26, _)
			-- upvalues: (ref) v_u_10, (ref) v_u_8
			local v27 = p26:FindFirstChild("HumanoidRootPart")
			if v27 then
				v_u_10:Flash(p26, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_8.Yuta.M1.Hit4, v27, game.SoundService.Effect)
			end
		end,
		["StartBomb"] = function(p28, p29)
			-- upvalues: (ref) v_u_10, (ref) v_u_8
			local v30 = p28:FindFirstChild("HumanoidRootPart")
			if v30 then
				local v_u_31 = v_u_10:PlaySound(v_u_8.Yuta.EnergyRipple.Start, v30, game.SoundService.Effect)
				p29.AncestryChanged:Connect(function()
					-- upvalues: (copy) v_u_31
					v_u_31:Destroy()
				end)
				p29:GetAttributeChangedSignal("Feint"):Connect(function()
					-- upvalues: (copy) v_u_31
					v_u_31:Destroy()
				end)
			end
		end,
		["StabFloor"] = function(p32)
			-- upvalues: (ref) v_u_9
			local v33 = p32:FindFirstChild("HumanoidRootPart")
			if v33 then
				local v34 = v33.Position
				if (workspace.CurrentCamera.CFrame.Position - v34).Magnitude < 30 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
				end
			end
		end,
		["Bomb"] = function(p35, p36)
			-- upvalues: (ref) v_u_7, (ref) v_u_10, (ref) v_u_14, (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_9, (ref) v_u_2
			local v_u_37 = v_u_7.Yuta.EnergyRipple:Clone()
			v_u_37.Ground.Lightning.Enabled = false
			v_u_37.Position = p35
			v_u_37.Ground.Position = p35
			local v_u_38 = v_u_10:PreloadMeshFlipbook(v_u_14)
			local v39 = v_u_37.Size.Y / 2
			local v40
			if v39 == p36 then
				v40 = nil
			else
				local v41 = p36 / v39
				v40 = Instance.new("Model")
				v_u_37.Parent = v40
				v40:ScaleTo(v41)
			end
			local v42 = v_u_37.RingBeams:GetChildren()
			for _, v43 in v42 do
				v43.Enabled = false
			end
			local v_u_44 = v_u_37.Size
			local v45 = v_u_37.Transparency
			local v46 = v_u_37.PointLight.Range
			local v47 = v_u_37.PointLight.Brightness
			v_u_37.Size = Vector3.new(5, 5, 5)
			v_u_37.Ground.Size = Vector3.new(10, 5, 10)
			v_u_37.Transparency = 1
			v_u_37.PointLight.Range = 0
			v_u_37.PointLight.Brightness = 0
			v_u_37.Parent = workspace.Effects
			if v40 then
				v40:Destroy()
			end
			v_u_10:PlaySound(v_u_8.Yuta.EnergyRipple.Bomb1, v_u_37, game.SoundService.Effect)
			v_u_3:AddItem(v_u_37, 5)
			v_u_37.Ground.Lightning.Enabled = true
			local v48 = v_u_4
			local v49 = TweenInfo.new(0.19999999999999998, Enum.EasingStyle.Linear)
			local v50 = {}
			local v51 = v_u_44.X / 2.5
			local v52 = v_u_44.Y * 0.66
			local v53 = v_u_44.Z / 2.5
			v50.Size = Vector3.new(v51, v52, v53)
			v48:Create(v_u_37, v49, v50):Play()
			task.delay(0.19999999999999998, function()
				-- upvalues: (ref) v_u_4, (copy) v_u_37, (copy) v_u_44
				local v54 = {
					["Size"] = v_u_44
				}
				v_u_4:Create(v_u_37, TweenInfo.new(0.1), v54):Play()
			end)
			local v55 = v_u_4
			local v56 = v_u_37.Ground
			local v57 = TweenInfo.new(0.3)
			local v58 = {}
			local v59 = v_u_44.X
			local v60 = v_u_44.Y
			v58.Size = Vector3.new(v59, 5, v60)
			v55:Create(v56, v57, v58):Play()
			v_u_4:Create(v_u_37, TweenInfo.new(0.15), {
				["Transparency"] = v45
			}):Play()
			v_u_4:Create(v_u_37.PointLight, TweenInfo.new(0.3), {
				["Brightness"] = v47,
				["Range"] = v46
			}):Play()
			task.wait(0.3)
			v_u_10:PlaySound(v_u_8.Yuta.EnergyRipple.Bomb2, v_u_37, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p35).Magnitude < 50 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
			end
			v_u_37.Transparency = 1
			v_u_37.Ground.Lightning.Enabled = false
			v_u_4:Create(v_u_37.PointLight, TweenInfo.new(0.1), {
				["Brightness"] = 0,
				["Range"] = nil,
				["Range"] = v46 * 2
			}):Play()
			v_u_37.Ground.Attachment.WindCrescent1:Emit(4)
			v_u_37.Ground.Attachment.Wind2:Emit(30)
			local v61 = TweenInfo.new(0.5)
			local v62 = TweenInfo.new(0.35)
			for _, v_u_63 in v42 do
				v_u_63.Enabled = true
				v_u_4:Create(v_u_63, v61, {
					["CurveSize0"] = 0,
					["CurveSize1"] = 0
				}):Play()
				v_u_4:Create(v_u_63, v62, {
					["Width0"] = 0,
					["Width1"] = 0
				}):Play()
				local v64 = v_u_4
				local v65 = v_u_63.Attachment0
				local v66 = {}
				local v67 = v_u_44.Y * 1.2 / 2
				v66.Position = Vector3.new(0, v67, 0)
				v64:Create(v65, v61, v66):Play()
				local v68 = v_u_4
				local v69 = v_u_63.Attachment1
				local v70 = {}
				local v71 = v_u_44.Y * 1.2 / 2
				v70.Position = Vector3.new(0, v71, 0)
				v68:Create(v69, v61, v70):Play()
				task.delay(0.2, function()
					-- upvalues: (copy) v_u_63
					v_u_63.Color = ColorSequence.new(Color3.new())
				end)
			end
			local v_u_72 = v_u_7.Yuta.ExplosionDissolve:Clone()
			local v73 = CFrame.new(p35)
			local v74 = CFrame.Angles
			local v75 = Random.new():NextNumber(-180, 180)
			v_u_72.CFrame = v73 * v74(0, math.rad(v75), 0)
			v_u_72.Parent = workspace.Effects
			v_u_72.Mesh.Scale = v_u_44 / 2
			v_u_72.Attachment.WindRings:Emit(10)
			v_u_10:PlayMeshFlipbook(v_u_72.Mesh, 1, v_u_14, function()
				-- upvalues: (copy) v_u_72, (copy) v_u_38, (ref) v_u_2
				v_u_72.Transparency = 1
				v_u_38:Destroy()
				local v81 = v_u_2.Heartbeat:Connect(function(p76)
					-- upvalues: (ref) v_u_72, (ref) v_u_2
					local v77 = v_u_72
					local v78 = v_u_72.CFrame
					local v79 = CFrame.Angles
					local v80 = p76 * 300
					v77.CFrame = v78 * v79(0, math.rad(v80), 0)
					v_u_2.RenderStepped:Wait()
				end)
				task.wait(2)
				v81:Disconnect()
				v_u_72:Destroy()
			end)
			v_u_4:Create(v_u_72, TweenInfo.new(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
				["CFrame"] = v_u_72.CFrame * CFrame.Angles(0, 3.12413936106985, 0)
			}):Play()
			v_u_4:Create(v_u_72.Mesh, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
				["Scale"] = v_u_72.Mesh.Scale * 1.2
			}):Play()
			v_u_4:Create(v_u_72.PointLight, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
				["Range"] = v_u_72.PointLight.Range * 1.2
			}):Play()
			task.wait(0.5)
			v_u_4:Create(v_u_72.PointLight, TweenInfo.new(1), {
				["Brightness"] = 0
			}):Play()
		end,
		["BombHit"] = function(p82)
			-- upvalues: (ref) v_u_10, (ref) v_u_8
			local v83 = p82:FindFirstChild("HumanoidRootPart")
			if v83 then
				v_u_10:Flash(p82, Color3.fromRGB(255, 170, 255))
				v_u_10:PlaySound(v_u_8.Yuta.M1.Hit4, v83, game.SoundService.Effect)
			end
		end,
		["FeintSwing"] = function(p84)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v85 = p84:FindFirstChild("HumanoidRootPart")
			if v85 then
				local v86 = v_u_7.Yuta.ResoluteSlash.RingSwing.Attachment:Clone()
				v86.Ring.RotSpeed = NumberRange.new(-800, -200)
				v86.Parent = v85
				v86.Ring:Emit(8)
				v_u_3:AddItem(v86, 0.6)
				local v_u_87 = v_u_7.Ryu.Slash:Clone()
				v_u_87:ScaleTo(1.7)
				v_u_87.Weld.Part0 = v85
				v_u_87.Weld.C0 = CFrame.Angles(0.2617993877991494, -0.4363323129985824, 3.490658503988659)
				v_u_87.Part1.Mesh.Scale = Vector3.new(-20, 1, 20)
				v_u_87.Part2.Mesh.Scale = Vector3.new(20.445, 1, 20.445)
				v_u_87.Weld.C1 = CFrame.Angles(0, -1.5707963267948966, 0)
				v_u_87.Parent = workspace.Effects
				v_u_3:AddItem(v_u_87, 0.115)
				task.spawn(function()
					-- upvalues: (ref) v_u_3, (ref) v_u_7, (copy) v_u_87
					local v88 = Instance.new("Part")
					v88.CanCollide = false
					v88.Anchored = true
					v88.Parent = workspace.Effects
					v88.Transparency = 1
					v88.Size = Vector3.new(1, 1, 1)
					v_u_3:AddItem(v88, 2)
					local v89 = v_u_7.Yuta.Outburst.OutburstExplode.Hitbox.Star:Clone()
					v89.Parent = v88
					v89.Lifetime = NumberRange.new(0.2)
					v89.LockedToPart = false
					repeat
						task.wait(0.02)
						v88.CFrame = v_u_87.Weld.Part0.CFrame * v_u_87.Weld.C0 * v_u_87.Weld.C1:Inverse() * CFrame.new(0, 0, 10)
						v89:Emit(1)
					until v_u_87.Parent == nil
				end)
				local v90 = TweenInfo.new(0.115, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
				local v91 = TweenInfo.new(0.115, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				v_u_4:Create(v_u_87.Weld, v90, {
					["C1"] = v_u_87.Weld.C1 * CFrame.Angles(0, -2.181661564992912, 0)
				}):Play()
				for _, v92 in v_u_87:GetDescendants() do
					if v92:IsA("Decal") then
						v92.Color3 = Color3.fromRGB(440, 223, 355)
						v_u_4:Create(v92, v91, {
							["Transparency"] = 1
						}):Play()
					else
						if not v92:IsA("SpecialMesh") then
							continue
						end
						v_u_4:Create(v92, v90, {
							["Scale"] = v92.Scale * 1.2
						}):Play()
					end
				end
			end
		end,
		["FeintHit"] = function(p93, p94)
			-- upvalues: (ref) v_u_10, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9
			if p93:FindFirstChild("HumanoidRootPart") then
				local v95 = p94:FindFirstChild("HumanoidRootPart")
				if v95 then
					v_u_10:PlaySound(v_u_8.Yuta.EnergyRipple.Feint.Hit, v95, game.SoundService.Effect)
					v_u_10:PlaySound(v_u_8.Yuta.EnergyRipple.Feint.CEBurst, v95, game.SoundService.Effect)
					local v96 = v_u_7.Yuta.Outburst.OutburstExplode:Clone()
					v96:ScaleTo(0.65)
					v96.Hitbox.Anchored = false
					v96.Hitbox.Massless = true
					v96.Weld.Part0 = v95
					v_u_3:AddItem(v96, 3)
					local v97 = v96.Hitbox.Attachment.PointLight
					local v98 = v97.Range
					v97.Range = 0
					v96.Parent = workspace.Effects
					v_u_4:Create(v97, TweenInfo.new(0.2), {
						["Range"] = v98
					}):Play()
					for _, v99 in v96:GetDescendants() do
						if not v99:IsA("ParticleEmitter") then
							continue
						end
						if v99:GetAttribute("EmitDelay") == 0.5 then
							v99:SetAttribute("EmitDelay", 0.8)
						end
						if v99.Lifetime.Min > 0.25 then
							v99.Lifetime = NumberRange.new(v99.Lifetime.Min + 0.3, v99.Lifetime.Max + 0.3)
						end
						v99.ZOffset = v99.ZOffset + 4
						v99.LockedToPart = true
					end
					for _, v_u_100 in v96:GetDescendants() do
						if not v_u_100:IsA("ParticleEmitter") then
							continue
						end
						if v_u_100:GetAttribute("EmitDelay") and v_u_100:GetAttribute("EmitDelay") ~= 0.8 then
							task.delay(v_u_100:GetAttribute("EmitDelay"), function()
								-- upvalues: (copy) v_u_100
								v_u_100:Emit(v_u_100:GetAttribute("EmitCount"))
							end)
						else
							v_u_100:Emit(v_u_100:GetAttribute("EmitCount"))
						end
					end
					task.wait(0.75)
					v_u_4:Create(v97, TweenInfo.new(0.1), {
						["Range"] = 0
					}):Play()
					if p94:GetAttribute("Ragdoll") == 0 then
						v_u_3:AddItem(v96, 0.25)
					else
						v_u_10:PlaySound(v_u_8.Yuta.EnergyRipple.Feint.Explosion, v95, game.SoundService.Effect)
						if v_u_5.Character == p93 or (v_u_5.Character == p94 or (workspace.CurrentCamera.CFrame.Position - v96.Hitbox.Position).Magnitude < 50) then
							v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
						end
						for _, v101 in v96:GetDescendants() do
							if not v101:IsA("ParticleEmitter") or v101:GetAttribute("EmitDelay") ~= 0.8 then
								continue
							end
							v101.LockedToPart = false
							v101:Emit(v101:GetAttribute("EmitCount"))
						end
						local v102 = v_u_7.Gojo.ReversalRed.RedExplode:Clone()
						v102.Position = v96.Hitbox.Position
						v102.Parent = workspace.Effects
						v_u_3:AddItem(v102, 2)
						v102.Light.Color = v97.Color
						v102.Burst.Color = ColorSequence.new(Color3.fromRGB(255, 150, 255))
						v102.Sparks.Color = ColorSequence.new(Color3.fromRGB(255, 150, 255))
						v102.Burst:Emit(1)
						v102.Sparks:Emit(15)
						v102.Wind:Emit(6)
						v102.Dust:Emit(6)
						v_u_4:Create(v102.Light, TweenInfo.new(0.5), {
							["Brightness"] = 0
						}):Play()
					end
				else
					return
				end
			else
				return
			end
		end
	}
	v_u_11.Effects:Connect(function(p104, ...)
		-- upvalues: (copy) v_u_103
		local v105 = v_u_103[p104]
		if v105 then
			v105(...)
		end
	end)
end
function v12.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_10
	v_u_11 = v_u_1.GetService("EnergyRippleService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v12