-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Hanami.Base.BudShotController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v4 = game.ReplicatedStorage
local _ = v4.Animations
local v_u_5 = v4.Utils
local v_u_6 = v4.Sounds
require(v4.Modules.CameraShaker)
require(v4.Modules.BloodyZee)
local v_u_7 = nil
local v_u_8 = nil
local v9 = v_u_1.CreateController({
	["Name"] = "BudShotController"
})
function v9.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_8, (copy) v_u_6, (copy) v_u_2, (copy) v_u_5, (copy) v_u_3, (ref) v_u_7
	local v_u_21 = {
		["Startup"] = function(p10)
			-- upvalues: (ref) v_u_8, (ref) v_u_6
			local v11 = p10:FindFirstChild("HumanoidRootPart")
			if v11 then
				v_u_8:PlaySound(v_u_6.Hanami.BudShot.Startup, v11, game.SoundService.Effect)
			end
		end,
		["Interp"] = function(p_u_12)
			-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_2
			v_u_8:PlaySound(v_u_6.Hanami.BudShot.Throw, p_u_12, game.SoundService.Effect)
			local v_u_13 = p_u_12.CFrame
			local v_u_14 = tick()
			local v_u_15 = p_u_12:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_13, (copy) p_u_12, (ref) v_u_14
				v_u_13 = p_u_12.CFrame
				v_u_14 = tick()
			end)
			local v_u_16 = nil
			v_u_16 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_12, (ref) v_u_16, (copy) v_u_15, (ref) v_u_13, (ref) v_u_14
				if p_u_12.Parent then
					workspace:BulkMoveTo({ p_u_12 }, { v_u_13 + v_u_13.LookVector * (200 * (tick() - v_u_14)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_16:Disconnect()
					v_u_15:Disconnect()
				end
			end)
		end,
		["Hit"] = function(p17, p18)
			-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_5, (ref) v_u_3
			local v19 = p17:FindFirstChild("HumanoidRootPart")
			if v19 then
				v_u_8:PlaySound(v_u_6.Hanami.BudShot[("Hit%*"):format(p18)], v19, game.SoundService.Effect)
				v_u_8:Flash(p17, Color3.new(1, 1, 1))
				local v20 = v_u_5.Gojo.Twofold.Sparks:Clone()
				v20.Parent = v19.RootAttachment
				v20:Emit(20)
				v_u_3:AddItem(v20, 0.4)
			end
		end
	}
	v_u_7.Effects:Connect(function(p22, ...)
		-- upvalues: (copy) v_u_21
		local v23 = v_u_21[p22]
		if v23 then
			v23(...)
		end
	end)
end
function v9.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (ref) v_u_8
	v_u_7 = v_u_1.GetService("BudShotService")
	v_u_8 = v_u_1.GetController("FXController")
end
return v9