-- Original instance: Players.YouNeverSeenThat.PlayerScripts.PlayerModule.CameraModule.ZoomController.Popper
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v1 = game:GetService("Players")
local v2 = script.Parent.Parent.Parent:WaitForChild("CommonUtils")
local v3 = require(v2:WaitForChild("FlagUtil"))
local v4 = require(v2:WaitForChild("CameraWrapper"))
local v5 = require(v2:WaitForChild("ConnectionUtil"))
local v_u_6 = v3.getUserFlag("UserRaycastUpdateAPI2")
local v_u_7 = v3.getUserFlag("UserCurrentCameraUpdate2")
local v_u_8 = v3.getUserFlag("UserPlayerConnectionMemoryLeak")
local v_u_9
if v_u_7 then
	v_u_9 = v4.new()
else
	v_u_9 = nil
end
local v_u_10
if v_u_7 then
	v_u_10 = nil
else
	v_u_10 = game.Workspace.CurrentCamera
end
if v_u_7 then
	v_u_9:Enable()
end
local v_u_11 = math.min
local v_u_12 = math.tan
local v_u_13 = math.rad
local v_u_14 = Ray.new
local v_u_15 = RaycastParams.new()
v_u_15.IgnoreWater = true
v_u_15.FilterType = Enum.RaycastFilterType.Exclude
v_u_15.RespectCanCollide = true
local v_u_16 = RaycastParams.new()
v_u_16.IgnoreWater = true
v_u_16.FilterType = Enum.RaycastFilterType.Include
local v_u_17
if v_u_8 then
	v_u_17 = v5.new()
else
	v_u_17 = nil
end
local v_u_18 = nil
local v_u_19 = nil
local v_u_20, v_u_21, v_u_22
if v_u_7 then
	local function v27() -- name: updateProjection
		-- upvalues: (copy) v_u_9, (copy) v_u_13, (ref) v_u_19, (copy) v_u_12, (ref) v_u_18
		local v23 = v_u_9:getCamera()
		local v24 = v_u_13(v23.FieldOfView)
		local v25 = v23.ViewportSize
		local v26 = v25.X / v25.Y
		v_u_19 = v_u_12(v24 / 2) * 2
		v_u_18 = v26 * v_u_19
	end
	v_u_9:Connect("FieldOfView", v27)
	v_u_9:Connect("ViewportSize", v27)
	local v28 = v_u_9:getCamera()
	local v29 = v_u_13(v28.FieldOfView)
	local v30 = v28.ViewportSize
	local v31 = v30.X / v30.Y
	local v32 = v_u_12(v29 / 2) * 2
	local v33 = v31 * v32
	local v_u_34 = v_u_9:getCamera().NearPlaneZ
	v_u_9:Connect("NearPlaneZ", function()
		-- upvalues: (ref) v_u_34, (copy) v_u_9
		v_u_34 = v_u_9:getCamera().NearPlaneZ
	end)
	v_u_20 = v32
	v_u_21 = v33
	v_u_22 = v_u_34
else
	local function v38() -- name: updateProjection
		-- upvalues: (ref) v_u_10, (copy) v_u_13, (ref) v_u_19, (copy) v_u_12, (ref) v_u_18
		local v35 = v_u_13(v_u_10.FieldOfView)
		local v36 = v_u_10.ViewportSize
		local v37 = v36.X / v36.Y
		v_u_19 = v_u_12(v35 / 2) * 2
		v_u_18 = v37 * v_u_19
	end
	v_u_10:GetPropertyChangedSignal("FieldOfView"):Connect(v38)
	v_u_10:GetPropertyChangedSignal("ViewportSize"):Connect(v38)
	local v39 = v_u_13(v_u_10.FieldOfView)
	local v40 = v_u_10.ViewportSize
	local v41 = v40.X / v40.Y
	local v42 = v_u_12(v39 / 2) * 2
	local v43 = v41 * v42
	local v_u_44 = v_u_10.NearPlaneZ
	v_u_10:GetPropertyChangedSignal("NearPlaneZ"):Connect(function()
		-- upvalues: (ref) v_u_44, (ref) v_u_10
		v_u_44 = v_u_10.NearPlaneZ
	end)
	v_u_20 = v42
	v_u_21 = v43
	v_u_22 = v_u_44
end
local v_u_45 = {}
local v_u_46 = {}
local function v57(p_u_47) -- name: playerAdded
	-- upvalues: (copy) v_u_46, (ref) v_u_45, (copy) v_u_8, (copy) v_u_17
	local function v51(p48) -- name: characterAdded
		-- upvalues: (ref) v_u_46, (copy) p_u_47, (ref) v_u_45
		v_u_46[p_u_47] = p48
		local v49 = 1
		v_u_45 = {}
		for _, v50 in pairs(v_u_46) do
			v_u_45[v49] = v50
			v49 = v49 + 1
		end
	end
	local function v54() -- name: characterRemoving
		-- upvalues: (ref) v_u_46, (copy) p_u_47, (ref) v_u_45
		v_u_46[p_u_47] = nil
		local v52 = 1
		v_u_45 = {}
		for _, v53 in pairs(v_u_46) do
			v_u_45[v52] = v53
			v52 = v52 + 1
		end
	end
	if v_u_8 then
		v_u_17:trackConnection(("%*CharacterAdded"):format(p_u_47.UserId), p_u_47.CharacterAdded:Connect(v51))
		v_u_17:trackConnection(("%*CharacterRemoving"):format(p_u_47.UserId), p_u_47.CharacterRemoving:Connect(v54))
	else
		p_u_47.CharacterAdded:Connect(v51)
		p_u_47.CharacterRemoving:Connect(v54)
	end
	if p_u_47.Character then
		v_u_46[p_u_47] = p_u_47.Character
		local v55 = 1
		v_u_45 = {}
		for _, v56 in pairs(v_u_46) do
			v_u_45[v55] = v56
			v55 = v55 + 1
		end
	end
end
local function v61(p58) -- name: playerRemoving
	-- upvalues: (copy) v_u_46, (ref) v_u_45, (copy) v_u_8, (copy) v_u_17
	v_u_46[p58] = nil
	local v59 = 1
	v_u_45 = {}
	for _, v60 in pairs(v_u_46) do
		v_u_45[v59] = v60
		v59 = v59 + 1
	end
	if v_u_8 then
		v_u_17:disconnect((("%*CharacterAdded"):format(p58.UserId)))
		v_u_17:disconnect((("%*CharacterRemoving"):format(p58.UserId)))
	end
end
v1.PlayerAdded:Connect(v57)
v1.PlayerRemoving:Connect(v61)
for _, v62 in ipairs(v1:GetPlayers()) do
	v57(v62)
end
local v63 = 1
v_u_45 = {}
local v_u_64 = v_u_45
for _, v65 in pairs(v_u_46) do
	v_u_64[v63] = v65
	v63 = v63 + 1
end
local v_u_66 = nil
local v_u_67 = nil
if v_u_7 then
	v_u_9:Connect("CameraSubject", function()
		-- upvalues: (copy) v_u_9, (ref) v_u_67
		local v68 = v_u_9:getCamera().CameraSubject
		if v68 and v68:IsA("Humanoid") then
			v_u_67 = v68.RootPart
			return
		elseif v68 and v68:IsA("BasePart") then
			v_u_67 = v68
		else
			v_u_67 = nil
		end
	end)
else
	v_u_10:GetPropertyChangedSignal("CameraSubject"):Connect(function()
		-- upvalues: (ref) v_u_10, (ref) v_u_67
		local v69 = v_u_10.CameraSubject
		if v69:IsA("Humanoid") then
			v_u_67 = v69.RootPart
			return
		elseif v69:IsA("BasePart") then
			v_u_67 = v69
		else
			v_u_67 = nil
		end
	end)
end
local v_u_70 = workspace.Map.Data
local v_u_71 = workspace.Effects.CamIgnore
local function v_u_74(p72) -- name: canOcclude
	-- upvalues: (copy) v_u_70, (copy) v_u_71, (copy) v_u_6, (ref) v_u_66
	if p72.Parent == v_u_70 and p72.Locked == true or p72.Parent == v_u_71 then
		return false
	end
	local v73 = 1 - (1 - p72.Transparency) * (1 - p72.LocalTransparencyModifier) < 0.25 and (v_u_6 or p72.CanCollide)
	if v73 then
		if v_u_66 == (p72:GetRootPart() or p72) then
			v73 = false
		else
			v73 = not p72:IsA("TrussPart")
		end
	end
	return v73
end
local v_u_75 = {
	Vector2.new(0.4, 0),
	Vector2.new(-0.4, 0),
	Vector2.new(0, -0.4),
	Vector2.new(0, 0.4),
	Vector2.new(0, 0.2)
}
local function v_u_86(p76, p77) -- name: getCollisionPoint
	-- upvalues: (copy) v_u_6, (copy) v_u_15, (ref) v_u_64, (copy) v_u_14
	if v_u_6 then
		v_u_15.FilterDescendantsInstances = v_u_64
		local v78 = workspace:Raycast(p76, p77, v_u_15)
		if v78 then
			return v78.Position, true
		end
	else
		local v79 = #v_u_64
		local v80, v81 = workspace:FindPartOnRayWithIgnoreList(v_u_14(p76, p77), v_u_64, false, true)
		if v80 then
			if v80.CanCollide then
				local v82 = v_u_64
				for v83 = #v82, v79 + 1, -1 do
					v82[v83] = nil
				end
				return v81, true
			end
			v_u_64[#v_u_64 + 1] = v80
		end
		if v80 then
			continue
		end
		local v84 = v_u_64
		for v85 = #v84, v79 + 1, -1 do
			v84[v85] = nil
		end
	end
	return p76 + p77, false
end
local function v_u_112(p87, p88, p89, p90) -- name: queryPoint
	-- upvalues: (ref) v_u_64, (ref) v_u_22, (copy) v_u_6, (copy) v_u_15, (copy) v_u_74, (copy) v_u_16, (copy) v_u_14
	debug.profilebegin("queryPoint")
	local v91 = #v_u_64
	local v92 = p89 + v_u_22
	local v93 = p87 + p88 * v92
	local v94 = (1 / 0)
	local v95 = (1 / 0)
	local v96 = 0
	local v97
	if v_u_6 then
		v_u_15.FilterDescendantsInstances = v_u_64
		local v98 = p87
		while true do
			local v99 = workspace:Raycast(p87, v93 - p87, v_u_15)
			if not v99 then
				v97 = v94
				break
			end
			v96 = v96 + 1
			local v100 = v99.Instance
			local v101 = v99.Position
			v97 = (v101 - v98).Magnitude
			if v96 >= 64 then
				v95 = v97
				v97 = v94
			elseif v_u_74(v100) then
				v_u_16.FilterDescendantsInstances = { v100 }
				if workspace:Raycast(v93, v101 - v93, v_u_16) then
					local v102
					if p90 then
						v102 = workspace:Raycast(p90, v93 - p90, v_u_16) or workspace:Raycast(v93, p90 - v93, v_u_16)
					else
						v102 = false
					end
					if v102 then
						v95 = v97
						v97 = v94
					elseif v92 >= v94 then
						v97 = v94
					end
				else
					v95 = v97
					v97 = v94
				end
			else
				v97 = v94
			end
			v_u_15:AddToFilter(v100)
			p87 = v101 - p88 * 0.001
			if v95 < (1 / 0) or not v100 then
				break
			end
			v94 = v97
		end
	else
		local v103 = p87
		while true do
			if true then
				local v104, v105 = workspace:FindPartOnRayWithIgnoreList(v_u_14(p87, v93 - p87), v_u_64, false, true)
				v96 = v96 + 1
				if v104 then
					local v106 = v96 >= 64
					if v_u_74(v104) or v106 then
						local v107 = { v104 }
						local v108 = workspace:FindPartOnRayWithWhitelist(v_u_14(v93, v105 - v93), v107, true)
						v97 = (v105 - v103).Magnitude
						if v108 and not v106 then
							local v109
							if p90 then
								v109 = workspace:FindPartOnRayWithWhitelist(v_u_14(p90, v93 - p90), v107, true) or workspace:FindPartOnRayWithWhitelist(v_u_14(v93, p90 - v93), v107, true)
							else
								v109 = false
							end
							if v109 then
								v95 = v97
								v97 = v94
							elseif v92 >= v94 then
								v97 = v94
							end
						else
							v95 = v97
							v97 = v94
						end
					else
						v97 = v94
					end
					v_u_64[#v_u_64 + 1] = v104
					p87 = v105 - p88 * 0.001
				else
					v97 = v94
				end
			end
			if v95 < (1 / 0) or not v104 then
				break
			end
			v94 = v97
		end
		local v110 = v_u_64
		for v111 = #v110, v91 + 1, -1 do
			v110[v111] = nil
		end
	end
	debug.profileend()
	return v97 - v_u_22, v95 - v_u_22
end
local function v_u_128(p113, p114) -- name: queryViewport
	-- upvalues: (ref) v_u_10, (copy) v_u_7, (copy) v_u_9, (ref) v_u_21, (ref) v_u_20, (ref) v_u_22, (copy) v_u_112
	debug.profilebegin("queryViewport")
	local v115 = p113.p
	local v116 = p113.rightVector
	local v117 = p113.upVector
	local v118 = -p113.lookVector
	local v119
	if v_u_7 then
		v119 = v_u_9:getCamera()
	else
		v119 = v_u_10
	end
	v_u_10 = v119
	local v120 = v_u_10.ViewportSize
	local v121 = (1 / 0)
	local v122 = (1 / 0)
	for v123 = 0, 1 do
		local v124 = v116 * ((v123 - 0.5) * v_u_21)
		for v125 = 0, 1 do
			local v126, v127 = v_u_112(v115 + v_u_22 * (v124 + v117 * ((v125 - 0.5) * v_u_20)), v118, p114, v_u_10:ViewportPointToRay(v120.x * v123, v120.y * v125).Origin)
			if v127 >= v122 then
				v127 = v122
			end
			if v126 < v121 then
				v122 = v127
				v121 = v126
			else
				v122 = v127
			end
		end
	end
	debug.profileend()
	return v121, v122
end
local function v_u_142(p129, p130, p131) -- name: testPromotion
	-- upvalues: (copy) v_u_86, (copy) v_u_11, (copy) v_u_112, (copy) v_u_75
	debug.profilebegin("testPromotion")
	local v132 = p129.p
	local v133 = p129.rightVector
	local v134 = p129.upVector
	local v135 = -p129.lookVector
	debug.profilebegin("extrapolate")
	local v136 = (v_u_86(v132, p131.posVelocity * 1.25) - v132).Magnitude
	local v137 = p131.posVelocity.magnitude
	for v138 = 0, v_u_11(1.25, p131.rotVelocity.magnitude + v136 / v137), 0.0625 do
		local v139 = p131.extrapolate(v138)
		if p130 > v_u_112(v139.p, -v139.lookVector, p130) then
			continue
		end
		return false
	end
	debug.profileend()
	debug.profilebegin("testOffsets")
	for _, v140 in ipairs(v_u_75) do
		local v141 = v_u_86(v132, v133 * v140.x + v134 * v140.y)
		if v_u_112(v141, (v132 + v135 * p130 - v141).Unit, p130) ~= (1 / 0) then
			continue
		end
		return false
	end
	debug.profileend()
	debug.profileend()
	return true
end
return function(p143, p144, p145) -- name: Popper
	-- upvalues: (ref) v_u_66, (ref) v_u_67, (copy) v_u_128, (copy) v_u_142
	debug.profilebegin("popper")
	v_u_66 = v_u_67 and v_u_67:GetRootPart() or v_u_67
	local v146, v147 = v_u_128(p143, p144)
	if v147 >= p144 then
		v147 = p144
	end
	if v146 < v147 then
		if not v_u_142(p143, p144, p145) then
			v146 = v147
		end
	else
		v146 = v147
	end
	v_u_66 = nil
	debug.profileend()
	return v146
end