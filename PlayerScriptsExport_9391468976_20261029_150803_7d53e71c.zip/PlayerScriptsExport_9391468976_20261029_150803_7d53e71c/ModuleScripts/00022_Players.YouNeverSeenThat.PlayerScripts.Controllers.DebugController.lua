-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.DebugController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
game:GetService("TweenService")
local v_u_3 = game.Players.LocalPlayer
local v_u_4 = game.ReplicatedStorage
local _ = v_u_4.Remotes
local _ = v_u_4.Utils
local v_u_5 = v_u_4.Sounds
local v_u_6 = require(game.ReplicatedStorage.Modules.CameraShaker)
require(v_u_4.Modules.Icon)
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v10 = v_u_1.CreateController({
	["Name"] = "DebugController"
})
local v_u_11 = v_u_3
local v_u_12 = {
	["Respawn2"] = true,
	["Destroy"] = true,
	["OP"] = false,
	["FF"] = true,
	["TI"] = false,
	["Item"] = true,
	["Dummy1"] = false,
	["Dummy2"] = false,
	["Dummy3"] = false,
	["Dummy4"] = false,
	["Dummy5"] = false,
	["Dummy6"] = false,
	["Dummy7"] = false,
	["Dummy8"] = false,
	["Dummy9"] = false,
	["ForceRespawn"] = false,
	["Gravity"] = 196.2,
	["WalkSpeed"] = 16,
	["JumpPower"] = 40,
	["ServerName"] = "",
	["ServerIcon"] = 0,
	["Fidelity"] = 2,
	["DBRespawn"] = 25,
	["Tick"] = 20,
	["Damage"] = 1,
	["Knockback"] = 1,
	["DBLag"] = true,
	["AutoRes"] = true,
	["Lock"] = false,
	["Voice"] = false,
	["RC"] = false,
	["CC1"] = false,
	["CC2"] = false,
	["CC3"] = false,
	["GlobalName"] = false,
	["MaxDmg"] = 0,
	["VK"] = false,
	["VKB"] = false,
	["KF"] = false
}
local v_u_13 = {
	["Flight"] = false,
	["Build"] = false,
	["PSPerms"] = false,
	["CD"] = true,
	["Ult"] = false,
	["Stun"] = false,
	["Respawn"] = true,
	["DeathKick"] = true,
	["Skill"] = true,
	["SkillM1"] = true,
	["SkillUlt"] = true,
	["Parkour"] = true,
	["Burst"] = true,
	["ApplyNew"] = false,
	["Workshop"] = false,
	["Shenanigans"] = true
}
local v_u_14 = {
	["Kick"] = true,
	["Ban"] = true,
	["Heal"] = true,
	["ResetCD"] = true,
	["Kill"] = true,
	["Bring"] = true,
	["Go"] = true,
	["Respawn3"] = true
}
local v_u_27 = {
	["Flight"] = function()
		-- upvalues: (ref) v_u_11
		local v15 = v_u_11.Character
		if v15 then
			local v16 = v15:FindFirstChild("HumanoidRootPart")
			if v16 then
				return v16:FindFirstChild("FlightForce") ~= nil
			end
		end
	end,
	["Build"] = function()
		-- upvalues: (ref) v_u_11
		return v_u_11:FindFirstChild("BuildTag") ~= nil
	end,
	["PSPerms"] = function()
		-- upvalues: (ref) v_u_11
		return v_u_11:GetAttribute("PS_Perms")
	end,
	["CD"] = function()
		-- upvalues: (ref) v_u_11
		local v17 = v_u_11.Character
		if v17 and v17:FindFirstChild("Info") then
			return not v17.Info:GetAttribute("CD")
		end
	end,
	["Ult"] = function()
		-- upvalues: (ref) v_u_11
		local v18 = v_u_11.Character
		if v18 then
			return v18:GetAttribute("UltDrain")
		end
	end,
	["Stun"] = function()
		-- upvalues: (ref) v_u_11
		local v19 = v_u_11.Character
		if v19 and v19:FindFirstChild("Info") then
			return v19.Info:GetAttribute("NoStun")
		end
	end,
	["Respawn"] = function()
		-- upvalues: (ref) v_u_11
		local v20 = v_u_11.Character
		if v20 and v20:FindFirstChild("Info") then
			return not v20.Info:GetAttribute("NoRes")
		end
	end,
	["DeathKick"] = function()
		-- upvalues: (ref) v_u_11
		local v21 = v_u_11.Character
		if v21 and v21:FindFirstChild("Info") then
			return v21.Info:GetAttribute("DeathKick")
		end
	end,
	["Skill"] = function()
		-- upvalues: (ref) v_u_11
		local v22 = v_u_11.Character
		if v22 and v22:FindFirstChild("Info") then
			return not v22.Info:GetAttribute("Skill")
		end
	end,
	["SkillM1"] = function()
		-- upvalues: (ref) v_u_11
		local v23 = v_u_11.Character
		if v23 and v23:FindFirstChild("Info") then
			return not v23.Info:GetAttribute("M1")
		end
	end,
	["SkillUlt"] = function()
		-- upvalues: (ref) v_u_11
		local v24 = v_u_11.Character
		if v24 and v24:FindFirstChild("Info") then
			return not v24.Info:GetAttribute("Ult")
		end
	end,
	["Parkour"] = function()
		-- upvalues: (ref) v_u_11
		local v25 = v_u_11.Character
		if v25 and v25:FindFirstChild("Info") then
			return not v25.Info:GetAttribute("Parkour")
		end
	end,
	["Shenanigans"] = function()
		-- upvalues: (ref) v_u_11
		return v_u_11:GetAttribute("NoShenanigans") ~= true
	end,
	["Burst"] = function()
		-- upvalues: (ref) v_u_11
		local v26 = v_u_11.Character
		if v26 and v26:FindFirstChild("Info") then
			return not v26.Info:GetAttribute("Burst")
		end
	end,
	["Workshop"] = function()
		-- upvalues: (ref) v_u_11
		return v_u_11:GetAttribute("Workshop") == true
	end
}
local function v_u_30(p28, p29) -- name: updateBool
	if p29 == true then
		p28.Toggle.BackgroundColor3 = Color3.fromRGB(85, 255, 0)
		p28.Toggle.Side.BackgroundColor3 = Color3.fromRGB(169, 255, 189)
		p28.Toggle.Side.Position = UDim2.new(0, 0, 0, 0)
	else
		p28.Toggle.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
		p28.Toggle.Side.BackgroundColor3 = Color3.fromRGB(85, 0, 0)
		p28.Toggle.Side.Position = UDim2.new(0.5, 0, 0, 0)
	end
end
function v10.KnitStart(_) -- name: KnitStart
	-- upvalues: (copy) v_u_3, (ref) v_u_11, (copy) v_u_13, (copy) v_u_30, (copy) v_u_27, (ref) v_u_9, (copy) v_u_5, (ref) v_u_7, (copy) v_u_12, (copy) v_u_14, (copy) v_u_2, (copy) v_u_4, (copy) v_u_6
	local v_u_31 = v_u_3.PlayerGui:WaitForChild("Menus")
	local v_u_32 = v_u_31.Group.Private
	v_u_32:SetAttribute("Loaded", true)
	v_u_3:WaitForChild("leaderstats")
	local function v_u_35() -- name: updateDebugPlayer
		-- upvalues: (ref) v_u_11, (copy) v_u_32, (ref) v_u_13, (ref) v_u_30, (ref) v_u_27
		if v_u_11 == "All" then
			v_u_32.Items.Players.Players.ApplyNew.Visible = true
			for _, v33 in v_u_32.Items.Players.Players:GetDescendants() do
				if not v33:IsA("Frame") or (v_u_13[v33.Name] == nil or not v33:FindFirstChild("Toggle")) then
					continue
				end
				v_u_30(v33, v_u_13[v33.Name])
			end
		else
			v_u_32.Items.Players.Players.ApplyNew.Visible = false
			for _, v34 in v_u_32.Items.Players.Players:GetDescendants() do
				if not v34:IsA("Frame") or (v_u_27[v34.Name] == nil or not v34:FindFirstChild("Toggle")) then
					continue
				end
				v_u_30(v34, v_u_27[v34.Name]())
			end
		end
	end
	for _, v_u_36 in v_u_32.Categories:GetChildren() do
		if not v_u_36:IsA("TextButton") then
			continue
		end
		v_u_36.MouseButton1Down:Connect(function()
			-- upvalues: (copy) v_u_32, (copy) v_u_36, (ref) v_u_9, (ref) v_u_5, (copy) v_u_35
			for _, v37 in v_u_32.Categories:GetChildren() do
				if not v37:IsA("TextButton") then
					continue
				end
				v37.Select.Visible = v37 == v_u_36
			end
			v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
			if v_u_36.Name == "Players" then
				v_u_35()
			end
			for _, v38 in v_u_32.Items:GetChildren() do
				v38.Visible = v38.Name == v_u_36.Name
			end
		end)
	end
	local v_u_39 = v_u_31.Preset.Player:Clone()
	v_u_39.Name = "All"
	v_u_39.Display.Text = "All"
	v_u_39.Main.Text = "All Players"
	v_u_39.Parent = v_u_32.Items.Players.List
	v_u_39.Select.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_11, (copy) v_u_35, (ref) v_u_9, (ref) v_u_5, (copy) v_u_32, (copy) v_u_39
		v_u_11 = "All"
		v_u_35()
		v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
		for _, v40 in v_u_32.Items.Players.List:GetChildren() do
			if not v40:IsA("Frame") then
				continue
			end
			if v40 == v_u_39 then
				v40.BackgroundTransparency = 0.5
			else
				v40.BackgroundTransparency = 1
			end
		end
	end)
	local function v46(p_u_41) -- name: createGiftPlayer
		-- upvalues: (copy) v_u_31, (ref) v_u_11, (copy) v_u_32, (copy) v_u_35, (ref) v_u_9, (ref) v_u_5
		local v_u_42 = v_u_31.Preset.Player:Clone()
		v_u_42.Name = p_u_41.Name
		v_u_42.Display.Text = p_u_41.DisplayName or p_u_41.Name
		v_u_42.Main.Text = "(@" .. p_u_41.Name .. ")"
		if p_u_41 == v_u_11 then
			v_u_42.BackgroundTransparency = 0.5
		end
		v_u_42.Parent = v_u_32.Items.Players.List
		v_u_42.Select.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_11, (copy) p_u_41, (ref) v_u_35, (ref) v_u_9, (ref) v_u_5, (ref) v_u_32, (copy) v_u_42
			v_u_11 = p_u_41
			v_u_35()
			v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
			for _, v43 in v_u_32.Items.Players.List:GetChildren() do
				if not v43:IsA("Frame") then
					continue
				end
				if v43 == v_u_42 then
					v43.BackgroundTransparency = 0.5
				else
					v43.BackgroundTransparency = 1
				end
			end
		end)
		p_u_41.CharacterAdded:Connect(function()
			-- upvalues: (copy) p_u_41, (ref) v_u_11, (ref) v_u_35
			if p_u_41 == v_u_11 then
				task.defer(function()
					-- upvalues: (ref) v_u_35
					v_u_35()
				end)
			end
		end)
		pcall(function()
			-- upvalues: (copy) p_u_41, (copy) v_u_42
			local v44 = game.Players:GetUserIdFromNameAsync(p_u_41.Name)
			local v45 = game.Players:GetUserThumbnailAsync(v44, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size48x48)
			v_u_42.Icon.Image = v45
		end)
	end
	v_u_7.Debug:Connect(function(p47, p48)
		-- upvalues: (copy) v_u_32, (copy) v_u_31, (ref) v_u_9, (ref) v_u_5, (ref) v_u_7, (ref) v_u_30
		if p47 and p48 ~= nil then
			if p47 == "Banned" then
				for _, v49 in v_u_32.Items.Moderation.Banned:GetChildren() do
					if not v49:IsA("Frame") then
						continue
					end
					v49:Destroy()
				end
				for v_u_50, v51 in p48 do
					local v_u_52 = v_u_31.Preset.UnbanPlayer:Clone()
					v_u_52.Display.Text = v51.DisplayName or v51.Name
					v_u_52.Main.Text = "(@" .. v51.Name .. ")"
					v_u_52.Parent = v_u_32.Items.Moderation.Banned
					v_u_52.Button.MouseButton1Down:Connect(function()
						-- upvalues: (ref) v_u_9, (ref) v_u_5, (ref) v_u_7, (copy) v_u_50
						v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
						v_u_9:PlaySound(v_u_5.Misc.UI.Switch, workspace, game.SoundService.Effect)
						v_u_7.Unban:Fire(v_u_50)
					end)
					task.spawn(function()
						-- upvalues: (copy) v_u_50, (copy) v_u_52
						local v53 = game.Players:GetUserThumbnailAsync(v_u_50, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size48x48)
						v_u_52.Icon.Image = v53
					end)
				end
				return
			end
			for _, v54 in v_u_32.Items:GetDescendants() do
				if not v54:IsA("Frame") or (v54.Name ~= p47 or v54.Parent ~= v_u_32.Items.Server and (v54.Parent ~= v_u_32.Items.Moderation and v54.Parent ~= v_u_32.Items.Players.Players)) then
					continue
				end
				if v54:FindFirstChild("Toggle") then
					v_u_30(v54, p48)
				else
					if not v54:FindFirstChild("TextBox") then
						continue
					end
					v54.TextBox.Text = p48
				end
			end
		end
	end)
	v_u_7.Update:Connect(function(p55)
		-- upvalues: (ref) v_u_13, (copy) v_u_35
		if p55 then
			for v56, v57 in p55 do
				if v_u_13[v56] == nil then
					continue
				end
				v_u_13[v56] = v57
			end
		end
		v_u_35()
	end)
	for _, v58 in game.Players:GetChildren() do
		task.spawn(v46, v58)
	end
	game.Players.PlayerAdded:Connect(v46)
	game.Players.PlayerRemoving:Connect(function(p59)
		-- upvalues: (ref) v_u_11, (ref) v_u_3, (copy) v_u_35, (copy) v_u_32
		if v_u_11 == p59 then
			v_u_11 = v_u_3
		end
		v_u_35()
		for _, v60 in v_u_32.Items.Players.List:GetChildren() do
			if not v60:IsA("Frame") then
				continue
			end
			if v60.Name == v_u_11.Name then
				v60.BackgroundTransparency = 0.5
			elseif v60.Name == p59.Name then
				v60:Destroy()
			else
				v60.BackgroundTransparency = 1
			end
		end
	end)
	for _, v_u_61 in v_u_32.Items:GetDescendants() do
		if not v_u_61:IsA("Frame") or v_u_61.Parent ~= v_u_32.Items.Server and (v_u_61.Parent ~= v_u_32.Items.Moderation and v_u_61.Parent ~= v_u_32.Items.Players.Players) then
			continue
		end
		local v_u_62 = v_u_61.Name
		if v_u_12[v_u_62] == nil then
			if v_u_13[v_u_62] == nil then
				if v_u_14[v_u_62] == nil then
					continue
				end
				v_u_61.Button.MouseButton1Down:Connect(function()
					-- upvalues: (ref) v_u_7, (copy) v_u_62, (ref) v_u_11, (ref) v_u_9, (ref) v_u_5
					v_u_7.Debug:Fire(v_u_62, v_u_11)
					v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
				end)
			else
				v_u_61.Toggle.Side.MouseButton1Down:Connect(function()
					-- upvalues: (ref) v_u_7, (copy) v_u_62, (ref) v_u_11, (ref) v_u_9, (ref) v_u_5
					v_u_7.Debug:Fire(v_u_62, v_u_11)
					v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
					v_u_9:PlaySound(v_u_5.Misc.UI.Switch, workspace, game.SoundService.Effect)
				end)
			end
		elseif v_u_61:FindFirstChild("Toggle") then
			v_u_30(v_u_61, v_u_12[v_u_62])
			v_u_61.Toggle.Side.MouseButton1Down:Connect(function()
				-- upvalues: (ref) v_u_7, (copy) v_u_62, (ref) v_u_9, (ref) v_u_5
				v_u_7.Debug:Fire(v_u_62)
				v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
				v_u_9:PlaySound(v_u_5.Misc.UI.Switch, workspace, game.SoundService.Effect)
			end)
		elseif v_u_61:FindFirstChild("Button") then
			v_u_61.Button.MouseButton1Down:Connect(function()
				-- upvalues: (ref) v_u_7, (copy) v_u_62, (ref) v_u_9, (ref) v_u_5
				v_u_7.Debug:Fire(v_u_62)
				v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
			end)
		else
			if not v_u_61:FindFirstChild("TextBox") then
				continue
			end
			v_u_61.TextBox.FocusLost:Connect(function()
				-- upvalues: (ref) v_u_7, (copy) v_u_62, (copy) v_u_61, (ref) v_u_9, (ref) v_u_5
				v_u_7.Debug:Fire(v_u_62, v_u_61.TextBox.Text)
				v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
			end)
		end
	end
	local v_u_63 = game.ReplicatedStorage.Remotes.Request
	v_u_63.OnClientEvent:Connect(function(p_u_64, p65)
		-- upvalues: (ref) v_u_9, (ref) v_u_5, (copy) v_u_63, (ref) v_u_2
		local v66 = Instance.new("BindableFunction", script)
		function v66.OnInvoke(p67) -- name: OnInvoke
			-- upvalues: (ref) v_u_9, (ref) v_u_5, (ref) v_u_63, (copy) p_u_64
			v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
			if p67 == "Allow" then
				v_u_63:FireServer(p_u_64)
			end
		end
		v_u_2:AddItem(v66, 2)
		game:GetService("StarterGui"):SetCore("SendNotification", {
			["Title"] = "Build Mode Request",
			["Text"] = nil,
			["Button1"] = "Allow",
			["Button2"] = "Deny",
			["Callback"] = nil,
			["Duration"] = 2,
			["Text"] = p_u_64.Name .. p65,
			["Callback"] = v66
		})
	end)
	v_u_3.PlayerGui.ChildRemoved:Connect(function(p68)
		if p68.Name == "BuildTools" then
			for _, v69 in workspace.Logic:GetDescendants() do
				if v69:IsA("BillboardGui") then
					v69.Enabled = false
				elseif v69:IsA("SelectionBox") then
					v69.Visible = false
				else
					if not v69:IsA("Beam") then
						continue
					end
					v69:Destroy()
				end
			end
		end
	end)
	v_u_32:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (ref) v_u_7
		v_u_7.Update:Fire()
	end)
	v_u_32.Items.Presets:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_5, (copy) v_u_32
		v_u_9:PlaySound(v_u_5.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_32.Visible = false
		for _, v70 in v_u_32.Categories:GetChildren() do
			if not v70:IsA("TextButton") then
				continue
			end
			v70.Select.Visible = v70.Name == "Server"
		end
		for _, v71 in v_u_32.Items:GetChildren() do
			v71.Visible = v71.Name == "Server"
		end
		_G.WorkshopIcon:select()
	end)
	v_u_4.Keybind.Creator["Reset Cooldowns"].Pressed:Connect(function()
		-- upvalues: (ref) v_u_7, (ref) v_u_3
		v_u_7.Debug:Fire("ResetCD", v_u_3)
	end)
	v_u_4.Keybind.Creator["Toggle Flight"].Pressed:Connect(function()
		-- upvalues: (ref) v_u_7, (ref) v_u_3
		v_u_7.Debug:Fire("Flight", v_u_3)
	end)
	v_u_4.Keybind.Creator["Toggle Build Menu"].Pressed:Connect(function()
		-- upvalues: (ref) v_u_7, (ref) v_u_3
		v_u_7.Debug:Fire("Build", v_u_3)
	end)
	if workspace.Map.Destructible:FindFirstChild("Model") and workspace.Map.Destructible.Model:FindFirstChild("StationControl") then
		workspace.Map.Destructible.Model.StationControl.Handle.Train.OnClientEvent:Connect(function()
			-- upvalues: (ref) v_u_6
			local v_u_72 = workspace.Effects:WaitForChild("Train", 1)
			task.spawn(function()
				-- upvalues: (copy) v_u_72, (ref) v_u_6
				task.wait(0.05)
				local v73 = (workspace.CurrentCamera.CFrame.Position - v_u_72.Position).Magnitude
				if v73 <= 500 then
					local v74 = workspace.CurrentCamera.CFrame.Position
					if not workspace:Raycast(v74, v_u_72.Position - v74, _G.MapParams) then
						if v73 < 150 then
							v_u_6.CurrentShaker:Shake(v_u_6.Presets.Snap)
						elseif v73 < 300 then
							v_u_6.CurrentShaker:Shake(v_u_6.Presets.HeavyHit)
						elseif v73 > 300 then
							v_u_6.CurrentShaker:Shake(v_u_6.Presets.LightHit)
						end
					end
				end
				if v_u_72.Parent then
					continue
				end
			end)
		end)
	end
end
function v10.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (ref) v_u_8, (ref) v_u_9
	v_u_7 = v_u_1.GetService("DebugService")
	v_u_8 = v_u_1.GetService("BuildService")
	v_u_9 = v_u_1.GetController("FXController")
end
return v10