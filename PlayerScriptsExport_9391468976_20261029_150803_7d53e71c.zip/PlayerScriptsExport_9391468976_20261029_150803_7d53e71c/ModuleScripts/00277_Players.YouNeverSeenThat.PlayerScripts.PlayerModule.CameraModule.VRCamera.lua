-- Original instance: Players.YouNeverSeenThat.PlayerScripts.PlayerModule.CameraModule.VRCamera
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("VRService")
UserSettings():GetService("UserGameSettings")
require(script.Parent:WaitForChild("CameraInput"))
require(script.Parent:WaitForChild("CameraUtils"))
local v_u_3 = require(script.Parent:WaitForChild("VRCameraTeleportDetector"))
local v4 = script.Parent.Parent:WaitForChild("CommonUtils")
local v5 = require(v4:WaitForChild("FlagUtil"))
local v_u_6 = v5.getUserFlag("UserVRRecenterOnExternalTeleport")
local v_u_7 = v5.getUserFlag("UserFixVRImmersionAutoRotate")
local v_u_8 = require(script.Parent:WaitForChild("VRBaseCamera"))
local v_u_9 = setmetatable({}, v_u_8)
v_u_9.__index = v_u_9
function v_u_9.new() -- name: new
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_1
	local v10 = v_u_8.new()
	local v11 = v_u_9
	local v12 = setmetatable(v10, v11)
	v12.lastUpdate = tick()
	v12.focusOffset = CFrame.new()
	v12:Reset()
	v12.controlModule = require(v_u_1.LocalPlayer:WaitForChild("PlayerScripts").PlayerModule:WaitForChild("ControlModule"))
	v12.savedAutoRotate = true
	v12.autoRotateOverridden = false
	return v12
end
function v_u_9.Reset(p13) -- name: Reset
	-- upvalues: (copy) v_u_8
	p13.needsReset = true
	p13.needsBlackout = true
	p13.motionDetTime = 0
	p13.blackOutTimer = 0
	p13.lastCameraResetPosition = nil
	v_u_8.Reset(p13)
end
function v_u_9.Update(p14, p15) -- name: Update
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v16 = workspace.CurrentCamera
	local v17 = v16.CFrame
	local v18 = v16.Focus
	local v19 = v_u_1.LocalPlayer
	p14:GetHumanoid()
	local _ = v16.CameraSubject
	if p14.lastUpdate == nil or p15 > 1 then
		p14.lastCameraTransform = nil
	end
	p14:UpdateFadeFromBlack(p15)
	local v20 = p14.lastSubjectPosition
	local v21 = p14:GetSubjectPosition()
	if p14.needsBlackout then
		p14:StartFadeFromBlack()
		local v22 = math.clamp(p15, 0.0001, 0.1)
		p14.blackOutTimer = p14.blackOutTimer + v22
		if p14.blackOutTimer > 0.1 and game:IsLoaded() then
			p14.needsBlackout = false
			p14.needsReset = true
		end
	end
	if v21 and (v19 and v16) then
		local v23 = p14:GetVRFocus(v21, p15)
		if p14:IsInFirstPerson() then
			if v_u_2.AvatarGestures then
				v17, v18 = p14:UpdateImmersionCamera(p15, v17, v23, v20, v21)
			else
				v17, v18 = p14:UpdateFirstPersonTransform(p15, v17, v23, v20, v21)
			end
		elseif v_u_2.ThirdPersonFollowCamEnabled then
			v17, v18 = p14:UpdateThirdPersonFollowTransform(p15, v17, v23, v20, v21)
		else
			v17, v18 = p14:UpdateThirdPersonComfortTransform(p15, v17, v23, v20, v21)
		end
		p14.lastCameraTransform = v17
		p14.lastCameraFocus = v18
	end
	p14.lastUpdate = tick()
	return v17, v18
end
function v_u_9.GetAvatarFeetWorldYValue(_) -- name: GetAvatarFeetWorldYValue
	local v24 = workspace.CurrentCamera.CameraSubject
	if not v24 then
		return nil
	end
	if not (v24:IsA("Humanoid") and v24.RootPart) then
		return nil
	end
	local v25 = v24.RootPart
	return v25.Position.Y - v25.Size.Y / 2 - v24.HipHeight
end
function v_u_9.UpdateFirstPersonTransform(p26, p27, _, p28, _, _) -- name: UpdateFirstPersonTransform
	if p26.needsReset then
		p26:StartFadeFromBlack()
		p26.needsReset = false
	end
	local v29 = p28.p
	local v30 = p26:GetCameraLookVector()
	local v31 = v30.X
	local v32 = v30.Z
	local v33 = Vector3.new(v31, 0, v32).Unit
	local v34 = p26:getRotation(p27)
	local v35 = p26:CalculateNewLookVectorFromArg(v33, Vector2.new(v34, 0))
	return CFrame.new(v29 - 0.5 * v35, v29), p28
end
function v_u_9.UpdateImmersionCamera(p36, p37, _, _, p38, p39) -- name: UpdateImmersionCamera
	-- upvalues: (copy) v_u_1, (copy) v_u_6, (copy) v_u_7, (copy) v_u_2, (copy) v_u_3
	local v40 = p36:GetSubjectCFrame()
	local v41 = workspace.CurrentCamera
	local v42 = v_u_1.LocalPlayer.Character
	local v43 = p36:GetHumanoid()
	if not v43 then
		return v41.CFrame, v41.Focus
	end
	local v44 = v42:FindFirstChild("HumanoidRootPart")
	if not v44 then
		return v41.CFrame, v41.Focus
	end
	local v45
	if v_u_6 then
		if p38 then
			local v46 = p39.X - p38.X
			local v47 = p39.Z - p38.Z
			v45 = Vector3.new(v46, 0, v47).Magnitude
		else
			v45 = 0
		end
	else
		v45 = nil
	end
	p36.characterOrientation = v44:FindFirstChild("CharacterAlignOrientation")
	if not p36.characterOrientation then
		local v48 = v44:FindFirstChild("RootAttachment")
		if not v48 then
			return
		end
		p36.characterOrientation = Instance.new("AlignOrientation")
		p36.characterOrientation.Name = "CharacterAlignOrientation"
		p36.characterOrientation.Mode = Enum.OrientationAlignmentMode.OneAttachment
		p36.characterOrientation.Attachment0 = v48
		p36.characterOrientation.RigidityEnabled = true
		p36.characterOrientation.Parent = v44
	end
	if p36.characterOrientation.Enabled == false then
		p36.characterOrientation.Enabled = true
	end
	if p36.needsReset then
		p36.needsReset = false
		if v_u_7 then
			p36:updateImmersionAutoRotate()
		else
			p36.savedAutoRotate = v43.AutoRotate
			v43.AutoRotate = false
		end
		if v_u_6 then
			v_u_2:RecenterUserHeadCFrame()
			p36.lastTeleportRecenter = tick()
		end
		p36:StartFadeFromBlack()
	elseif not v43.Sit then
		local v49 = p36.controlModule:GetEstimatedVRTorsoFrame()
		p36.characterOrientation.CFrame = v41.CFrame * v49
		if p36.controlModule.inputMoveVector.Magnitude > 0 then
			p36.motionDetTime = 0.1
		end
		if p36.controlModule.inputMoveVector.Magnitude > 0 or p36.motionDetTime > 0 then
			p36.motionDetTime = p36.motionDetTime - p37
			local v50 = v_u_2:GetUserCFrame(Enum.UserCFrame.Head)
			local v51 = v50.Rotation + v50.Position * v41.HeadScale
			local v52 = v42.HumanoidRootPart
			local v53 = -0.7 * v52.Size.Y / 2
			local v54 = v41.CFrame * v51 * CFrame.new(0, v53, 0)
			local v55 = v52.CFrame.LookVector
			local v56 = v55.X
			local v57 = v55.Z
			local v58 = p39 - (v54 - Vector3.new(v56, 0, v57).Unit * v52.Size.Y * 0.125).Position + v41.CFrame.Position
			local v59 = v58.X
			local v60 = p39.Y
			local v61 = v58.Z
			local v62 = Vector3.new(v59, v60, v61)
			v40 = v41.CFrame.Rotation + v62
		elseif v_u_6 and v_u_3.shouldRecenter(p36.prevSubjStep, v45, p36.lastTeleportRecenter, tick()) then
			local v63 = v_u_2:GetUserCFrame(Enum.UserCFrame.Head)
			local v64 = v63.Rotation + v63.Position * v41.HeadScale
			local v65 = v42.HumanoidRootPart
			local v66 = -0.7 * v65.Size.Y / 2
			local v67 = v41.CFrame * v64 * CFrame.new(0, v66, 0)
			local v68 = v65.CFrame.LookVector
			local v69 = v68.X
			local v70 = v68.Z
			local v71 = p39 - (v67 - Vector3.new(v69, 0, v70).Unit * v65.Size.Y * 0.125).Position + v41.CFrame.Position
			local v72 = v71.X
			local v73 = p39.Y
			local v74 = v71.Z
			local v75 = Vector3.new(v72, v73, v74)
			v40 = v41.CFrame.Rotation + v75
			v_u_2:RecenterUserHeadCFrame()
			p36:StartFadeFromBlack()
			p36.lastTeleportRecenter = tick()
		else
			local v76 = v41.CFrame.Rotation
			local v77 = v41.CFrame.Position.X
			local v78 = p39.Y
			local v79 = v41.CFrame.Position.Z
			v40 = v76 + Vector3.new(v77, v78, v79)
		end
		local v80 = p36:getRotation(p37)
		if math.abs(v80) > 0 then
			local v81 = v_u_2:GetUserCFrame(Enum.UserCFrame.Head)
			local v82 = v81.Rotation + v81.Position * v41.HeadScale
			local v83 = v40 * v82
			local v84 = CFrame.new(v83.Position)
			local v85 = CFrame.Angles
			local v86 = v80 * 90
			v40 = v84 * v85(0, -math.rad(v86), 0) * v83.Rotation * v82:Inverse()
		end
	end
	if v_u_6 then
		p36.prevSubjStep = v45
	end
	return v40, v40 * CFrame.new(0, 0, -0.5)
end
function v_u_9.UpdateThirdPersonComfortTransform(p87, p88, p89, p90, p91, p92) -- name: UpdateThirdPersonComfortTransform
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v93 = p87:GetCameraToSubjectDistance()
	local v94 = v93 < 0.5 and 0.5 or v93
	if p91 ~= nil and p87.lastCameraFocus ~= nil then
		local _ = v_u_1.LocalPlayer
		local v95 = p91 - p92
		local v96 = p87.controlModule:GetMoveVector()
		local v97 = v95.magnitude > 0.01 and true or v96.magnitude > 0.01
		if v97 then
			p87.motionDetTime = 0.1
		end
		p87.motionDetTime = p87.motionDetTime - p88
		if (p87.motionDetTime > 0 and true or v97) and not p87.needsReset then
			local v98 = p87.lastCameraFocus
			p87.VRCameraFocusFrozen = true
			return p89, v98
		end
		local v99 = p87.lastCameraResetPosition == nil and true or (p92 - p87.lastCameraResetPosition).Magnitude > 1
		local v100 = p87:getRotation(p88)
		if math.abs(v100) > 0 then
			local v101 = p90:ToObjectSpace(p89)
			p89 = p90 * CFrame.Angles(0, -v100, 0) * v101
		end
		if p87.VRCameraFocusFrozen and v99 or p87.needsReset then
			v_u_2:RecenterUserHeadCFrame()
			p87.VRCameraFocusFrozen = false
			p87.needsReset = false
			p87.lastCameraResetPosition = p92
			p87:ResetZoom()
			p87:StartFadeFromBlack()
			local v102 = p87:GetHumanoid()
			local v103 = v102.Torso and v102.Torso.CFrame.lookVector or Vector3.new(1, 0, 0)
			local v104 = v103.X
			local v105 = v103.Z
			local v106 = Vector3.new(v104, 0, v105)
			local v107 = p90.Position - v106 * v94
			local v108 = p90.Position.X
			local v109 = v107.Y
			local v110 = p90.Position.Z
			local v111 = Vector3.new(v108, v109, v110)
			p89 = CFrame.new(v107, v111)
		end
	end
	return p89, p90
end
function v_u_9.UpdateThirdPersonFollowTransform(p112, p113, _, _, p114, p115) -- name: UpdateThirdPersonFollowTransform
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v116 = workspace.CurrentCamera
	local v117 = p112:GetCameraToSubjectDistance()
	local v118 = p112:GetVRFocus(p115, p113)
	if p112.needsReset then
		p112.needsReset = false
		v_u_2:RecenterUserHeadCFrame()
		p112:ResetZoom()
		p112:StartFadeFromBlack()
	end
	if p112.recentered then
		local v119 = p112:GetSubjectCFrame()
		if not v119 then
			return v116.CFrame, v116.Focus
		end
		local v120 = v118 * v119.Rotation * CFrame.new(0, 0, v117)
		p112.focusOffset = v118:ToObjectSpace(v120)
		p112.recentered = false
		return v120, v118
	end
	local v121 = v118:ToWorldSpace(p112.focusOffset)
	local _ = v_u_1.LocalPlayer
	local v122 = p114 - p115
	local v123 = p112.controlModule
	local v124 = v123:GetMoveVector()
	if v122.magnitude > 0.01 or v124.magnitude > 0 then
		local v125 = v123:GetEstimatedVRTorsoFrame()
		local v126 = v125.Rotation + v125.Position * v116.HeadScale
		local v127 = v116.CFrame * v126
		local v128 = v127.LookVector
		local v129 = v128.X
		local v130 = v128.Z
		local v131 = Vector3.new(v129, 0, v130).Unit * v117
		local v132 = v118.Position - v131
		v121 = v121:Lerp(CFrame.new(v116.CFrame.Position + v132 - v127.Position) * v121.Rotation, 0.01)
	end
	local v133 = p112:getRotation(p113)
	if math.abs(v133) > 0 then
		local v134 = v118:ToObjectSpace(v121)
		v121 = v118 * CFrame.Angles(0, -v133, 0) * v134
	end
	p112.focusOffset = v118:ToObjectSpace(v121)
	return v121, v121 * CFrame.new(0, 0, -v117)
end
function v_u_9.updateImmersionAutoRotate(p135) -- name: updateImmersionAutoRotate
	-- upvalues: (copy) v_u_2
	local v136 = p135:GetHumanoid()
	if v136 then
		if p135:IsInFirstPerson() and v_u_2.AvatarGestures then
			if not p135.autoRotateOverridden then
				p135.savedAutoRotate = v136.AutoRotate
				p135.autoRotateOverridden = true
			end
			v136.AutoRotate = false
		elseif p135.autoRotateOverridden then
			v136.AutoRotate = p135.savedAutoRotate
			p135.autoRotateOverridden = false
		end
	else
		return
	end
end
function v_u_9.OnEnabledChanged(p_u_137) -- name: OnEnabledChanged
	-- upvalues: (copy) v_u_8, (copy) v_u_7, (copy) v_u_2
	v_u_8.OnEnabledChanged(p_u_137)
	if v_u_7 then
		if p_u_137.enabled then
			if not p_u_137.avatarGesturesChangedConn then
				p_u_137.avatarGesturesChangedConn = v_u_2:GetPropertyChangedSignal("AvatarGestures"):Connect(function()
					-- upvalues: (copy) p_u_137
					p_u_137:updateImmersionAutoRotate()
				end)
				return
			end
		elseif p_u_137.avatarGesturesChangedConn then
			p_u_137.avatarGesturesChangedConn:Disconnect()
			p_u_137.avatarGesturesChangedConn = nil
		end
	end
end
function v_u_9.LeaveFirstPerson(p138) -- name: LeaveFirstPerson
	-- upvalues: (copy) v_u_8, (copy) v_u_7
	v_u_8.LeaveFirstPerson(p138)
	p138.needsReset = true
	if p138.VRBlur then
		p138.VRBlur.Visible = false
	end
	if p138.characterOrientation then
		p138.characterOrientation.Enabled = false
	end
	if v_u_7 then
		p138:updateImmersionAutoRotate()
	else
		local v139 = p138:GetHumanoid()
		if v139 then
			v139.AutoRotate = p138.savedAutoRotate
		end
	end
end
return v_u_9