-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Hakari.HakariController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local v_u_6 = v5.Animations
local v_u_7 = v5.Utils
local v_u_8 = v5.Sounds
local v_u_9 = require(v5.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "HakariController"
})
local v_u_14 = {
	"rbxassetid://17207807777",
	"rbxassetid://17207806991",
	"rbxassetid://17207806413",
	"rbxassetid://17207805758",
	"rbxassetid://17207805299",
	"rbxassetid://17207804676",
	"rbxassetid://17207804009"
}
function v13.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_9, (copy) v_u_6, (copy) v_u_14, (ref) v_u_10
	local v_u_147 = {
		["Hit"] = function(p15, p16)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v17 = p15:FindFirstChild("HumanoidRootPart")
			if v17 then
				v_u_12:Flash(p15, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Hakari.M1:FindFirstChild("Hit" .. p16), v17, game.SoundService.Effect)
			end
		end,
		["ChaseHit"] = function(p18, p19)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_2
			local v20 = p18:FindFirstChild("HumanoidRootPart")
			if v20 then
				local v21 = p19:FindFirstChild("HumanoidRootPart")
				if v21 then
					v_u_12:Flash(p19, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Hakari.M1:FindFirstChild("Hit3"), v21, game.SoundService.Effect)
					local v22 = v_u_7.ChaseHit:Clone()
					local v23 = CFrame.new
					local v24 = v21.Position
					local v25 = v20.Position.X
					local v26 = v21.Position.Y
					local v27 = v20.Position.Z
					v22.CFrame = v23(v24, (Vector3.new(v25, v26, v27))) * CFrame.Angles(0, 3.141592653589793, 0)
					v22.Parent = workspace.Effects
					v22.Ring:Emit(7)
					v22.Sparks:Emit(12)
					v_u_2:AddItem(v22, 0.5)
				end
			else
				return
			end
		end,
		["Counter"] = function(p28, p29, p30)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_3, (ref) v_u_2
			local v31 = p28.HumanoidRootPart
			if v31 then
				v_u_12:PlaySound(v_u_8.Hakari.Counter.Startup, v31, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_8.Hakari.ShutterDoors.Spawn, v31, game.SoundService.Effect)
				local v32 = Instance.new("Highlight")
				v32.FillTransparency = 0
				v32.FillColor = Color3.new(2, 2, 2)
				v32.OutlineColor = Color3.new(2, 2, 2)
				v32.DepthMode = Enum.HighlightDepthMode.Occluded
				v32.Parent = p29.Doors
				if p30 then
					p29.Doors.Door1.Color = p30
					p29.Doors.Door2.Color = p30
					p29.Doors.Door1.Stars.Color = ColorSequence.new(p30)
					p29.Doors.Door2.Stars.Color = ColorSequence.new(p30)
				end
				v_u_3:Create(v32, TweenInfo.new(0.4), {
					["FillTransparency"] = 1,
					["OutlineTransparency"] = 1
				}):Play()
				v_u_2:AddItem(v32, 0.4)
				task.wait(0.2)
				p29.Doors.Door1.Stars.Enabled = false
				p29.Doors.Door2.Stars.Enabled = false
			end
		end,
		["Fade"] = function(p33)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v34 = p33:FindFirstChild("HumanoidRootPart")
			v_u_12:Flash(p33, Color3.new(0, 0, 0), 0.3)
			v_u_12:PlaySound(v_u_8.Hakari.ShutterDoors.Slam, v34, game.SoundService.Effect)
		end,
		["CounterHit"] = function(p35, p36)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_4, (ref) v_u_9
			local v37 = p36:FindFirstChild("HumanoidRootPart")
			v_u_12:Flash(p36, Color3.new(1, 1, 1))
			v_u_12:PlaySound(v_u_8.Itadori.CraniumSmash.Hit2, v37, game.SoundService.Effect)
			if v_u_4 == p35 or v_u_4.Character == p36 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
			end
		end,
		["CounterEnd"] = function(_, p38)
			-- upvalues: (ref) v_u_3
			v_u_3:Create(p38.Weld1, TweenInfo.new(0.5, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
				["C1"] = CFrame.new(0, 0, 8) * CFrame.Angles(0, -1.5707963267948966, 0)
			}):Play()
			v_u_3:Create(p38.Weld2, TweenInfo.new(0.5, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
				["C1"] = CFrame.new(0, 0, 8) * CFrame.Angles(0, -1.5707963267948966, 3.141592653589793)
			}):Play()
			for _, v39 in p38.Doors:GetDescendants() do
				if not (v39:IsA("BasePart") or v39:IsA("Texture")) then
					continue
				end
				v_u_3:Create(v39, TweenInfo.new(0.5), {
					["Transparency"] = 1
				}):Play()
			end
		end,
		["CounterSwing"] = function(p40, p41, p42)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_3
			local v43 = p40.HumanoidRootPart
			if v43 then
				v_u_12:PlaySound(v_u_8.Hakari.Counter.Swing, v43, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_8.Hakari.Counter.Slam, v43, game.SoundService.Effect)
				local v44 = p41.Doors:Clone()
				v44.Parent = p41
				p41.Doors:Destroy()
				v44.Door1.Stars:Emit(20)
				v44.Door2.Stars:Emit(20)
				v44.Door1.CanCollide = true
				v44.Door2.CanCollide = true
				v44.Door1.Velocity = v43.CFrame.LookVector * (p42 and -60 or 60) + v43.CFrame.RightVector * 20
				v44.Door2.Velocity = v43.CFrame.LookVector * (p42 and -60 or 60) + v43.CFrame.RightVector * 20
				for _, v45 in v44:GetDescendants() do
					if not (v45:IsA("BasePart") or v45:IsA("Texture")) then
						continue
					end
					v_u_3:Create(v45, TweenInfo.new(0.6, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
						["Transparency"] = 1
					}):Play()
				end
			end
		end,
		["Chase"] = function(p46)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_12, (ref) v_u_8
			local v47 = p46.HumanoidRootPart
			if v47 then
				local v48 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v48.CFrame = v47.CFrame * CFrame.new(0, 1, -4)
				v48.Size = Vector3.new(0, 0, 2)
				v48.Parent = workspace.Effects
				v_u_3:Create(v48, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v48, 0.3)
				v_u_12:PlaySound(v_u_8.Misc.Chase, v47, game.SoundService.Effect)
				v_u_12:DustTrail(p46, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p49)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v50 = p49:FindFirstChild("HumanoidRootPart")
			if v50 then
				v_u_12:PlaySound(v_u_8.Misc.Swing.Fist, v50, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p51, p52, p53)
			-- upvalues: (ref) v_u_12
			if p51:GetAttribute("InUlt") then
				if p53 == "Down" then
					v_u_12:ArmFlash(p51["Right Leg"], Color3.fromRGB(85, 255, 127), 0.4)
					return
				elseif p52 == 1 or p52 == 4 then
					v_u_12:ArmFlash(p51["Right Arm"], Color3.fromRGB(85, 255, 127), 0.3)
				else
					v_u_12:ArmFlash(p51["Left Arm"], Color3.fromRGB(85, 255, 127), 0.3)
				end
			elseif p53 == "Up" then
				v_u_12:ArmFlash(p51["Left Leg"], Color3.fromRGB(85, 255, 127), 0.4)
				return
			elseif p53 == "Down" then
				v_u_12:ArmFlash(p51["Right Leg"], Color3.fromRGB(85, 255, 127), 0.4)
				return
			elseif p52 == 4 then
				v_u_12:ArmFlash(p51["Left Leg"], Color3.fromRGB(85, 255, 127))
			else
				v_u_12:ArmFlash(p51["Right Leg"], Color3.fromRGB(85, 255, 127), 0.3)
			end
		end,
		["Launch"] = function(p54, p55)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_12, (ref) v_u_8, (ref) v_u_4, (ref) v_u_9
			local v56 = p54:FindFirstChild("HumanoidRootPart")
			if v56 then
				local v57 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v57.CFrame = CFrame.new(v56.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v57.Size = Vector3.new(0, 0, 5)
				v57.Parent = workspace.Effects
				v_u_3:Create(v57, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = nil,
					["Position"] = v57.Position + Vector3.new(0, p55, 0)
				}):Play()
				v_u_2:AddItem(v57, 0.3)
				if p55 < 0 then
					v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v56, game.SoundService.Effect)
					v_u_12:DustBreak(v56.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_4:DistanceFromCharacter(v56.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			end
		end,
		["Surge"] = function(p58, p59)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_4, (ref) v_u_9
			local v60 = p58:FindFirstChild("HumanoidRootPart")
			if v60 then
				p59.EnergyBurst:Emit(20)
				v_u_12:Flash(p58, Color3.fromRGB(85, 255, 127), 1)
				v_u_12:PlaySound(v_u_8.Hakari.OverLuck.Charge, v60, game.SoundService.Effect)
				if v_u_4.Character == p58 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					local v61 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.LightHit)
					repeat
						task.wait()
					until not p59.Parent or p59.Surge.Enabled == false
					v61:StartFadeOut(1)
				end
			end
		end,
		["Startup"] = function(p62)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_4, (ref) v_u_6
			local v63 = p62:FindFirstChild("HumanoidRootPart")
			if v63 then
				v_u_12:PlaySound(v_u_8.Hakari.IdleDeath.Voice, v63, game.SoundService.Voice)
				v_u_12:DomainBurst(v63)
				local v64 = v_u_4.Character
				if v64 and v64:FindFirstChild("HumanoidRootPart") then
					local v65 = v64:FindFirstChild("HumanoidRootPart")
					if (v63.Position - v65.Position).Magnitude <= 37.5 then
						v_u_12:Domain(p62, function(p66, p67)
							-- upvalues: (ref) v_u_6
							p67.Humanoid:LoadAnimation(v_u_6.Hakari.DomainWarn):Play(0)
							p66.Panel.ImageLabel.Image = "rbxassetid://16069822951"
						end)
					end
				end
			end
		end,
		["Opening"] = function(p68, p69, p_u_70, p71)
			-- upvalues: (ref) v_u_7, (ref) v_u_2, (ref) v_u_12, (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_14, (ref) v_u_9
			local v_u_72 = v_u_7.Hakari.IdleDeath.DomainBG:Clone()
			v_u_72.Parent = p68
			v_u_72.CFrame = p68.CFrame
			task.spawn(function()
				-- upvalues: (copy) p_u_70, (copy) v_u_72
				repeat
					task.wait()
				until not (p_u_70.Parent and (p_u_70.Parent.Parent and p_u_70.Parent.Parent.Parent))
				v_u_72:Destroy()
			end)
			local v_u_73 = nil
			if not p71 then
				local v_u_74 = p69.DomainGround
				v_u_74.Surround.ShapePartial = 1
				v_u_74.Surround.Enabled = true
				v_u_2:AddItem(v_u_74, 2)
				v_u_12:PlaySound(v_u_8.Hakari.IdleDeath.IdleDeath, workspace, game.SoundService.Effect)
				task.delay(0.5, function()
					-- upvalues: (ref) v_u_3, (copy) v_u_74, (ref) v_u_12
					v_u_3:Create(v_u_74, TweenInfo.new(0.25), {
						["Transparency"] = 0
					}):Play()
					v_u_12:DomainMapFade(Color3.new(1, 1, 1), 0.25, 1)
				end)
				task.wait(1)
				if not (p_u_70 and p_u_70.Parent) then
					return
				end
				local v75 = v_u_4.Character
				if v75 and v75:GetAttribute("Moveset") ~= "Toji" then
					local v_u_76 = v_u_7.Hakari.IdleDeath.DomainInfo:Clone()
					v_u_76.Scenario1.Text = "Transit Card Richii (\226\152\134 \226\152\134 \226\152\133)"
					v_u_76.Scenario2.Text = "Travel Emergency Richii (\226\152\134 \226\152\133 \226\152\133)"
					v_u_76.Parent = v_u_4.PlayerGui
					v_u_2:AddItem(v_u_76, 15)
					task.spawn(function()
						-- upvalues: (ref) v_u_76, (ref) v_u_3
						local v77 = 0
						for _, v78 in v_u_76:GetChildren() do
							if not v78:IsA("TextLabel") then
								continue
							end
							v_u_3:Create(v78, TweenInfo.new(15, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
								["TextTransparency"] = 1,
								["TextStrokeTransparency"] = 1
							}):Play()
							local v79 = v78.Position
							v78.Position = v79 + UDim2.new(v78.AnchorPoint.X == 1 and 0.5 or -0.5, 0, 0, 0)
							v_u_3:Create(v78, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
								["Position"] = v79
							}):Play()
						end
						for _, v80 in v_u_76:GetChildren() do
							if not v80:IsA("TextLabel") then
								continue
							end
							v80.TextColor3 = Color3.fromHSV(v77, 1, 1)
						end
						task.wait()
						v77 = (v77 + 0.01) % 1
						if v_u_76.Parent then
							break
						end
					end)
					v_u_73 = v_u_76
					for _, v81 in v_u_14 do
						local v82 = Instance.new("ImageLabel")
						v82.Size = UDim2.new(0, 0, 0, 0)
						v82.Image = v81
						v82.Parent = v_u_73
					end
				end
			end
			local v_u_83 = v_u_12:PlaySound(v_u_8.Hakari.IdleDeath.Music, workspace, game.SoundService.Music, true)
			local v_u_84 = v_u_12:PlaySound(v_u_8.Hakari.IdleDeath.Travel, workspace, game.SoundService.Effect, true)
			game.SoundService.AmbientReverb = Enum.ReverbType.Alley
			task.spawn(function()
				-- upvalues: (copy) p_u_70, (ref) v_u_3, (copy) v_u_83, (ref) v_u_2, (copy) v_u_84, (ref) v_u_73
				repeat
					task.wait()
				until not (p_u_70.Parent and (p_u_70.Parent.Parent and p_u_70.Parent.Parent.Parent))
				game.SoundService.AmbientReverb = Enum.ReverbType.NoReverb
				v_u_3:Create(v_u_83, TweenInfo.new(2), {
					["PlaybackSpeed"] = 0
				}):Play()
				v_u_2:AddItem(v_u_83, 2)
				if v_u_84 then
					v_u_84:Destroy()
				end
				if v_u_73 and v_u_73.Parent then
					v_u_73:Destroy()
				end
			end)
			v_u_72:GetAttributeChangedSignal("OhYeah"):Connect(function()
				-- upvalues: (ref) v_u_3, (copy) v_u_83
				v_u_3:Create(v_u_83, TweenInfo.new(2), {
					["PlaybackSpeed"] = 0,
					["Volume"] = 0
				}):Play()
			end)
			v_u_72.Speedlines.Enabled = true
			local v85 = v_u_7.Hakari.IdleDeath.Segment:Clone()
			local v86 = v_u_7.Hakari.IdleDeath.Segment:Clone()
			v85.CFrame = p68.CFrame * CFrame.new(40, 0, 400) * CFrame.Angles(0, 3.141592653589793, 0)
			v86.CFrame = p68.CFrame * CFrame.new(-40, 0, 400)
			for v87 = 1, 50 do
				local v88 = v_u_7.Hakari.IdleDeath.Segment:Clone()
				v88.CFrame = v85.CFrame * CFrame.new(0, 0, v87 * -8)
				v88.Anchored = false
				v88.WeldConstraint.Part1 = v85
				v88.Parent = v85
				local v89 = v88:Clone()
				v89.CFrame = v86.CFrame * CFrame.new(0, 0, v87 * 8)
				v89.WeldConstraint.Part1 = v86
				v89.Parent = v86
			end
			v85.Parent = p68
			v86.Parent = p68
			v_u_3:Create(v85, TweenInfo.new(0.5), {
				["CFrame"] = p68.CFrame * CFrame.new(40, 0, -200) * CFrame.Angles(0, 3.141592653589793, 0)
			}):Play()
			v_u_3:Create(v86, TweenInfo.new(0.5), {
				["CFrame"] = p68.CFrame * CFrame.new(-40, 0, -200)
			}):Play()
			local v90 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.HeavyHit)
			task.wait(0.5)
			local v91 = Instance.new("NumberValue", v_u_72)
			v91.Value = 0
			v_u_3:Create(v91, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.InOut), {
				["Value"] = 90
			}):Play()
			v_u_2:AddItem(v91, 1.5)
			repeat
				local v92 = p68.CFrame
				local v93 = CFrame.Angles
				local v94 = v91.Value
				local v95 = math.rad(v94)
				local v96 = v91.Value * 2
				v_u_72.CFrame = v92 * v93(v95, 0, (math.rad(v96)))
				v85.CFrame = v_u_72.CFrame * CFrame.new(40, 0, -200 + math.random(-200, 200) / 100) * CFrame.Angles(0, 3.141592653589793, 0)
				v86.CFrame = v_u_72.CFrame * CFrame.new(-40, 0, -200 + math.random(-200, 200) / 100)
				task.wait()
			until not (v91.Parent and v85.Parent)
			v90:StartFadeOut(1)
			if v_u_72.Parent then
				v_u_72.Speedlines:Destroy()
				v_u_3:Create(v_u_72, TweenInfo.new(0.5), {
					["Color"] = Color3.fromRGB(160, 160, 160)
				}):Play()
				v_u_3:Create(v85, TweenInfo.new(0.5), {
					["CFrame"] = v_u_72.CFrame * CFrame.new(40, 0, -800) * CFrame.Angles(0, 3.141592653589793, 0)
				}):Play()
				v_u_3:Create(v86, TweenInfo.new(0.5), {
					["CFrame"] = v_u_72.CFrame * CFrame.new(-40, 0, -800)
				}):Play()
				v_u_2:AddItem(v85, 0.5)
				v_u_2:AddItem(v86, 0.5)
				v_u_72.CFrame = p68.CFrame
				local v97 = v_u_7.Hakari.IdleDeath.Normal:Clone()
				v97.CFrame = p68.CFrame * CFrame.new(0, -150, 0)
				v97.Parent = v_u_72
				v_u_3:Create(v97, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["CFrame"] = p68.CFrame
				}):Play()
				local v98 = v97:GetChildren()
				for v99 = 1, 16 do
					local v100 = CFrame.new()
					local v101 = CFrame.Angles
					local v102 = (v99 - 1) * 22.5
					local v103 = v100 * v101(0, math.rad(v102), 0)
					v98[v99].Weld.C1 = v103 * CFrame.new(0, 0, 50) * CFrame.Angles(0, 1.5707963267948966, 0)
				end
			end
		end,
		["Richii"] = function(_, p104, p105, p106, p107)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_12
			local v108 = p104:FindFirstChild("DomainBG")
			if v108 then
				local v109 = v108:FindFirstChild("Normal")
				if v109 then
					local v110 = p107 and p107 == 2 and 1.667 or 1
					local v111 = { v_u_7.Hakari.IdleDeath.Scenarios.IC, v_u_7.Hakari.IdleDeath.Scenarios.P }
					v_u_3:Create(v109, TweenInfo.new(0), {
						["CFrame"] = p104.CFrame * CFrame.new(0, -250, 0)
					}):Play()
					local v112 = v111[p106]:Clone()
					v112:SetAttribute("Jackpot", p105)
					v112:SetAttribute("Speed", v110)
					v112:PivotTo(p104.CFrame)
					v112.Parent = v108.Scenario
					v112.ScenarioPlay.Enabled = true
					game.Lighting.ExposureCompensation = 15
					v_u_3:Create(game.Lighting, TweenInfo.new(1), {
						["ExposureCompensation"] = 0
					}):Play()
					task.wait(3 / v110)
					if p105 then
						v108:SetAttribute("OhYeah", true)
						local v113 = v_u_12:PlaySound(v_u_7.Hakari.IdleDeath.Aura.Torso.JackpotMusic, v108, game.SoundService.Music)
						v113.TimePosition = v113.TimePosition - 3 / v110
						v113.Volume = 0
						v_u_3:Create(v113, TweenInfo.new(2), {
							["Volume"] = 1
						}):Play()
					end
					task.wait(3 / v110)
					if p104.Parent then
						if not p105 then
							v108.Scenario:ClearAllChildren()
							v_u_3:Create(v109, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
								["CFrame"] = p104.CFrame
							}):Play()
							game.Lighting.ExposureCompensation = -15
							v_u_3:Create(game.Lighting, TweenInfo.new(1), {
								["ExposureCompensation"] = 0
							}):Play()
						end
					else
						return
					end
				else
					return
				end
			else
				return
			end
		end,
		["Roll"] = function(p114, p115)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_2, (ref) v_u_14, (ref) v_u_12, (ref) v_u_8, (ref) v_u_3, (ref) v_u_9
			local v116 = v_u_7.Hakari.IdleDeath.Roll:Clone()
			v116.Parent = v_u_4.PlayerGui
			v_u_2:AddItem(v116, 3)
			if p114 then
				v116.Number1.Image = v_u_14[p114]
				v_u_12:PlaySound(v_u_8.Hakari.IdleDeath.Roll, workspace, game.SoundService.Effect)
				v_u_3:Create(v116.Number1, TweenInfo.new(0.75, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out), {
					["Position"] = UDim2.new(0.225, 0, 0.5, 0)
				}):Play()
				v_u_3:Create(v116.Number1, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
					["ImageTransparency"] = 1
				}):Play()
				task.wait(0.15)
				v116.Number3.Image = v_u_14[p114]
				v_u_12:PlaySound(v_u_8.Hakari.IdleDeath.Roll, workspace, game.SoundService.Effect)
				v_u_3:Create(v116.Number3, TweenInfo.new(0.75, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out), {
					["Position"] = UDim2.new(0.775, 0, 0.5, 0)
				}):Play()
				v_u_3:Create(v116.Number3, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
					["ImageTransparency"] = 1
				}):Play()
				task.wait(0.15)
			end
			if p115 then
				v116.Number2.Image = v_u_14[p115]
				v_u_12:PlaySound(v_u_8.Hakari.IdleDeath.Roll, workspace, game.SoundService.Effect)
				v_u_3:Create(v116.Number2, TweenInfo.new(0.75, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out), {
					["Position"] = UDim2.new(0.5, 0, 0.5, 0)
				}):Play()
				v_u_3:Create(v116.Number2, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
					["ImageTransparency"] = 1
				}):Play()
				if p115 == p114 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					v_u_12:PlaySound(v_u_8.Hakari.IdleDeath.Jackpot, workspace, game.SoundService.Effect)
				end
			end
		end,
		["Jackpot"] = function(p_u_117, p118, p_u_119)
			-- upvalues: (ref) v_u_7, (ref) v_u_2, (ref) v_u_3, (ref) v_u_4, (ref) v_u_9
			local v120 = p_u_117:FindFirstChild("HumanoidRootPart")
			if v120 then
				local v121 = v_u_7.Hakari.IdleDeath.Jackpot:Clone()
				v121.Parent = workspace.Effects
				v121.CFrame = v120.CFrame
				v121.EnergyBurst:Emit(7)
				v121.Ring:Emit(7)
				v121.Sparks:Emit(21)
				v_u_2:AddItem(v121, 1)
				task.spawn(function()
					-- upvalues: (ref) v_u_7, (copy) p_u_117, (copy) p_u_119, (ref) v_u_3, (ref) v_u_2
					local v122 = v_u_7.Hakari.Dialogue:Clone()
					v122.Parent = p_u_117.Torso
					if p_u_119 then
						v122.Chat1.Sub.Text = "IN THE NEXT 50 SECONDS..."
					end
					local v123 = v122.Chat1.Position
					v122.Chat1.Position = v123 - UDim2.new(0, 0, 0.15, 0)
					v_u_3:Create(v122.Chat1, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Position"] = v123
					}):Play()
					v_u_3:Create(v122.Chat1, TweenInfo.new(0.3), {
						["BackgroundTransparency"] = 0
					}):Play()
					v_u_3:Create(v122.Chat1.Sub, TweenInfo.new(0.3), {
						["TextTransparency"] = 0
					}):Play()
					task.wait(0.5)
					local v124 = v122.Chat2.Position
					v122.Chat2.Position = v124 - UDim2.new(0, 0, 0.15, 0)
					v_u_3:Create(v122.Chat2, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Position"] = v124
					}):Play()
					v_u_3:Create(v122.Chat2, TweenInfo.new(0.3), {
						["BackgroundTransparency"] = 0
					}):Play()
					v_u_3:Create(v122.Chat2.Sub, TweenInfo.new(0.3), {
						["TextTransparency"] = 0
					}):Play()
					task.wait(2)
					v_u_2:AddItem(v122, 0.6)
					for _, v125 in v122:GetDescendants() do
						if v125:IsA("Frame") then
							v_u_3:Create(v125, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
								["Position"] = nil,
								["BackgroundTransparency"] = 1,
								["Position"] = v125.Position - UDim2.new(0, 0, 0.2, 0)
							}):Play()
						else
							if not v125:IsA("TextLabel") then
								continue
							end
							v_u_3:Create(v125, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
								["TextTransparency"] = 1
							}):Play()
						end
					end
				end)
				if v_u_4.Character == p_u_117 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					local v126 = v_u_7.Hakari.IdleDeath.AudioVis:Clone()
					v126.Parent = v_u_4.PlayerGui
					local v127 = {
						[49.375] = "You struck me,",
						[51.03] = "boy, you knocked me down",
						[52.9] = "Was never looking for you but you called me out",
						[57.01] = "You caught me and I can\'t get enough",
						[60.7] = "I\'m trippin\' out, I\'m trippin\' out",
						[62.8] = "I\'m trippin\' out on love",
						[64.13] = "I gotta pinch myself so I know it\'s real",
						[68.26] = "With you next to me, I am strong as steel",
						[71.91] = "Boy, you struck me, can\'t get enough",
						[76.06] = "I\'m trippin\' out, I\'m trippin\' out",
						[78.04] = "I\'m trippin\' out on love",
						[80.84] = ""
					}
					for v128, v129 in v127 do
						if v128 >= p118.TimePosition then
							continue
						end
						v126.Lyrics.Text = v129
						v127[v128] = nil
					end
					local v130 = 2 - p118.PlaybackLoudness / 330
					local v131 = math.clamp(v130, 1, (1 / 0))
					v126.Beat.Size = v126.Beat.Size:Lerp(UDim2.new(v131, 0, v131, 0), 0.5)
					task.wait()
					if p118.Parent and p118.Volume == 1 then
						break
					end
					v_u_3:Create(v126.Beat, TweenInfo.new(0.25), {
						["ImageTransparency"] = 1
					}):Play()
					v_u_2:AddItem(v126, 0.25)
				end
			end
		end,
		["Shatter"] = function(p132)
			-- upvalues: (ref) v_u_7, (ref) v_u_2, (ref) v_u_12, (ref) v_u_8, (ref) v_u_3
			local v133 = v_u_7.Domain:Clone()
			v133.Transparency = 1
			v133.CanCollide = false
			v133.Position = p132
			v133.Parent = workspace.Effects
			v_u_2:AddItem(v133, 3)
			for _, v134 in v133:GetChildren() do
				if v134.Name == "Shatter" then
					v134:Emit(100)
				else
					v134:Destroy()
				end
			end
			v_u_12:PlaySound(v_u_8.Hakari.IdleDeath.Shatter, v133, game.SoundService.Effect)
			v133.Transparency = 0
			v_u_3:Create(v133, TweenInfo.new(0.2), {
				["Transparency"] = 1
			}):Play()
			if _G.Settings.DesPHY then
				if (workspace.CurrentCamera.CFrame.Position - v133.Position).Magnitude > 150 then
					return
				end
				local v135 = Random.new()
				local v136 = TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
				for _ = 1, 80 do
					local v137 = v_u_7.Gojo.Shard:Clone()
					local v138 = v135:NextUnitVector().Unit
					local v139 = math.random(1, 8)
					local v140 = math.random
					v137.Size = Vector3.new(0.1, v139, v140(1, 8))
					v137.CFrame = CFrame.lookAlong(p132, v138) * CFrame.Angles(1.5707963267948966, 0, 0) + v138 * 37.5
					v137.CFrame = v137.CFrame * CFrame.Angles(0, math.random(0, 3.141592653589793), 0)
					v137.CanCollide = true
					v137.CollisionGroup = "Effects"
					v137.Parent = workspace.Effects
					local v141 = math.random(-50, 50)
					local v142 = math.random(-50, 50)
					local v143 = math.random
					v137.RotVelocity = Vector3.new(v141, v142, v143(-50, 50))
					v137.Transparency = 0
					v137.Material = Enum.Material.Neon
					v_u_3:Create(v137, v136, {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_2:AddItem(v137, 4)
				end
			end
		end,
		["RevengeAppear"] = function(p144)
			-- upvalues: (ref) v_u_7, (ref) v_u_12, (ref) v_u_8, (ref) v_u_2
			local v145 = v_u_7.Hakari.RevengeAppear:Clone()
			v145.Parent = workspace.Effects
			v145.WorldPosition = p144
			for _, v146 in v145:GetChildren() do
				v146:Emit(v146:GetAttribute("EmitCount"))
			end
			v_u_12:PlaySound(v_u_8.Kogane.Disappear, v145, game.SoundService.Effect)
			v_u_2:AddItem(v145, 3)
		end
	}
	task.spawn(function()
		-- upvalues: (ref) v_u_14
		game:GetService("ContentProvider"):PreloadAsync(v_u_14)
	end)
	v_u_10.Effects:Connect(function(p148, ...)
		-- upvalues: (copy) v_u_147
		local v149 = v_u_147[p148]
		if v149 then
			v149(...)
		end
	end)
end
function v13.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("HakariService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13