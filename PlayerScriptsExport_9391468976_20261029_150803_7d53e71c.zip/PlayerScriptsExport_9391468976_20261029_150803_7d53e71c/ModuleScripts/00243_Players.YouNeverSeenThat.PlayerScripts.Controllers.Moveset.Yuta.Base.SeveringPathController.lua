-- Original instance: Players.YouNeverSeenThat.PlayerScripts.Controllers.Moveset.Yuta.Base.SeveringPathController
-- Class: ModuleScript
-- Decompiled output; accuracy is not guaranteed.

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v3 = game.ReplicatedStorage
local _ = v3.Animations
local v_u_4 = v3.Utils
local v_u_5 = v3.Sounds
require(v3.Modules.CameraShaker)
local v_u_6 = nil
local v_u_7 = nil
local v8 = v_u_1.CreateController({
	["Name"] = "SeveringPathController"
})
local v_u_9 = {
	10,
	5,
	55,
	50
}
function v8.KnitStart(_) -- name: KnitStart
	-- upvalues: (ref) v_u_6, (copy) v_u_5, (copy) v_u_4, (copy) v_u_2, (copy) v_u_9, (ref) v_u_7
	local v_u_33 = {
		["Start"] = function(p10)
			-- upvalues: (ref) v_u_6, (ref) v_u_5
			local v11 = p10:FindFirstChild("HumanoidRootPart")
			if v11 then
				v_u_6:PlaySound(v_u_5.Yuta.SeveringPath.Start, v11, game.SoundService.Effect)
			end
		end,
		["Start2"] = function(p12)
			-- upvalues: (ref) v_u_4, (ref) v_u_2
			local v13 = p12.SetAssets:FindFirstChild("YutaSword")
			if v13 then
				if p12:FindFirstChild("HumanoidRootPart") then
					local v14 = v13.Sword.Blade
					local v15 = v_u_4.Yuta.ResoluteSlash.SwordBurst.Attachment0:Clone()
					local v16 = v_u_4.Yuta.ResoluteSlash.SwordBurst.Center:Clone()
					v15.Parent = v14
					v16.Parent = v14
					v_u_2:AddItem(v15, 0.5)
					v_u_2:AddItem(v16, 4)
					v15.Burst1:Emit(1)
					v16.Burst2:Emit(1)
					task.wait(0.3)
					v16:Destroy()
					local v17 = v_u_4.Yuta.ResoluteSlash.SwordBurst.Sparks:Clone()
					v17.Parent = v14
					v_u_2:AddItem(v17, 0.7)
					v17:Emit(30)
				end
			else
				return
			end
		end,
		["Swing"] = function(p18)
			-- upvalues: (ref) v_u_6, (ref) v_u_5
			local v19 = p18:FindFirstChild("HumanoidRootPart")
			if v19 then
				v_u_6:PlaySound(v_u_5.Yuta.SeveringPath["Swing" .. math.random(1, 3)], v19, game.SoundService.Effect)
			end
		end,
		["PunchSwing"] = function(p20)
			-- upvalues: (ref) v_u_6, (ref) v_u_5
			local v21 = p20:FindFirstChild("HumanoidRootPart")
			if v21 then
				v_u_6:PlaySound(v_u_5.Hiromi.Throw2, v21, game.SoundService.Effect).PlaybackSpeed = math.random(9, 11) / 10
			end
		end,
		["Hit"] = function(p22, p23, p24)
			-- upvalues: (ref) v_u_6, (ref) v_u_5, (ref) v_u_4, (ref) v_u_9, (ref) v_u_2
			local v25 = p22:FindFirstChild("HumanoidRootPart")
			if v25 then
				local v26 = p23:FindFirstChild("HumanoidRootPart")
				if v26 then
					v_u_6:Flash(p23, Color3.fromRGB(255, 170, 255))
					v_u_6:PlaySound(v_u_5.Yuta.SeveringPath:FindFirstChild("Hit" .. p24), v26, game.SoundService.Effect)
					local v27 = v_u_4.Yuta.SlashHit:Clone()
					v27.Slash.Color = ColorSequence.new(Color3.fromRGB(255, 85, 255))
					local v28 = CFrame.lookAlong(v26.Position, v25.CFrame.LookVector)
					local v29 = CFrame.Angles
					local v30 = v_u_9[p24] or 0
					v27.CFrame = v28 * v29(0, 0, (math.rad(v30)))
					v27.Parent = workspace.Effects
					v_u_2:AddItem(v27, 0.5)
					v27.Slash:Emit(5)
				end
			else
				return
			end
		end,
		["AirHit"] = function(p31, _)
			-- upvalues: (ref) v_u_6, (ref) v_u_5
			local v32 = p31:FindFirstChild("HumanoidRootPart")
			if v32 then
				v_u_6:Flash(p31, Color3.new(1, 1, 1))
				v_u_6:PlaySound(v_u_5.Yuta.M1.Hit4, v32, game.SoundService.Effect)
			end
		end
	}
	v_u_7.Effects:Connect(function(p34, ...)
		-- upvalues: (copy) v_u_33
		local v35 = v_u_33[p34]
		if v35 then
			v35(...)
		end
	end)
end
function v8.KnitInit(_) -- name: KnitInit
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (ref) v_u_6
	v_u_7 = v_u_1.GetService("SeveringPathService")
	v_u_6 = v_u_1.GetController("FXController")
end
return v8